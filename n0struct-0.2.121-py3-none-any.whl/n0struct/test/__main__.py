import sys
import os

sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
import test_n0struct

test_n0struct.main()
