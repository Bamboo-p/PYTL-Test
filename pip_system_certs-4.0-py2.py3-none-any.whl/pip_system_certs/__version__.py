# Version managed by git-versioner
version = "v4.0"
version_short = "v4.0"
git_hash = "1544d35"
on_tag = "v4.0"
dirty = False
SUPPORT_PATCH = False
