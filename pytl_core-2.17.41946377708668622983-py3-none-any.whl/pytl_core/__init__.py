print("="*80 + f" START: {__file__}")

# Imports for all needen in jobs will be here
import os
import sys
import logging
import datetime
from pathlib import Path
import lxml
from lxml import objectify
from lxml import etree as et
import n0struct
import csv
import collections
import fnmatch
import json
import re
import traceback
from jinja2 import Template
'''
import numpy as np
import pandas as pd
'''

try:
    # Could be imported ONLY if it's run as module
    from importlib_metadata import version as importlib_metadata_version
    __version__ = importlib_metadata_version(__job_name__)
except:
    __version__ = "0.2.17"
__job_name__ = "pytl_core"
__bat_files__ = ["n0library.bat", "__runme.bat"]

print(f"{__file__=}")
print(f"{__version__=}")
print(f"{__job_name__=}")
print(f"{__bat_files__=}")

# Add parent of pytl_core (e.g. ".../pytl_core_repo") for imports from it.
# This will determine usage from installed package or from pytl_core src on development
# depending on job_launcher called from package of from src.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

#TODO: resort libs and chain imports scheme
from pytl_core.pytl_path import PytlPath
from pytl_core.pytl_config import Config
from pytl_core.logger import configure_logging
from pytl_core.logger import org_logging_debug, org_logging_info, org_logging_error
import pytl_core.utils as utils
from pytl_core.oracle_db import Connection, OracleDB
from pytl_core.oracle_db import PyTL_Sequence
from pytl_core.oracle_db import mask_control_m_string
from pytl_core.timestamp import Timestamp as timestamp



from pytl_core.pytl_config import Params
from pytl_core.pytl_config import raiser
from pytl_core.pytl_config import get_all_related_files

## Should be imported in the user developed file as:
## import pytl_core.pytl_globals as pytl_globals

'''
if __name__ == "__main__":
    # Init pytl app from command-line args
    # TODO: UI requirements refinement. What should we do on direct module call?
    #  Do nothing, or init config, or call job launcher? What should be the result of such usage?
    if 'cfg' not in globals():
        cfg = config = Config.configure_pytl_core()
        __all__.extend(['cfg', 'config'])
'''

__all__ = [
    'os',
    'sys',
    'logging',
    'datetime',
    'Path',
    'lxml',
    'objectify',
    'n0struct',
    'csv',
    'collections',
    'fnmatch',
    'json',
    're',
    'traceback',
    'Template',
    # 'np',
    # 'pd',
    'et',

    'PytlPath',
    'Config',
    'configure_logging',
    'org_logging_debug',
    'org_logging_info',
    'org_logging_error',
    'utils',
    'Connection',
    'OracleDB',
    'timestamp',
    'PyTL_Sequence',
    'mask_control_m_string',

    'Params',
    'raiser',
    'get_all_related_files',
]


print("-"*80 + f" END: {__file__}")
