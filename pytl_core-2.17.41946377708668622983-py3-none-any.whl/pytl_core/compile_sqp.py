import sys
import os

if __name__ == "__main__":
    print(  f"Usage: {os.path.basename(sys.argv[0])} ^\n"
            "\tORG=<any value, for example 000> ^\n"
            "\tENV=<the real path to PARM file> ^\n"
            "\tSQL_QUERY=<path to source SQP file> ^\n"
            "\tDST_FILE=<path to destination SQL file> ^\n"
            "\t+ additional parameters, which is used during SQP compilation"
    )
    # python compile_sqp.py ENV=regress.parm ORG=000 SQL_QUERY=demo_compile_on_the_fly.sqp DST_FILE=demo_compile_on_the_fly.sql BEHAVIOR=ENBDGR

    import pytl_core
    
    config = pytl_core.Config.configure_pytl_core({'JOB_FILE': __file__, 'JOB_NAME': "compile_sqp"})
    compiled_sql = pytl_core.utils.load_statement_from_file(config['SQL_QUERY'], config)
    with open(config["DST_FILE"], 'wt') as filehandler:
        filehandler.write(compiled_sql)