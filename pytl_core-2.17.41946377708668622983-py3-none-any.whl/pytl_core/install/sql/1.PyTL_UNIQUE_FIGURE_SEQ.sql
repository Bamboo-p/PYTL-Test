set linesize 2000
set serveroutput on
set verify off

declare
    V_SQL_TEXT  varchar2(32000);
    V_SEQ_NAME1 varchar2(30) := 'PyTL_UNIQUE_FIGURE__SEQ';
    V_SEQ_NAME2 varchar2(30) := 'PyTL_PETRA_UNIQUE_FIGURE__SEQ';
begin
    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create sequence ''' || V_SEQ_NAME1 || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_SEQUENCES t where upper(t.SEQUENCE_NAME) = upper(V_SEQ_NAME1) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create sequence ' || V_SEQ_NAME1 || ' MINVALUE 1 MAXVALUE 9999 start with 1 cache 20 cycle';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;
    
    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create sequence ''' || V_SEQ_NAME2 || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_SEQUENCES t where upper(t.SEQUENCE_NAME) = upper(V_SEQ_NAME2) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create sequence ' || V_SEQ_NAME2 || ' MINVALUE 1 MAXVALUE 9999 start with 1 cache 20 cycle';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;
    
    commit;
end;
/

exit;
