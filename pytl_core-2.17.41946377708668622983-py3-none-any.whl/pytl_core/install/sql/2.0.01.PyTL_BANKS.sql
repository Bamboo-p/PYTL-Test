set linesize 2000
set serveroutput on
set verify off

declare
    V_SQL_TEXT   varchar2(32000);
    V_TABLE_NAME USER_TABLES.TABLE_NAME%type := 'PyTL_BANKS';
begin
    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create table ''' || V_TABLE_NAME || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_TABLES where upper(TABLE_NAME) = upper(V_TABLE_NAME) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create table '|| V_TABLE_NAME ||'(
                            BANK_CODE varchar2(8) primary key,
                            BANK_DESC varchar2(4000)
                       )
        ';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;

    V_SQL_TEXT := 'merge into ' || V_TABLE_NAME || ' trgt using (';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''057'' as BANK_CODE, ''Banque MISR''               as BANK_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''033'' as BANK_CODE, ''NBD''                       as BANK_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''010'' as BANK_CODE, ''BANK_010''                  as BANK_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''011'' as BANK_CODE, ''BANK_011''                  as BANK_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''101'' as BANK_CODE, ''BANK_101''                  as BANK_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''012'' as BANK_CODE, ''BANK_012''                  as BANK_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''049'' as BANK_CODE, ''Banque WARBA''              as BANK_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''994'' as BANK_CODE, ''PETRA Issuing DEV R 16.5''  as BANK_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''016'' as BANK_CODE, ''KSA''                       as BANK_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''017'' as BANK_CODE, ''EIB''                       as BANK_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''034'' as BANK_CODE, ''ENBD Egypt''                as BANK_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ') src on (src.BANK_CODE = trgt.BANK_CODE)
                    when not matched then insert values (src.BANK_CODE, src.BANK_DESC)
                    when matched     then update set trgt.BANK_DESC = src.BANK_DESC
    ';
    V_SQL_TEXT := regexp_replace(V_SQL_TEXT, ' +', ' ');
    dbms_output.put_line('>>> ' || V_SQL_TEXT);
    execute immediate V_SQL_TEXT;

    commit;
end;
/


exit;
