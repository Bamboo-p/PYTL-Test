set linesize 2000
set serveroutput on
set verify off

declare
    V_SQL_TEXT   varchar2(32000);
    V_TABLE_NAME USER_TABLES.TABLE_NAME%type := 'PyTL_JOB_PARAMS';
begin
    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create table ''' || V_TABLE_NAME || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_TABLES where upper(TABLE_NAME) = upper(V_TABLE_NAME) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create table ' || V_TABLE_NAME || '(
                            PARAM_ID    number(20) primary key, 
                            PARAMS_NAME varchar2(255) not null,
                            PARAM_DESC  varchar2(4000)
                       )
        ';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;
    commit;
end;
/

/*
begin
    merge into PyTL_JOB_PARAMS trgt
    using(
           select -1 as param_id, 'applicationFilePrefix' as params_name, 'Interface-specific XML application file prefix' as param_desc from dual
             union all
           select 86 as param_id, 'FOLLOWING_JOB'as params_name, 'Talend Job which follows just after the current one' as param_desc from dual
             union all
           select 87 as param_id, 'WAY4_RESPONSE_FILE'as params_name, 'The file name which is returned from the way4 system as a update credit limit process report' as param_desc from dual
             union all
           select 88 as param_id, 'TEMP_TABLE_NAME'as params_name, 'Table name where temporary data is being put to' as param_desc from dual
             union all
           select 105 as param_id, 'ORG1'as params_name, '' as param_desc from dual
             union all
           select 106 as param_id, 'ORG2'as params_name, '' as param_desc from dual
             union all
           select 107 as param_id, 'ORG3'as params_name, '' as param_desc from dual
             union all
           select 108 as param_id, 'ORG4'as params_name, '' as param_desc from dual
             union all
           select 109 as param_id, 'ORG5'as params_name, '' as param_desc from dual
             union all
           select 110 as param_id, 'XML_FILENAME1'as params_name, '' as param_desc from dual
             union all
           select 111 as param_id, 'XML_FILENAME2'as params_name, '' as param_desc from dual
             union all
           select 112 as param_id, 'XML_FILENAME3'as params_name, '' as param_desc from dual
             union all
           select 113 as param_id, 'XML_FILENAME4'as params_name, '' as param_desc from dual
             union all
           select 114 as param_id, 'XML_FILENAME5'as params_name, '' as param_desc from dual
             union all
           select 10 as param_id, 'REPORT_DATE'as params_name, 'Banking date of report' as param_desc from dual
             union all
           select 11 as param_id, 'SQL_WHERE_FILTER'as params_name, 'Custom SQL WHERE filter, one or more conditions i.e. 1=1' as param_desc from dual
             union all
           select 23 as param_id, 'REPORT_DST_PATH'as params_name, 'Directory path where report file will be stored' as param_desc from dual
             union all
           select 24 as param_id, 'REPORT_FILE_NAME'as params_name, 'Report file name' as param_desc from dual
             union all
           select 25 as param_id, 'STATS_DST_PATH'as params_name, 'Directory path where stats file will be stored' as param_desc from dual
             union all
           select 26 as param_id, 'STATS_FILE_NAME'as params_name, 'Stats file name' as param_desc from dual
             union all
           select 27 as param_id, 'ERRORS_FILE_NAME'as params_name, 'Errors file name' as param_desc from dual
             union all
           select 28 as param_id, 'ERRORS_DST_PATH'as params_name, 'Errors destination file path' as param_desc from dual
             union all
           select 19 as param_id, 'DLY_FH_REC'as params_name, 'File Header indicator' as param_desc from dual
             union all
           select 20 as param_id, 'DLY_FILE_ID'as params_name, 'File ID Indicator' as param_desc from dual
             union all
           select 21 as param_id, 'DLY_FILE_TAPNUM'as params_name, 'Tape Number' as param_desc from dual
             union all
           select 22 as param_id, 'reportName'as params_name, '' as param_desc from dual
             union all
           select 32 as param_id, 'BATCH_PROCESSING_INPUT_FILE'as params_name, 'Incoming file name which will be recieved from a bank to update credit limit(s) in batch mode' as param_desc from dual
             union all
           select 33 as param_id, 'ADHOC_PROCESSING_INPUT_FILE'as params_name, 'Incoming file name which will be recieved from a bank to update credit limit(s) in adhoc mode' as param_desc from dual
             union all
           select 49 as param_id, 'versNum'as params_name, '' as param_desc from dual
             union all
           select 50 as param_id, 'subscribeId'as params_name, '' as param_desc from dual
             union all
           select 51 as param_id, 'formatId'as params_name, '' as param_desc from dual
             union all
           select 52 as param_id, 'groupId'as params_name, '' as param_desc from dual
             union all
           select 53 as param_id, 'userId'as params_name, '' as param_desc from dual
             union all
           select 54 as param_id, 'subscriberName'as params_name, '' as param_desc from dual
             union all
           select 55 as param_id, 'dateFormat'as params_name, '' as param_desc from dual
             union all
           select 56 as param_id, 'headerRecType'as params_name, '' as param_desc from dual
             union all
           select 57 as param_id, 'bottomRecType'as params_name, '' as param_desc from dual
             union all
           select 58 as param_id, 'reportName'as params_name, '' as param_desc from dual
             union all
           select 61 as param_id, 'versNum'as params_name, '' as param_desc from dual
             union all
           select 62 as param_id, 'subscribeId'as params_name, '' as param_desc from dual
             union all
           select 63 as param_id, 'formatId'as params_name, '' as param_desc from dual
             union all
           select 64 as param_id, 'groupId'as params_name, '' as param_desc from dual
             union all
           select 65 as param_id, 'userId'as params_name, '' as param_desc from dual
             union all
           select 66 as param_id, 'subscriberName'as params_name, '' as param_desc from dual
             union all
           select 67 as param_id, 'dateFormat'as params_name, '' as param_desc from dual
             union all
           select 68 as param_id, 'headerRecType'as params_name, '' as param_desc from dual
             union all
           select 69 as param_id, 'bottomRecType'as params_name, '' as param_desc from dual
             union all
           select 70 as param_id, 'reportName'as params_name, '' as param_desc from dual
             union all
           select 71 as param_id, 'versNum'as params_name, '' as param_desc from dual
             union all
           select 72 as param_id, 'subscribeId'as params_name, '' as param_desc from dual
             union all
           select 73 as param_id, 'formatId'as params_name, '' as param_desc from dual
             union all
           select 74 as param_id, 'groupId'as params_name, '' as param_desc from dual
             union all
           select 75 as param_id, 'userId'as params_name, '' as param_desc from dual
             union all
           select 76 as param_id, 'subscriberName'as params_name, '' as param_desc from dual
             union all
           select 77 as param_id, 'dateFormat'as params_name, '' as param_desc from dual
             union all
           select 78 as param_id, 'headerRecType'as params_name, '' as param_desc from dual
             union all
           select 79 as param_id, 'bottomRecType'as params_name, '' as param_desc from dual
             union all
           select 80 as param_id, 'reportName'as params_name, '' as param_desc from dual
             union all
           select 89 as param_id, 'BANK_010'as params_name, '' as param_desc from dual
             union all
           select 90 as param_id, 'BANK_011'as params_name, '' as param_desc from dual
             union all
           select 91 as param_id, 'BANK_012'as params_name, '' as param_desc from dual
             union all
           select 92 as param_id, 'BANK_101'as params_name, '' as param_desc from dual
             union all
           select 93 as param_id, 'BANK_033'as params_name, '' as param_desc from dual
             union all
           select 94 as param_id, 'JOB_REQUEST_FILE_010'as params_name, 'File which comes from the Talend job with credit limit update data to the Way4 for bank 010' as param_desc from dual
             union all
           select 95 as param_id, 'JOB_REQUEST_FILE_011'as params_name, 'File which comes from the Talend job with credit limit update data to the Way4 for bank 011' as param_desc from dual
             union all
           select 96 as param_id, 'JOB_REQUEST_FILE_012'as params_name, 'File which comes from the Talend job with credit limit update data to the Way4 for bank 012' as param_desc from dual
             union all
           select 97 as param_id, 'JOB_REQUEST_FILE_101'as params_name, 'File which comes from the Talend job with credit limit update data to the Way4 for bank 101' as param_desc from dual
             union all
           select 98 as param_id, 'JOB_REQUEST_FILE_033'as params_name, 'File which comes from the Talend job with credit limit update data to the Way4 for bank 033' as param_desc from dual
             union all
           select 99 as param_id, 'WAY4_RESPONSE_FILE_010'as params_name, 'The file name which is returned from the way4 system as a update credit limit process report for bank 010' as param_desc from dual
             union all
           select 100 as param_id, 'WAY4_RESPONSE_FILE_011'as params_name, 'The file name which is returned from the way4 system as a update credit limit process report for bank 011' as param_desc from dual
             union all
           select 101 as param_id, 'WAY4_RESPONSE_FILE_012'as params_name, 'The file name which is returned from the way4 system as a update credit limit process report for bank 010' as param_desc from dual
             union all
           select 102 as param_id, 'WAY4_RESPONSE_FILE_101'as params_name, 'The file name which is returned from the way4 system as a update credit limit process report for bank 101' as param_desc from dual
             union all
           select 103 as param_id, 'WAY4_RESPONSE_FILE_033'as params_name, 'The file name which is returned from the way4 system as a update credit limit process report for bank 033' as param_desc from dual
             union all
           select 104 as param_id, 'WAY4_RESPONSE_FILE_MASK'as params_name, 'The file MASK name which is returned from the way4 system as a update credit limit process report for bank 033' as param_desc from dual
             union all
           select 115 as param_id, 'FILE_LABEL'as params_name, 'File Label' as param_desc from dual
             union all
           select 125 as param_id, 'prevJobName'as params_name, '' as param_desc from dual
             union all
           select 14 as param_id, 'formatDate'as params_name, '' as param_desc from dual
             union all
           select 15 as param_id, 'dateFormat'as params_name, '' as param_desc from dual
             union all
           select 16 as param_id, 'bottomRecType'as params_name, '' as param_desc from dual
             union all
           select 17 as param_id, 'reportName'as params_name, '' as param_desc from dual
             union all
           select 34 as param_id, 'IN_XML_PREFIX'as params_name, 'Input XML file name prefix to W4' as param_desc from dual
             union all
           select 35 as param_id, 'REG_PREFIX'as params_name, 'Record prefix' as param_desc from dual
             union all
           select 36 as param_id, 'FORMAT_VERSION'as params_name, 'File format version' as param_desc from dual
             union all
           select 37 as param_id, 'productCodePrefix'as params_name, 'Prefix for Product Code (format: Prefix + Logo + Suffix), ex. 033_AED_' as param_desc from dual
             union all
           select 38 as param_id, 'productCodeSuffix'as params_name, 'Suffix for Product Code (format: Prefix + Logo + Suffix), ex. _A' as param_desc from dual
             union all
           select 81 as param_id, 'SEQUENCE_VALUE'as params_name, 'Just sequence unique value' as param_desc from dual
             union all
           select 82 as param_id, 'OUTER_REQUEST_FILE'as params_name, 'File which comes from the outer sustems with credit limit update data' as param_desc from dual
             union all
           select 83 as param_id, 'JOB_REQUEST_FILE_PREFIX'as params_name, 'File which comes from the Talend job with credit limit update data to the Way4' as param_desc from dual
             union all
           select 84 as param_id, 'JOB_RESPONSE_SUCCESS_PREFIX'as params_name, 'Name prefix of the file which comes from the Talend Job after Way4 credit limit report processing and having SUCCESS status' as param_desc from dual
             union all
           select 85 as param_id, 'JOB_RESPONSE_FAIL_PREFIX'as params_name, 'Name prefix of the file which comes from the Talend Job after Way4 credit limit report processing and having FAIL status' as param_desc from dual
             union all
           select 0 as param_id, 'ZERO_PARAMETER'as params_name, '' as param_desc from dual
             union all
           select 1 as param_id, 'dateFormat'as params_name, '' as param_desc from dual
             union all
           select 2 as param_id, 'emptyDate'as params_name, '' as param_desc from dual
             union all
           select 3 as param_id, 'fileName'as params_name, '' as param_desc from dual
             union all
           select 4 as param_id, 'versNum'as params_name, '' as param_desc from dual
             union all
           select 5 as param_id, 'subsribeId'as params_name, '' as param_desc from dual
             union all
           select 6 as param_id, 'formatId'as params_name, '' as param_desc from dual
             union all
           select 7 as param_id, 'groupId'as params_name, '' as param_desc from dual
             union all
           select 8 as param_id, 'userId'as params_name, '' as param_desc from dual
             union all
           select 9 as param_id, 'subscriberName'as params_name, '' as param_desc from dual
             union all
           select 12 as param_id, 'subscribeId'as params_name, '' as param_desc from dual
             union all
           select 13 as param_id, 'headerRecType'as params_name, '' as param_desc from dual
             union all
           select 18 as param_id, 'P_REPORT_DATE'as params_name, 'Parameter for banking date of report' as param_desc from dual
             union all
           select 29 as param_id, 'SEQ_NAME'as params_name, 'sequence for generating unique file names' as param_desc from dual
             union all
           select 31 as param_id, 'RESPONSE_FILE_NAME'as params_name, 'file name with credit limit update results from way4' as param_desc from dual
             union all
           select 40 as param_id, 'REG_PREFIX'as params_name, '' as param_desc from dual
             union all
           select 41 as param_id, 'reportName'as params_name, '' as param_desc from dual
             union all
           select 30 as param_id, 'REQUEST_FILE_NAME'as params_name, 'file name to be created to send to way4 to update credit limits' as param_desc from dual
             union all
           select 39 as param_id, 'INTERFACE_CLASSIFIER'as params_name, '' as param_desc from dual
             union all
           select 48 as param_id, 'REG_PREFIX'as params_name, '' as param_desc from dual
             union all
           select 59 as param_id, 'ADHOC_INPUT_UPLOAD_PATH'as params_name, 'Incoming file path where talend job will be recieve uploaded_files from a bank to update credit limit(s) in adhoc mode' as param_desc from dual
             union all
           select 60 as param_id, 'BATCH_INPUT_UPLOAD_PATH'as params_name, 'Incoming file path where talend job will be recieve uploaded_files from a bank to update credit limit(s) in adhoc mode' as param_desc from dual
             union all
           select 45 as param_id, 'INTERFACE_CLASSIFIER'as params_name, '' as param_desc from dual
             union all
           select 46 as param_id, 'REG_PREFIX'as params_name, '' as param_desc from dual
             union all
           select 47 as param_id, 'INTERFACE_CLASSIFIER'as params_name, '' as param_desc from dual
             union all
           select 127 as param_id, 'INPUT_TEMP_TABLE_NAME'as params_name, '' as param_desc from dual
             union all
           select 128 as param_id, 'AL_ANSARI_EX_SENDER'as params_name, 'Stores value for Sender field for Al_Ansari_Exchange' as param_desc from dual
             union all
           select 129 as param_id, 'AL_ANSARI_EX_RECEIVER'as params_name, 'Stores value for Receiver field for Al_Ansari_Exchange' as param_desc from dual
             union all
           select 131 as param_id, 'CHECK_DATA_TABLE'as params_name, '' as param_desc from dual
             union all
           select 134 as param_id, 'FILE_PREFIX'as params_name, '' as param_desc from dual
             union all
           select 126 as param_id, 'REG_PREFIX'as params_name, '' as param_desc from dual
             union all
           select 130 as param_id, 'DICTIONARY_TABLE_NAME'as params_name, '' as param_desc from dual
             union all
           select 132 as param_id, 'JOB_LAUNCH_DATE'as params_name, 'Launching date(Last or current)' as param_desc from dual
             union all
           select 133 as param_id, 'SEQUENCE_VALUE'as params_name, 'Launching date(Last or current)' as param_desc from dual
             union all
           select 121 as param_id, 'BAL_LIMIT'as params_name, 'Balance limit for conditions in accounts purging process' as param_desc from dual
             union all
           select 120 as param_id, 'ORG'as params_name, 'ORG value' as param_desc from dual
             union all
           select 135 as param_id, 'FINPAY_IN_SENDER'as params_name, 'Sender value for ENBDCC_IS_In_FinaclePayment job' as param_desc from dual
             union all
           select 136 as param_id, 'FINPAY_IN_RECEIVER'as params_name, 'Sender value for ENBDCC_IS_In_FinaclePayment job' as param_desc from dual
             union all
           select 137 as param_id, 'FINPAY_IN_MEMBER'as params_name, 'Sender value for ENBDCC_IS_In_FinaclePayment job' as param_desc from dual
             union all
           select 138 as param_id, 'FINPAY_IN_TRANSIT'as params_name, 'Sender value for ENBDCC_IS_In_FinaclePayment job' as param_desc from dual
    )src
    on (trgt.param_id = src.param_id)
    when not matched
      then insert values (src.param_id, src.params_name, src.param_desc)
    ;
    commit;
end;
/
*/

exit;
