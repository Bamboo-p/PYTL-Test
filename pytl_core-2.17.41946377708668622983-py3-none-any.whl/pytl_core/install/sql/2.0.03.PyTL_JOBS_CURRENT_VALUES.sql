set linesize 2000
set serveroutput on
set verify off

declare
    V_SQL_TEXT     varchar2(32000);
    V_TABLE_NAME   USER_TABLES.TABLE_NAME%type  := 'PyTL_JOBS_CURRENT_VALUES';
    V_INDEX_NAME_1 USER_INDEXES.INDEX_NAME%type := 'PyTL_JOBS_CURRENT_VALUES__INDEX';
    V_INDEX_NAME_2 USER_INDEXES.INDEX_NAME%type := 'PyTL_JOBS_CURR_VAL_SEQ__INDEX';
begin
    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create table ''' || V_TABLE_NAME || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_TABLES where upper(TABLE_NAME) = upper(V_TABLE_NAME) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create table ' || V_TABLE_NAME || '(
                            IN_JOB_ID varchar2(255),
                            OUT_JOB_ID varchar2(255),
                            CURRENT_SEQUENCE_VALUE number(5,0),
                            RECORD_STATUS varchar2(20) default ''OPEN'',
                            OPEN_DATE date default sysdate,
                            CLOSE_DATE date default to_date(''31122999'',''DDMMYYYY'')
                       )
        ';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;

    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create index ''' || V_INDEX_NAME_1 || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_INDEXES where upper(INDEX_NAME) = upper(V_INDEX_NAME_1) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create index '|| V_INDEX_NAME_1 ||' on '|| V_TABLE_NAME ||'(OUT_JOB_ID, RECORD_STATUS)';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;

    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create index ''' || V_INDEX_NAME_2 || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_INDEXES where upper(INDEX_NAME) = upper(V_INDEX_NAME_2) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create index '|| V_INDEX_NAME_2 ||' on '|| V_TABLE_NAME ||'(OUT_JOB_ID, CURRENT_SEQUENCE_VALUE)';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;

    commit;
end;
/

exit;
