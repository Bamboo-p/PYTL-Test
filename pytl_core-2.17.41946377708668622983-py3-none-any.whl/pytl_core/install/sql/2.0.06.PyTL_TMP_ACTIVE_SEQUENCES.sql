set linesize 2000
set serveroutput on
set verify off

declare
    V_SQL_TEXT   varchar2(32000);
    V_TABLE_NAME USER_TABLES.TABLE_NAME%type := 'PyTL_TMP_ACTIVE_SEQUENCES';
begin
    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create table ''' || V_TABLE_NAME || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_TABLES where upper(TABLE_NAME) = upper(V_TABLE_NAME) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create table '|| V_TABLE_NAME ||'(
                            JOB_ID varchar2(255),
                            SEQ_VALUE number(5),
                            SEQ_STATUS varchar2(20),
                            CREATE_DATE date default sysdate
                       )
        ';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;

    commit;
end;
/

exit;

