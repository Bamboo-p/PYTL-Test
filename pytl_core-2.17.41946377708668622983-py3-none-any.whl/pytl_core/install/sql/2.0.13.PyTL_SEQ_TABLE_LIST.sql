/* 
    TALEND: DDL script for the table TLND_SEQ_TABLE_LIST this table is used in the job 'ENBDCC_IS_In_Technical'
    It is used by PyTL_JOB_SUPPORT.delete_old_sequences(p_days NUMBER default 14)
*/
set linesize 2000
set serveroutput on
set verify off

declare
    V_SQL_TEXT   varchar2(32000);
    V_TABLE_NAME USER_TABLES.TABLE_NAME%type := 'PyTL_SEQ_TABLE_LIST';
begin
    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create table ''' || V_TABLE_NAME || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_TABLES where upper(TABLE_NAME) = upper(V_TABLE_NAME) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create table '|| V_TABLE_NAME ||'(
                            TABLE_NAME varchar2(30)        
                       )
        ';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;
    
    V_SQL_TEXT := 'merge into ' || V_TABLE_NAME || ' trgt using (';
    -- V_SQL_TEXT := V_SQL_TEXT || 'select ''PyTL_FINPAY_CURRENT_VALUES''   as TABLE_NAME from dual';
    -- V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''PyTL_JOBS_CURRENT_VALUES''     as TABLE_NAME from dual';
    -- V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    -- V_SQL_TEXT := V_SQL_TEXT || 'select ''PyTL_SPGBPF_CURRENT_VALUES''   as TABLE_NAME from dual';
    -- V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    -- V_SQL_TEXT := V_SQL_TEXT || 'select ''PyTL_ALANSARI_CURRENT_VALUES'' as TABLE_NAME from dual';
    V_SQL_TEXT := V_SQL_TEXT || ') src on (src.TABLE_NAME = trgt.TABLE_NAME) when not matched then insert values (src.TABLE_NAME)';
    V_SQL_TEXT := regexp_replace(V_SQL_TEXT, ' +', ' ');
    dbms_output.put_line('>>> ' || V_SQL_TEXT);
    execute immediate V_SQL_TEXT;

    commit;
end;
/

exit;
