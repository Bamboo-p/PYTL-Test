set linesize 2000
set serveroutput on
set verify off

declare
    V_SQL_TEXT   varchar2(32000);
    V_TABLE_NAME USER_TABLES.TABLE_NAME%type := 'PyTL_JOBS';
begin
    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create table ''' || V_TABLE_NAME || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_TABLES where upper(TABLE_NAME) = upper(V_TABLE_NAME) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create table '|| V_TABLE_NAME ||'(
                            JOB_ID   varchar2(255) primary key,
                            JOB_DESC varchar2(4000)
                       )
        ';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;

/*
    -- Just a sample for updating jobs' descriptions
    V_SQL_TEXT := 'merge into ' || V_TABLE_NAME || ' trgt using (';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''ENBD_IS_In_Al_Ansari_Exchange''    as JOB_ID, ''To capture the detail on Al Ansari payment file''  as JOB_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ' union all ';
    V_SQL_TEXT := V_SQL_TEXT || 'select ''ENBDCC_IS_In_BulkAccountTransfer'' as JOB_ID, ''Input bulk Account transfer file job for ENBD CC'' as JOB_DESC from dual';
    V_SQL_TEXT := V_SQL_TEXT || ') src on (src.BANK_CODE = trgt.BANK_CODE)
                    when not matched then insert values (src.BANK_CODE, src.SEQ_NAME)
                    when matched     then update set trgt.SEQ_NAME = src.SEQ_NAME
    ';
    V_SQL_TEXT := regexp_replace(V_SQL_TEXT, ' +', ' ');
    dbms_output.put_line('>>> ' || V_SQL_TEXT);
    execute immediate V_SQL_TEXT;
*/

    commit;
end;
/

exit;
