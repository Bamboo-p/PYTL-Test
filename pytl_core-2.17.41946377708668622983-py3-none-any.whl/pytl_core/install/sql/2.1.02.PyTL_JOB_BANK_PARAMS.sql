set linesize 2000
set serveroutput on
set verify off

declare
    V_SQL_TEXT     varchar2(32000);
    V_TABLE_NAME   USER_TABLES.TABLE_NAME%type  := 'PyTL_JOB_BANK_PARAMS';
    V_INDEX_NAME_1 USER_INDEXES.INDEX_NAME%type := 'PyTL_JOB_BANK_PARAMS__INDEX';
begin
    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create table ''' || V_TABLE_NAME || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_TABLES where upper(TABLE_NAME) = upper(V_TABLE_NAME) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create table ' || V_TABLE_NAME || '(
                            JOB_ID      varchar2(255),
                            BANK_CODE   varchar2(8),
                            PARAM_ID    number(20),
                            PARAM_VALUE varchar2(4000),

                            constraint PyTL_JOB_BANK_PARAMS__PyTL_JOBS__FK          foreign key (JOB_ID)    references PyTL_JOBS(JOB_ID),
                            constraint PyTL_JOB_BANK_PARAMS__PyTL_BANKS__FK         foreign key (BANK_CODE) references PyTL_BANKS(BANK_CODE),
                            constraint PyTL_JOB_BANK_PARAMS__PyTL_JOB_PARAMS__FK    foreign key (PARAM_ID)  references PyTL_JOB_PARAMS(PARAM_ID)

                       )
        ';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;

    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create index ''' || V_INDEX_NAME_1 || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_INDEXES where upper(INDEX_NAME) = upper(V_INDEX_NAME_1) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create index '|| V_INDEX_NAME_1 ||' on '|| V_TABLE_NAME ||'(JOB_ID, BANK_CODE, PARAM_ID)';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;

    commit;
end;
/

exit;
