set linesize 2000
set serveroutput on
set verify off

declare
    V_SQL_TEXT   varchar2(32000);
    V_VIEW_NAME USER_VIEWS.VIEW_NAME%type := 'PyTL_TMP_ACTIVE_SEQUENCES_VW';
begin
    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to create table ''' || V_VIEW_NAME || ''' if DOES NOT exist');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_VIEWS where upper(VIEW_NAME) = upper(V_VIEW_NAME) having count(1) = 0)
    loop
        V_SQL_TEXT := 'create or replace force view '|| V_VIEW_NAME ||'(
                            OUT_JOB_ID,
                            CURRENT_SEQUENCE_VALUE,
                            OPEN_DATE
                        ) as
                            select
                                OUT_JOB_ID,
                                CURRENT_SEQUENCE_VALUE,
                                OPEN_DATE
                            from
                                PyTL_JOBS_CURRENT_VALUES
                            where
                                RECORD_STATUS = ''OPEN''
        ';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;

    commit;
end;
/

exit;

