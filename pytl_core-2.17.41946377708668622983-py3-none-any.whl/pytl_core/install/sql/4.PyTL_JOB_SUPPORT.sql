create or replace package PyTL_JOB_SUPPORT is

  /*
    constants representations
  */
  function C__ACTIVE  return VARCHAR2;
  function C__PROCESSED return VARCHAR2;
  function C__OPEN  return VARCHAR2;
  function C__CLOSED  return VARCHAR2;
  function C__ACTIVE_SEQ_TABLE_NAME return VARCHAR2;
  function C__CURR_JOB_VAL_TABLE_NAME return VARCHAR2;
  function C__ACTIVE_SEQ_VIEW_NAME return VARCHAR2;
  function C__MODE_DELETE return VARCHAR2;
  function C__MODE_MARK return VARCHAR2;
  function C__JOB_RELATIONS_TABLE_NAME return VARCHAR2;


  /* The purpose of this function is to get the next sequence value (mostly in In-interfaces)
      and save the sequence value with interim data for further processing (mostly in the corresponding Out-interfaces)
  */
  function getSequenceValue(p_job_name IN VARCHAR2
                            , p_file_name IN VARCHAR2 default null
                            , p_bank_code VARCHAR2 default null)
  return VARCHAR2;


  /* The purpose of this function is to get the next sequence value by job name */
  function getSeqValueByJob(p_job_name IN VARCHAR2)
  return VARCHAR2;


   /* The purpose of this function is to get the next sequence value by bank code */
  function getBankSequenceValue(p_job_name IN VARCHAR2
                             , p_bank_code IN VARCHAR2
                             )
  return VARCHAR2;


  /* procedure marks or delete the seq value from the temp_table to exclude this sequence from the further calculations
    p_mode: ['DELETE', 'MARKED_AS_PROCESSED']
  */
  procedure setSeqValueUsed(p_job_id VARCHAR2
                             , p_seq_value NUMBER
                             , p_mode VARCHAR2 default C__MODE_DELETE
                           );


  /* procedure to insert in and out jobs into the relation table */
  procedure addJobPairs(
                        p_in_job_id VARCHAR2,
                        p_out_job_id VARCHAR2
                       );


  /*
    * procedure deletes old sequence numbers from the TLND tech tables in order to keep the system tough
    * parameter p_days: real TTL for the sequence record in the tech tables.
  */
  procedure delete_old_sequences(p_days NUMBER default 14);

end PyTL_JOB_SUPPORT;
/

commit;
exit;
