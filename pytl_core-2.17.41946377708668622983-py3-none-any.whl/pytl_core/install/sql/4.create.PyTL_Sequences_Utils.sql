/*
    Changes history
    ---------------
    220827.1 = Denis Kaloshin = ENG-4678: RAW/NUMBER types, Sequence+Trigger support are added
    220905.1 = Denis Kaloshin = ENG-4678: Isolated package PyTL_Sequences_Utils
*/
create or replace package PyTL_Sequences_Utils is
    function get_sequence_value(P_SEQUENCE_NAME varchar2, P_SEQUENCE_RESERVE number default 1) return number;
    procedure save_sequence_value(p_sequence_name varchar2, p_sequence_value number);
end PyTL_Sequences_Utils;
/
commit;
/
create or replace package body PyTL_Sequences_Utils is
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
    function get_sequence_value(P_SEQUENCE_NAME varchar2, P_SEQUENCE_RESERVE number default 1) return number
    as
        V_SEQUENCE_VALUE    number;
    begin
        select sum(SEQUENCE_VALUE)
        into   V_SEQUENCE_VALUE
        from   PyTL_Sequences
        where  upper(SEQUENCE_NAME) = upper(P_SEQUENCE_NAME)
        ;

        if V_SEQUENCE_VALUE is null then
            V_SEQUENCE_VALUE := 0;
        end if;

        PyTL_Sequences_Utils.save_sequence_value(P_SEQUENCE_NAME, V_SEQUENCE_VALUE + P_SEQUENCE_RESERVE);
        return V_SEQUENCE_VALUE;
    end get_sequence_value;
--------------------------------------------------------------------------------
    procedure save_sequence_value(P_SEQUENCE_NAME varchar2, P_SEQUENCE_VALUE number)
    as
        pragma autonomous_transaction;
    begin
        merge into PyTL_Sequences using dual on (SEQUENCE_NAME = P_SEQUENCE_NAME)
        when not matched then insert (SEQUENCE_NAME, SEQUENCE_VALUE) values (P_SEQUENCE_NAME, P_SEQUENCE_VALUE)
        when matched then update set SEQUENCE_VALUE = P_SEQUENCE_VALUE;

        commit;
        return;
    end save_sequence_value;
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
end PyTL_Sequences_Utils;
/
commit;
/
exit;
