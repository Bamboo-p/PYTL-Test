create or replace package body PyTL_JOB_SUPPORT is

  /* constants */
  /* C__ACTIVE */
  function C__ACTIVE
    return VARCHAR2
  is
  begin
    return 'ACTIVE';
  end C__ACTIVE;

  /* C__PROCESSED */
  function C__PROCESSED
    return VARCHAR2
  is
  begin
    return 'PROCESSED';
  end C__PROCESSED;

    /* C__OPEN */
  function C__OPEN
    return VARCHAR2
  is
  begin
    return 'OPEN';
  end C__OPEN;

    /* C__CLOSED */
  function C__CLOSED
    return VARCHAR2
  is
  begin
    return 'CLOSED';
  end C__CLOSED;

  /* C__ACTIVE_SEQ_TABLE_NAME */
  function C__ACTIVE_SEQ_TABLE_NAME
    return VARCHAR2
  is
  begin
    return 'PyTL_TMP_ACTIVE_SEQUENCES';
  end C__ACTIVE_SEQ_TABLE_NAME;

  /* C__CURR_JOB_VAL_TABLE_NAME */
  function C__CURR_JOB_VAL_TABLE_NAME
    return VARCHAR2
  is
  begin
    return 'PyTL_JOBS_CURRENT_VALUES';
  end C__CURR_JOB_VAL_TABLE_NAME;

  /* C__ACTIVE_SEQ_VIEW_NAME */
  function C__ACTIVE_SEQ_VIEW_NAME
    return VARCHAR2
  is
  begin
    return 'PyTL_TMP_ACTIVE_SEQUENCES_VW';
  end C__ACTIVE_SEQ_VIEW_NAME;

  /* C__MODE_DELETE */
  function C__MODE_DELETE
    return VARCHAR2
  is
  begin
    return 'DELETE';
  end C__MODE_DELETE;

  /* C__MODE_MARK */
  function C__MODE_MARK
    return VARCHAR2
  is
  begin
    return 'MARKED_AS_PROCESSED';
  end C__MODE_MARK;

  /* C__JOB_RELATIONS_TABLE_NAME */
  function C__JOB_RELATIONS_TABLE_NAME
    return VARCHAR2
  is
  begin
    return 'PyTL_JOB_RELATIONS';
  end C__JOB_RELATIONS_TABLE_NAME;

  
  /* Function which returns the name of the following Talend job which is the next to the starter talend job */
  function getNextJobName(p_job_id IN VARCHAR2
                          , p_bank_code IN VARCHAR2
                         )
    return VARCHAR2
  is
    v_next_job_name PyTL_JOB_BANK_PARAMS.PARAM_VALUE%type;
  begin
    select max(t.param_value) into v_next_job_name
      from PyTL_JOB_BANK_PARAMS t
        where t.job_id = p_job_id
          and t.param_id = 86 /*FOLLOWING_JOB*/
    ;

    return v_next_job_name;
  end getNextJobName;

  
  /*
    Function returns sequence name
      the sequence name belongs to the precise institution code
      this sequence will be used for generating unique figures
  */
  function getSequenceName (p_job_name IN VARCHAR2
                             , p_bank_code IN VARCHAR2 default null
                           )
    return VARCHAR2
    is
      v_sn VARCHAR2(30);
      v_seqname_param_id PyTL_JOB_PARAMS.param_id%type := 29 /*SEQ_NAME*/;
    begin
      execute immediate 'select max(pars.param_value) keep (dense_rank first order by pars.bank_code nulls last)
                            from PyTL_JOB_BANK_PARAMS pars
                             where pars.job_id = :1
                               and (pars.bank_code is null or pars.bank_code '||case when p_bank_code is null then ' is null' else ' = '''||p_bank_code||'''' end || ')
                               and pars.param_id = :2 /*SEQ_NAME*/
      ' into v_sn using p_job_name, v_seqname_param_id;
      return v_sn;
    exception
      when others then
        return 'PyTL_UNIQUE_FIGURE__SEQ';
  end getSequenceName;

  /* overload: just to use only one sequence */
  function getSequenceName
    return VARCHAR2
  is
  begin
    return 'PyTL_UNIQUE_FIGURE__SEQ';
  end getSequenceName;

  /*
    Function returns sequence name
      the sequence name belongs to the precise institution code
      this sequence will be used for generating unique figures
  */
  function getBankSequenceName (p_bank_code IN VARCHAR2 default null)
    return VARCHAR2
    is
      v_sn VARCHAR2(30);
    begin
      execute immediate 'select seqs.seq_name
                            from PyTL_BANKS_SEQ_NAMES seqs
                            where seqs.bank_code = :1
      ' into v_sn using p_bank_code;
      return v_sn;
    exception
      when others then
        return 'PyTL_UNIQUE_FIGURE__SEQ';
  end getBankSequenceName;

  
  /* procedure put the sequence value given in the IN parameter p_seq_value for p_job_id job */
  procedure saveCurrentSeqValue(p_job_id VARCHAR2
                                 , p_seq_value NUMBER
                               )
    is
      pragma autonomous_transaction;
    begin

      execute immediate 'insert into '|| C__ACTIVE_SEQ_TABLE_NAME||'(job_id, seq_value, seq_status, create_date)
                           values (:1, :2, PyTL_JOB_SUPPORT.C__ACTIVE, sysdate)
      ' using p_job_id, p_seq_value;

      --with table C__CURR_JOB_VAL_TABLE_NAME (Job relations)
      execute immediate 'insert into '|| C__CURR_JOB_VAL_TABLE_NAME||'(IN_JOB_ID, OUT_JOB_ID, CURRENT_SEQUENCE_VALUE, RECORD_STATUS)
                         select T.IN_JOB_ID, T.OUT_JOB_ID, :1,PyTL_JOB_SUPPORT.C__OPEN
                         from PyTL_JOB_RELATIONS T
                         where IN_JOB_ID = :2
      ' using p_seq_value, p_job_id;
      commit;
  end saveCurrentSeqValue;

  
  /* procedure marks or delete the seq value from the temp_table to exclude this sequence from the further calculations */
  procedure setSeqValueUsed(p_job_id VARCHAR2
                             , p_seq_value NUMBER
                             , p_mode VARCHAR2 default C__MODE_DELETE
                           )
  is
      pragma autonomous_transaction;
  begin
    if (p_mode = C__MODE_DELETE) then
      execute immediate 'delete from '||C__ACTIVE_SEQ_TABLE_NAME||' trgt where trgt.job_id = :1 and trgt.seq_value = :2'
        using p_job_id, p_seq_value
      ;

      --with table C__CURR_JOB_VAL_TABLE_NAME (Job relations)
      execute immediate 'delete from '||C__CURR_JOB_VAL_TABLE_NAME||' trgt where trgt.out_job_id = :1 and trgt.current_sequence_value = :2'
        using p_job_id, p_seq_value
      ;


    else
      execute immediate 'update '||C__ACTIVE_SEQ_TABLE_NAME||' trgt set trgt.seq_status = '''||C__PROCESSED||''' where trgt.job_id = :1 and trgt.seq_value = :2'
        using p_job_id, p_seq_value
      ;

      --with table C__CURR_JOB_VAL_TABLE_NAME (Job relations)
      execute immediate 'update '||C__CURR_JOB_VAL_TABLE_NAME||' trgt set trgt.record_status = '''||C__CLOSED||''' where trgt.out_job_id = :1 and trgt.current_sequence_value = :2'
        using p_job_id, p_seq_value
      ;

    end if;
    commit;
  end setSeqValueUsed;

  
  /* The purpose of this function is to get the next sequence value only */
  function getSequenceValue(p_job_name IN VARCHAR2
                             , p_file_name IN VARCHAR2 default null
                            , p_bank_code VARCHAR2 default null
                          )
   return VARCHAR2
  is
    v_seq_num VARCHAR2(40);
    v_seq_name user_sequences.sequence_name%type;
  begin
    v_seq_name := getSequenceName;--(p_job_name, p_bank_code);
    execute immediate 'select to_char('||v_seq_name||'.nextval) from dual' into v_seq_num;
    -- saving the sequence value
    saveCurrentSeqValue(p_job_name, v_seq_num);
    return v_seq_num;
  end getSequenceValue;


   /* The purpose of this function is to get the next sequence value by bank code */
  function getBankSequenceValue(p_job_name IN VARCHAR2
                             , p_bank_code IN VARCHAR2
                             )
  return VARCHAR2
  is
    v_seq_num VARCHAR2(40);
    v_seq_name user_sequences.sequence_name%type;
  begin
    v_seq_name := getBankSequenceName(p_bank_code);
    execute immediate 'select to_char('||v_seq_name||'.nextval) from dual' into v_seq_num;
    -- saving the sequence value
    saveCurrentSeqValue(p_job_name, v_seq_num);
    return v_seq_num;
  end getBankSequenceValue;


   /* The purpose of this function is to get the next sequence value by job name */
  function getSeqValueByJob(p_job_name IN VARCHAR2)
  return VARCHAR2
  is
    v_seq_num VARCHAR2(40);
    v_seq_name user_sequences.sequence_name%type;
  begin
    v_seq_name := getSequenceName(p_job_name);
    execute immediate 'select to_char('||v_seq_name||'.nextval) from dual' into v_seq_num;
    -- saving the sequence value
    saveCurrentSeqValue(p_job_name, v_seq_num);
    return v_seq_num;
  end getSeqValueByJob;

  /* function returns the CURRENT sequence value */
  function getCurrentSequenceValue(p_job_name IN VARCHAR2)
   return VARCHAR2
  is
    v_seq_num VARCHAR2(40);
    v_seq_name user_sequences.sequence_name%type;
  begin
    v_seq_name := getSequenceName; --(p_job_name, p_bank_code);
    execute immediate 'select to_char('||v_seq_name||'.CURRVAL) from dual' into v_seq_num;
    return v_seq_num;
  end;


  /* This function returns the name of the temporary table where Talend Job_1 saves interim data for the Talend Job_2 usage */
  function get_temp_table_name (p_job_name VARCHAR2
                                 , p_bank_code VARCHAR2
                               )
    return VARCHAR2
    is
      v_temp_table user_tables.table_name%type;
      v_temp_table_param_id PyTL_JOB_PARAMS.param_id%type := 88 /*TEMP_TABLE_NAME*/;
    begin
     execute immediate 'select max(pars.param_value) keep (dense_rank first order by pars.bank_code nulls last)
                            from PyTL_JOB_BANK_PARAMS pars
                             where pars.job_id = :1
                               and (pars.bank_code is null or pars.bank_code '||case when p_bank_code is null then ' is null' else ' = '''||p_bank_code||'''' end || ')
                               and pars.param_id = :2
      ' into v_temp_table using p_job_name, v_temp_table_param_id;
      return v_temp_table;
  end get_temp_table_name;


  /* procedure to insert in and out jobs into the relation table */
  procedure addJobPairs(p_in_job_id VARCHAR2,p_out_job_id VARCHAR2) is
  begin
    execute immediate 'insert into '|| C__JOB_RELATIONS_TABLE_NAME||'(IN_JOB_ID, OUT_JOB_ID)
                         values(:1,:2)'
    using p_in_job_id, p_out_job_id;
   commit;
  end;


  /* procedure delete outdated rows from the table p_table_name */
  procedure clean_old_seqs_from_table(p_table_name VARCHAR2, p_days NUMBER)
  is
    PRAGMA AUTONOMOUS_TRANSACTION;
  begin
     execute immediate 'delete from '||p_table_name||' where OPEN_DATE < (sysdate - '||p_days||')';
     commit;
  end clean_old_seqs_from_table;

  /*
   * procedure deletes old sequence numbers from the TLND tech tables in order to keep the system tough
   * parameter p_days: real TTL for the sequence record in the tech tables.
  */
  procedure delete_old_sequences(p_days NUMBER default 14)
  is
  begin
     for rec in (select TABLE_NAME from PyTL_SEQ_TABLE_LIST)
     loop
       clean_old_seqs_from_table(rec.TABLE_NAME , p_days);
     end loop;
  end delete_old_sequences;

end PyTL_JOB_SUPPORT;
/

commit;
exit;
