
# The Module usage:
# called like a module (-m pytl_core.job_launcher -> "__name__" == "__main__")
# imported like a module (from pytl_core import *)
# called like a function from the package ( job_launcher(config) )

# to include all imports from __init__.py
from pytl_core import *

# global config
if 'cfg' not in globals():
    default_cfg = {'JOB_FILE': sys.argv[1]} if __name__ == "__main__" else {}
    cfg = config = Config.configure_pytl_core(default_cfg)
    logging.debug(f"Config: initialisation finished, 'config' and 'cfg' variables were created.")


def job_launcher(config=None):
    """ run the job from source code """

    logging.info(f"Started {config.JOB_NAME}")

    try:
        code_pth = config.JOB_FILE
        code_txt = Path(code_pth).read_text()

        code_start_pattern = "job_launcher(config)" # script execution will be started from the first match found
        code_start_index = code_txt.find(code_start_pattern) + len(code_start_pattern) # prevent recursive call
        empty_lines = '\n' * (len(code_txt[:code_start_index].split('\n')) - 1) # count skipped lines
        code_txt = empty_lines + code_txt[code_start_index:] # keep lines numbering for correct tracebacks

        code_obj = compile(code_txt, code_pth, 'exec')

        exec(code_obj, globals())

    except SystemExit as exc:

        logging.error(f"System Exit with code {exc} called from job_launcher(config)")
        config.EXIT_CODE = exc

    except Exception as exc:

        # exc_type, exc_value, exc_traceback = sys.exc_info()
        # traceback.print_tb(exc_traceback)
        logging.exception(exc)
        config.EXIT_CODE = exc

    finally:

        logging.info(f"Finished {config.JOB_NAME}")
        config.show_output_files()

        if config.get('TEST_MODE', False):
            # make all job variables available in tests (e.g. 'output_file'),
            return utils.get_public(globals())
        else:
            sys.exit(config.EXIT_CODE)


if __name__ == "__main__":
    job_launcher(config)







