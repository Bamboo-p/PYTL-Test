import sys
import os
import logging
from pathlib import Path
from datetime import datetime
import re
import platform

try:
    # Could be imported ONLY if it's run as module
    from . import __job_name__
    from importlib_metadata import version as importlib_metadata_version
    __version__ = importlib_metadata_version(__job_name__)
except:
    # Could be imported ONLY if it's run as normal py
    from __init__ import __job_name__
    from __init__ import __version__

import n0struct
import inspect

levels = {
    'DEBUG': logging.DEBUG,
    'INFO': logging.INFO,
    'WARNING': logging.WARNING
}

mask_patterns = (
    ( re.compile("([234569][0-9]{5})([0-9]{6})([0-9]{4})"), r"\1*********\3" ),
    ( re.compile("([234569][0-9]{5})([0-9]{7})([0-9]{4})"), r"\1********\3"  ),
    ( re.compile("([234569][0-9]{5})([0-9]{8})([0-9]{4})"), r"\1*******\3"   ),
    ( re.compile("([234569][0-9]{5})([0-9]{9})([0-9]{4})"), r"\1******\3"    ),
    ( re.compile("(jdbc:oracle:thin:.*/)(.+)(@)"),         r"\1*****\3"     ),
)

def mask_buffer(args: tuple):
    global mask_patterns
    masked_str = str(args[0])
    for mask_pattern in mask_patterns:
        masked_str = mask_pattern[0].sub(mask_pattern[1], masked_str)
    return [masked_str] + list(args[1:])

org_logging_debug = None
def my_logging_debug(*args, **kwargs):
    global org_logging_debug
    org_logging_debug(*mask_buffer(args), **kwargs)


org_logging_info = None
def my_logging_info(*args, **kwargs):
    global org_logging_info
    org_logging_info(*mask_buffer(args), **kwargs)


org_logging_error = None
def my_logging_error(*args, **kwargs):
    global org_logging_error
    org_logging_error(*mask_buffer(args), **kwargs)


def configure_logging(config):
    global org_logging_debug
    global org_logging_info
    global org_logging_error
    if org_logging_debug or org_logging_info or org_logging_info:
        frameinfo = inspect.stack()
        n0struct.n0debug_calc(frameinfo, f"inspect.stack()")
        frameinfo = inspect.getframeinfo(inspect.currentframe().f_back)
        n0struct.n0debug_calc(frameinfo, "inspect.currentframe().f_back")
        raise Exception(f"More one call of configure_logging({config})")

    format = "%(asctime)s %(name)-10s %(levelname)s %(message)s"
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    config['LOG_FILE'] = Path(config['LOG_DIR'], config.get('LOG_FN_PREFIX', config['JOB_NAME']) + f"_{ts}_{os.getpid():0>5}.log")
    logging.shutdown()  # stop logging of job_launcher
    Path(config['LOG_FILE']).parent.mkdir(parents=True, exist_ok=True)
    config['LOG_FILE'].unlink(missing_ok=True)
    logging.basicConfig(filename=config['LOG_FILE'], level=logging.DEBUG, format=format, force=True)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(logging.Formatter(format))
    console_handler.setLevel(levels.get(config.get('LOG_LEVEL', 'DEBUG')))
    logging.getLogger().addHandler(console_handler)

    logging.debug(f"Config: Logger started. {__job_name__} v{__version__} @ {sys.executable} {platform.python_version()} {platform.system()} {platform.architecture()[0]}")
    org_logging_debug, logging.debug = logging.debug, my_logging_debug
    org_logging_info,  logging.info  = logging.info,  my_logging_info
    org_logging_error, logging.error = logging.error, my_logging_error
    
    if config.get('TRACE'):
        n0struct.init_logger("TRACE")
    else:
        n0struct.init_logger("INFO")
