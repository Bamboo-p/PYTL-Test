import typing
import cx_Oracle
'''
import pandas as pd # alternative for some operations
'''
from pytl_core.utils import primed
import sys
import logging
import re
from pathlib import Path
from n0struct import *
from pytl_core.logger import mask_patterns

# https://jira.network.ae/jira/browse/AJM-3982
# https://jira.network.ae/jira/browse/NICORE-651
control_m_error_tags = {
    "ERROR":        "3RR0R",
    "Error":        "3Rr0r",
    "error":        "3rr0r",
    "EXCEPTION":    "EXC3PT10N",
    "Exception":    "3Xc3pt10n",
    "exception":    "3xc3pt10n",
    "UNABLE":       "UN@BL3",
    "Unable":       "Un@bl3",
    "unable":       "un@bl3",
    "CANNOT":       "C@NN0T",
    "Cannot":       "C@nn0t",
    "cannot":       "c@nn0t",
    "DUPLICATE":    "DUPL1C@T3",
    "Duplicate":    "Dupl1c@t3",
    "duplicate":    "Dupl1c@t3",
    "INVALID":      "1NV@L1D",
    "Invalid":      "1Nv@l1d",
    "invalid":      "1nv@l1d",
    "ORA-":         "0RA-",
}
def mask_control_m_string(masked_str: str):
    for tag_name in control_m_error_tags:
        for variant in (lambda s: s.lower(), lambda s: s.upper(), lambda s: s.capitalize(), lambda s: s.title()):
            masked_str = masked_str.replace(variant(tag_name), control_m_error_tags[tag_name])
    for mask_pattern in mask_patterns:
        masked_str = mask_pattern[0].sub(mask_pattern[1], masked_str)
    return masked_str

# ******************************************************************************
# https://code.activestate.com/recipes/577504/
# from __future__ import print_function
from sys import getsizeof, stderr
from itertools import chain
from collections import deque
try:
    from reprlib import repr
except ImportError:
    pass

def total_size(o, handlers={}, verbose=False):
    """ Returns the approximate memory footprint an object and all of its contents.

    Automatically finds the contents of the following builtin containers and
    their subclasses:  tuple, list, deque, dict, set and frozenset.
    To search other containers, add handlers to iterate over their contents:

        handlers = {SomeContainerClass: iter,
                    OtherContainerClass: OtherContainerClass.get_elements}

    ##### Example call #####
        d = dict(a=1, b=2, c=3, d=[4,5,6,7], e='a string of chars')
        print(total_size(d, verbose=True))
    """
    dict_handler = lambda d: chain.from_iterable(d.items())
    all_handlers = {tuple: iter,
                    list: iter,
                    deque: iter,
                    dict: dict_handler,
                    set: iter,
                    frozenset: iter,
                   }
    all_handlers.update(handlers)     # user handlers take precedence
    seen = set()                      # track which object id's have already been seen
    default_size = getsizeof(0)       # estimate sizeof object without __sizeof__

    def sizeof(o):
        if id(o) in seen:       # do not double count the same object
            return 0
        seen.add(id(o))
        s = getsizeof(o, default_size)

        if verbose:
            print(s, type(o), repr(o), file=stderr)

        for typ, handler in all_handlers.items():
            if isinstance(o, typ):
                s += sum(map(sizeof, handler(o)))
                break
        return s

    return sizeof(o)


class Connection(object):
    """

    this class should do:
    | impl |
    1. +    fetch data from db // old_method: execute_select // old_method: execute_select_2
    2. -
    3. +
    4. +/-  insert
    5. -    delete
    ... "some DML operations not implemented" - which?



    """

    current_cursor_metadata = None

    def _call_dbms_application_info(self, action_name: str = "", procedure: str = "set_action"):
        try:
            self.execute_statement_or_anonym_block(sql_statement:= f"""
BEGIN
    DBMS_APPLICATION_INFO.{procedure}({
"        module_name => '"+self.module_name+"'," if procedure.lower() == "set_module" else ""
}
        action_name => '{action_name[:32]}'
    );
END;""",
                    bind_vars={},
                    commit=False,
                    show_statement=True,
                    dbms_application_info=False,
            )
            ## logging.debug(n0pretty(self.execute_select(statement="SELECT  sid,serial#,username,osuser,module,action,client_info FROM v$session where MODULE like 'PyTL%'")['data']))
        except Exception as e:
            logging.error(f"sql statement:\n{sql_statement}")
            logging.error(f"execution error with OCI: {e}")
            raise e

    def call_dbms_application_info(self, prefix: str = "", sql_file: str = "", bind_vars: typing.Union[list, dict] = [], action_name: str = "", procedure: str = "set_action"):
        """
        procedure:
            set_module  == first call after connection
            set_action  == all other calls
        """
        if not self.module_name or (not action_name and not sql_file):
            return

        if sql_file:
            sql_file = Path(sql_file).stem

        action_name = f"{prefix}{sql_file}{action_name}"
        self._call_dbms_application_info(action_name)

        if bind_vars:
            if isinstance(bind_vars, dict):
                serialized_params = n0dict(bind_vars).to_json(compress=True, skip_empty_arrays=True)[2:-1] \
                    .replace('":',  '=')    \
                    .replace(',"',  ';')    \
                    .replace('\\"', '')     \
                    .replace('\\',  '/')    \
                    .replace('"',   '')     \
                    .replace("'",   '')
            elif isinstance(bind_vars, (list, tuple)):
                serialized_params = ";".join(bind_vars)
            else:
                raise TypeError(f"{bind_vars} must be list or dict")

            max_len_action_name=32
            for action_name in [serialized_params[i:i+max_len_action_name] for i in range(0, len(serialized_params), max_len_action_name)]:
                self._call_dbms_application_info(action_name)

    def dbms_application_info__open_connection(self, action: str, message: str = "", sql_file: str = "", bind_vars: typing.Union[list, dict] = []):
        self.call_dbms_application_info(prefix=action, action_name=message, procedure="set_module")

    def dbms_application_info__start_process(self, action: str, message: str = "", sql_file: str = "", bind_vars: typing.Union[list, dict] = []):
        self.call_dbms_application_info(prefix=f">{action}>", sql_file=sql_file, bind_vars=bind_vars, action_name=message)

    def dbms_application_info__end_process(self, action: str, message: str = "", sql_file: str = "", bind_vars: typing.Union[list, dict] = []):
        self.call_dbms_application_info(prefix=f"<{action}<", sql_file=sql_file, action_name=message)

    def dbms_application_info__close_connection(self, action: str, message: str = "", sql_file: str = "", bind_vars: typing.Union[list, dict] = []):
        self.call_dbms_application_info(prefix=action, action_name=message)


    def __init__(self, connection_string: str, module_name: str = None):
        self.current_cursor_metadata = []
        self.connection = self.get_connection(connection_string)  # Run static method
        self.connection_string = connection_string

        self.module_name = module_name[:48] if module_name else module_name
        self.dbms_application_info__open_connection("CONNECTED")

    # deniska: I suppose, it was done previously to run from outside of object, directly from class, just for parsing connection string and open connection
    @staticmethod
    def get_connection(connection_string):
        # create the new Cx oracle connection
        try:
            # ORACLE_HOME = C:\Oracle\product\12.2.0\client_1\bin
            # cx_Oracle.init_oracle_client(lib_dir=ORACLE_HOME)
            # logging.info(f"Oracle client successfully init. Version is {cx_Oracle.clientversion()}")
            connection_string = connection_string.replace('jdbc:oracle:thin:', '')
            if not all(x in connection_string for x in ['/', '@']):
                logging.info(f"connecting using wallet: {connection_string}")
                # result = super(Connection, self).__init__(dsn=dns_conn, encoding="UTF-8")  # via wallet
                result = cx_Oracle.connect(dsn=connection_string, encoding="UTF-8")
            else:
                tmp = connection_string.split('/', 1)
                user = tmp[0]
                password = tmp[1].split('@', 1)[0]
                easy_conn = tmp[1].split('@', 1)[1]
                logging.info(f"connecting using easy conn connection_string: {user}/*****@{easy_conn}")
                result = cx_Oracle.connect(user, password, easy_conn, encoding="UTF-8")
            return result
        except cx_Oracle.DatabaseError as e:
            logging.error(f"database connection error: {e}")
            raise e

    def empty_str_instead_none(self, value):
        if value is None:
            return ''
        return value

    # inner methods // _return_only_strings
    # See cx_oracle db docs for reasonong
    # return only strings for cx_Pracle.cursor.fetchmany()
    def return_only_strings(self, cursor, name, defaultType, size, precision, scale):
        if (defaultType == cx_Oracle.DB_TYPE_NUMBER) | (defaultType == cx_Oracle.DB_TYPE_DATE):
            return cursor.var(str, arraysize=cursor.arraysize)

    # inner
    # for info/debug only // show commands that should be executed by oracle DB
    def show_statement(self, statement, bind_vars={}, size=100):
        expected_vars = set(re.findall(":([a-zA-Z][a-zA-Z0-9_]*)", statement))

        logging.debug(f"the statement expected variables: {mask_control_m_string(str(expected_vars)) if expected_vars else None}")

        logging.debug(f"executing statement:\n{mask_control_m_string(statement)}")
        if bind_vars:
            if bind_vars:
                if (bind_vars_size:=total_size(bind_vars)) < 10000:  # MemoryError
                    n0debug("bind_vars_size")
                    bind_vars_str = str(bind_vars)
                else:
                    bind_vars_str = f"are {bind_vars_size} bytes and too big to show"
            else:
                bind_vars_str = None
            logging.debug(f"the statement bind variables: {mask_control_m_string(bind_vars_str)}")

        not_provided_vars = expected_vars - bind_vars.keys()
        if not_provided_vars:
            logging.debug(f"possible additional variables are required: {mask_control_m_string(str(not_provided_vars))}")
        # TODO: method for masking of digits: SOME_NAME_1234 -> SOME_NAME_****
        # e.g. re.sub(r'[0-9]+', r'\*', bind_vars.value)


    # outer, returns dicts/list/str -->
    # SELECT form db (streaming)
    def execute_select_batch(self, statement, bind_vars={}, pd_mode=False, batch_size=50000, show_statement=True, sql_file: str = "") -> typing.Generator[list, None, None]:
        if show_statement:
            self.show_statement(statement=statement, bind_vars=bind_vars)
        self.dbms_application_info__start_process(action="SB", sql_file=sql_file, bind_vars=bind_vars)

        count = 0
        '''
        if pd_mode:
            try:
                for chunk in pd.read_sql(sql=statement, con=self.connection, chunksize=batch_size, params=bind_vars):
                    count += len(chunk.index)
                    chunk.fillna(value='', inplace=True)
                    yield chunk
            except Exception as e:
                logging.error(f"sql statement:\n{mask_control_m_string(statement)}")
                logging.error(f"execution error with pandas: {e}")
                raise e
        else:
        '''
        if True:
            try:
                cursor = self.connection.cursor()
                cursor.outputtypehandler = self.return_only_strings
                cursor.execute(statement, bind_vars)
                self.current_cursor_metadata = cursor.description

                # return list of dicts instead of default list of tuples
                cursor.rowfactory = lambda *args: dict(zip([d[0] for d in cursor.description], args))

                while True:
                    rows = cursor.fetchmany(batch_size)
                    if not rows:
                        break
                    count += len(rows)
                    yield rows
            except Exception as e:
                logging.error(f"sql statement:\n{mask_control_m_string(statement)}")
                logging.error(f"execution error with OCI: {e}")
                raise e

        cursor.close()
        self.dbms_application_info__end_process(action="SB", sql_file=sql_file, bind_vars=bind_vars, message=f" {count}")
        logging.info(f"{count} rows have been extracted.")


    def execute_select_seamlessly(self, statement, bind_vars={}, pd_mode=False, batch_size=50000, show_statement=True, sql_file: str = "") -> typing.Generator[dict, None, None]:
        """
        Because of yield, this method will be not executed directly, and returns only generator
        Execution will be happened ONLY in the loop/next
        """
        if show_statement:
            self.show_statement(statement=statement, bind_vars=bind_vars)
        self.dbms_application_info__start_process(action="SS", sql_file=sql_file, bind_vars=bind_vars)

        count = 0
        try:
            cursor = self.connection.cursor()
            cursor.outputtypehandler = self.return_only_strings
            cursor.execute(statement, bind_vars)
            self.current_cursor_metadata = cursor.description

            # return list of dicts instead of default list of tuples
            cursor.rowfactory = lambda *args: dict(zip([d[0] for d in cursor.description], args))

            while True:
                rows = cursor.fetchmany(batch_size)
                if not rows:
                    break
                for row in rows:
                    count += 1
                    yield row
        except Exception as e:
            logging.error(f"sql statement:\n{mask_control_m_string(statement)}")
            logging.error(f"seamless execution error: {e}")
            raise e

        cursor.close()
        self.dbms_application_info__end_process(action="SS", sql_file=sql_file, bind_vars=bind_vars, message=f" {count}")
        logging.info(f"{count} rows have been extracted.")

    # outer, return {}
    def execute_select(self, statement, bind_vars={}, pd_mode=False, show_statement=True, sql_file: str = "") -> dict:
        if show_statement:
            self.show_statement(statement=statement, bind_vars=bind_vars)
        self.dbms_application_info__start_process(action="S", sql_file=sql_file, bind_vars=bind_vars)

        count = 0
        '''
        if pd_mode:
            try:
                result = pd.read_sql(sql=statement, con=self.connection, params=bind_vars)
                result.fillna(value='', inplace=True)
                count += len(result.index)
            except Exception as e:
                logging.error(f"sql statement execution error: {e}")
                raise e
        else:
        '''
        if True:
            try:
                cursor = self.connection.cursor()
                cursor.outputtypehandler = self.return_only_strings
                cursor.execute(statement, bind_vars)
                cursor.rowfactory = lambda *args: dict(zip([d[0] for d in cursor.description],
                                                           args))  # return list of dicts instead of default list of tuples
                result={}
                result["data"] = cursor.fetchall()
                result["desc"] = [[item[0],] for item in cursor.description][1:] # make json-serialisible by removing redundant and tuples
                count += len(result["data"])
            except Exception as e:
                logging.error(f"sql statement execution error: {e}")
                raise e

        cursor.close()
        self.dbms_application_info__end_process(action="S", sql_file=sql_file, bind_vars=bind_vars, message=f" {count}")
        logging.info(f"{count} rows have been extracted.")
        return result

    # outer, no return
    # send a command to DB, see exceptiond from DB in not execued
    def execute_statement_or_anonym_block(self, statement, bind_vars={}, commit=False, show_statement=True, sql_file: str = "", dbms_application_info = True):
        if show_statement:
            self.show_statement(statement=statement, bind_vars=bind_vars)

        if dbms_application_info:
            self.dbms_application_info__start_process(action="A", sql_file=sql_file, bind_vars=bind_vars)

        try:
            cursor = self.connection.cursor()
            cursor.execute(statement, bind_vars)
        except Exception as e:
            logging.error(f"sql statement/anonym block execution error: {e}")
            self.connection.rollback()
            raise e

        cursor.close()

        if dbms_application_info:
            self.dbms_application_info__end_process(action="A", sql_file=sql_file, bind_vars=bind_vars)


    # outer, no return
    def execute_stored_procedure(self, statement, bind_vars={}, commit=False, show_statement=True):
        self.dbms_application_info__start_process(action="P", sql_file=statement, bind_vars=bind_vars)

        try:
            cursor = self.connection.cursor()
            cursor.callproc(statement, keywordParameters=bind_vars)
        except Exception as e:
            logging.error(f"stored procedure execution error: {e}")
            self.connection.rollback()
            raise e

        cursor.close()
        self.dbms_application_info__end_process(action="P", sql_file=statement, bind_vars=bind_vars)


    # outer, no return
    # write data to DB, exception of no, some errors (partial write fail) may be not shown
    # TODO: make sure no cases we missed unwritten issue, or check by our own
    def execute_insert_batch(self, table_name, data, commit=False, show_statement=True, sql_file: str = ""):
        columns = data[0].keys()
        self.dbms_application_info__start_process(action="IB", sql_file=table_name, bind_vars=(__bind_vars:={column: "" for column in columns}))

        try:
            statement = f"insert into {table_name}({','.join(columns)}) values ({','.join(f':{col}' for col in columns)})"
            if show_statement:
                self.show_statement(statement=statement, bind_vars=data[0])
            cursor = self.connection.cursor()
            cursor.executemany(statement, data)
            if commit:
                self.connection.commit()
        except Exception as e:
            logging.error(f"batch insert execution error: {e}")
            self.connection.rollback()
            raise e

        cursor.close()
        count = len(data)
        self.dbms_application_info__end_process(action="IB", sql_file=table_name, bind_vars=__bind_vars, message=f" {count}")
        logging.info(f"{count} rows have been inserted into {table_name}.")

    # outer, no return
    # write data to DB, exception of no, some errors (partial write fail) may be not shown
    # TODO: make sure no cases we missed unwritten issue, or check by our own
    def execute_update_batch(self, table_name, data: list, conditions: dict, commit=False, show_statement=True, sql_file: str = ""):
        columns = data[0].keys()
        self.dbms_application_info__start_process(action="UB", sql_file=table_name, bind_vars=(__bind_vars:={column: "" for column in columns}))

        try:
            statement = f"update {table_name} set " \
                        + ", ".join([
                            f"{column_name} = :{column_name}"
                            for column_name in columns
                            if not column_name in conditions
                               or conditions[column_name].upper() != "$CURRENT$"
                          ]) \
                        + " where " \
                        + " and ".join([
                                        (
                                            f"{column_name}" +
                                            (
                                                (
                                                    f" = :{column_name}"
                                                    if column_value.upper() == "$CURRENT$"
                                                    else f" = '{column_value}'"
                                                ) if isinstance(column_value:=conditions[column_name], str)
                                                else (
                                                    "is NULL"
                                                    if column_value is None
                                                    else f" = {column_value}"
                                                )
                                            )
                                        )
                                        for column_name in conditions
                          ])
            if show_statement:
                self.show_statement(statement=statement, bind_vars=data[0])
            cursor = self.connection.cursor()
            cursor.executemany(statement, data)
            if commit:
                self.connection.commit()
        except Exception as e:
            logging.error(f"batch update execution error: {e}")
            self.connection.rollback()
            raise e

        cursor.close()
        count = len(data)
        self.dbms_application_info__end_process(action="UB", sql_file=table_name, bind_vars=__bind_vars, message=f" {count}")
        logging.info(f"{count} rows have been updated into {table_name}.")

    # outer, no return
    # write data to DB, exception of no, some errors (partial write fail) may be not shown
    # TODO: make sure no cases we missed unwritten issue, or check by our own
    def execute_update(self, table_name, data: dict, conditions: dict, commit=False, show_statement=True, sql_file: str = ""):
        columns = data[0].keys()
        self.dbms_application_info__start_process(action="U", sql_file=table_name, bind_vars=(__bind_vars:={column: "" for column in columns}))

        try:
            statement = f"update {table_name} set " \
                        + ", ".join([
                            f"{column_name} = :{column_name}"
                            for column_name in columns
                            if not column_name in conditions
                               or conditions[column_name].upper() != "$CURRENT$"
                          ]) \
                        + " where " \
                        + " and ".join([
                                        (
                                            f"{column_name}" +
                                            (
                                                (
                                                    f" = :{column_name}"
                                                    if column_value.upper() == "$CURRENT$"
                                                    else f" = '{column_value}'"
                                                ) if isinstance(column_value:=conditions[column_name], str)
                                                else (
                                                    "is NULL"
                                                    if column_value is None
                                                    else f" = {column_value}"
                                                )
                                            )
                                        )
                                        for column_name in conditions
                          ])
            if show_statement:
                self.show_statement(statement=statement, bind_vars=data)
            cursor = self.connection.cursor()
            cursor.execute(statement, data)
            if commit:
                self.connection.commit()
        except Exception as e:
            logging.error(f"update execution error: {e}")
            self.connection.rollback()
            raise e

        cursor.close()
        count = len(data)
        self.dbms_application_info__end_process(action="U", sql_file=table_name, bind_vars=__bind_vars, message=f" {count}")
        logging.info(f"{count} rows have been updated into {table_name}.")

    # Fix (approve changes in oracle DB)
    # alternative to auto-commit function of DB
    # rare use case, with inserts/deletes
    def commit(self):
        self.dbms_application_info__start_process(action="С")

        try:
            self.connection.commit()
            logging.debug("commit")
        except Exception as e:
            logging.error(f"problem with commit: {e}")

        self.dbms_application_info__end_process(action="С")

    # CLose connection
    def close(self):
        # TODO: chech if connection is closed before trying to close it
        try:
            self.dbms_application_info__close_connection("DISCONNECTING")
            self.connection.close()
            logging.info("Oracle DB connection has been closed")
        except Exception as e:
            logging.error(f"problem with closing Oracle DB connection: {e}")


"""
    def __enter__(self):
        # init_ora_client()
        # self.connector = self.get_connection(string=self.connection_string)
        self.connector = cx_Oracle.connect(dsn=self.connection_string, encoding="UTF-8")
        return self.connector

    def __exit__(self, exc_type, exc_val, exc_tb):
        logging.info(f"{exc_type} \n {exc_val} \n {exc_tb}")
        if not exc_val is None:
            print(f"oracle issue : {exc_val}")
            self.connector.rollback()
        self.connector.close()
"""

class OracleDB(Connection):

    def select(self, *args, **kwargs):
        # force execute of the first iteration to get the cursor metadata before the first data call
        return primed( self.execute_select_batch(*args, **kwargs) )

    def get_headers(self, filter=None):

        # extract column headers from cursor metadata
        headers = [item[0] for item in self.current_cursor_metadata]

        if not headers:
            logging.error(f"No column headers extracted from cursor metadata {self.current_cursor_metadata}!")
            sys.exit(1)

        # select headers specified by column numbers
        if isinstance(filter, list):
            return [headers[i] for i in filter]

        elif not filter:
            slice_obj = slice(None)

        elif filter=='skip_first':
            slice_obj = slice(1, None)

        else: # "filter" considered to be a slice-like string, e.g. "2:5"
            slice_parts = filter.split(':')
            n_slice_parts = len(slice_parts)
            slice_parts = [int(slice_parts[i]) if (i < n_slice_parts and slice_parts[i]) else None for i in range(0,3)]
            slice_obj = slice(slice_parts[0], slice_parts[1], slice_parts[2])

        return headers[slice_obj]

class PyTL_Sequence():
    def get_db_sequence(self):
        sequence_value = int(self.db_connection.execute_select(
                f"select PyTL_Sequences_Utils.get_sequence_value(:SEQUENCE_NAME, :SEQUENCE_RESERVE) SEQUENCE_VALUE from dual",
                {'SEQUENCE_NAME': self.sequence_name, 'SEQUENCE_RESERVE': self.sequence_reserve}
        )['data'][0]['SEQUENCE_VALUE'])
        self.max_sequence = sequence_value + self.sequence_reserve - 1
        return sequence_value

    def __iter__(self):
        return self

    # Impossible to use yield-generator, because of impossible to read from DB during iteration.
    def __next__(self):
        if  self.sequence_value >= self.max_sequence:
            self.sequence_value = self.get_db_sequence()
        else:
            self.sequence_value += 1
        return self.sequence_value

    def next(self):
        return self.__next__()

    def current(self):
        return self.sequence_value

    def set_sequence_reserve(self, sequence_reserve):
        self.sequence_value = sequence_reserve

    def __init__(self, sequence_name: str, db_connection, sequence_reserve: int = 1):
        if sequence_reserve < 1:
            raise Exception(f"Impossible to reserve range with {sequence_reserve} lenght in sequence")
        self.sequence_name      = sequence_name
        self.db_connection      = db_connection
        self.sequence_reserve   = sequence_reserve
        self.sequence_value     = -999
        self.max_sequence       = -999
