import pathlib
import os
import sys
import re
from datetime import datetime
import logging

import argparse
from pathlib import Path
from pytl_core.logger import configure_logging
from pytl_core.pytl_path import PytlPath
from pytl_core.utils import str2bool
from n0struct import *
import typing

# [+][begin] 220103.1 = DenisKa = ENG-3781: Fixed issue for windows - pathlib.py::_WindowsFlavour.resolve uses nt._getfinalpathname, which converts not only symlinks, but and mapped network drives too.
import pathlib
import ntpath
class fixed_WindowsFlavour(pathlib._WindowsFlavour):
    def resolve(self, path, strict=False):
        return ntpath._abspath_fallback(path)
pathlib._WindowsFlavour.resolve = fixed_WindowsFlavour.resolve
# [+][end]   220103.1 = DenisKa = ENG-3781: Fixed issue for windows - pathlib.py::_WindowsFlavour.resolve uses nt._getfinalpathname, which converts not only symlinks, but and mapped network drives too.

# create a keyvalue class
class KeyValue(argparse.Action):
    # Constructor calling
    def __call__(self, parser, namespace,
                 values, option_string=None):
        setattr(namespace, self.dest, dict())

        for value in values:
            # split it into key and value
            key, value = value.split('=')
            # assign into dictionary
            getattr(namespace, self.dest)[key] = value


# instance of Config is a singletone version of a standard dict
class Config(dict):

    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(Config, cls).__new__(cls, *args, **kwargs)
        return cls._instance

    def __init__(self, *args, **kwargs):
        super(Config, self).__init__(*args, **kwargs)
        self.__dict__ = self

    def __getattr__(self, key):
        key = key.upper()
        if key in self.__dict__:
            return self.__dict__[key]
        else:
            raise AttributeError(f"No such attribute: {key}")


    def cleanup(self):
        #self.__class__._instance = None # good idea, wrong way
        self.clear()


    def get_mandatory(self, *args, default=None):
        """ Iterates over keys to get one mandatory value from config, sys.exit if no success """

        last_arg = len(args)-1

        for i_arg, arg in enumerate(args):

            value = self.get(arg, None)

            if value is not None:
                return value

            if i_arg == last_arg:

                if default is not None:
                    return default

                else:
                    logging.error(f"Config: Mandatory parameters not found with the set {args}, a default value not specified.")
                    sys.exit(1)


    def __read_sys_argv(self):
        # parser = argparse.ArgumentParser()
        # parser.add_argument("-ENV", "--ENV", help="Path to .parm file",
        #                     default='env.parm')
        # parser.add_argument('--kwargs',
        #                     nargs='*',
        #                     action=KeyValue)
        # args = parser.parse_args()

        ## return {key.upper().strip(): value.strip() for key, value in (arg.strip().split("=", 1) for arg in sys.argv if '=' in arg)} # [*] 211121.1 = deniska = OPKSAIC-118/OPKSAIC-1693
        ## RTG: replaced: originally sys.argv[1:]
        ## RTG: refactor? : the '=' in any arg may happen, e.g. in file path
        config = {}
        for arg in sys.argv[1:]:
            if '=' in arg:
                ## key, value = arg.split("=", 1)
                ## key = key.upper().strip()
                ## if len(key) > 1 and key.endswith('+'):
                ##     key = key[:-1]
                ##     if key in config:
                ##         config[key] += value
                ## else:
                ##     config[key] = value
                key, value = split_pair(arg, '=', transform_left = lambda x: x.upper().strip(), default_element = 0)
                if len(key) > 1 and key.endswith('+'):
                    key = key[:-1]
                    if key in config:
                        value = config[key] + value
                config[key] = value

        return config

    '''
    def __read_parm_file(self, file_path=False, file_ext='.parm', path_sep=':;, ', delimiter=';') -> []:

        # multiple path separators are available: windows ";" unix ":" comma "," space " "

        if not file_path or file_path.strip('"') == "--skip":
            #  all required args should be specified in another way
            return {}
        else:
            # split .parm files by ext, remove leading delimiters and empty entries
            paths = [p+'.parm' for p in (p.lstrip(path_sep) for p in file_path.lower().split(file_ext)) if p]
            config = {}

        for path in paths:
            try:
                file = Path(path)

                if not file.is_file():
                    # TODO: refactoring. f-strings do not work with basic logging... and logger init has not happen yet
                    msg = f"Config: Parm file not found at path {path}"
                    logging.error(msg)
                    sys.exit(1)

                with open(file) as file:
                    for line in file.readlines():
                        if not line.strip() or line.startswith('#'):  # skip empty and #-commented lines
                            continue
                        elif delimiter not in line:
                            msg = f"Config: Wrong syntax line {line} found in parm file {file}."
                            logging.warning(msg)

                        ## key = line.split(delimiter)[0].upper().strip()  # [*] 211121.1 = deniska = OPKSAIC-118/OPKSAIC-1693
                        ## value = line.split(delimiter, 1)[1].strip()
                        ## if len(key) > 1 and key.endswith('+'):
                        ##     key = key[:-1]
                        ##     if key in config:
                        ##         config[key] += value
                        ## else:
                        ##     config[key] = value

                        key, value = split_pair(line, delimiter, transform_left = lambda x: x.upper().strip(), default_element = 0)
                        if len(key) > 1 and key.endswith('+'):
                            key = key[:-1]
                            if key in config:
                                value = config[key] + value
                        config[key] = value

            except Exception as e:
                msg = f"Config: Unknown exception {e} wile parsing parm file {file}."
                #logging.exception(msg)
                logging.error(msg)

        return config
    '''

## ############################################################################
## ############################################################################

    def __complete_config(self):
        config = self.__dict__

        config['OUTPUT_FILES'] = {}
        config['LOG_TO_DB'] = config.get('LOG_TO_DB', 'FALSE')
        # default LOG_LEVEL will be set in logger.py
        # config['LOG_LEVEL'] = config.get('LOG_LEVEL', 'DEBUG')
        # default EXIT_CODE will be set in configure_pytl_core() if config init was/not successful
        # config['EXIT_CODE'] = 0

        ## #####################################################################
        # Seach for files with current script name to get job file name and path (first found will be a default)
        sys_argv_py_files = [arg for arg in sys.argv if arg.endswith('.py') and 'job_launcher' not in arg]
        if (job_file := config.get('JOB_FILE', sys_argv_py_files[0] if sys_argv_py_files else None)):
            config['JOB_FILE'] = str(Path(job_file).resolve())
        else:
            msg = f"Config: JOB_FILE is not specified and was not resolved from args."
            logging.error(msg)
            raise ValueError(msg)

        sys_argv_bat_files = [arg for arg in sys.argv if arg.endswith('.bat') and 'job_launcher' not in arg]
        if (job_batch_file := config.get('JOB_BATCH_FILE', sys_argv_bat_files[0] if sys_argv_bat_files else None)):
            config['JOB_BATCH_FILE'] = str(Path(job_batch_file).resolve())

        ## #####################################################################
        common_variables1 = {        # Variable synonym name     Default value
            'JOB_NAME':             ( None,                     Path(job_batch_file if job_batch_file else job_file).stem ),
            'JOB_DIR':              ( None,                     str(Path(config['JOB_FILE']).parent) ),
            'BANK_NAME':            ( None,                     config.get(
                                                                    'ORG',
                                                                    config.get(
                                                                        'ORGLIST',
                                                                        Path(os.getcwd()).stem
                                                                    ).split(',',1)[0]
                                                                )
                                    ),
            'REGION_ROOT_DIR':      ( None,                     str(Path(os.getcwd()).parents[1]) ),
            'INTERCHANGE_DIR':      ( None,                     "Interchange" ),
            'LOGS_ROOT_DIR':        ( None,                     "Logs" ),

        }
        # it's mandatory to segregate definitions of common_variables2 from common_variables1
        # because of common_variables2 reuses common_variables1
        common_variables2 = {        # Variable synonym name    Default value
            'INTERCHANGE_JOB_DIR':  ( None,                     lambda: config['JOB_NAME'] ),
            'INTERCHANGE_BANK_DIR': ( None,                     lambda: config['BANK_NAME'] ),
        }
        def update_config_variables(common_variables: dict):
            for dir_variable_name in common_variables:
                variable_synonym = common_variables[dir_variable_name][0]                           # synonym variable name
                if dir_variable_name not in config:
                    if isinstance(default_value:=common_variables[dir_variable_name][1], typing.Callable):
                        config[dir_variable_name] = default_value()                                 # default value #2
                    else:
                        config[dir_variable_name] = default_value                                   # default value #1
                    if variable_synonym:
                        config[dir_variable_name] = config.get(variable_synonym, config[dir_variable_name])
                config[dir_variable_name] = config[dir_variable_name].strip()

                if variable_synonym and variable_synonym in config:
                    config[variable_synonym] = config[dir_variable_name]

        update_config_variables(common_variables1)
        update_config_variables(common_variables2)

        ## #####################################################################
        dirs_from_relative_to_absolute = (
            'INTERCHANGE_DIR',
            'LOGS_ROOT_DIR',
        )
        for dir_variable_name in dirs_from_relative_to_absolute:
            if not Path(config[dir_variable_name]).is_absolute():
                config[dir_variable_name] = os.path.join(config['REGION_ROOT_DIR'], config[dir_variable_name])
        ## #####################################################################
        '''
        # Alternative dir keys assumed for replacing the old ones
        # Table: New key | Old key | Directory name | Default directory path
        work_dirs = [
            ('SRC_DIR',     'SRC_FILEPATH',     'Input',      './{INTERCHANGE_DIR}/{BANK_NAME}/{JOB_NAME}/Input/'),
            ('DST_DIR',     'TGT_FILEPATH',     'Output',     './{INTERCHANGE_DIR}/{BANK_NAME}/{JOB_NAME}/Output/'),
            ('W4C_IN_DIR',  'W4C_IN_FILEPATH',  'W4C-Input',  './{INTERCHANGE_DIR}/{BANK_NAME}/{JOB_NAME}/W4C-Input/'),
            ('W4C_OUT_DIR', 'W4C_OUT_FILEPATH', 'W4C-Output', './{INTERCHANGE_DIR}/{BANK_NAME}/{JOB_NAME}/W4C-Output/'),
            ('TEMP_DIR',    'TEMP',             'Temp',       './{INTERCHANGE_DIR}/{BANK_NAME}/{JOB_NAME}/Temp/'),
            ('LOG_DIR',     'LOG_FOLDER',       'Logs',       './{LOGS_ROOT_DIR}/{BANK_NAME}/{JOB_NAME}/'),
        ]

        n0debug_calc(config['WORKDIR_PATH'], "config['WORKDIR_PATH']")
        for new_key, old_key, dir_name, default_path in work_dirs:

            if 'WORKDIR_PATH' in config:
                config[new_key] = config[old_key] = PytlPath(config['WORKDIR_PATH'] \
                                                    .replace('*work_dirs*', dir_name), config=config) \
                                                    .resolve() \
                                                    .str

            elif new_key not in config:
                    config[new_key] = PytlPath(config.get(old_key, default_path), config=config).str
            else:
                config[new_key] = PytlPath(config[new_key], config=config).str
        '''

        ## #####################################################################
        dirs_variables = {          # Variable synonym name     Default value for *_NAME    Root dir
            'SRC_DIR':              ( 'SRC_FILEPATH',           "Input",                    config['INTERCHANGE_DIR']   ),
            'ARCHIVE_SRC_DIR':      ( None,                     "Input.Archive",            config['INTERCHANGE_DIR']   ),
            'W4C_IN_DIR':           ( 'W4C_IN_FILEPATH',        "W4C-Input",                config['INTERCHANGE_DIR']   ),

            'W4C_OUT_DIR':          ( 'W4C_OUT_FILEPATH',       "W4C-Output",               config['INTERCHANGE_DIR']   ),
            'ARCHIVE_W4C_OUT_DIR':  ( None,                     "W4C-Output.Archive",       config['INTERCHANGE_DIR']   ),
            'DST_DIR':              ( 'TGT_FILEPATH',           "Output",                   config['INTERCHANGE_DIR']   ),

            'TEMP_DIR':             ( 'TEMP',                   "Temp",                     config['INTERCHANGE_DIR']   ),
            'LOG_DIR':              ( 'LOG_FOLDER',             "",                         config['LOGS_ROOT_DIR']     ),

        }
        # Ending directories names: 'SRC_DIR_NAME':     "Input"
        for dir_variable_name in dirs_variables:
            ending_dir_variable_name = dir_variable_name + '_NAME'
            if ending_dir_variable_name not in config:
                config[ending_dir_variable_name] = dirs_variables[dir_variable_name][1]     # Default value

        # Relative directories:     'RELATIVE_SRC_DIR': "{INTERCHANGE_BANK_DIR}/{INTERCHANGE_JOB_DIR}/{SRC_DIR_NAME}"
        for dir_variable_name in dirs_variables:
            relative_dir_variable_name = 'RELATIVE_' + dir_variable_name
            if relative_dir_variable_name not in config:
                ending_dir_variable_name = dir_variable_name + '_NAME'
                config[relative_dir_variable_name] = os.path.join(
                                                        config['INTERCHANGE_BANK_DIR'],
                                                        config['INTERCHANGE_JOB_DIR'],
                                                        config[ending_dir_variable_name]
                )

        # Directories:              'SRC_DIR': "{INTERCHANGE_DIR|LOGS_ROOT_DIR}/{INTERCHANGE_BANK_DIR}/{INTERCHANGE_JOB_DIR}/{SRC_DIR_NAME}"
        for dir_variable_name in dirs_variables:
            relative_dir_variable_name = 'RELATIVE_' + dir_variable_name
            variable_synonym = dirs_variables[dir_variable_name][0]                         # Variable synonym name
            if dir_variable_name not in config:
                if variable_synonym and variable_synonym in config:
                    config[dir_variable_name] = config[variable_synonym]
                else:
                    config[dir_variable_name] = os.path.join(
                                                    dirs_variables[dir_variable_name][2],   # Root dir
                                                    config[relative_dir_variable_name]
                    )
                n0debug_calc(config[dir_variable_name], f"config[{dir_variable_name=}]")
            if variable_synonym and variable_synonym in config:
                config[variable_synonym] = config[dir_variable_name]

## ############################################################################
        # Job sql dir and workdir insertion
        # TODO: QUERIES arg should be removed later
        resources_dirs_variables = {# Variable synonym name     Default value
            'SQL_DIR':              ( 'QUERIES',                "sql" ),
            'TEMPLATES_DIR':        ( None,                     "templates" ),
            'SCHEMAS_DIR':          ( None,                     "schemas" ),
            'RESOURCES_DIR':        ( None,                     "resources" ),
            'SETTINGS_DIR':         ( None,                     "settings" ),
            'REPORT_SETTINGS_DIR':  ( None,                     "report_settings" ),
        }
        for dir_variable_name in resources_dirs_variables:
            variable_synonym = resources_dirs_variables[dir_variable_name][0]                         # synonym variable name
            if dir_variable_name not in config:
                config[dir_variable_name] = resources_dirs_variables[dir_variable_name][1].strip()    # default value
            if dir_variable_name in config:
                if not Path(config[dir_variable_name]).is_absolute():
                    config[dir_variable_name] = os.path.join(config['JOB_DIR'], config[dir_variable_name])
                if not PytlPath(config[dir_variable_name], config=config).is_dir():
                    if variable_synonym and variable_synonym in config:
                        if not Path(config[variable_synonym]).is_absolute():
                            config[variable_synonym] = os.path.join(config['JOB_DIR'], config[variable_synonym])
                        if not PytlPath(config[variable_synonym], config=config).is_dir():
                            config[dir_variable_name] = config[variable_synonym]
                        else:
                            del config[variable_synonym]
                            del config[dir_variable_name]
                    else:
                        del config[dir_variable_name]
## ############################################################################
        # n0debug_calc(config, "config")
## ############################################################################

    # fetch params from the ENV file and store to environment variables
    def load_config(self):

        args = self.__read_sys_argv()
        n0debug("args")
        # self.__dict__.update(args)



        # if 'ENV' not in self.__dict__:
        if 'ENV' not in args:
            raise ValueError('Mandatory ENV parameter was not found')

        # file_path = self.__dict__['ENV']

        ## parms = self.__read_parm_file(file_path) # we can add default env.parm
        env_parms = load_ini(
                    args['ENV'],
                    equal_tag = (';', '='),  # For compatibility with Talend delimiter ';'
                    parse_value = lambda key_value, default_value = "": (key_value[1] or default_value or "").strip(),  # Disable converting numbers into int
        )
        n0debug("env_parms")

        # logging.debug(f'successfully loaded parm file {parms}')
        # override params from file with params from command line arguments
        ## over_parms = parms.copy()
        ## over_parms.update(args)

        # RTG: temporary disabled due to cross-init prevention
        # RTG: replaced: __configure_logging(console_level=args.get('LOG_LEVEL'), path=over_parms['LOG_FOLDER'])
        #configure_logging(console_level=args.get('LOG_LEVEL'), path=parms['LOG_FOLDER'])
        #logging.debug(f'successfully loaded agrs {args}')


        priority_parms = {}
        default_parms = {}
        if 'DEFAULT_PARMS' in args or 'PRIORITY_PARMS' in args:
            found_prm_files = get_all_related_files(
                                        what_engines:={
                                            (_job_name if (_job_name:=self.get('JOB_NAME')) != "__main__" else None) or '',
                                            Path(__file__).absolute().parent.name,
                                            
                                        },
                                        "*.prm",
                                        where_to_search_parm:={
                                            Path(__file__).absolute().parent,
                                            Path(self.get('JOB_FILE')).absolute().parent
                                        },
            )
            n0debug("found_prm_files")

            if 'DEFAULT_PARMS' in args:
                _default_parms_files = deserialize_list(args['DEFAULT_PARMS'])
                for _default_parms_file in _default_parms_files:
                    _default_parms_file_key = Path(_default_parms_file.lower()).stem
                    if _default_parms_file_key not in found_prm_files:
                        n0debug("_default_parms_file_key")
                        raise ValueError(f"File {_default_parms_file} from DEFAULT_PARMS= is not found")
                    default_parms.update(
                                    load_ini(
                                        found_prm_files[_default_parms_file_key],
                                        equal_tag = (';','='),
                                        parse_value = lambda key_value, default_value = "": (key_value[1] or default_value or "").strip(),
                                    )
                    )
            n0debug("default_parms")
                    
            if 'PRIORITY_PARMS' in args:
                _priority_parms_files = deserialize_list(args['PRIORITY_PARMS'])
                for _priority_parms_file in _priority_parms_files:
                    _priority_parms_file_key = Path(_priority_parms_file.lower()).stem
                    if _priority_parms_file_key not in found_prm_files:
                        n0debug("_priority_parms_file_key")
                        raise ValueError(f"File {_priority_parms_file} from PRIORITY_PARMS= is not found")
                    priority_parms.update(
                                    load_ini(
                                        found_prm_files[_priority_parms_file_key],
                                        equal_tag = (';','='),
                                        parse_value = lambda key_value, default_value = "": (key_value[1] or default_value or "").strip(),
                                    )
                    )
            n0debug("priority_parms")

        # Override current config from parm files, and after that, with command-line arguments
        self.__dict__.update(default_parms)
        self.__dict__.update(env_parms)
        self.__dict__.update(args)
        self.__dict__.update(priority_parms)
        self.__complete_config()  # self-check and add missed vars
        n0debug_calc(self.__dict__, "self.__dict__")

        # return over_parms
        return self.__dict__



    # show final parameters
    def show_config(self):

        # init logger with config before it

        logging.debug(f'Config: successfully loaded agrs {sys.argv}')

        logging.debug(f'Config: final agrs list ({len(self.items())} items):')
        for key, value in  self.items():
            logging.info(f'{key}={value}')

    # show final output files
    def show_output_files(self):

        if not self.OUTPUT_FILES:
            logging.info(f"The job has no registered output files.")

        else:
            for key, file_path in self.OUTPUT_FILES.items():
                # PytlPath exits by default if there is no file, so force conv to Path
                if Path(file_path).is_file():
                    logging.info(f"Output file exists {file_path} (label {key})")
                else:
                    logging.warning(f"Output file does not exist {file_path} (label {key})")


    # common init method, to provide one-line alternative to init all at class instantiation
    @staticmethod
    def configure_pytl_core(default_dict={}):

        try:
            from pytl_core import configure_logging

            config = Config(default_dict)

            config.load_config()

            configure_logging(config)

            config.show_config()

            config.EXIT_CODE = 0

            return config

        except SystemExit as exc:

            logging.error(f"Config: System Exit with code {exc} "
                          f"was called from configure_pytl_core(default={default_dict})")
            config.EXIT_CODE = exc

        except Exception as exc:

            # exc_type, exc_value, exc_traceback = sys.exc_info()
            # traceback.print_tb(exc_traceback)
            logging.exception(f"Config: Unexpected exception {exc} "
                              f"while configure_pytl_core(default={default_dict})")
            config.EXIT_CODE = exc

        finally:

            if config.get('TEST_MODE', False):
                # make all job variables available in tests, e.g. 'output_file'
                return config
            elif config.EXIT_CODE != 0:
                sys.exit(config.EXIT_CODE)

# ----------------------------------------------------------------------------------
class Params:
    __params__ = {}  # {param_name: [value||callable]}
    def __init__(self, __params__: dict, **kw):
        if not isinstance(__params__, dict):
            raise TypeError("Params.__init__(..) takes exactly one notnamed argument (dict)")
        self.__params__ = __params__

    def __getitem__(self, param_name):
        if not param_name in self.__params__:
            raise KeyError(f"{param_name} not exists in Params")
        # Without cache:
        # return self.__params__[param_name]() if callable(__params__[param_name]) else __params__[param_name]
        # With cache:
        # print(f"*0* __params__[{param_name}] = ({type(self.__params__[param_name])}) {str(self.__params__[param_name])}")
        if callable(self.__params__[param_name]):
            # print(f"*1* __params__[{param_name}] = {self.__params__[param_name]()}")
            self.__params__[param_name] = self.__params__[param_name]()
        elif \
          isinstance(self.__params__[param_name], (list, tuple)) \
          and len(self.__params__[param_name]) == 2 \
          and callable(self.__params__[param_name][0]) \
          and self.__params__[param_name][1] == True \
        :
            # print(f"*2* __params__[{param_name}] = {self.__params__[param_name][0]()}")
            return self.__params__[param_name][0]()
        # else:
            # print(f"*3* OTHER TYPE: __params__[{param_name}] = {self.__params__[param_name]}")

        return self.__params__[param_name]

    def __repr__(self):
        __repr = ""
        for key in self.__params__:
            __repr += f"{key} == '{self.__params__[key]}'\n"
        return __repr.rstrip()

    def __iter__(self):
        return iter(self.__params__)

    def keys(self):
        return self.__params__.keys()

    def values(self):
        return self.__params__.values()

    def get(self, key, default_value = None):
        return self.__params__.get(key, default_value)

    def __setitem__(self, key, value):
        self.__params__[key] = value
        return value

def raiser(ex): raise ex

########################################################################################################################
def get_all_related_files(
    engine_names: typing.Union[str, typing.Iterable[str]],
    file_masks: typing.Union[str, typing.Iterable[str]],
    start_paths: typing.Union[Path, typing.Iterable[Path]],
) -> dict:
    """
    Find all {file_mask} files related to {engine_name} and generate dict for quick search
    """

    n0debug("start_paths")
    n0debug("engine_names")
    n0debug("file_masks")

    if not isiterable(engine_names):
        raise TypeError(f"Expected engine_names as str|Iterable, but received {type(engine_names)} '{engine_names}'")
    if not isiterable(file_masks):
        raise TypeError(f"Expected file_masks as str|Iterable, but received {type(file_masks)} '{file_masks}'")
    if not isiterable(start_paths, Path):
        raise TypeError(f"Expected start_path as Path|Iterable, but received {type(start_path)} '{start_path}'")

    found_files_in_all_directories = []
    for start_path in iterable(start_paths):
        n0debug("start_path")
        for engine_name in iterable(engine_names):
            n0debug("engine_name")
            for file_mask in iterable(file_masks):
                n0debug("file_mask")
                found_files_in_all_directories += list(start_path.glob(f"../{engine_name}*/**/{file_mask}"))


    found_files = {}    # for each found file just only 1 record will be generated,
                        # where key is lower case file name only WITHOUT extention
    for file_fullpath in found_files_in_all_directories:
        # key is lower case file name only WITHOUT extention
        # n0debug("file_fullpath") # contains relative paths like '..'
        ## file_fullpath = Path(os.path.abspath(file_fullpath)) 
        file_fullpath = Path(os.path.abspath(file_fullpath))
        n0debug("file_fullpath")

        file_key = file_fullpath.stem.lower()
        if not file_key in found_files:
            # First found (the mordern one) will be used, other will be ignored
            found_files.update({file_key: file_fullpath})
        else:
            n0error(f"{file_key}: found '{file_fullpath}', but already found file with the same name '{found_files[file_key]}'")
    return found_files
