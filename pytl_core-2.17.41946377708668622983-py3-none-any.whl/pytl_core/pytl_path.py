"""PytlPath module of pytl_core package

Add extra functionality to pathlib Path objects (creation and usage)
Assumed to collect all path-based file operations in the core

Unrefactored version! (just PoC, no code optimisation done)

"""

#TODO: resort libs and chain imports scheme
from pathlib import Path
import re
import logging
import sys
import copy
from pytl_core import *
from pytl_core.timestamp import Timestamp as timestamp


class PytlPath(type(Path())):

    def __new__(cls, *args, **kwargs):
        """Extended pathlib Path object

        Composes and resolves paths that include variables from config and evaluable expressions.
        Provides improved methods for checking file existence, create / remove / clear file or dirs, and others.

        Parameters
        ----------
        args : string
            any amount of path-like strings. first resolvable will be used.
        config : dict
            Pytl config (or another dictionary) will be used for looking for substitution variables
        unresolved_path_error : bool
            Log error and exit if mandatory args was provided in config, but are not resolvable to paths

        Returns
        -------
        PytlPath obj
            Is a subclass of pathlib Path objects, extended with special methods for pytl path configure and tasks

        Extra methods
        -------------
        (preliminary set of planned methods)
            "exists" - will check existence and raise an error if path does not exist
            "remove" - will remove a file or a directory
            "create_parents" - will make all parents dirs (if not exist)
            "create_file" - will make an empty file with specified name (if not exists)
            "create_dir" - will make an dir with specified name (if not exists)
            "clear_dir" - will empty a dir with specified name (even if is not empty)
            "masked_clear" - will remove files from parent dir according to the file mask in path
            "masked_listdir" - will get a list of files from parent dir according to the file mask in path

        Examples
        --------
        in .parm file:
        >>> BANK_NAME;COMMON
        >>> SQL_DIR;./../PyTL_Jobs/<BANK_NAME>/Output/
        SQL_DIR=./../PyTL_Jobs/COMMON/Output/

        in COM_Ou_SQLtoCSV.py file:
        >>> sql_file = PytlPath('{SQL_FILE} || {SQL_DIR}/{{SQL_FILE || OUTPUT_FILE}.stem}.sql').is_file()
        PytlPath('C:/Temp/pytl_jobs/pytl_jobs/COMMON/sql/W4_PROCESS_LOG_DUMP.sql')

        in COM_Ou_SQLtoCSV.py file:
        >>> output_file = PytlPath(
        ...     '{OUTPUT_FILE} || {DST_DIR}/{{OUTPUT_FILE || SQL_FILE}.stem}_{timestamp().solid}.csv').create_parents()
        PytlPath('C:/Temp/pytl_jobs/pytl_jobs/COMMON/tests/TEST_IO/COM_Ou_SQLtoCSV_py/Output/W4_PROCESS_LOG_DUMP_20210615121129.csv')

        """

        # Load default config (used for search
        if 'config' not in kwargs:
            from pytl_core.config import Config
            kwargs['config'] = Config()

        # Resolving some complex args to a simple one is a main part of work
        args = [cls.compose(cls, *args, **kwargs)]

        return super(PytlPath, cls).__new__(cls, *args, **kwargs)

    def compose(self, *args, config={}, unresolved_path_error=True):
        """Compose paths on based of variables form config, and check mandatory config params on-the-go

        Take path-like strings with substitution variables,
        and use config keys and code evaluation for path resolving.
        Log ERROR and make sys exit if not possible to perform all tasks.
        
        Parameters
        ----------
        unresolved_path_error : bool
            When True - if a path substitution variable is NOT in config, it considered to be optional and skipped,
            elsif it IS in config - considered to be mandatory and resolvable path, and raises an error if unresolvable.

        Returns
        -------
        pathlib Path object

        Algorithm
        ---------
        1. take any number of string args (like file paths)
        2. split strings separated by "||" to alternatives (will increase amount of args)
        3. iterate over args till the end, break on success:
        3.1 try to resolve an arg by recursive curly "{expr}" brackets enclosing:
        3.1.1 try to substitute variables from config before enclosing
        3.1.2 try to enclosing enclose brackets, go deeper if needed
        3.1.3 try to evaluate expressions from upper-level brackets enclosing and substitute them as parts of string
        4. if the arg resolved - return Path obj, otherwise continue and raise an error after the last iteration

        """

        def substitute_variables(arg, config={}):
            # Parse config and substitute variables by names
            # e.g. "{NAME}" or "<NAME>" --> "cofig['NAME']" or "PytlPath(cofig['NAME'])"
            while any(bool(re.findall(f'(?<![\'\"])[<|{{]?{key}[}}|>]?(?![\'\"])', arg)) for key in config):

                for key in config:
                    subst_var = None
                    if key in arg:
                        if key.endswith('_FILE') or key.endswith('_DIR'):
                            subst_var = f"{{PytlPath(config['{key}'])}}"
                        else:
                            subst_var = f"{{config['{key}']}}"
                    # substitute both regular and enclosed keys, exclude quoted
                    if subst_var:
                        arg = re.sub(f'(?<![\'\"])[<|\{{]?{key}[\}}>]?(?![\'\"])', subst_var, arg)

            substitution_variables = re.findall(r'[<](.*?)[>]', arg)  # remove brackets
            for var in substitution_variables:
                if var.endswith('_FILE') or var.endswith('_DIR'):
                    subst_var = f"{{PytlPath(config['{var}'])}}"
                else:
                    subst_var = f"{{config['{var}']}}"

                # substitute both regular and enclosed keys, exclude quoted
                if subst_var:
                    arg = re.sub(f'(?<![\'\"])[<]?{var}[>]?(?![\'\"])', subst_var, arg)
                    # print(f"arg after config parsing 2 {arg}")

                # The var seems to be missed in config but specified in arg
                missed_params.add(var)

            return arg


        def evaluate_arg(code_snippet, config={}):
            # config is passed to eval inderectly via locals

            variable_name = re.split(r'\.', code_snippet)[0]

            try:
                return str(eval(code_snippet.encode()))

            except (NameError, KeyError) as e:
                missed_params.add(variable_name)
                return None

            except Exception as e:
                raise ValueError(
                    f"PytlPath compose command error. "
                    f"Substitution variable \'{variable_name}\' could not been resolved for argument \'{arg}\'.")


        def recursive_brackets_enclose(arg, recursion_depth=0, config={}):

            # subst vars from config before curly brackets evaluation
            arg = substitute_variables(arg, config)

            while ('{' in arg) and ('}' in arg):

                enclosed_brackets = PytlPath.catch_brackets(arg)

                if not enclosed_brackets:
                    raise ValueError(f"Path in {arg} has inconsistent curly barackets")
                elif recursion_depth == 0:
                    backup_enclosed_brackets = enclosed_brackets

                while ('{' in enclosed_brackets) and ('}' in enclosed_brackets):
                    enclosed_brackets = recursive_brackets_enclose(enclosed_brackets, recursion_depth + 1)

                if recursion_depth == 0:

                    string_obj = evaluate_arg(enclosed_brackets, config=config)

                    if string_obj:
                        arg = arg.replace(f"{{{backup_enclosed_brackets}}}", string_obj, 1)
                    else:
                        return None  # some parameters missed, evaluation not possible
                else:
                    arg = arg.replace(f"{{{enclosed_brackets}}}", enclosed_brackets, 1)

            return arg



        # STAGE 1 (preliminary):
        # split "||" alternatives in/between parts of paths on independend and full path s
        args = PytlPath.split_args_sitring(*args)

        # STAGE 2 (main and last):
        # Resolving alternative path args (with priority from left to right)
        # First resolved will be returned, otherwise exit with
        missed_params = set()
        last_arg_index = len(args) - 1

        for i_arg, arg in enumerate(args):

            # Recursive enclosing of curly brackets and resolving expressions
            resolved_arg = recursive_brackets_enclose(arg, config=config)

            if resolved_arg not in [None, 'None']:

                try:
                    path_obj = Path(resolved_arg.strip()).resolve()
                    return path_obj

                except Exception as e:
                    var_name = args[i_arg]
                    missed_params.add(var_name)
                    msg = f"Unresolvable mandatory parameter provided to PytlPath: " \
                          f"{args[i_arg]} --> {arg} --> {resolved_arg}, \n" \
                          f"(resolving attempt case the exception: {e})"

                    # exit on error is allowed from outside
                    if unresolved_path_error:
                        logging.error(msg)
                        sys.exit(1)
                    else:
                        logging.warning(msg)

            # this was the last arg and resolve was not successfull
            elif i_arg == last_arg_index:
                logging.error(f"Missed input params: {missed_params}. "
                              f"Check mandatory params alternatives in PytPath.compose({args})")
                sys.exit(1)

            # else: goto next arg (cycle iteration)


    @staticmethod
    def split_args_sitring(*args):

        # if Path or PytlPath item happens, convert back to string
        alt_path_string = [str(arg) for arg in args]

        while '||' in ' '.join(alt_path_string):
            new_alt_path_string = []
            for arg in alt_path_string:

                if '||' in arg:
                    unparity_counter = 0
                    brackets_found = [i for i in re.finditer(r'\{|\}|\|{2}', arg)]

                    for i_obj, re_match_obj in enumerate(brackets_found):

                        if re_match_obj.group() == '{':
                            unparity_counter += 1

                        elif re_match_obj.group() == '}':
                            unparity_counter -= 1

                        elif re_match_obj.group() == '||':

                            if unparity_counter == 0:
                                arg_left = arg[:re_match_obj.start()]
                                arg_right = arg[re_match_obj.end():]

                            else:
                                unparity_counter_left = 0
                                for obj_left in brackets_found[i_obj - 1::-1]:
                                    if obj_left.group() == '{' and unparity_counter_left == 0:
                                        index_arg_left = obj_left.start()
                                        break
                                    elif obj_left.group() == '}':
                                        unparity_counter_left += 1
                                    else:  # obj_left.group() = '{' and unparity_counter_left > 0
                                        unparity_counter_left -= 1

                                unparity_counter_right = 0
                                for obj_right in brackets_found[i_obj + 1:]:
                                    if obj_right.group() == '}' and unparity_counter_right == 0:
                                        index_arg_right = obj_right.start()
                                        break
                                    elif obj_right.group() == '{':
                                        unparity_counter_right += 1
                                    else:  # obj_right.group() = '}' and unparity_counter_right > 0
                                        unparity_counter_right -= 1

                                pass  # duplicate and split in smallest brackets
                                arg_left = arg[:re_match_obj.start()].strip() + arg[index_arg_right:].strip()
                                arg_right = arg[:index_arg_left + 1].strip() + arg[re_match_obj.end():].strip()

                            new_alt_path_string.extend([arg_left.strip(), arg_right.strip()])
                            break
                else:
                    new_alt_path_string.append(arg.strip())

            alt_path_string = copy.copy(new_alt_path_string)

        return alt_path_string


    @staticmethod
    def catch_brackets(string=None, brackets='{}', disclose=True):

        brackets_found = [(i.start(), i.group()) for i in re.finditer(r'[{}]', string)]
        unparity_counter = 0

        for bracket_index, bracket_char in brackets_found[1:]:
            if bracket_char == brackets[1]:
                if unparity_counter == 0:
                    if disclose:
                        return string[brackets_found[0][0]+1:bracket_index]
                    else:
                        return string[brackets_found[0][0]:bracket_index+1]
                else:
                    unparity_counter -= 1
            else:
                unparity_counter += 1
        return None



    # SOME EXTRA METHODS (not all from planned is implemented)

    def is_file(self, type=None):
        """ check file exists

        Log error and exit if no, return path object if ok

        Parameters
        ----------
        type : string or list/tuple of strings
            planned (not implemented) parameter for checking if the object is a file of certain type
            by file extension or/and content (e.g. .sql is really sql)

        Returns
        -------
        path object
            standard Path().is_file() form pathlib performs a logical check,
            here we log error and exit (assumed the file to be a mandatory param),
            or return object for further usage (means the validation was successfull).

        """
        if self.str == 'None':
            raise ValueError(f"PytlPath: path to file is {None}")

        if not super(PytlPath, self).is_file():
            # additional check e.g. "type" may be here

            logging.error(f"PytlPath: File not found {self.str}")

            sys.exit(1)

        return self


    def mkdir(self, mode=0o777, parents=True, exist_ok=True, *args, **kvargs):
        """ mkdir which returns path object and set another default values for input args"""

        super(PytlPath, self).mkdir(mode=mode, parents=parents, exist_ok=parents, *args, **kvargs)

        return self


    def create_parents(self, mode=0o777, parents=True, exist_ok=True, *args, **kvargs):
        """ mkdir which create parent dirs and return path object """

        self.parent.mkdir(mode=mode, parents=parents, exist_ok=parents, *args, **kvargs)

        return self

    def clear_dir(self, deletion_log=False, dir_not_exist='create' ):
        """ remove all files from current path (should target a dir) and return path object """

        if super(PytlPath, self).is_file():
            raise ValueError(f"PytlPath: specified path is not a directory but a file: {self}")

        elif not super(PytlPath, self).is_dir():
            if dir_not_exist == 'error':
                logging.error(f"PytlPath: dir not found {self}")

            elif dir_not_exist == 'warning':
                logging.warning(f"PytlPath: dir not found {self}")

            if dir_not_exist in ['create', 'warning']:
                self.mkdir()

        for file in self.iterdir():

            file.unlink(missing_ok=True)
            if deletion_log:
                logging.info(f"File deleted {file}")

        return self


    def has_parts(self):
        """ checks if path object consist from multiple parts (used in resolving of vars substitution) """
        return self if len(self.parts) > 1 else None


    @property
    def str(self):
        """ fast call of string transform """
        return self.__str__()

    #TODO: review UI requirements. duplicate or replace "+" with "^" operator (or try "&"?)
    def __add__(self, path):
        """ Use "+" operator for appending string (not path, like "/" does)  """
        try:
            return PytlPath(str(self) + str(path))
        except TypeError:
            return NotImplemented

    #TODO: review UI requirements. duplicate or replace "+" with "^" operator (or try "&"?)
    def __xor__(self, path):
        """ Use "^" operator for appending string (not path, like "/" does)  """
        try:
            return PytlPath(str(self) + str(path))
        except TypeError:
            return NotImplemented


    def add_to_config(self, config_key, subdict_key=None):
        """ the method was designed for storing output file paths in config, but is suitable for any records"""

        from pytl_core.config import Config
        cfg = Config()

        if isinstance(cfg.get(config_key, None), list):
            cfg[config_key].append(copy.deepcopy(self))

        elif isinstance(cfg.get(config_key, None), dict):
            if not subdict_key:
                subdict_key = len(cfg[config_key])
            logging.debug(f"!!!! saved 1 {self} type {type(self)}")
            # TODO: debug: we coudln't save PytlPath properly because of not the same read back value
            # (only drive leter. e.g. C:/), and copy / deepcopy does not solve it.
            cfg[config_key][subdict_key] = Path(self.str)
            logging.debug(f"!!!! saved 3 {cfg[config_key][subdict_key]} type {type(cfg[config_key][subdict_key])}")

        else:
            cfg[config_key] = copy.deepcopy(self)

        return self

    def remove_from_config(self, config_key=None, subdict_key=None):
        """ the method was designed for storing output file paths in config, but is suitable for any records"""

        from pytl_core.config import Config
        cfg = Config()

        if not config_key:

            NOT_FOUND = True

            for key, value in copy.deepcopy(cfg).items():

                if value == self:
                    del cfg[key]
                    NOT_FOUND = False
                    # no break to remove all matches

                elif isinstance(value, list):
                    for item in copy.deepcopy(value):
                        if value == self:
                            del cfg[key][value.index(item)]
                            NOT_FOUND = False

                elif isinstance(value, dict):
                    for sub_key, sub_value in copy.deepcopy(value).items():
                        if sub_value == self:
                            del cfg[key][sub_key]
                            NOT_FOUND = False

            if NOT_FOUND:
                logging.error(f"PytlPath: object {self} not found in config an cannot be removed.")

        if config_key in copy.deepcopy(cfg).keys():

            if isinstance(list_obj := cfg[config_key], list):
                if self in list_obj:
                    del list_obj[list_obj.index(self)]
                else:
                    logging.error(f"PytlPath: config key {config_key} found, contains list,"
                                  f"but the object {self} do not found in list and cannot be removed.")

            elif isinstance(dict_obj := cfg[config_key], dict):
                if subdict_key:
                    if dict_obj[subdict_key] == self:
                       del cfg[config_key][subdict_key]
                    else:
                        logging.error(f"PytlPath: config key {config_key} found, "
                                      f"contains dict, subkey {subdict_key} found, "
                                      f"but the object {self} do not match and cannot be removed.")
                else:
                    NOT_FOUND = True
                    for sub_key, sub_value in copy.deepcopy(dict_obj).items(): # int
                        if sub_value == self:
                            del cfg[config_key][sub_key]
                            NOT_FOUND = False
                            # no break to continue scanning and remove all values
                    if NOT_FOUND:
                        logging.error(f"PytlPath: config key {config_key} found, contains dict, subkey not defined, "
                                      f"but the object {self} do not found ins subdict and cannot be removed.")

            else:
                if cfg[config_key] == self:
                    del cfg[config_key]
                else:
                    logging.error(f"PytlPath: config key {config_key} found, "
                                  f"but the object {self} do not match and cannot be removed.")

        return self