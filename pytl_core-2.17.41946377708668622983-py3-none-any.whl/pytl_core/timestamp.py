"""Pytl core timestamp.py

A module for fast access to timestamps as strings
to be easily inserted in filenames, reports, etc

"""

import datetime
import re

class Timestamp(str):
    """Sting of timestamp with easy access to format conversions

    see details in class constructor (__new__)

    List of fast conversion methods
    Regular attributes are not used due to getattr() redefining was not successful for str

    solid = '%Y%m%d%H%M%S'           # 20210612083400
    slashed = '%d/%m/%Y %H:%M:%S'    # 12/06/2021 08:34:00
    slashed_dmy = '%d/%m/%Y'         # 12/06/2021 
    slashed_dby = '%d/%b/%Y'         # 12/Jun/2021 
    dashed = '%d-%m-%Y %H:%M:%S'     # 12-06-2021 08:34:00
    dashed_dmy = '%d-%m-%Y'          # 12-02-1991
    dashed_dby = '%d-%b-%Y'          # 12-Feb-1991
    julian = '' # day from the beginning or julian calendar, i.e. Nov 24 4717 BC. See SOFW/13943062 for methods.
    ordinal = '%Y-%j'                # 2021-152 # number of year and number of day in the year
    ordinal_yj = '%Y%j'              # 2021152  # number of year and number of day in the year
    ordinal_day = '%j'               # 152      # number of the day in the year, e.g. 2021-06-01 == 152                   
    decreasing = '%Y-%m-%d-%H-%M-%S' # 2021-06-08-16-59-59
    isoformat = '%Y-%m-%d %H:%M:%S'  # 2021-06-08 16:59:59
    isoformat_ymd = '%Y-%m-%d'       # 2021-06-08
    time = '%H:%M:%S'                # 08:34:00

    """

    default_format = '%d-%m-%Y' # 08-06-2021

    def __new__(cls, output_format=None, stamp_time=None, input_format=None, metainfo=None):
        """Sting of timestamp with easy access to format conversions

        Parameters
        ----------
        output_format : string
            Output datetime string format. If not provided self.default_format is used.
            Will be kept in timestamp object as current format.
            name "output_format" is not the best, but is used because "format" is a builtin keyword,
            and it's better not to redefine it, even if currently not used in the class
        stamp_time : datetime or string
            The string datetime value. If not provided - current datetime is used.
            If string provided input_format will be applied.
            Special case - if output_format is omitted, stamp_time is provided instead as unnamed first arg,
            input_format is optional and may be provided as unnamed seconf arg. Then all the args will be reassigned.
        input_format : string
            Input datetime string format (if stamp_time is a string)
            If not provided self.default_format is used.
        metainfo : string
            additional info that can be stored with the timestamp string
            not used/required for any class methods

        Returns
        -------
        string subclass
            formatted timestamp string with additional attributes
            (keeps datetime object, current format, some common formats for conversion as attributes)

        Notes
        -----
        The order of input arguments is based on "most used input arg first",
        taking into account cases with default datetime.now() usage.
        Maybe it will be more logical to specify imput_format first, and output_format last,
        e.g in case of "output_format + stamp_time : string + imput_format",
        or make variable args with auto-detect, e.g. in case of only "stamp_time : datetime + output_format" given.

        Examples
        --------
        >>> timestamp()
        '20210606130309'
        >>> timestamp().slashed
        '06/06/2021 13:03:36'
        >>> timestamp('%Y-%m-%d')
        '2021-06-06'
        >>> timestamp('%d %b %Y', '2042-12-19', '%Y-%m-%d')
        '19 Dec 2042'
        >>> timestamp(stamp_time=datetime.strptime('1 1 2079','%d %m %Y')).solid
        '20790101000000'
        >>> timestamp(datetime.strptime('1 2 2079','%d %m %Y')).format('%Y-%j')
        '2079-032'
        >>> timestamp('1 2 2079','%d %m %Y').format('%Y-%j')
        '2079-032'
        >>> help(timestamp)
        # will show this docstring

        """

        if not output_format:
            output_format = cls.default_format

        # auto-detect cases when stamp_time is provided as the first arg,
        # input_format is omitted, named, or the second arg,
        # output_format is surely omitted.
        # Check if output_format supposed to be not a format string if it has more digits than percent chars
        if isinstance(output_format, datetime.datetime) \
                or len(re.findall(r'[0-9]', output_format)) > len(re.findall(r'%', output_format)):
            if (stamp_time is None or isinstance(stamp_time, str)):
                if input_format is None:
                    input_format = stamp_time
                stamp_time = output_format
            output_format = cls.default_format

        if not stamp_time: # default is now
            datetime_obj = datetime.datetime.now()

        elif isinstance(stamp_time, datetime.datetime):
            datetime_obj = stamp_time

        else: # supposed to be a datetime string
            if input_format == None: input_format = cls.default_format
            datetime_obj = datetime.datetime.strptime(stamp_time, input_format)

        # Get regular string with timestamp contents
        datetime_str = datetime_obj.strftime(output_format)
        output_str = super(Timestamp, cls).__new__(cls, datetime_str)

        # Store additional attributes of timestamp string for format access and conversions
        output_str.stamp_time = datetime_obj
        output_str.output_format = output_format
        output_str.metainfo = metainfo

        return output_str


    # Unused due to recursion problem was not fixed by super()
    """ 
    def __getattribute__(self, item):
        output_format = super(Timestamp, self).__getattribute__(item)
        return Timestamp(output_format, self.stamp_time, metainfo=self.metainfo)
    """

    def format(self, output_format):
        """ Apply specific format provided

        Parameters
        ----------
        output_format : string
            Special letter keys should be prefixed with %, use %% for percent character.

        Returns
        -------
        string
            formatted timestamp string with additional attributes
            (keeps datetime object, current format, some common formats for conversion)

        """
        if not output_format: raise ValueError(f"New format not specified")
        return Timestamp(output_format, self.stamp_time, metainfo=self.metainfo)

    @property
    def solid(self):
        return self.format('%Y%m%d%H%M%S')

    @property
    def slashed(self):
        return self.format('%d/%m/%Y %H:%M:%S')

    @property
    def slashed_dmy(self):
        return self.format('%d/%m/%Y')

    @property
    def slashed_dby(self):
        return self.format('%d/%b/%Y')

    @property
    def dashed(self):
        return self.format('%d-%m-%Y %H:%M:%S')

    @property
    def dashed_dmy(self):
        return self.format('%d-%m-%Y')

    @property
    def dashed_dby(self):
        return self.format('%d-%b-%Y')

    @property
    def ordinal(self):
        return self.format('%Y-%j')

    @property
    def ordinal_yj(self):
        return self.format('%Y%j')

    @property
    def ordinal_day(self):
        return self.format('%j')

    @property
    def decreasing(self):
        return self.format('%Y-%m-%d-%H-%M-%S')

    @property
    def isoformat(self):
        return self.format('%Y-%m-%d %H:%M:%S')

    @property
    def isoformat(self):
        return self.format('%Y-%m-%d')

    @property
    def time(self):
        return self.format('%H:%M:%S')

