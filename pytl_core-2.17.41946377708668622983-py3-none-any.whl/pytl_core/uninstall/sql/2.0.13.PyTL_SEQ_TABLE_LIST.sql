set linesize 2000
set serveroutput on
set verify off

declare
    V_SQL_TEXT   varchar2(32000);
    V_TABLE_NAME USER_TABLES.TABLE_NAME%type := 'PyTL_SEQ_TABLE_LIST';
begin
    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to drop table ''' || V_TABLE_NAME || ''' if exists');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from USER_TABLES where upper(TABLE_NAME) = upper(V_TABLE_NAME) having count(1) = 1)
    loop
        V_SQL_TEXT := 'drop table ' || V_TABLE_NAME || ' cascade constraints';
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;
    commit;
end;
/

exit;
