set linesize 2000
set serveroutput on
set verify off

declare
    V_SQL_TEXT   varchar2(32000);
    V_PACKAGE_NAME USER_TABLES.TABLE_NAME%type := 'PyTL_JOB_SUPPORT';
begin
    dbms_output.put_line('************************************************************');
    dbms_output.put_line('*** Try to drop package ''' || V_PACKAGE_NAME || ''' if exists');
    dbms_output.put_line('************************************************************');

    for rec in (select 1 from ALL_OBJECTS where (OBJECT_TYPE = 'PACKAGE' or  OBJECT_TYPE = 'PACKAGE BODY') and upper(OBJECT_NAME) = upper(V_PACKAGE_NAME) having count(1) > 0)
    loop
        V_SQL_TEXT := 'drop package ' || V_PACKAGE_NAME;
        dbms_output.put_line('>>> ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
    end loop;

    commit;
end;
/

exit;
