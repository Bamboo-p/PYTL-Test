import shutil
import logging
import os
'''
import numpy as np
'''
from pathlib import Path
import json
import sys
import itertools
from string import Formatter as string__Formatter

import pytl_core.pytl_globals as pytl_globals

class Sequence(object):
    seq_dict = {}

    @staticmethod
    def get_next_seq_number(name, start, step):
        if name in Sequence.seq_dict:
            Sequence.seq_dict[name] = Sequence.seq_dict[name] + step
            return Sequence.seq_dict[name]
        else:
            Sequence.seq_dict[name] = start
            return start

    @staticmethod
    def next(name, start = 1, step = 1):
        return Sequence.get_next_seq_number(name, start, step)


def string_not_empty(string_value):
    result = False
    if string_value and bool(string_value.strip()):
        result = True
    return result


def delete_file(file_name):
    try:
        Path(file_name).unlink(missing_ok=True)
        logging.info(f"file has been removed {file_name}")
    except Exception as e:
        logging.error(e)
        raise e


def clean_folder(path, file_mask='*'):
    if path.is_dir():
        shutil.rmtree(path)
    path.mkdir(parents=True)
    # for f in Path(path).glob(file_mask):
    #     delete_file(path)


def load_statement_from_file(path, _config={}):
    ## For using config in lambda functions:
    if _config:
        config = _config
    elif pytl_globals.config:
        config = pytl_globals.config
    else:
        raise Exception('variable config is not defined')


    # RTG: what is statement? the name seems unclear for me

    # quoted path string if given won't be loaded properly
    if isinstance(path, str):
        path = path.strip('"')

    path = Path(path).resolve()

    if not path.is_file():
        logging.error(f"Statement file not found ({path})")
        sys.exit(1)

    with path.open('r') as f_obj:
        sql_text = f_obj.read()

    # [+] begin 220621.1 v2.7: added ability to include into SQL files placeholders with complex logic based on config variable
    if "{{" in sql_text:
        # if "{{" is/are found, then complex logic exists
        # All double { will be replaced into single { and all single { will be replaced into double {{
        # it's required to parse correctly placeholders with string.Formatter().parse(str)
        formated_sql_text = sql_text \
                                .replace("{{", "\xDE")  \
                                .replace("}}", "\xFE")  \
                                .replace("{", "{{")     \
                                .replace("}", "}}")     \
                                .replace("\xDE", "{")   \
                                .replace("\xFE", "}")
        sql_text = ""
        for parsed_items in string__Formatter().parse(formated_sql_text):
            if not parsed_items[1] and not parsed_items[2] and not parsed_items[3]:
                sql_text += parsed_items[0]
            else:
                parsed_items_for_eval = parsed_items[1]
                if parsed_items[2]:
                    # raise Exception(f"unexpected format_spec (parsed_items[2]): {parsed_items[2]}")
                    parsed_items_for_eval += ':' + parsed_items[2]
                if parsed_items[3]:
                    raise Exception(f"unexpected conversion (parsed_items[3]): {parsed_items[3]}")
                eval_parsed_items = eval(parsed_items_for_eval)
                # logging.debug(f"\n------------------------------->\n{parsed_items_for_eval}\n===============================>\n{parsed_items_for_eval}\n<-------------------------------")
                sql_text += parsed_items[0] + eval_parsed_items
        logging.debug(f"Loaded and compiled on the fly SQL file {path}:\n" + sql_text)
    return sql_text
    # [+] end   220621.1 v2.7: added ability to include into SQL files placeholders with complex logic based on config variable
    '''
    if not config:
        return sql_text

    # This will keep all loaded sqls and bind wars in config. if may be removed in future - if not used.
    config.setdefault('SQL_QUERIES',[]).append(sql_text)
    config.setdefault('SQL_BIND_VARS',[]).\
        append({key: val for (key, val) in config.items() if f":{key.lower()}" in sql_text.lower()})

    return config['SQL_QUERIES'][-1], config['SQL_BIND_VARS'][-1]
    '''


'''
def pandas_dataframe_to_csv_file(df, file_name, delimiter='', header=False, index=False, mode='w', np_mode=False, log=True):
    try:
        # numpy correct handles records with \n
        folder = os.path.dirname(file_name)
        Path(folder).mkdir(parents=True, exist_ok=True)
        if np_mode:

            with open(file_name, mode) as target:
                numpy_array = df.to_numpy(dtype=object, na_value='')
                np.savetxt(target, numpy_array, fmt='%s', delimiter=delimiter)
        else:
            df.to_csv(path_or_buf=file_name, sep=delimiter, header=header, index=index,
                  mode=mode)
        if log:
            logging.info(f"file {file_name} contains {len(df.index)}")
    except Exception as e:
        logging.error(f"file isn't created/appended: {e}")
        raise e
'''

def string_to_file(str, file_name, mode='w', log=False):
    try:
        folder = os.path.dirname(file_name)
        Path(folder).mkdir(parents=True, exist_ok=True)
        with open(file_name, mode) as file:
            file.write(str)
        if log:
            logging.debug(f"file {file_name} updated by {str[:20]}")
    except Exception as e:
        logging.error(f"file isn't created/appended: {e}")
        raise e

def capitalize(x):
    if isinstance(x, list):
        return [capitalize(v) for v in x]
    elif isinstance(x, dict):
        return {k.lower(): capitalize(v) for k, v in x.items()}
    else:
        return x

def read_json(file_name):
    try:
        with open(file_name, 'r') as json_file:
            data = json.load(json_file)
            data_upd = capitalize(data)
            logging.info(f"reading json file {file_name}")
            return data_upd
    except Exception as e:
        logging.error(e)
        raise e

def primed(iterable):
    """ To make first iteration of lazy evaluation """

    #TODO: rewrite for DB case, src url: SOF/5724009

    #itr = iter(iterable)
    # convert list of lists of dicts to list of dicts
    itr = itertools.chain.from_iterable(iterable)

    # force first iteration if possible
    try:
        first = next(itr)
    except StopIteration:
        return itr
    return itertools.chain([first], itr)


def get_public(vars={}):
    """ For providing locals from job back to tests for checking """

    public_dict = {k:v for k,v in vars.items() if not k.startswith('_')}

    return public_dict

def str2bool(value):
    """ check special string cases to make bool from str """
    if isinstance(value, str):
        if any(value.lower() == v for v in ['1', 'true', 'yes', 'y']):
            return True
        elif any(value.lower() == v for v in ['0', 'false', 'no', 'n', 'none', 'null', '']):
            return False

    return bool(value)

def make_serializable(some_object):
    """ ensure object is serializable else replace with description string """

    if isinstance(some_object, (int, str, bool, type(None))):
        return some_object

    elif isinstance(some_object, dict):
        return {key: make_serializable(value) for key, value in some_object.items()}

    elif isinstance(some_object, (list, tuple, set)):
        return (make_serializable(item) for item in some_object)

    else:
        return str(some_object)
