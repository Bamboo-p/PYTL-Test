from requests.exceptions import SSLError

print("-" * 70)
print(f"{__file__=}")

import os
import argparse

import requests
from datetime import datetime


def download_file(url, target_folder, target_file_name, params):
    print("download_file started")
    print(f"url: {url}")
    print(f"target_folder: {target_folder}")
    print(f"target_file_name: {target_file_name}")
    print(f"params: {params}")
    print(f"REQUESTS_CA_BUNDLE: {os.environ.get('REQUESTS_CA_BUNDLE')}")
    # Create the target folder if it doesn't exist
    os.makedirs(target_folder, exist_ok=True)

    # Create a filename based on the current date and time
    current_datetime = datetime.now().strftime('%y%m%d_%H%M%S')
    filename = f"{target_file_name}_{current_datetime}.csv"

    # Combine the folder path and filename to get the full file path
    file_path = os.path.join(target_folder, filename)

    # Create a dictionary for HTTP GET parameters
    params_dict = string_params_to_dict(params)

    # for testing purposes on servers without internet:
    if "fake" in url:
        generate_fake_file(file_path)
        return
    # Perform the HTTP GET request and save the file
    print(f"requesting url: "f"{url}\nparams: {params_dict}")
    try:
        response = requests.get(url, params=params_dict)
    except SSLError as e:
        print(f"ERROR: SSL certificate validation failed. Root certificate must be installed in the system. "
              f"Run pip install pip_system_certs for requests module to use system certificates.")
        raise e
    except requests.exceptions.RequestException as e:
        if response:
            status_code = response.status_code
        print(f"Failed to download file. Status code: {status_code or 'N/A as no response received'}")
        raise e
    print(f"response: {response}")
    response.raise_for_status()
    if response.status_code == 200:
        with open(file_path, 'wb') as file:
            file.write(response.content)
        print(f"File downloaded to: {file_path}")


def generate_fake_file(file_path):
    print("WARNING! fake url received. fake file will be generated")
    with open(file_path, 'w') as file:
        file.write("fake content")
        print(f"Fake file downloaded to {file_path}")


def string_params_to_dict(string):
    if not string:
        return {}
    return dict(token.split('=') for token in string.split("&"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Download a file from a URL with optional parameters.")
    parser.add_argument("--url", help="URL of the file to download", required=True)
    parser.add_argument("--target_folder", help="Target folder where the file will be saved", required=True)
    parser.add_argument("--target_file_name", default="exceptions_report",
                        help="Resulting file name is gonna be like {target_file_name}_{current_datetime}.csv",
                        required=True)
    parser.add_argument("--http_params",
                        help="string with HTTP GET parameters in the format key1=value1&key2=value2")
    parser.add_argument("other_params", nargs="*", help="Additional parameters will be ignored")

    args = parser.parse_args()
    download_file(args.url, args.target_folder, args.target_file_name, args.http_params)
