import glob
import shutil
from pathlib import Path

import pytest
import requests

from pytl_jobs.NIC.PyTL_Get_File_by_Http.__main__ import string_params_to_dict, download_file


@pytest.fixture(scope="function")
def temp_folder():
    temp_folder = Path(__file__).parent.joinpath("temp_folder")
    yield temp_folder
    shutil.rmtree(temp_folder)


class TestDownloadFile:
    def test1(self, requests_mock, temp_folder):
        # test data
        url = "https://momopvt.network.ae/api/v1/report?startDate=2023-10-11T22:00:00.000Z%22"
        target_folder = temp_folder
        target_file_name = "exceptions_report"
        http_parms = ""
        # test scenario
        test_file = Path(__file__).parent.joinpath(r"test_data\test_exceptions_report_231007_095655.csv")
        with open(test_file, "rb") as file:
            requests_mock.get(url, body=file)
            download_file(url, target_folder, target_file_name, http_parms)
        # assertions
        actual_file_name = glob.glob(f"{target_file_name}*", root_dir=target_folder)[0]
        actual_file = target_folder.joinpath(actual_file_name)
        assert actual_file.is_file()
        with open(test_file, "r") as tfile:
            with open(actual_file, "r") as afile:
                assert tfile.read() == afile.read()

    def test_negative(self, requests_mock, temp_folder):
        # test data
        url = "https://momopvt.network.ae/api/v1/report?startDate=2023-10-11T22:00:00.000Z%22"
        target_folder = temp_folder
        target_file_name = "exceptions_report"
        http_parms = ""
        # test scenario
        test_file = Path(__file__).parent.joinpath(r"test_data\test_exceptions_report_231007_095655.csv")
        with open(test_file, "rb") as file:
            requests_mock.get(url, status_code=404)
            with pytest.raises(requests.exceptions.RequestException):
                download_file(url, target_folder, target_file_name, http_parms)
        # assertions

    def test_fake_url(self, temp_folder):
        # test data
        url = "https://fake_momopvt.network.ae/api/v1/report?startDate=2023-10-11T22:00:00.000Z%22"
        target_folder = temp_folder
        target_file_name = "exceptions_report_fake"
        http_parms = ""
        # test scenario
        download_file(url, target_folder, target_file_name, http_parms)
        # assertions
        actual_file_name = glob.glob(f"{target_file_name}*", root_dir=target_folder)[0]
        actual_file = target_folder.joinpath(actual_file_name)
        assert actual_file.is_file()
        with open(actual_file, "r") as afile:
            assert "fake content" == afile.read()


class TestStringParamsToDict:
    def test_startDate(self):
        string = "startDate=2023-10-04T01:30:00.000+04:00"
        assert string_params_to_dict(string) == {"startDate": "2023-10-04T01:30:00.000+04:00"}

    def test_empty_string(self):
        string = ""
        assert string_params_to_dict(string) == {}

    def test_many_params(self):
        string = "key1=value1&key2=value2&key3=value3"
        assert string_params_to_dict(string) == {
            "key1": "value1",
            "key2": "value2",
            "key3": "value3",
        }

    def test_invalid_input_1(self):
        string = "startDate"
        with pytest.raises(ValueError):
            string_params_to_dict(string)

    def test_invalid_input_4(self):
        string = "startDate==asdfasdf"
        with pytest.raises(ValueError):
            string_params_to_dict(string)

    def test_value_error_if_many_params_with_spaces(self):
        string = "key1=value1 key2=value2 key3=value3"
        with pytest.raises(ValueError):
            string_params_to_dict(string)
