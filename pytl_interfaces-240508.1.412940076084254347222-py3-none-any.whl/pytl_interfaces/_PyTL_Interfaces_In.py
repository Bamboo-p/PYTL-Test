'''
220907.1 Initial version
220907.2 Some enhancements
230222.2 New optional parameters with default values:
                        PAIRED_WORKFLOW=True
                        INPUT_SCHEMA_MASK=*.*schema*
                        OUTPUT_TEMPLATE_MASK=*.*jinja*
                        OUTPUT_SCHEMA_MASK=*.*schema*
                        GENERATE_REPORT=False
         Support additional filters inside jinja template.
230223.4 New optional parameters with default values:
                        INPUT_FORMAT=CSV (default)
                        INPUT_FORMAT=JSON
                        INPUT_FORMAT=JSONROWS
230224.1 Added JSON validation
230323.3 NICORE-528: Providing __params__ into validate_csv_row
230323.5 NICORE-528: Resolving conflicts between NICORE-133 and NICORE-528
230504.1 NICORE-600: incoming files negative cases parsing enhancement
230509.1 NICORE-603: mitigate issue with not ASCII/UTF-8 encoded files
230512.1 NIBOA-8482: Add additional functions for Validation check for date format & skip header and footer from the source file
230512.2 NIBOA-8482: Mandatory checking of CSV header in case of INPUT_CSV_HEADER == True (default), write header in case of OUTPUT_CSV_HEADER == True (default)
230512.3 NIBOA-8482: INPUT_CSV_HEADER == False (default), for back compatibility
230526.1 EIB-9633: Fixed sequence tail number
230630.1 NICORE-701: Added incoming XML format. Added parameter QUERY_WORKFLOW=. Statuses Model is standartized and described. Code is splitted to separate files.
230721.3 NICORE-701: Deleting records older than DELETE_OLDER_DAYS= (by default 90) days
231017.1 MaximSk: ADCBA-1425: added check on data exist to handle empty input file
231017.2 deniska: ADCBA-1425: mixing with changes of 231017.1 with development branch
231123.1 deniska: PRD-25745: Mitigation Oracle 11 client issue with too long of VARCHAR2 in case of connection to Oracle 19 DB server with latest patches
231225.1 deniska: PRD-25745: Performance optimization
240125.1: Hamza: NICORE-1089: Reading the new schema
240131.1: Hamza: NICORE-1089: Adding execution for all levels
240131.2: Hamza: NICORE-1089: fixing data missing bug
240201.1: Hamza: NICORE-1089: Adding the validation on the row stage
240202.1: Hamza: NICORE-1089: Fixing defects and testing
240318.1 deniska: NICORE-1089: Looking for OUTPUT_RECRD_UID in .../ParmCode[text()=SRN]/../Value for MSR~1546
240319.1 deniska: NICORE-1089: merge with feature/NICORE-1089_dev_240206
240402.1 deniska: NICORE-1313: OUTPUT_TEMPLATE -> TEMPLATE, OUTPUT_TEMPLATE_MASK -> TEMPLATE_MASK
240402.2 deniska: NICORE-1313: merge with feature/NICORE-1089_240319
240403.1 deniska: NICORE-1313: schema node 'var' is renamed into 'vars'
240403.2 deniska: NICORE-1313: TEMPLATE -> INPUT_TEMPLATE, TEMPLATE_MASK -> INPUT_TEMPLATE_MASK
                               added new OUTPUT_TEMPLATE, OUTPUT_TEMPLATE_MASK
240408.1 deniska: NICORE-1313: vars[when][var_name]['source_db'] supports all possible connections
240425.1 deniska: PRD-27149: fixed defect "name 'open_db_connection' is not defined"
240425.2 deniska: PRD-27149: log messages corrected
240425.3 deniska: PRD-27149: fixed defect with multiple output files
240425.4 deniska: PRD-27149: fixed IndexErr0r: not f0und '9F14' in '//ApplicationData'
240508.1 deniska: PRD-27276: Disable checking INPUT_TEMPLATE for QUERY_WORKFLOW
'''
from pathlib import Path
from inspect import stack as inspect__stack
debug_line = lambda: f"{Path((frameinfo:=inspect__stack()[1]).filename).name}:{frameinfo.lineno}:"
print(f"{debug_line()}START\n")

import sys
import os
import jinja2

from pathlib import Path
import pytl_core
import pytl_core.pytl_globals as pytl_globals
import logging
from n0struct import *
import jsonschema

########################################################################################################################
try:
    # Could be imported ONLY if it's run as module
    import_type = "MODULE:"

    import_action = "from ._import_params import __params__, open_db_connection"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from ._import_params import __params__, open_db_connection
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    import_action = "from ._utils import *"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from ._utils import *
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    import_action = "from ._config import *"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from ._config import *
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

except Exception as ex:
    print(f"FA1LED  of {import_action} == {ex}")
    try:
        # Could be imported ONLY if it's run as normal py
        import_type = "NORMAL:"

        import_action = "from _import_params import __params__, open_db_connection"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        from _import_params import __params__, open_db_connection
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

        import_action = "from _utils import *"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        from _utils import *
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

        import_action = "from _config import *"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        from _config import *
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    except Exception as ex:
        print(f"FA2LED  of {import_action} == {ex}")
        raise ex
########################################################################################################################

global_configuration = None
input_schema__vars = {}
vars = {}

########################################################################################################################
def main_in(_config):

    combined_config = {**pytl_globals.config, **__params__}
    try:
        for key, value in combined_config.items():
            n0debug_calc(value, f"combined_config[{key}]")
    except KeyError as ex:
        if ex != key:
            logging.error(f"Mandatory parameter {ex} during generation of {key} is not provided")
        else:
            logging.error(f"Mandatory parameter {ex} is not provided")
        sys.exit(-999)

    if not __params__['INPUT_TEMPLATE'] and not __params__['QUERY_WORKFLOW']:
        logging.error(f"parameter INPUT_TEMPLATE must be provided.")
        sys.exit(-999)

    global global_configuration
    global_configuration = GlobalConfiguration()

### [+][begin] 240125.1-240202.1: Hamza: NICORE-1089
    global input_schema__vars, vars
### [+][end]   240125.1-240202.1: Hamza: NICORE-1089

    batches_seq   = None
    records_seq   = None
    input_schema = {}
    input_schema__transformations = []
    input_schema__remove_columns = []
    json_validator = None                           # INPUT_FORMAT=JSONROWS INPUT_SCHEMA=...
                                                    # INPUT_FORMAT=JSON|XML //jsonschema

    # INPUT_FORMAT=JSONROWS, for other will be redefined
    input_schema__items__transformations = []
    input_schema__validations = {} # to simulate csvschema: {"items": []}

    if __params__['INPUT_FORMAT'] in ("CSV", "XML", "JSON", "FWF"):
        n0debug_calc(__params__['INPUT_SCHEMA'], "__params__['INPUT_SCHEMA']")
        ## input_schema = dict contains complex structure with list of columns and validation rules
        input_schema = n0dict( file=(
                                input_schema__path:=find_file_in_subdirs(
                                    __params__['INPUT_SCHEMA'],
                                    __params__['INPUT_SCHEMA_MASK']
                                )
        ))
        n0debug("input_schema")

        input_schema__transformations = [ [transformation[0], transformation[1], None] for transformation in input_schema.get('transformations', []) ]
        n0debug("input_schema__transformations")

        input_schema__items = input_schema.get('items', [])
        n0debug("input_schema__items")
        if input_schema__items:
        # if __params__['INPUT_FORMAT'] in {"CSV", "FWF"}:
            # for input_schema__item in input_schema__items:
                # n0debug("input_schema__item")
                # for item__transformations in (input_schema__item.get('transformations') or tuple()):
                    # n0debug("item__transformations")
                    # __input_schema__items__transformations = [
                        # (input_schema__item.get('block'), input_schema__item['id'], item__transformations)
                    # ]
            __input_schema__items__transformations = [
                (input_schema__item.get('block'), input_schema__item['id'], item__transformations)
                for input_schema__item in input_schema__items
                for item__transformations in (input_schema__item.get('transformations') or tuple())
            ]
            n0debug("__input_schema__items__transformations")
            if __params__['INPUT_FORMAT'] == "FWF":
                input_schema__items__transformations = {}
                for file_block in ('header', 'footer', 'body'):
                    input_schema__items__transformations[file_block] = [
                        [ transformation[1], transformation[2], None ]  # column_name, lambda_txt, future lambda_code
                        for transformation in __input_schema__items__transformations
                        if transformation[0] == file_block or transformation[0] is None
                    ]
            # if __params__['INPUT_FORMAT'] == "CSV":
            else:
                input_schema__items__transformations = [
                    [ transformation[1], transformation[2], None ]  # column_name, lambda_txt, future lambda_code
                    for transformation in __input_schema__items__transformations
                ]


        input_schema__remove_columns = input_schema.get('remove_columns', [])
        n0debug("input_schema__remove_columns")

### [+][begin] 240125.1-240202.1: Hamza: NICORE-1089
        input_schema__validations = input_schema.get('validations', {})
        n0debug("input_schema__validations")
        # to simulate csvschema:
        # {column_name: validations} -> {"items": {"id":column_name, "validations": validations}}
        input_schema__validations = {
            "items": [
                {"id": column1_name, "validations": validations}
                for column1_name,validations in input_schema__validations.items()
            ]
        }
        n0debug("input_schema__validations")

        input_schema__vars = input_schema.get('vars', {})
        n0debug_calc(input_schema__vars, "global.input_schema__vars")
### [+][end]   240125.1-240202.1: Hamza: NICORE-1089

        if __params__['INPUT_FORMAT'] == "CSV":
            ## all_input_columns = list contains only columns' names [column1_name,..,columnN_name]
            all_input_columns = [item['id'] for item in input_schema['items']]
            ## mandatory_input_columns = list contains only columns' names [column1_name,..,columnN_name]
            #### mandatory_input_columns = [item['id'] for item in input_schema['items'] if item.get('mandatory') == True]
            mandatory_input_columns = input_schema.get('required')
            n0debug("mandatory_input_columns")
            csv_row_format = {
                item['id']: {
                    'mandatory': item.get('offset'),
                    'validations': item.get('validations'),
                    'transformations': item.get('transformations'),
                }
                for item in input_schema['items']
                if not (fwf_block:=item.get('block')) or fwf_block == 'header'
            }
        elif __params__['INPUT_FORMAT'] == "FWF":
            fwf_format = {}
            for fwf_block in ('header', 'body', 'footer'):
                fwf_format[fwf_block] = {
                    item['id']: {
                        'offset': item.get('offset'),
                        'width': item.get('width'),
                        'till': item.get('till'),
                        'validations': item.get('validations'),
                        'transformations': item.get('transformations'),
                    }
                    for item in input_schema['items']
                    if not (_fwf_block:=item.get('block')) or _fwf_block == fwf_block
                }
            n0debug("fwf_format")
        elif __params__['INPUT_FORMAT'] in {"JSON", "XML"}:
            if not (input_schema__axis__xpath:=input_schema.get(__xpath:='//axis/xpath')):
                raise(Exception(f"{__xpath} is not found in '{input_schema__path}'"))

            if (input_schema__jsonschema:=input_schema.get('jsonschema')):
                json_validator = jsonschema.Draft4Validator(schema =
                                    n0dict( file=
                                        find_file_in_subdirs(
                                            input_schema__jsonschema,
                                            __params__['INPUT_SCHEMA_MASK']
                                        )
                                    )
                )
    elif __params__['INPUT_FORMAT'] == "JSONROWS":
        json_validator = jsonschema.Draft4Validator(schema=
                            n0dict( file=(
                                find_file_in_subdirs(
                                    __params__['INPUT_SCHEMA'],
                                    __params__['INPUT_SCHEMA_MASK']
                                )
                            ))
        )
    else:
        raise(Exception(f"{__params__['INPUT_FORMAT']} currently is not supported as input format"))
    n0debug("input_schema")
    n0debug("json_validator")

    ## jinja2_template = Jinja2 template used for output file rendering
    if __params__['INPUT_TEMPLATE']:
        with open(
            find_file_in_subdirs(
                __params__['INPUT_TEMPLATE'],
                __params__['INPUT_TEMPLATE_MASK']
            ),
            "rt"
        ) as in_filehandler:
            jinja2_env = jinja2.Environment()
            jinja2_env.filters["to_date"] = to_date
            jinja2_env.filters["to_currency"] = lambda v, precision=2: round(float(v), precision) if v and (v:=v.replace(',', '').strip()) else None
            jinja2_env.filters["n0debug"] = n0pretty

            n0debug("in_filehandler")
            # jinja2_template = jinja2.Template(in_filehandler.read())
            jinja2_template = jinja2_env.from_string(in_filehandler.read())
    else:
        jinja2_template = None
    n0debug("jinja2_template")

    stg_db_connection = open_db_connection('STG')

    ########################################################################################################################
    ## MAIN loop for all files found in SRC_DIR
    ########################################################################################################################

    # n0debug_calc(__params__, "__params__")

### [+][begin] 240125.1-240202.1: Hamza: NICORE-1089
    update_vars('BEFORE_ALL')
### [+][end]   240125.1-240202.1: Hamza: NICORE-1089

    logging.debug(f"Looking for {__params__['INPUT_FN_MASK']} in {__params__['SRC_DIR']}")
    for file_i,input_file_path in enumerate(
        found_files := [
            found_file
            for found_file in Path(__params__['SRC_DIR']).glob(__params__['INPUT_FN_MASK'])
            if not found_file.name.startswith("$REJECTED$.") and not found_file.name.startswith("$PARTIALLY$.")
        ]
    ):
        logging.info(f"Found INPUT file: {input_file_path}")
        output_file_path = None
        output_report_path = None
        try:
            if __params__['INPUT_FORMAT'] == "CSV":
                ## loaded_data_rows = list with
                ##   dict [{column1_name:row1_column1_value,..,columnN_name:row1_columnN_value},..,{column1_name:rowR_column1_value,..,columnN_name:rowR_columnN_value}]
                ## or
                ##   list [[row1_column1_value,..,row1_columnN_value],..,[rowR_column1_value,..,rowR_columnN_value]]
                ## each list item contains values from corresponding row.
                loaded_data_rows = n0list(
                    load_csv(
                        input_file_path,
                        all_input_columns,
                        delimiter=__params__['DELIMITER'],
                        contains_header = (
                            mandatory_input_columns
                            if __params__['INPUT_CSV_HEADER']
                            else None
                        ),
                        header_is_mandatory = __params__['INPUT_CSV_HEADER'],
                    )
                )
            elif __params__['INPUT_FORMAT'] == "FWF":
                loaded_data_rows = n0list(
                    load_fwf(
                        input_file_path,
                        fwf_format['header'],
                        fwf_format['body'],
                        fwf_format['footer'],
                        validate = False,
                        return_original_row = 'ORIGINAL_RAW_ROW'
                    )
                )
            elif __params__['INPUT_FORMAT'] == "JSONROWS":
                loaded_data_rows = n0list(
                    n0dict(loaded_data_row) for loaded_data_row in load_lines(input_file_path)
                )
            elif __params__['INPUT_FORMAT'] in ("JSON", "XML"):
                loaded_data = n0dict(file=input_file_path)
                loaded_data_rows = loaded_data.get(input_schema['axis/xpath'])
            else:
                raise(Exception(f"{__params__['INPUT_FORMAT']} currently is not supported as input format"))

### [+][begin] 240125.1-240202.1: Hamza: NICORE-1089
            pytl_globals.config['input_file_path'] = input_file_path
            pytl_globals.config['rows'] = loaded_data_rows
            pytl_globals.config['rows_count'] = len(loaded_data_rows)
            update_vars('BEFORE_FILE')
### [+][end]   240125.1-240202.1: Hamza: NICORE-1089

        except UnicodeDecodeError as ex:
            output_msg = "009 - Incoming file contains invalid data"
            if not (loaded_file:=load_file(input_file_path, mode = 'b')).isascii():
                for offset,ch in enumerate(loaded_file):
                    if ch > 127:
                        print(output_msg:=f"009 - Incoming file '{input_file_path.name}' contains invalid data: not ASCII character 0x{ch:02x} at the offset {offset}")
                        break
                logging.error(f"Exception: {output_msg}")

            output_file_path = Path(__params__['DST_DIR']) / __params__['OUTPUT_FN2_MASK'] \
                                                                .format(
                                                                    file_i = f"_{file_i}" if len(found_files) > 1 else "",
                                                                    **__params__
                                                                )
            save_file(
                output_file_path:=unique_file_path(output_file_path, "creation of "),
                output_msg
            )
            logging.debug(f"{output_file_path} is saved")

            os.rename(
                input_file_path,
                new_file_path:=unique_file_path(
                    input_file_path.parent / ("$REJECTED$." + input_file_path.name),
                    "renaming of "
                )
            )
            logging.debug(f"{input_file_path} is renamed into {new_file_path} and skipped")
            continue

        n0debug("loaded_data_rows")

        if not loaded_data_rows:
            logging.debug(f"File {input_file_path} will be skipped due to contains 0 valid records")
        else:
            if not batches_seq:
                batches_seq = pytl_core.PyTL_Sequence(__params__['JOB_NAME']+"_BATCHES", stg_db_connection, 1)
            # if not records_seq:
                # records_seq = pytl_core.PyTL_Sequence(__params__['JOB_NAME']+"_RECORDS", stg_db_connection, 100)
            records_seq = pytl_core.PyTL_Sequence(__params__['JOB_NAME']+"_RECORDS", stg_db_connection, len(loaded_data_rows))

            batch_to_write_into_db = {}
            batch_to_write_into_db['UNIQUE_ID']         = batches_seq.next()
            batch_to_write_into_db['INTERFACE']         = __params__['INTERFACE']
            batch_to_write_into_db['ORG']               = __params__['ORG']
            batch_to_write_into_db['INPUT_FILENAME']    = (INPUT_FILENAME:=input_file_path.name)
            batch_to_write_into_db['INPUT_DATETIME']    = global_configuration.sysdate
            batch_to_write_into_db['INPUT_BATCH_UID']   = __params__['INPUT_BATCH_UID'] or input_file_path.stem
            batch_to_write_into_db['OUTPUT_BATCH_UID']  = __params__['OUTPUT_BATCH_UID'] or batches_seq.current()
            batch_to_write_into_db['TOTALLY_RECORDS']   = 0
            batch_to_write_into_db['VALID_RECORDS']     = 0
            batch_to_write_into_db['FAILED_RECORDS']    = 0
            batch_to_write_into_db['SKIPPED_RECORDS']   = 0
            batch_to_write_into_db['NOWAIT_RECORDS']    = 0
            batch_to_write_into_db['PROCESSED_RECORDS'] = 0
            batch_to_write_into_db['OUTPUT_FILENAME']   = None
            batch_to_write_into_db['OUTPUT_DATETIME']   = None
            batch_to_write_into_db['STATUS_CODE']       = 1
            batch_to_write_into_db['STATUS_DESC']       = "Loaded and saved into DB"
            batch_to_write_into_db['ERROR_MSG']         = ""

            ## Primary parsing
            row_i = None
            records_to_write_into_db = []
            for row_i,row in enumerate(loaded_data_rows):
                n0debug("row_i")
                # n0print(row.to_xpath())

### [+][begin] 240125.1-240202.1: Hamza: NICORE-1089
                pytl_globals.config['row'] = row
                pytl_globals.config['row_i'] = row_i
                update_vars('BEFORE_ROW')
### [+][end]   240125.1-240202.1: Hamza: NICORE-1089

                n0debug_calc(__params__, "__params__")
                n0debug_calc(input_schema__items__transformations, "input_schema__items__transformations")
                if __params__['INPUT_FORMAT'] == "FWF":
                    if row_i == 0:
                        file_block = 'header'
                    elif row_i == pytl_globals.config['rows_count']-1:
                        file_block = 'footer'
                    else:
                        file_block = 'body'
                    # row_format = fwf_format[file_block]
                    __input_schema__items__transformations = input_schema__items__transformations[file_block]
                # if __params__['INPUT_FORMAT'] == "CSV":
                else:
                    # row_format = csv_row_format
                    __input_schema__items__transformations = input_schema__items__transformations


                # Recompile is required, because of vars could be updated
                combined_config = {**pytl_globals.config, **__params__, **vars}

                n0debug("__input_schema__items__transformations")
                for i,transformation in enumerate(__input_schema__items__transformations):
                    n0debug_calc(__input_schema__items__transformations[i], f"__input_schema__items__transformations[{i}]")
                    n0debug_calc(transformation[1].format(**combined_config), "transformation[1].format(**combined_config)")

                    __input_schema__items__transformations[i][2] = eval(
                        "lambda column_name, field_value, row: "
                        + transformation[1].format(**combined_config)
                    )
                n0debug("__input_schema__items__transformations")

                n0debug("input_schema__transformations")
                for i,transformation in enumerate(input_schema__transformations):
                    n0debug_calc(input_schema__transformations[i], f"input_schema__transformations[{i}]")
                    n0debug_calc(transformation[1].format(**combined_config), "transformation[1].format(**combined_config)")

                    input_schema__transformations[i][2] = eval(
                        "lambda column_name, field_value, row: "
                        + transformation[1].format(**combined_config)
                    )
                n0debug("input_schema__transformations")

                if __input_schema__items__transformations or input_schema__transformations:
                    for column_name, transformation_txt, transformation_lambda in __input_schema__items__transformations + input_schema__transformations:
                        n0debug("column_name")
                        n0debug("transformation_txt")
                        row[column_name] = transformation_lambda(column_name, field_value := row.get(column_name), row)

                if input_schema__remove_columns:
                    n0debug("row")
                    for column_name in input_schema__remove_columns:
                        try:
                            row.pop(column_name, None)
                        except:
                            pass

                n0debug("row")
                # n0print(row.to_xpath())

                record_to_write_into_db = {} # 'IN_DATA' is CLOB in DB, so it MUST BE the last in dict in case of insert
                record_to_write_into_db['UNIQUE_ID']        = None
                record_to_write_into_db['BATCH_ID']         = batches_seq.current()
                record_to_write_into_db['INPUT_RECRD_UID']  = row_i+1
                record_to_write_into_db['OUTPUT_RECRD_UID'] = None
                record_to_write_into_db['INPUT_DATETIME']   = date_today()
                record_to_write_into_db['OUTPUT_DATETIME']  = None
                record_to_write_into_db['STATUS_CODE']      = None
                record_to_write_into_db['STATUS_DESC']      = None
                record_to_write_into_db['ERROR_MSG']        = None
                record_to_write_into_db['IN_DATA']          = row   # structure will be converted into json-string
                records_to_write_into_db.append(record_to_write_into_db)

### [+][begin] 240125.1-240202.1: Hamza: NICORE-1089
                pytl_globals.config['row'] = row
                update_vars('BEFORE_ROW_VALIDATION')
### [+][end]   240125.1-240202.1: Hamza: NICORE-1089

            n0debug("records_to_write_into_db")
            n0debug("row_i")
            if row_i is None:
                batch_to_write_into_db['TOTALLY_RECORDS']       = 0
            else:
                batch_to_write_into_db['TOTALLY_RECORDS']       = row_i + 1

            ## Validation
            valid_rows   = []
            n0debug("input_schema")
            ApplicationFile_Number = str(batches_seq.current()).zfill(5)[-5:]
            rows_count = len(records_to_write_into_db)
            for i,record in enumerate(records_to_write_into_db):
                records_to_write_into_db[i]['UNIQUE_ID']        =   records_seq.next()
                records_to_write_into_db[i]['OUTPUT_RECRD_UID'] =   __params__['REGNUMBER_PREFIX'] \
                                                                    + ApplicationFile_Number \
                                                                    + '_' \
                                                                    + str(i+1).zfill(5) \
                                                                    + '_' \
                                                                    + str(records_seq.current())

                validation_result = "VALID"
                failed_validations = {}
                # if __params__['INPUT_FORMAT'] == "CSV":
                if __params__['INPUT_FORMAT'] in ("CSV", "FWF", "XLS"):
                    # n0debug_calc(records_to_write_into_db[i]['IN_DATA'], f"records_to_write_into_db[{i}]['IN_DATA']")
                    n0debug("input_schema")
                    # n0debug_calc({**pytl_globals.config, **__params__, **vars}, "{**pytl_globals.config, **__params__, **vars}")
                    # n0debug("i")
                    # n0debug("rows_count")
                    validation_result, failed_validations = validate_csv_row(
                        input_row:=records_to_write_into_db[i]['IN_DATA'],
                        csv_schema = input_schema,
### [*][begin] 240125.1-240202.1: Hamza: NICORE-1089
                        external_variables = {**pytl_globals.config, **__params__, **vars},
### [*][end]   240125.1-240202.1: Hamza: NICORE-1089
                        row_i = i,
                        rows_count = rows_count,
                    )
                    n0debug("input_row")
                if json_validator:
                    for error in json_validator.iter_errors(input_row:=records_to_write_into_db[i]['IN_DATA']):
                        if error.json_path and len(error.json_path) > 1:
                            xpath = error.json_path[1:].replace('.', '/')
                        else:
                            xpath = None
                        if xpath not in failed_validations:
                            failed_validations[xpath] = []
                        if error.validator == "type":
                            failed_validations[xpath].append(f"{xpath}=='{error.instance}' is not type of '{error.validator_value}'")
                        elif error.validator == "required":
                            failed_validations[xpath].append(f"{error.json_path[1:].replace('.', '/')} is a required property")
                        else:
                            failed_validations[xpath].append(f"{error.validator}: {error.message}")

### [+][begin] 240125.1-240202.1: Hamza: NICORE-1089
                n0debug_calc(input_schema__validations, "input_schema__validations")
                if input_schema__validations and validation_result == "VALID":
                    validation_result, failed_validations = validate_csv_row(
                        input_row:=records_to_write_into_db[i]['IN_DATA'],
                        csv_schema = input_schema__validations,
                        external_variables = {**pytl_globals.config, **__params__, **vars},
                        row_i = i,
                        rows_count = rows_count,
                    )
### [+][end]   240125.1-240202.1: Hamza: NICORE-1089

                if validation_result == "REJECT":
                    n0debug("failed_validations")
                    records_to_write_into_db[i]['STATUS_CODE']      = -1
                    records_to_write_into_db[i]['STATUS_DESC']      = "Rejected during primary validation"
                    records_to_write_into_db[i]['ERROR_MSG']        = ";".join([  # Concatenated msg related to all columns
                                                                        ";".join(  # Concatenated msg related to single column
                                                                            list_of_failed_msg # Failed validations are already in the list
                                                                            if isinstance(
                                                                                list_of_failed_msg:=failed_validations[failed_column_name],
                                                                                (list,tuple)
                                                                            )
                                                                            else [list_of_failed_msg] # If just only single validation is failed -> convert into the list
                                                                        ) for failed_column_name in failed_validations
                    ])
                    batch_to_write_into_db['FAILED_RECORDS']    += 1
                elif validation_result == "VALID":
                    if __params__['QUERY_WORKFLOW']:
                        records_to_write_into_db[i]['STATUS_CODE']      = 3
                        records_to_write_into_db[i]['STATUS_DESC']      = "Validated, awaiting for query"
                    else:
                        records_to_write_into_db[i]['STATUS_CODE']      = 10
                        records_to_write_into_db[i]['STATUS_DESC']      = "Exported, awaiting for response"
                    records_to_write_into_db[i]['ERROR_MSG']            = ""
                    batch_to_write_into_db['VALID_RECORDS']     += 1
                    valid_rows.append(records_to_write_into_db[i])
                elif validation_result == "NOWAIT":
                    records_to_write_into_db[i]['STATUS_CODE']          = 601
                    records_to_write_into_db[i]['STATUS_DESC']          = "Validated, not expected response"
                    records_to_write_into_db[i]['ERROR_MSG']            = ""
                    batch_to_write_into_db['NOWAIT_RECORDS']    += 1
                    valid_rows.append(records_to_write_into_db[i])
                elif validation_result == "SKIP":
                    records_to_write_into_db[i]['STATUS_CODE']          = 602
                    records_to_write_into_db[i]['STATUS_DESC']          = "Skipped"
                    records_to_write_into_db[i]['ERROR_MSG']            = ""
                    batch_to_write_into_db['SKIPPED_RECORDS']   += 1

                records_to_write_into_db[i]['OUTPUT_DATETIME']  = date_today()

### [+][begin] 240125.1-240202.1: Hamza: NICORE-1089
                pytl_globals.config['row'] = {**(row or {}), **(records_to_write_into_db[i] or {})}
                update_vars('AFTER_ROW')
### [+][end]   240125.1-240202.1: Hamza: NICORE-1089

            if not batch_to_write_into_db['VALID_RECORDS']:
                ## If no valid records in batch, generate report
                n0debug("valid_rows")
                # All records are failed with validations so generate report immediately
                for i,record_to_write_into_db in enumerate(records_to_write_into_db):
                    records_to_write_into_db[i]['STATUS_CODE']      = -900
                    records_to_write_into_db[i]['STATUS_DESC']      = "All records were rejected during primary validation, report is generated"
                batch_to_write_into_db['STATUS_CODE']           = -905
                batch_to_write_into_db['STATUS_DESC']           = "All records were rejected during primary validation, is report generated"
            else:
                n0debug("batch_to_write_into_db")

                if __params__['PAIRED_WORKFLOW']:
                    if not batch_to_write_into_db['FAILED_RECORDS']:
                        batch_to_write_into_db['STATUS_CODE']           = 11
                        batch_to_write_into_db['STATUS_DESC']           = "All records were successfully validated, exported, awaiting all responses"
                    else:
                        batch_to_write_into_db['STATUS_CODE']           = 12
                        batch_to_write_into_db['STATUS_DESC']           = "Not all records were successfully validated, exported, awaiting all responses"
                elif __params__['QUERY_WORKFLOW']:
                    if not batch_to_write_into_db['FAILED_RECORDS']:
                        batch_to_write_into_db['STATUS_CODE']           = 5
                        batch_to_write_into_db['STATUS_DESC']           = "All records were successfully validated, awaiting query"
                    else:
                        batch_to_write_into_db['STATUS_CODE']           = 6
                        batch_to_write_into_db['STATUS_DESC']           = "Not all records were successfully validated, awaiting query"

                if not __params__['INPUT_TEMPLATE']:
                    if not __params__['QUERY_WORKFLOW']:
                        logging.error(f"{batch_to_write_into_db['VALID_RECORDS']} rows were processed successfully, but parameter INPUT_TEMPLATE is not defined. So no output file will be saved.")
                else:
                    logging.info(f"{batch_to_write_into_db['VALID_RECORDS']} records will be extracted into OUTPUT file")
                    save_file(
                                output_file_path := unique_file_path(
                                                        Path(__params__['W4C_IN_DIR']) /
                                                        __params__['OUTPUT_FN_MASK'].format(
                                                                ApplicationFile_Number = ApplicationFile_Number,
                                                                **__params__
                                                        )
                                                    )
                                ,
                                jinja2_template.render(
                                    timestamp               = date_timestamp(global_configuration.sysdate).replace('_', ''),
                                    sysdate_dash_yyyymmdd   = date_dash_yyyymmdd(global_configuration.sysdate),
                                    systime_colon_hhmmss    = time_colon_hhmmss(global_configuration.sysdate),
                                    ORG                     = __params__['ORG'],
                                    ApplicationFile_Number  = ApplicationFile_Number,
                                    input_file_rows         = valid_rows
                                )
                    )
                    logging.info(f"OUTPUT file is saved into '{output_file_path}'")


            if not batch_to_write_into_db['VALID_RECORDS'] or __params__['GENERATE_REPORT']:
                if not __params__['OUTPUT_SCHEMA']:
                    if not batch_to_write_into_db['VALID_RECORDS']:
                        logging.error(f"No rows were processed successfully, but parameter OUTPUT_SCHEMA is not defined. So no OUTPUT report file will be saved.")
                    else:
                        logging.info(f"{batch_to_write_into_db['VALID_RECORDS']} rows were processed successfully, parameter GENERATE_REPORT is defined, but parameter OUTPUT_SCHEMA is not defined. So no OUTPUT report file will be saved.")
                else:
                    batch_to_write_into_db['OUTPUT_DATETIME'] = date_today()
                    batch_to_write_into_db['OUTPUT_FILENAME'] = __params__['OUTPUT_FN2_MASK'] \
                                                                    .format(
                                                                        file_i = f"_{file_i}" if len(found_files) > 1 else "",
                                                                        **__params__
                                                                    )
                    output_report_path = unique_file_path(
                        Path(__params__['DST_DIR']) / batch_to_write_into_db['OUTPUT_FILENAME'],
                        "creation of "
                    )
                    n0debug("output_report_path")
                    if not __params__['OUTPUT_TEMPLATE']:
                        generate_csv(
                                    global_configuration.construct_csv(records_to_write_into_db),
                                    '[*]',
                                    save_to=output_report_path,
                                    show_header=__params__['WRITE_HEADER'],
                                    delimiter=__params__['DELIMITER'],
                        )
                    else:
                        with open(
                            find_file_in_subdirs(
                                __params__['OUTPUT_TEMPLATE'],
                                __params__['OUTPUT_TEMPLATE_MASK']
                            ),
                            "rt"
                        ) as in_filehandler:
                            jinja2_env = jinja2.Environment()
                            jinja2_env.filters["to_date"] = to_date
                            jinja2_env.filters["to_currency"] = lambda v, precision=2: round(float(v), precision) if v and (v:=v.replace(',', '').strip()) else None
                            jinja2_env.filters["n0debug"] = n0pretty

                            n0debug("in_filehandler")
                            # jinja2_template = jinja2.Template(in_filehandler.read())
                            jinja2_template = jinja2_env.from_string(in_filehandler.read())
                        save_file(
                                    output_report_path,
                                    jinja2_template.render(
                                        timestamp               = date_timestamp(global_configuration.sysdate).replace('_', ''),
                                        sysdate_dash_yyyymmdd   = date_dash_yyyymmdd(global_configuration.sysdate),
                                        systime_colon_hhmmss    = time_colon_hhmmss(global_configuration.sysdate),
                                        ORG                     = __params__['ORG'],
                                        ApplicationFile_Number  = ApplicationFile_Number,
                                        input_file_rows         = records_to_write_into_db
                                    )
                        )
                    logging.info(f"REPORT file is saved into '{output_report_path}'")
                    logging.debug(f"File received as {input_file_path} and responded as {output_report_path}'")

            if __params__['PAIRED_WORKFLOW'] or __params__['QUERY_WORKFLOW']:
                n0debug("batch_to_write_into_db")
                if batch_to_write_into_db:
                    stg_db_connection.execute_insert_batch(
                        table_name='PyTL_Interfaces_Batches',
                        data=[batch_to_write_into_db],
                        commit=True
                    )

                n0debug("records_to_write_into_db")
                if records_to_write_into_db:
                    # Convert struct into json before writing into DB
                    for i,record_to_write_into_db in enumerate(records_to_write_into_db):
                        # records_to_write_into_db[i].pop('OUTPUT_DATETIME', None)
                        # records_to_write_into_db[i].pop('ERROR_MSG', None)
                        records_to_write_into_db[i]['IN_DATA'] = n0dict(records_to_write_into_db[i]['IN_DATA']).to_json(compress=True)

                    stg_db_connection.execute_insert_batch(
                        table_name='PyTL_Interfaces_Records',
                        data=records_to_write_into_db,
                        commit=True
                    )
                    logging.info(f"{len(records_to_write_into_db)} processed records are saved inside DB")

        input_file_path.unlink()
        logging.info(f"Input file '{input_file_path}' is deleted")

### [+][begin] 240125.1-240202.1: Hamza: NICORE-1089
        try:
            pytl_globals.config.pop('row', None)
        except:
            pass
        pytl_globals.config['rows'] = records_to_write_into_db
        pytl_globals.config['batch'] = batch_to_write_into_db
        pytl_globals.config['output_file_path'] = output_file_path
        pytl_globals.config['output_report_path'] = output_report_path
        update_vars('AFTER_FILE')

    try:
        pytl_globals.config.pop('rows', None)
        pytl_globals.config.pop('batch', None)
        pytl_globals.config.pop('output_file_path', None)
        pytl_globals.config.pop('output_report_path', None)
    except:
        pass
    update_vars('AFTER_ALL')
### [+][end]   240125.1-240202.1: Hamza: NICORE-1089

    ########################################################################################################################
    ## End of MAIN loop
    ########################################################################################################################

    # Deleted old records from STG tables
    stg_db_connection.execute_statement_or_anonym_block(
        "delete from stg_etl.PyTL_Interfaces_Records t where t.INPUT_DATETIME < (sysdate - :DELETE_OLDER_DAYS)",
        bind_vars={"DELETE_OLDER_DAYS": int(__params__['DELETE_OLDER_DAYS'])}
    )
    stg_db_connection.execute_statement_or_anonym_block(
        "delete from stg_etl.PyTL_Interfaces_Batches t where t.INPUT_DATETIME < (sysdate - :DELETE_OLDER_DAYS)",
        bind_vars={"DELETE_OLDER_DAYS": int(__params__['DELETE_OLDER_DAYS'])}
    )
    stg_db_connection.commit()

    stg_db_connection.close()

########################################################################################################################
### [+][begin] 240125.1-240202.1: Hamza: NICORE-1089
def update_vars(stage:str):
    if stage not in (possible_stages:=(
        'BEFORE_ALL',
        'BEFORE_FILE',
        'BEFORE_ROW',                       # Before transformation
        'BEFORE_ROW_VALIDATION',            # After transformation, before validation
        'AFTER_ROW',                        # After validation
        'AFTER_FILE',
        'AFTER_ALL',
    )):
        raise Exception(f"Unknown stage {stage}, expected {possible_stages}")

    global input_schema__vars, vars
    global global_configuration

    input_schema__vars_for_current_level = sorted(input_schema__vars.get(stage, {}).items(), key=lambda key_value_pair: key_value_pair[1].get("order", 0))
    combined_config = {**pytl_globals.config, **__params__, **vars}

    # Synonyms which could be used in lambda's
    input_file_path = combined_config.get('input_file_path')
    row = combined_config.get('row')
    row_i = combined_config.get('row_i')
    rows = combined_config.get('rows')

    ###############################

    for var_name, var_properties in input_schema__vars_for_current_level:
        # if not var_properties.get("lambda"):
            # logging.debug(f"Var {var_name} will be skipped due to missing 'lambda' property")
            # continue

        var_value = -112358

        # CSV file parsing
        if var_property_load_csv:=var_properties.get("load_csv"):
            columns = eval(var_properties.get("column_names", "None"))
            if columns and not isinstance(columns,(list, tuple)):
                columns = [columns]
            var_value = n0list(
                load_csv(
                    find_file_in_subdirs(var_property_load_csv, ''),
                    column_names=columns,
                    contains_header=columns,
                    header_is_mandatory=True
                )
            )
            vars.update({var_name: var_value})
            n0debug_calc(var_value, var_name)

        # SQL parsing
        elif var_property_sql_query:=var_properties.get("sql_query"):
            if not (var_property_source_db:=var_properties.get("source_db")):
                raise SyntaxError(f"'source_db' property is missed for var {var_name} with existence of 'sql_query' property")

            db_connection = open_db_connection(var_property_source_db)
            # if var_property_source_db != "STG":
                # raise NotImplementedError(f"Var {var_name} will be skipped due to source_db={var_property_source_db} is not supported for now")

            if var_property_sql_query.startswith('@'):
                var_property_sql_query = pytl_core.utils.load_statement_from_file(find_file_in_subdirs(var_property_sql_query[1:], ''))
            #####################################################
            # Execute the query
            #####################################################
            sql_result = db_connection.execute_select(var_property_sql_query.format(**combined_config))
            var_value = sql_result.get('data', [])
            vars.update({var_name: var_value})
            n0debug_calc(var_value, var_name)

        # Lambda Execution
        if var_property_lambda:=var_properties.get("lambda"):
            combined_config = {**combined_config, **vars}
            var_property_lambda_txt = var_property_lambda.format(**combined_config)
            n0debug("var_property_lambda_txt")
            var_value = eval(var_property_lambda_txt)
            vars.update({var_name: var_value})
            n0debug_calc(var_value, var_name)

        if var_value == -112358:
            raise Exception(f" no load_csv|sql_query|lambda properties found for variable {load_csv}")

    return vars
### [+][end] 240125.1-240202.1: Hamza: NICORE-1089
########################################################################################################################
