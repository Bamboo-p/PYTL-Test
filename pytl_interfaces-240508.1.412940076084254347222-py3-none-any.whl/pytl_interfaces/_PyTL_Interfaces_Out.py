from pathlib import Path
from inspect import stack as inspect__stack
debug_line = lambda: f"{Path((frameinfo:=inspect__stack()[1]).filename).name}:{frameinfo.lineno}:"
print(f"{debug_line()}START")

import sys
import os
import jinja2

from pathlib import Path
import pytl_core
import pytl_core.pytl_globals as pytl_globals
import logging
from n0struct import *
import jsonschema

########################################################################################################################
try:
    # Could be imported ONLY if it's run as module
    import_type = "MODULE:"

    import_action = "from ._import_params import __params__, open_db_connection"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from ._import_params import __params__, open_db_connection
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    import_action = "from ._utils import *"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from ._utils import *
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    import_action = "from ._config import *"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from ._config import *
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

except Exception as ex:
    print(f"FA1LED  of {import_action} == {ex}")
    try:
        # Could be imported ONLY if it's run as normal py
        import_type = "NORMAL:"

        import_action = "from _import_params import __params__, open_db_connection"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        from _import_params import __params__, open_db_connection
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

        import_action = "from _utils import *"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        from _utils import *
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

        import_action = "from _config import *"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        from _config import *
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    except Exception as ex:
        print(f"FA2LED  of {import_action} == {ex}")
        raise ex
########################################################################################################################
LOCKED_BY = None
stg_db_connection = None
def fetch_not_more(sql_statement: str, bind_var: str, record_ids: list, key: str = None, max_len_of_group: int = 4000) -> list:
    global LOCKED_BY
    global_configuration = GlobalConfiguration()

    groupes_record_ids = []
    group_record_ids = ""
    for record_id in record_ids or tuple():
        if len(group_record_ids) + 1 + len(record_id) > max_len_of_group: # Mitigation of limitation of Oracle 11 client
            groupes_record_ids.append(group_record_ids)
            group_record_ids = ""
        if record_id:
            group_record_ids = f"{group_record_ids}{',' if group_record_ids else ''}{record_id}"
    # to prevent cases when no items in record_ids or the latest item(s) is(are) empty string(s)
    if group_record_ids:
        groupes_record_ids.append(group_record_ids)
    n0debug('groupes_record_ids')

    bind_vars = {
        'LOCK_BY': LOCKED_BY,
    }

    fetched_records_from_db = []
    len_group_record_ids = None
    for group_record_ids in groupes_record_ids:
        if bind_var:
            bind_vars.update({bind_var: group_record_ids})

            len_group_record_ids = group_record_ids.count(',')+1
            n0debug("len_group_record_ids")
            logging.info(f"Expected to extract {len_group_record_ids} row")

        fetched_group_from_db = stg_db_connection.execute_select(
                sql_statement,
                bind_vars
            )['data']
        len_fetched_group_from_db = len(fetched_group_from_db)
        n0debug("len_fetched_group_from_db")

        if len_group_record_ids and len_group_record_ids != len_fetched_group_from_db:
            raise Exception(f"Expected to fetch {len_group_record_ids}, but fetched {len_fetched_group_from_db} rows")

        fetched_records_from_db.extend(fetched_group_from_db)

    n0debug_calc(len(fetched_records_from_db), "fetched_records_from_db")

    if key:
        fetched_records_from_db = {
            itm[key]: itm
            for itm in fetched_records_from_db
        }
    n0debug_calc(len(fetched_records_from_db), "fetched_records_from_db")

    return fetched_records_from_db

########################################################################################################################
def main_out(_config):
    global LOCKED_BY
    LOCKED_BY     = __params__['INTERFACE'] + '_' + date_timestamp()

    global_configuration = GlobalConfiguration()
    set_debug_show_object_type(True)
    set_debug_show_item_count(True)

    global stg_db_connection
    stg_db_connection = open_db_connection('STG')

    ########################################################################################################################
    ## MAIN loop for all files found in W4C_OUT_DIR
    ########################################################################################################################
    logging.debug("*********************************************************************************")
    logging.debug(f"*** Looking for {__params__['INPUT_FN_MASK']} in {__params__['W4C_OUT_DIR']}")
    logging.debug("*********************************************************************************")
    for file_i,input_file_path in enumerate(
        found_files := [
            found_file
            for found_file in Path(__params__['W4C_OUT_DIR']).glob(__params__['INPUT_FN_MASK'])
            if not found_file.name.startswith("$REJECTED$.") and not found_file.name.startswith("$PARTIALLY$.")
        ]
    ):
        logging.info(f"Found INPUT file: {input_file_path}")

        try:
            response_xml = n0dict(file=input_file_path)
        except Exception as ex:
            logging.error(f"{input_file_path} is not correct XML file")
            continue

        # n0debug_calc(pytl_core.mask_control_m_string(str(response_xml)), f"Loaded {input_file_path}")
        n0debug_calc(len(response_xml), f"Loaded {input_file_path}")

        csv_rows = []
        rows_matchs = []

        # ##################################################################################################################
        xpath = f"{global_configuration.match_schema['axis/xpath']}/{global_configuration.match_schema['axis/match']}"
        n0debug("xpath")
        record_ids_from_file = response_xml.get(xpath)
        n0debug("record_ids_from_file")

        if not record_ids_from_file:
            n0error(f"{record_ids_from_file=} is empty")
            sys.exit(-999)
        else:
            if not isinstance(record_ids_from_file, (list, tuple)):
                record_ids_from_file = [record_ids_from_file]
            record_ids_from_file = [record_id_from_file[0] if isinstance(record_id_from_file, (list, tuple)) and len(record_id_from_file) == 1 else record_id_from_file for record_id_from_file in record_ids_from_file]
        n0debug("record_ids_from_file")

        logging.debug(f"Got {record_ids_from_file=}")

        saved_records_inside_db = fetch_not_more(
                            """
                            select
                                *
                            from
                                table(
                                    PyTL_Interfaces_Utils.get_and_lock_pytl_interfaces_records(
                                        :LOCK_BY,
                                        :OUTPUT_RECRD_UID_LIST
                                    )
                                )
                            """,
                            'OUTPUT_RECRD_UID_LIST',
                            record_ids_from_file,
                            'OUTPUT_RECRD_UID'
        )
        n0debug_calc(len(saved_records_inside_db), "saved_records_inside_db")

        if len(saved_records_inside_db) != len(record_ids_from_file):
            # We have received ID from file, which doesn't exist in DB
            found_ids_inside_db = saved_records_inside_db.keys()
            n0debug("found_ids_inside_db")
            not_found_ids = set(record_ids_from_file) - set(found_ids_inside_db)
            n0debug("not_found_ids")

            if not len(saved_records_inside_db):
                # No one IDs from file exists in DB
                os.rename(
                    input_file_path,
                    new_file_path:=unique_file_path(
                        input_file_path.parent / ("$REJECTED$." + input_file_path.name),
                        "renaming of "
                    )
                )
                logging.error(f"*** No any records with ID {list(not_found_ids)} from file is found inside DB: {input_file_path} was renamed into {new_file_path}")
                continue
            else:
                # Some of IDs from file doens't exist in DB
                os.rename(
                    input_file_path,
                    new_file_path:=unique_file_path(
                        input_file_path.parent / ("$PARTIALLY$." + input_file_path.name),
                        "renaming of "
                    )
                )
                logging.error(f"*** Records with ID {list(not_found_ids)} from file are not found inside DB: {input_file_path} was renamed into {new_file_path}")
        # ##################################################################################################################
        batch_ids_from_db = set(itm['BATCH_ID'] for itm in saved_records_inside_db.values())
        n0debug("batch_ids_from_db")

        saved_batches_inside_db = fetch_not_more(
                            """
                            select
                                *
                            from
                                table(
                                    PyTL_Interfaces_Utils.get_and_lock_pytl_interfaces_batches(
                                        :LOCK_BY,
                                        :BATCH_ID_LIST
                                    )
                                )
                            """,
                            'BATCH_ID_LIST',
                            batch_ids_from_db,
                            'UNIQUE_ID'
        )
        n0debug("saved_batches_inside_db")

        # ##################################################################################################################
        for item_from_file in response_xml.get(global_configuration.match_schema['axis/xpath']):
            # n0debug("item_from_file")
            OUTPUT_RECRD_UID = item_from_file[global_configuration.match_schema['axis/match']]
            if isinstance(OUTPUT_RECRD_UID, (list, tuple)) and len(OUTPUT_RECRD_UID) == 1:
                OUTPUT_RECRD_UID = OUTPUT_RECRD_UID[0]
            n0debug("OUTPUT_RECRD_UID")

            if OUTPUT_RECRD_UID not in saved_records_inside_db:
                raise LookupError(f"{OUTPUT_RECRD_UID} from file in not found in DB ({saved_records_inside_db.keys()})")

            saved_records_inside_db[OUTPUT_RECRD_UID]['OUT_DATA']    = item_from_file.to_json(compress=True)
            if (STATUS_CODE:=int(saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_CODE'])) == 10:
                saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_CODE'] = 20
                saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_DESC'] = "Response is recevied"
            else:
                saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_CODE'] = 24
                saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_DESC'] = ( "Unexpected STATUS_CODE" \
                    f" {STATUS_CODE}: {saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_DESC']}" \
                    " + response is recevied" )[:255]

            BATCH_ID = saved_records_inside_db[OUTPUT_RECRD_UID]['BATCH_ID']
            if BATCH_ID not in saved_batches_inside_db:
                raise LookupError(f"{BATCH_ID} from file in not found in DB ({saved_batches_inside_db.keys()})")

            saved_batches_inside_db[BATCH_ID]['PROCESSED_RECORDS'] = int(saved_batches_inside_db[BATCH_ID]['PROCESSED_RECORDS']) + 1

            if (STATUS_CODE:=int(saved_batches_inside_db[BATCH_ID]['STATUS_CODE'])) == 11:
                saved_batches_inside_db[BATCH_ID]['STATUS_CODE'] = 21
                saved_batches_inside_db[BATCH_ID]['STATUS_DESC'] = "All records were successfully validated, some responses are received"
            elif STATUS_CODE == 12:
                saved_batches_inside_db[BATCH_ID]['STATUS_CODE'] = 22
                saved_batches_inside_db[BATCH_ID]['STATUS_DESC'] = "Not all records were successfully validated, some responses are received"
            elif STATUS_CODE in (21, 22, 23):
                # Nothing to do -- all statuses are already changed
                pass
            else:
                # raise ValueError(f"Not expected STATUS_CODE in {saved_batches_inside_db[BATCH_ID]}, expected 11, 21, 12, 22")
                saved_batches_inside_db[BATCH_ID]['STATUS_CODE'] = 23
                saved_batches_inside_db[BATCH_ID]['STATUS_DESC'] = ( "Unexpected STATUS_CODE" \
                    f" {STATUS_CODE}: {saved_batches_inside_db[BATCH_ID]['STATUS_DESC']}" \
                    " + some responses are received" )[:255]

        stg_db_connection.execute_update_batch(
            table_name='PyTL_Interfaces_Batches',
            data=(data_to_save:=list(saved_batches_inside_db.values())),
            conditions={'UNIQUE_ID':'$CURRENT$'},
            commit=True
        )
        n0debug_calc(data_to_save, "saved_batches_inside_db")

        stg_db_connection.execute_update_batch(
            table_name='PyTL_Interfaces_Records',
            data=(data_to_save:=list(saved_records_inside_db.values())),
            conditions={'UNIQUE_ID':'$CURRENT$'},
            commit=True
        )
        # n0debug("data_to_save")
        n0debug_calc(len(data_to_save), "saved_batches_inside_db")

        # n0debug("saved_batches_inside_db")
        # n0debug_calc(len(saved_records_inside_db), "saved_records_inside_db")
        # n0debug("saved_records_inside_db")

        if input_file_path.exists():
            input_file_path.unlink()
            logging.debug(f"*** File {input_file_path} is DELETED.")

    ########################################################################################################################
    ## End of MAIN loop
    ########################################################################################################################
    logging.info("*********************************************************************************")
    logging.info("*** Check for the batches, which are ready to return back")
    logging.info("*********************************************************************************")

    saved_batches_inside_db = {
        itm['UNIQUE_ID']: itm
        for itm in stg_db_connection.execute_select(
                                    """
                                    select
                                        *
                                    from table(
                                            PyTL_Interfaces_Utils.get_and_lock_pytl_interfaces_batches(
                                                :LOCK_BY
                                            )
                                    )
                                    """,
                                    {
                                        'LOCK_BY': LOCKED_BY
                                        # Second parameter BATCH_ID_LIST is not defined, so fetch completed batches, but not returned back:
                                        #      STATUS_CODE >= 20 and t1.STATUS_CODE < 100
                                        #      TOTALLY_RECORDS > 0
                                        #      PROCESSED_RECORDS = (t1.TOTALLY_RECORDS - t1.FAILED_RECORDS - t1.NOWAIT_RECORDS - t1.SKIPPED_RECORDS)
                                    }
        )['data']
    }
    n0debug("saved_batches_inside_db")

    if saved_batches_inside_db:
        for saved_batch_inside_db_i,UNIQUE_ID in enumerate(saved_batches_inside_db):
            saved_records_inside_db = {
                itm['OUTPUT_RECRD_UID']: itm
                for itm in stg_db_connection.execute_select(
                                            """
                                            select
                                                *
                                            from
                                                table(
                                                    PyTL_Interfaces_Utils.get_and_lock_pytl_interfaces_records(
                                                        :LOCK_BY,
                                                        NULL,
                                                        :BATCH_ID
                                                    )
                                                )
                                            """,
                                            {
                                                'LOCK_BY': LOCKED_BY,
                                                # Second parameter OUTPUT_RECRD_UID_LIST is not defined, so fetch records by BATCH_ID
                                                'BATCH_ID': int(UNIQUE_ID)
                                            }
                )['data']
            }
            n0debug_calc(len(saved_records_inside_db), "saved_records_inside_db")

            if int(saved_batches_inside_db[UNIQUE_ID]['TOTALLY_RECORDS']) != len(saved_records_inside_db):
                raise ValueError("Check locked records." \
                    f" Expected {saved_batches_inside_db[UNIQUE_ID]['TOTALLY_RECORDS']}" \
                    f" in batch {UNIQUE_ID}" \
                    f", but got {len(saved_records_inside_db)} records"
                )

            if int(saved_batches_inside_db[UNIQUE_ID]['STATUS_CODE']) == 21:
                saved_batches_inside_db[UNIQUE_ID]['STATUS_DESC'] = "All records were successfully validated, all responses were received, report is generated"
                saved_batches_inside_db[UNIQUE_ID]['STATUS_CODE'] = 901
            elif int(saved_batches_inside_db[UNIQUE_ID]['STATUS_CODE']) == 22:
                saved_batches_inside_db[UNIQUE_ID]['STATUS_DESC'] = "Not all records were successfully validated, all responses were received, report is generated"
                saved_batches_inside_db[UNIQUE_ID]['STATUS_CODE'] = 902
            else:
                saved_batches_inside_db[UNIQUE_ID]['STATUS_DESC'] = ( "Unexpected STATUS_CODE" \
                    f" {saved_batches_inside_db[UNIQUE_ID]['STATUS_CODE']}: {saved_batches_inside_db[UNIQUE_ID]['STATUS_DESC']}" \
                    " + report is generated" )[:255]
                saved_batches_inside_db[UNIQUE_ID]['STATUS_CODE'] = 903

            saved_batches_inside_db[UNIQUE_ID]['OUTPUT_FILENAME'] = \
                __params__['OUTPUT_FN_MASK'].format(
                                                ApplicationFile_Number = \
                                                    f"_{saved_batch_inside_db_i}" \
                                                    if len(saved_batches_inside_db) > 1 \
                                                    else ""
                                                ,
                                                **__params__
                )

            for OUTPUT_RECRD_UID in saved_records_inside_db:
                if int(saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_CODE']) == 20:
                    saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_DESC'] = "Response was received, report is generated"
                    saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_CODE'] = 900
                else:
                    saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_DESC'] = ( "Unexpected STATUS_CODE" \
                        f" {saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_CODE']}:" \
                        f" {saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_DESC']}" \
                        " + report is generated" )[:255]
                    saved_records_inside_db[OUTPUT_RECRD_UID]['STATUS_CODE'] = 904

            stg_db_connection.execute_update_batch(
                table_name='PyTL_Interfaces_Records',
                data=list(saved_records_inside_db.values()),
                conditions={'UNIQUE_ID': '$CURRENT$'},
                commit=True
            )
            n0debug_calc(len(saved_records_inside_db), "saved_records_inside_db")

            stg_db_connection.execute_update_batch(
                table_name='PyTL_Interfaces_Batches',
                data=[saved_batches_inside_db[UNIQUE_ID]],
                conditions={'UNIQUE_ID': '$CURRENT$'},
                commit=True
            )
            n0debug_calc(saved_batches_inside_db[UNIQUE_ID], f"saved_batches_inside_db[{UNIQUE_ID}]")

            ## ######################################################################################
            ## Save report file
            ## ######################################################################################
            Path(__params__['DST_DIR']).mkdir(parents=True, exist_ok=True)
            output_file_path = unique_file_path(
                Path(__params__['DST_DIR']) / saved_batches_inside_db[UNIQUE_ID]['OUTPUT_FILENAME'],
                "creation of "
            )
            n0debug("output_file_path")
            if not __params__['OUTPUT_TEMPLATE']:
                generate_csv(
                            global_configuration.construct_csv(saved_records_inside_db.values()),
                            '[*]',
                            save_to=output_file_path,
                            show_header=__params__['WRITE_HEADER'],
                            delimiter=__params__['DELIMITER'],
                )
            else:
                with open(
                    find_file_in_subdirs(
                        __params__['OUTPUT_TEMPLATE'],
                        __params__['OUTPUT_TEMPLATE_MASK']
                    ),
                    "rt"
                ) as in_filehandler:
                    jinja2_env = jinja2.Environment()
                    jinja2_env.filters["to_date"] = to_date
                    jinja2_env.filters["to_currency"] = lambda v, precision=2: round(float(v), precision) if v and (v:=v.replace(',', '').strip()) else None
                    jinja2_env.filters["n0debug"] = n0pretty

                    n0debug("in_filehandler")
                    # jinja2_template = jinja2.Template(in_filehandler.read())
                    jinja2_template = jinja2_env.from_string(in_filehandler.read())
                save_file(
                            output_file_path,
                            jinja2_template.render(
                                timestamp               = date_timestamp(global_configuration.sysdate).replace('_', ''),
                                sysdate_dash_yyyymmdd   = date_dash_yyyymmdd(global_configuration.sysdate),
                                systime_colon_hhmmss    = time_colon_hhmmss(global_configuration.sysdate),
                                ORG                     = __params__['ORG'],
                                ApplicationFile_Number  = ApplicationFile_Number,
                                input_file_rows         = saved_records_inside_db.values()
                            )
                )
            logging.info(f"REPORT file is saved into '{output_file_path}'")
            logging.debug(f"File received as {saved_batches_inside_db[UNIQUE_ID]['INPUT_FILENAME']} and responded as {output_file_path}'")
         ## ######################################################################################

    stg_db_connection.execute_stored_procedure(
        "PyTL_Interfaces_Utils.unlock_pytl_interfaces_batches",
        {'UNLOCK_LOCKED_BY': LOCKED_BY}
    )
    stg_db_connection.execute_stored_procedure(
        "PyTL_Interfaces_Utils.unlock_pytl_interfaces_records",
        {'UNLOCK_LOCKED_BY': LOCKED_BY}
    )
    stg_db_connection.close()

