from pathlib import Path
from inspect import stack as inspect__stack
debug_line = lambda: f"{Path((frameinfo:=inspect__stack()[1]).filename).name}:{frameinfo.lineno}:"
print(f"{debug_line()}START")

__version__ = "240508.1"
__job_name__ = "PyTL_Interfaces"
__bat_files__ = ["PyTL_Interfaces_In.bat", "PyTL_Interfaces_Out.bat"]

print(f"{debug_line()}{__file__=}")
print(f"{debug_line()}{__version__=}")
print(f"{debug_line()}{__job_name__=}")
print(f"{debug_line()}{__bat_files__=}")
