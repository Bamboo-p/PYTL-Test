from pathlib import Path
from inspect import stack as inspect__stack
debug_line = lambda: f"{Path((frameinfo:=inspect__stack()[1]).filename).name}:{frameinfo.lineno}:"
print(f"{debug_line()}START")

from pathlib import Path
import pytl_core
import pytl_core.pytl_globals as pytl_globals
import logging
from n0struct import *

########################################################################################################################
try:
    # Could be imported ONLY if it's run as module
    import_type = "MODULE:"
    import_action = f"{debug_line()} from ._import_params import *"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    # from ._import_params import *
    from ._import_params import  __job_name__, __version__
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")
    
    import_action = f"{debug_line()}MODULE: from ._PyTL_Interfaces_In import main_in"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from ._PyTL_Interfaces_In import main_in
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")
    
    import_action = f"{debug_line()}MODULE: from ._PyTL_Interfaces_Out import main_out"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from ._PyTL_Interfaces_Out import main_out
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")
    
except Exception as ex:
    print(f"FA1LED  of {import_action} == {ex}")
    try:
        # Could be imported ONLY if it's run as normal py
        import_type = "NORMAL:"
        import_action = f"{debug_line()}from _import_params import __job_name__, __version__"
        # print(f"{debug_line()}{dir()}")
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        # from _import_params import *
        from _import_params import __job_name__, __version__
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")
        # print(f"{debug_line()}{dir()}")
        
        import_action = f"{debug_line()}from _PyTL_Interfaces_In import main_in"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        from _PyTL_Interfaces_In import main_in
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        import_action = f"{debug_line()}from _PyTL_Interfaces_Out import main_out"
        from _PyTL_Interfaces_Out import main_out
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    except Exception as ex:
        print(f"FA2LED  of {import_action} == {ex}")
        raise ex
########################################################################################################################

print("*"*10 + f" {__name__}: {__job_name__} v{__version__}")
if __name__ == "__main__":
    config = pytl_globals.config = pytl_core.Config.configure_pytl_core({'JOB_FILE': __file__, 'JOB_NAME': __job_name__})
    logging.debug(f"Config: initialization finished, variable 'pytl_globals.config' is created.")

    '''
    n0debug_calc(pytl_globals.config.get('P_REPORT_DATE'))
    n0debug_calc(date_today())
    n0debug_calc(__params__['INPUT_DATE_FORMAT'], "__params__['INPUT_DATE_FORMAT']")
    n0debug_calc(date_to_format(date_today(), __params__['INPUT_DATE_FORMAT']), f"date_to_format({date_today()}, {__params__['INPUT_DATE_FORMAT']})")

    try:
        for config_name in config:
            is_defined = config[config_name]
            n0debug_calc(is_defined, f"config[{config_name}]")
    except KeyError as ex:
        print(f"Mandatory parameter {ex} was not defined")
        sys.exit(-1)
    except Exception as ex:
        n0debug("ex")
        raise ex

    try:
        for param_name in __params__:
            is_defined = __params__[param_name]
            n0debug_calc(is_defined, f"__params__[{param_name}]")
    except KeyError as ex:
        print(f"Mandatory parameter {ex} was not defined")
        sys.exit(-1)
    except Exception as ex:
        n0debug("ex")
        raise ex
    '''

    try:
        if config.get('LOCK_FILE'):
            config['LOCK_FILE'] = Path(config['LOCK_FILE'])
            config['LOCK_FILE'].parent.mkdir(parents=True, exist_ok=True)
            config['LOCK_FILE'].unlink(missing_ok=True)
            with open(config['LOCK_FILE'], 'wt') as fh:
                logging.debug(f"Lock file '{config['LOCK_FILE']}' is created.")
                fh.write(config['JOB_FILE'])
        pytl_core.logger.org_logging_info(f"******* {__file__}@{__job_name__} v{__version__} is STARTED")
        logging.info("*"*10 + f" execute main(config)")
        if config.get('DIRECTION') == "OUT":
            logging.info("*"*10 + f" execute main_out(config)")
            main_out(config)
        else:
            logging.info("*"*10 + f" execute main_in(config)")
            main_in(config)
        pytl_core.logger.org_logging_info(f"******* {__file__}@{__job_name__} v{__version__} is COMPLETED")
    except Exception as ex:
        # it doesn't catch BaseException or the system-exiting exceptions SystemExit, KeyboardInterrupt and GeneratorExit
        print(ex.message, ex.args)
    except:
        # it catches all other exceptions: BaseException or the system-exiting exceptions SystemExit, KeyboardInterrupt and GeneratorExit
        pass
    if config.get('LOCK_FILE'):
        logging.debug(f"Lock file '{config['LOCK_FILE']}' is deleted.")
        config['LOCK_FILE'].unlink(missing_ok=True)
