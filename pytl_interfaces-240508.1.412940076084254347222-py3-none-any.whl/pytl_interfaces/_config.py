from pathlib import Path
from inspect import stack as inspect__stack
debug_line = lambda: f"{Path((frameinfo:=inspect__stack()[1]).filename).name}:{frameinfo.lineno}:"
print(f"{debug_line()}START")

import os
import glob

from pathlib import Path
from n0struct import (
    # validate_values,
    # validate_bool,
    # date_to_format,
    date_today,
    # date_julian,
    # to_date,
    n0debug,
    n0debug_calc,
    n0dict,
)
import pytl_core
from cx_Oracle import LOB as cx_Oracle__LOB

########################################################################################################################
try:
    # Could be imported ONLY if it's run as module
    import_type = "MODULE:"

    # import_action = f"{debug_line()}from ._import_params import *"
    # print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    # from ._import_params import *
    # print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    import_action = "from ._import_params import __params__"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from ._import_params import __params__
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    import_action = "from ._utils import *"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from ._utils import *
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

except Exception as ex:
    print(f"FA1LED  of {import_action} == {ex}")
    try:
        # Could be imported ONLY if it's run as normal py
        import_type = "NORMAL:"

        # import_action = f"{debug_line()}from _import_params import *"
        # print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        # from _import_params import *
        # print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

        import_action = "from _import_params import __params__"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        from _import_params import __params__
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

        import_action = "from _utils import *"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        from _utils import *
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    except Exception as ex:
        print(f"FA2LED  of {import_action} == {ex}")
        raise ex
########################################################################################################################
class GlobalConfiguration:
    sysdate = None
    match_schema = None
    match_schema__validations = None
    match_schema__transformations = None
########################################################################################################################
########################################################################################################################
    def __init__(self):
        ## DB connection and common variables initialization
        self.sysdate       = date_today()

        ## match_schema = dict contains complex structure with rules of parsing, transformation and mapping for destination CSV
        if __params__['OUTPUT_SCHEMA']:
            self.match_schema = n0dict(file=find_file_in_subdirs(__params__['OUTPUT_SCHEMA'], __params__['OUTPUT_SCHEMA_MASK']))
            # n0debug("match_schema")

            ## Compile validations
            self.match_schema__validations = self.match_schema.get('validations', tuple())
            for column_name in self.match_schema__validations:
                for i,validation in enumerate(self.match_schema__validations[column_name]):
                    self.match_schema__validations[column_name][i].append(eval("lambda column_name, field_value, row: " + validation[0]))
                    self.match_schema__validations[column_name][i].append(eval("lambda column_name, field_value, row: " + validation[1]))
            n0debug_calc(self.match_schema__validations, "self.match_schema__validations")

            ## Compile transformations
            self.match_schema__transformations = self.match_schema.get('transform', tuple())
            for column_name in self.match_schema__transformations:
                for i,transformation in enumerate(self.match_schema__transformations[column_name]):
                    self.match_schema__transformations[column_name][i].append(eval("lambda column_name, field_value, row: " + (transformation[0] if transformation[0] else "True")))
                    self.match_schema__transformations[column_name][i].append(eval("lambda column_name, field_value, row: " + transformation[1]))
            n0debug_calc(self.match_schema__transformations, "self.match_schema__transformations")

        (n0debug_calc(__params__[key], key) for key in __params__)

    def construct_csv(self, data_list: list) -> list:
        ##global sysdate, db_connection, match_schema, match_schema__validations, match_schema__transformations

        # n0debug_calc(validation[0], f"Validation condition for {column_name}")
        # n0debug("data_list")

        match_schema__mapping = self.match_schema['mapping']
        csv_rows = []

        match_schema__remove_columns = self.match_schema.get('remove_columns', []) + ['$VALIDATION$']

        for found_j,data_item in enumerate(data_list):
            if 'IN_DATA' in data_item:
                if isinstance(data_item['IN_DATA'], cx_Oracle__LOB):
                    _out_data = ''.join(data_item['IN_DATA'].read())
                else:
                    _out_data = data_item['IN_DATA']
                if _out_data:
                    data_item['IN_DATA']  = n0dict(_out_data)
                else:
                    data_item['IN_DATA']  = n0dict()
            if 'OUT_DATA' in data_item:
                if isinstance(data_item['OUT_DATA'], cx_Oracle__LOB):
                    _out_data = ''.join(data_item['OUT_DATA'].read())
                else:
                    _out_data = data_item['OUT_DATA']
                if _out_data:
                    data_item['OUT_DATA']  = n0dict(_out_data)
                else:
                    data_item['OUT_DATA']  = n0dict()
            if not isinstance(data_item, n0dict):
                data_item = n0dict(data_item)
            n0debug("data_item")

            csv_row = {}
            ## Copying to destination structure
            for column_name in match_schema__mapping:
                # n0debug("column_name")
                if not (xpath:=match_schema__mapping[column_name]):
                    field_value = None
                else:
                    ## field_value = data_item.get(xpath)
                    # column_xpath_value = data_item.findfirst(
                    column_xpath_value = data_item.findall(
                        xpath,
                        raise_exception=False,
                    )
                    n0debug("xpath")
                    n0debug("column_xpath_value")
                    if column_xpath_value:
                        field_value = list(column_xpath_value.values())[0]
                    else:
                        field_value = None
                    n0debug("field_value")

                csv_row.update({column_name: field_value})
            csv_row.update({'$VALIDATION$': ""})
            # n0debug("csv_row")

            ## Validations
            n0debug("csv_row")
            for column_name in csv_row:
                if column_name in self.match_schema__validations:
                    for validation in self.match_schema__validations[column_name]:
                        n0debug("column_name")
                        field_value = csv_row[column_name]
                        n0debug("field_value")
                        n0debug_calc(validation[0], f"Validation condition for {column_name}")
                        n0debug_calc(validation[2](column_name, field_value, csv_row), f"Result of '{validation[0]}'")
                        if not validation[2](column_name, field_value, csv_row):
                            n0debug_calc(validation[1], f"Message for not valid {column_name}")
                            n0debug_calc(validation[3](column_name, field_value, csv_row), f"Result of '{validation[1]}'")
                            if csv_row['$VALIDATION$']:
                                csv_row['$VALIDATION$'] += ";"
                            csv_row['$VALIDATION$'] += str(validation[3](column_name, field_value, csv_row))

            ## Transformations
            n0debug("csv_row")
            for column_name in csv_row:
                if column_name in self.match_schema__transformations:
                    for transformation in self.match_schema__transformations[column_name]:
                        n0debug("column_name")
                        field_value = csv_row[column_name]
                        n0debug("field_value")
                        n0debug_calc(transformation[0], f"Transformation condition for {column_name}")
                        n0debug_calc(transformation[2](column_name, field_value, csv_row), f"Result of '{transformation[0]}'")
                        if transformation[2](column_name, field_value, csv_row):
                            # n0debug_calc(transformation[1], f"Transformation for {column_name}")
                            # n0debug_calc(transformation[3](column_name, field_value, csv_row), f"Result of '{transformation[1]}'")
                            csv_row[column_name] = transformation[3](column_name, field_value, csv_row)
                            break
            n0debug("csv_row")

            ## Removing redaundant columns
            for column_name in match_schema__remove_columns:
                if column_name in csv_row:
                    del csv_row[column_name]
            # n0debug("csv_row")

            csv_rows.append(csv_row)

        n0debug_calc(csv_rows, "csv_rows (after construction)")
        return csv_rows
########################################################################################################################
