from pathlib import Path
from inspect import stack as inspect__stack
debug_line = lambda: f"{Path((frameinfo:=inspect__stack()[1]).filename).name}:{frameinfo.lineno}:"
print(f"{debug_line()}START")
    
########################################################################################################################
try:
    # Could be imported ONLY if it's run as module
    import_type = "MODULE:"
    
    import_action = "from . import __job_name__"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from . import __job_name__
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")
    
    import_action = "from importlib_metadata import version as importlib_metadata_version"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from importlib_metadata import version as importlib_metadata_version
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")
    
    import_action = "__version__ = importlib_metadata_version(__job_name__)"
    print(f"{debug_line()}{import_type}EXECUTE of {import_action}")
    __version__ = importlib_metadata_version(__job_name__)
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    import_action = "from ._params import __params__, open_db_connection"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    from ._params import __params__, open_db_connection
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")
    
except Exception as ex:
    print(f"FA1LED  of {import_action} == {ex}")
    try:
        # Could be imported ONLY if it's run as normal py
        import_type = "NORMAL:"
        
        import_action = "from __init__ import __job_name__, __version__"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        from __init__ import __job_name__, __version__
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

        import_action = "from _params import __params__, open_db_connection"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        from _params import __params__, open_db_connection
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")
        
    except Exception as ex:
        print(f"FA2LED  of {import_action} == {ex}")
        raise ex
########################################################################################################################
