from pytl_core import (
    Params as pytl_Params,
    pytl_globals,
    Connection as pytl_core__Connection,
)
from n0struct import (
    validate_values,
    validate_bool,
    date_to_format,
    date_today,
    date_julian,
    to_date,
    date_timestamp,
    n0debug,
    n0debug_calc,
)

__params__ = pytl_Params({
# ******************************************************************************
# Common for In/Out job
# ******************************************************************************
# Precalculated values
        # "DB_STG_SRC_WLTURL":    lambda: pytl_globals.config["DB_STG_SRC_WLTURL"],   # Parameters from file, mentioned in pytl_globals.config["ENV"]
        "JOB_NAME":             lambda: pytl_globals.config["JOB_NAME"],            # It's Defined in __main__.py
        "SCHEMAS_DIR":          lambda: pytl_globals.config["SCHEMAS_DIR"],         # By default it's defined in pytl_config.py

        "INPUT_DATE_FORMAT":    lambda: pytl_globals.config.get('INPUT_DATE_FORMAT')    or "%Y-%m-%d %H:%M:%S",
        "OUTPUT_DATE_FORMAT":   lambda: pytl_globals.config.get('OUTPUT_DATE_FORMAT')   or "%Y%m%d%H%M%S",
        "P_REPORT_DATE":        lambda: pytl_globals.config.get('P_REPORT_DATE')        or date_to_format(date_today(), __params__['INPUT_DATE_FORMAT']),
# MANDATORY
        "ENV":                  lambda: pytl_globals.config['ENV'],
        "INTERFACE":            lambda: pytl_globals.config['INTERFACE'],
        "DIRECTION":            lambda: validate_values((pytl_globals.config.get('DIRECTION') or '').upper(), ("OUT", "IN")),
        "ORG":                  lambda: pytl_globals.config['ORG'],
# ******************************************************************************
# Parameters from file .parm file defined in pytl_globals.config['ENV']
        'DB_CONNECTIONS':       lambda: {
                                            db_source_synonym_name: db_connection_string
                                            for db_source_synonym_name,db_source_var_name in CONNECTION_SYNONYMS
                                            if (db_connection_string:=pytl_globals.config.get(db_source_var_name))
                                        },
# Optional
        "DELETE_OLDER_DAYS":    lambda: pytl_globals.config.get('DELETE_OLDER_DAYS') or 90,
        "INPUT_BATCH_UID":      lambda: pytl_globals.config.get('INPUT_BATCH_UID'),     # Used to synchronize imported file and query
        "OUTPUT_BATCH_UID":     lambda: pytl_globals.config.get('OUTPUT_BATCH_UID'),    # Used to synchronize imported file and query
        "INPUT_FORMAT":         lambda: validate_values(
                                                        (pytl_globals.config.get('INPUT_FORMAT') or '').upper(),
                                                        (
                                                            "XLSX",
                                                            "XLS",
                                                            "XML",
                                                            "JSON",
                                                            "JSONROWS",
                                                            "FWF",
                                                            "CSV",
                                                        )
                                        ),
        "INPUT_SCHEMA":         lambda: (
                                            pytl_globals.config.get(
                                                'INPUT_SCHEMA',
                                                pytl_globals.config.get('OUTPUT_SCHEMA')  # for back compartibility
                                            )
                                        ) if __params__['DIRECTION'] == "IN"
                                        else (
                                            pytl_globals.config.get('INPUT_SCHEMA')
                                        ),
        "INPUT_SCHEMA_MASK":    lambda: "*.*schema*"
                                        if not (__INPUT_SCHEMA_MASK := pytl_globals.config.get("INPUT_SCHEMA_MASK"))
                                        else (__INPUT_SCHEMA_MASK if __INPUT_SCHEMA_MASK != '.' else ""),
        "OUTPUT_FORMAT":        lambda: validate_values(
                                                        (pytl_globals.config.get('OUTPUT_FORMAT') or '').upper(),
                                                        (
                                                            "XLSX",
                                                            "XLS",
                                                            "XML",
                                                            "JSON",
                                                            "JSONROWS",
                                                            "FWF",
                                                            "CSV"
                                                        )
                                        ),
        "INPUT_FN_PREFIX":      lambda: (
                                            ""                  # IN
                                            if __params__['DIRECTION'] == "IN"
                                            else "RXADVAPL"     # OUT
                                        )
                                        if not (__INPUT_FN_PREFIX := pytl_globals.config.get("INPUT_FN_PREFIX"))
                                        else (__INPUT_FN_PREFIX if __INPUT_FN_PREFIX != '.' else ""),
        "INPUT_FN_SEPARATOR":   lambda: ""
                                        if not (__INPUT_FN_SEPARATOR := pytl_globals.config.get("INPUT_FN_SEPARATOR"))
                                        else (__INPUT_FN_SEPARATOR if __INPUT_FN_SEPARATOR != '.' else ""),
        "INPUT_FN_EXTENSION":   lambda: (
                                            ".csv"              # IN
                                            if __params__['DIRECTION'] == "IN"
                                            else ".*"           # OUT
                                        )
                                        if not (__INPUT_FN_EXTENSION := pytl_globals.config.get("INPUT_FN_EXTENSION"))
                                        else (__INPUT_FN_EXTENSION if __INPUT_FN_EXTENSION != '.' else ""),
        "INPUT_FN_MASK":        lambda: (
                                    (
                                        # IN
                                        __params__['INPUT_FN_PREFIX'] +
                                        __params__['INPUT_FN_SEPARATOR'] +
                                        "*" +
                                        __params__['INPUT_FN_EXTENSION']
                                    ) if __params__['DIRECTION'] == "IN"
                                    else (
                                        # OUT
                                        __params__['INPUT_FN_PREFIX'] +
                                        __params__['INPUT_FN_SEPARATOR'] +
                                        "*" +
                                        __params__['INPUT_FN_EXTENSION']
                                    )
                                    if not (__INPUT_FN_MASK := pytl_globals.config.get("INPUT_FN_MASK"))
                                    else (__INPUT_FN_MASK if __INPUT_FN_MASK != '.' else "")
                                ),
# ------------------------------------------------------------------------------
        "OUTPUT_FN_PREFIX":     lambda: (
                                            "XADVAPL"           # IN
                                            if __params__['DIRECTION'] == "IN"
                                            else "RESPONSE"     # OUT
                                        )
                                        if not (__OUTPUT_FN_PREFIX := pytl_globals.config.get("OUTPUT_FN_PREFIX"))
                                        else (__OUTPUT_FN_PREFIX if __OUTPUT_FN_PREFIX != '.' else ""),
        "OUTPUT_FN_SEPARATOR":  lambda: "_"
                                        if not (__OUTPUT_FN_SEPARATOR := pytl_globals.config.get("OUTPUT_FN_SEPARATOR"))
                                        else (__OUTPUT_FN_SEPARATOR if __OUTPUT_FN_SEPARATOR != '.' else ""),
        "OUTPUT_FN_SUFIX":       (
                                    lambda: (
                                                (
                                                    ""
                                                    if __params__['DIRECTION'] == "IN"
                                                    else date_to_format(
                                                            to_date(__params__['P_REPORT_DATE'], __params__['INPUT_DATE_FORMAT']),
                                                            __params__['OUTPUT_DATE_FORMAT']
                                                         )
                                                )
                                                + "{ApplicationFile_Number}" # IN  == ApplicationFile_Number == str(batches_seq.current()).zfill(5)[-5:]
                                                                             # OUT == # of processed batch (for example '_0'), if it's not only one
                                            )
                                            if not (__OUTPUT_FN_SUFIX := pytl_globals.config.get("OUTPUT_FN_SUFIX"))
                                            else (__OUTPUT_FN_SUFIX if __OUTPUT_FN_SUFIX != '.' else "")
                                    ,
                                    True # Don't cache and recalculate each usage
                                ),
        "OUTPUT_FN_EXTENSION":  lambda: (
                                            "." + date_julian(to_date(__params__['P_REPORT_DATE'], __params__['INPUT_DATE_FORMAT'])) # IN
                                            if __params__['DIRECTION'] == "IN"
                                            else
                                            ".csv"              # OUT
                                        )
                                        if not (__OUTPUT_FN_EXTENSION := pytl_globals.config.get("OUTPUT_FN_EXTENSION"))
                                        else (__OUTPUT_FN_EXTENSION if __OUTPUT_FN_EXTENSION != '.' else ""),
        "OUTPUT_FN_MASK":       (
                                    lambda: (
                                        (
                                            # IN
                                            __params__['OUTPUT_FN_PREFIX'] +
                                            __params__['OUTPUT_FN_SEPARATOR'] +
                                            __params__['OUTPUT_FN_SUFIX'] +
                                            __params__['OUTPUT_FN_EXTENSION']
                                        ) if __params__['DIRECTION'] == "IN"
                                        else (
                                            # OUT
                                            __params__['OUTPUT_FN_PREFIX'] +
                                            __params__['OUTPUT_FN_SEPARATOR'] +
                                            __params__['OUTPUT_FN_SUFIX'] +
                                            __params__['OUTPUT_FN_EXTENSION']
                                        )
                                        if not (__OUTPUT_FN_MASK := pytl_globals.config.get("OUTPUT_FN_MASK"))
                                        else (__OUTPUT_FN_MASK if __OUTPUT_FN_MASK != '.' else "")
                                    ),
                                    True # Don't cache and recalculate each usage because of '{}' is inside OUTPUT_FN_MASK
                                ),
# ------------------------------------------------------------------------------
        "WRITE_HEADER":         lambda: validate_bool(pytl_globals.config.get('WRITE_HEADER') or True, True),
        "INPUT_CSV_HEADER":     lambda: validate_bool(pytl_globals.config.get('INPUT_CSV_HEADER') or False, False),
        "OUTPUT_CSV_HEADER":    lambda: validate_bool(pytl_globals.config.get('OUTPUT_CSV_HEADER') or True, True),
        "DELIMITER":            lambda: pytl_globals.config.get('DELIMITER') or "|",
# ------------------------------------------------------------------------------
        "PAIRED_WORKFLOW":      lambda: validate_bool(pytl_globals.config.get('PAIRED_WORKFLOW') or True, True),
        "QUERY_WORKFLOW":       lambda: validate_bool(pytl_globals.config.get('QUERY_WORKFLOW') or False, False),
        "GENERATE_REPORT":      lambda: validate_bool(pytl_globals.config.get('GENERATE_REPORT') or False, False),
# ******************************************************************************
# In job: Client -> PyTL -> W4
# ******************************************************************************
# Precalculated values
        "TEMPLATES_DIR":        lambda: pytl_globals.config["TEMPLATES_DIR"],       # By default it's defined in pytl_config.py
        "SRC_DIR":              lambda: pytl_globals.config["SRC_DIR"],             # By default it's defined in pytl_config.py
        "W4C_IN_DIR":           lambda: pytl_globals.config["W4C_IN_DIR"],          # By default it's defined in pytl_config.py
# MANDATORY
        "INPUT_SCHEMA":         lambda: pytl_globals.config['INPUT_SCHEMA']
                                        if __params__['DIRECTION'] == "IN"
                                        else pytl_globals.config.get('INPUT_SCHEMA'),
        "INPUT_SCHEMA_MASK":    lambda: "*.*schema*"
                                        if not (__INPUT_SCHEMA_MASK := pytl_globals.config.get("INPUT_SCHEMA_MASK"))
                                        else (__INPUT_SCHEMA_MASK if __INPUT_SCHEMA_MASK != '.' else ""),
        "INPUT_TEMPLATE":       lambda: pytl_globals.config.get('INPUT_TEMPLATE', pytl_globals.config.get('TEMPLATE', pytl_globals.config.get('OUTPUT_TEMPLATE'))),
        "INPUT_TEMPLATE_MASK":  lambda: "*.*jinja*"
                                        if not (__INPUT_TEMPLATE_MASK := pytl_globals.config.get("INPUT_TEMPLATE_MASK"))
                                        else (__INPUT_TEMPLATE_MASK if __INPUT_TEMPLATE_MASK != '.' else ""),
# Optional
        "OUTPUT_SCHEMA":        lambda: pytl_globals.config.get('OUTPUT_SCHEMA'),
        "OUTPUT_SCHEMA_MASK":   lambda: "*.*schema*"
                                        if not (__OUTPUT_SCHEMA_MASK := pytl_globals.config.get("OUTPUT_SCHEMA_MASK"))
                                        else (__OUTPUT_SCHEMA_MASK if __OUTPUT_SCHEMA_MASK != '.' else ""),
        "OUTPUT_TEMPLATE":      lambda: pytl_globals.config.get('OUTPUT_TEMPLATE')
                                        if pytl_globals.config.get('INPUT_TEMPLATE') or pytl_globals.config.get('TEMPLATE')
                                        else None,  # for back compartibility
        "OUTPUT_TEMPLATE_MASK": lambda: "*.*jinja*"
                                        if not (__OUTPUT_TEMPLATE_MASK := pytl_globals.config.get("OUTPUT_TEMPLATE_MASK"))
                                        else (__OUTPUT_TEMPLATE_MASK if __OUTPUT_TEMPLATE_MASK != '.' else ""),
# ------------------------------------------------------------------------------
        "REGNUMBER_PREFIX":     lambda: pytl_globals.config.get("REGNUMBER_PREFIX", ""),
# ------------------------------------------------------------------------------
# OUTPUT_FN2_* are used for negative response in case of all records are rejected
        "OUTPUT_FN2_PREFIX":    lambda: (
                                            "RESPONSE"      # IN
                                            if __params__['DIRECTION'] == "IN"
                                            else
                                            "$NOT$USED$"    # OUT
                                        )
                                        if not (__OUTPUT_FN2_PREFIX := pytl_globals.config.get("OUTPUT_FN2_PREFIX"))
                                        else (__OUTPUT_FN2_PREFIX if __OUTPUT_FN2_PREFIX != '.' else ""),
        "OUTPUT_FN2_SEPARATOR": lambda: "_"
                                        if not (__OUTPUT_FN2_SEPARATOR := pytl_globals.config.get("OUTPUT_FN2_SEPARATOR"))
                                        else (__OUTPUT_FN2_SEPARATOR if __OUTPUT_FN2_SEPARATOR != '.' else ""),

        "OUTPUT_FN2_SUFIX":     (  # IN  == of processed batch (for example '_0'), if it's not only one
                                    lambda: (
                                                date_to_format(
                                                        to_date(__params__['P_REPORT_DATE'], __params__['INPUT_DATE_FORMAT']),
                                                        __params__['OUTPUT_DATE_FORMAT'],
                                                )
                                                + "{file_i}"
                                            )
                                            if not (__OUTPUT_FN_SUFIX := pytl_globals.config.get("OUTPUT_FN_SUFIX"))
                                            else (__OUTPUT_FN_SUFIX if __OUTPUT_FN_SUFIX != '.' else "")
                                    ,
                                    True # Don't cache and recalculate each usage
                                ),
        "OUTPUT_FN2_EXTENSION": lambda: (
                                            ".csv"          # IN
                                            if __params__['DIRECTION'] == "IN"
                                            else
                                            ".$NOT$USED$"    # OUT
                                        )
                                        if not (__OUTPUT_FN2_EXTENSION := pytl_globals.config.get("OUTPUT_FN2_EXTENSION"))
                                        else (__OUTPUT_FN2_EXTENSION if __OUTPUT_FN2_EXTENSION != '.' else ""),
        "OUTPUT_FN2_MASK":      (
                                    lambda: (
                                        (
                                            # IN
                                            __params__['OUTPUT_FN2_PREFIX'] +
                                            __params__['OUTPUT_FN2_SEPARATOR'] +
                                            __params__['OUTPUT_FN2_SUFIX'] +
                                            __params__['OUTPUT_FN2_EXTENSION']
                                        ) if __params__['DIRECTION'] == "IN"
                                        else (
                                            # OUT
                                            __params__['OUTPUT_FN2_PREFIX'] +
                                            __params__['OUTPUT_FN2_SEPARATOR'] +
                                            __params__['OUTPUT_FN2_SUFIX'] +
                                            __params__['OUTPUT_FN2_EXTENSION']
                                        )
                                        if not (__OUTPUT_FN2_MASK := pytl_globals.config.get("OUTPUT_FN2_MASK"))
                                        else (__OUTPUT_FN2_MASK if __OUTPUT_FN2_MASK != '.' else "")
                                    ),
                                    True # Don't cache and recalculate each usage because of '{}' is inside OUTPUT_FN2_MASK
                                ),
# ******************************************************************************
# Out job: W4 -> PyTL -> Client
# ******************************************************************************
# Precalculated values
        "W4C_OUT_DIR":          lambda: pytl_globals.config["W4C_OUT_DIR"],         # By default it's defined in pytl_config.py
        "DST_DIR":              lambda: pytl_globals.config["DST_DIR"],             # By default it's defined in pytl_config.py
})

########################################################################################################################
CONNECTION_SYNONYMS =(
    ('OWS', 'DB_W4C_TGT_WLTURL'),
    ('OWS', 'DB_W4C_SRC_WLTURL'),
    ('DWH', 'DB_DM_TGT_WLTURL'),
    ('DWH', 'DB_DM_SRC_WLTURL'),
    ('STG', 'DB_STG_TGT_WLTURL'),
    ('STG', 'DB_STG_SRC_WLTURL'),
)
def open_db_connection(source_db: str):
    source_db = validate_values(
        source_db,
        tuple(pytl_globals.config.keys() | dict(CONNECTION_SYNONYMS).keys()) + ('OWS',),
        raise_if_not_found=NotImplementedError(
                                f"Unexpected value '{source_db}' in parameter 'SOURCE_DB'. "
                                "Expected: OWS, DWH, STG or other defined parameters with connectivity string"
                            )
    )
    if source_db not in __params__['DB_CONNECTIONS']:
        __params__['DB_CONNECTIONS'][source_db] = pytl_globals.config[source_db]

    if isinstance(__params__['DB_CONNECTIONS'][source_db], str):
        __params__['DB_CONNECTIONS'][source_db] = pytl_core__Connection(
            __params__['DB_CONNECTIONS'][source_db],
            (pytl_globals.config['INTERCHANGE_JOB_DIR'].lstrip(__params__['JOB_NAME']+"_") or __params__['JOB_NAME']) + " " + date_timestamp()[-6:]
        )

    n0debug_calc(__params__['DB_CONNECTIONS'], "__params__['DB_CONNECTIONS']")
    n0debug_calc(__params__['DB_CONNECTIONS'][source_db], f"__params__['DB_CONNECTIONS']['{source_db}']")
    return __params__['DB_CONNECTIONS'][source_db]
########################################################################################################################
