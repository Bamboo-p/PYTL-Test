from pathlib import Path
from inspect import stack as inspect__stack
debug_line = lambda: f"{Path((frameinfo:=inspect__stack()[1]).filename).name}:{frameinfo.lineno}:"
print(f"{debug_line()}START")

import os
import glob

from pathlib import Path
from n0struct import *
import pytl_core
import pytl_core.pytl_globals as pytl_globals
import logging

########################################################################################################################
try:
    # Could be imported ONLY if it's run as module
    import_type = "MODULE:"
    import_action = f"{debug_line()}from ._import_params import *"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    # from ._import_params import *
    from ._import_params import __params__
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    import_type = "MODULE:"
    import_action = f"{debug_line()}from ._import_params import *"
    print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
    # from ._import_params import *
    from ._import_params import __job_name__
    print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

except Exception as ex:
    print(f"FA1LED  of {import_action} == {ex}")
    try:
        # Could be imported ONLY if it's run as normal py
        import_type = "NORMAL:"
        import_action = f"{debug_line()}from _import_params import *"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        # from _import_params import *
        from _import_params import __params__
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

        import_type = "NORMAL:"
        import_action = f"{debug_line()}from _import_params import *"
        print(f"{debug_line()}{import_type}IMPORT  of {import_action}")
        # from _import_params import *
        from _import_params import __job_name__
        print(f"{debug_line()}{import_type}SUCCESS of {import_action}")

    except Exception as ex:
        print(f"FA1LED  of {import_action} == {ex}")
        raise ex
########################################################################################################################

########################################################################################################################
def find_file_in_subdirs(file_name:str, file_mask:str):
    if os.path.exists(file_name):
        return file_name
    found_files_in_all_directories = sorted(
        list(glob.iglob(
                os.path.abspath(f"{os.path.dirname(os.path.abspath(__file__))}/../{__job_name__}*/**/{file_mask}"),
                recursive=True,
        )), \
        key=os.path.getmtime, reverse=True,
    )
    found_files = {}    # for each found file just only 1 record will be generated,
                        # where key is lower case file name only WITHOUT extention
    for file_fullpath in found_files_in_all_directories:
        if file_fullpath.endswith('~') or file_fullpath.endswith('$'):  # Skip files ends with ~ or $
            continue
        # key is lower case file name only WITHOUT extention
        file_key = os.path.splitext(os.path.basename(file_fullpath.lower()))[0]
        if not file_key in found_files:
            # First found (the mordern one) will be used, other will be ignored
            found_files.update({file_key: file_fullpath})

    file_key = os.path.splitext(os.path.basename(file_name.lower()))[0]
    if not file_key in found_files:
        raise Exception(f"File '{file_name}' is not found")
    return found_files[file_key]
########################################################################################################################
########################################################################################################################
