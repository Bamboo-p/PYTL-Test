create or replace package PyTL_Interfaces_Utils is
--------------------------------------------------------------------------------
-- 220907.3
--------------------------------------------------------------------------------
    type T_PYTL_INTERFACES_BATCHES_TABLE is table of PyTL_Interfaces_Batches%ROWTYPE;
    function get_and_lock_pytl_interfaces_batches(LOCK_BY varchar2, BATCH_ID_LIST varchar2 default NULL) return T_PYTL_INTERFACES_BATCHES_TABLE pipelined;
    procedure unlock_pytl_interfaces_batches(UNLOCK_LOCKED_BY varchar2);

    type T_PYTL_INTERFACES_RECORDS_TABLE is table of PyTL_Interfaces_Records%ROWTYPE;
    function get_and_lock_pytl_interfaces_records(LOCK_BY varchar2, OUTPUT_RECRD_UID_LIST varchar2, WITH_BATCH_ID number default NULL) return T_PYTL_INTERFACES_RECORDS_TABLE pipelined;
    procedure unlock_pytl_interfaces_records(UNLOCK_LOCKED_BY varchar2);

end PyTL_Interfaces_Utils;
/
commit;
/
create or replace package body PyTL_Interfaces_Utils is
--------------------------------------------------------------------------------
-- 220907.3
--------------------------------------------------------------------------------
    function get_and_lock_pytl_interfaces_batches(LOCK_BY varchar2, BATCH_ID_LIST varchar2 default NULL) return T_PYTL_INTERFACES_BATCHES_TABLE pipelined
    as
        pragma autonomous_transaction;
        PYTL_INTERFACES_BATCHES_COLLECTION T_PYTL_INTERFACES_BATCHES_TABLE;
    begin
/*
ORA-01002: fetch out of sequence
*Cause:    This error means that a fetch has been attempted from a cursor
           which is no longer valid.  Note that a PL/SQL cursor loop
           implicitly does fetches, and thus may also cause this error.
           There are a number of possible causes for this error, including:
           1) Fetching from a cursor after the last row has been retrieved
           and the ORA-1403 error returned.
           2) If the cursor has been opened with the FOR UPDATE clause,
           fetching after a COMMIT has been issued will return the error.
           3) Rebinding any placeholders in the SQL statement, then issuing
           a fetch before reexecuting the statement.
*Action:   1) Do not issue a fetch statement after the last row has been
           retrieved - there are no more rows to fetch.
           2) Do not issue a COMMIT inside a fetch loop for a cursor
           that has been opened FOR UPDATE.
           3) Reexecute the statement after rebinding, then attempt to
           fetch again.

update+commit and pipe are not allowed inside the same loop
with cursor 'select ... for update nowait'+'... where current of ROW_CURSOR',
so lets split into the 2 loops: 1) update 2) return row
*/
        if BATCH_ID_LIST is NULL then
            -- Fetch completed batches, but not returned back
            select t1.*
            bulk collect into PYTL_INTERFACES_BATCHES_COLLECTION
            from PyTL_Interfaces_Batches t1
            where
                t1.LOCKED_BY is null
                and t1.STATUS_CODE >= 20 and t1.STATUS_CODE < 100
                and t1.TOTALLY_RECORDS > 0
                and t1.PROCESSED_RECORDS = (t1.TOTALLY_RECORDS - t1.FAILED_RECORDS - t1.NOWAIT_RECORDS - t1.SKIPPED_RECORDS)
            for update of t1.LOCKED_BY skip locked;
        else
            -- Fetch batches by UNIQUE_ID
            select *
            bulk collect into PYTL_INTERFACES_BATCHES_COLLECTION
            from PyTL_Interfaces_Batches t1
            where
                t1.LOCKED_BY is null
                and t1.UNIQUE_ID in (
                    select to_number(regexp_substr(BATCH_ID_LIST, '[^,]+', 1, level)) from dual
                    connect by level <= length(regexp_replace(BATCH_ID_LIST, '[^,]+')) + 1
                )
            for update of t1.LOCKED_BY skip locked;
        end if;

        if PYTL_INTERFACES_BATCHES_COLLECTION.count > 0 then
            /*
            for i in PYTL_INTERFACES_BATCHES_COLLECTION.first .. PYTL_INTERFACES_BATCHES_COLLECTION.last
            -- Temporary disabled for testing purpose
            loop
                update PyTL_Interfaces_Records
                set LOCKED_BY = LOCK_BY
                where UNIQUE_ID = PYTL_INTERFACES_BATCHES_COLLECTION(i).UNIQUE_ID;
            end loop;
            */
            commit;

            for i in PYTL_INTERFACES_BATCHES_COLLECTION.first .. PYTL_INTERFACES_BATCHES_COLLECTION.last
            loop
                -- PYTL_INTERFACES_BATCHES_COLLECTION(i).LOCKED_BY := LOCK_BY;
                pipe row (PYTL_INTERFACES_BATCHES_COLLECTION(i));
            end loop;
        else
            rollback;
        end if;

        return;
    end get_and_lock_pytl_interfaces_batches;
--------------------------------------------------------------------------------
    procedure unlock_pytl_interfaces_batches(UNLOCK_LOCKED_BY varchar2)
    as
        pragma autonomous_transaction;
    begin
        update PyTL_Interfaces_Batches
        set LOCKED_BY = NULL
        where LOCKED_BY = UNLOCK_LOCKED_BY;

        commit;
        return;
    end unlock_pytl_interfaces_batches;
--------------------------------------------------------------------------------
    function get_and_lock_pytl_interfaces_records(LOCK_BY varchar2, OUTPUT_RECRD_UID_LIST varchar2, WITH_BATCH_ID number default NULL) return T_PYTL_INTERFACES_RECORDS_TABLE pipelined
    as
        pragma autonomous_transaction;
        PYTL_INTERFACES_RECORDS_COLLECTION T_PYTL_INTERFACES_RECORDS_TABLE;
    begin
        if WITH_BATCH_ID is NULL then
            -- Fetch records by OUTPUT_RECRD_UID
            select *
            bulk collect into PYTL_INTERFACES_RECORDS_COLLECTION
            from PyTL_Interfaces_Records t1
            where
                t1.LOCKED_BY is null
                and t1.OUTPUT_RECRD_UID in (
                    select regexp_substr(OUTPUT_RECRD_UID_LIST, '[^,]+', 1, level) from dual
                    connect by level <= length(regexp_replace(OUTPUT_RECRD_UID_LIST, '[^,]+')) + 1
                )
            for update of t1.LOCKED_BY skip locked;
        else
            -- Fetch records by BATCH_ID
            select *
            bulk collect into PYTL_INTERFACES_RECORDS_COLLECTION
            from PyTL_Interfaces_Records t1
            where
                t1.LOCKED_BY is null
                and t1.BATCH_ID = WITH_BATCH_ID
            for update of t1.LOCKED_BY skip locked;
        end if;

        if PYTL_INTERFACES_RECORDS_COLLECTION.count > 0 then
            /*
            for i in PYTL_INTERFACES_RECORDS_COLLECTION.first .. PYTL_INTERFACES_RECORDS_COLLECTION.last
            -- Temporary disabled for testing purpose
            loop
                update PyTL_Interfaces_Records
                set LOCKED_BY = LOCK_BY
                where UNIQUE_ID = PYTL_INTERFACES_RECORDS_COLLECTION(i).UNIQUE_ID;
            end loop;
            */
            commit;

            for i in PYTL_INTERFACES_RECORDS_COLLECTION.first .. PYTL_INTERFACES_RECORDS_COLLECTION.last
            loop
                -- PYTL_INTERFACES_RECORDS_COLLECTION(i).LOCKED_BY := LOCK_BY;
                pipe row (PYTL_INTERFACES_RECORDS_COLLECTION(i));
            end loop;
        else
            rollback;
        end if;

        return;
    end get_and_lock_pytl_interfaces_records;
--------------------------------------------------------------------------------
    procedure unlock_pytl_interfaces_records(UNLOCK_LOCKED_BY varchar2)
    as
        pragma autonomous_transaction;
    begin
        update PyTL_Interfaces_Records
        set LOCKED_BY = NULL
        where LOCKED_BY = UNLOCK_LOCKED_BY;

        commit;
        return;
    end unlock_pytl_interfaces_records;
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
end PyTL_Interfaces_Utils;
/
commit;
/
exit;
