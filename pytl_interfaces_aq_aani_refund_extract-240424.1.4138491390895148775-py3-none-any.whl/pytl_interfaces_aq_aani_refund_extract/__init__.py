__version__ = "240424.1"
__job_name__ = "PyTL_Interfaces_AQ_AANI_Refund_Extract"
__bat_files__ = ["PyTL_AQ_AANI_Refund_Extract.bat"]