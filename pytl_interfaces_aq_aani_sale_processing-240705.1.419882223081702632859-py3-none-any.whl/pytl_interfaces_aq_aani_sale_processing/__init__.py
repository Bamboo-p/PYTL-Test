__version__ = "240705.1"
__job_name__ = "PyTL_Interfaces_AQ_AANI_Sale_Processing"
__bat_files__ = []
