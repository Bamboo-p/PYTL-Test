__version__ = "240503.1"
__job_name__ = "PyTL_Interfaces_AQ_BIN_Upload"
__bat_files__ = ["PyTL_AQ_BIN_Upload.bat"]
