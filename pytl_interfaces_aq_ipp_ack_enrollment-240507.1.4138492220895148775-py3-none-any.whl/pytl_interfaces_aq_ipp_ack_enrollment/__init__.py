__version__ = "240507.1"
__job_name__ = "PyTL_Interfaces_AQ_IPP_ACK_ENROLLMENT"
__bat_files__ = []

print("="*70)
print(f"{__file__=}")
print(f"{__version__=}")
print(f"{__job_name__=}")
print(f"{__bat_files__=}")
