__version__ = "240711.1"
__job_name__ = "PyTL_Interfaces_AQ_NPCI_QR_Adjustment_File_Processing"
__bat_files__ = []

print("="*70)
print(f"{__file__=}")
print(f"{__version__=}")
print(f"{__job_name__=}")
print(f"{__bat_files__=}")
