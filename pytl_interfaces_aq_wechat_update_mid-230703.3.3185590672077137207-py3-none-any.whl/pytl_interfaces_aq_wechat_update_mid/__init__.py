__version__ = "230703.3"
__job_name__ = "PyTL_Interfaces_AQ_WeChat_Update_MID"
__bat_files__ = []

print("="*70)
print(f"{__file__=}")
print(f"{__version__=}")
print(f"{__job_name__=}")
print(f"{__bat_files__=}")
