__version__ = "230614.1"
__job_name__ = "PyTL_Interfaces_BULK_CIF_UPDATE"
__bat_files__ = []

print("="*70)
print(f"{__file__=}")
print(f"{__version__=}")
print(f"{__job_name__=}")
print(f"{__bat_files__=}")
