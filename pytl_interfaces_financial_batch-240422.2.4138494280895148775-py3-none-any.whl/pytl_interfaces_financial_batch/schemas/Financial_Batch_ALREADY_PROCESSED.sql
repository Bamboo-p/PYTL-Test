select
    r.in_data.CARD_NUMBER || ';' || r.in_data.TRANS_CODE || ';' || r.in_data.AMOUNT || ';' || r.in_data.DATETIME    as KEY
    ,b.INPUT_DATETIME                                                                                               as INPUT_DATETIME
    ,b.INPUT_FILENAME                                                                                               as INPUT_FILENAME
    ,r.INPUT_RECRD_UID                                                                                              as INPUT_RECRD_UID
    ,r.STATUS_CODE                                                                                                  as STATUS_CODE
    ,r.STATUS_DESC                                                                                                  as STATUS_DESC
from stg_etl.pytl_interfaces_records r
join stg_etl.pytl_interfaces_batches b on b.UNIQUE_ID = r.BATCH_ID
where
    b.INTERFACE = 'Financial_Batch'
    and b.ORG = '{ORG}'
    and r.STATUS_CODE > 0
    and b.INPUT_DATETIME >= SYSDATE - 90
order by
    b.UNIQUE_ID desc
    ,r.UNIQUE_ID asc
