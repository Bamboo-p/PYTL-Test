__version__ = "240301.1"
__job_name__ = "PyTL_Interfaces_ISS_IPP_Transaction_Processing"
__bat_files__ = []

print("="*70)
print(f"{__file__=}")
print(f"{__version__=}")
print(f"{__job_name__=}")
print(f"{__bat_files__=}")
