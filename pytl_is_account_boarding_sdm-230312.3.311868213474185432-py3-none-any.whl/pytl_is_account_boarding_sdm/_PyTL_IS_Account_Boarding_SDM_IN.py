''' NIC_IS_In_Account_Boarding_SDM

The pytl job validates/converts JSON source file to WAY4 XML format in accordance with SDM format

Requirements
------------
    pytl core v2.8


Mandatory parameters
--------------------
ENV
    Specifies path to settings file with database connection and in/out/etc dirs paths.
    Can be an absolute or relative path, or a file name without extension.

ORG
    Parameter that is used in several XML tags like Sender as Financial institution, output file name.
    Must match the value Accounts.Institution from JSON source
    Sample: "092"

Optional parameters
-------------------
OUTPUT_FN_SPACE
    By default '_'
OUTPUT_FN_SEPARATOR
    By default '-'
OUTPUT_FN_PREFIX
    By default 'OLTLCM'+{OUTPUT_FN_SEPARATOR}
OUTPUT_FN_EXTENSION
    By default '.txt'

References
----------
    ENG-2921
    ALMAS-98

Changes
-------
    210915.1 = deniska = ALMAS-98: optional parameter OUTPUT_FN to allow default file prefix 'XADVAPL' change.
    210922.1 = deniska = ALMAS-98: /W4C-Input/XADVAPL??????_?????.???: /ApplicationFile/FileHeader/Sender will be left-padded with '0' till 6 characters.
    210923.1 = deniska = ALMAS-98: Rewritten for unification, according to discussion with TatianaO/MaximS 20/09/2021, PavelP 22/09/2021:
                         Optional parameter OUTPUT_FN renamed into OUTPUT_FN_PREFIX
                         Default values if optional parameters were not set:
                             OUTPUT_FN_PREFIX    == 'XADVAPL'
                         Output file name: {OUTPUT_FN_PREFIX}{ORG.lzeropad(6)}__{DB.TLND_JOB_SUPPORT.getSequenceValue.lzeropad(5)}.{CurrentJulianDay.lzeropad(3)}
    210927.1 = deniska = ENG-3936: If //header/sdm_channel inside incoming json file is empty or not provided, the default value "APPL_FILE" will be used for /ApplicationFile/ApplicationsList/Application/AddData/SDM_CHANNEL.
    220512.6 = deniska = PRD-20670: added ability to process files with correct names, but incorrect content
    221223.1 = deniska = NICORE-126: Excluding usage of legacy dict2xml library, pytl_core.Params usage
'''
# [*][begin] 221223.1 = deniska = NICORE-126: Excluding usage of legacy dict2xml library, pytl_core.Params usage
import pytl_core
__params__ = pytl_core.Params({
# [*][end]   221223.1 = deniska = NICORE-126: Excluding usage of legacy dict2xml library, pytl_core.Params usage
# Mandatory
        "ENV":                      lambda: config["ENV"],              # D:\PYTL\NIC\JOBNAME\W4UAT25.PARM
        "ORG":                      lambda: config["ORG"],              # XXX
# Optional
        # "OUTPUT_FN_SPACE":          lambda: "_" if not (__OUTPUT_FN_SPACE := config.get("OUTPUT_FN_SPACE")) else (__OUTPUT_FN_SPACE if __OUTPUT_FN_SPACE != '.' else ""),
        # "OUTPUT_FN_SEPARATOR":      lambda: "" if not (__OUTPUT_FN_SEPARATOR := config.get("OUTPUT_FN_SEPARATOR")) else (__OUTPUT_FN_SEPARATOR if __OUTPUT_FN_SEPARATOR != '.' else ""),
        # "OUTPUT_FN_PREFIX":         lambda: ("OLTLCM" + __params__['OUTPUT_FN_SEPARATOR']) if not (__OUTPUT_FN_PREFIX := config.get("OUTPUT_FN_PREFIX")) else (__OUTPUT_FN_PREFIX if __OUTPUT_FN_PREFIX != '.' else ""),
        "OUTPUT_FN_PREFIX":         lambda: "XADVAPL" if not (__OUTPUT_FN_PREFIX := config.get("OUTPUT_FN_PREFIX")) else (__OUTPUT_FN_PREFIX if __OUTPUT_FN_PREFIX != '.' else ""),
        # "OUTPUT_FN_EXTENSION":      lambda: ".txt" if not (__OUTPUT_FN_EXTENSION := config.get("OUTPUT_FN_EXTENSION")) else (__OUTPUT_FN_EXTENSION if __OUTPUT_FN_EXTENSION != '.' else ""),
# Parameters from file config["ENV"]
        "DB_STG_SRC_WLTURL":        lambda: config["DB_STG_SRC_WLTURL"],
# Precalculated values
        "JOB_NAME":                 lambda: config["JOB_NAME"],
        "SRC_DIR":                  lambda: config["SRC_DIR"],
        "DST_DIR":                  lambda: config["DST_DIR"],
        "W4C_IN_DIR":               lambda: config["W4C_IN_DIR"],
})  # [*] 221223.1 = deniska = NICORE-126: Excluding usage of legacy dict2xml library, pytl_core.Params usage

try:
    # Could be imported ONLY if it's run as module
    from . import __job_name__
except:
    # Could be imported ONLY if it's run as normal py
    from __init__ import __job_name__

from lxml import etree as et
# [*] begin 221223.1 = deniska = NICORE-126: Excluding usage of legacy dict2xml library
'''
from dict2xml import dict2xml
from collections import OrderedDict
'''
import n0struct
# [*] end   221223.1 = deniska = NICORE-126: Excluding usage of legacy dict2xml library
from collections import defaultdict

# Global variables
sdm_cdata_max_len = 3900 - 32 #SDM input is limited by 3900 symbols and CDATA block takes 32 symbols
src_app_name = ''
src_app_code = ''
ext_user_id = ''
explicit_client_number_generation = ''
sdm_channel = ''
sdm_ext_ignore_nulls = ''
sdm_ext_de_match = ''

current_timestamp = None
app_number = None

def sequence_generator(sequence_value=1):
    while True:
        yield sequence_value
        sequence_value += 1
sequence_var = sequence_generator()

def sequence():
    return str(next(sequence_var)).rjust(5,  '0')

def reg_number(prefix, current_timestamp, app_number):
    return prefix + current_timestamp.strftime("%Y%m%d") + app_number + '_' + sequence()

def add_text_element(parent_element, element_name, text):
    elem = et.SubElement(parent_element, element_name)
    elem.text = text

# this function converts list of dictionaries with "key"/"value" keys to list of xml applications splitted in accordance
# with the max length that can be processed by SDM
def process_sdm_fields(object_fields, object_type, parent_reg_num):
    sub_sequence = sequence_generator()
    var_outer = [[]]
    return_list = []
    leng = 0
    for object_field in object_fields:
        length_next_iteration = leng + len(object_field['key']) + len(object_field['value']) + 26 # 26 is the length of symbols added by json.dumps to dictionary with "key"/"value" as keys
        if  length_next_iteration <= sdm_cdata_max_len:
            var_outer[len(var_outer)-1].append(object_field)
            leng = length_next_iteration
        else:
            var_outer.append([])
            var_outer[len(var_outer)-1].append(object_field)
            leng = len(object_field['key']) + len(object_field['value']) + 26 # 26 is the length of symbols added by json.dumps to dictionary with "key"/"value" as keys
    for record in var_outer:
        sdm_app = et.Element('Application')
        add_text_element(sdm_app, 'RegNumber',parent_reg_num + '_' + str(next(sub_sequence)).rjust(5, '0'))
        add_text_element(sdm_app, 'ObjectType', object_type+'AddInfo')
        add_text_element(sdm_app, 'ActionType', 'Add')
        data = et.SubElement(sdm_app, 'Data')
        appinfo = et.SubElement(data, 'AppInfo')
        add_text_element(appinfo, 'InfoType', 'SDM_INPUT')
        add_text_element(appinfo, 'AddInfo02', et.CDATA(json.dumps(record)))
        return_list.append(sdm_app)
    return return_list


def process_card_production(card_data):
    # return et.fromstring(dict2xml(OrderedDict(card_data), wrap = "ProductionParms")) # [*] begin 221223.1 = deniska = NICORE-126: Excluding usage of legacy dict2xml library
    return et.fromstring(n0struct.n0dict(card_data).to_xml())  # [+] 221223.1 = deniska = NICORE-126: Excluding usage of legacy dict2xml library

# this function recursively processes nested hierarchy of applications
def process_application(input_data, level = 0, parent_key = '', parent_xml_element = None, main_appl_ord_num = 0):
    data = input_data
    if isinstance(data, dict):
        rv = {}
        if parent_key == 'application':
            rv['ApplicationStatus'] = {}
            rv['ApplicationStatus']['RegNumber'] = reg_number("", current_timestamp, app_number)
            error_reg_num = rv['ApplicationStatus']['RegNumber']

            # mandatory validations
            if data.get('ObjectType','') == '':
                rv['ApplicationStatus']['RespText'] = '(File Check) ObjectType is missing'
            elif data.get('Action','') == '':
                rv['ApplicationStatus']['RespText'] = '(File Check) Action is missing'
            elif 'object_fields' not in data:
                rv['ApplicationStatus']['RespText'] = '(File Check) object_fields is missing'

            if rv.get('ApplicationStatus',{}).get('RespText','') == '':
            #    main_appl_error.append({"main_appl_ord_num": main_appl_ord_num, "error_reg_num": error_reg_num})
            #else:
                parent_xml_element = et.SubElement(parent_xml_element, 'Application')
                reg_num = rv['ApplicationStatus']['RegNumber']

                #exception case
                if (data['ObjectType'] == "Contract") & (data['Action'] == 'Add') & (data.get('ContractForIdt','')!='') & (data.get('ClientForIdt','')!=''):
                    add_text_element(parent_xml_element, 'RegNumber', reg_num)
                    add_text_element(parent_xml_element, 'ObjectType', 'Client')
                    add_text_element(parent_xml_element, 'ActionType', 'AddOrUpdate')
                    ObjectFor = et.SubElement(parent_xml_element, 'ObjectFor')
                    ClientIDT = et.SubElement(ObjectFor, 'ClientIDT')
                    ClientInfo = et.SubElement(ClientIDT, 'ClientInfo')
                    add_text_element(ClientInfo, 'ClientNumber', data['ClientForIdt'])
                    add_text_element(ClientInfo, 'ShortName', '<<<NONE>>>')
                    Data = et.SubElement(parent_xml_element, 'Data')
                    et.SubElement(Data, 'Client')
                    if level == 2:
                        AddData = et.SubElement(parent_xml_element, 'AddData')
                        add_text_element(AddData, 'CPYPRIV-APPL_TYPE', 'PEI_SDM_CONTR')
                        add_text_element(AddData, 'SDM_EXT_FORMAT', 'JSON')
                        add_text_element(AddData, 'SDM_EXT_IGNORE_NULLS', sdm_ext_ignore_nulls)
                        add_text_element(AddData, 'SDM_CHANNEL', sdm_channel)
                        add_text_element(AddData, 'SDM_EXT_DE_MATCH', sdm_ext_de_match)
                        add_text_element(AddData, 'SRC_APP_NAME', data.get('src_app_name', src_app_name))
                        add_text_element(AddData, 'SRC_APP_CODE', data.get('src_app_code', src_app_code))
                        add_text_element(AddData, 'EXT_USER_ID', data.get('ext_user_id', ext_user_id))

                    if data['ObjectType'] == 'Client':
                        if level != 2:
                            AddData = et.SubElement(parent_xml_element, 'AddData')
                        add_text_element(AddData, 'CPYPRIV-OBJECT_CODE', data['ClientType'])  #TODO check if exists

                    parent_xml_element = et.SubElement(parent_xml_element, 'SubApplList')
                    parent_xml_element = et.SubElement(parent_xml_element, 'Application')
                    reg_num = reg_number("", current_timestamp, app_number)
                    data['ClientForIdt'] = ''
                    level = level + 1


                #create application header
                add_text_element(parent_xml_element, 'RegNumber', reg_num)
                add_text_element(parent_xml_element, 'ObjectType', data['ObjectType'])
                add_text_element(parent_xml_element, 'ActionType', data['Action'])

                sdm_client_number_idx = next((i for i, item in enumerate(data.get('object_fields',[])) if item["key"] == 'CL-CLIENT_NUMBER'),None)
                sdm_client_number = ''.join([x['value'] for x in data.get('object_fields',[]) if x['key'] == 'CL-CLIENT_NUMBER'])
                if (data['ObjectType'] == 'Client') & (explicit_client_number_generation != 'Y') & (
                        (sdm_client_number == '') ^ (sdm_client_number == 'AUTOGEN')) & (
                        (data['Action'] == 'Add') ^ ((data['Action'] == 'AddOrUpdate') & (data.get('ContractForIdt','') == ''))):
                    sdm_client_number = reg_num
                    if sdm_client_number_idx:
                        data['object_fields'][sdm_client_number_idx]['value']=reg_num
                    else:
                        data['object_fields'].append({"key": "CL-CLIENT_NUMBER","value": reg_num})

                #create objectFor
                #case 1
                if (data['ObjectType'] == 'Client') & (data['Action'] == 'Add') & (data.get('ContractForIdt','') != ''):
                    rv['ApplicationStatus']['RespText'] = f'(File Check) Unable to create ObjectFor section for {error_reg_num}'
                #case 2
                if (data['ObjectType'] == 'Client') & (data['Action'] == 'AddOrUpdate'):
                    if data.get('ContractForIdt','') != '':
                        ObjectFor=et.SubElement(parent_xml_element, 'ObjectFor')
                        ClientIDT = et.SubElement(ObjectFor, 'ClientIDT')
                        ClientInfo =  et.SubElement(ClientIDT, 'ClientInfo')
                        add_text_element(ClientInfo, 'ShortName', '<<<NONE>>>')
                        add_text_element(ClientIDT, 'RefContractNumber', data['ContractForIdt'])
                    elif (sdm_client_number !='') & (sdm_client_number !='AUTOGEN'):
                        ObjectFor = et.SubElement(parent_xml_element, 'ObjectFor')
                        ClientIDT = et.SubElement(ObjectFor, 'ClientIDT')
                        ClientInfo = et.SubElement(ClientIDT, 'ClientInfo')
                        add_text_element(ClientInfo,  'ClientNumber', sdm_client_number)
                        add_text_element(ClientInfo, 'ShortName', '<<<NONE>>>')
                    elif (explicit_client_number_generation == 'Y') & (sdm_client_number ==''):
                        rv['ApplicationStatus']['RespText'] = f'(File Check) Unable to create ObjectFor section for {error_reg_num}'
                #case 3
                if (data['ObjectType'] == 'Client') & (data['Action'] == 'Update'):
                    if data.get('ContractForIdt','') != '':
                        ObjectFor=et.SubElement(parent_xml_element, 'ObjectFor')
                        ClientIDT = et.SubElement(ObjectFor, 'ClientIDT')
                        ClientInfo =  et.SubElement(ClientIDT, 'ClientInfo')
                        add_text_element(ClientInfo, 'ShortName', '<<<NONE>>>')
                        add_text_element(ClientIDT, 'RefContractNumber', data['ContractForIdt'])
                    elif (sdm_client_number !='') & (sdm_client_number !='AUTOGEN'):
                        ObjectFor = et.SubElement(parent_xml_element, 'ObjectFor')
                        ClientIDT = et.SubElement(ObjectFor, 'ClientIDT')
                        ClientInfo = et.SubElement(ClientIDT, 'ClientInfo')
                        add_text_element(ClientInfo, 'ClientNumber', sdm_client_number)
                        add_text_element(ClientInfo, 'ShortName', '<<<NONE>>>')
                    else:
                        rv['ApplicationStatus']['RespText'] = f'(File Check) Unable to create ObjectFor section for {error_reg_num}'
                #case 5
                if (data['ObjectType'] == 'Contract') & (data['Action']=='Update'):
                    if data.get('ContractForIdt','') != '':
                        ObjectFor=et.SubElement(parent_xml_element, 'ObjectFor')
                        ContractIDT = et.SubElement(ObjectFor, 'ContractIDT')
                        add_text_element(ContractIDT, 'AlternativeIDType', data.get('ContractForType','CONTRACT_NUMBER'))
                        add_text_element(ContractIDT, 'AlternativeID', data['ContractForIdt'])
                    elif sdm_client_number != '':
                        ObjectFor=et.SubElement(parent_xml_element, 'ObjectFor')
                        ContractIDT = et.SubElement(ObjectFor, 'ContractIDT')
                        add_text_element(ContractIDT, 'AlternativeIDType', 'CONTRACT_NUMBER')
                        add_text_element(ContractIDT, 'AlternativeID', sdm_client_number)
                    else:
                        rv['ApplicationStatus']['RespText'] = f'(File Check) Unable to create ObjectFor section for {error_reg_num}'
                #case 4
                if (data['ObjectType'] == 'Contract') & (data['Action']=='Add'):
                    if data.get('ContractForIdt','') != '' and data.get('ClientForIdt','') == '':
                        ObjectFor=et.SubElement(parent_xml_element, 'ObjectFor')
                        ContractIDT = et.SubElement(ObjectFor, 'ContractIDT')
                        add_text_element(ContractIDT, 'AlternativeIDType', data.get('ContractForType','CONTRACT_NUMBER'))
                        add_text_element(ContractIDT, 'AlternativeID', data['ContractForIdt'])
                    elif data.get('ClientForIdt','') != '' and data.get('ContractForIdt','') == '':
                        ObjectFor = et.SubElement(parent_xml_element, 'ObjectFor')
                        ClientIDT = et.SubElement(ObjectFor, 'ClientIDT')
                        ClientInfo = et.SubElement(ClientIDT, 'ClientInfo')
                        add_text_element(ClientInfo, 'ClientNumber', data['ClientForIdt'])
                        add_text_element(ClientInfo, 'ShortName', '<<<NONE>>>')


                #Data
                if data.get('PRODUCT_CODE','') != '':
                    Data = et.SubElement(parent_xml_element, 'Data')
                    Contract = et.SubElement(Data, 'Contract')
                    Product = et.SubElement(Contract, 'Product')
                    add_text_element(Product, 'ProductCode1', data['PRODUCT_CODE'])

                if data.get('ProduceCard', {}) :
                    if data.get('PRODUCT_CODE','') == '':
                        Data = et.SubElement(parent_xml_element, 'Data')
                        Contract = et.SubElement(Data, 'Contract')
                    Contract.append(process_card_production(data['ProduceCard']))

                if data.get('PRODUCT_CODE','') == '' and not data.get('ProduceCard', {}):
                    Data = et.SubElement(parent_xml_element, 'Data')
                    add_text_element(Data, data['ObjectType'] , '')

                #AddData
                if level==2:
                    AddData = et.SubElement(parent_xml_element, 'AddData')
                    add_text_element(AddData, 'CPYPRIV-APPL_TYPE', 'PEI_SDM_CONTR')
                    add_text_element(AddData, 'SDM_EXT_FORMAT', 'JSON')
                    add_text_element(AddData, 'SDM_EXT_IGNORE_NULLS', sdm_ext_ignore_nulls)
                    add_text_element(AddData, 'SDM_CHANNEL', sdm_channel)
                    add_text_element(AddData, 'SDM_EXT_DE_MATCH', sdm_ext_de_match)
                    add_text_element(AddData, 'SRC_APP_NAME', data.get('src_app_name',src_app_name))
                    add_text_element(AddData, 'SRC_APP_CODE', data.get('src_app_code',src_app_code))
                    add_text_element(AddData, 'EXT_USER_ID', data.get('ext_user_id',ext_user_id))

                if data['ObjectType'] == 'Client':
                    if level!=2:
                        AddData = et.SubElement(parent_xml_element, 'AddData')
                    add_text_element(AddData, 'CPYPRIV-OBJECT_CODE', data['ClientType'])

                # SDM data
                if len(data['object_fields']) != 0:
                    sub_appl_list = et.SubElement(parent_xml_element, 'SubApplList')
                    for appl in process_sdm_fields(data['object_fields'],data['ObjectType'],reg_num):
                        sub_appl_list.append(appl)

                if data.get('applications',{}):
                    if len(data['object_fields']) == 0:
                        sub_appl_list = et.SubElement(parent_xml_element, 'SubApplList')
                    parent_xml_element = sub_appl_list

            if rv.get('ApplicationStatus',{}).get('RespText','') != '':
                main_appl_error.append({"main_appl_ord_num" : main_appl_ord_num, "error_reg_num" : error_reg_num})

        for k, v in input_data.items():
           rv[k] = process_application(v, level = level+1, parent_key = k, parent_xml_element = parent_xml_element,main_appl_ord_num = main_appl_ord_num)
        return rv


    elif isinstance(input_data, list):
        if level == 0:
            rv = [process_application(v, level=level + 1, parent_xml_element = parent_xml_element,main_appl_ord_num = i) for i,v in enumerate(input_data)]
        else:
            rv = [process_application(v, level=level + 1, parent_xml_element = parent_xml_element, main_appl_ord_num = main_appl_ord_num) for v in input_data]
        return rv
    else:
        return input_data

def main_in(_config):
    global config
    config = _config

    global current_timestamp, app_number
    current_timestamp = datetime.datetime.now()
    db_connection = OracleDB(__params__['DB_STG_SRC_WLTURL'])
    way4_file_prefix = __params__['OUTPUT_FN_PREFIX']
    logging.info(f"Search for {__params__['SRC_DIR']}\\NIC*") # [+] 221223.1 = deniska = NICORE-126: fixing of EXID logic support with parameter RETURN_EXID_CARD
    for input_filepath in list(Path(__params__['SRC_DIR']).glob('NIC*')):
        logging.info(f"Processing incoming file {input_filepath}")
        with open(input_filepath, 'r') as json_file:
            appl_file = json.load(json_file)

        sequence_var = sequence_generator()
        app_number = db_connection.execute_select(
            statement=f"select PyTL_JOB_SUPPORT.getSequenceValue('{__params__['JOB_NAME']}', 'file_name') SEQUENCE_NUMBER from dual",
            bind_vars={}, pd_mode=False
        )['data'][0]['SEQUENCE_NUMBER'].rjust(5, '0')

        main_appl_error = []

        output_filename = Path(__params__['W4C_IN_DIR']).joinpath(
            f"{way4_file_prefix}{__params__['ORG'].rjust(6, '0')}_{app_number}.{current_timestamp.strftime('%j').rjust(3, '0')}"
        )

        output_filename_json = Path(__params__['DST_DIR']).joinpath(
            f"{way4_file_prefix}{__params__['ORG'].rjust(6, '0')}_{app_number}.{current_timestamp.strftime('%j').rjust(3, '0')}.json"
        )

        #check mandatory elements
        if not 'header' in appl_file:
            appl_file['header'] = {'FileStatus': {'Error': 'header element is missing'}}
        else:
            if 'FileStatus' not in appl_file['header']:
                appl_file['header']['FileStatus'] = {}

            if not "applications" in appl_file:
                appl_file['header']['FileStatus']['Error'] = "applications element is missing"
            elif not (header_fi:=appl_file['header'].get('fi','')):
                appl_file['header']['FileStatus']['Error'] = "header.fi is missing"
            elif header_fi != __params__['ORG']:
                appl_file['header']['FileStatus']['Error'] = f"header.fi is invalid: expected '{__params__['ORG']}', but got '{header_fi}'"
            elif not (header_file_type:=appl_file['header'].get('file_type','')):
                appl_file['header']['FileStatus']['Error'] = "header.file_type is missing"
            elif header_file_type != 'IN.BATCH.APPL_CONTR_CLIENT':
                appl_file['header']['FileStatus']['Error'] = "header.file_type is invalid: expected 'IN.BATCH.APPL_CONTR_CLIENT', but got '{header_file_type}'"


        global src_app_name, src_app_code, ext_user_id, explicit_client_number_generation, sdm_channel, sdm_ext_ignore_nulls, sdm_ext_de_match
        if (error_msg:=appl_file['header']['FileStatus'].get('Error','')) == '':
            src_app_name = appl_file['header'].get('src_app_name','')
            src_app_code = appl_file['header'].get('src_app_code','')
            ext_user_id = appl_file['header'].get('ext_user_id','')
            explicit_client_number_generation = appl_file['header'].get('explicit_client_number_generation','')
            # [*][begin] 210927.1 = deniska = ENG-3936
            sdm_channel = appl_file['header'].get('sdm_channel',"APPL_FILE") or "APPL_FILE"
            # [*][end]   210927.1 = deniska = ENG-3936
            sdm_ext_ignore_nulls = appl_file['header'].get('sdm_ext_ignore_nulls','')
            sdm_ext_de_match = appl_file['header'].get('sdm_ext_de_match','')

            root = et.Element('ApplicationFile')
            header = et.SubElement(root, 'FileHeader')
            add_text_element(header,'FormatVersion', '2.0')
            add_text_element(header, 'Sender', str(appl_file['header']['fi']).rjust(6, '0'))
            add_text_element(header, 'CreationDate', current_timestamp.strftime("%Y-%m-%d"))
            add_text_element(header, 'CreationTime', current_timestamp.strftime("%H:%M:%S"))
            add_text_element(header, 'Number', app_number)
            add_text_element(header, 'Institution', appl_file['header']['fi'])
            application_list = et.SubElement(root,'ApplicationsList')

            appl_file['header']['FileStatus']['InputFileName'] = Path(input_filepath).name
            appl_file['header']['FileStatus']['TotalApplications'] = str(len(appl_file['applications']))

            appl_file['applications'] = process_application(input_data = appl_file['applications'],parent_xml_element=application_list)

            main_appl_error_agg = defaultdict(list)

            for d in main_appl_error:
                k = d["main_appl_ord_num"]
                del d["main_appl_ord_num"]
                main_appl_error_agg[k].append(d['error_reg_num'])

            for key,value in dict(sorted(main_appl_error_agg.items(),reverse=True)).items():
                if appl_file['applications'][key]['application']['ApplicationStatus'].get('RespText','') == '':
                    appl_file['applications'][key]['application']['ApplicationStatus']['RespText'] =\
                        f"Error(s) occurred in the child application(s): {','.join(value)}"
                appl_file['applications'][key]['application']['ApplicationStatus']['RespClass'] = 'Error'
                appl_file['applications'][key]['application']['ApplicationStatus']['RespCode'] = '1005'
                appl_file['applications'][key]['application']['ApplicationStatus']['PostingStatus'] = 'Declined'

                application_list[key].getparent().remove(application_list[key])

            appl_file['header']['FileStatus']['AcceptedApplications'] = str(len(application_list))
            appl_file['header']['FileStatus']['RejectedApplications'] = str(int(appl_file['header']['FileStatus']['TotalApplications']) - len(application_list))

            if appl_file['header']['FileStatus']['AcceptedApplications'] != 0:
                if appl_file['header']['FileStatus']['RejectedApplications'] != 0:
                    appl_file['header']['FileStatus']['LoadingStatus'] = 'FILE PARTIALLY PROCESSED'
                else:
                    appl_file['header']['FileStatus']['LoadingStatus'] = 'FILE PROCESSED'

                Path(output_filename).parents[0].mkdir(parents=True, exist_ok=True)
                with open(output_filename,'w+', encoding='utf-8') as output_xml:
                    output_xml.write(et.tostring(root, xml_declaration=True, pretty_print=True, encoding="ISO-8859-15").decode("utf-8"))
                db_connection.execute_insert_batch(__job_name__,
                                                   [{"APP_NUMBER" : app_number.lstrip("0"), "ORG" : __params__['ORG'], "RESPONSE_JSON" :
                                                       json.dumps(appl_file, ensure_ascii=False, indent=4),
                                                     "INPUT_FILENAME" : output_filename_json.name}],commit=True)
            else:
                Path(output_filename_json).parents[0].mkdir(parents=True, exist_ok=True)
                with open(output_filename_json, 'w+', encoding='utf-8') as output_json:
                    appl_file['header']['FileStatus']['LoadingStatus'] = 'FILE REJECTED'
                    json.dump(appl_file, output_json, ensure_ascii=False, indent=4)
                db_connection.execute_stored_procedure('PyTL_JOB_SUPPORT.setSeqValueUsed',bind_vars={'p_job_id': __params__['JOB_NAME'],'p_seq_value': app_number.lstrip("0"), 'p_mode': 'mark'})
                db_connection.commit()

            utils.delete_file(input_filepath)
        else:
            logging.error(error_msg)

    db_connection.close()

#TODO - code below can be used to validate resulting XML
'''
    xml_error=''
    xml_validator = lxml.etree.XMLSchema(file="C:\\IT\\xsd\\xsd\\offline\\WAY4ApplFile.xsd")
    try:
        for element in root.xpath(".//*[not(node())]"):
            element.getparent().remove(element)
        is_valid = xml_validator.validate(root)
        if xml_validator.error_log:
            for error in xml_validator.error_log:
                xml_error = xml_error + error.message.upper() + ';'
'''

from pytl_core import *
