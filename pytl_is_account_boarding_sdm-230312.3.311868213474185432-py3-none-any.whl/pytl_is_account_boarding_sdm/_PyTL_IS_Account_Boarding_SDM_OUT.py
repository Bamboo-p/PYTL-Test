''' NIC_IS_Ou_Account_Boarding_SDM

The pytl job converts WAY4 XML response file to JSON format

Requirements
------------
    pytl core v2.8


Parameters
----------
ENV : string
    Specifies path to settings file with database connection and in/out/etc dirs paths.
    Cann be an absolute or relative path, or a file name without extension.
    Mandatory.
ORG : string
    Code of fin institution in Way4
    Mandatory.

References
----------
    ENG-2921
    ENG-3771
    ALMAS-99

Changes
-------
    210806.1 = Konstantin Akulshin+Aleksander Parfenov = ENG-2921: Initial development
    210909.1 = deniska+Aleksander Parfenov = ENG-3771: report saving into CSV added
    211006.1 = deniska = ALMAS-99: Rewritten for unification, according to discussion with TatianaO/MaximS 20/09/2021, PavelP 22/09/2021:
                         If optional parameters were not set, then default values are:
                             DELIMITER          == '|'
                             INPUT_FN_PREFIX    == 'RXADVAPL'
                             INPUT_FN_SEPARATOR == '_'
                         Input file name mask: {INPUT_FN_PREFIX}{ORG.lzeropad(6)}{INPUT_FN_SEPARATOR}{tlnd_tmp_active_sequences_vw.CURRENT_SEQUENCE_VALUE.lzeropad(5)}.???
    211025.1 = deniska = ALMAS-495: added ability to process already processed file = added optional parameter APPLICATIONS
    211025.2 = deniska = ALMAS-495: csv.[Contract Type] = application.ContractForType if application.ContractForType is not empty else 'CONTRACT_NUMBER'
    220512.2 = deniska = PRD-20670: the names of used tables are renamed from old Talend naming convention into new PyTL.
    220512.7 = deniska = PRD-20670: added ability to process files with correct names, but incorrect content
    221219.1 = AhmedG  = ETSLT-47:  EXID logic support
    221223.1 = deniska = NICORE-126: fixing of EXID logic support with parameter RETURN_EXID_CARD and RETURN_EXID_CONTRACT
    230312.3 = deniska = ALMAS-927: mitigation of None values inside DB.
'''
# [*][begin] 221223.1 = deniska = NICORE-126: fixing of EXID logic support with parameter RETURN_EXID_CARD
import pytl_core
__params__ = pytl_core.Params({
# [*][end]   221223.1 = deniska = NICORE-126: fixing of EXID logic support with parameter RETURN_EXID_CARD
# [+][begin] 211006.1 = deniska = ALMAS-99
# Mandatory
        "ENV":                      lambda: config["ENV"],              # D:\PYTL\NIC\JOBNAME\W4UAT25.PARM
        "ORG":                      lambda: config["ORG"],              # XXX
# Optional
# [*][begin] 221223.1 = deniska = NICORE-126: fixing of EXID logic support with parameter RETURN_EXID_CARD
        "RETURN_EXID_CARD":         lambda: validate_bool(config.get("RETURN_EXID_CARD"), False), # [+][begin] 221219.1 = AhmedG  = ETSLT-47:  EXID logic support
        "RETURN_EXID_CONTRACT":     lambda: validate_bool(config.get("RETURN_EXID_CONTRACT"), False),
# [*][begin] 221223.1 = deniska = NICORE-126: fixing of EXID logic support with parameter RETURN_EXID_CARD
        "DELIMITER":                lambda: config.get("DELIMITER") or "|",
        "INPUT_FN_PREFIX":          lambda: "RXADVAPL" if not (__INPUT_FN_PREFIX := config.get("INPUT_FN_PREFIX")) else (__INPUT_FN_PREFIX if __INPUT_FN_PREFIX != '.' else ""),
        "INPUT_FN_SEPARATOR":       lambda: "_" if not (__INPUT_FN_SEPARATOR := config.get("INPUT_FN_SEPARATOR")) else (__INPUT_FN_SEPARATOR if __INPUT_FN_SEPARATOR != '.' else ""),
        "APPLICATIONS":             lambda: config.get("APPLICATIONS", None),  # [+] 211025.1 = deniska = ALMAS-495: added ability to process already processed file
# Parameters from file config["ENV"]
        "DB_STG_SRC_WLTURL":        lambda: config["DB_STG_SRC_WLTURL"],
# Precalculated values
        "JOB_NAME":                 lambda: config["JOB_NAME"],
        "W4C_OUT_DIR":              lambda: config["W4C_OUT_DIR"],
        "DST_DIR":                  lambda: config["DST_DIR"],
}) # [*] 221223.1 = deniska = NICORE-126: fixing of EXID logic support with parameter RETURN_EXID_CARD
# [+][end]   211006.1 = deniska = ALMAS-99
'''
# [-][begin] 211006.1 = deniska = ALMAS-99
import sys
import os
from pytl_core.job_launcher import logging
import pytl_core

globals()["cfg"] = globals()["config"] = pytl_core.Config.configure_pytl_core({})
pytl_core.logging.debug(f"Config: initialisation finished, 'config' and 'cfg' variables were created.")
# [-][end]   211006.1 = deniska = ALMAS-99
'''

try:
    # Could be imported ONLY if it's run as module
    from . import __job_name__
    # from .findall import findall as findall_findall
except:
    # Could be imported ONLY if it's run as normal py
    from __init__ import __job_name__
    # from findall import findall as findall_findall

from pathlib import Path
import n0struct
from n0struct import *
import logging

def main_out(_config):
    global config
    config = _config

    stg_conn = pytl_core.Connection(__params__['DB_STG_SRC_WLTURL'])

    if __params__['APPLICATIONS']:
        logging.info(f"*** DEBUG MODE for {__params__['APPLICATIONS']=}")
        # Debug info
        select = f"select * from PyTL_JOBS_CURRENT_VALUES where OUT_JOB_ID = '{__params__['JOB_NAME']}' and CURRENT_SEQUENCE_VALUE in ({__params__['APPLICATIONS']})"
        logging.debug(stg_conn.execute_select(statement=select))

        # Extract numbers of open/closed application {__params__['APPLICATIONS']} 
        # from STG_ETL schema, assosiated with {__params__['JOB_NAME']}
        select = f"select PyTL_IS_Account_Boarding_SDM.APP_NUMBER as VALUE from PyTL_IS_Account_Boarding_SDM " \
                 f"where PyTL_IS_Account_Boarding_SDM.APP_NUMBER in ({__params__['APPLICATIONS']})"
    else:
        logging.info(f"*** NORMAL MODE")
        # Extract numbers of open applications from STG_ETL schema, assosiated with {__params__['JOB_NAME']}
        # select = f"select CURRENT_SEQUENCE_VALUE as VALUE from PyTL_TMP_ACTIVE_SEQUENCES_VW where OUT_JOB_ID = '{__params__['JOB_NAME']}' " \
        #          f"order by CURRENT_SEQUENCE_VALUE"
        # [*][begin] 221223.1 = deniska = NICORE-126: fixing of EXID logic support with parameter RETURN_EXID_CARD
        # input_file_mask = f"{__params__['INPUT_FN_PREFIX']}{int(__params__['ORG']):0>6}{__params__['INPUT_FN_SEPARATOR']}{int(seq):0>5}.???"
        # TypeError: int() argument must be a string, a bytes-like object or a number, not 'NoneType'
        # because of original query could return one of item as None
        select = "select CURRENT_SEQUENCE_VALUE as VALUE from PyTL_TMP_ACTIVE_SEQUENCES_VW " \
                 "join PyTL_IS_Account_Boarding_SDM on " \
                 "PyTL_IS_Account_Boarding_SDM.APP_NUMBER = PyTL_TMP_ACTIVE_SEQUENCES_VW.CURRENT_SEQUENCE_VALUE " \
                 "order by CURRENT_SEQUENCE_VALUE"
        # [*][end]   221223.1 = deniska = NICORE-126: fixing of EXID logic support with parameter RETURN_EXID_CARD


    open_seqs = [d['VALUE'] for d in stg_conn.execute_select(statement=select)['data']]
    # n0debug_calc(open_seqs, f"open (not processed) applications")

    for seq in open_seqs:
        # n0debug("seq")
        # [*][begin] 211006.1 = deniska = ALMAS-99
        input_file_mask = f"{__params__['INPUT_FN_PREFIX']}{int(__params__['ORG'] or 666666):0>6}{__params__['INPUT_FN_SEPARATOR']}{int(seq or 55555):0>5}.???"
        logging.debug(f"{input_file_mask=}")
        inputs = list(Path(__params__['W4C_OUT_DIR']).glob(input_file_mask))
        logging.debug(f"Found files: {inputs=}")
        if len(inputs) == 0: logging.info(f"No input files found for mask {input_file_mask} in '{__params__['W4C_OUT_DIR']}'")
        # [*][end]   211006.1 = deniska = ALMAS-99
        for found_incoming_file_from_way4 in inputs:
            way4_resp_xml = n0struct.n0dict(file = str(found_incoming_file_from_way4))
            # ######################################################################
            # Convert nested applications' structure from way4_resp_xml into the plain == way4_resp_xml__applications_list
            # ######################################################################
            way4_resp_xml__applications_list = []
            
            # __findall_findall1 = way4_resp_xml.findall("*/Application") # returns dict
            # n0debug("__findall_findall1")
            # n0debug_calc(__findall_findall1.keys(), "__findall_findall1.keys()")
            # __findall_findall1_ = list(__findall_findall1.items())
            # n0debug("__findall_findall1_")
            
            ## _findall_findall1 = findall_findall(way4_resp_xml, '*/Application') # returns list of tuples
            _findall_findall1 = list((way4_resp_xml.findall('*/Application') or {}).items()) # returns dict -> list of tuples
            # n0debug("_findall_findall1")
            for xpath, application in _findall_findall1:
                if isinstance(application, dict):
                    way4_resp_xml__applications_list.append((xpath, application))
                elif isinstance(application, list):
                    for item_index,application_item in enumerate(application):
                        if not isinstance(application_item, dict):
                            raise Exception("Expected dict")
                        way4_resp_xml__applications_list.append((f"{xpath}[{item_index}]", application_item))
                else:
                    raise Exception("Expected dict/list")

            # ######################################################################
            # Accumulate ObjectNumber/RespClass/RespCode/RespText/PostingStatus from way4_resp_xml__applications_list == in way4_resp_xml__applications_level
            # Dictinary way4_resp_xml__applications_level will consists of prepared structure for injections into the client_req_json
            # ######################################################################
            way4_resp_xml__applications_level = n0struct.n0dict()
            for way4_resp_xml__src_application_xpath,way4_resp_xml__src_application in way4_resp_xml__applications_list:
                way4_resp_xml__application_regnumber = way4_resp_xml__src_application.get("RegNumber")
                way4_resp_xml__applications_level__dst_application = way4_resp_xml__applications_level[way4_resp_xml__application_regnumber] = n0struct.n0dict()

                ObjectType      = way4_resp_xml__src_application.get("ObjectType")
                ClientNumber    = way4_resp_xml__src_application.get("ObjectFor/ClientIDT/ClientInfo/ClientNumber")
                ContractNumber  = way4_resp_xml__src_application.get("DataRs/ContractRs/Contract/ContractIDT/ContractNumber")
# [+][begin] 221219.1 = AhmedG  = ETSLT-47:  EXID logic support
# [*][begin] 221223.1 = deniska = NICORE-126: fixing of EXID logic support with parameter RETURN_EXID_CARD
                if ObjectType == 'Contract' and (__params__['RETURN_EXID_CARD'] or __params__['RETURN_EXID_CARD']):
                    contract_category = way4_resp_xml__src_application.get(
                                            "DataRs/ContractRs/Contract/Product/AddInfo/Parm"
                                            "/ParmCode[text()=ContractCategory]"
                                            "/../Value"
                    )
                    extra_rs = deserialize_dict(
                                                    way4_resp_xml__src_application.get(
                                                        "DataRs/ContractRs/Contract/AddContractInfo/ExtraRs"
                                                    )
                    )
                    if __params__['RETURN_EXID_CARD'] and contract_category == "Card":
                        ContractNumber = ""  # Don't show card no if RETURN_EXID_CARD is True and have not received EXID
                        if extra_rs.get("ALT_ID_TYPE") == "EXID":
                            ContractNumber = extra_rs.get("ALT_ID", "")
                    if __params__['RETURN_EXID_CONTRACT'] and contract_category == "Account":
                        ContractNumber = ""  # Don't show card no if RETURN_EXID_CONTRACT is True and have not received EXID
                        if extra_rs.get("ALT_ID_TYPE") == "EXID":
                            ContractNumber = extra_rs.get("ALT_ID", "")
                    way4_resp_xml__applications_level__dst_application['ObjectNumber'] = ContractNumber
# [*][end]   221223.1 = deniska = NICORE-126: fixing of EXID logic support with parameter RETURN_EXID_CARD
# [+][end]   221219.1 = AhmedG  = ETSLT-47:  EXID logic support

                if ObjectType == 'Client' and ClientNumber:
                    way4_resp_xml__applications_level__dst_application['ObjectNumber'] = ClientNumber
                elif ObjectType == 'Contract' and ContractNumber:
                    way4_resp_xml__applications_level__dst_application['ObjectNumber'] = ContractNumber

                way4_resp_xml__src_application_status = way4_resp_xml__src_application.get("Status")
                if way4_resp_xml__src_application_status:
                    way4_resp_xml__applications_level__dst_application['RespClass']     = way4_resp_xml__src_application_status.get('RespClass')
                    way4_resp_xml__applications_level__dst_application['RespCode']      = way4_resp_xml__src_application_status.get('RespCode')
                    way4_resp_xml__applications_level__dst_application['RespText']      = way4_resp_xml__src_application_status.get('RespText')
                    way4_resp_xml__applications_level__dst_application['PostingStatus'] = way4_resp_xml__src_application_status.get('PostingStatus')
            # ######################################################################
            # Load initial json and enrich with data from way4_resp_xml__applications_level
            # ######################################################################
            # FIXME: check the reason, why PyTL_IS_Account_Boarding_SDM.APP_NUMBER is string
            select = f"select RESPONSE_JSON,INPUT_FILENAME from {__job_name__} where APP_NUMBER = '{seq}'"
            processed_json = stg_conn.execute_select(statement=select)['data'][0]
            client_req_json = n0struct.n0dict(str(processed_json['RESPONSE_JSON']), recursively = True)

            # __findall_findall2 = client_req_json.findall('*/application/ApplicationStatus/RegNumber')
            # n0debug("__findall_findall2")
            # n0debug_calc(__findall_findall2.keys())
            ## _findall_findall2 = findall_findall(client_req_json, '*/application/ApplicationStatus/RegNumber')
            _findall_findall2 = list((client_req_json.findall('*/application/ApplicationStatus/RegNumber') or {}).items()) # returns dict -> list of tuples
            # n0debug("_findall_findall2")
            for xpathRegNumber, valueRegNumber in _findall_findall2:
                if valueRegNumber in way4_resp_xml__applications_level:
                    client_req_json['/'.join(xpathRegNumber.split('/')[:-1])].update(way4_resp_xml__applications_level[valueRegNumber])
            # ######################################################################
            # Update the counts AcceptedApplications/RejectedApplications and LoadingStatus
            # ######################################################################
            rejected = int(client_req_json.get('header/FileStatus/RejectedApplications', -999))
            way4_resp_xml__file_trailer = way4_resp_xml.get("//ApplicationResponseFile/FileTrailer")
            if way4_resp_xml__file_trailer:
                accepted = int(way4_resp_xml__file_trailer.get('NOfAcceptedRecs', 0))
                rejected += int(way4_resp_xml__file_trailer.get('NOfRejectedRecs', 0))
            else:
                accepted = 0
            total = accepted + rejected
            if total == accepted:
                load_status = 'FILE PROCESSED'
            elif total == rejected:
                load_status = 'FILE REJECTED'
            else:
                load_status = 'FILE PARTIALLY PROCESSED'
            client_req_json['header/FileStatus/AcceptedApplications'] = str(accepted)
            client_req_json['header/FileStatus/RejectedApplications'] = str(rejected)
            client_req_json['header/FileStatus/LoadingStatus'] = load_status
            # ######################################################################
            # Save outgoing json
            # ######################################################################
            output_filename = Path(__params__['DST_DIR']) / processed_json['INPUT_FILENAME']
            output_filename.parents[0].mkdir(parents=True, exist_ok=True)
            with open(output_filename, 'w+', encoding='utf-8') as output_json:
                # n0struct.json.dump(client_req_json, output_json, ensure_ascii=False, indent=4)
                output_json.write(client_req_json.to_json(pairs_in_one_line = True))
                logging.info(f"JSON response file is created {str(output_filename)}")

            # ######################################################################
            # Save outgoing csv
            # ######################################################################
            csv_header = {
                "Level"                 : lambda xpathApplication, nodeApplication:
                                            ".".join(
                                                        [
                                                            str(int(node_index)+1)
                                                                        for node_index in xpathApplication \
                                                                                            .replace("/applications[","") \
                                                                                            .replace("]/application",".") \
                                                                                            .replace("/","") \
                                                                                            .split(".") \
                                                                        if node_index
                                                        ]
                                            ),  # Lambda:
                                                # 1) convert xpath ("//applications[2]/application/applications[0]/application/applications[0]/application")
                                                # into the string only with node indexes == "2.0.0"
                                                # 2) convert into the list with int == [2, 0, 0]
                                                # 3) add 1 to each of index to get serial number of the each node == [3, 1, 1]
                                                # 4) convert list into the str == "3.1.1"
                "Source Reg Number"     : "source_reg_number",              # FOUND only after manual update of the json sample in DB
                "Application Reg Number": "ApplicationStatus/RegNumber",
                "Object Type"           : "ObjectType",
                "Action"                : "Action",
                "Object Number"         : "ApplicationStatus/ObjectNumber",
                "Client For Idt"        : "ClientForIdt",
# [*][begin] 211025.2 = deniska = ALMAS-495: csv.[Contract Type] = application.ContractType if application.ContractType is not empty else 'CONTRACT_NUMBER'
#                "Contract Type"         : "ContractForType",                # According to specification from TatianaO
                "Contract Type"         : lambda xpathApplication, nodeApplication: nodeApplication.get("ContractForType", "CONTRACT_NUMBER") or "CONTRACT_NUMBER",
# [*][end]   211025.2 = deniska = ALMAS-495: csv.[Contract Type] = application.ContractForType if application.ContractForType is not empty else 'CONTRACT_NUMBER'
                "Contract For Idt"      : "ContractForIdt",
                "Posting Status"        : "ApplicationStatus/PostingStatus",
                "Response Text"         : "ApplicationStatus/RespText",
            }
            delimiter = __params__['DELIMITER']

            # Change the extension .json of processed_json['INPUT_FILENAME'] into .csv
            output_filename = (Path(__params__['DST_DIR']) / processed_json['INPUT_FILENAME']).with_suffix(".csv")
            output_filename.parents[0].mkdir(parents=True, exist_ok=True)
            with open(output_filename, 'w+', encoding='utf-8') as output_csv:
                output_csv.write(delimiter.join(csv_header) + "\n")
                # n0debug("client_req_json")
                # n0print(client_req_json.to_xpath())
                # found_application = findall_findall(client_req_json, "*/application")
                # n0debug("found_application")
                # for xpathApplication, nodeApplication in found_application:
                # __findall_findall3 = client_req_json.findall('*/application')
                # n0debug("__findall_findall3")
                # n0debug_calc(__findall_findall3.keys())
                ## _findall_findall3 = findall_findall(client_req_json, "*/application")
                _findall_findall3 = list((client_req_json.findall('*/application') or {}).items()) # returns dict -> list of tuples
                # n0debug("_findall_findall3")
                for xpathApplication, nodeApplication in _findall_findall3:
                    row_with_values = {}
                    for field in csv_header:
                        xpath = csv_header[field]
                        value = ""
                        if callable(xpath):
                            # n0debug("xpathApplication")
                            # n0debug("nodeApplication")
                            value = xpath(xpathApplication, nodeApplication)
                            # n0debug("value")
                        elif isinstance(xpath, str) and xpath:
                            value = str(nodeApplication.get(xpath, ""))
                        elif isinstance(xpath, (int, float)):
                            value = str(xpath)
                        row_with_values.update({field: value})
                    output_csv.write(delimiter.join(row_with_values.values()) + "\n")
                logging.info(f"CSV response file is created {str(output_filename)}")

            # ######################################################################
            # Clean the DB and delete incoming file fromway4
            # ######################################################################

            # Disabled just for unit-testing
            # close processed sequense number, delete source file
            stg_conn.execute_stored_procedure('PyTL_JOB_SUPPORT.setSeqValueUsed',bind_vars={'p_job_id': __params__['JOB_NAME'],'p_seq_value': seq, 'p_mode': 'mark'})
            stg_conn.commit()
            pytl_core.utils.delete_file(found_incoming_file_from_way4)

    # Debug info

    # Deleted old records from STG table
    stg_conn.execute_statement_or_anonym_block(
        "delete from PyTL_IS_Account_Boarding_SDM where to_date(PROCESS_DATE, 'yyyy-mm-dd') < (sysdate - :DAYS)",
        bind_vars={"DAYS":90}
    )
    stg_conn.commit()
    stg_conn.close()

