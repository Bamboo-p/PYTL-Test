__version__ = "230312.3"
__job_name__ = "PyTL_IS_Account_Boarding_SDM"
__bat_files__ = ["NIC_IS_In_Account_Boarding_SDM.bat", "NIC_IS_Ou_Account_Boarding_SDM.bat"]

print("="*70)
print(f"{__file__=}")
print(f"{__version__=}")
print(f"{__job_name__=}")
print(f"{__bat_files__=}")