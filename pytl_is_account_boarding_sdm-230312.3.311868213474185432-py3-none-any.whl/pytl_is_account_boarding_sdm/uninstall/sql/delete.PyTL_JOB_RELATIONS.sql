/*
* Version history:
* ENG-3781  22-Dec-2021 Denis Kaloshin
* ENG-3781  26-Dec-2021 Denis Kaloshin
*/
set linesize 2000
set serveroutput on
set verify off

declare
    V_JOB_NAME varchar2(255) := 'PyTL_IS_Account_Boarding_SDM';
    V_SQL_TEXT varchar2(32000);
begin
    dbms_output.enable();
    
    V_SQL_TEXT := 'delete from PyTL_JOB_RELATIONS where IN_JOB_ID = '''|| V_JOB_NAME ||''' or OUT_JOB_ID = '''|| V_JOB_NAME ||'''';
    dbms_output.put_line('>>> ' || V_SQL_TEXT);
    execute immediate V_SQL_TEXT;

    V_SQL_TEXT := 'delete from PyTL_JOBS where JOB_ID = '''|| V_JOB_NAME ||'''';
    dbms_output.put_line('>>> ' || V_SQL_TEXT);
    execute immediate V_SQL_TEXT;

    commit;
end;
/
exit;

