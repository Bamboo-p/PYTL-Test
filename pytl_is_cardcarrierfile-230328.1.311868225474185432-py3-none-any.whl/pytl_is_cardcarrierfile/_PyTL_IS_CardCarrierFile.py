""" NIC_IS_Ou_CardCarrierFile

Requirements
------------
pytl-core >= 0.2.7


Parameters
----------
ENV : string
    Specifies path to settings file with database connection and in/out/etc dirs paths.
    Cann be an absolute or relative path, or a file name without extension.
    Mandatory.


#TODO: refactor me
     Input parameters:
     ENV=R:\Test_Env\Env_Parms\Env.parm - ENV - path to the parameters file which incorporates parameters for the interface work: folder paths etc.
     ORG=982 - ORG code, represents banking institute
     CSV_HEADER=CardNumber,ClientName,CardExpiry - common field names used in the target JSON file(s)
     SUB_ARRAY_NAME=CustomizedFields - Object Array name used in the target JSON file(s)

Refactoring
-----------

References
----------
    ENG-3271
    ALMB-357
    ALMB-782
    ALMB-964

Changes
-------
    220218.1 = deniska = ALMB-357: Adoptation for target state deployment
    220427.1 = shalini = ALMB-782: Added characters _- to be considered in ParmValue
    230316.1 = deniska = ALMB-964: Changing approach of columns calculation. Added optional parameters with default values: COLUMNS_QUANTITY=7 DELIMITER=,
    230328.1 = deniska = ALMB-964: Fully rewritten without perl regualar expressions and without saving into temporary directory
"""

########################################################################################################################
print("-"*20 + f" Importing in {__file__} of internal modules is started")
try:
    # Could be imported ONLY if it's run as module
    import_action = "MODULE: from ._params import ("
    from ._params import (
        __params__,
    )
    print(import_action + " == SUCCESS")
    
    # will be excluded after pytl_core 2.9:
    import_action = "MODULE: from ._utils import ("
    from ._utils import (
        load_csv,
        deserialize_dict,
    )
    print(import_action + " == SUCCESS")
except Exception as ex:
    print("#"*20 + f" E%cept1on1 in {__file__}: {import_action} == {ex}")
    try:
        import_action = "NORMAL: from _params import ("
        from _params import (
            __params__,
        )
        print(import_action + " == SUCCESS")
        
        # will be excluded after pytl_core 2.9:
        import_action = "NORMAL: from _utils import ("
        from _utils import (
            load_csv,
            deserialize_dict,
        )
        print(import_action + " == SUCCESS")
        
    except Exception as ex:
        print("#"*20 + f" E%cept1on1 in {__file__}: {import_action} == {ex}")
        raise ex
print("-"*20 + f" internal modules were SUCCESSFULLY imported in {__file__}")
########################################################################################################################

import pytl_core
from pathlib import Path
from n0struct import (
    save_file,
    n0dict,
)

def main(_config: None) -> None:
    # get all files that match the given pattern(file name mask):
    pytl_core.logging.info(f"Looking for '{__params__['INPUT_FN_MASK']}' in '{__params__['SRC_DIR']}'")
    found_files = list(Path(__params__['SRC_DIR']).glob(__params__['INPUT_FN_MASK']))
    for file_i,input_file_path in enumerate(found_files):
        pytl_core.logging.info(f"Found file: {input_file_path}")
        result_json = { "data": [] }
        for parsed_csv_line, original_line in load_csv(input_file_path, delimiter = __params__['DELIMITER'], return_original_line = True):
            pytl_core.logging.debug(f"Original line: {original_line}")
            pytl_core.logging.debug(f"Parsed line: {parsed_csv_line}")
            
            # Check: if the number of fields equals to expected
            if (got_columns_quantity:=len(parsed_csv_line)) != __params__['COLUMNS_QUANTITY']:
                pytl_core.logging.error(f"Record has more fields then expected. Expected {__params__['COLUMNS_QUANTITY']} fields, but got {got_columns_quantity}")
                continue
                
            if not parsed_csv_line[-1].rstrip().endswith(';'):
                pytl_core.logging.error("Record should end with ';' !!!")
                continue
            
            # Use first 3 (in real depends of __params__['CSV_HEADER']) items as independed elements...
            csv_row_into_jsob_item = {
                item_name: parsed_csv_line[i]
                for i,item_name in enumerate(__params__['CSV_HEADER'])
            }
            
            # and put other under node with name __params__['SUB_ARRAY_NAME']
            all_tags_with_value = {}
            for i,item in enumerate(parsed_csv_line[len(__params__['CSV_HEADER']):]):
                only_items_with_value = dict(filter(lambda key_value: key_value[1], deserialize_dict(item).items()))
                all_tags_with_value.update(only_items_with_value)
            
            csv_row_into_jsob_item[__params__['SUB_ARRAY_NAME']] = [
                { 'ParmCode': key, 'ParmValue': value }
                for key,value in all_tags_with_value.items()
            ]
            result_json['data'].append(csv_row_into_jsob_item)
        
        target_json_file_name = Path(__params__['DST_DIR']) /  (str(Path(input_file_path).stem) + __params__['OUTPUT_FN_EXTENSION'])
        count = 0
        while target_json_file_name.exists():
            count += 1
            target_json_file_name = Path(__params__['DST_DIR']) /  (str(Path(input_file_path).stem) + "." + str(count).zfill(3) + __params__['OUTPUT_FN_EXTENSION'])
            if count > 999:
                raise FileExistsError(f"Impossible to create unique file in '{__params__['DST_DIR']}' with name '{Path(input_file_path).stem}' and extension '{__params__['OUTPUT_FN_EXTENSION']}'")
            
        save_file(target_json_file_name, n0dict(result_json).to_json())
        
        # delete source file:
        input_file_path.unlink(missing_ok=True)
        
    if not found_files:
        pytl_core.logging.info(f"No files '{__params__['INPUT_FN_MASK']}' found in '{__params__['SRC_DIR']}'")
