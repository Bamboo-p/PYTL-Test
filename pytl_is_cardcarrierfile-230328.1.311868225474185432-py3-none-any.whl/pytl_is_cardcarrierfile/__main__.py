print("-"*70)
print(f"{__file__=}")

from pathlib import Path
import pytl_core
import pytl_core.pytl_globals as pytl_globals

########################################################################################################################
print("="*20 + f" Importing in {__file__} of internal modules is started")
try:
    # Could be imported ONLY if it's run as module
    import_action = "MODULE: from . import __job_name__"
    from . import __job_name__
    print(import_action + " == SUCCESS")
    
    import_action = "MODULE: from importlib_metadata import version as importlib_metadata_version"
    from importlib_metadata import version as importlib_metadata_version
    print(import_action + " == SUCCESS")
    
    import_action = "MODULE: __version__ = importlib_metadata_version(__job_name__)"
    __version__ = importlib_metadata_version(__job_name__)
    print(import_action + " == SUCCESS")

    import_action = "MODULE: from ._PyTL_IS_CardCarrierFile import main"
    from ._PyTL_IS_CardCarrierFile import main
    print(import_action + " == SUCCESS")
except Exception as ex:
    print("#"*20 + f" E%cept1on1 in {__file__}: {import_action} == {ex}")
    try:
        # Could be imported ONLY if it's run as normal py
        import_action = "NORMAL: from __init__ import ("
        from __init__ import (
            __job_name__,
            __version__,
        )
        print(import_action + " == SUCCESS")
        
        import_action = "NORMAL: from _PyTL_IS_CardCarrierFile import main"
        from _PyTL_IS_CardCarrierFile import main
        print(import_action + " == SUCCESS")
    except Exception as ex:
        print("#"*20 + f" E%cept1on1 in {__file__}: {import_action} == {ex}")
        raise ex
print("="*20 + f" internal modules were SUCCESSFULLY imported in {__file__}")
########################################################################################################################

print("*"*30 + f" {__job_name__} v{__version__}")
print("*"*20 + f" {__name__}")
if __name__ == "__main__":
    config = pytl_globals.config = pytl_core.Config.configure_pytl_core({'JOB_FILE': __file__, 'JOB_NAME': __job_name__})
    pytl_core.logging.debug(f"Config: initialization finished, variable 'pytl_globals.config' is created.")

    try:
        if config.get('LOCK_FILE'):
            config['LOCK_FILE'] = Path(config['LOCK_FILE'])
            config['LOCK_FILE'].parent.mkdir(parents=True, exist_ok=True)
            config['LOCK_FILE'].unlink(missing_ok=True)
            with open(config['LOCK_FILE'], 'wt') as fh:
                pytl_core.logging.debug(f"Lock file '{config['LOCK_FILE']}' is created.")
                fh.write(config['JOB_FILE'])
        pytl_core.logger.org_logging_info(f"******* {__file__}@{__job_name__} v{__version__} is STARTED")
        pytl_core.logging.info("*"*10 + f" execute main(config)")
        main(config)
        pytl_core.logger.org_logging_info(f"******* {__file__}@{__job_name__} v{__version__} is COMPLETED")
    except Exception as ex:
        # it doesn't catch BaseException or the system-exiting exceptions SystemExit, KeyboardInterrupt and GeneratorExit
        print(ex.message, ex.args)
    except:
        # it catches all other exceptions: BaseException or the system-exiting exceptions SystemExit, KeyboardInterrupt and GeneratorExit
        pass
    if config.get('LOCK_FILE'):
        pytl_core.logging.debug(f"Lock file '{config['LOCK_FILE']}' is deleted.")
        config['LOCK_FILE'].unlink(missing_ok=True)
