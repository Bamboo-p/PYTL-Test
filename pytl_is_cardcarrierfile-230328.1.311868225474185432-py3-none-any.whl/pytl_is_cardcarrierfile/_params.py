import pytl_core
import pytl_core.pytl_globals as pytl_globals
# after pytl_core 2.9:
# from n0struct import deserialize_list
########################################################################################################################
# will be excluded after pytl_core 2.9:
print("~"*20 + f" Importing in {__file__} of internal modules is started")
try:
    import_action = "MODULE: from ._utils import deserialize_list"
    from ._utils import deserialize_list
    print(import_action + " == SUCCESS")
except Exception as ex:
    print("#"*20 + f" E%cept1on1 in {__file__}: {import_action} == {ex}")
    try:
        import_action = "NORMAL: from _utils import deserialize_list"
        from _utils import deserialize_list
        print(import_action + " == SUCCESS")
        
    except Exception as ex:
        print("#"*20 + f" E%cept1on1 in {__file__}: {import_action} == {ex}")
        raise ex
print("~"*20 + f" internal modules were SUCCESSFULLY imported in {__file__}")
########################################################################################################################

__params__ = pytl_core.Params({
################################################################################
# Mandatory incoming parameters for each call
        'ENV':                  lambda: pytl_globals.config['ENV'],             # D:\PYTL\NIC\JOBNAME\W4UAT25.PARM

        'ORG':                  lambda: pytl_globals.config.get('ORG_LIST')
                                        or pytl_globals.config.get('ORGLIST')   # 'or' means that empty ORG_LIST is NOT acceptable
                                        or pytl_globals.config['ORG'],          # "982" || "982,320"
# Is used in few of PyTL_IS_SimpleReports/PyTL_IS_XlsReports
        'ORG_LIST':             lambda: __params__['ORG'],
# Is used in most of PyTL_IS_SimpleReports/PyTL_IS_XlsReports/PyTL_IS_EmbosserFiles
        'ORGLIST':              lambda: __params__['ORG'],
################################################################################
# Mandatory parameters specific for job
        'CSV_HEADER':           lambda: __CSV_HEADER
                                        if len(__CSV_HEADER:=deserialize_list(pytl_globals.config['CSV_HEADER'], delimiter = ',')) == 3
                                        else pytl_core.raiser(SyntaxError(f"Mandatory incoming parameter CSV_HEADER must contain 3 items splitted by ',', but received '{pytl_globals.config['CSV_HEADER']}'")),
        'SUB_ARRAY_NAME':       lambda: __SUB_ARRAY_NAME[0]
                                        if len(__SUB_ARRAY_NAME:=deserialize_list(pytl_globals.config['SUB_ARRAY_NAME'], delimiter = ',')) == 1
                                        else pytl_core.raiser(SyntaxError(f"Mandatory incoming parameter SUB_ARRAY_NAME must contain 1 item, but received '{pytl_globals.config['SUB_ARRAY_NAME']}'")),
################################################################################
# Optional parameters
        'DELIMITER':            lambda: pytl_globals.config.get('DELIMITER') or ",",
        'COLUMNS_QUANTITY':     lambda: int(__COLUMNS_QUANTITY) if (__COLUMNS_QUANTITY:=pytl_globals.config.get('COLUMNS_QUANTITY')) and isnumber(__COLUMNS_QUANTITY) else 7,
################################################################################
# Date parameters
        'INPUT_DATE_FORMAT':    lambda: pytl_globals.config.get('INPUT_DATE_FORMAT')
                                        or "%d-%m-%Y",
        'OUTPUT_DATE_FORMAT':   lambda: pytl_globals.config.get('OUTPUT_DATE_FORMAT')
                                        or "%Y%m%d",
        'P_REPORT_DATE':        lambda: pytl_globals.config.get('P_REPORT_DATE')
                                        or date_to_format(date_today(), __params__['INPUT_DATE_FORMAT']),
################################################################################
# File name parameters
        'INPUT_FN_PREFIX':      lambda: __params__['ORG']
                                        if not (__INPUT_FN_PREFIX := pytl_globals.config.get('INPUT_FN_PREFIX'))
                                        else (__INPUT_FN_PREFIX if __INPUT_FN_PREFIX != '.' else ""),
        'INPUT_FN_SEPARATOR':   lambda: ""
                                        if not (__INPUT_FN_SEPARATOR := pytl_globals.config.get('INPUT_FN_SEPARATOR'))
                                        else (__INPUT_FN_SEPARATOR if __INPUT_FN_SEPARATOR != '.' else ""),
        'INPUT_FN_EXTENSION':   lambda: ".csv"
                                        if not (__INPUT_FN_EXTENSION := pytl_globals.config.get('INPUT_FN_EXTENSION'))
                                        else (__INPUT_FN_EXTENSION if __INPUT_FN_EXTENSION != '.' else ""),
        'INPUT_FN_MASK':        lambda: (
                                            __params__['INPUT_FN_PREFIX'] +
                                            __params__['INPUT_FN_SEPARATOR'] +
                                            "*" +
                                            __params__['INPUT_FN_EXTENSION']
                                        )
                                        if not (__INPUT_FN_MASK := pytl_globals.config.get('INPUT_FN_MASK'))
                                        else (__INPUT_FN_MASK if __INPUT_FN_MASK != '.' else ""),
########################################
        'OUTPUT_FN_PREFIX':     lambda: ""
                                        if not (__OUTPUT_FN_PREFIX := pytl_globals.config.get('OUTPUT_FN_PREFIX'))
                                        else (__OUTPUT_FN_PREFIX if __OUTPUT_FN_PREFIX != '.' else ""),
        'OUTPUT_FN_SEPARATOR':  lambda: ""
                                        if not (__OUTPUT_FN_SEPARATOR := pytl_globals.config.get('OUTPUT_FN_SEPARATOR'))
                                        else (__OUTPUT_FN_SEPARATOR if __OUTPUT_FN_SEPARATOR != '.' else ""),
        'OUTPUT_FN_SUFIX':      lambda: date_to_format(to_date(__params__['P_REPORT_DATE'], __params__['INPUT_DATE_FORMAT']), __params__['OUTPUT_DATE_FORMAT'])
                                        if (__OUTPUT_FN_SUFIX := pytl_globals.config.get('OUTPUT_FN_SUFIX')) is None  # Empty OUTPUT_FN_SUFIX is acceptable
                                        else validate_path(__OUTPUT_FN_SUFIX),
        'OUTPUT_FN_EXTENSION':  lambda: ".json"
                                        if not (__OUTPUT_FN_EXTENSION := pytl_globals.config.get('OUTPUT_FN_EXTENSION'))
                                        else (__OUTPUT_FN_EXTENSION if __OUTPUT_FN_EXTENSION != '.' else ""),
        'OUTPUT_FN_MASK':       (
                                    lambda: (
                                                __params__['OUTPUT_FN_PREFIX'] +
                                                __params__['OUTPUT_FN_SEPARATOR'] +
                                                __params__['OUTPUT_FN_SUFIX'] +
                                                __params__['OUTPUT_FN_EXTENSION']
                                            )
                                            if not (__OUTPUT_FN_MASK := pytl_globals.config.get('OUTPUT_FN_MASK'))
                                            else (__OUTPUT_FN_MASK if __OUTPUT_FN_MASK != '.' else "")
                                    ,
                                    True # Don't cache and recalculate each usage because of '{}' is inside OUTPUT_FN_MASK
                                ),
        'OUTPUT_FN_RELATED':    lambda: pytl_globals.config.get('OUTPUT_FN_RELATED') # OUTPUT_FN_RELATED could be as-is, but NOT empty
                                        or __params__['OUTPUT_FN_MASK'],
################################################################################
# Predefined mandatory values
        'JOB_NAME':             lambda: pytl_globals.config['JOB_NAME'],
        'SRC_DIR':              lambda: pytl_globals.config['SRC_DIR'],
        'DST_DIR':              lambda: pytl_globals.config['DST_DIR'],
        'ROUTING_DIR':          lambda: validate_path(pytl_globals.config.get('ROUTING_DIR'), "{ORG}"),
})

