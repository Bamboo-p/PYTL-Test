import typing
from pathlib import Path
# ******************************************************************************
# Will be replaced, when pytl_core will be upgraded till 2.9
# ******************************************************************************
def parse_complex_csv_line(
    line:str,
    delimiter:str = ',',
    process_field:callable = lambda field_value: field_value,  # possible to field_value.strip()
    EOL:str = '\n',
) -> list:
    fields_in_the_row = []
    flag_quotes_in_the_begining = flag_expect_delimiter_or_quotes = False
    field_value = ""
    for offset,ch in enumerate(line.strip(EOL)):
        if ch == delimiter and (flag_quotes_in_the_begining == False or flag_expect_delimiter_or_quotes == True):
            # The next field is started
            fields_in_the_row.append(process_field(field_value))
            flag_quotes_in_the_begining = flag_expect_delimiter_or_quotes = False
            field_value = ""
            continue  # skip delimiter
        elif ch == '"':
            if len(field_value) == 0:
                flag_quotes_in_the_begining = True
                continue  # skip " in the begining of the field
            elif flag_quotes_in_the_begining:
                flag_expect_delimiter_or_quotes = not flag_expect_delimiter_or_quotes # Switch flag_expect_delimiter_or_quotes
                if flag_expect_delimiter_or_quotes == True:
                    # previously flag_expect_delimiter_or_quotes == False, so skip first " in the middle of line
                    continue
                n0print('Got the second ", so save it')
                # previously flag_expect_delimiter_or_quotes == True, so save the second "
        elif flag_expect_delimiter_or_quotes:
            raise ValueError(f"Expected delimiter '{delimiter}' or second '\"', but received '{ch}' in offset {offset} of '{line}'")
        field_value += ch
    fields_in_the_row.append(process_field(field_value)) # Save the last field
    return fields_in_the_row
# ******************************************************************************
def load_csv(
    file_name: str,
    column_names: list = None,
    delimiter: str = ',',
    process_field: typing.Union[callable, None] = None,
    EOL: str = '\n',
    contains_header: typing.Union[bool,str] = False,
    process_line: typing.Union[callable, None] = None,
    skip_empty_lines: bool = True,
    strip_line: typing.Union[bool,callable] = False,
    strip_field: typing.Union[bool,callable] = False,
    return_always_list: bool = False,
    return_original_line: bool = False,
    parse_csv_line: callable = parse_complex_csv_line,
) -> typing.Generator:  # list, typing.Tuple[list, str], dict, typing.Tuple[dict, str]

    if column_names and len(column_names) != len(set(column_names)):
        raise KeyError(f"Column names {column_names} contains not unique names of columns")

    if not callable(process_field):
        if isinstance(strip_field, bool) and strip_field == True:
            process_field = lambda field_value: field_value.strip()
        elif callable(strip_field):
            process_field = strip_field
        else:
            process_field = lambda field_value: field_value

    if not callable(process_line):
        if isinstance(strip_line, bool) and strip_line == True:
            process_line = lambda field_value: field_value.strip()
        elif callable(strip_line):
            process_line = strip_line
        else:
            process_line = lambda line: line
            
    if not isinstance(contains_header, (str, bool)):
        raise ValueError(f"Not expectable value in {contains_header=}. Should be bool or str")

    if not process_line:
        process_line = lambda line_value: line_value
    elif isinstance(process_line, bool) and process_line == True:
        process_line = lambda line_value: line_value.strip()

    with open(file_name, 'rt') as in_file:
        if contains_header:
            while True:  # skip empty lines at the begining of the file
                file_offset = in_file.tell()
                if not (line:=in_file.readline()):
                    return [] # Empty file or file only with spaces
                header_line = process_line(line.rstrip(EOL))
                if header_line:
                    break
            possible_column_names = parse_csv_line(header_line, delimiter, process_field)
            if isinstance(contains_header, str):
                # if contains_header is not boolean, then first line could be header or not
                # to check if the first line is header, check value of first column
                # if it's like expected, then the first line is header
                if possible_column_names[0] != contains_header:
                    in_file.seek(file_offset) # first line is NOT header, re-read first line as data line
                    possible_column_names = None
            else:
                if column_names:
                    if isinstance(contains_header, bool):
                        if set(possible_column_names) != set(column_names):
                            raise KeyError(f"Expected column names {column_names}, but read {possible_column_names}")
                else:
                    if possible_column_names:
                        # Only in case of
                        #   contains_header = "first column name",
                        #   first line contains the header
                        #   column_names = None
                        column_names = possible_column_names

        while True:
            if not (line:=in_file.readline()):
                return None  # EOF
            stripped_line = process_line(line.rstrip(EOL))
            if skip_empty_lines and not stripped_line:
                continue
            field_values = parse_csv_line(stripped_line, delimiter, process_field, EOL)
            if not column_names or return_always_list:
                if return_original_line:
                    yield field_values, stripped_line
                else:
                    yield field_values
            else:
                if return_original_line:
                    yield n0dict(zip(column_names, field_values)), stripped_line 
                else:
                    yield n0dict(zip(column_names, field_values))
# ******************************************************************************
# ******************************************************************************
# ******************************************************************************
def deserialize_list(
                        buffer_str: str,
                        delimiter: str = ";",
                        parse_item = lambda item, item_index, separated_items, previous_items: item,
                        parse_empty = False,
                        default_list_result = None,
) -> list:
    '''
        buffer_str = "ITEM1;ITEM2;ITEM3"
        deserialize_list_of_lists(buffer_str) == ["ITEM1", "ITEM2", "ITEM3"]
    '''
    if not isinstance(buffer_str, str):
        return default_list_result or []

    separated_items = buffer_str.split(delimiter)
    deserialized_list = []
    for item_index,item in enumerate(separated_items):
        if item or parse_empty:
            parsed_item = parse_item(item, item_index = item_index, separated_items = separated_items, previous_items = deserialized_list)
            deserialized_list.append(parsed_item)
    return deserialized_list
# ******************************************************************************
def deserialize_key_value(
                        buffer_str: str,
                        equal_tag: str = "=",
                        parse_key: typing.Callable = lambda key_value, default_key: key_value[0],
# Sample of calling:
#   default_key(key_value, parsed_value)
# Sample of definition:
#   lambda key_value, parsed_value: parsed_value.get('SQL_FILE') if isinstance(parsed_value, dict) else key_value
                        default_key: typing.Union[typing.Callable, typing.Any, None] = None,
                        
                        parse_value: typing.Callable = lambda key_value, default_value: key_value[1],
# Sample of calling:
#   default_value(key_value, parsed_key)
# Sample of definition:
#   lambda key_value, parsed_key: key_value
                        default_value: typing.Union[typing.Callable, typing.Any, None] = None,
                        default_tuple_result = None,
) -> tuple:
    '''
        buffer_str = "TAG1=VALUE1"
        deserialize_key_value(buffer_str) == ("TAG1", "VALUE1")
        buffer_str = "TAG1"
        deserialize_key_value(buffer_str) == ("TAG1", None)
        buffer_str = "VALUE1"
        deserialize_key_value(buffer_str, default_key = "TAG1") == ("TAG1", "VALUE1")
    '''
    if not isinstance(buffer_str, str):
        return default_tuple_result or tuple()

    key_value = buffer_str.split(equal_tag, 1)
    
    parsed_key = None
    parsed_value = None
    if len(key_value) < 2:
        if default_key:
            # key_value == (single_item) -> {default_key: single_item}
            key_value = (
                            parsed_key:=(default_key((key_value[0], None), key_value[0]) if callable(default_key) else default_key),
                            key_value[0]
            )
            # Skip more one manipulation with the key, because of it's already default
            parse_key = lambda key_value, default_key: key_value[0]
        else:
            # key_value == (single_item) -> {single_item: default_value}
            key_value = (
                            key_value[0],
                            parsed_value:=default_value((None, key_value[0]), key_value[0]) if callable(default_value) else default_value
            )
            # Skip more one manipulation with the value, because of it's already default
            parse_value = lambda key_value, default_value: key_value[1]
    parsed_key = parse_key(key_value, (default_key(key_value, key_value[1]) if callable(default_key) else default_key) )
    parsed_value = parse_value(key_value, default_value(key_value, parsed_key) if callable(default_value) else default_value)
    
    return parsed_key, parsed_value
# ******************************************************************************
def deserialize_dict(
                        buffer_str: str,
                        delimiter: str = ";",
# Sample of definition:
#   parse_item = lambda item, item_index, separated_items, previous_items: item
                        parse_item: typing.Union[typing.Callable, None] = None,
                        parse_empty = False,
                        equal_tag: str = "=",
                        parse_key: typing.Callable = lambda key_value, default_key: key_value[0],
                        default_key: typing.Any = None,
                        parse_value: typing.Callable = lambda key_value, default_value: key_value[1],
                        default_value: typing.Any = None,
                        default_dict_result = None,
                        default_list_result = None,
                        default_tuple_result = None,
) -> dict:
    '''
        buffer_str = "TAG1=VALUE1;TAG2=VALUE2"
        deserialize_dict(buffer_str) == {"TAG1": "VALUE1", "TAG2": "VALUE2"}
    '''
    deserialized_list = deserialize_list(
                            buffer_str,
                            delimiter,
                            parse_item = parse_item or (
                                            lambda item, item_index, separated_items, previous_items: 
                                                deserialize_key_value(
                                                    item,
                                                    equal_tag = equal_tag,
                                                    parse_key = parse_key,
                                                    default_key = default_key,
                                                    parse_value = parse_value,
                                                    default_value = default_value,
                                                )
                                         )
                            ,
                            parse_empty = parse_empty,
    )
    deserialized_dict = dict(deserialized_list)
    return deserialized_dict
# ******************************************************************************
def save_file(
                file_path: str,
                lines: typing.Union[tuple, list, dict, str],
                mode: str = 't',
                EOL: str = '\n',
                encoding: str = 'utf-8',
                equal_tag: str = "=",
):
    Path(file_path).parent.mkdir(parents=True, exist_ok=True)

    if isinstance(lines, (list, tuple)):
        output_buffer = EOL.join(lines)
    if isinstance(lines, dict):
        output_buffer = EOL.join([key+equal_tag+lines[key] for key in lines])
    elif isinstance(lines, str):
        output_buffer = lines
    else:
        output_buffer = str(lines)

    if 'b' in mode:
        output_buffer = output_buffer.encode(encoding)

    with open(file_path, 'w'+mode) as out_filehandler:
        out_filehandler.write(output_buffer)
# ******************************************************************************
# ******************************************************************************
# ******************************************************************************