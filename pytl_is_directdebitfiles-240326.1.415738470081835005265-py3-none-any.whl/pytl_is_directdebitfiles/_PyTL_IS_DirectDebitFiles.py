''' NIC_IS_Ou_DirectDebit_Files

???


Requirements
------------
pytl-core >= 0.1.3


Parameters
----------
ENV : string
    Specifies path to settings file with database connection and in/out/etc dirs paths.
    Cann be an absolute or relative path, or a file name without extension.
    Mandatory.

ORG
    Parameter that is used in several XML tags like Sender as Financial institution and for the validation
    Mandatory

INPUT_FN_EXTENSION
    File postfix of the input XML file
    Optional, default value is ".xml"

INPUT_FN_PREFIX
    File name prefix of the input XML file
    Optional, default value is "OIC_Documents_PAY"

INPUT_FN_MASK
    Optional, default value is "{INPUT_FN_PREFIX}*{ORG}*{INPUT_FN_EXTENSION}"

OUTPUT_FN_PREFIX
    File name prefix of the output DSV file
    Optional, default value is "NICDD"

OUTPUT_FN_PREFIX
    File name prefix of the output DSV file
    Optional, default value is "NICUAEDDS"

DELIMITER
    Delimiter between values in output DSV files
    Optional, default value is "|"

MASK_CARD
    Possible values: TRUE, YES, 1 => True, else => False
    Default value is False
    If MASK_CARD is True, then Primary card will be masked in DD file
Refactoring
-----------
# TODO: refactor: output_dir with PytlPath
    output_dir = PytlPath(config['DST_DIR']) / config['JOB_NAME']
    output_dir.clear_dir(deletion_log=True)
    csvDDFileName = output_dir / config['CSV_DD_PREFIX'] + timestamp('%d%m%Y%H%M%S')
    csvUAEDDSFileName = output_dir / config['CSV_UAEDDS_PREFIX'] + timestamp('%d%m%Y%H%M%S')
    config['OUTPUT_FILES'].update({'csvDDFile':csvDDFileName, 'csvUAEDDSFile':csvUAEDDSFileName})


References
----------
    ENG-3241
    ALMAS-73
    ALMAS-452

Changes
-------
    210322.1 = Konstantin Akulshin = ENG-3241: Python implementation for Direct Debit interface
               https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/47d43061ebe1c0478669f11c938202ae2c61c95c#pytl_jobs/NIC/NIC_IS_Ou_DirectDebit_Files.py
    210327.1 = Aliaksandr Tsurko = Updated job_launcher call sequence, messages, returns;
               https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/a88059fcb08ebff27daff198478a03b31e5bd5c7#pytl_jobs/NIC/NIC_IS_Ou_DirectDebit_Files/NIC_IS_Ou_DirectDebit_Files.py
    210329.1 = Konstantin Akulshin = ENG-3241: scr file deletion + REFACTORING
               https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/4209f0a4c904c8060342b28b10b270f25b2946e3#pytl_jobs/NIC/NIC_IS_Ou_DirectDebit_Files.py
    210428.1 = Konstantin Akulshin/Aliaksandr Tsurko = ENG-3241: fixed the field 'AMOUNT' in UAEDDS file
               https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/466e347be3d113b966e5df3aab5fd6e417cedbf7#pytl_jobs/NIC/NIC_IS_Ou_DirectDebit_Files/NIC_IS_Ou_DirectDebit_Files.py
    210428.2 = Konstantin Akulshin/Aliaksandr Tsurko = ENG-3241:  fix for minus in current balance field (2)
               https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/375959f20b324e23a0e910813747a24a7b6245aa#pytl_jobs/NIC/NIC_IS_Ou_DirectDebit_Files/NIC_IS_Ou_DirectDebit_Files.py
    210505.1 = Konstantin Akulshin = ENG-3241: changed padding with zeros to padding with spaces
               https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/9eb726774a3108458ccd0a0610a07db9d3963314#pytl_jobs/NIC/NIC_IS_Ou_DirectDebit_Files/NIC_IS_Ou_DirectDebit_Files.py
    210630.1 = Aliaksandr Tsurko = Added output files paths store and logging; Updated jobs for output files and required pytl core version storage;
               https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/20dd8df2a6becc224a469e6c34403bede20f9143#pytl_jobs/NIC/NIC_IS_Ou_DirectDebit_Files/NIC_IS_Ou_DirectDebit_Files.py
    210825.1 = Aleksander Parfenov = ENG-3806:  excluded the extra jobName level
               https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/03ced979a7c73a635f772ecd1b78e86cee9eb631#pytl_jobs/NIC/NIC_IS_Ou_DirectDebit_Files/NIC_IS_Ou_DirectDebit_Files.py
    211014.1 = deniska = ALMAS-452: Fixed issue with cutting PRIMARY_CARD_NUMBER till 13 digits
    211014.2 = deniska = ALMAS-452: Fixed issue with AttributeError: 'NoneType' object has no attribute 'ljust'
    211014.3 = deniska = ALMAS-452: Rewritten for unification
                                    Renamed optional parameters:
                                        XML_PREFIX        -> INPUT_FN_PREFIX   by default "OIC_Documents_PAY"
                                        CSV_DD_PREFIX     -> OUTPUT_FN_PREFIX  by default "NICDD"
                                        CSV_UAEDDS_PREFIX -> OUTPUT_FN2_PREFIX by default "NICUAEDDS"
                                    Documented:
                                        DELIMITER                              by default "|"
                                    Added optional parameters:
                                        INPUT_FN_EXTENSION                     by default ".xml"
                                        INPUT_FN_MASK                          by default "{INPUT_FN_PREFIX}*{ORG}*{INPUT_FN_EXTENSION}"
                                        OUTPUT_FN_EXTENSION                    by default ".dsv"
                                        OUTPUT_FN2_EXTENSION                   by default ".dsv"
    211014.4 = deniska = ALMAS-452: Using /-method of Path class
    211014.5 = deniska = ALMAS-452: Changing format of output dsv files from fixed width into real delimiter separated values format
    211014.5 = deniska = ALMAS-452: Changing format of output dsv files from fixed width into real delimiter separated values format
    220218.2 = deniska = ALMB-351: Adoptation for target state deployment
    220420.1 = shalini = ALMB-351: Added contract_number and masking parameter for card_number in DD file
    220512.1 = deniska = PRD-20670: Creation of incoming directory for PyTL_IS_DirectDebitFiles before search
    230503.1 = deniska = PRD-23908: Fixing 'NoneType' object is not subscriptable
                                    card_num = dic.get("PRIMARY_CARD_NUMBER")[:6] + 'X' * 6 + dic.get("PRIMARY_CARD_NUMBER")[-4:]
    240103.1 = deniska = PRD-26002: Saving output files with unique names. Disabled clearing of output directories. Removed old comments.
    240216.1 = deniska = PRD-26002: Disabling saving UUEDDS files for wrong files.
    240216.2 = deniska = PRD-26002: ERROR message in case of BROKEN incoming XML files.
    240326.1 = deniska = PRD-26920: Mask PRIMARY_CARD_NUMBER in UAEDDS, in case of MASK_CARD=YES.
                                    New parameter MASK_CONTRACT=YES to mask CONTRACTNUMBER in DD.
'''

from n0struct import *

__version__ = "240326.1"
__job_name__ = "PyTL_IS_DirectDebitFiles"
__bat_files__ = ["NIC_IS_Ou_DirectDebit_Files.bat"]
__params__ = {
# Mandatory
        "ENV":                      lambda: config["ENV"],              # D:\PYTL\NIC\JOBNAME\W4UAT25.PARM
        "ORG":                      lambda: config["ORG"],              # XXX
# Optional
        "INPUT_FN_PREFIX":          lambda: "OIC_Documents_PAY" if not (__INPUT_FN_PREFIX := config.get("INPUT_FN_PREFIX")) else (__INPUT_FN_PREFIX if __INPUT_FN_PREFIX != '.' else ""),
        "INPUT_FN_EXTENSION":       lambda: ".xml" if not (__INPUT_FN_EXTENSION := config.get("INPUT_FN_EXTENSION")) else (__INPUT_FN_EXTENSION if __INPUT_FN_EXTENSION != '.' else ""),
        "INPUT_FN_MASK":            lambda: (__params__['INPUT_FN_PREFIX']()+"*"+__params__['ORG']()+"*"+__params__['INPUT_FN_EXTENSION']()) if not (__INPUT_FN_MASK := config.get("INPUT_FN_MASK")) else (__INPUT_FN_MASK if __INPUT_FN_MASK != '.' else ""),

        "OUTPUT_FN_PREFIX":         lambda: "NICDD" if not (__OUTPUT_FN_PREFIX := config.get("OUTPUT_FN_PREFIX")) else (__OUTPUT_FN_PREFIX if __OUTPUT_FN_PREFIX != '.' else ""),
        "OUTPUT_FN_EXTENSION":      lambda: ".dsv" if not (__OUTPUT_FN_EXTENSION := config.get("OUTPUT_FN_EXTENSION")) else (__OUTPUT_FN_EXTENSION if __OUTPUT_FN_EXTENSION != '.' else ""),

        "OUTPUT_FN2_PREFIX":        lambda: "NICUAEDDS" if not (__OUTPUT_FN2_PREFIX := config.get("OUTPUT_FN2_PREFIX")) else (__OUTPUT_FN2_PREFIX if __OUTPUT_FN2_PREFIX != '.' else ""),
        "OUTPUT_FN2_EXTENSION":     lambda: ".dsv" if not (__OUTPUT_FN2_EXTENSION := config.get("OUTPUT_FN2_EXTENSION")) else (__OUTPUT_FN2_EXTENSION if __OUTPUT_FN2_EXTENSION != '.' else ""),

        "DELIMITER":                lambda: "|" if not (__DELIMITER := config.get("DELIMITER")) else (__DELIMITER if __DELIMITER != '.' else ""),
# Precalculated values
        "JOB_NAME":                 lambda: config["JOB_NAME"],
        "SRC_DIR":                  lambda: config["SRC_DIR"],
        "DST_DIR":                  lambda: config["DST_DIR"],
        "MASK_CARD":                lambda: False if not (__MASK_CARD := config.get('MASK_CARD', ""))
                                            else (
                                                True if __MASK_CARD.upper() in ("TRUE", "YES", "1")
                                                else False
                                            ),
        "MASK_CONTRACT":            lambda: False if not (__MASK_CONTRACT := config.get('MASK_CONTRACT', ""))
                                            else (
                                                True if __MASK_CONTRACT.upper() in ("TRUE", "YES", "1")
                                                else False
                                            ),
        'CREATE_EMPTY_REPORT':      lambda: validate_bool(config.get('CREATE_EMPTY_REPORT'), True),
}

import pytl_core
import logging
from pathlib import Path
import fnmatch
import lxml
import datetime
import csv

def main():
    # initialize job parameters
    logging.info("*************************")

    path = Path(__params__['SRC_DIR']())
    path.mkdir(parents=True, exist_ok=True)
    xmlFileMask = path / __params__['INPUT_FN_MASK']()

    logging.info(f"Input path is used: {path}")
    logging.info(f"xml file mask is used: {xmlFileMask}")

    # get all files that match the given pattern(file name mask)
    xmlFiles = (fl for fl in path.iterdir() if fl.is_file() and fnmatch.fnmatch(fl, xmlFileMask))
    for xmlFile in xmlFiles:
        logging.info(f"Found matched file name {xmlFile}")
        # Check whether XML file with the designated name exists or not
        if Path(xmlFile).exists():
            logging.info(f'Existence of the file {xmlFile} is approved')
            required_tags = {}
            required_tags_array = []

            with open(xmlFile, 'r') as srcFile:
                xml = srcFile.read().encode("UTF-8")
            root = lxml.objectify.fromstring(xml)

            # create an array with all required for the future CSV files data
            for appt in root.getchildren():      # below DocFile
                if appt.tag.upper() == 'DOCLIST':
                    for elem in appt.getchildren():  # below DocList
                        if elem.tag.upper() == 'DOC':
                            for doc_elem in elem.getchildren():  # below Doc
                                if doc_elem.tag.upper() == 'ORIGINATOR':
                                    required_tags['CONTRACTNUMBER'] = str(doc_elem.ContractNumber)
                                if doc_elem.tag.upper() == 'DESTINATION':
                                    required_tags['MEMBERID'] = doc_elem.MemberId
                                    required_tags['INSTITUTION'] = str(doc_elem.InstInfo.Institution)
                                if doc_elem.tag.upper() == 'TRANSACTION':
                                    required_tags['AMOUNT'] = '{:0>12d}'.format(int('{:.2f}'.format(float(doc_elem.Amount)).replace('.', '')))

                                    for parms in doc_elem.Extra.AddData.getchildren():  # walk through all parm tags in Doc
                                        if parms.ParmCode.text.upper() == 'PRIMARY_CARD_NUMBER'\
                                                or parms.ParmCode.text.upper() == 'DD_NUM'\
                                                or parms.ParmCode.text.upper() == 'DUE_DATE'\
                                                or parms.ParmCode.text.upper() == 'CURRENT_BALANCE'\
                                                or parms.ParmCode.text.upper() == 'DDS_REFNUM'\
                                        :
                                            logging.debug(f"Adding {parms.ParmCode.text.upper()} to the Tag Dictionary")
                                            required_tags[parms.ParmCode.text.upper()] = '{:.2f}'.format(float(parms.Value.text)).replace('.', '') if parms.ParmCode.text.upper() == 'CURRENT_BALANCE' else parms.Value.text

                            logging.debug(required_tags)
                            required_tags_array.append(required_tags) # add created and filled dictionary to dict_array
                            logging.debug("Data from the created dictionary added to the Dic Array object.")
                            required_tags = {}
                            logging.debug("Dictionary is emptied.")
            # Action after walking through the XML tree:
            logging.debug("Required tags array grabbed from XML file:")
            logging.debug(required_tags_array)

            '''
               So as we've read, input XML file we are supposed to create two types of output csv files:
                 1) DD file (MemberID = 'PAY' + ORG-parameter)
                 2) UAEDDS file (MemberID = 'UAEDDS')
            '''
            outputPath = Path(__params__['DST_DIR']())
            logging.info(f"Output path is used: {outputPath}")
            # Check whether the target folder exists and create it if doesn't:
            Path(outputPath).mkdir(parents=True, exist_ok=True)

            # [*] begin 240103.1 = deniska = PRD-26002: Saving output files with unique names. Disabled clearing of output directories. Removed old comments.
            timestamp = datetime.datetime.now()
            for i in range(3600):
                csvDDFileName = outputPath / (__params__['OUTPUT_FN_PREFIX']() + timestamp.strftime('%d%m%Y%H%M%S') + __params__['OUTPUT_FN_EXTENSION']())
                csvUAEDDSFileName = outputPath / (__params__['OUTPUT_FN2_PREFIX']() + timestamp.strftime('%d%m%Y%H%M%S') + __params__['OUTPUT_FN2_EXTENSION']())
                if not csvDDFileName.exists() and not csvUAEDDSFileName.exists():
                    break
                else:
                    timestamp += datetime.timedelta(seconds=1)
            else:
                raise FileExistsError(f"Impossible to generate unique output file names: {csvDDFileName}, {csvUAEDDSFileName}")
            # [*] end   240103.1 = deniska = PRD-26002: Saving output files with unique names. Disabled clearing of output directories. Removed old comments.


            # [-] begin 240103.1 = deniska = PRD-26002: Saving output files with unique names. Disabled clearing of output directories. Removed old comments.
            '''
            # Empty the target directory before writing there:
            for file in Path(outputPath).iterdir():
                file.unlink(missing_ok=True)
            '''
            # [*] end   240103.1 = deniska = PRD-26002: Saving output files with unique names. Disabled clearing of output directories. Removed old comments.

            # write DDFile:
            unexpectable_records = 0
            dd_records = 0
            uae_records = 0
            with open(csvDDFileName, 'w', newline='') as csvDD, open(csvUAEDDSFileName, 'w', newline='') as csvUAE:
                ddWriter = csv.writer(csvDD, delimiter = __params__['DELIMITER']())
                uaeDDSWriter = csv.writer(csvUAE, delimiter = __params__['DELIMITER']())
                
                for dic in required_tags_array:
                    if dic.get("INSTITUTION") == __params__['ORG']():
                        if dic.get("MEMBERID") == 'PAY'+__params__['ORG']():
                            card_num = dic.get("PRIMARY_CARD_NUMBER", "")
                            contract_num = dic.get("CONTRACTNUMBER", "")
                            if __params__['MASK_CARD']():
                                if card_num and len(card_num) >= 11:
                                    card_num = card_num[:6] + 'X' * (len(card_num) - 10) + card_num[-4:]
                                if contract_num and len(contract_num) >= 11:
                                    contract_num = contract_num[:6] + 'X' * (len(contract_num) - 10) + contract_num[-4:]

                            ddWriter.writerow([
                                card_num,
                                dic.get("AMOUNT").replace("-", "").lstrip("0"),
                                dic.get("DD_NUM"),
                                dic.get("DUE_DATE"),
                                dic.get("CURRENT_BALANCE").replace("-", ""),
                                contract_num.rjust(19,"0")
                            ])
                            dd_records+=1
                        elif dic.get("MEMBERID") == "UAEDDS":
                            card_num = dic.get("PRIMARY_CARD_NUMBER", "")
                            if __params__['MASK_CARD']():
                                if card_num and len(card_num) >= 11:
                                    card_num = card_num[:6] + 'X' * (len(card_num) - 10) + card_num[-4:]
                                    
                            uaeDDSWriter.writerow([
                                card_num,
                                dic.get("DDS_REFNUM") or "",
                                dic.get("AMOUNT").replace("-", "").lstrip("0")
                            ])
                            uae_records += 1
                        else:
                            logging.info(f"{dic} has not expected {dic.get('MEMBERID')}, so skipped")
                            unexpectable_records += 1
                    else:
                        logging.info(f"{dic} is not {__params__['ORG']()}, so skipped")
                        unexpectable_records += 1

            # delete empty destination files:
            logging.info(f"{dd_records} records were inserted into {csvDDFileName}")
            if not __params__['CREATE_EMPTY_REPORT']() and not dd_records:
                logging.info(f"Empty {csvDDFileName} is deleted")
                csvDDFileName.unlink(missing_ok=True)
            logging.info(f"{uae_records} records were inserted into {csvUAEDDSFileName}")
            if not __params__['CREATE_EMPTY_REPORT']() and not uae_records:
                logging.info(f"Empty {csvUAEDDSFileName} is deleted")
                csvUAEDDSFileName.unlink(missing_ok=True)
                
            # delete source file:
            if not unexpectable_records:
                xmlFile.unlink(missing_ok=True)
            else:
                xmlFile.rename(xmlFile2 := xmlFile.parent / ("$BROKEN$." + xmlFile.name))
                logging.error(f"Broken incoming file {xmlFile} is renamed into {xmlFile2}: {unexpectable_records} unexpectable records")
                
        # if XML file wasn't found we do nothing but writing into the log
        else:
            logging.info('[INFO]: File {} wasn\'t not found'.format(xmlFile))


def _main():
    global cfg, config
    cfg = config = pytl_core.Config.configure_pytl_core({'JOB_FILE': __file__, 'JOB_NAME': __job_name__})
    logging.debug(f"Config: initialization finished, 'config' and 'cfg' variables were created.")
    logging.info(f"Starting {Path(__file__).stem} python job")
    main()
    logging.info(f"{Path(__file__).stem} python job is FINISHED!")

