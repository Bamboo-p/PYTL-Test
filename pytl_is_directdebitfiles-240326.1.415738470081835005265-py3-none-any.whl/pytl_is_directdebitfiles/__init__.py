import os
import sys

sys.path.insert(0, my_dir:=os.path.split(os.path.abspath(__file__))[0])
from _PyTL_IS_DirectDebitFiles import __version__
from _PyTL_IS_DirectDebitFiles import __job_name__
from _PyTL_IS_DirectDebitFiles import __bat_files__

print(f"{__version__=}")
print(f"{__job_name__=}")
print(f"{__bat_files__=}")
