''' NIC_IS_Ou_EmbosserFile

???


Requirements
------------
pytl-core >= 0.1.3


Parameters
----------
ENV : string
    Specifies path to settings file with database connection and in/out/etc dirs paths.
    Cann be an absolute or relative path, or a file name without extension.
    Mandatory.


#TODO: refactor me
    ENV=R:\Test_Env\Env_Parms\Env.parm ORGLIST=982,100 SRC_FILE_REFIX=_NORMAL_ CSV_PREFIX=NIC_EMBOSSER_FILE_ DELIMITER=|

Refactoring
-----------

# TODO: refactor: output_dir with PytlPath
    output_dir = PytlPath(config['DST_DIR']) / config['JOB_NAME']
    output_dir.clear_dir(deletion_log=True)

# TODO: refactor: output_file_path
    datenow = timestamp()
    output_file_name = f"{v_org}_config['CSV_PREFIX']{datenow.format('%d%m%Y%H%M%S%f')[:-3]}.txt"
    output_file_path = output_dir / output_file_name
    output_file_path.add_to_config('OUTPUT_FILES', 'second_field_name_if_required')




References
----------
    ENG-3262

History
-------
    000000.0 = ??????? = Initial version
    210926.1 = deniska = ALMAS-416: Unification of loading, fixing defect with get_value(), renamed SRC_FILE_REFIX into INPUT_FN_SUFIX, renamed CSV_PREFIX into OUTPUT_FN_PREFIX
    220418.1 = deniska = OPKSAIC-3394: Adopted for Target State Deployment (TSD) without any other changes
    230221.1 = DenisIu = OPKSAIC-5062: Fix defect with None values
    230707.1 = deniska = OPKSAIC-5428: Fix made based on KSA production baseline + 230221.1
    230727.1 = Shalini = OPKSAIC-5509: Added ability to mask CARD NUMBER
    240308.1 = deniska = PRD-26678: fixed issues with commas in the XML file
    240515.1 = deniska = PRD-27277: implemented new parameter ENCODING (by default 'utf-8'), which allowes to process any encoding
'''
'''
# [-][begin] 210926.1 = deniska = ALMAS-416
from pytl_core.job_launcher import *
job_launcher(config) # reassign control
# [-][end]   210926.1 = deniska = ALMAS-416
'''

try:
    # Could be imported ONLY if it's run as module
    from . import __job_name__
except:
    # Could be imported ONLY if it's run as normal py
    from __init__ import __job_name__

# [+][begin] 210923.2 = deniska = ALMAS-416
__params__ = {
# Mandatory
        "ENV":                      lambda: config["ENV"],              # D:\PYTL\NIC\JOBNAME\W4UAT25.PARM
        "ORG":                      lambda: config["ORG"],              # XXX
    # for rows in ows_connection.execute_select_batch(statement=sql_text, bind_vars={"ORGLIST":config.get("ORGLIST")}):
        "ORGLIST":                  lambda: config["ORGLIST"],
# # Optional
        # "OUTPUT_FN_SPACE":          lambda: "_" if not (__OUTPUT_FN_SPACE := config.get("OUTPUT_FN_SPACE")) else (__OUTPUT_FN_SPACE if __OUTPUT_FN_SPACE != '.' else ""),
        # "OUTPUT_FN_SEPARATOR":      lambda: "" if not (__OUTPUT_FN_SEPARATOR := config.get("OUTPUT_FN_SEPARATOR")) else (__OUTPUT_FN_SEPARATOR if __OUTPUT_FN_SEPARATOR != '.' else ""),
        # "OUTPUT_FN_PREFIX":         lambda: ("OLTLCM" + __params__['OUTPUT_FN_SEPARATOR']()) if not (__OUTPUT_FN_PREFIX := config.get("OUTPUT_FN_PREFIX")) else (__OUTPUT_FN_PREFIX if __OUTPUT_FN_PREFIX != '.' else ""),
        # "OUTPUT_FN_PREFIX":         lambda: "XADVAPL" if not (__OUTPUT_FN_PREFIX := config.get("OUTPUT_FN_PREFIX")) else (__OUTPUT_FN_PREFIX if __OUTPUT_FN_PREFIX != '.' else ""),
        # "OUTPUT_FN_EXTENSION":      lambda: ".txt" if not (__OUTPUT_FN_EXTENSION := config.get("OUTPUT_FN_EXTENSION")) else (__OUTPUT_FN_EXTENSION if __OUTPUT_FN_EXTENSION != '.' else ""),
        "OUTPUT_FN_SEPARATOR":      lambda: "_" if not (__OUTPUT_FN_SEPARATOR := config.get("OUTPUT_FN_SEPARATOR")) else (__OUTPUT_FN_SEPARATOR if __OUTPUT_FN_SEPARATOR != '.' else ""),
    # src_file_mask = str(path) + "\\" + str(v_org) + config.get("SRC_FILE_REFIX") + "*"
        "INPUT_FN_SUFIX":          lambda: (__params__['OUTPUT_FN_SEPARATOR']() + "NORMAL" + __params__['OUTPUT_FN_SEPARATOR']()) if not (__INPUT_FN_SUFIX := config.get("INPUT_FN_SUFIX")) else (__INPUT_FN_SUFIX if __INPUT_FN_SUFIX != '.' else ""),
    # output_file_name = str(output_path) + "\\" + str(v_org) + "_" + config.get("CSV_PREFIX") + datenow.strftime('%d%m%Y%H%M%S%f')[:-3] + ".txt"
        "OUTPUT_FN_PREFIX":         lambda: ("NIC_EMBOSSER_FILE" + __params__['OUTPUT_FN_SEPARATOR']()) if not (__OUTPUT_FN_PREFIX := config.get("OUTPUT_FN_PREFIX")) else (__OUTPUT_FN_PREFIX if __OUTPUT_FN_PREFIX != '.' else ""),
    # header_2b_written += str(col).ljust(max_lengths[col], ' ') + config.get("DELIMITER")
        "DELIMITER":                lambda: config["DELIMITER"],
# # Parameters from file config["ENV"]
# # Precalculated values
    # logging.info(f"Starting {config.get('JOB_NAME')} python job on {datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        "JOB_NAME":                 lambda: config["JOB_NAME"],
    # path = Path(config.get("SRC_DIR"))
        "SRC_DIR":                  lambda: config["SRC_DIR"],
    # output_path = Path(config.get("DST_DIR"))
        "DST_DIR":                  lambda: config["DST_DIR"],
    # temp_path = Path(config.get("TEMP_DIR"))
        "TEMP_DIR":                 lambda: config["TEMP_DIR"],
    # ows_connection = Connection(config.get('DB_W4C_SRC_WLTURL'))
        "DB_W4C_SRC_WLTURL":        lambda: config["DB_W4C_SRC_WLTURL"],
    # sql_text = utils.load_statement_from_file(config.get('SQL_DIR') + "\\" + config.get('JOB_NAME') + "_get_inst_names.sql")
        "SQL_DIR":                  lambda: config["SQL_DIR"],
# [+][begin]   230727.1 = Shalini = OPKSAIC-5509
        'MASK_COLUMNS':             lambda: [ item for item in serialized_list.split(',')] \
                                            if (serialized_list:= config.get('MASK_COLUMNS')) \
                                            else [],
        'MASK_PATTERN':             lambda: [re.compile("([2-6,8-9][0-9]{5})([0-9]{4,9})([0-9]{4})"), r"\1******\3"]
                                            if not (__MASK_PATTERN := config.get('MASK_PATTERN', ""))
                                            else [re.compile((__MASK_PATTERNS := __MASK_PATTERN.split('=',1))[0]), __MASK_PATTERNS[1]],
# [+][end]   230727.1 = Shalini = OPKSAIC-5509
        "ENCODING":                lambda: config.get('ENCODING', "utf-8"),
}
from n0struct import *
# [+][end]   210923.2 = deniska = ALMAS-416

import pandas as pd

def main():
    # initialize job parameters and define functions
    logging.info("*".rjust(80,"*"))

    logging.info(f"Starting {__params__['JOB_NAME']()} python job on {datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")

    def has_DataElement_Value_tag_field_number(text, delimiter, field_num):
        return bool(text.split(delimiter)+1 == field_num)

    def has_illegal_char(str, check=re.compile("[^a-zA-Z0-9 _;:.,\(\)\-+\r\n]").search):
        return bool(check(str))

    '''
    # [-][begin] 210926.1 = deniska = ALMAS-416
    # function that returns value from key=value; pairs
    # parameter is the key of the desired value
    def get_value(source_str, key):
        return re.search(key+"=(.*?);", source_str).group(1) if re.search(key+"=(.*?);", source_str) != None else ''
    def get_value_delimited(source_str, side):
        if side == "DataElement":
            ret_value = re.search("([a-zA-Z0-9]+):[a-zA-Z0-9]*", source_str).group(1) if re.search("([a-zA-Z0-9]+):[a-zA-Z0-9]*", source_str) != None else ''
        elif side == "DataElement_Value_tag":
            ret_value = re.search("[a-zA-Z0-9]+:([a-zA-Z0-9]*)", source_str).group(1) if re.search("[a-zA-Z0-9]+:([a-zA-Z0-9]*)", source_str) != None else ''
        else:
            ret_value = "ERROR in get_value_delimited"
        return ret_value
    # [-][end]   210926.1 = deniska = ALMAS-416
    '''
    # [+][begin] 210926.1 = deniska = ALMAS-416
    def pairs_to_dict(source_str: str, pairs_delimiter: str = ';', keyvalue_delimiter: str = '=') -> dict:
        '''
            convert string with list of pairs key=value:
                "{key1}{keyvalue_delimiter}{value1}[{pairs_delimiter}{key2}{keyvalue_delimiter}{value2}[...{pairs_delimiter}{key3}{keyvalue_delimiter}{value3}]]"
                Sample:
                    "key1=value1;key2=value2;key3=value3"
            into dictionary:
                {
                    "key1": "value1",
                    "key2": "value2",
                    ...
                    "key3": "value3"
                }

            default values:
                keyvalue_delimiter: '='
                pairs_delimiter:    ';'
        '''
        # n0debug("source_str")
        got_dict = {}
        for pair in source_str.split(pairs_delimiter):
            if (pair:=pair.strip()):
                key, value = pair.split(keyvalue_delimiter, 1)
                got_dict.update({key.strip(): value.strip()})
        return got_dict
    def get_key_from_pair(source_str: str, keyvalue_delimiter: str = ':') -> str:
        '''
            return key from {key}{keyvalue_delimiter}{value}
            default values:
                keyvalue_delimiter: ':'
        '''
        key, value = source_str.split(keyvalue_delimiter, 1)
        return key.strip()
    def get_value_from_pair(source_str: str, keyvalue_delimiter: str = ':') -> str:
        '''
            return value from {key}{keyvalue_delimiter}{value}
            default values:
                keyvalue_delimiter: ':'
        '''
        key, value = source_str.split(keyvalue_delimiter, 1)
        return value.strip()
    # [+][end]   210926.1 = deniska = ALMAS-416


    # Path for input Dir
    path = Path(__params__['SRC_DIR']())
    logging.info(f"Input path is used: {path}")

    # Path for Output dir
    output_path = Path(__params__['DST_DIR']())
    logging.info(f"Output path is used: {output_path}")

    # ********************  Output Dir preparation ****************************
    # Check whether the target folder exists and create it if doesn't:
    Path(output_path).mkdir(parents=True, exist_ok=True)
    # Empty the target directory before writing there:
    for file in Path(output_path).iterdir():
        file.unlink(missing_ok=True)
        logging.info(f"Old file {file} deleted.")

    # ********************  Temp Dir preparation ******************************
    temp_path = Path(__params__['TEMP_DIR']())
    # Create Temp folder if it doesn't exist:
    Path(temp_path).mkdir(parents=True, exist_ok=True)
    # Empty the Temp directory before writing there:
    for file in Path(temp_path).iterdir():
        file.unlink(missing_ok=True)
        logging.info(f"Old Temp file {file} deleted.")

    '''
       new reqs: we need to generate aggregated report of the current interface run:
                 required fields: * Bank Name
                                  * File Name
                                  * Product
                                  * Count
                                  * Card Action (New/Renew/PIN only etc.)
    '''
    # Opening connection to OWS for all further queries:
    ows_connection = Connection(__params__['DB_W4C_SRC_WLTURL']())

    # get Bank Names:
    # NIC_IS_Ou_EmbosserFile_get_inst_names.sql
    sql_text = utils.load_statement_from_file(__params__['SQL_DIR']() + "\\" + __params__['JOB_NAME']() + "_get_inst_names.sql")
    orgs = {} # a dictionary of pair: ORG and it's Name
    for rows in ows_connection.execute_select_batch(statement=sql_text, bind_vars={"ORGLIST":__params__['ORGLIST']()}):
        for row in rows:
            orgs[row.get("BRANCH_CODE")] = row.get("NAME")
            logging.debug(str(orgs[row.get("BRANCH_CODE")]))


    '''
        new reqs: ORG may be designated as a list separated by comma
    '''
    for v_org in (__params__['ORGLIST']()).split(","):
        logging.info(f"Start processing {v_org} institute (ORG)")
        logging.info(f"Let check custom field settings for the report for ORG={v_org}")

        '''
            new reqs: we'll keep custom fields settings in the DB in sy_handbook table
            So required fields will be checked and loaded all the time
            But Custom fields will be added and checked only if they exist within the settings DB
        '''
        sql_text = utils.load_statement_from_file(__params__['SQL_DIR']() + "\\" + __params__['JOB_NAME']() + ".sql")
        v_cnt = 0 # batch counter
        v_rec_cnt = 0 # records counter
        v_batch_size = 50000
        v_custom_field_settings = {}
        v_unique_tags = set()

        # let's create a dictionary of Custom fields settings:
        for rows in ows_connection.execute_select_batch(statement=sql_text,
                                                         batch_size=v_batch_size,
                                                         bind_vars={ 'ORG': v_org},
                                                         pd_mode=False):
            # get every row from the previously retrieved batch (technical)
            for row in rows:
                v_custom_field_settings[row["NAME_IN_REPORT"]] = row["TAG_AND_ATTR"]

                # fill unique tag set
                upper_tag = get_key_from_pair(row["TAG_AND_ATTR"]).upper()
                # n0debug_calc(upper_tag, "MODIFIED:upper_tag")
                if upper_tag in v_unique_tags:
                    continue
                else:
                    v_unique_tags.add(upper_tag)
            logging.debug("Unique tags from DB settings:" + str(v_unique_tags))

        '''
           At the end of this interface work we need to generate a report with the aggregated data (aggregated report)
           So let's create a temporary file with the designated header
        '''
        v_agg_temp_file = str(temp_path) + "\\" + str(v_org) + ".agg.csv" # TODO: + Path(xml_file).stem
        with open(v_agg_temp_file, "wt", encoding=__params__['ENCODING']()) as agg_temp:
            agg_temp.write("BANK NAME;FILE NAME;PRODUCT NAME;CARD ACTION\n")

        # Input dir searching:
        src_file_mask = str(path) + "\\" + str(v_org) + __params__['INPUT_FN_SUFIX']() + "*"
        logging.info(f"src file mask is used: {src_file_mask}")

        # get all files that match the given pattern(file name mask)
        xml_files = (fl for fl in path.iterdir() if fl.is_file() and fnmatch.fnmatch(fl, src_file_mask))

        for xml_file in xml_files:
            logging.info(f"Found matched file name {xml_file}")
            # Check whether src file with the designated name exists or not
            if Path(xml_file).exists():
                logging.info(f'Existence of the file {xml_file} is approved')

                # If xml input file is empty we delete it without further processing
                if Path(xml_file).stat().st_size==0 :
                    logging.warning(f"file {xml_file} is empty. Skipping this file from further processing.")
                    # delete source file:
                    xml_file.unlink(missing_ok=True)
                    continue

                '''
                  New Requirements:
                    Input file got XML format (not comma delimited)
                    So to minimize further development will create temporary file similar to the former input comma delimited one
                '''

                ''' we need to remove namespace references from he source XML file
                    so we'll work with the temporary file (xml_temp_file) afterwards
                '''
                xml_temp_file = str(temp_path) + '\\' + Path(xml_file).stem + '.xml.tmp'
                with open(xml_file, 'rt', encoding=__params__['ENCODING']()) as xml_source, open (xml_temp_file, 'at', encoding=__params__['ENCODING']()) as xml_target:
                    for line in xml_source:
                        xml_target.write(re.sub(' xmlns="[^"]+"', '', line, count=1))

                # we create interim file to store data received from XML
                rep_temp_file = str(temp_path) + '\\' + Path(xml_file).stem + '.src.tmp'
                with open(rep_temp_file, 'at', encoding=__params__['ENCODING']()) as interim_tmp:
                    # creating a header
                    header = "CARD NUMBER|CARD PRODUCTION TYPE|EXPIRY DATE|POS SERVICE CODE|CARD NAME|COMPANY NAME|" \
                             + "CLIENT MAILING ADDRESS LINE 1|CLIENT MAILING ADDRESS LINE 2|CLIENT MAILING ADDRESS LINE 3|" \
                             + "CLIENT MAILING ADDRESS LINE 4|CLIENT MAILING ADDRESS CITY|CLIENT MAILING ADDRESS COUNTRY"

                    # add Custom field name to the header:
                    for key in sorted(v_custom_field_settings.keys()):
                        header += '|' + key
                    header += '\n'

                    #write the header into temp file
                    interim_tmp.write(header)

                # walk through the XML tree and create a temp file with all required data for further processing
                with open(xml_temp_file, 'rt', encoding=__params__['ENCODING']()) as src_xml_file:
                    xml = src_xml_file.read().encode("UTF-8")
                root = objectify.fromstring(xml) # <PinManagementFile> level
                for ApplicationDataNotification in root.PMJobs.GPMessage.GPBody.getchildren(): # getting all ApplicationDataNotification (Looping tag) tags and its underlying tags
                    # dictionary to store data from XML to report it later
                    report_data = {# Unique Data part:
                                     "EXPIRY DATE": "", "POS SERVICE CODE":"", "CARD NAME":"", "COMPANY NAME":"","CLIENT MAILING ADDRESS LINE 1":"", "CLIENT MAILING ADDRESS LINE 2":"", "CLIENT MAILING ADDRESS LINE 3":""
                                    , "CLIENT MAILING ADDRESS LINE 4":"", "CLIENT MAILING ADDRESS CITY":"", "CLIENT MAILING ADDRESS COUNTRY":""
                                   # Data which exists in both XML sections: Common and PerCRN
                                   , "CARD NUMBER":"", "CARD PRODUCTION TYPE":"", "CARD ACTION TYPE":"", "REPLACEMENT FLAG":""
                                   # Part for one Custom but required for Agg report dict member
                                   , "PRODUCT NAME":""
                    }
                    # add empty dictionary elements for the Custom fields:
                    for key in v_custom_field_settings.keys():
                        report_data[key] = ""

                    # some data exists within two XML sections: Common and PerCRN
                    # so we have to take them both and to use coalesce to calculate the result (variables are required):
                    v_card_number_crn = ""
                    v_card_production_type_crn = ""
                    v_card_action_type_crn = ""
                    v_replacement_flag_crn = ""
                    v_card_number_common = ""
                    v_card_production_type_common = ""
                    v_card_action_type_common = ""
                    v_replacement_flag_common = ""

                    logging.debug("BatchID:"+ApplicationDataNotification.attrib['BatchID'])
                    for appl in ApplicationDataNotification.getchildren(): # below ApplicationDataNotification tag
                        if appl.tag.upper() == "APPLICATIONDATAPERCRN" and appl.ApplicationData.AID.attrib["Order"] == "1":
                            for dataset in appl.ApplicationData.ICCData.getchildren(): # below ICCData tag
                                # Compulsory Part:
                                if dataset.attrib["Name"] == "ADTA":
                                    for data in dataset.getchildren():
                                        if data.get("DataElement") == "PAND":
                                            v_card_number_crn = data.get("Value")
                                        if data.get("DataElement") == "PRTP":
                                            v_card_production_type_crn = data.get("Value")
                                        #Removed as part of ALMAS-350
                                        #if data.get("DataElement") == "PRDP":
                                            #v_card_action_type_crn = get_value(data.get("Value"), "ACT_TYPE")
                                            #v_replacement_flag_crn = get_value(data.get("Value"), "CARD_REPL")
                                # Custom part (is taken from DB):
                                if dataset.attrib["Name"] == "ADDI":
                                    # Get all Data tags below <DataSet Name="ADDI">:
                                    for data in dataset.getchildren():
                                        # check whether current DataElement belong to the set of unique DataElements mentioned in "DB Setings"
                                        if data.get("DataElement") in v_unique_tags:
                                            # [+][begin] 210926.1 = deniska = ALMAS-416
                                            pairsValue = pairs_to_dict(data.get("Value"))
                                            # [+][end]   210926.1 = deniska = ALMAS-416
                                            # Go through all settings from "DB Settings"
                                            for key, value in v_custom_field_settings.items():
                                                # if DataElement of the current 'Data' tag equals to one tag from "DB settings" we will ask for the tag_value (get_value function)
                                                '''
                                                # [-][begin] 210926.1 = deniska = ALMAS-416
                                                if get_value_delimited(value, "DataElement") == data.get("DataElement"):
                                                    report_data[key]= get_value(data.get("Value"), get_value_delimited(value, "DataElement_Value_tag"))
                                                    # logging.debug(key+"="+report_data[key])
                                                # [-][end]   210926.1 = deniska = ALMAS-416
                                                '''
                                                # [+][begin] 210926.1 = deniska = ALMAS-416
                                                # n0debug_calc(get_key_from_pair(value), f"MODIFIED: key from '{value}'")
                                                # n0debug_calc(data.get("DataElement"), 'data.get("DataElement")')
                                                if get_key_from_pair(value) == data.get("DataElement"):
                                                    # n0debug_calc(get_value_from_pair(value),  f"MODIFIED: value from '{value}'")
                                                    report_data[key] = pairsValue.get(get_value_from_pair(value))
                                                    # n0debug_calc(report_data[key], f"MODIFIED:{key}")
                                                # [+][end]   210926.1 = deniska = ALMAS-416
                        elif appl.tag.upper() == "APPLICATIONCOMMONDATA" and appl.ApplicationData.AID.attrib["Order"] == "1":
                            for dataset in appl.ApplicationData.ICCData.getchildren():  # below ICCData tag
                                if dataset.attrib["Name"] == "ADTA":
                                    for data in dataset.getchildren():
                                        if data.get("DataElement") == "PAND":
                                            v_card_number_common = data.get("Value")
                                        if data.get("DataElement") == "PRTP":
                                            v_card_production_type_common = data.get("Value")
                                        #Removed as part of ALMAS-350
                                        #if data.get("DataElement") == "PRDP":
                                            #v_card_action_type_common = get_value(data.get("Value"), "ACT_TYPE")
                                            #v_replacement_flag_common = get_value(data.get("Value"), "CARD_REPL")
                                if dataset.attrib["Name"] == "ENCD":
                                    for data in dataset.getchildren():
                                        if data.get("DataElement") == "EXDT":
                                            report_data["EXPIRY DATE"] = data.get("Value")
                                        if data.get("DataElement") == "SVCD":
                                            report_data["POS SERVICE CODE"] = data.get("Value")
                                if dataset.attrib["Name"] == "EMBD":
                                    for data in dataset.getchildren():
                                        if data.get("DataElement") == "CRDN":
                                            report_data["CARDHOLDER NAME"] = data.get("Value")
                                        '''
                                        [-][begin] 20210921-001: shalini, ALMAS-416
                                        if data.get("DataElement") == "CMPN":
                                            report_data["CARD NAME"] = data.get("Value")
                                        if data.get("DataElement") == "CRDN":
                                            report_data["COMPANY NAME"] = data.get("Value")
                                        [-][begin] 20210921-001: shalini, ALMAS-416
                                        '''
                                        # [+][begin] 20210921-001: shalini, ALMAS-416
                                        if data.get("DataElement") == "CRDN":
                                            report_data["CARD NAME"] = data.get("Value")
                                        if data.get("DataElement") == "CMPN":
                                            report_data["COMPANY NAME"] = data.get("Value")
                                        # [+][begin] 20210921-001: shalini, ALMAS-416
                                if dataset.attrib["Name"] == "CRDM":
                                    for data in dataset.getchildren():
                                        if data.get("DataElement") == "PIN1":
                                            report_data["CLIENT MAILING ADDRESS LINE 1"] = data.get("Value")
                                        if data.get("DataElement") == "PIN2":
                                            report_data["CLIENT MAILING ADDRESS LINE 2"] = data.get("Value")
                                        if data.get("DataElement") == "PIN3":
                                            report_data["CLIENT MAILING ADDRESS LINE 3"] = data.get("Value")
                                        if data.get("DataElement") == "PIN4":
                                            report_data["CLIENT MAILING ADDRESS LINE 4"] = data.get("Value")
                                        if data.get("DataElement") == "CITY":
                                            report_data["CLIENT MAILING ADDRESS CITY"] = data.get("Value")
                                        if data.get("DataElement") == "CNTR":
                                            report_data["CLIENT MAILING ADDRESS COUNTRY"] = data.get("Value")
                    report_data["CARD NUMBER"] = (v_card_number_crn if v_card_number_crn != "" else v_card_number_common)
                    report_data["CARD PRODUCTION TYPE"] = (v_card_production_type_crn if v_card_production_type_crn != "" else v_card_production_type_common)
# [+] [begin] 230727.1 = Shalini = OPKSAIC-5509
                    for mask_column in __params__['MASK_COLUMNS']():
                        if (fields_value:=report_data.get(mask_column)) and __params__['MASK_PATTERN']()[0].match(fields_value):
                            report_data[mask_column] = __params__['MASK_PATTERN']()[0].sub(__params__['MASK_PATTERN']()[1], fields_value)
# [+] [end] 230727.1 = Shalini = OPKSAIC-5509
                    #Removed as part of ALMAS-350
                    #report_data["CARD ACTION TYPE"] = (v_card_action_type_crn if v_card_action_type_crn != "" else v_card_action_type_common)
                    #report_data["REPLACEMENT FLAG"] = (v_replacement_flag_crn if v_replacement_flag_crn != "" else v_replacement_flag_common)
                    logging.debug(report_data)

                    ''' these fields are custom and not supposed to have any data transformation:
                    # Some logical data modifications:
                    # 1) Card Action Type
                    if report_data["CARD ACTION"].strip() == "1":
                        v_Card_Action = "New/Replace"
                    elif report_data["CARD ACTION"].strip() == "3":
                        v_Card_Action = "Reissue"
                    elif report_data["CARD ACTION"].strip() == "5":
                        v_Card_Action = "Pin Mailer"
                    elif report_data["CARD ACTION"].strip() == "7":
                        v_Card_Action = "Renewal"
                    else:
                        v_Card_Action = "NA"

                    # 2) Replacement Action Flag:
                    if report_data["CARD ACTION"].strip() == "1" and report_data["REPLACEMENT ACTION FLAG"].strip() == "R":
                        v_Replacement_Action_Flag = "Replacement"
                    else:
                        v_Replacement_Action_Flag = "New"

                    # 3) Card Holder Flag:
                    if report_data["CARDHOLDER FLAG"].strip() == "0":
                        v_Card_Holder_Flag = "Primary"
                    elif report_data["CARDHOLDER FLAG"] == "1":
                        v_Card_Holder_Flag = "Supplementary"
                    '''

                    # [*][begin] 230221.1 = DenisIu = OPKSAIC-5062: Fix defect with None values
                    '''
                    interim_line = report_data.get("CARD NUMBER") + "," + report_data.get("CARD PRODUCTION TYPE") + "," + report_data.get("EXPIRY DATE") + "," + report_data.get("POS SERVICE CODE") + "," \
                                   + report_data.get("CARD NAME") + "," + report_data.get("COMPANY NAME") + "," + report_data.get("CLIENT MAILING ADDRESS LINE 1") + "," + report_data.get("CLIENT MAILING ADDRESS LINE 2") + ","\
                                   + report_data.get("CLIENT MAILING ADDRESS LINE 3") + "," + report_data.get("CLIENT MAILING ADDRESS LINE 4") + "," + report_data.get("CLIENT MAILING ADDRESS CITY") + "," \
                                   + report_data.get("CLIENT MAILING ADDRESS COUNTRY")
                    '''
                    fields_for_concatinate = [
                        "CARD NUMBER",
                        "CARD PRODUCTION TYPE",
                        "EXPIRY DATE",
                        "POS SERVICE CODE",
                        "CARD NAME",
                        "COMPANY NAME",
                        "CLIENT MAILING ADDRESS LINE 1",
                        "CLIENT MAILING ADDRESS LINE 2",
                        "CLIENT MAILING ADDRESS LINE 3",
                        "CLIENT MAILING ADDRESS LINE 4",
                        "CLIENT MAILING ADDRESS CITY",
                        "CLIENT MAILING ADDRESS COUNTRY",
                    ]
                    interim_line = '|'.join([report_data.get(field_name) or "" for field_name in fields_for_concatinate])
                    # [*][end] 230221.1 = DenisIu = OPKSAIC-5062: Fix defect with None values

                    for key in sorted(v_custom_field_settings.keys()):
                        interim_line += '|' + (report_data.get(key) or "")  # [*] 230707.1 = deniska = OPKSAIC-5428: Fix made based on KSA production baseline

                    '''
                    # Data quality check:
                    # Check 1: Primary card number empty or is not a Number
                    if not bool(re.compile("\d+", re.IGNORECASE).search(report_data["Primary card number"].strip())):
                        logging.warning(f"'Primary card number' field has empty or incorrect value: {report_data['Primary card number']}.")
                        logging.warning(f"Incorrect record: {interim_line}")
                        continue
                    # Check 2: Cardholder Name empty or has incorrect value
                    if not bool(re.compile("[a-zA-Z0-9 ]+", re.IGNORECASE).search(report_data["Company name"].strip())):
                        logging.warning(f"'Company name' field has empty or incorrect value: {report_data['Company name']}.")
                        logging.warning(f"Incorrect record: {interim_line}")
                        continue
                    # Check 3: Expiry Date empty or has incorrect value
                    if not bool(re.compile("\d{8}", re.IGNORECASE).search(report_data["Account open date"].strip())):
                        logging.warning(f"'Account open date' field has empty or incorrect value: {report_data['Account open date']} (should be 'ddmmyyyy').")
                        logging.warning(f"Incorrect record: {interim_line}")
                        continue
                    # Check 5: if the record has illegal characters
                    if has_illegal_char(str(interim_line)):
                        logging.warning("record has illegal character(s) in the input file")
                        logging.warning(f"incorrect record:{interim_line}")
                        continue
                    '''

                    # write obtained XML data into temp file
                    with open(rep_temp_file, 'at', encoding=__params__['ENCODING']()) as interim_tmp:
                        interim_tmp.write(interim_line+"\n")

                    if report_data.get("CARD ACTION TYPE") == "1":
                        v_card_production_type = "New/Replace"
                    elif report_data.get("CARD ACTION TYPE") == "3":
                        v_card_production_type = "Reissue"
                    elif report_data.get("CARD ACTION TYPE") == "5":
                        v_card_production_type = "Pin Mailer"
                    elif report_data.get("CARD ACTION TYPE") == "7":
                        v_card_production_type = "Renewal"
                    else:
                        v_card_production_type = "N/A"

                    # write data into aggregated report temporary file:
                    with open(v_agg_temp_file, "at", encoding=__params__['ENCODING']()) as agg_temp_file:
                        agg_temp_file.write(str(orgs.get(str(v_org))) + ";" + str(Path(xml_file).stem) + ";" + report_data.get("PRODUCT NAME") + ";" + v_card_production_type + "\n")


                '''
                  we have to check some parameters and use only valid records after it
                  so we're creating temp file with valid records for further processing
                '''

                # Read the input file and calculate max length of column values
                max_lengths = {}
                # create dictionary key:value -> column_name:max_field_length with headers only (just to begin)
                with open(rep_temp_file, 'rt', newline='', encoding=__params__['ENCODING']()) as curr_src_file_headers:
                    headers = csv.DictReader(curr_src_file_headers, delimiter='|').fieldnames
                    for hd in headers:
                        max_lengths[hd] = len(str(hd).strip())
                    logging.debug("Headers' lengths :"+str(max_lengths))

                # fill the dictionary key:value -> column_name:max_field_length with the really max values
                with open(rep_temp_file, 'rt', newline='', encoding=__params__['ENCODING']()) as curr_src_file:
                    reader = csv.DictReader(curr_src_file, delimiter='|')
                    for row in reader:
                        for col in reader.fieldnames:
                            max_lengths[col] = (len(str(row[col]).strip()) if max_lengths[col] < len(str(row[col]).strip()) else max_lengths[col])
                logging.debug("Overall max lengths:"+str(max_lengths))

                # create output_file_name
                datenow = datetime.datetime.now()
                output_file_name = str(output_path) + "\\" + str(v_org) + "_" + __params__['OUTPUT_FN_PREFIX']() + datenow.strftime('%d%m%Y%H%M%S%f')[:-3] + ".txt"

                # Reading an temporary file with source data
                with open(rep_temp_file, 'rt', encoding=__params__['ENCODING']()) as curr_src_file_w:
                    r_cnt = 0 # variable to comprise a number of records inserted into the new file
                    checked = set() # set is used for further duplicate check
                    # Start writing into the new report file
                    with open(output_file_name, 'wt', encoding=__params__['ENCODING']()) as new_file:
                        new_file.write(v_org + "    EMBOSSER FILE   " + datenow.strftime('%d-%m-%Y %H:%M:%S') + '\n')
                        reader = csv.DictReader(curr_src_file_w, delimiter='|')
                        #header_2b_written = __params__['DELIMITER']() #[-]20210922-002: shalini, ALMAS-416
                        header_2b_written = ""
                        for col in reader.fieldnames:
                            header_2b_written += str(col).ljust(max_lengths[col], ' ') + __params__['DELIMITER']()
                        header_2b_written += '\n'
                        new_file.write(header_2b_written)

                        for row in reader:
                            #row_2b_written = __params__['DELIMITER']() #[-]20210922-002: shalini, ALMAS-416
                            row_2b_written = ""
                            for col in reader.fieldnames:
                                row_2b_written += str(row[col]).strip().ljust(max_lengths[col], ' ') + __params__['DELIMITER']()
                            row_2b_written += '\n'
                            # Check: if the record has duplicates
                            lower_row = str(row).lower().strip()
                            if lower_row in checked:
                                logging.warning(f"Duplicated record is found: {row}")
                                continue
                            else:
                                checked.add(lower_row)
                            new_file.write(row_2b_written)
                            r_cnt+=1
                    logging.info(f"Report file {output_file_name} created with {r_cnt} records")
                    checked.clear()

                #------------------

                # delete source file:
                xml_file.unlink(missing_ok=True)

            # if src file wasn't found we do nothing but writing into the log
            else:
                logging.info('[INFO]: File {} wasn\'t not found'.format(xml_file))

        '''
           Here we will take temporary CSV file and will create Aggregated report:
            1) retrieve data from temporary CSV file
            2) put the data into Data Frame
            3) calculate max lengths
            4) create aggregated report file(s)
        '''
        logging.info("*".rjust(80, "*"))
        agg_max_lengths = {}
        # 1) read CSV file:
        df = pd.read_csv(v_agg_temp_file, sep=";")

        # 2) get data into Data Frame, group retrieved data and calculate number of each element group
        agg_df = df.groupby(["BANK NAME", "FILE NAME", "PRODUCT NAME", "CARD ACTION"], dropna=False).size().reset_index(
            name="COUNT")
        logging.debug(agg_df)
        # pd.options.display.width = 0 # we need all fields to be printed
        # 3) calculate max lengths
        for col in agg_df.columns:
            agg_max_lengths[col] = len(col)
            for i, rec in agg_df.iterrows():
                agg_max_lengths[col] = (len(str(rec[col]).upper().replace("NAN", "").strip()) if agg_max_lengths[col] < len(
                    str(rec[col]).upper().replace("NAN", "").strip()) else agg_max_lengths[col])
        logging.debug(agg_max_lengths)

        # 4) create aggregated report
        agg_report_file = str(output_path) + "\\" + str(v_org) + "_agg.txt"
        agg_cnt = 0
        with open(agg_report_file, "wt+", encoding=__params__['ENCODING']()) as agg_report:
            agg_header = ""
            for col in agg_df.columns:
                #agg_header += __params__['DELIMITER']() + str(col).strip().ljust(agg_max_lengths[col], " ") #[-]20210922-002: shalini, ALMAS-416
                agg_header += str(col).strip().ljust(agg_max_lengths[col], " ")+__params__['DELIMITER']()
            #agg_header += __params__['DELIMITER']() + "\n" #[-]20210922-002: shalini, ALMAS-416
            agg_header += "\n"
            agg_report.write(agg_header)

            for i, iter_row in agg_df.iterrows():
                agg_row = ""
                for col in agg_df.columns:
                    #agg_row += __params__['DELIMITER']() + str(iter_row[col]).strip().upper().replace("NAN", "").ljust(
                        #agg_max_lengths[col], " ") #[-]20210922-002: shalini, ALMAS-416
                    agg_row += str(iter_row[col]).strip().upper().replace("NAN", "").ljust(
                        agg_max_lengths[col], " ") + __params__['DELIMITER']()
                #agg_row += __params__['DELIMITER']() + "\n" #[-]20210922-002: shalini, ALMAS-416
                agg_row += "\n"
                agg_report.write(agg_row)
                agg_cnt += 1
            logging.info(f"Aggregated report for ORG={v_org}: {agg_report_file} was created with {agg_cnt} records.")

    logging.info(f"Python Job {__params__['JOB_NAME']()} is finished on {datetime.datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")

from pytl_core import *
def _main():
    global cfg, config
    cfg = config = Config.configure_pytl_core({'JOB_FILE': __file__, 'JOB_NAME': __job_name__})
    logging.debug(f"Config: initialisation finished, 'config' and 'cfg' variables were created.")
    logging.info(f"Starting {Path(__file__).stem} python job")
    main()
    logging.info(f"{Path(__file__).stem} python job is FINISHED!")
