__version__ = "240515.1"
__job_name__ = "PyTL_IS_EmbosserFiles"
__bat_files__ = ["NIC_IS_Ou_EmbosserFile.bat"]

print(f"{__version__=}")
print(f"{__job_name__=}")
print(f"{__bat_files__=}")