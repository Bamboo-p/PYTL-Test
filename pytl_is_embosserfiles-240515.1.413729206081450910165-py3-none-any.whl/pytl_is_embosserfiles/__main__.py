# from _PyTL_IS_EmbosserFiles import _main, __job_name__
try:
    # Could be imported ONLY if it's run as module
    from ._PyTL_IS_EmbosserFiles import _main
    from . import __job_name__
    from importlib_metadata import version as importlib_metadata_version
    __version__ = importlib_metadata_version(__job_name__)
except:
    # Could be imported ONLY if it's run as normal py
    from _PyTL_IS_EmbosserFiles import _main
    from __init__ import __job_name__
    from __init__ import __version__
 
print("*"*30 + " " + __job_name__)
if __name__ == "__main__":
    print("*"*15 + " " + __name__)
    _main()
