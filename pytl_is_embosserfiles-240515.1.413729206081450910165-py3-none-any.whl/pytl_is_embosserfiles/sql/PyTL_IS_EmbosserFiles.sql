/*
* ENG-3262: NIC_IS_Ou_EmbosserFile = NIC_IS_Ou_EmbosserFile.sql
*
* Version history:
* 20210528.1 = KonstantinA = ENG-3262:   001 - Initial development
* 20220131.1 = ShaliniU    = ALMB-478:   002 - Added schema name before tables
*/
select replace(filter2, 'ADD_INFO_0', 'ADD')||':'||code as tag_and_attr
     , UPPER(name) as name_in_report
from ows.sy_handbook 
  where amnd_state = 'A' 
    and filter = :ORG||'-FIPARM_CC_TAGS' 
    and group_code = 'NI_EVR_ACTCODE'
  order by UPPER(name)