/*
* ENG-3262: NIC_IS_Ou_EmbosserFile = NIC_IS_Ou_EmbosserFile_get_inst_names.sql
*
* Version history:
* 20210528.1 = KonstantinA = ENG-3262:   001 - Initial development
* 20220131.1 = ShaliniU    = ALMB-478:   002 - Added schema name before tables
*/
with ORGS
as (
     select trim(regexp_substr(:ORGLIST, '[^\,]+', 1, level)) as org
  from dual
    connect by level <= regexp_count(:ORGLIST, '\,')+1
)
select branch_code, name from ows.F_I where branch_code in (select org from ORGS) and amnd_state = 'A'