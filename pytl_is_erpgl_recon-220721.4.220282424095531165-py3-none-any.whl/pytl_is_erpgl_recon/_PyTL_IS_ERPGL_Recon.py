"""
220610.1 = RobbyD  = OPKSAIC-3443: Initial design
220614.1 = RobbyD  = OPKSAIC-3443: Input file naming convention change, validate input before executing procedure
220614.2 = RobbyD  = OPKSAIC-3443: Fixes
220617.1 = RobbyD  = OPKSAIC-3443: Correcting column name as part of latest enhancement
220718.1 = DenisKa = OPKSAIC-3443: Fix for TSD
220721.1 = DenisKa = OPKSAIC-4666: Changed connection from DB_STG_SRC_WLTURL to DB_W4C_SRC_WLTURL
220721.2 = DenisKa = OPKSAIC-4666: Delete incomming file after success processing, code optimization
220721.3 = DenisKa = OPKSAIC-4666: Fix of unit testing
220721.4 = DenisKa = OPKSAIC-4666: Fix slice. Defect could be catched only if CSV will contain more than 15 columns
"""

import pytl_core
import logging
import glob
from pathlib import Path

try:
    # Could be imported ONLY if it's run as module
    from . import __job_name__
    from importlib_metadata import version as importlib_metadata_version
    __version__ = importlib_metadata_version(__job_name__)
    # from . import input_output
except:
    # Could be imported ONLY if it's run as normal py
    from __init__ import __job_name__
    from __init__ import __version__
    # import input_output

# ------------------------------------------------------------------------------
__params__ = pytl_core.Params({
# Mandatory
        "ENV":                      lambda: config["ENV"],              # D:\PYTL\NIC\JOBNAME\W4UAT25.PARM
        "ORG":                      lambda: config["ORG"],              # XXX
# Optional
# ------------------------------------------------------------------------------
# In job: Client -> PyTL -> W4
        "INPUT_FN_PREFIX":          lambda: __params__['ORG'] + '_Corebanking_ERPGLExtract' # In job: Client -> PyTL -> W4
                                            if not (__INPUT_FN_PREFIX := config.get("INPUT_FN_PREFIX"))
                                            else (__INPUT_FN_PREFIX if __INPUT_FN_PREFIX != '.' else ""),
        "INPUT_FN_SEPARATOR":       lambda: "_" if not (__INPUT_FN_SEPARATOR := config.get("INPUT_FN_SEPARATOR")) else (__INPUT_FN_SEPARATOR if __INPUT_FN_SEPARATOR != '.' else ""),
        "INPUT_FN_EXTENSION":       lambda: ".txt" if not (__INPUT_FN_EXTENSION := config.get("INPUT_FN_EXTENSION")) else (__INPUT_FN_EXTENSION if __INPUT_FN_EXTENSION != '.' else ""),
        "INPUT_FN_MASK":            lambda: __params__['INPUT_FN_PREFIX'] + "*" + __params__['INPUT_FN_EXTENSION'] # In job: Client -> PyTL -> W4
                                            if not (__INPUT_FN_MASK := config.get("INPUT_FN_MASK"))
                                            else (__INPUT_FN_MASK if __INPUT_FN_MASK != '.' else ""),
# ******************************************************************************
# Common for both jobs
# Parameters from file config["ENV"]
        "DB_W4C_SRC_WLTURL":        lambda: config["DB_W4C_SRC_WLTURL"],
# Precalculated values
        "JOB_NAME":                 lambda: config["JOB_NAME"],
# ------------------------------------------------------------------------------
# In job: Client -> PyTL -> W4
        "SRC_DIR":                  lambda: config["SRC_DIR"],
})

# ******************************************************************************
# In job: Client -> PyTL -> W4
# ******************************************************************************

def main(_config):
    global config
    config = _config

    stg_conn = pytl_core.Connection(__params__['DB_W4C_SRC_WLTURL'])
    cursor = stg_conn.connection.cursor()

    # ==============================================================================================
    # Parsing csv file
    search_mask = __params__['SRC_DIR']+"\\"+__params__['INPUT_FN_MASK']
    logging.debug(f"Search mask: '{search_mask}'")
    
    value_separator = ','
    max_columns_in_incoming_file = 15

    sql = '''
    insert into ows.opt_erpgl (
        FI_CODE,
        ACCOUNT_NUMBER,
        POSTING_DATE,
        ENTRY_DATE,
        AUTH_CODE,
        TRANS_CURR,
        TRANS_AMOUNT,
        SETTL_CURR,
        SETTL_AMOUNT,
        TRANS_DETAIL,
        RRN,
        CARD_NUMBER,
        LINKED_ACCOUNT_NUMBER,
        TRANS_DIRECTION,
        POSTED_USER,
        APPROVED_USER
    ) values (
        :1,
        :2,
        to_date(:3, 'dd/mm/rrrr'),
        to_date(:4, 'dd/mm/rrrr'),
        :5,
        :6,
        :7,
        :8,
        :9,
        :10,
        :11,
        :12,
        :13,
        :14,
        :15,
        :16
    )
    '''


    totaly_rows_count = 0
    batch_size = 1000
    for found_file in glob.glob(search_mask):
        logging.info(f"Found file '{found_file}'.")

        file_rows_count = 0
        file_data = []
        with open(found_file, 'rt') as in_filehandler:
            for line in in_filehandler.readlines():
                # DenisKa: I am not sure that .rstrip() is good way == possible last columns could be ended with spaces
                # DenisKa: I am not sure that .split() is good way == possible some could contains value_separator
                row_data = line.rstrip().split(value_separator)
                file_data.append([__params__['ORG']] + row_data[:max_columns_in_incoming_file] + [None]*(max_columns_in_incoming_file - len(row_data)))
                if len(file_data) == batch_size:
                    file_rows_count += len(file_data)
                    cursor.executemany(sql, file_data)
                    file_data = []
        if file_data:
            file_rows_count += len(file_data)
            cursor.executemany(sql, file_data)
            
        if file_rows_count:
            logging.debug(f"inserted from file '{found_file}': {file_rows_count} rows")
            stg_conn.connection.commit()
        else:
            logging.debug(f"no data loaded from file '{found_file}'")
            
        totaly_rows_count += file_rows_count
        Path(found_file).unlink(missing_ok=True)
        logging.info(f"Processed file {found_file} is deleted.")

    if totaly_rows_count:
        logging.debug(f"inserted totaly: {totaly_rows_count} rows")
        stg_conn.execute_statement_or_anonym_block(
            "begin ows.stnd.start_session(1, '', :JOB_NAME, ''); ows.opt_py_recon.process_erpgl_parallel(:ORG); ows.stnd.finish_session; end;",
            bind_vars = {
                'ORG': __params__['ORG'],
                'JOB_NAME': __params__['JOB_NAME']
            }
        )
        logging.info(f"opt_py_recon.process_erpgl_parallel executed")
    else:
        logging.info(f"no record was processed")

    stg_conn.close()
