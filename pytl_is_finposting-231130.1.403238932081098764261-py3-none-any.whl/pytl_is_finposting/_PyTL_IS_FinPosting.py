'''
    220512.5 = deniska = PRD-20670: added ability to: process files with correct names, but incorrect content
    230501.1 = deniska = PRD-23905: renamed load_ini() parameter equal_sign -> equal_tag
'''

__version__ = "231130.1"
__job_name__ = "PyTL_IS_FinPosting"
__bat_files__ = ["NIC_IS_In_FinPostingService.bat", "NIC_IS_Ou_FinPostingService.bat"]

# import sys
# import os
# sys.path.insert(0, (my_dir:=os.path.split(os.path.abspath(__file__))[0]) + "/../")

import pytl_core
import n0struct
import logging
from pathlib import Path
import datetime
import jinja2
import typing

is_empty = lambda string_value: string_value is None or not str(string_value).strip()
is_not_empty = lambda string_value: not(string_value is None or not str(string_value).strip())

# ------------------------------------------------------------------------------
__params__ = pytl_core.Params({
# Mandatory
        "ENV":                      lambda: config["ENV"],              # D:\PYTL\NIC\JOBNAME\W4UAT25.PARM
        "ORG":                      lambda: config["ORG"],              # XXX
        "DIRECTION":                lambda: __DIRECTION if (__DIRECTION := config['DIRECTION'].strip().upper()) in ("IN", "OUT") else pytl_core.raiser(Exception("Incorrect value in parameter DIRECTION={config['DIRECTION']}. Expected IN or OUT")),
# Optional
# ------------------------------------------------------------------------------
# In job: Client -> PyTL -> W4
        "INPUT_FN_PREFIX":          lambda: (
                                                # Out job: W4 -> PyTL -> Client
                                                "R_nic_"
                                                if __params__['INPUT_FN_EXTENSION'] == "OUT"
                                                else
                                                # In job: Client -> PyTL -> W4
                                                "NIC_FIN"
                                            )
                                            if not (__INPUT_FN_PREFIX := config.get("INPUT_FN_PREFIX"))
                                            else (__INPUT_FN_PREFIX if __INPUT_FN_PREFIX != '.' else ""),
        "INPUT_FN_SEPARATOR":       lambda: "_" if not (__INPUT_FN_SEPARATOR := config.get("INPUT_FN_SEPARATOR")) else (__INPUT_FN_SEPARATOR if __INPUT_FN_SEPARATOR != '.' else ""),
        "INPUT_FN_EXTENSION":       lambda: ".json" if not (__INPUT_FN_EXTENSION := config.get("INPUT_FN_EXTENSION")) else (__INPUT_FN_EXTENSION if __INPUT_FN_EXTENSION != '.' else ""),
        "INPUT_FN_MASK":            (
                                        lambda: (
                                            # Out job: W4 -> PyTL -> Client
                                            (
                                                __params__['INPUT_FN_PREFIX'] +
                                                __params__['ORG'].rjust(6, '0') +
                                                __params__['INPUT_FN_SEPARATOR'] +
                                                "{}" + # f"{seq_number.rjust(5, '0')}" +
                                                ".*"
                                            ) if __params__['DIRECTION'] == "OUT"
                                            # In job: Client -> PyTL -> W4
                                            else (
                                                __params__['INPUT_FN_PREFIX'] +
                                                "*" +
                                                __params__['INPUT_FN_EXTENSION']
                                            )
                                            if not (__INPUT_FN_MASK := config.get("INPUT_FN_MASK"))
                                            else (__INPUT_FN_MASK if __INPUT_FN_MASK != '.' else "")
                                        ),
                                        True # Don't cache and recalculate each usage
                                    ),
        "OUTPUT_FN_PREFIX":         lambda: "nic_"
                                            if not (__OUTPUT_FN_PREFIX := config.get("OUTPUT_FN_PREFIX"))
                                            else (__OUTPUT_FN_PREFIX if __OUTPUT_FN_PREFIX != '.' else ""),
        "OUTPUT_FN_SEPARATOR":       lambda: "_" if not (__OUTPUT_FN_SEPARATOR := config.get("OUTPUT_FN_SEPARATOR")) else (__OUTPUT_FN_SEPARATOR if __OUTPUT_FN_SEPARATOR != '.' else ""),
        "OUTPUT_FN_MASK":            (
                                        lambda: (
                                            # Out job: W4 -> PyTL -> Client
                                            (
                                                "" # Out job uses incoming file name for saving output for client
                                            ) if __params__['DIRECTION'] == "OUT"
                                            # In job: Client -> PyTL -> W4
                                            else (
                                                __params__['OUTPUT_FN_PREFIX'] +
                                                __params__['ORG'].rjust(6, '0') +
                                                __params__['OUTPUT_FN_SEPARATOR'] +
                                                "{}" + # f"{seq_number.rjust(5, '0')}" +
                                                 f".{pytl_core.timestamp('%j').rjust(3, '0')}"
                                            )
                                            if not (__OUTPUT_FN_MASK := config.get("OUTPUT_FN_MASK"))
                                            else (__OUTPUT_FN_MASK if __OUTPUT_FN_MASK != '.' else "")
                                        ),
                                        True # Don't cache and recalculate each usage
                                    ),
# ==============================================================================
# In job: Client -> PyTL -> W4
        "ALLOW_NON_WHITE_TAGS":     lambda: "" if not (__ALLOW_NON_WHITE_TAGS := config.get("ALLOW_NON_WHITE_TAGS")) else (__ALLOW_NON_WHITE_TAGS.upper() if __ALLOW_NON_WHITE_TAGS != '.' else ""),
        "WHITE_LIST":               lambda: config.get("WHITE_LIST") or "white_list.txt",
        "TEMPLATE_FILE":            lambda: config.get("TEMPLATE_FILE") or "DOC.txt",

# ==============================================================================
# Out job: W4 -> PyTL -> Client
        "DELIMITER":                lambda:  config.get("DELIMITER") or "|",
        "APPLICATIONS":             lambda:  config.get("APPLICATIONS", None),

# ******************************************************************************
# Common for both jobs
# Parameters from file config["ENV"]
        "DB_STG_SRC_WLTURL":        lambda: config["DB_STG_SRC_WLTURL"],
# Precalculated values
        "JOB_NAME":                 lambda: config["JOB_NAME"],
# ------------------------------------------------------------------------------
# In job: Client -> PyTL -> W4
        "TEMPLATES_DIR":            lambda: config["TEMPLATES_DIR"],
        "SRC_DIR":                  lambda: config["SRC_DIR"],
        "W4C_IN_DIR":               lambda: config["W4C_IN_DIR"],
# ==============================================================================
# Out job: W4 -> PyTL -> Client
        "W4C_OUT_DIR":              lambda: config["W4C_OUT_DIR"],
        "DST_DIR":                  lambda: config["DST_DIR"],
})
# ==============================================================================
# In job: Client -> PyTL -> W4
# ------------------------------------------------------------------------------
def validate_incoming_record(record, white_list):
    '''
    Validation procedure for all records in the input Json file

    :param dict record: record with input data
    :return:  list with error messages
    :rtype: list of str
    '''
    result = []
    default_length = 64
    if (
        is_empty(record['card_number']) or
        len(record['card_number']) > default_length
    ):
        result.append("ACCOUNT/CARD_NUMBER IS NOT VALID")

    # ------------------------------------------------------
    counter_party_mode = record.get('counter_party_mode', '').lower()
    if (
        counter_party_mode in ['contract', 'same_contract'] and
        is_not_empty(record.get('counter_party_member_id'))
    ):
        result.append("SOURCE_MEMBER_ID IS NOT VALID")
    if (
        counter_party_mode == 'contract' and
        is_empty(record.get('counter_party_number'))
    ):
        result.append("SOURCE NUMBER IS NOT VALID")
    if (
        counter_party_mode == 'same_contract' and
        (
            is_not_empty(record.get('counter_party_number')) or
            is_not_empty(record.get('counter_party_idt_scheme')) or
            is_not_empty(record.get('counter_party_add_idt'))
        )
    ):
        result.append("SOURCE VALUES MUST BE SKIPPED FOR SAME_CONTRACT MODE")
    # ------------------------------------------------------

    if is_empty(record['transaction_code']):
        result.append("MSG CODE IS NOT VALID")

    if (
        is_empty(record['amount']) or
        not record['amount'].replace('.', '').isdigit() or
       '-' in record['amount'] or
       record['amount'].count('.') > 1
    ):
        result.append("AMOUNT IS NOT VALID")

    if is_empty(record['currency']):
        result.append("CURRENCY IS NOT VALID")

    if (
        is_not_empty(record['trans_date']) and
        not n0struct.is_date_format(record['trans_date'], '%Y-%m-%d %H:%M:%S')
    ):
        result.append("INVALID TRANS DATE FORMAT")

    if (
        is_not_empty(record.get('settl_amount')) and
        (
            not record.get('settl_amount', '').replace('.', '').isdigit() or
            '-' in record.get('settl_amount')
        )
    ):
        result.append("SETTLEMENT AMOUNT IS NOT VALID")

    if (
        is_not_empty(record['ref_number']) and
        len(record['ref_number']) > 12
    ):
        result.append("RET_REF_NUMBER IS NOT VALID")

    if record.get('pack_rrn', '').upper() == 'D':
        result.append("THE REFERRED PACK_RRN ALGORITHM IS NOT SUPPORTED")

    for dt in record.get('custom', []):
        key = ([*dt.keys()][0]).upper()
        value = [*dt.values()][0]
        max_length = white_list.get(key)

        # Checking semicolon in ./Extra/AddData/Parm/
        if ';' in value:
            result.append(f"SEMICOLON CHARACTER IN CUSTOM VALUES {dt}")

        # Checking value/max length from ./Extra/AddData/Parm/ with white list
        if (
            __params__['ALLOW_NON_WHITE_TAGS'] != 'Y' and
                (
                    not key.upper() in white_list.keys() or
                    max_length < len(value)
                )
         ):
            result.append(
                f"INCORRECT CUSTOM VALUES {dt}." + (f" MAX LEN IS {max_length}" if max_length else ""))
        elif __params__['ALLOW_NON_WHITE_TAGS'] == 'Y' and default_length < len(value):
            result.append(
                f"INCORRECT CUSTOM VALUES {dt}." + (f" MAX LEN IS {max_length}" if max_length else ""))

        # Values CHECK_FI_SRC and CHECK_FI_TGT must be skipped
        if key in ['CHECK_FI_SRC', 'CHECK_FI_TGT']:
            result.append(f"{key} IS PRESENT IN THE FILE")

    return result

# ==============================================================================
# In job: Client -> PyTL -> W4
# ------------------------------------------------------------------------------
def validate_xpath_values(struct_for_validation:n0struct.n0dict, validation_rules: dict) -> typing.List[dict]:
    '''
    struct_for_validation = n0dict({
    })
    validation_rules = {
        "//xpath1": ("Expected value1", "Message contains '{xpath}','{existed_value}','{expected_value}', which will be returned, in case of not expected value")
        "//xpath2": ("Expected value2", "Message contains '{xpath}','{existed_value}','{expected_value}', which will be returned, in case of not expected value")
    }
    validate_xpath_values(struct_for_validation, validation_rules) == [
        {"RespText" : "Message contains '//xpath1','','Expected value1', which will be returned, in case of not expected value"},
        {"RespText" : "Message contains '//xpath2','','Expected value2', which will be returned, in case of not expected value"},
    ]
    '''
    file_err_msg = []
    for xpath in validation_rules:
        existed_value = str(struct_for_validation.get(xpath, ''))
        expected_value = str(validation_rules[xpath][0])
        if existed_value.lower() != expected_value.lower():
            file_err_msg.append({
                                    "RespText" :
                                        validation_rules[xpath][1].format(
                                            key = xpath,
                                            existed_value = existed_value,
                                            expected_value = expected_value
                                        )
            })
    return file_err_msg
# ==============================================================================
# In job: Client -> PyTL -> W4
# Out job: W4 -> PyTL -> Client
# ------------------------------------------------------------------------------
def generate_status(resp_class:str  = "Error",
                    resp_code:str   = "998",
                    resp_text:str   = "Rejected by PyTL",
                    posting_status:typing.Union[str, None] = None,
                    statuses:dict   = []):
    result = {
        "RespClass": resp_class,
        "RespCode": resp_code,
        "RespText": resp_text
    }
    if posting_status:
        result["PostingStatus"] = posting_status
    if statuses:
        result["TransitStatuses"] = statuses
    return result
# ******************************************************************************
# In job: Client -> PyTL -> W4
# ******************************************************************************
def main_in():
    white_list = n0struct.load_ini(Path(__params__['TEMPLATES_DIR']) / __params__['WHITE_LIST'], default_value = 64, equal_tag = '|')
    with open(Path(template_file_path:=__params__['TEMPLATES_DIR']) / __params__['TEMPLATE_FILE'], "rt") as in_filehandler:
        template = jinja2.Template(in_filehandler.read())
    logging.debug(f"Jinja2 template has been loaded from {template_file_path}")

    stg_conn = pytl_core.Connection(__params__['DB_STG_SRC_WLTURL'])
    ## stg_conn = None # For DEBUG purpose

    # ==============================================================================================
    # Iterate by source Json files in the job_name/Input/
    for path in (found_files := list(Path(__params__['SRC_DIR']).glob(__params__['INPUT_FN_MASK']))):
        # Parsing Json file, apply the validation procedure to the file
        input_json = n0struct.n0dict(file=path)


        file_err_msg = validate_xpath_values( input_json, {
                                                '//header/file_type': (
                                                        "IN.BATCH.FIN_POSTING",
                                                        "FILE TYPE IS NOT VALID. {xpath} == '{existed_value}', but should be '{expected_value}'"
                                                ),
                                                '//header/fi': (
                                                        __params__['ORG'],
                                                        "FI IS NOT VALID. {xpath} == '{existed_value}', but should be '{expected_value}'"
                                                ),
                                             }
        )
        reject_file_path = Path(__params__['DST_DIR']) / path.name
        if file_err_msg:
            input_json['//header/FileStatus'] = {
                                            'loading_status': "Rejected",
                                            'status':         generate_status(
                                                                    resp_text="The whole file was rejected by PyTL",
                                                                    statuses=file_err_msg
                                                              )
            }
            # buffer = "\n".join([striped_line for line in input_json.to_json().expandtabs(4).split('\n') if (striped_line:=line.rstrip())])
            n0struct.save_file(reject_file_path, input_json.to_json())
            logging.info(f"JSON response file is saved into '{reject_file_path}'")

            pytl_core.utils.delete_file(path)
            logging.info(f"JSON incoming file '{path}' is deleted")

            continue

        # Get sequence number, the unique input file identifier
        seq_number = stg_conn.execute_select(
            statement= "select "
                      f"PyTL_JOB_SUPPORT.getSequenceValue('{__params__['JOB_NAME']}', 'file_name') SEQUENCE_NUMBER "
                       "from dual",
            bind_vars={}, pd_mode=False
        )['data'][0]['SEQUENCE_NUMBER']
        logging.info(f"seq_number = PyTL_JOB_SUPPORT.getSequenceValue('{__params__['JOB_NAME']}'), 'file_name') == {seq_number}")

        # ------------------------------------------------------------------------------------------
        # Parsing Json file, apply the validation procedure to each record, convert to WAY4 XML
        # and Json outgoing response (the same incoming json + status of processing)
        # Transactions.custom_fields list contains mandatory/defined XML structure fields
        # and optional records that will be moved as is into Doc/Transaction/Extra/AddData section
        valid_output_xml_records = []
        for input_json_transaction_i, input_json_transaction in enumerate(input_json['transactions']):
            output_xml_transaction = {}
            output_xml_transaction['counter_party_number'] = input_json_transaction.get('counter_party_number')
            output_xml_transaction['card_number']          = input_json_transaction.get('card_number')

            # ------------------------------------------------------------------
            custom_fields_l1 = input_json_transaction.get('custom_fields', [])
            output_xml_transaction['custom'] = []
            major_fields = [
                            'contract_idt_scheme',      # 1

                            'counter_party_mode',       # 3

                            'counter_party_idt_scheme', # 5
            # output_xml_transaction['counter_party_number'] = input_json_transaction.get('counter_party_number')
                            'counter_party_add_idt',    # 6

            # output_xml_transaction['contract_idt_scheme'] = output_xml_transaction.get('contract_idt_scheme') or 'CONTRACT_NUMBER'
            # output_xml_transaction['card_number']          = input_json_transaction.get('card_number')
                            'contract_add_idt',         # 2

            # output_xml_transaction['counter_party_number'] = input_json_transaction.get('counter_party_number')
                            'counter_party_member_id',  # 4
            ]
            for field in custom_fields_l1:
                key, value = field.get('key', ''), field.get('value')
                if key in major_fields:
                    output_xml_transaction.update({key: value})
                elif is_not_empty(key):
                    output_xml_transaction['custom'].append({key: value})
            # default value
            output_xml_transaction['contract_idt_scheme'] = output_xml_transaction.get('contract_idt_scheme') or 'CONTRACT_NUMBER'
            # ------------------------------------------------------------------

            # transformation logic for Originator part
            mode = output_xml_transaction.get('counter_party_mode') or 'member'
            if mode.upper() == 'CONTRACT':
                output_xml_transaction['orig_type'] = output_xml_transaction.get('counter_party_idt_scheme',# ./custom_fields[*]/key[text()=counter_party_idt_scheme]/../value
                                                                                 'CONTRACT_NUMBER')
                output_xml_transaction['orig_id']   = output_xml_transaction['counter_party_number']        # ./custom_fields[*]/key[text()=counter_party_number]/../value
                output_xml_transaction['orig_ext']  = output_xml_transaction.get('counter_party_add_idt')   # ./custom_fields[*]/key[text()=counter_party_add_idt]/../value
            elif mode.upper() == 'SAME_CONTRACT':
                output_xml_transaction['orig_type'] = output_xml_transaction['contract_idt_scheme']         # ./custom_fields[*]/key[text()=contract_idt_scheme]/../value
                output_xml_transaction['orig_id']   = output_xml_transaction['card_number']                 # input_json_transaction.get('card_number')
                output_xml_transaction['orig_ext']  = output_xml_transaction['contract_add_idt']            # ./custom_fields[*]/key[text()=contract_add_idt]/../value
            else:
                output_xml_transaction['contract_number'] = output_xml_transaction['counter_party_number']  # input_json_transaction.get('counter_party_number')
                output_xml_transaction['memberId']  = output_xml_transaction.get('counter_party_member_id', # ./custom_fields[*]/key[text()=counter_party_member_id]/../value
                                                                                 f"PAY{__params__['ORG']}")

            input_json_transaction__transaction = input_json_transaction.get('transaction')
            output_xml_transaction['transaction_code'] = input_json_transaction__transaction.get('transaction_code')
            output_xml_transaction['amount']           = input_json_transaction__transaction.get('amount')
            output_xml_transaction['currency']         = input_json_transaction__transaction.get('currency')

            # default value
            datetime_format = '%Y-%m-%d %H:%M:%S'
            dateonly_format = '%Y-%m-%d'
            sysdate = datetime.datetime.now()
            sysdate_str = sysdate.strftime(datetime_format) # Generate current date in datetime_format
            output_xml_transaction['trans_date'] = input_json_transaction__transaction.get('trans_date') or sysdate_str
            # datetime_format -> dateonly_format == '%Y-%m-%d %H:%M:%S' -> '%Y-%m-%d'
            trans_datetime = datetime.datetime.strptime(output_xml_transaction['trans_date'], datetime_format)
            trans_dateonly_str = trans_datetime.strftime(datetime_format)

            # transformation logic for posting_date and force_calendar_posting_date
            posting_dateonly_str = posting_date_str[:10] if (posting_date_str:=input_json_transaction__transaction.get('posting_date')) else None # only %Y-%m-%d is required
            output_xml_transaction['posting_date'] = (
                                    trans_dateonly_str
                                    if not posting_dateonly_str
                                       and input_json_transaction__transaction.get('force_calendar_posting_date', '').upper() == 'Y'
                                       and trans_datetime
                                       and (trans_datetime + datetime.timedelta(days=1)) >= sysdate
                                    else posting_dateonly_str
            )

            output_xml_transaction['description'] = input_json_transaction__transaction.get('description', '')
            output_xml_transaction['doc_ref_custom'] = []

            # ==================================================================
            custom_fields_l2 = input_json_transaction__transaction.get('custom_fields', [])
            major_fields = [
                            'settl_amount',
                            'settl_currency',
                            'pack_rrn',         # ?
                            'reason_details',
                            'sic',
                            'country',
                            'state',
                            'city',
                            'merchant_id'
            ]
            doc_ref_fields = [
                            'authcode',
                            'arn',
                            'irn',
                            'srn'
            ]
            for field in custom_fields_l2:
                key, value = field.get('key', ''), field.get('value')
                if key in major_fields:  # and is_not_empty(value):
                    output_xml_transaction.update({key: value})
                elif key in doc_ref_fields:
                    output_xml_transaction['custom'].append({key: value})
                    output_xml_transaction['doc_ref_custom'].append({key: value})
                elif is_not_empty(key):
                    output_xml_transaction['custom'].append({key: value})
            # ==================================================================

            # transformation logic for transaction_ref_number
            # TODO: waiting of the packaging logic
            output_xml_transaction['ref_number'] = input_json_transaction__transaction.get('transaction_ref_number')
            output_xml_transaction['doc_ref_custom'].append({'RRN': output_xml_transaction['ref_number']})

            # Listed fields are optional so need to understand about the high level tag
            output_xml_transaction['billing_exists'] = output_xml_transaction.get('settl_amount') \
                                                       or output_xml_transaction.get('settl_currency') \
                                                       or output_xml_transaction.get('posting_date')
            output_xml_transaction['sourcedtls_exists'] = output_xml_transaction.get('sic') \
                                                          or output_xml_transaction.get('country') \
                                                          or output_xml_transaction.get('state') \
                                                          or output_xml_transaction.get('city') \
                                                          or output_xml_transaction.get('merchant_id')
            output_xml_transaction["error_msg"] = validate_incoming_record(output_xml_transaction, white_list)

            doc_reg_number = \
                            f"{pytl_core.timestamp('%Y%m%d')}" \
                            f"{seq_number.rjust(5, '0')}" \
                            f"_" \
                            f"{pytl_core.utils.Sequence.next('DOC_REG_NUMBER__SEQ')}"
            output_xml_transaction['custom'].append({'DOC_REG_NUMBER': doc_reg_number})

            # delete doc_ref_custom elements from the common custom array after validation
            # due to these elements mapped to different places in WAY4 XML file
            custom = output_xml_transaction['custom']
            output_xml_transaction['custom'] = []
            for rec in custom:
                if [*rec.keys()][0] not in doc_ref_fields:
                    output_xml_transaction['custom'].append(rec)

            # create JSON response that based on the input but contains several new fields
            status = None
            if len(output_xml_transaction['error_msg']) > 0:
                status = generate_status(statuses=[
                                            {'RespText': value} for value in output_xml_transaction['error_msg']
                                        ]
                )

            input_json['transactions'][input_json_transaction_i].update({
                'doc_reg_number': doc_reg_number,
                'DocResponse': {
                    'status': status
                }
            })
            if not status:
                valid_output_xml_records.append(output_xml_transaction)
        # ------------------------------------------------------------------------------------------
        # Create WAY4 XML file if valid records are available in the processed Json file
        if valid_output_xml_records:
            logging.info(f"{len(valid_output_xml_records)} records will be extracted into XML file")
            n0struct.save_file(
                        way4xml_path := Path(__params__['W4C_IN_DIR']) / __params__['OUTPUT_FN_MASK'].format(seq_number.rjust(5, '0')),
                        template.render(
                            org=__params__['ORG'],
                            seq_number=seq_number,
                            records=valid_output_xml_records,
                            CreationDate=pytl_core.timestamp("%Y-%m-%d"),
                            CreationTime=pytl_core.timestamp("%H:%M:%S"),
                        )
            )
            logging.info(f"WAY4 XML file is saved into '{way4xml_path}'")

        # or generate Json response file with rejected results
        else:
            input_json['//header/FileStatus'] = {
                                                "total_docs":       (total_docs:=len(input_json['transactions'])),
                                                "rejected_docs":    total_docs,
                                                "accepted_docs":    "0",
                                                "loading_status":   "Rejected"
            }
            n0struct.save_file(reject_file_path, input_json.to_json())
            logging.info(f"JSON response file with rejected records is saved into '{reject_file_path}'")

            stg_conn.execute_stored_procedure(
                                                'PyTL_JOB_SUPPORT.setSeqValueUsed',
                                                bind_vars={
                                                            'p_job_id': __params__['JOB_NAME'],
                                                            'p_seq_value': seq_number,
                                                            'p_mode': 'mark'
                                                }
            )
            logging.info(f"PyTL_JOB_SUPPORT.setSeqValueUsed('{__params__['JOB_NAME']}'), 'seq_number', 'mark')")

        # Push updated json into STG_ETL schema for future processing
        stg_conn.execute_insert_batch(
                                        __job_name__,
                                        [
                                            {
                                                "APP_NUMBER": seq_number,
                                                "ORG": __params__['ORG'],
                                                "RESPONSE_JSON": input_json.to_json(),
                                                "INPUT_FILENAME": path.name
                                            }
                                        ],
                                        commit=True
        )
        pytl_core.utils.delete_file(path)
        logging.info(f"Incoming JSON file '{path}' is deleted")
    # ==============================================================================================
    if not found_files:
        logging.info(f"No input files found with mask {__params__['INPUT_FN_MASK']} in {__params__['SRC_DIR']}")
    if stg_conn:
        stg_conn.close()

# ******************************************************************************
# Out job: W4 -> PyTL -> Client
# ******************************************************************************
def main_out():
    stg_conn = pytl_core.Connection(__params__['DB_STG_SRC_WLTURL'])
    # stg_connection = pytl_core.OracleDB(connection_string)

    if __params__['APPLICATIONS']:
        # Extract numbers of open/closed application[s] {__params__['APPLICATIONS']} from STG_ETL schema, assosiated with {__params__['JOB_NAME']}
        sql_awaiting_processing_applications = \
                            f"select CURRENT_SEQUENCE_VALUE as VALUE " \
                            f"from PyTL_JOBS_CURRENT_VALUES " \
                            f"where OUT_JOB_ID = '{__params__['JOB_NAME']}' "\
                            f"and current_sequence_value in ({__params__['APPLICATIONS']})"
    else:
        # Fetch all awaiting processing applications' numbers from STG_ETL schema, assosiated with {__params__['JOB_NAME']}
        sql_awaiting_processing_applications = \
                            f"select CURRENT_SEQUENCE_VALUE as VALUE " \
                            f"from PyTL_TMP_ACTIVE_SEQUENCES_VW " \
                            f"where OUT_JOB_ID = '{__params__['JOB_NAME']}'"
    awaiting_processing_applications = [
                                        data['VALUE'] for data
                                        in stg_conn.execute_select(sql_awaiting_processing_applications)['data']
    ]

    # Iterate by WAY4 response files in the job_name/W4C-Output/ only for open sequence numbers
    for seq_number in awaiting_processing_applications:
        input_fn_mask = __params__['INPUT_FN_MASK'].format(seq_number.rjust(5, '0'))
        for path in (found_files := list(Path(__params__['W4C_OUT_DIR']).glob(input_fn_mask))):
            # Extracting original Json from STG_ETL table
            stg_data = stg_conn.execute_select("select RESPONSE_JSON, INPUT_FILENAME " \
                                              f"from {__job_name__} " \
                                              f"where APP_NUMBER = {seq_number}"
            )['data'][0]

            response_json = n0struct.n0dict(str(stg_data.get('RESPONSE_JSON')))

            logging.info(f"Reading WAY4 XML response file {path}")
            way4_xml_response_file = n0struct.n0dict(file=path)

            # Processing Json file, data enrichment
            accepted_docs = 0
            processed_at_least_one_record = 0
            for json_transaction in response_json.get('transactions', []):
                xpath__DocFile_DocList_Doc_Status = "//DocFile/DocList/Doc/Transaction/Extra/AddData/Parm/" \
                    "ParmCode[text()=DOC_REG_NUMBER]" \
                    "/../Value[text()=" + json_transaction.get('doc_reg_number') + "]" \
                    "/../../../../../Status" # //DocFile/DocList/Doc/Status
                # n0struct.n0debug("xpath__DocFile_DocList_Doc_Status")
                way4_xml_response_file__doc_status = way4_xml_response_file.first(xpath__DocFile_DocList_Doc_Status)
                # n0struct.n0debug("way4_xml_response_file__doc_status")
                # way4_xml_response_file__doc_status = way4_xml_response_file.findall(xpath__DocFile_DocList_Doc_Status)
                # n0struct.n0debug("way4_xml_response_file__doc_status")

                # n0struct.n0debug("way4_xml_response_file__doc_status")
                if way4_xml_response_file__doc_status:
                    processed_at_least_one_record += 1
                    # way4_xml_response_file__doc_status = [way4_xml_response_file__doc_status[found] for found in way4_xml_response_file__doc_status][0]
                    json_transaction.update({
                        'DocResponse': { 
                            'status': generate_status(
                                        resp_class     = way4_xml_response_file__doc_status.get('RespClass'),           # //DocFile/DocList/Doc[i]/Status/RespClass
                                        resp_code      = way4_xml_response_file__doc_status.get('RespCode'),            # //DocFile/DocList/Doc[i]/Status/RespCode
                                        resp_text      = way4_xml_response_file__doc_status.get('RespText'),            # //DocFile/DocList/Doc[i]/Status/RespText
                                        posting_status = way4_xml_response_file__doc_status.get('PostingStatus'),       # //DocFile/DocList/Doc[i]/Status/PostingStatus
                                        statuses       = way4_xml_response_file__doc_status.get('TransitStatuses', [])  # //DocFile/DocList/Doc[i]/Status/TransitStatuses
                                      )
                        }
                    })

                # Calculate success/failed documents
                if json_transaction.get('DocResponse') and json_transaction.get('DocResponse/status'): # added not mitigate cases when filename is correct but content is not correct.
                    if json_transaction.get('DocResponse/status/RespCode') == '0':
                        accepted_docs += 1

            if processed_at_least_one_record:
                # Create FileStatus
                response_json['//header/FileStatus'] = {
                    'total_docs':       (total_docs:=len(response_json['transactions'])),
                    'rejected_docs':    (rejected_docs:=total_docs - accepted_docs),
                    'accepted_docs':    accepted_docs,
                    'loading_status':   'Accepted'
                                        if total_docs == accepted_docs else
                                        (
                                            'Rejected'
                                            if total_docs == rejected_docs
                                            else 'PartiallyAccepted'
                                        )
                }
                n0struct.save_file(
                        report_file_path:=Path(__params__['DST_DIR']) / stg_data.get('INPUT_FILENAME'),
                        response_json.to_json()
                )
                logging.info(f"JSON response file with accepted/rejected records is saved into '{report_file_path}'")

                csv_mapping = {
                    "PAN, account number":                  'card_number',                      # "9998510169290759
                    "Transaction Code":                     'transaction/transaction_code',     # "MP-CASH-INC-M01
                    "Transaction Amount":                   'transaction/amount',               # "100.00
                    "Transaction Currency":                 'transaction/currency',             # "784",
                    "Transaction Date":                     'transaction/trans_date',           # "2021-06-10 10:00:01
                    "Posting Date":                         'transaction/posting_date',         # "2021-06-10 12:00:01
                    "Transaction Description":              'transaction/description',          # "transaction description 1
                    "Transaction reference number":         'transaction/transaction_ref_number', # "1234567890"
                    "Settlement Amount":                    'transaction/custom_fields[*]/key[text()=settl_amount]/../value',      # "99.99"
                    "Settlement Currency":                  'transaction/custom_fields[*]/key[text()=settl_currency]/../value',    # "784"
                    "Response code description":            'DocResponse/status/RespText',      # "Successfully completed"
                    "Posting status of transaction":        'DocResponse/status/PostingStatus', # "Posted"
                    # https://jira.network.ae/jira/browse/ENG-3781:
                    # 42  transactions.transaction.custom_fields.[key=auth_code]        Optional
                    "Authorization Code":                   (                                   # "123456"
                                                            'transaction/custom_fields[*]/key[text()=authcode]/../value',
                                                            'transaction/custom_fields[*]/key[text()=auth_code]/../value',
                                                            ),
                    # https://jira.network.ae/jira/browse/ENG-3781
                    # 49    transactions.transaction.custom_fields.[key=INST_DESC]      Optional (mandatory for installment interface)  Instalments description
                    # 50    transactions.transaction.custom_fields.[key=PLAN_NR]        Optional (mandatory for installment interface)  Instalments plan number
                    # 51    transactions.transaction.custom_fields.[key=INST_NUM]       Optional (mandatory for installment interface)  Instalments plan tenor
                    # 52    transactions.transaction.custom_fields.[key=INST_FTOTAL]    Optional (mandatory for installment interface)  Instalments unbilled interest amount
                    "Instalments description":              'transaction/custom_fields[*]/key[text()=INST_DESC]/../value',
                    "Instalments plan number":              'transaction/custom_fields[*]/key[text()=PLAN_NR]/../value',
                    "Instalments plan tenor":               'transaction/custom_fields[*]/key[text()=INST_NUM]/../value',
                    "Instalments unbilled interest amount": 'transaction/custom_fields[*]/key[text()=INST_FTOTAL]/../value',
                }
                n0struct.generate_csv(
                        response_json,
                        "//transactions[*]",
                        csv_mapping,
                        csv_file_path:=Path(__params__['DST_DIR']) / (stg_data.get('INPUT_FILENAME')+".csv")
                )
                logging.info(f"CSV response file with accepted/rejected records is saved into '{report_file_path}'")
                

                stg_conn.execute_stored_procedure(
                                                    'PyTL_JOB_SUPPORT.setSeqValueUsed',
                                                    bind_vars={
                                                                'p_job_id': __params__['JOB_NAME'],
                                                                'p_seq_value': seq_number,
                                                                'p_mode': 'mark'
                                                    }
                )
                logging.info(f"PyTL_JOB_SUPPORT.setSeqValueUsed('{__params__['JOB_NAME']}'), 'seq_number', 'mark')")

                pytl_core.utils.delete_file(path)
                logging.info(f"WAY4 XML file '{path}' is deleted")
            else:
                logging.error(f"Incorrect file {path} with correct name, but incorect content")

        if not found_files:
            logging.info(f"No input files found with mask {input_fn_mask} in {__params__['W4C_OUT_DIR']}")
    stg_conn.close()
# ******************************************************************************
# ******************************************************************************
def main():
    if __params__['DIRECTION'] == "OUT":
        main_out()
    else:
        main_in()
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
# ------------------------------------------------------------------------------
def _main():
    global cfg, config
    cfg = config = pytl_core.Config.configure_pytl_core({'JOB_FILE': __file__, 'JOB_NAME': __job_name__})
    logging.debug(f"Config: initialization finished, 'config' and 'cfg' variables were created.")
    logging.info(f"Starting {Path(__file__).stem} python job")
    main()
    logging.info(f"{Path(__file__).stem} python job is FINISHED!")
