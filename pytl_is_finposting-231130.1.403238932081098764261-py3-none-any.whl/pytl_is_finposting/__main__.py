from _PyTL_IS_FinPosting import _main, __job_name__
 
print("*"*30 + " " + __job_name__)
if __name__ == "__main__":
    print("*"*15 + " " + __file__)
    _main()
