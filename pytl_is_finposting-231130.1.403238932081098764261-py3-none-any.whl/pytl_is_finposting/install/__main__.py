import sys
import os
import glob
import shutil
from pathlib import Path
import subprocess

from .. import __version__
from .. import __job_name__
from .. import __bat_files__

if __name__ == '__main__':
    print(f"+++ INSTALLATION {__job_name__} v{__version__} STARTED")

    print(f"{sys.argv=}")
    cmd_line_parameters = {(param_splited := param.split('=', 1))[0]: param_splited[1] for param in sys.argv[1:] if '=' in param}
    print(f"{cmd_line_parameters=}")

    # ##########################################################################
    # Check ENV+DB_CONNECTION_NAME and DDL files
    # ##########################################################################
    target_env = cmd_line_parameters.get("ENV", "").strip() or os.environ.get("ENV", "").strip()
    target_con = cmd_line_parameters.get("DB_CONNECTION_NAME", "").strip() or os.environ.get("DB_CONNECTION_NAME", "").strip() or "DB_STG_SRC_WLTURL"

    print(f"{target_env=}")
    print(f"{target_con=}")

    ddl_files_dir = os.path.abspath(os.path.join(os.path.split(__file__)[0], "sql"))
    ddl_files = []
    if os.path.exists(run_sql_txt:=os.path.join(ddl_files_dir, "run_sql.txt")) and os.path.isfile(run_sql_txt):
        with open(run_sql_txt, "rt") as fIn:
            ddl_files = [
                ddl_file
                for line in fIn.readlines()
                if  (stripped_line:=line.strip())
                    and not stripped_line.startswith('#')
                    and os.path.exists(ddl_file:=os.path.join(ddl_files_dir, stripped_line))
            ]
        if ddl_files:
            print(f"{ddl_files=}")
            if not target_env:
                if not target_con:
                    raise Exception(f"OS environment ENV and DB_CONNECTION_NAME are not defined. Impossible to execute '{ddl_files}'. Execution terminated.")
                else:
                    raise Exception(f"OS environment ENV is not defined. Impossible to execute '{ddl_files}'. Execution terminated.")
            elif not target_con:
                raise Exception(f"OS environment DB_CONNECTION_NAME is not defined. Impossible to execute '{ddl_files}'. Execution terminated.")

            with open(target_env, "rt") as fIn:
                env_params = {
                    key_value[0]: key_value[1]
                    for line in fIn.readlines()
                    if  (stripped_line:=line.strip())
                        and not stripped_line.startswith('#')
                        and len(key_value:=stripped_line.split(';', 1)) == 2
                }
            if not target_con in env_params:
                raise Exception(f"Parameter '{target_con}' was not found in '{target_env}'. Impossible to execute '{ddl_files}'. Execution terminated.")
            if not "thin:" in env_params[target_con]:
                raise Exception(f"Parameter '{target_con}' in '{target_env}' should contain string like 'jdbc:oracle:thin:USER/PASSWORD@IP:PORT/SID' but contains '{env_params[target_con]}'. Execution terminated.")
            connection = env_params[target_con].split("thin:",1)[1]
            connection_user_password, connection_url = connection.split('@',1)
            connection_user, connection_password= connection_user_password.split('/',1)
        else:
            print("+*+ No DDL files found")

    # ##########################################################################
    # Check TARGET_DIR and BAT files
    # ##########################################################################
    bat_files_dir = os.path.abspath(os.path.join(os.path.split(__file__)[0], "bat"))
    bat_files = [
        bat_file_fullpath
        for bat_file in __bat_files__
        if os.path.exists(bat_file_fullpath:=os.path.join(bat_files_dir, bat_file))
    ]
    if bat_files:
        target_dir = cmd_line_parameters.get("TARGET_DIR", "").strip() or os.environ.get("TARGET_DIR", "").strip()
        if not target_dir:
            raise Exception(f"OS environment TARGET_DIR is not defined. Impossible to copy '{bat_files}'. Execution terminated.")
        target_dir = os.path.abspath(target_dir)
        if os.path.exists(target_dir) and os.path.isfile(target_dir):
            raise Exception(f"TARGET_DIR={target_dir} must be directory or not exists. Execution terminated.")
        Path(target_dir).mkdir(parents=True, exist_ok=True)
    else:
        print("+*+ No BAT files found")

    # ##########################################################################
    # DDL execution and coping BAT files
    # ##########################################################################
    for ddl_file in ddl_files:
        print(rf'+++ sqlplus -s "{connection_user}/***@{connection_url}" "@{ddl_file}')
        sys.stdout.flush()
        errorlevel = subprocess.call(["sqlplus", "-s", connection, "@"+ddl_file], shell=True)
        sys.stdout.flush()
        if errorlevel:
            raise Exception(f"Execution of 'sqlplus' terminated with {errorlevel=}.")

    for bat_file in bat_files:
        print(rf'+++ copy "{bat_file}" "{target_dir}"')
        shutil.copy(bat_file, target_dir)

    print(f"+++ INSTALLATION {__job_name__} v{__version__} COMPLETED")
