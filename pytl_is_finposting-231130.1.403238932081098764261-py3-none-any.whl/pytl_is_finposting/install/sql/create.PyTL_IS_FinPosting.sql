/*
    Changes history
    ---------------
    211208.2 = Denis Kaloshin = ENG-3781: universal DDL script
    211226.1 = Denis Kaloshin = ENG-3781: added command 'exit;' for execution with sqlplus and some addional logging commands.
*/
set linesize 2000
set serveroutput on
set verify off

declare
    type T_FIELD_NAME       is record (           -- desc ALL_TAB_COLUMNS;
        COLUMN_NAME         varchar2(128 char),
        DATA_TYPE           varchar2(128 char),
        CHAR_LENGTH         number,
        CHAR_USED           varchar2(1 char),
        DATA_DEFAULT        varchar2(4000 char),  -- it's LONG in the table ALL_TAB_COLUMNS 
        OLD_COLUMN_NAMES    varchar2(4000 char)
    );
    type T_TABLE_FIELDS     is table of T_FIELD_NAME;
------------------------------------------------------------------------------------------------------------------------
-- Just only 2 parameters (V_TABLE_NAME/V_OLD_TABLE_NAMES) and 1 structure (V_TABLE_STRUCTURE) are required to be defined
------------------------------------------------------------------------------------------------------------------------
    V_TABLE_NAME            USER_TABLES.TABLE_NAME%type := 'PyTL_IS_FinPosting';
/*    
    if V_TABLE_NAME will be not found, but one of %V_OLD_TABLE_NAMES% will be found, then
    the first (could not predict which one) will be renamed into %V_TABLE_NAME%
*/    
    V_OLD_TABLE_NAMES       varchar2(4000 char)         := '';
/*
    V_OLD_TABLE_NAMES       varchar2(4000 char)         := '';
    or
    V_OLD_TABLE_NAMES       varchar2(4000 char)         := 'POSSIBLE_OLD_NAME' 
    or
    V_OLD_TABLE_NAMES       varchar2(4000 char)         := 'POSSIBLE_OLD_NAME1,POSSIBLE_OLD_NAME2,POSSIBLE_OLD_NAME3'
*/    
    V_TABLE_STRUCTURE       T_TABLE_FIELDS := T_TABLE_FIELDS(
        T_FIELD_NAME('APP_NUMBER'       ,'VARCHAR2' ,100    ,'C'    ,''                                 ,''),
        T_FIELD_NAME('ORG'              ,'VARCHAR2' ,200    ,'C'    ,''                                 ,''),
        T_FIELD_NAME('RESPONSE_JSON'    ,'CLOB'     ,''     ,''     ,''                                 ,''),
        T_FIELD_NAME('INPUT_FILENAME'   ,'VARCHAR2' ,100    ,'C'    ,''                                 ,''),
        T_FIELD_NAME('PROCESS_DATE'     ,'VARCHAR2' ,255    ,'C'    ,'TO_CHAR(sysdate, ''yyyy-mm-dd'')' ,'PROC_DATE'),

        T_FIELD_NAME('REG_NUMBER'       ,'VARCHAR2' ,255    ,'C'    ,''                                 ,''),
        T_FIELD_NAME('CONTRACT_number'  ,'VARCHAR2' ,255    ,'C'    ,''                                 ,''),
        T_FIELD_NAME('DD_NUM'           ,'VARCHAR2' ,255    ,'C'    ,''                                 ,'DD_NUMBER'), -- Only existed in NIC_UAEDDS_FILE_STG
        T_FIELD_NAME('DDS_NUMBER'       ,'VARCHAR2' ,255    ,'C'    ,''                                 ,''),
        T_FIELD_NAME('DD_DAY'           ,'VARCHAR2' ,50     ,'C'    ,''                                 ,''),
        T_FIELD_NAME('DD_FLAG'          ,'VARCHAR2' ,50     ,'C'    ,''                                 ,''),
        T_FIELD_NAME('ERROR_CD'         ,'VARCHAR2' ,255    ,'C'    ,''                                 ,''),
        T_FIELD_NAME('ERROR_MSG'        ,'VARCHAR2' ,1000   ,'C'    ,''                                 ,''),
        T_FIELD_NAME('ERROR_TYPE'       ,'VARCHAR2' ,255    ,'C'    ,''                                 ,'')
    );
------------------------------------------------------------------------------------------------------------------------
-- Go away. This is not a place to be. If you do try to enter here, you will fail and also be cursed. 
-- If somehow you succeed, then do not complain that you entered unwarned, nor bother us with your deathbed prayers
--                                                                      (c) Lord of Light by Roger Zelazny
------------------------------------------------------------------------------------------------------------------------
    V_TMP_TABLE_NAME        USER_TABLES.TABLE_NAME%type := 'TMP_PYTL_CREATE_UPDATE_TABLE';
    V_MAX_COLUMN_NAME       integer := -1;
    V_SQL_TEXT              varchar2(32000);
    V_FLAG_TABLE_EXISTS     number;
    V_FOUND_TABLE_NAME      varchar2(128);
begin
    --========================================================================--
    --== Copy data from %V_TABLE_STRUCTURE% into %V_TMP_TABLE_NAME%,
    --== because of it's impossible to compare virtual table of records with real table
    --========================================================================--
    ----------------------------------------------------------------------------
    -- Drop %V_TMP_TABLE_NAME% if it exists
    ----------------------------------------------------------------------------
    select count(*) into V_FLAG_TABLE_EXISTS from USER_TABLES where upper(TABLE_NAME) = upper(V_TMP_TABLE_NAME);
    if V_FLAG_TABLE_EXISTS = 1 then
        ------------------------------------------------------------------------
        -- Drop already existed V_TMP_TABLE_NAME
        ------------------------------------------------------------------------
        dbms_output.put_line('*** Found already existed ' || V_TMP_TABLE_NAME || ', so drop it...');
        V_SQL_TEXT := 'drop table ' || V_TMP_TABLE_NAME;
        -- dbms_output.put_line('*** ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
        dbms_output.put_line('*** Droped successfully.');
    end if;
    ------------------------------------------------------------------------
    -- Create %V_TMP_TABLE_NAME%
    ------------------------------------------------------------------------
    dbms_output.put_line('*** Create ' ||  V_TMP_TABLE_NAME || '...');
    V_SQL_TEXT := 'create table ' || V_TMP_TABLE_NAME || ' (
        COLUMN_NAME         varchar2(128 char),
        DATA_TYPE           varchar2(128 char),
        CHAR_LENGTH         number,
        CHAR_USED           varchar2(1 char),
        DATA_DEFAULT        varchar2(4000 char),
        OLD_COLUMN_NAMES    varchar2(4000 char)
    )';
    -- dbms_output.put_line('*** ' || V_SQL_TEXT);
    execute immediate V_SQL_TEXT;
    dbms_output.put_line('*** Created successfully.');
    ------------------------------------------------------------------------
    -- Copy data from %V_TABLE_STRUCTURE% into %V_TMP_TABLE_NAME%
    ------------------------------------------------------------------------
    dbms_output.put_line('*** Copy data from V_TABLE_STRUCTURE into ' ||  V_TMP_TABLE_NAME || '...');
    for i in 1 .. V_TABLE_STRUCTURE.count loop
        V_SQL_TEXT := 'insert into '|| V_TMP_TABLE_NAME ||'(COLUMN_NAME, DATA_TYPE, CHAR_LENGTH, CHAR_USED, DATA_DEFAULT, OLD_COLUMN_NAMES)'
                      || ' values('
                      || '''' || upper(V_TABLE_STRUCTURE(i).COLUMN_NAME) || ''''
                      || ', '
                      || '''' || upper(V_TABLE_STRUCTURE(i).DATA_TYPE) || ''''
                      || ', '
                      || case when V_TABLE_STRUCTURE(i).CHAR_LENGTH is null then 0 else V_TABLE_STRUCTURE(i).CHAR_LENGTH end
                      || ', '
                      || '''' || upper(V_TABLE_STRUCTURE(i).CHAR_USED) || ''''
                      || ', '
                      || '''' || replace(V_TABLE_STRUCTURE(i).DATA_DEFAULT, '''', '''''') || ''''
                      || ', '
                      || '''' || case when V_TABLE_STRUCTURE(i).OLD_COLUMN_NAMES is null then '' else V_TABLE_STRUCTURE(i).OLD_COLUMN_NAMES end || ''''
                      || ')'
        ;
        -- dbms_output.put_line('*** ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
        -- dbms_output.put_line('*** Executed successfully.');
    end loop;
    dbms_output.put_line('*** Copied successfully.');

    -- *************************************************************************************************************************
    -- *************************************************************************************************************************
    -- *************************************************************************************************************************

    select count(*) into V_FLAG_TABLE_EXISTS from USER_TABLES where upper(TABLE_NAME) = upper(V_TABLE_NAME);
    if V_FLAG_TABLE_EXISTS = 0 then
        ------------------------------------------------------------------------
        -- Table %V_TABLE_NAME% doesn't exist
        ------------------------------------------------------------------------
        dbms_output.put_line('*** Table ' || V_TABLE_NAME || ' was NOT found...');
        select count(*) into V_FLAG_TABLE_EXISTS from USER_TABLES where
            TABLE_NAME in (
                select upper(trim(regexp_substr(V_OLD_TABLE_NAMES, '[^,]+', 1, level))) 
                from dual connect by regexp_substr(V_OLD_TABLE_NAMES, '[^,]+', 1, level) is not null
            )
        ;
        if V_FLAG_TABLE_EXISTS = 1 then
            ------------------------------------------------------------------------
            -- Rename if one of V_OLD_TABLE_NAMES was found
            ------------------------------------------------------------------------
            select TABLE_NAME into V_FOUND_TABLE_NAME from USER_TABLES where
                TABLE_NAME in (
                    select upper(trim(regexp_substr(V_OLD_TABLE_NAMES, '[^,]+', 1, level))) 
                    from dual connect by regexp_substr(V_OLD_TABLE_NAMES, '[^,]+', 1, level) is not null
                )
                and rownum = 1
            ;
            dbms_output.put_line('*** Old table ' || V_FOUND_TABLE_NAME || ' was found, so rename it into new one...');
            V_SQL_TEXT := 'rename ' || V_FOUND_TABLE_NAME || ' to ' || V_TABLE_NAME;
            dbms_output.put_line('*** ' || V_SQL_TEXT);
            execute immediate V_SQL_TEXT;
            dbms_output.put_line('*** Executed successfully.');
        else
            dbms_output.put_line('*** No one table from [' || V_OLD_TABLE_NAMES || '] was NOT found...');
        end if; -- Check if OLD table exists
        ------------------------------------------------------------------------
        -- Check more one time, possible old table from V_OLD_TABLE_NAMES was not found
        ------------------------------------------------------------------------
        select count(*) into V_FLAG_TABLE_EXISTS from USER_TABLES where upper(TABLE_NAME) = upper(V_TABLE_NAME);
        if V_FLAG_TABLE_EXISTS = 0 then
            dbms_output.put_line('*** Table ' || V_TABLE_NAME || ' was NOT found again, so create the new one...');
            ------------------------------------------------------------------------
            -- Create table
            ------------------------------------------------------------------------
            V_SQL_TEXT := 'create table ' || V_TABLE_NAME || '(' || chr(10);
            -- get max length of field names
            for i in 1 .. V_TABLE_STRUCTURE.count loop
                V_MAX_COLUMN_NAME := greatest(V_MAX_COLUMN_NAME, length(V_TABLE_STRUCTURE(i).COLUMN_NAME));
            end loop;
            -- generate sql for execute immediate
            for i in 1 .. V_TABLE_STRUCTURE.count loop
                if i > 1 then
                    V_SQL_TEXT :=  V_SQL_TEXT || ',' || chr(10);
                end if;
                V_SQL_TEXT := V_SQL_TEXT || '    '
                    || RPAD( V_TABLE_STRUCTURE(i).COLUMN_NAME, V_MAX_COLUMN_NAME+1, ' ')
                    || V_TABLE_STRUCTURE(i).DATA_TYPE
                    || case when V_TABLE_STRUCTURE(i).CHAR_LENGTH is not null then
                            '(' || V_TABLE_STRUCTURE(i).CHAR_LENGTH ||
                                case when upper(V_TABLE_STRUCTURE(i).CHAR_USED) = 'B' then
                                ' BYTE'
                                else ' CHAR'
                                end
                            || ')'
                            else ''
                       end
                    || case when V_TABLE_STRUCTURE(i).DATA_DEFAULT is not null then
                            ' default ' || V_TABLE_STRUCTURE(i).DATA_DEFAULT
                            else ''
                       end
                ;
            end loop;
            V_SQL_TEXT := V_SQL_TEXT ||  chr(10) || ')';
            dbms_output.put_line('*** ' || V_SQL_TEXT);
            execute immediate V_SQL_TEXT;
            dbms_output.put_line('*** Executed successfully.');
        else
            dbms_output.put_line('*** Old table ' || V_FOUND_TABLE_NAME || ' was FOUND and successfully renamed into ' || V_TABLE_NAME || '...');
        end if; -- Double check if table was not renamed from the old one
    else
        dbms_output.put_line('*** Table ' || V_TABLE_NAME || ' was FOUND...');
    end if; -- Check if table not exists

    -- *************************************************************************************************************************
    -- https://community.oracle.com/tech/developers/discussion/3649885/execute-immediate-for-select-with-loop
    -- Because of %V_TMP_TABLE_NAME% doesn't exist at the moment of script start, Oracle checks used tables
    -- and prevent running of script with not existed table. Only with incapsulatation into 'execute immediate' it's possible to run.
    -- *************************************************************************************************************************
    --------------------------------------------------------------------------------------------------------------------
    -- COLUMN_NAME exists in meta-structure (%V_TMP_TABLE_NAME%), but not exists in REAL (ALL_TAB_COLUMNS)
    -- but one of OLD_COLUMN_NAMES exists in REAL (ALL_TAB_COLUMNS) => rename
    --------------------------------------------------------------------------------------------------------------------
    execute immediate q'{
declare
    V_SQL_TEXT varchar2(32000);
begin
    for COLUMNS_TO_RENAME in (
        select t6.COLUMN_NAME as EXISTED_NAME, t5.NEW_NAME
        from
            (
                select trim(regexp_substr(t4.OLD_COLUMN_NAMES, '[^,]+', 1, level)) as OLD_NAME, t4.COLUMN_NAME as NEW_NAME
                from (
                    select t3.OLD_COLUMN_NAMES, t3.COLUMN_NAME from }' || V_TMP_TABLE_NAME || q'{ t3 where t3.COLUMN_NAME in (
                        select t1.COLUMN_NAME from }' || V_TMP_TABLE_NAME || q'{ t1
                        left outer join (select * from ALL_TAB_COLUMNS where upper(TABLE_NAME) = '}' || upper(V_TABLE_NAME) || q'{') t2 on t1.COLUMN_NAME = t2.COLUMN_NAME
                        where t2.DATA_TYPE is null
                    )
                    and t3.OLD_COLUMN_NAMES is not null
                ) t4
                connect by regexp_substr(t4.OLD_COLUMN_NAMES, '[^,]+', 1, level) is not null
            ) t5
        join (select * from ALL_TAB_COLUMNS where upper(TABLE_NAME) = '}' || upper(V_TABLE_NAME) || q'{') t6 on t6.COLUMN_NAME = t5.OLD_NAME
    )
    loop
        dbms_output.put_line('[*] ' || COLUMNS_TO_RENAME.EXISTED_NAME || ' -> ' || COLUMNS_TO_RENAME.NEW_NAME);
        V_SQL_TEXT := 'alter table }' || V_TABLE_NAME || q'{ rename column ' || COLUMNS_TO_RENAME.EXISTED_NAME || ' to ' || COLUMNS_TO_RENAME.NEW_NAME;
        dbms_output.put_line('*** ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
        dbms_output.put_line('*** Executed successfully.');
    end loop;
end; }';

    --------------------------------------------------------------------------------------------------------------------
    -- COLUMN_NAME exists in meta-structure (%V_TMP_TABLE_NAME%), but not exist in REAL (ALL_TAB_COLUMNS) => add column
    --------------------------------------------------------------------------------------------------------------------
    execute immediate q'{
declare
    V_SQL_TEXT varchar2(32000);
begin
    for COLUMNS_TO_ADD in (
        select t1.* from }' || V_TMP_TABLE_NAME || q'{ t1
        left outer join (select * from ALL_TAB_COLUMNS where upper(TABLE_NAME) = '}' || upper(V_TABLE_NAME) || q'{') t2 on t1.COLUMN_NAME = t2.COLUMN_NAME
        where t2.DATA_TYPE is null
    )
    loop
        dbms_output.put_line('[+] ' || COLUMNS_TO_ADD.COLUMN_NAME);
        V_SQL_TEXT := 'alter table }' || V_TABLE_NAME || q'{ add '
                    || COLUMNS_TO_ADD.COLUMN_NAME
                    || ' '
                    || COLUMNS_TO_ADD.DATA_TYPE
                    || case when COLUMNS_TO_ADD.CHAR_LENGTH is not null then
                            '(' || COLUMNS_TO_ADD.CHAR_LENGTH ||
                                case when upper(COLUMNS_TO_ADD.CHAR_USED) = 'B' then
                                ' BYTE'
                                else ' CHAR'
                                end
                            || ')'
                            else ''
                       end
                    || case when COLUMNS_TO_ADD.DATA_DEFAULT is not null then
                            ' default ' || COLUMNS_TO_ADD.DATA_DEFAULT
                            else ''
                       end
        ;
        dbms_output.put_line('*** ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
        dbms_output.put_line('*** Executed successfully.');
    end loop;
end; }';
    --------------------------------------------------------------------------------------------------------------------
    -- COLUMN_NAME exists in REAL (ALL_TAB_COLUMNS), but not exist in meta-structure (%V_TMP_TABLE_NAME%) => drop column
    --------------------------------------------------------------------------------------------------------------------
    execute immediate q'{
declare
    V_SQL_TEXT varchar2(32000);
begin
    for COLUMNS_TO_DROP in (
        select t2.COLUMN_NAME from }' || V_TMP_TABLE_NAME || q'{ t1
        right outer join (select * from ALL_TAB_COLUMNS where upper(TABLE_NAME) = '}' || upper(V_TABLE_NAME) || q'{') t2 on t1.COLUMN_NAME = t2.COLUMN_NAME
        where t1.DATA_TYPE is null
    )
    loop
        dbms_output.put_line('[-] ' || COLUMNS_TO_DROP.COLUMN_NAME);
        V_SQL_TEXT := 'alter table }' || V_TABLE_NAME || q'{ drop column ' || COLUMNS_TO_DROP.COLUMN_NAME;
        dbms_output.put_line('*** ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
        dbms_output.put_line('*** Executed successfully.');
    end loop;
end; }';

    --------------------------------------------------------------------------------------------------------------------
    -- COLUMN_NAME exists in both: in REAL (ALL_TAB_COLUMNS) and in meta-structure (%V_TMP_TABLE_NAME%)
    -- but has DIFFERENT types, except DATA_DEFAULT (it's LONG in ALL_TAB_COLUMNS, so it's not possible to compare by ordinary way)
    --------------------------------------------------------------------------------------------------------------------
    execute immediate q'{
declare
    V_SQL_TEXT varchar2(32000);
begin
    for COLUMNS_TO_MODIFY in (
        select t1.* from }' || V_TMP_TABLE_NAME || q'{ t1
        left outer join (select * from ALL_TAB_COLUMNS where upper(TABLE_NAME) = '}' || upper(V_TABLE_NAME) || q'{') t2 on t1.COLUMN_NAME = t2.COLUMN_NAME
        where
            t2.COLUMN_NAME is not null
            and (
                   t1.DATA_TYPE   <> t2.DATA_TYPE
                or t1.char_length <> t2.char_length
                or t1.char_used   <> t2.char_used
            )
    )
    loop
        dbms_output.put_line('[^] ' || COLUMNS_TO_MODIFY.COLUMN_NAME);
        V_SQL_TEXT := 'alter table }' || V_TABLE_NAME || q'{ modify '
                    || COLUMNS_TO_MODIFY.COLUMN_NAME
                    || ' '
                    || COLUMNS_TO_MODIFY.DATA_TYPE
                    || case when COLUMNS_TO_MODIFY.CHAR_LENGTH is not null then
                            '(' || COLUMNS_TO_MODIFY.CHAR_LENGTH ||
                                case when upper(COLUMNS_TO_MODIFY.CHAR_USED) = 'B' then
                                ' BYTE'
                                else ' CHAR'
                                end
                            || ')'
                            else ''
                       end
                    || case when COLUMNS_TO_MODIFY.DATA_DEFAULT is not null then
                            ' default ' || COLUMNS_TO_MODIFY.DATA_DEFAULT
                            else ''
                       end
        ;
        dbms_output.put_line('*** ' || V_SQL_TEXT);
        execute immediate V_SQL_TEXT;
        dbms_output.put_line('*** Executed successfully.');
    end loop;
end; }';

    --------------------------------------------------------------------------------------------------------------------
    -- COLUMN_NAME exists in both: in REAL (ALL_TAB_COLUMNS) and in meta-structure (%V_TMP_TABLE_NAME%)
    -- but has DIFFERENT values in DATA_DEFAULT (it's LONG in ALL_TAB_COLUMNS, so it's not possible to compare by ordinary way)
    --------------------------------------------------------------------------------------------------------------------
    execute immediate q'{
declare
    V_SQL_TEXT          varchar2(32000);
    v_DATA_DEFAULT_ASIS varchar2(4000 char);
begin
    for LONG_COLUMNS_TO_MODIFY in (
        select t1.*, t2.DATA_DEFAULT as ASIS from }' || V_TMP_TABLE_NAME || q'{ t1
        right outer join (select * from ALL_TAB_COLUMNS where upper(TABLE_NAME) = '}' || upper(V_TABLE_NAME) || q'{' and DATA_DEFAULT is not null) t2 on t1.COLUMN_NAME = t2.COLUMN_NAME
    )
    loop
        v_DATA_DEFAULT_ASIS := LONG_COLUMNS_TO_MODIFY.ASIS;           -- because of impossible to compare LONG by other way
        if v_DATA_DEFAULT_ASIS <> LONG_COLUMNS_TO_MODIFY.DATA_DEFAULT then
            dbms_output.put_line('[^^] ' || LONG_COLUMNS_TO_MODIFY.COLUMN_NAME);
            V_SQL_TEXT := 'alter table }' || V_TABLE_NAME || q'{ modify '
                        || LONG_COLUMNS_TO_MODIFY.COLUMN_NAME
                        || ' '
                        || LONG_COLUMNS_TO_MODIFY.DATA_TYPE
                        || case when LONG_COLUMNS_TO_MODIFY.CHAR_LENGTH is not null then
                                '(' || LONG_COLUMNS_TO_MODIFY.CHAR_LENGTH ||
                                    case when upper(LONG_COLUMNS_TO_MODIFY.CHAR_USED) = 'B' then
                                    ' BYTE'
                                    else ' CHAR'
                                    end
                                || ')'
                                else ''
                           end
                        || case when LONG_COLUMNS_TO_MODIFY.DATA_DEFAULT is not null then
                                ' default ' || LONG_COLUMNS_TO_MODIFY.DATA_DEFAULT
                                else ''
                           end
            ;
            dbms_output.put_line('*** ' || V_SQL_TEXT);
            execute immediate V_SQL_TEXT;
            dbms_output.put_line('*** Executed successfully.');
        end if;
    end loop;
end; }';

    ----------------------------------------------------------------------------
    -- Drop %V_TMP_TABLE_NAME%
    ----------------------------------------------------------------------------
    dbms_output.put_line('*** Drop temporary ' || V_TMP_TABLE_NAME || '...');
    V_SQL_TEXT := 'drop table ' || V_TMP_TABLE_NAME;
    -- dbms_output.put_line('*** ' || V_SQL_TEXT);
    execute immediate V_SQL_TEXT;
    dbms_output.put_line('*** Droped successfully.');

    commit;
    dbms_output.put_line('*** Mission acomplished.');
end;
/
exit;
