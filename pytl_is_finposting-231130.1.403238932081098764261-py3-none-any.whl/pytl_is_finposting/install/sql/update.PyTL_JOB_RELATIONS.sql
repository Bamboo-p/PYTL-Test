/*
* Version history:
* ALMAS-514 19-Oct-2021 Sergei Miasnikov
* ENG-3781  21-Dec-2021 Denis Kaloshin
* ENG-3781  26-Dec-2021 Denis Kaloshin
*/
set linesize 2000
set serveroutput on
set verify off

declare
    V_JOB_NAME varchar2(255) := 'PyTL_IS_FinPosting';
    V_JOB_DESC varchar2(255) := 'Universal Fin Posting Service. ENG-3689, ALMAS-514, ENG-3781';
    V_SQL_TEXT varchar2(32000);
begin
    dbms_output.enable();
    
    V_SQL_TEXT := 'delete from PyTL_JOB_RELATIONS where IN_JOB_ID = '''|| V_JOB_NAME ||''' or OUT_JOB_ID = '''|| V_JOB_NAME ||'''';
    dbms_output.put_line('>>> ' || V_SQL_TEXT);
    execute immediate V_SQL_TEXT;
    
    V_SQL_TEXT := 'insert into PyTL_JOB_RELATIONS (IN_JOB_ID, OUT_JOB_ID) values ('''|| V_JOB_NAME ||''', '''|| V_JOB_NAME ||''')';
    dbms_output.put_line('>>> ' || V_SQL_TEXT);
    execute immediate V_SQL_TEXT;

    V_SQL_TEXT := 'delete from PyTL_JOBS where JOB_ID = '''|| V_JOB_NAME ||'''';
    dbms_output.put_line('>>> ' || V_SQL_TEXT);
    execute immediate V_SQL_TEXT;

    V_SQL_TEXT := 'insert into PyTL_JOBS (JOB_ID, JOB_DESC) values ('''|| V_JOB_NAME ||''', '''|| V_JOB_DESC ||''')';
    dbms_output.put_line('>>> ' || V_SQL_TEXT);
    execute immediate V_SQL_TEXT;

    commit;
end;
/
exit;
