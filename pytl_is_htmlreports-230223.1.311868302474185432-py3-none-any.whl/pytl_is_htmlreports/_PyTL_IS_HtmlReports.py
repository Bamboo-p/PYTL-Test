''' PyTL_IS_HtmlReports

References
----------
    OPKSAIC-1692

Changes
-------
    220209.1 = deniska = OPKSAIC-1692: Initial version based on PyTL_IS_SimpleReports 211219.1
    220621.1 = deniska = EK-3122: added ability to include into SQL files placeholders with complex logic based on config variable (together with pytl_core v2.7)
    220623.2 = deniska = EK-3122: looking SQL files with extension *.SQ?
    230223.1 = deniska = NICORE-513: support additional filters inside jinja template, providing config into jinja template.
'''
__version__ = "230223.1"
__job_name__ = "PyTL_IS_HtmlReports"
__bat_files__ = ["NIC_IS_Ou_HtmlReports.bat"]
import datetime

# def raiser(ex): raise ex
import pytl_core
import pytl_core.pytl_globals as pytl_globals
import logging
from pathlib import Path
# import csv
import glob
# from n0struct import *
import n0struct
import jinja2
import os
import re


__params__ = pytl_core.Params({
# Mandatory parameters
        "ENV":                      lambda: config['ENV'],                          # D:\PYTL\NIC\JOBNAME\W4UAT25.PARM
        "DATA_SOURCES":             lambda: {}  if not (
                                                        __DATA_SOURCES := (
                                                                            config.get('DATA_SOURCE', "")
                                                                            or config['DATA_SOURCES']
                                                        ).strip()
                                                )
                                                else {
                                                        (__SPLITTED_DATA_SOURCE := n0struct.split_pair(__STRIPPED_FULL_DATA_SOURCE, '=', default_element = 0))[0]
                                                        :
                                                        list(n0struct.split_pair(
                                                                __SPLITTED_DATA_SOURCE[1],
                                                                ':',
                                                                lambda x: __stripped_x
                                                                          if (__stripped_x := x.strip())
                                                                          else __params__['DB_SOURCE']
                                                                ,
                                                                lambda x: __stripped_x
                                                                          if (__stripped_x := x.strip()).lower().endswith(".sql")
                                                                          else (
                                                                            __stripped_x + ".sql"
                                                                            if __stripped_x
                                                                            else pytl_core.raiser(Excepition(f"Empty sql in '{__SPLITTED_DATA_SOURCE[1]}'"))
                                                                          )
                                                                ,
                                                        ))
                                                        for __FULL_DATA_SOURCE in __DATA_SOURCES.split(';')
                                                        if (__STRIPPED_FULL_DATA_SOURCE:=__FULL_DATA_SOURCE.strip())
                                                }
                                            ,
        "TEMPLATE":                 lambda: config['TEMPLATE'],
# Optional parameters
        "ORG":                      lambda: config.get('ORG', "")
                                            or config['ORGLIST'],                   # "982" || "982,320"
        "DB_SOURCE":                lambda: config.get('DB_SOURCE', "OWS").upper()
                                            or "OWS",                               # "DWH" || "OWS" default
        "INPUT_DATE_FORMAT":        lambda: config.get('INPUT_DATE_FORMAT', "")
                                            or "%d-%m-%Y",
        "OUTPUT_DATE_FORMAT":       lambda: config.get('OUTPUT_DATE_FORMAT', "")
                                            or "%Y%m%d",
        "P_REPORT_DATE":            lambda: config.get('P_REPORT_DATE', "")
                                            or datetime.datetime.now().strftime(__params__['INPUT_DATE_FORMAT']),
        "OUTPUT_FN_PREFIX":         lambda: os.path.splitext(os.path.basename(__params__['DATA_SOURCES'].values()[0][0]))[0]
                                            if not (__OUTPUT_FN_PREFIX := config.get('OUTPUT_FN_PREFIX', "").strip())
                                            else (
                                                __OUTPUT_FN_PREFIX
                                                if __OUTPUT_FN_PREFIX != '.'
                                                else ""
                                            )
                                            ,
        "OUTPUT_FN_SEPARATOR":      lambda: "_"
                                            if not (__OUTPUT_FN_SEPARATOR := config.get('OUTPUT_FN_SEPARATOR', ""))
                                            else (
                                                __OUTPUT_FN_SEPARATOR if __OUTPUT_FN_SEPARATOR != '.'
                                                else ""
                                            ),
        "OUTPUT_FN_SUFIX":          lambda: datetime.datetime.strptime(
                                                                __params__['P_REPORT_DATE'],
                                                                __params__['INPUT_DATE_FORMAT']
                                            ).strftime(__params__['OUTPUT_DATE_FORMAT'])
                                            if not (__OUTPUT_FN_SUFIX := config.get('OUTPUT_FN_SUFIX', ""))
                                            else (
                                                __OUTPUT_FN_SUFIX if __OUTPUT_FN_SUFIX != '.'
                                                else ""
                                            ),
        "OUTPUT_FN_EXTENSION":      lambda: ".txt" if not (__OUTPUT_FN_EXTENSION := config.get('EXTENSION', "")
                                                                                    or config.get('OUTPUT_FN_EXTENSION', "")
                                            )
                                            else (
                                                "" if __OUTPUT_FN_EXTENSION == '.'
                                                else (
                                                    "."+__OUTPUT_FN_EXTENSION if not __OUTPUT_FN_EXTENSION.startswith('.')
                                                    else __OUTPUT_FN_EXTENSION
                                                )
                                            ),
        "OUTPUT_FN_RELATED":        lambda: config.get('OUTPUT_FN_RELATED', "")
                                            or (
                                                  __params__['OUTPUT_FN_PREFIX']
                                                + __params__['OUTPUT_FN_SEPARATOR']
                                                + __params__['OUTPUT_FN_SUFIX']
                                                + __params__['OUTPUT_FN_EXTENSION']
                                            ),
# Parameters from file config['ENV']
        "DB_W4C_SRC_WLTURL":        lambda: config['DB_W4C_SRC_WLTURL'],
        "DB_DM_SRC_WLTURL":         lambda: config['DB_DM_SRC_WLTURL'],
# Precalculated values
        "JOB_NAME":                 lambda: config['JOB_NAME'],
        "SQL_DIR":                  lambda: config['SQL_DIR'],
        "DST_DIR":                  lambda: config.get('TGT_FILEPATH', "") or config['DST_DIR'],
})

def main():
    # ##########################################################################
    # Find all *.html files related to PyTL_IS_HtmlReports and generate dict for quick search
    # ##########################################################################
    html_template_files_in_all_directories = sorted(
        list(glob.iglob(
                os.path.abspath(f"{os.path.dirname(os.path.abspath(__file__))}/../{__job_name__}*/**/*.htm*"),
                recursive=True,
        )), \
        key=os.path.getmtime, reverse=True,
    )
    html_template_files = {}    # for each found HTM*-file just only 1 record will be generated,
                                # where key is lower case file name only WITHOUT extention
    for html_template_file_fullpath in html_template_files_in_all_directories:
        # key is lower case file name only WITHOUT extention
        html_template_key = os.path.splitext(os.path.basename(html_template_file_fullpath.lower()))[0]
        if not html_template_key in html_template_files:
            # First found (the mordern one) will be used, other will be ignored
            html_template_files.update({html_template_key: html_template_file_fullpath})
    if not os.path.exists(html_template_file := __params__['TEMPLATE']):
        html_template_key = os.path.splitext(os.path.basename(html_template_file.lower()))[0]
        if not html_template_key in html_template_files:
            n0struct.n0debug("html_template_files")
            raise Exception(f"Template file '{html_template_file}' is not found")
        html_template_file = html_template_files[html_template_key]
    with open(html_template_file, "rt") as in_filehandler:
        jinja2_env = jinja2.Environment()
        jinja2_env.filters["to_date"] = n0struct.to_date
        jinja2_env.filters["to_currency"] = lambda v, precision=2: round(float(v.replace(',', '')), precision)
        jinja2_env.filters["n0debug"] = n0struct.n0pretty
        # jinja2_template = jinja2.Template(in_filehandler.read())
        jinja2_template = jinja2_env.from_string(in_filehandler.read())
        
    # ##########################################################################
    # Find all *.sq? files related to PyTL_IS_HtmlReports and generate dict for quick search
    # ##########################################################################
    found_sql_query_files_in_all_directories = sorted(
        list(glob.iglob(
                os.path.abspath(f"{os.path.dirname(os.path.abspath(__file__))}/../{__job_name__}*/**/*.sq?"),
                recursive=True,
        )), \
        key=os.path.getmtime, reverse=True,
    )
    found_sql_query_files = {}  # for each found SQL-file just only 1 record will be generated,
                                # where key is lower case file name only WITHOUT extention
    for sql_query_file_fullpath in found_sql_query_files_in_all_directories:
        # key is lower case file name only WITHOUT extention
        sql_query_key = os.path.splitext(os.path.basename(sql_query_file_fullpath.lower()))[0]
        if not sql_query_key in found_sql_query_files:
            # First found (the mordern one) will be used, other will be ignored
            found_sql_query_files.update({sql_query_key: sql_query_file_fullpath})
    # ##########################################################################
    # Check if required sql exists
    # ##########################################################################
    if __params__['DB_SOURCE'] == "DWH":
        default_connection = __params__['DB_DM_SRC_WLTURL']
    else:
        default_connection = __params__['DB_W4C_SRC_WLTURL']
    datasources = __params__['DATA_SOURCES']
    for datasource_name in datasources:
        if not datasources[datasource_name][0]:
            datasources[datasource_name][0] = default_connection
        elif datasources[datasource_name][0].upper() == "DWH":
            datasources[datasource_name][0] = __params__['DB_DM_SRC_WLTURL']
        else:
            datasources[datasource_name][0] = __params__['DB_W4C_SRC_WLTURL']

        if not os.path.exists(sql_query_file := datasources[datasource_name][1]):
            sql_query_key = os.path.splitext(os.path.basename(sql_query_file.lower()))[0]
            if not sql_query_key in found_sql_query_files:
                raise Exception(f"SQL file '{sql_query_file}' is not found")
            datasources[datasource_name][1] = found_sql_query_files[sql_query_key]
    # ##########################################################################
    # Execute each sql
    # ##########################################################################
    db_connections = {}
    
    united_config = { key: __params__[key] if key in __params__ else config[key] for key in (__params__.keys() | config.keys()) }
    
    ## n0struct.n0debug("datasources")
    for datasource_name in datasources:
        sql_query_text = pytl_core.utils.load_statement_from_file(datasources[datasource_name][1], config)  # [*] 220621.1 = deniska = EK-3122: added ability to include into SQL files placeholders with complex logic based on config variable (together with pytl_core v2.7)
        sql_query_parms = {}
        for key in united_config:
            if re.search(":"+key+"\W", sql_query_text):
                sql_query_parms[key] = united_config[key]
                
        if not (db_connection_name := datasources[datasource_name][0]) in db_connections:
            ## n0struct.n0debug("db_connection_name")
            db_connections[db_connection_name] = pytl_core.Connection(db_connection_name)

        ## n0struct.n0debug("sql_query_text")
        ## n0struct.n0debug("sql_query_parms")
        ## n0struct.n0print("execute_select_batch: " + sql_query_text.split('\n')[0])
        datasources[datasource_name] = db_connections[db_connection_name].execute_select_batch(
                                                                            statement=sql_query_text,
                                                                            bind_vars=sql_query_parms,
                                                                            pd_mode=False
                                                                        )
        ## for i,row in enumerate(datasources[datasource_name]):
        ##     n0struct.n0debug_calc(row, f"datasources[{datasource_name}].row[{i}]")

    ## n0struct.n0debug("datasources")
    # ##########################################################################
    # Render html
    # ##########################################################################
    report_path = Path(__params__['DST_DIR']) / (
                                                    datetime.datetime.strptime(
                                                                __params__['P_REPORT_DATE'],
                                                                __params__['INPUT_DATE_FORMAT']
                                                    ).strftime(__params__['OUTPUT_FN_RELATED'])
                                                  )
    report_path.parent.mkdir(parents=True, exist_ok=True)
    for datasource_name in datasources:
       datasources[datasource_name] = [itm for itm in datasources[datasource_name]]
    datasources['config'] = united_config
    # n0struct.n0debug("datasources")
    logging.info(f"Saving report into '{report_path}'")
    n0struct.save_file(
                report_path,
                jinja2_template.render(**datasources)
    )

    # ##########################################################################
    # Close db_connections
    # ##########################################################################
    for db_connection_name in db_connections:
        db_connections[db_connection_name].close()

def _main():
    # global config is used in current module, outside of current procedure
    # pytl_globals.config is used in other modules
    global config
    config = pytl_globals.config = pytl_core.Config.configure_pytl_core({'JOB_FILE': __file__, 'JOB_NAME': __job_name__})

    logging.debug(f"Config: initialization finished, 'config' and 'cfg' variables were created.")
    logging.info(f"Starting {Path(__file__).stem} python job")
    main()
    logging.info(f"{Path(__file__).stem} python job is FINISHED!")
