from _PyTL_IS_HtmlReports import _main, __job_name__
 
print("*"*30 + " " + __job_name__)
if __name__ == "__main__":
    print("*"*15 + " " + __name__)
    _main()
