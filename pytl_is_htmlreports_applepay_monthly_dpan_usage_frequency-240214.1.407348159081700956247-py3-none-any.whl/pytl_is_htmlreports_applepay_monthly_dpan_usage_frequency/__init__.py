__version__ = "240214.1"
__job_name__ = "PyTL_IS_HtmlReports_APPLEPAY_Monthly_DPAN_Usage_Frequency"
__bat_files__ = []

