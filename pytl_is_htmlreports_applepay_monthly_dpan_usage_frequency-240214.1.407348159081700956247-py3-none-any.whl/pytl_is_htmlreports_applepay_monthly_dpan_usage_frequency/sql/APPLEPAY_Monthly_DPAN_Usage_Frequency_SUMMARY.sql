--APPLEPAY_Monthly_DPAN_Usage_Frequency_SUMMARY.sql
/*Version Hitory:
*Initial version: ?
*221014.1 : AJM-3217 : Added new fields
*230414.1 : OPKSAIC-5254 : Removed redundant date_sources field
*/
select dwd_institution.branch_code                                                 as ORG,
       dwd_institution.id                                                          as INSTITUTION_ID,
       dwd_institution.name                                                        as INSTITUTION_NAME,
       to_char(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'MON-YYYY')                  as REPORTING_MONTH_REAL,
       add_months(trunc(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'MM'),-1)           as FROM_INCLUDED,
       last_day(add_months(trunc(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'MM'),-1)) as TO_INCLUDED,
       to_char(add_months(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'),-1), 'MON-YYYY')   as REPORTING_MONTH
       -------------------------------------------------------------------------------------------------
        --APPLEPAY_Monthly_DPAN_Usage_Frequency_SUMMARY.sql : FWF Only
       -------------------------------------------------------------------------------------------------
       ,:TOKEN_NAME                                                                as TOKEN_NAME
       ,TO_CHAR(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'), 'DD/MM/YY')                 as P_REPORT_DATE
       ,TO_CHAR(sysdate, 'DD/MM/YY HH24.MI.SS')                                    as SYS_DATE
        -------------------------------------------------------------------------------------------------
  from dwd_institution
 where dwd_institution.record_state = 'A'
   and dwd_institution.branch_code = :ORG
   
   