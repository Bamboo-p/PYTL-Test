--APPLEPAY_Monthly_Issuer_Metrics_SUMMARY.sql
select dwd_institution.branch_code                                                 as ORG,
       dwd_institution.id                                                          as INSTITUTION_ID,
       dwd_institution.name                                                        as INSTITUTION_NAME,
       to_char(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'MON-YYYY')                  as REPORTING_MONTH_REAL,
       add_months(trunc(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'MM'),-1)           as FROM_INCLUDED,
       last_day(add_months(trunc(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'MM'),-1)) as TO_INCLUDED,
       to_char(add_months(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'),-1), 'MON-YYYY')   as REPORTING_MONTH
  from dwd_institution
 where dwd_institution.record_state = 'A'
   and dwd_institution.branch_code = :ORG
   
   