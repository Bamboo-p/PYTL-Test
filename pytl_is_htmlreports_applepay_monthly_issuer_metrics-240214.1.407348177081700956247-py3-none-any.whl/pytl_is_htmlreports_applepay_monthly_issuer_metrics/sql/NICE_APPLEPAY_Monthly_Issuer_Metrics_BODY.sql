/*
APPLEPAY_Monthly_Issuer_metrics_BODY.sql
15-02-2022 : OPKSAIC-1691 : Bharath : Initial version : Monthly issuer metrics for Apple Pay tokens
28-02-2022 : OPKSAIC-3323 : Bharath : Default Toeknization configuration for sy_handbook implemented
28-03-2022 : ALMB-619 : Shalini : re-order of nvl() in transactions subquery
31-03-2022 : ALMB-619 : Shalini : changes updated in final_3 subquery to fetch total active tokens for respective token names
19-04-2022 : OPKSAIC-1691 : Bharath : Custom tag addition to display card category code , it is optional since it is applicable for only Tiqmo
* 230406.1 = TatianaO = AUBI-3720: Fixed join to Token Requestor ID parameter
230502.1 : deniska: PRD-23886: Removing not ASCII characters
230508.1 : Shalini : AUBI-3720 : Conflicts resolution
230926.1 : BharathG : OPKSAIC-5704 : Generic changes to support MADA Tokens
240214.1 : OsamaO   : PRD-26098 : Change the Date behavior to be based on consist point date
*/
with inst as (
    select /*+ no_merge materialize */
          id,
          branch_code,
          name inst_name,
          local_currency
     from (select dwd_institution.branch_code,
                  dwd_institution.posting_institution_id,
                  dwd_institution.id,
                  dwd_institution.local_currency,
                  dwd_institution2.branch_code branch_code_posting,
                  dwd_institution.name
             from dwd_institution
             join dwd_institution dwd_institution2
               on dwd_institution.posting_institution_id = dwd_institution2.id
            where dwd_institution.record_state = 'A'
           ) inst
       start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                         from dual
                                   connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
                                      )
                            connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
    ),
m_dates as (
    select /*+no_merge materialize*/
           trunc(add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1),'mm') as min_date,
           last_day(add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1))   as max_date
      from dual
    ), 
cp_dates as (
   -- [*] OsamaO
    select  /*+ no_merge materialize*/ 
        CALENDAR_DATE CP_DATE_TO 
     from ETL_consist_point mcp
     join ETL_consist_type mct 
       on mcp.ETL_consist_type__id = mct.id
      and mct.code = 'END_DAY'
      AND MCP.AMND_STATE = 'A'
      AND MCT.AMND_STATE = 'A'
      and local_date  = last_day(add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1))
	  ),
cards as (
    select /*+no_merge materialize*/
           c.record_idt,
          decode(nvl(sy_convert.get_tag_value(dip.add_info,'PR_GROUP_REP'),p.card_category_code),
          'ISSCREDIT','CREDIT','ISSDEB','DEBIT','ISSPREPAID','PREPAID',
          nvl(sy_convert.get_tag_value(dip.add_info,'PR_GROUP_REP'),p.card_category_code)) as card_category_code
      from dwd_card c
      join inst
        on c.institution_id = inst.id
       and c.record_state   = 'A'
      join dwd_card_product p
        on c.card_product_id = p.id
       and p.record_state   = 'A'
      join dwd_int_product dip
        on dip.product_id = p.product_id
       and dip.record_state = 'A'
    ),
token_meta as (
    select /*+no_merge materialize*/
          coalesce(org_conf.code, org_conf.filter2, default_conf.code, default_conf.filter2) as code
     from ( select *
              from c$sy_handbook
             where amnd_state = 'A'
               and group_code like 'TOKEN_REQUESTOR%' --[*] 280322: ALMB-619
               and filter5 = :ORG
               and name    = :TOKEN_NAME) org_conf
full join ( select *
              from dwh.c$sy_handbook tt
             where tt.filter = '000'
               and tt.name   = :TOKEN_NAME
               and tt.group_code like 'TOKEN_REQUESTOR%'
               and tt.amnd_state = 'A') default_conf
       on (org_conf.filter2 = default_conf.filter2)
    ),
domain_tkn as (
    select /*+no_merge materialize*/
           tatu.td_auth_type__oid
      From c$td_domain td
      join c$td_auth_type_used tatu
        on td.id   = tatu.domain
     where td.code = 'VCARDS'
       and tatu.amnd_state = 'A'
       and tatu.is_ready   = 'Y'
    ),
parm_id as (
    select /*+no_merge materialize*/
          parm.id
     from v_c$td_auth_parm parm
     join v_c$td_auth_type t
       on parm.td_auth_type__oid = t.id
      and instr(t.code,:ORG) > 0
     join domain_tkn d
       on d.td_auth_type__oid = t.id
    where parm.code = 'T_STATUS'
      and parm.amnd_state = 'A'
    ),
parm_id2 as (
    select /*+no_merge materialize*/
          parm.id
     from v_c$td_auth_parm parm
     join v_c$td_auth_type t
       on parm.td_auth_type__oid = t.id
      and instr(t.code,:ORG) > 0
     join domain_tkn d
       on d.td_auth_type__oid = t.id
    where parm.code       = 'TOKEN_REQ_ID'
      and parm.amnd_state = 'A'
    ),
active_token as (
    select /*+ no_merge materialize*/
          s.id,
          s.auth_idt,
          c.card_category_code as card_category
     from v_c$td_auth_sch s
     join v_c$td_auth_type t
       on s.auth_type  = t.id
      and t.amnd_state = 'A'
      and instr(t.code,:ORG) > 0
     join domain_tkn d
       on d.td_auth_type__oid = t.id
     join cards c
       on c.record_idt = s.acnt_contract__id
     join v_c$td_auth_val td_auth_val1
       on s.id         = td_auth_val1.td_auth_sch__oid
      and td_auth_val1.parm_value = 'Active'
      and td_auth_val1.amnd_state = 'A'
     join parm_id
       on td_auth_val1.auth_parm  = parm_id.id
     join cp_dates cp -- [*] osama
     ON 1 =1 
     WHERE t.amnd_state = 'A'
     AND   S.AMND_STATE = 'A'
     AND   S.is_ready = 'Y' 
     AND   s.date_from  < cp.cp_date_to
     and nvl(s.date_to,  cp.cp_date_to ) >=cp.cp_date_to
    ),
transactions as (
    select /*+ no_merge materialize use_hash(p c) use_hash(t c) parallel(8)*/
          regexp_substr(t.trans_info, '(D_TKN+)=([^;]+);', 1, 1, '', 2) AS d_tkn,
          case when instr(dtc.condition_list, 'ENET') > 0 then 1 else 0 end as in_application_flag,
          t.amount,
          t.primary_doc_idt,
          decode(nvl(sy_convert.get_tag_value(dip.add_info,'PR_GROUP_REP'),p.card_category_code),
          'ISSCREDIT','CREDIT','ISSDEB','DEBIT','ISSPREPAID','PREPAID',
          nvl(sy_convert.get_tag_value(dip.add_info,'PR_GROUP_REP'),p.card_category_code)) as code
     from dwh.opt_dm_nice_transaction_info t
     join dwh.opt_dm_nice_contract_info c
       on c.record_idt   = t.contract_idt
     join dwd_product p
       on p.id           = c.product_id
      and p.record_state = 'A'
     join dwd_int_product dip
       on dip.product_id  = p.id
      and dip.record_state = 'A'
     join m_dates d
       on t.banking_date between d.min_date and d.max_date
left join dwh.dwd_trans_conditions dtc
       on dtc.id = t.trans_conditions_id
    where t.org  = :ORG
      and c.org  = :ORG
      and instr(t.trans_info,'D_TKN') > 0
      and nvl(sy_convert.get_tag_value(t.trans_info,'WSP_REQ_ID'),sy_convert.get_tag_value(t.trans_info,'MC_WALLET_DATA')) in (select code from token_meta) --[*]220328 ALMB-619
    ),
token_info as (
    select /*+ no_merge materialize*/
           decode(t.code,'DEBIT',d_tkn)   as count_debit,
           decode(t.code,'CREDIT',d_tkn)  as count_credit,
           decode(t.code,'PREPAID',d_tkn) as count_prepaid,
           d_tkn
      from transactions t
    ),
final_1 as (
    select /*+ no_merge materialize*/
           count(distinct count_debit)   as count_debit_tkn,
           count(distinct count_credit)  as count_credit_tkn,
           count(distinct count_prepaid) as count_prepaid_tkn,
           count(distinct d_tkn)         as count_dtkn
      from token_info
    ),
final_2 as (
    select /*+ no_merge materialize*/
           /*Monthly DPAN transaction count*/
           sum(decode(t.code,'DEBIT',1,0))   as total_debit_count,
           sum(decode(t.code,'CREDIT',1,0))  as total_credit_count,
           sum(decode(t.code,'PREPAID',1,0)) as total_prepaid_count,
           count(1)                          as count_total,

           /*Monthly DPAN spend*/
           abs(sum(decode(t.code,'DEBIT',  amount,0))) as total_debit_spend,
           abs(sum(decode(t.code,'CREDIT', amount,0))) as total_credit_spend,
           abs(sum(decode(t.code,'PREPAID',amount,0))) as total_prepaid_spend,
           abs(sum(amount))                            as amount_total,

           /*% of POS DPAN transactions out of the monthly processed DPAN transactions*/
           sum(decode(t.code,'DEBIT',  decode(t.in_application_flag,0,1,0),0)) as count_debit_pos,
           sum(decode(t.code,'CREDIT', decode(t.in_application_flag,0,1,0),0)) as count_credit_pos,
           sum(decode(t.code,'PREPAID',decode(t.in_application_flag,0,1,0),0)) as count_prepaid_pos,
           sum(decode(t.in_application_flag,0,1,0))                            as count_pos_total,

           /*% of POS DPAN spend amount out of the monthly processed DPAN transactions*/
           abs(sum(decode(t.code,'DEBIT',  decode(t.in_application_flag,0,amount,0),0))) as amount_debit_pos,
           abs(sum(decode(t.code,'CREDIT', decode(t.in_application_flag,0,amount,0),0))) as amount_credit_pos,
           abs(sum(decode(t.code,'PREPAID',decode(t.in_application_flag,0,amount,0),0))) as amount_prepaid_pos,
           abs(sum(decode(t.in_application_flag,0,amount,0)))                            as amount_pos_total,

           /*% of Remote DPAN transactions out of the monthly processed DPAN transactions*/
           sum(decode(t.code,'DEBIT',  decode(t.in_application_flag,1,1,0),0)) as count_debit_remote,
           sum(decode(t.code,'CREDIT', decode(t.in_application_flag,1,1,0),0)) as count_credit_remote,
           sum(decode(t.code,'PREPAID',decode(t.in_application_flag,1,1,0),0)) as count_prepaid_remote,
           sum(decode(t.in_application_flag,1,1,0))                            as count_remote_total,

           /*% of Remote DPAN spend amount out of the monthly processed DPAN transactions*/
           abs(sum(decode(t.code,'DEBIT',  decode(t.in_application_flag,1,amount,0),0))) as amount_debit_remote,
           abs(sum(decode(t.code,'CREDIT', decode(t.in_application_flag,1,amount,0),0))) as amount_credit_remote,
           abs(sum(decode(t.code,'PREPAID',decode(t.in_application_flag,1,amount,0),0))) as amount_prepaid_remote,
           abs(sum(decode(t.in_application_flag,1,amount,0)))                            as amount_remote_total

      from transactions t
    ),
final_3 as (
    select /*+ leading(active_token) use_hash(active_token v2) */
          /*Total Available DPANs
          Any changes to total active tokens logic should be in synch with Monthly DPAN Usage Report and ILF Dump Report*/
          to_char(nvl(sum(decode(card_category,'DEBIT',1,0)),0),'999,999,999')   as debit,
          to_char(nvl(sum(decode(card_category,'CREDIT',1,0)),0),'999,999,999')  as credit,
          to_char(nvl(sum(decode(card_category,'PREPAID',1,0)),0),'999,999,999') as prepaid,
          to_char(COUNT(1),'999,999,999')                                        as total
     from active_token
     join v_c$td_auth_val v2 --[*] 220331 : ALMB-619
       on active_token.id = v2.td_auth_sch__oid
      and v2.parm_value in (select code from token_meta)
      and v2.amnd_state   = 'A'
--[*][start] 230406.1 = TatianaO = AUBI-3720: Fixed join to Token Requestor ID parameter
     join parm_id2
       on v2.auth_parm    = parm_id2.id
--[*][end] 230406.1 = TatianaO = AUBI-3720: Fixed join to Token Requestor ID parameter
    )
 select 1 as rn,'Monthly DPAN transaction count'          as name,
        to_char(nvl(TOTAL_DEBIT_COUNT,0),'999,999,999')   as debit,
        to_char(nvl(TOTAL_CREDIT_COUNT,0),'999,999,999')  as credit,
        to_char(nvl(TOTAL_PREPAID_COUNT,0),'999,999,999') as prepaid,
        to_char(nvl(COUNT_TOTAL,0),'999,999,999')         as total
  from final_2

  union all

 select 2 as rn,'Monthly DPAN spend' as name,
        to_char(round(nvl(TOTAL_DEBIT_SPEND,0)),'999,999,999'),
        to_char(round(nvl(TOTAL_CREDIT_SPEND,0)),'999,999,999'),
        to_char(round(nvl(TOTAL_PREPAID_SPEND,0)),'999,999,999'),
        to_char(round(nvl(AMOUNT_TOTAL,0)),'999,999,999')
  from final_2

  union all

 select 3 as rn,'% of POS DPAN transactions out of the monthly processed DPAN transactions' as name,
        to_char(nvl(round((count_debit_pos/count_total)  *100,2),0))||'%',
        to_char(nvl(round((count_credit_pos/count_total) *100,2),0))||'%',
        to_char(nvl(round((count_prepaid_pos/count_total)*100,2),0))||'%',
        to_char(nvl(round((count_pos_total/count_total)  *100,2),0))||'%'
  from final_2

  union all

 select 5 as rn,'% of POS DPAN spend amount out of the monthly processed DPAN transactions' as name,
        to_char(nvl(round((amount_debit_pos/amount_total)  *100,2),0))||'%',
        to_char(nvl(round((amount_credit_pos/amount_total) *100,2),0))||'%',
        to_char(nvl(round((amount_prepaid_pos/amount_total)*100,2),0))||'%',
        to_char(nvl(round((amount_pos_total/amount_total)  *100,2),0))||'%'
  from final_2

  union all

 select 4 as rn,'% of Remote DPAN transactions out of the monthly processed DPAN transactions' as name,
        to_char(nvl(round((count_debit_remote/count_total)  *100,2),0))||'%',
        to_char(nvl(round((count_credit_remote/count_total) *100,2),0))||'%',
        to_char(nvl(round((count_prepaid_remote/count_total)*100,2),0))||'%',
        to_char(nvl(round((count_remote_total/count_total)  *100,2),0))||'%'
  from final_2

  union all

 select 6 as rn,'% of Remote DPAN spend amount out of the monthly processed DPAN transactions' as name,
        to_char(nvl(round((amount_debit_remote/amount_total)  *100,2),0))||'%',
        to_char(nvl(round((amount_credit_remote/amount_total) *100,2),0))||'%',
        to_char(nvl(round((amount_prepaid_remote/amount_total)*100,2),0))||'%',
        to_char(nvl(round((amount_remote_total/amount_total)  *100,2),0))||'%'
  from final_2

  union all

  select 8 as rn,'Monthly Active DPANs' as name,
         to_char(count_debit_tkn,'999,999,999'),
         to_char(count_credit_tkn,'999,999,999'),
         to_char(count_prepaid_tkn,'999,999,999'),
         to_char(count_dtkn,'999,999,999')
    from final_1

  union all

  select 7 as rn,'Total Available DPANs' as name,
         debit,credit, prepaid, total
    from final_3
order by rn
