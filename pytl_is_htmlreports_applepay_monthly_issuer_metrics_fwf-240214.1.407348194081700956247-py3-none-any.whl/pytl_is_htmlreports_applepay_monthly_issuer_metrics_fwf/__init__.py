__version__ = "240214.1"
__job_name__ = "PyTL_IS_HtmlReports_APPLEPAY_Monthly_Issuer_Metrics_FWF"
__bat_files__ = []

