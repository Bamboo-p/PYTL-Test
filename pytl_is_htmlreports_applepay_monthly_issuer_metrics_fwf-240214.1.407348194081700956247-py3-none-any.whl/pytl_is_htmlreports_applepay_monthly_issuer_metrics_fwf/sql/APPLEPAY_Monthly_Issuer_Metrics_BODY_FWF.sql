/*
APPLEPAY_Monthly_Issuer_Metrics_BODY_FWF.sql
221013.1 : Shalini : Initial version
230508.1 : Shalini : Synched with APPLEPAY_Monthly_Issuer_Metrics_BODY.sqp to fix join to Token Requestor ID parameter
230612.1 : PRD-24150 : Shalini : Amount field mapping changes in transactions subquery
230926.1 : BharathG : OPKSAIC-5704 : Generic changes to support MADA Tokens
240214.1 : OsamaO   : PRD-26098 : Change the Date behavior to be based on consist point date
*/
with inst as (
    select /*+ no_merge materialize */
          id,
          branch_code,
          name inst_name,
          local_currency
     from (select dwd_institution.branch_code,
                  dwd_institution.posting_institution_id,
                  dwd_institution.id,
                  dwd_institution.local_currency,
                  dwd_institution2.branch_code branch_code_posting,
                  dwd_institution.name
             from dwd_institution
             join dwd_institution dwd_institution2
               on dwd_institution.posting_institution_id = dwd_institution2.id
            where dwd_institution.record_state = 'A'
           ) inst
       start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                         from dual
                                   connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
                                      )
                            connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
    ),
m_dates as (
    select /*+no_merge materialize*/
           trunc(add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1),'mm') as min_date,
           last_day(add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1))   as max_date
      from dual
    ), 
cp_dates as (
   -- [*] OsamaO
    select  /*+ no_merge materialize*/ 
        CALENDAR_DATE CP_DATE_TO 
     from ETL_consist_point mcp
     join ETL_consist_type mct 
       on mcp.ETL_consist_type__id = mct.id
      and mct.code = 'END_DAY'
      AND MCP.AMND_STATE = 'A'
      AND MCT.AMND_STATE = 'A'
      and local_date  = last_day(add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1))
	  ) 
     ,
cards as (
    select /*+no_merge materialize*/
           c.record_idt,
          decode(nvl(sy_convert.get_tag_value(dip.add_info,'PR_GROUP_REP'),p.card_category_code),
          'ISSCREDIT','CREDIT','ISSDEB','DEBIT','ISSPREPAID','PREPAID',
          nvl(sy_convert.get_tag_value(dip.add_info,'PR_GROUP_REP'),p.card_category_code)) as card_category_code
      from dwd_card c
      join inst
        on c.institution_id = inst.id
       and c.record_state   = 'A'
      join dwd_card_product p
        on c.card_product_id = p.id
       and p.record_state   = 'A'
      join dwd_int_product dip
        on dip.product_id = p.product_id
       and dip.record_state = 'A'
    ),
token_meta as (
    select /*+no_merge materialize*/
          coalesce(org_conf.code, org_conf.filter2, default_conf.code, default_conf.filter2) as code
     from ( select *
              from c$sy_handbook
             where amnd_state = 'A'
               and group_code like 'TOKEN_REQUESTOR%' --[*] 280322: ALMB-619
               and filter5 = :ORG
               and name    = :TOKEN_NAME) org_conf
full join ( select *
              from dwh.c$sy_handbook tt
             where tt.filter = '000'
               and tt.name   = :TOKEN_NAME
               and tt.group_code like 'TOKEN_REQUESTOR%'
               and tt.amnd_state = 'A') default_conf
       on (org_conf.filter2 = default_conf.filter2)
    ),
domain_tkn as (
    select /*+no_merge materialize*/
           tatu.td_auth_type__oid
      From c$td_domain td
      join c$td_auth_type_used tatu
        on td.id   = tatu.domain
     where td.code = 'VCARDS'
       and tatu.amnd_state = 'A'
       and tatu.is_ready   = 'Y'
    ),
parm_id as (
    select /*+no_merge materialize*/
          parm.id
     from v_c$td_auth_parm parm
     join v_c$td_auth_type t
       on parm.td_auth_type__oid = t.id
      and instr(t.code,:ORG) > 0
     join domain_tkn d
       on d.td_auth_type__oid = t.id
    where parm.code = 'T_STATUS'
      and parm.amnd_state = 'A'
    ),
parm_id2 as (
    select /*+no_merge materialize*/
          parm.id
     from v_c$td_auth_parm parm
     join v_c$td_auth_type t
       on parm.td_auth_type__oid = t.id
      and instr(t.code,:ORG) > 0
     join domain_tkn d
       on d.td_auth_type__oid = t.id
    where parm.code       = 'TOKEN_REQ_ID'
      and parm.amnd_state = 'A'
    ),
active_token as (
    select /*+ no_merge materialize*/
          s.id,
          s.auth_idt,
          c.card_category_code as card_category
     from v_c$td_auth_sch s
     join v_c$td_auth_type t
       on s.auth_type  = t.id
      and t.amnd_state = 'A'
      and instr(t.code,:ORG) > 0
     join domain_tkn d
       on d.td_auth_type__oid = t.id
     join cards c
       on c.record_idt = s.acnt_contract__id
     join v_c$td_auth_val td_auth_val1
       on s.id         = td_auth_val1.td_auth_sch__oid
      and td_auth_val1.parm_value = 'Active'
      and td_auth_val1.amnd_state = 'A'
     join parm_id
       on td_auth_val1.auth_parm  = parm_id.id
     join cp_dates cp -- [*] OsamaO
     ON 1 =1 
     WHERE t.amnd_state = 'A'
     AND   S.AMND_STATE = 'A'
     AND   S.is_ready = 'Y' 
     AND   s.date_from  < cp.cp_date_to
     and   nvl(s.date_to,  cp.cp_date_to ) >=cp.cp_date_to
    ),

contracts as
(Select /*+ index(DWD_CONTRACT_INST_IDX c)*/
    c.record_idt,
    c.personal_account,
    decode(nvl(sy_convert.get_tag_value(dip.add_info, 'PR_GROUP_REP'), p.card_category_code), 'ISSCREDIT', 'CREDIT', 'ISSDEB', 'DEBIT',
           'ISSPREPAID', 'PREPAID', nvl(sy_convert.get_tag_value(dip.add_info, 'PR_GROUP_REP'), p.card_category_code)) AS code
FROM dwd_contract c
JOIN inst i ON i.id = c.institution_id --[*] 220718 = AJM-3617
JOIN M_DATES D -- [*] OSAMA
ON c.record_date_from <= D.MAX_DATE
AND c.record_date_to >= D.MAX_DATE
JOIN dwd_int_product dip ON dip.product_id = c.product_id
AND dip.record_state = 'A'
JOIN dwd_product p ON p.id = c.product_id
AND p.record_state = 'A'
)
,operation_types as (
    select /*+ no_merge materialize */
           *
      from v_dwr_operation_type
      join inst
        on class_code = inst.branch_code||'_TXN_CODE'
     )
,entry as(
select /*+ no_merge use_nl(e) nlj_prefetch(e) use_nl(inst) use_nl(d) use_nl(op) swap_join_inputs(inst) swap_join_inputs(op) swap_join_inputs(d)*/
                   e.contract_idt,
                   e.banking_date,
                   e.primary_doc_idt,
                   sum(credit-debit) as amount
              from dwf_account_entry e
                  join inst
               on inst.id         = e.institution_id
                --[+] 221004.1 : AJM-4114
               join contracts c
               on c.record_idt=e.contract_idt
               --[+] 221004.1 : AJM-4114
               join m_dates d
                on e.banking_date between d.min_date and d.max_date
              join operation_types op
              on op.operation_type_id = e.operation_type_id
               where e.account_group_id not in (select id from dwd_account_group where record_state = 'A' and code = 'ISS-D-2740636506')
          group by e.contract_idt, e.banking_date, e.primary_doc_idt
          ),
transactions as (

 select /*+ parallel(4) no_px_join_filter(t) no_pq_replicate(t) pq_distribute(t broadcast none)*/
          regexp_substr(t.add_info, '(D_TKN+)=([^;]+);', 1, 1, '', 2) AS d_tkn,
          case when instr(dtc.condition_list, 'ENET') > 0 then 1 else 0 end as in_application_flag,
--[*]begin 230612.1 : PRD-24150
          e.amount as amt1,
          t.local_amount as amount,
--[*]end 230612.1 : PRD-24150
          e.primary_doc_idt,
          c.code
     from  contracts c
     join entry e on c.record_idt=e.contract_idt
     join  dwh.dwf_transaction t
      on  e.primary_doc_idt=t.doc_idt
      join inst i
      on i.id=t.institution_id
     join m_dates d
       on t.banking_date between d.min_date and d.max_date
left join dwh.dwd_trans_conditions dtc
       on dtc.id = t.trans_conditions_id
where instr(t.add_info,'D_TKN') > 0
and nvl(sy_convert.get_tag_value(t.add_info,'WSP_REQ_ID'),sy_convert.get_tag_value(t.add_info,'MC_WALLET_DATA')) in (select code from token_meta)
    ),
token_info as (
    select /*+ no_merge materialize*/
           decode(t.code,'CREDIT',d_tkn)  as count_credit,
           d_tkn
      from transactions t
    ),
final_1 as (
    select /*+ no_merge materialize*/
           count(distinct d_tkn)         as count_dtkn
      from token_info
    ),
final_2 as (
    select /*+ no_merge materialize*/
           /*MONTHLY DPAN TRANSACTION COUNT*/
           count(1)                                                     as count_total,

           /*MONTHLY DPAN SPEND*/
           abs(sum(amount))                                             as amount_total,

           /*PERCENTAGE OF POS DPAN TRANSACTIONS*/
           sum(decode(t.in_application_flag,0,1,0))                     as count_pos_total,

           /*PERCENTAGE OF POS DPAN AMOUNT*/
           abs(sum(decode(t.in_application_flag,0,amount,0)))           as amount_pos_total,

           /*PERCENTAGE OF INAPP DPAN TRANSACTIONS*/
           sum(decode(t.in_application_flag,1,1,0))                     as count_remote_total,

           /*PERCENTAGE OF INAPP DPAN AMOUNT*/
           abs(sum(decode(t.in_application_flag,1,amount,0)))           as amount_remote_total

      from transactions t
    ),
final_3 as (
    select /*+ leading(active_token) use_hash(active_token v2) */
          /*Total Available DPANs*/
         COUNT(1)                                                as total
     from active_token
join v_c$td_auth_val v2
       on active_token.id = v2.td_auth_sch__oid
      and v2.parm_value in (select code from token_meta)
      and v2.amnd_state   = 'A'
join parm_id2 --[*] 230508.1 : AUBI-3720
       on v2.auth_parm    = parm_id2.id
    )
 select 1 as rn,'MONTHLY DPAN TRANSACTION COUNT          :'          as "FIELD_NAME",

        to_char(nvl(COUNT_TOTAL,0))      as "EXPECTED_VALUE"
  from final_2

  union all

 select 2 as rn,'MONTHLY DPAN SPEND                      :' as "FIELD_NAME",

        to_char(round(nvl(AMOUNT_TOTAL,0))) as "EXPECTED_VALUE"
  from final_2

  union all

 select 3 as rn,'PERCENTAGE OF POS DPAN TRANSACTIONS     :' as "FIELD_NAME",

        to_char(nvl(round((count_pos_total/count_total)  *100,2),0)) as "EXPECTED_VALUE"
  from final_2

  union all

 select 5 as rn,'PERCENTAGE OF POS DPAN AMOUNT           :' as "FIELD_NAME",

        to_char(nvl(round((amount_pos_total/amount_total)  *100,2),0)) as "EXPECTED_VALUE"
  from final_2

  union all

 select 4 as rn,'PERCENTAGE OF INAPP DPAN TRANSACTIONS   :' as "FIELD_NAME",

        to_char(nvl(round((count_remote_total/count_total)  *100,2),0)) as "EXPECTED_VALUE"
  from final_2

  union all

 select 6 as rn,'PERCENTAGE OF INAPP DPAN AMOUNT         :' as "FIELD_NAME",

        to_char(nvl(round((amount_remote_total/amount_total)  *100,2),0)) as "EXPECTED_VALUE"
  from final_2

  union all

  select 8 as rn,'MONTHLY ACTIVE DPANS                    :' as "FIELD_NAME",

         to_char(count_dtkn) as "EXPECTED_VALUE"
    from final_1

  union all

  select 7 as rn,'TOTAL AVAILABLE ACTIVE DPANS            :' as "FIELD_NAME",
         to_char(total) as "EXPECTED_VALUE"
    from final_3
order by rn
