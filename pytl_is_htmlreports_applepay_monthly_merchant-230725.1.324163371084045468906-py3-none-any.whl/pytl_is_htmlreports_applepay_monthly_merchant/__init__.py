__version__ = "230725.1"
__job_name__ = "PyTL_IS_HtmlReports_APPLEPAY_Monthly_Merchant"
__bat_files__ = []

