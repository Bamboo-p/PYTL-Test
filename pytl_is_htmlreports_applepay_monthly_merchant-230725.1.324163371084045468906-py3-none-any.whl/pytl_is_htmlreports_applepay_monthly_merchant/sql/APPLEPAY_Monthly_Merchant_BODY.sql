/*
APPLEPAY_Monthly_Merchant_BODY.sql
31-01-2022 : OPKSAIC-1697 : Bharath : Initial version : Monthly merchant report for Apple Pay tokens
28-02-2022 : OPKSAIC-3323 : Bharath : Default Toeknization configuration for sy_handbook implemented
04-10-2022 : OPKSAIC-1697 : Santosh : Logic correction for fx_rate date
11-10-2022 : OPKSAIC-1697 : Santosh : correction for TRANSACTION_PRECETAGE
28-03-2023 : ETSLT-389 : Santosh : correction to populate tokenized_trans
27-03-2023 : OPKSAIC-5283 : Santosh : Filter rejected transactions
25-07-2023 : ETSLT-547 : Santosh : trans_amount changed to settl_amount
*/
with inst as (
	select /*+ no_merge materialize */ 
          id,
		  branch_code,
		  name inst_name,
		  local_currency
     from (select dwd_institution.branch_code,
				  dwd_institution.posting_institution_id,
				  dwd_institution.id,
                  dwd_institution.local_currency,
				  dwd_institution2.branch_code branch_code_posting,
                  dwd_institution.name
			 from dwd_institution
			 join dwd_institution dwd_institution2 
			   on dwd_institution.posting_institution_id = dwd_institution2.id
		    where dwd_institution.record_state = 'A'
		   ) inst
	   start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
										 from dual 
								   connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
									  )
					        connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
	),
--[+]begin 221004.1 = OPKSAIC-1697 : Santosh : Logic correction for fx_rate date
m_dates as (
	select /*+no_merge materialize*/
           trunc(add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1),'mm') as min_date, 
		   last_day(add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1))   as max_date
	  from dual
	),
--[+]end 221004.1 = OPKSAIC-1697 : Santosh : Logic correction for fx_rate date    
conversion_rates as (
	select /*+no_merge materialize*/
	      f.base_currency as settl_currency,
          f.rate_value
         ,f.banking_date --[+]begin 221004.1 = OPKSAIC-1697 : Santosh : Logic correction for fx_rate date
     from dwf_fx_rate f
	 join inst i
	   on f.institution_id = i.id
     join dwd_fx_rate_type d 
       on d.id = f.fx_rate_type_id
      and d.record_state   = 'A'
      --[+]begin 221004.1 = OPKSAIC-1697 : Santosh : Logic correction for fx_rate date
      join m_dates d
	   on f.banking_date between d.min_date and d.max_date
--    where f.banking_Date   = to_date(:P_REPORT_DATE,'DD-MM-YYYY')
      where d.fx_type_code   = 'D'
      --[+]end 221004.1 = OPKSAIC-1697 : Santosh : Logic correction for fx_rate date
      and d.rate_type_code = 'M'
      and base_currency    = i.local_currency
      and quote_currency   = (select min(code) from dwd_currency where name = 'USD' and record_state ='A')
		),
token_meta as (
    select /*+no_merge materialize*/ 
          coalesce(org_conf.code, org_conf.filter2, default_conf.code, default_conf.filter2) as code
     from ( select *
              from c$sy_handbook
             where amnd_state = 'A'
               and group_code like 'TOKEN_REQUESTOR'
               and filter5 = :ORG
               and name    = :TOKEN_NAME) org_conf
full join ( select *
              from dwh.c$sy_handbook tt
             where tt.filter = '000'
               and tt.name   = :TOKEN_NAME
               and tt.group_code like 'TOKEN_REQUESTOR%'
               and tt.amnd_state = 'A') default_conf
       on (org_conf.filter2 = default_conf.filter2) 
    ),
tokenized_trans as (
	select /*+no_merge materialize use_hash(t i) use_hash(t d) leading(d t)*/
	      count(1)                         as transaction_count,
		  round(sum(t.settl_amount*c.rate_value)) as transaction_spend, --[*]25-07-2023 : ETSLT-547 : Santosh : trans_amount changed to settl_amount
          min(t.trans_details)             as merchant_name
--          merchant   --[+] BEGIN 230427.1 = OPKSAIC-5283 : Santosh : Filter rejected transactions
	 from dwf_transaction t
	 join inst i
	   on t.institution_id = i.id
	 join m_dates d
	   on t.banking_date between d.min_date and d.max_date
	 join conversion_rates c
     --[+]begin 221004.1 = OPKSAIC-1697 : Santosh : Logic correction for fx_rate date
--	   on t.settl_currency = c.settl_currency
       on t.banking_date = c.banking_date
       --[+]end 221004.1 = OPKSAIC-1697 : Santosh : Logic correction for fx_rate date
	where instr(t.add_info,'D_TKN') > 0
	  and nvl(sy_convert.get_tag_value(t.add_info,'WSP_REQ_ID'),sy_convert.get_tag_value(t.add_info,'MC_WALLET_DATA')) in (select code from token_meta) --[*] 230328.1 = ETSLT-389 : Santosh : correction to populate tokenized_trans
       --[+] BEGIN 230427.1 = OPKSAIC-5283 : Santosh : Filter rejected transactions
      and t.posting_status <> 'E'
 group by t.trans_details
     --[+] END 230427.1 = OPKSAIC-5283 : Santosh : Filter rejected transactions
	),
total_count as (
	select /*+no_merge materialize */
	      sum(transaction_spend) as total_spend
	 from tokenized_trans
    )
    select rownum                                    as RANK_ASC,
           merchant_name                             as MERCHANT_NAME,
           round(per_spend,3)||'%'                   as TRANSACTION_PRECETAGE, --[+]begin 221011.1 = OPKSAIC-1697 : Santosh : correction for TRANSACTION_PRECETAGE
           to_char(transaction_spend,'L999,999,999') as TRANSACTION_SPENT,
           transaction_count                         as TRANSACTION_COUNT
      from (select merchant_name,
                   (transaction_spend/total_spend)*100 as per_spend,
                   transaction_spend,
                   transaction_count
              from tokenized_trans
              join total_count
                on 1 = 1
          order by transaction_spend desc,transaction_count desc
           ) where rownum <= 100
