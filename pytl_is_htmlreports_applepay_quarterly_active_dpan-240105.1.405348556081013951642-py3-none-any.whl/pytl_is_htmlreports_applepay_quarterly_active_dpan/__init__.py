__version__ = "240105.1"
__job_name__ = "PyTL_IS_HtmlReports_APPLEPAY_Quarterly_Active_DPAN"
__bat_files__ = []

