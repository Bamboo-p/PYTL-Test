/*
APPLEPAY_Quarterly_Active_DPAN_BODY.sql
25-01-2022 : OPKSAIC-1702 : Bharath : Initial version : Quarterly DPAN Active report for Apple Pay tokens
28-02-2022 : OPKSAIC-3323 : Bharath : Default Toeknization configuration for sy_handbook implemented
19-04-2022 : OPKSAIC-1702 : Bharath : Custom tag addition to display card category code , it is optional since it is applicable for only Tiqmo
28-03-2023 : ETSLT-389 : Santosh : correction to populate tokenized_trans
240105.1 = Shalini = IB-702: Logic changes to remove date manuplations
*/
with inst as (     
    select /*+ no_merge materialize */ 
          id,
          branch_code,
          name inst_name
     from (select dwd_institution.branch_code,
                  dwd_institution.posting_institution_id,
                  dwd_institution.id,
                  dwd_institution2.branch_code branch_code_posting,
                  dwd_institution.name
             from dwd_institution
             join dwd_institution dwd_institution2 
               on dwd_institution.posting_institution_id = dwd_institution2.id
            where dwd_institution.record_state = 'A'
           ) inst
       start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                         from dual 
                                   connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
                                      )
                            connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
    ),
token_meta as (
    select /*+no_merge materialize*/ 
          coalesce(org_conf.code, org_conf.filter2, default_conf.code, default_conf.filter2) as code
     from ( select *
              from c$sy_handbook
             where amnd_state = 'A'
               and group_code like 'TOKEN_REQUESTOR'
               and filter5 = :ORG
               and name    = :TOKEN_NAME) org_conf
full join ( select *
              from dwh.c$sy_handbook tt
             where tt.filter = '000'
               and tt.name   = :TOKEN_NAME
               and tt.group_code like 'TOKEN_REQUESTOR%'
               and tt.amnd_state = 'A') default_conf
       on (org_conf.filter2 = default_conf.filter2) 
    ),
base as (
    select /*+no_merge materialize*/
          level as rn,
          decode(level,1,'DEBIT',2,'CREDIT',3,'PREPAID') as card_type
     from dual
 connect by level <= 3
    ),
q_dates as (
    select /*+no_merge materialize*/
           min(dt) as min_date, 
           last_day(max(dt)) as max_date,
           to_char(dt,'Q')
      from (select add_months(trunc(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),'y'), level - 1) dt 
              from dual
        connect by level <= 12 )
   group by to_char(dt,'Q')
    ),
cards as (
    select /*+no_merge materialize use_hash(c i) use_hash(c dcp)*/
          c.record_idt as card_idt,
          decode(nvl(sy_convert.get_tag_value(dip.add_info,'PR_GROUP_REP'),dcp.card_category_code),
          'ISSCREDIT','CREDIT','ISSDEB','DEBIT','ISSPREPAID','PREPAID',
          nvl(sy_convert.get_tag_value(dip.add_info,'PR_GROUP_REP'),dcp.card_category_code)) as card_category_code
     from dwd_card c
     join inst i
       on c.institution_id    = i.id
     join dwd_card_product dcp
       on c.card_product_id   = dcp.id
     join dwd_int_product dip
       on dip.product_id = dcp.product_id
      and dip.record_state = 'A'
    where c.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
      and c.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
    ),
tokenized_trans as (
    select /*+no_merge materialize use_hash(t i) use_hash(t d) use_hash(t c) leading(d t)*/
          count(distinct c.card_idt) as card_count,
          c.card_category_code
     from dwf_transaction t
     join inst i
       on t.institution_id = i.id
     join q_dates d
       on d.max_date       = to_date(:P_REPORT_DATE,'DD-MM-YYYY') -- [*] 240105.1 = IB-702
      and t.banking_date between d.min_date and d.max_date
     join cards c
       on nvl(t.target_card_idt,t.source_card_idt) = c.card_idt
    where instr(t.add_info,'D_TKN') > 0
      and nvl(sy_convert.get_tag_value(t.add_info,'WSP_REQ_ID'),sy_convert.get_tag_value(t.add_info,'MC_WALLET_DATA')) in (select code from token_meta) --[*] 230328.1 = ETSLT-389 : Santosh : correction to populate tokenized_trans
 group by card_category_code
    )
    select decode(b.card_type,'DEBIT','Apple Pay Active Debit Card','CREDIT','Apple Pay Active Credit Card','PREPAID','Apple Pay Active Prepaid Card') as "DPAN_TYPE",
           nvl(t.card_count,0) as "NO_OF_ACTIVE_DPAN"
      from base b
 left join tokenized_trans t
        on b.card_type = t.card_category_code
  order by b.rn asc