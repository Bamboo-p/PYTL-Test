/* APPLEPAY_Quarterly_Active_DPAN_SUMMARY.sql
220210.1 = Bharath = OPKSAIC-1702: Initial version
240105.1 = Shalini = IB-702: Logic changes to remove date manuplations
*/
with q_data as (
    select /*+no_merge materialize*/
           min(dt) as min_date, 
           last_day(max(dt)) as max_date,
           to_char(dt,'Q')
      from (select add_months(trunc(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),'y'), level - 1) dt
              from dual
        connect by level <= 12 )
   group by to_char(dt,'Q')
   )
   select i.branch_code                        as ORG,
          i.id                                 as INSTITUTION_ID,
          i.name                               as INSTITUTION_NAME,
          to_date(:P_REPORT_DATE,'DD-MM-YYYY') as P_REPORT_DATE,
          q.max_date                           as REPORTING_QUARTER_END 
     from dwd_institution i
     join q_data q
       on q.max_Date = to_date(:P_REPORT_DATE,'DD-MM-YYYY') -- [*] 240105.1 = IB-702
      and i.record_state = 'A'
      and i.branch_code = :ORG
