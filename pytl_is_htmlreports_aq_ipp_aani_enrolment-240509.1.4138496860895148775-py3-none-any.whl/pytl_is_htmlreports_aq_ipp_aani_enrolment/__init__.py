__version__ = "240509.1"
__job_name__ = "PyTL_IS_HtmlReports_AQ_IPP_AANI_ENROLMENT"
__bat_files__ = []

