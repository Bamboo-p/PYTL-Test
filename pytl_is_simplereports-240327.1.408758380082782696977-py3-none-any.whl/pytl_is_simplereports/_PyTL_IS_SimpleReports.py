''' NIC_IS_Ou_SimpleReports

This pytl job dumps data from DB to delimited file.


Requirements
------------
pytl-core >= 0.1.6


Parameters
----------
ENV
    Specifies path to settings file with database connection and in/out/etc dirs paths.
    Can be an absolute or relative path, or a file name without extension.
    Mandatory.

DB_SOURCE : string
    Oracle schema name as a source.
    Possible values: DWH and OWS.
    Mandatory.

SQL_QUERIES or SQL_QUERY (legacy names 'OUTPUT_FN' and 'SQLQUERY' are still supported)
    List (or single) file name of the SQL query(-ies) with modificators:
    Global:
        DBSOURCE=OWS|DWH|STG
        WRITE_HEADER=TRUE|FALSE
        SKIP_COLUMNS={ColumnName#n},?
        COLUMNS_QUANTITY={max header (1st row) columns in query#n},{max body columns in query#n},{max footer (last row) columns in query#n};?
    SQL_QUERIES=
                (DBSOURCE=OWS|DWH|STG)?:?
                (WRITE_HEADER=TRUE|FALSE)?:?
                (SKIP_COLUMNS={ColumnName#1}(,{ColumnName#n})?)?:?
                (COLUMNS_QUANTITY={max header (1st row) columns in query#n},{max body columns in query#n},{max footer (last row) columns in query#n})?:?
                {SQL File#n};?

    Possible values:
        {SQL file #1}
        {SQL file #1};{SQL file #2};{SQL file #n}
        {Local param#1 for current SQL file}:{Local param#n for current SQL file}:{SQL file #1};{SQL file #2};{SQL file #n}
    Samples:
        "OUTPUT_FN=QUERY1.SQL"
        "SQL_QUERY=QUERY1.SQL"
        "SQL_QUERIES=QUERY1.SQL"
        "SQL_QUERIES=QUERY_FIRST.SQL;QUERY_OTHER.SQL;QUERY_FIRST.SQL"
        "SQL_QUERIES=QUERY_FIRST;QUERY_OTHER;QUERY_FIRST"
        "SQL_QUERIES=C:\SQL1\QUERY_FIRST.SQL;D:\SQL2\QUERY_OTHER.SQL;C:\SQL1\QUERY_FIRST.SQL"
        "SQL_QUERIES=DBSOURCE=STG:QUERY_FIRST;WRITE_HEADER=FALSE:SKIP_COLUMNS=DATE1,DATE2:QUERY_OTHER;COLUMNS_QUANTITY=1,,2:QUERY_FIRST"
    Mandatory.

ORGLIST or ORG
    Sql-query parameter. ORG or ORGLIST is used depends of Sql-query.
    Plan:
        * to use ORGLIST only in case of several ORG are allowed in sql-query.
        * to use ORG only in case of just single ORG is allowed in sql-query.
    List of financial institutions, may be one value.
    Mandatory.
    If it is required not to segregate results into the different destination files, then
    ORGLIST/ORG should be "000" and the list of BANK_CODES should be provided (if it's required) inside the different parameter.
    Samples:
        "ORGLIST=001,002,003"
        "ORGLIST=001"
        "ORGLIST=000"
        "ORG=001"
        "ORG=000"

INPUT_DATE_FORMAT
    Format of incomming dates. For example P_REPORT_DATE.
    Optional, default value is "%d-%m-%Y" (DD-MM-YYYY)

OUTPUT_DATE_FORMAT
    Format of outgoing dates. For example OUTPUT_FN_SUFIX.
    Optional, default value is "%Y%m%d" (YYYYMMDD).

P_REPORT_DATE
    Sql-query parameter. Date for report generation in INPUT_DATE_FORMAT (by default "%d-%m-%Y" (DD-MM-YYYY)).
    Optional, default value is sysdate in {INPUT_DATE_FORMAT} (by default "%d-%m-%Y" (DD-MM-YYYY)).

DELIMITER
    Delimiter (columns separator) in output file.
    Optional, default value is "|"

OUTPUT_FN_PREFIX (legacy name 'REPORT_NAME_PREFIX' is still supported)
    File name prefix of the output file.
    Optional, default value is "{SQLQUERY without path and extensions}"

OUTPUT_FN_SEPARATOR
    File name separator of the output file between {OUTPUT_FN_PREFIX} and {OUTPUT_FN_SUFIX}.
    Optional, default value is "_"

OUTPUT_FN_SUFIX
    File name sufix of the output file after {OUTPUT_FN_PREFIX}{OUTPUT_FN_SEPARATOR}.
    Optional, default value is {P_REPORT_DATE} in {OUTPUT_DATE_FORMAT} (by default "%Y%m%d" (YYYYMMDD))

OUTPUT_FN_EXTENSION (legacy name 'EXTENSION' is still supported)
    File name extension of the output file.
    Optional, default value is ".txt"

OUTPUT_FN_RELATED (after support of legacy name 'OUTPUT_FN' will be finished, will be renamed into 'OUTPUT_FN')
    Output file name.
    Optional, default value is "{OUTPUT_FN_PREFIX}{OUTPUT_FN_SEPARATOR}{OUTPUT_FN_SUFIX}{OUTPUT_FN_EXTENSION}"

MINIMUM_ROWS
    Possible values: numbers
    Default value is 1
    If destionation report contains rows less that MINIMUM_ROWS, then it means that destionation report was not generated/is empty

CREATE_EMPTY_REPORT
    Possible values: TRUE, YES, 1 => True, else => False
    Default value is True
    If CREATE_EMPTY_REPORT is False and destination report was not generated/is empty (look to MINIMUM_ROWS), then the destination report will be not generated/deleted.
    Else the empty destination report file will be generated (only with header if WRITE_HEADER is True).

WRITE_HEADER
    Possible values: TRUE, YES, 1 => True, else => False
    Default value is True
    If WRITE_HEADER is True, then the header (the columns' names)  will be writted into destination report file.

SKIP_COLUMNS
    Possible values: {Column name #1},{Column name #2},{Column name #n}
    Default value is empty.
    If SKIP_COLUMNS is not empty, then the columns with names in SKIP_COLUMNS will be not saved inside destination report file.

PACK
    Possible values: BZIP2, LZMA, DEFLATED
    Default value is empty.
    If PACK is not empty, then the destination report will be compessed into .zip file.

COLUMNS_QUANTITY
    Possible values: {maximum quantity of columns in the first line of the report},{maximum quantity of columns in the middle lines of the report},{maximum quantity of columns in the last line of the report}
    Default value is 888,888,888;888,888,888;888,888,888...
    If the quantity of fetched columns is more that defined in COLUMNS_QUANTITY, then such columnes will be truncated.
    If the quantity of fetched columns is less that defined in COLUMNS_QUANTITY, then they will be provided as is.
    Variable contains values for ALL files in SQL_QUERIES

    Samples:
        "COLUMNS_QUANTITY=3,7,2"    -> First row will contain maximum 3 columns, last row will contain maximum 2 columns, other rows will contain maximum 7 columns
        "COLUMNS_QUANTITY=3,7"      -> First row will contain maximum 3 columns, all other rows will contain maximum 7 columns
        "COLUMNS_QUANTITY=3,7,"     -> First row will contain maximum 3 columns, last row will contain maximum 888 columns, other rows will contain maximum 7 columns
        "COLUMNS_QUANTITY=3"        -> A rows will contain maximum 3 columns
        "COLUMNS_QUANTITY=3,"       -> First row will contain maximum 3 columns, all other rows will contain maximum 888 columns
        "COLUMNS_QUANTITY=3,,"      -> First row will contain maximum 3 columns, all other rows will contain maximum 888 columns
        "COLUMNS_QUANTITY=3,,2"     -> First row will contain maximum 3 columns, last row will contain maximum 2 columns, other rows will contain 888 columns
        "COLUMNS_QUANTITY=,7,"      -> First row will contain maximum 888 columns, last row will contain maximum 888 columns, other rows will contain 7 columns
        "COLUMNS_QUANTITY=,,;,,2"   -> Without any limitations for the first SQL file, not more that 2 columns for in the last row of the second SQL file

MASK_ALL
    Possible values: TRUE, YES, 1 => True, else => False
    Default value is False
    If MASK_ALL is True, then apply MASK_PATTERN to each (except header) row in destination report file.

MASK_PATTERN
    Possible values: {search for}={replace with}
    Default value is ([34569][0-9]{5})([0-9]{6})([0-9]{4})=\1******\3
    Is used only if MASK_ALL is True, of MASK_COLUMNS is set and mask patterns are not defined.
    Samples:
        "MASK_PATTERN=([34569][0-9]{5})([0-9]{6})([0-9]{4})=\1xxxxxx\3" -> Replace middle 6 numbers in all number sequences like PAN with 'xxxxxx'
        "MASK_PATTERN=0=o" -> Replace all '0' with 'o'

MASK_COLUMNS
    Possible values: {Column name #1}={search for}={replace with};{Column name #2}={search for}={replace with};{Column name #n}={search for}={replace with}
    Default value is empty.
    Samples:
        "MASK_COLUMNS=CARD_NO=([34569][0-9]{5})([0-9]{6})([0-9]{4})=\1xxxxxx\3" -> Replace middle 6 numbers in all number sequences like PAN with 'xxxxxx' in the column CARD_NO.
        "MASK_COLUMNS=ACCNT_NO=0=o;ACCNT_ID=1=i;"                               -> Replace all '0' with 'o' in the column ACCNT_NO, replace all '1' with 'i' in the column ACCNT_ID.
        "MASK_COLUMNS=ACCNT_NO;ACCNT_ID=1=i;ACNT_DESC"                          -> Replace all '1' with 'i' in the column ACCNT_ID, apply MASK_PATTERN to ACCNT_NO, ACNT_DESC.

CSV_GENERATOR
    Possible values: NATIVE|COMPLEX|SIMPLE.
    Default value is SIMPLE.
    Depends of value different implementation of CSV functionality will be used:
        SIMPLE  -> Own functionality WITHOUT validation of each column values
        COMPLEX -> Own functionality WITH validation of each column values
        NATIVE  -> standard module csv
    Samples:
        "CSV_GENERATOR=SIMPLE"  -> Could be used with PACK/MASK_ALL, the fastest. Could be used ONLY if there are no delimiters inside column values.
        "CSV_GENERATOR=COMPLEX" -> Could be used with PACK/MASK_ALL, the slowest. Could be used if there is no information about possible column values.
        "CSV_GENERATOR=NATIVE"  -> Could NOT be used with PACK/MASK_ALL, the almost fast like SIMPLE. Could be used if there is no information about possible column values.

References
----------
    ENG-3193
    ADCB-9182
    ALMAS-123
    ALMAS-383
    ADCB-9182
    ADCB-9810
    OPKSAIC-118/OPKSAIC-1693
    ENG-4179/ENG-4180

Changes
-------
    210324.1 = Nikita Fomin =           ENG-3193 : adding NIC_IS_Ou_SimpleReports
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/7e0d89cf74fbe6072455ee5b99e84e71a32d99b9#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports.py
    210408.1 = Nikita Fomin =           ENG-3193 : refactoring NIC_IS_Ou_SimpleReports in order to handle large datasets
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/0127cc8c3314bb9190089bc7f610a1cb14ae0777#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210421.1 = Nikita Fomin =           ENG-3309 : fixing issue with encoding
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/f231600b9c349eabdc007688f564e9f3ea2c36da#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210419.1 = Aliaksandr Tsurko =      Updated to core v0.1.0
                                        added test_job example for NIC_IS_Ou_SimpleReports and COM_IS_Ou_SQLtoCSV;
                                        updated job.bat example for NIC_IS_Ou_SimpleReports and COM_IS_Ou_SQLtoCSV;
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/cad4e7b5a53f6bff82379ac33e6a3362ec1bdf06#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports.py
    210527.1 = Aliaksandr Tsurko =      Updated to core_v0.1.2
                                        Updated jobs structure (dir of job_name added);
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/a88059fcb08ebff27daff198478a03b31e5bd5c7#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210630.1 = Aliaksandr Tsurko =      Updated to core v0.1.3
                                        Added output files paths store and logging;
                                        Updated jobs for output files and required pytl core version storage;
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/20dd8df2a6becc224a469e6c34403bede20f9143#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210819.1 = Aleksander Parfenov =    ADCB-9182: updated docstring; set compatibility for output folder; set default value for DELIMITER
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/c77f7585bb5a3edf4661957d7eb3dd805574cd05#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210819.2 = Aleksander Parfenov =    ADCB-9182: refactored file paths
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/e6333cd9da55a610948f33064bb7a7b1ff526acf#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210825.1 = Aleksander Parfenov =    ALMAS-123: returned ORG column for all SimpleReports
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/41abc43ad7c438db03e93dad2027e06b43d9b7db#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210826.1 = Shalini Udayashankar =   ALMAS-123;Python file reverted
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/079a1485aad453f6661d4f92f3cc72f3f1a7d91d#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210906.1 = Aleksander Parfenov =    ALMAS-383: refactored Simplereport and added EXTENSION parameter, fixed layout of standard credit limit changes report
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/1ed2acc055fed8892799edcc456ec50da0436d79#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210907.1 = Aleksander Parfenov =    ADCB-9182: updated posted date format and excluded C filter, refactored Simple report job
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/7a79ddc6393c3c19e73bc178881389be977ae1ea#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/95941d9d160c5726bfba14cf3007e592c5378535#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210907.2 = Aleksander Parfenov =    ALMAS-383: reverted SimpleReport changes due to urgent edits under ADCB TLMC project
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/ee7870901322c5f8f5dcdde948543125c55028b4#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210907.3 = Aleksander Parfenov =    ALMAS-383: reverted SimpleReport changes, fix 1
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/4c813753a29c6cb2d4b8d1d2573aec62885f8b8f#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210907.4 = Aleksander Parfenov =    ALMAS-383: reverted SimpleReport changes, fix 2
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/894c162d767b8b7b0c980495c4b9d2e677420fcc#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210908.1 = Aleksander Parfenov =    ADCB-9182: added optional parameter REPORT_NAME_PREFIX for SimpleReport
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/b83ab330970dcc02b4dd08cbd4e047b2a2816be5#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/8d516542b5193b55b87bfb7f5d465060e19a0045#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    210908.1 = Aleksander Parfenov =    ADCB-9182: added optional parameter REPORT_NAME_PREFIX for SimpleReport
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/b83ab330970dcc02b4dd08cbd4e047b2a2816be5#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
                                        https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/8d516542b5193b55b87bfb7f5d465060e19a0045#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/NIC_IS_Ou_SimpleReports.py
    211014.6 = deniska =                ADCB-9810: Changes history restory
    211014.7 = deniska =                ADCB-9810: Rewritten for unification. Started.
    211017.1 = deniska =                ADCB-9810: Rewritten for unification. Continue.
    211101.1 = deniska =                ADCB-9810: Rewritten for unification. Finish.
                                        Renamed optional parameter:
                                            OUTPUT_FN2 -> OUTPUT_FN_RELATED
                                        Added optional parameters:
                                            INPUT_DATE_FORMAT, default value is "%d-%m-%Y" (DD-MM-YYYY)
                                            OUTPUT_DATE_FORMAT, default value is "%Y%m%d" (YYYYMMDD)
                                            OUTPUT_FN_SUFIX, default value is P_REPORT_DATE in OUTPUT_DATE_FORMAT
                                            CREATE_EMPTY_REPORT, default value is TRUE
                                            WRITE_HEADER, default value is TRUE
    211117.1 = deniska =                OPKSAIC-118/OPKSAIC-1693: added SKIPCOLUMNS parameter.
    211118.1 = deniska =                OPKSAIC-118/OPKSAIC-1693: added PACK, MASK_PATTERN, MASK_ALL and MASK_COLUMNS parameters; renamed SKIPCOLUMNS into SKIP_COLUMNS;
                                                                  removed csv module usage because of it doesn't support binary writing into output stream, so impossible to compress.
    211121.1 = deniska =                OPKSAIC-118/OPKSAIC-1693: added COLUMNS_QUANTITY, MINIMUM_ROWS;
                                                                  renamed SQLQUERY into the SQL_QUERY/SQL_QUERIES, converted into the list;
                                                                  huge refactoring of the code.
    211123.1 = deniska =                OPKSAIC-118/OPKSAIC-1693: Performance optimization:
                                                                  "CSV_GENERATOR=SIMPLE":   Could be used with PACK/MASK_ALL, the fastest.
                                                                                            Could be used ONLY if there are no delimiters inside column values.
                                                                  "CSV_GENERATOR=COMPLEX":  Could be used with PACK/MASK_ALL, the slowest.
                                                                                            Could be used if there is no information about possible column values.
                                                                  "CSV_GENERATOR=NATIVE":   Could NOT be used with PACK/MASK_ALL, the almost fast like SIMPLE.
                                                                                            Could be used if there is no information about possible column values.
    211123.2 = deniska =                OPKSAIC-118/OPKSAIC-1693: Fixed defect with indents
    211212.2 = deniska =                OPKSAIC-118/OPKSAIC-1693: Finding SQL files in different places if full path is not defined. Compatibility with incremental deploy.
    211216.1 = deniska =                BBY-2064: Merge with testing/BBY_EPP
    211219.1 = deniska =                OPKSAIC-1711: Fixed binding of parameters to sql query
    220216.1 = deniska =                ALMB-508: fixing module 'datetime' has no attribute 'strptime'
    220415.1 = deniska =                OPKSAIC-3426/ALMB-707:
                                                                  DB_SOURCE=DWH|STG|OWS
                                                                  SQL_QUERIES= with local parameters
                                                                  ROUTING_DIR={ORG} by default + supporting substitution of result values in output path
    220418.1 = deniska =                OPKSAIC-3426/ALMB-707:
                                                                  WRITE_EMPTY_ROWS=TRUE by default
                                                                  WRITE_EOF=FALSE by default

    220517.1 = deniska =                OPKSAIC-3174:             SAVE_REPORT_FILES=<file with list of reports>
    220621.2 = deniska =                EK-3122:                  added ability to include into SQL files placeholders with complex logic based on config variable (together with pytl_core v2.7)
                                                                  added ability to cut header till config['COLUMNS_QUANTITY'][0] in case of config['WRITE_HEADER'] == True
    220623.1 = deniska =                EK-3122:                  removing extension from default value OUTPUT_FN_PREFIX, based on SQL_QUERIES
                                                                  looking SQL files with extension *.SQ?
                                                                  fixed issue with not safe report names
                                                                  added ONLY_COLUMNS parameter
    220705.1 = deniska =                OPKSAIC-4587/ALMB-847:    Saving empty reports, mitigation of saving empty reports with dynamic file names.
    220929.1 = deniska =                NICORE-56:                Fixed the issue when if header is cutted, so the body is cutted as well
    221101.1 = deniska =                NICORE-82:                Fixed the issue when masking is enabled
    230323.1 = deniska =                ACBSA-274:                Added ability to define columns names in any case in param ONLY_COLUMNS
    230403.1 = deniska =                EIB-9633/NICORE-528:      Fixing issue: name 'sql_query_files_pattern_in_plugins' is not defined
'''
import datetime as __datetime

lambda_validate_str                 = lambda v, default="":         f"{default if not v else v}"
lambda_validate_path                = lambda v, default="":         default if not v else ("" if v == "." else v)
lambda_validate_and_map             = lambda v, variants, default:  variants[upper_v] if (upper_v:=(v or "").upper()) in variants else default
lambda_validate_bool                = lambda v, default=True:       lambda_validate_and_map(
                                                                        v,
                                                                        {"TRUE": True, "YES": True, "1": True, "": default, None: default},
                                                                        False
                                                                    )
lambda_validate_values              = lambda v, etalon_list:        upper_v if (upper_v:=(v or "").upper()) in etalon_list else etalon_list[-1]
lambda_create_list                  = lambda v, separator = ',', process_item = (lambda w:w): \
                                                                    [
                                                                        process_item(item.strip())
                                                                        for item in stripped_v.split(separator)
                                                                    ] \
                                                                    if ( stripped_v:=(v or "").strip() ) \
                                                                    else []
lambda_create_set                   = lambda v: set(lambda_create_list(v))
lambda_create_list_of_lists         = lambda v: lambda_create_list(v, ';', lambda w:lambda_create_list(w))
lambda_create_fixed_list            = lambda v, l, default=None:    [
                                                                        (
                                                                            (
                                                                                v_value
                                                                                if (v_value:=v_list[i])
                                                                                else default
                                                                            )
                                                                            if i < v_len
                                                                            else default
                                                                        )
                                                                        for i in range(l)
                                                                    ] \
                                                                    if (v_len:=len(v_list:=lambda_create_list(v))) > 0 \
                                                                    else [default for i in range(l)]

__params__ = {
######### Mandatory parameters #########
        "ENV":                      lambda: config['ENV'],                          # D:\PYTL\NIC\JOBNAME\W4UAT25.PARM
## *** ORG is legacy ***
        "ORG":                      lambda: config.get('ORG')
                                            or config['ORGLIST'],                   # "982" || "982,320"
        "ORGLIST":                  lambda: config.get('ORGLIST')
                                            or __params__['ORG'](),                 # "982" || "982,320"
        "DB_SOURCE":                lambda: lambda_validate_values(config.get('DB_SOURCE'), ("DWH", "STG", "OWS")),
## *** OUTPUT_FN, SQLQUERY, SQL_QUERY are legacy ***
        "SQL_QUERIES":              lambda: lambda_create_list(
                                                               config.get('OUTPUT_FN')
                                                            or config.get('SQLQUERY')
                                                            or config.get('SQL_QUERY')
                                                            or config    ['SQL_QUERIES']
                                            , ';'),
######### Optional parameters #########
        "INPUT_DATE_FORMAT":        lambda: config.get('INPUT_DATE_FORMAT')
                                            or "%d-%m-%Y",
        "OUTPUT_DATE_FORMAT":       lambda: config.get('OUTPUT_DATE_FORMAT')
                                            or "%Y%m%d",
        "P_REPORT_DATE":            lambda: config.get('P_REPORT_DATE')
                                            or __datetime.datetime.now().strftime(__params__['INPUT_DATE_FORMAT']()),
## *** REPORT_NAME_PREFIX is legacy ***
        "OUTPUT_FN_PREFIX":         lambda: lambda_validate_path( config.get('REPORT_NAME_PREFIX') or config.get('OUTPUT_FN_PREFIX'),
                                                                  (
                                                                      os.path.splitext(os.path.basename(__params__['SQL_QUERIES']()[0].split(':')[-1]))[0]
                                                                      if len(__params__['SQL_QUERIES']()) > 0
                                                                      else ""
                                                                  )
                                            ),
        "OUTPUT_FN_SEPARATOR":      lambda: lambda_validate_path(config.get('OUTPUT_FN_SEPARATOR'), "_"),
        "OUTPUT_FN_SUFIX":          lambda: lambda_validate_path(config.get('OUTPUT_FN_SUFIX'), __datetime.datetime.strptime(
                                                                                                    __params__['P_REPORT_DATE'](),
                                                                                                    __params__['INPUT_DATE_FORMAT']()
                                                                                                ).strftime(__params__['OUTPUT_DATE_FORMAT']())
                                            ),
## *** EXTENSION is legacy ***
        "OUTPUT_FN_EXTENSION":      lambda: __OUTPUT_FN_EXTENSION
                                            if (__OUTPUT_FN_EXTENSION :=
                                                    lambda_validate_path(config.get('EXTENSION') or config.get('OUTPUT_FN_EXTENSION'), ".txt")
                                               ).startswith('.')
                                            else "." + __OUTPUT_FN_EXTENSION,
        "OUTPUT_FN_RELATED":        lambda: config.get('OUTPUT_FN_RELATED')
                                            or (
                                                  __params__['OUTPUT_FN_PREFIX']()
                                                + __params__['OUTPUT_FN_SEPARATOR']()
                                                + __params__['OUTPUT_FN_SUFIX']()
                                                + __params__['OUTPUT_FN_EXTENSION']()
                                            ),
        "ROUTING_DIR":              lambda: lambda_validate_path(config.get('ROUTING_DIR'), "{ORG}"),
        "DELIMITER":                lambda: config.get('DELIMITER') or "|",
        "CREATE_EMPTY_REPORT":      lambda: lambda_validate_bool(config.get('CREATE_EMPTY_REPORT'), True),
        "WRITE_HEADER":             lambda: lambda_validate_bool(config.get('WRITE_HEADER'), True),
        "WRITE_EMPTY_ROWS":         lambda: lambda_validate_bool(config.get('WRITE_EMPTY_ROWS'), True),
        "WRITE_EOF":                lambda: lambda_validate_bool(config.get('WRITE_EOF'), False),
        "EOL":                      lambda: lambda_validate_str(config.get('EOL',"").encode().decode('unicode_escape'), "\r\n"),
## *** SKIPCOLUMNS is legacy ***
        "SKIP_COLUMNS":             lambda: {"ORG"} | lambda_create_set(config.get('SKIPCOLUMNS') or config.get('SKIP_COLUMNS')),
        "ONLY_COLUMNS":             lambda: lambda_create_list(config.get('ONLY_COLUMNS'), ';'),
        "PACK":                     lambda: lambda_validate_and_map( config.get('PACK'),
                                                                      {
                                                                          "BZIP2":    zipfile.ZIP_BZIP2,
                                                                          "LZMA":     zipfile.ZIP_LZMA
                                                                      },
                                                                      None
                                            ),
        "MASK_ALL":                 lambda: lambda_validate_bool(config.get('MASK_ALL'), False),
        "MASK_PATTERN":             lambda: [re.compile("([34569][0-9]{5})([0-9]{6})([0-9]{4})"), r"\1******\3"]
                                            if not (__MASK_PATTERN := config.get('MASK_PATTERN', ""))
                                            else [re.compile((__MASK_PATTERNS := __MASK_PATTERN.split('=',1))[0]), __MASK_PATTERNS[1]],
        "MASK_COLUMNS":             lambda: {}
                                            if not (__MASK_COLUMNS := config.get('MASK_COLUMNS', ""))
                                            else {
                                                    (key_value_pair:=__STRIPPED_MASK_COLUMN.split('=', 1))[0].strip().upper(): [
                                                            re.compile((regexp:=key_value_pair[1].split('=', 1))[0]),
                                                            regexp[1]
                                                    ]
                                                    if len(key_value_pair) == 2
                                                    else __params__['MASK_PATTERN']()
                                                    for __MASK_COLUMN in __MASK_COLUMNS.split(';') if (__STRIPPED_MASK_COLUMN:=__MASK_COLUMN.strip())
                                            },
        "COLUMNS_QUANTITY":         lambda: [[888, 888, 888] for sql_query_file in __params__['SQL_QUERIES']()]
                                            if not (__COLUMNS_QUANTITIES := config.get('COLUMNS_QUANTITY', ""))
                                            else [
                                                __SPLITTED_COLUMNS_QUANTITIES:=n0list([
                                                        [
                                                            str2int((__SPLITTED_COLUMNS_QUANTITY:=n0list(__STRIPPED_COLUMNS_QUANTITY.split(','))).get(0, "901"), 909),
                                                            str2int(__SPLITTED_COLUMNS_QUANTITY.get(1, __SPLITTED_COLUMNS_QUANTITY.get(0, "911") or "912"), 919),
                                                            str2int(__SPLITTED_COLUMNS_QUANTITY.get(2, __SPLITTED_COLUMNS_QUANTITY.get(1, __SPLITTED_COLUMNS_QUANTITY.get(0, "921")) or "922"), 929)
                                                        ] for __COLUMNS_QUANTITY in n0list(__COLUMNS_QUANTITIES.split(';')) if (__STRIPPED_COLUMNS_QUANTITY:=__COLUMNS_QUANTITY.strip())
                                                ]).get(sql_query_file_i, [889, 889, 889])
                                                for sql_query_file_i, sql_query_file in enumerate(__params__['SQL_QUERIES']())
                                            ],
        "MINIMUM_ROWS":             lambda: str2int(config.get('MINIMUM_ROWS'), 1),
        "CSV_GENERATOR":            lambda: lambda_validate_values(config.get('CSV_GENERATOR'), ('NATIVE', 'COMPLEX', 'SIMPLE')),
        "SAVE_REPORT_FILES":        lambda: config.get('SAVE_REPORT_FILES'),
# Parameters from file config['ENV']
        "DB_W4C_SRC_WLTURL":        lambda: config.get('DB_W4C_SRC_WLTURL'),
        "DB_DM_SRC_WLTURL":         lambda: config.get('DB_DM_SRC_WLTURL'),
        "DB_STG_SRC_WLTURL":        lambda: config.get('DB_STG_SRC_WLTURL'),
# Precalculated values
        "JOB_NAME":                 lambda: config['JOB_NAME'],
        "SQL_DIR":                  lambda: config['SQL_DIR'],
## *** TGT_FILEPATH is legacy ***
        "DST_DIR":                  lambda: config.get('TGT_FILEPATH', "") or config['DST_DIR'],
}
try:
    # Could be imported ONLY if it's run as module
    from . import __job_name__
    from importlib_metadata import version as importlib_metadata_version
    __version__ = importlib_metadata_version(__job_name__)
except:
    # Could be imported ONLY if it's run as normal py
    from __init__ import __job_name__
    from __init__ import __version__

import pytl_core
import pytl_core.pytl_globals as pytl_globals
import logging
from pathlib import Path
import csv
import glob
import zipfile
import re
from n0struct import *

def str2int(str_: str, default_value: int = -1) -> int:
    if isinstance(str_, (int, float, complex)):
        return str_
    if not str_:
        return default_value
    if not isinstance(str_, str):
        raise Exception(f"Incorrect type '{type(str_)}' of incoming argument")

    str_ = str_.strip()
    if all(chr_ in '-+01234567890' for chr_ in str_):
        return int(str_)
    # raise Exception(f"Incorrect charaters in incoming argument: '{str_}'")
    return default_value

def generate_csv_row(row_values: list, delimiter: str) -> str:
    for i,column_value in enumerate(row_values):
        if not isinstance(column_value, str):
            row_values[i] = column_value = str(column_value)
        if not column_value.startswith('"') or not column_value.endwith('"'):
            # required to normalize
            if any(itm in column_value for itm in (delimiter, '"')):
                row_values[i] = '"' + column_value.replace('"', '""') + '"'
    return (delimiter.join(row_values) + __params__['EOL']())


def mask_buffer(buffer: str) -> list:
    buffer = __params__['MASK_PATTERN']()[0].sub(__params__['MASK_PATTERN']()[1], buffer)
    return buffer

def mask_columns(row_values: list, column_names: list) -> list:
    # NICORE-82: Fixed the issue when masking is enabled
    # if column_names is None, it means than it is header and must not be masked by column name
    if column_names and any(column_name.upper() in __params__['MASK_COLUMNS']() for column_name in column_names):
        for column_i,column_name in enumerate(column_names):
            if (column_name:=column_name.upper()) in __params__['MASK_COLUMNS']():
                column_mask = __params__['MASK_COLUMNS']()[column_name]
                row_values[column_i] = column_mask[0].sub(column_mask[1], row_values[column_i])
    return row_values

# ##############################################################################
def maskcols_write_native_csv(filehandler, row_values: list, column_names: list, delimiter: str):
    if __params__['WRITE_EMPTY_ROWS']() or any(row_values):
        filehandler.writerow(mask_columns(row_values, column_names))
def write_native_csv(filehandler, row_values: list, column_names: list, delimiter: str):
    if __params__['WRITE_EMPTY_ROWS']() or any(row_values):
        filehandler.writerow(row_values)
# ##########################################################################
def maskcols_maskrow_write_complex_csv(filehandler, row_values: list, column_names: list, delimiter: str):
    if __params__['WRITE_EMPTY_ROWS']() or any(row_values):
        filehandler.write(mask_buffer(generate_csv_row(mask_columns(row_values, column_names), delimiter)).encode('utf-8'))
def maskcols_maskrow_write_simple_csv(filehandler, row_values: list, column_names: list, delimiter: str):
    if __params__['WRITE_EMPTY_ROWS']() or any(row_values):
        filehandler.write(mask_buffer(delimiter.join(mask_columns(row_values, column_names)) + __params__['EOL']()).encode('utf-8'))

def maskcols_write_complex_csv(filehandler, row_values: list, column_names: list, delimiter: str):
    if __params__['WRITE_EMPTY_ROWS']() or any(row_values):
        filehandler.write(generate_csv_row(mask_columns(row_values, column_names), delimiter).encode('utf-8'))
def maskcols_write_simple_csv(filehandler, row_values: list, column_names: list, delimiter: str):
    if __params__['WRITE_EMPTY_ROWS']() or any(row_values):
        filehandler.write(delimiter.join(mask_columns(row_values, column_names) + __params__['EOL']()).encode('utf-8'))

def maskrow_write_complex_csv(filehandler, row_values: list, column_names: list, delimiter: str):
    if __params__['WRITE_EMPTY_ROWS']() or any(row_values):
        filehandler.write(mask_buffer(generate_csv_row(mask_columns(row_values, column_names), delimiter)).encode('utf-8'))
def maskrow_write_simple_csv(filehandler, row_values: list, column_names: list, delimiter: str):
    if __params__['WRITE_EMPTY_ROWS']() or any(row_values):
        filehandler.write(mask_buffer(delimiter.join(mask_columns(row_values, column_names))  + __params__['EOL']()).encode('utf-8'))

def write_comlex_csv(filehandler, row_values: list, column_names: list, delimiter: str):
    if __params__['WRITE_EMPTY_ROWS']() or any(row_values):
        filehandler.write(generate_csv_row(row_values, delimiter).encode('utf-8'))
def write_simple_csv(filehandler, row_values: list, column_names: list, delimiter: str):
    if __params__['WRITE_EMPTY_ROWS']() or any(row_values):
        filehandler.write((delimiter.join(row_values) + __params__['EOL']()).encode('utf-8'))
# ##############################################################################
mask_and_write_row = write_simple_csv
# def main(_config):
def main(_config = None):
    # global config is used in current module, outside of current procedure
    # pytl_globals.config is used in other modules
    global config
    if _config:
        config = _config
    elif pytl_globals.config:
        config = pytl_globals.config
    else:
        raise Exception('variable config is not defined')

    logging.debug(f'__params__ ({len(__params__)} items):')
    for key, value in  __params__.items():
        logging.info(f"{key}={value()}")
    # ##########################################################################
    # Validate conflicting parameters and setup mask_and_write_row() entrypoints
    # ##########################################################################
    if __params__['CSV_GENERATOR']() == 'NATIVE':
        # Native CSV module
        if __params__['PACK']():
            raise Exception("Impossible to use native csv module and pack destination report.")
        if __params__['MASK_ALL']():
            raise Exception("Impossible to use native csv module and mask rows (only masking per column is allowed).")
        if __params__['MASK_COLUMNS']():
            mask_and_write_row = maskcols_write_native_csv
        else:
            mask_and_write_row = write_native_csv
    elif __params__['CSV_GENERATOR']() == 'COMPLEX':
        # Comlex CSV generator
        if __params__['MASK_COLUMNS']():
            if __params__['MASK_ALL']() and __params__['MASK_PATTERN']():
                mask_and_write_row = maskcols_maskrow_write_comlex_csv
            else:
                mask_and_write_row = maskcols_write_comlex_csv
        else:
            if __params__['MASK_ALL']() and __params__['MASK_PATTERN']():
                mask_and_write_row = maskrow_write_comlex_csv
            else:
                mask_and_write_row = write_comlex_csv
    else:
        # All other: Simle CSV generator
        if __params__['MASK_COLUMNS']():
            if __params__['MASK_ALL']() and __params__['MASK_PATTERN']():
                mask_and_write_row = maskcols_maskrow_write_simple_csv
            else:
                mask_and_write_row = maskcols_write_simple_csv
        else:
            if __params__['MASK_ALL']() and __params__['MASK_PATTERN']():
                mask_and_write_row = maskrow_write_simple_csv
            else:
                mask_and_write_row = write_simple_csv
    # ##########################################################################
    # set a default value for DELIMITER
    delimiter = __params__['DELIMITER']()
    # ##########################################################################
    # Find all *.sql files related to PyTL_IS_SimpleReports and generate dict for quick search
    # ##########################################################################
    # Splitted into 2 parts: PyTL_IS_SimpleReports/sql/*.sql and PyTL_IS_SimpleReports*/**/*.sql
    #     PyTL_IS_SimpleReports/sql/*.sql have more priority than PyTL_IS_SimpleReports*/**/*.sql
    #     Fresher *.sql files from PyTL_IS_SimpleReports*/**/*.sql will have more priority that
    #     older files with the same name in PyTL_IS_SimpleReports/sql/*.sql
    found_sql_query_files_in_all_directories = sorted(
        list(glob.iglob(
                os.path.abspath(f"{os.path.dirname(os.path.abspath(__file__))}/../{__job_name__}*/**/*.sq?"),
                recursive=True,
        )), \
        key=os.path.getmtime, reverse=True,
    )
    found_sql_query_files = {}  # for each found SQL-file just only 1 record will be generated,
                                # where key is lower case file name only WITHOUT extention
    for sql_query_file_fullpath in found_sql_query_files_in_all_directories:
        # key is lower case file name only WITHOUT extention
        sql_query_key = os.path.splitext(os.path.basename(sql_query_file_fullpath.lower()))[0]
        if not sql_query_key in found_sql_query_files:
            # First found (the mordern one) will be used, other will be ignored
            found_sql_query_files.update({sql_query_key: sql_query_file_fullpath})
    # ##########################################################################
    # Put into sql_query_entity["SQL_QUERY"] the full paths of item from __params__['SQL_QUERIES'] based on found_sql_query_files or absolute path
    # ##########################################################################
    local_params_key_value = {
        'DB_SOURCE':        lambda v: lambda_validate_values(v, ('DWH', 'STG', 'OWS')),
        'WRITE_HEADER':     lambda_validate_bool,
        'SKIP_COLUMNS':     lambda_create_set,
        'ONLY_COLUMNS':     lambda_create_set,
        'COLUMNS_QUANTITY': lambda v: lambda_create_fixed_list(v, 3, 877),
        'DELIMITER':        lambda v: v or '|',
    }

    sql_queries = []
    for i_sql_query, sql_query_item in enumerate(__params__['SQL_QUERIES']()):
        sql_query_items = sql_query_item.split(':')
        sql_query_item = {}
        if not len(sql_query_items):
            raise Exception(f"Not correct parameter {__params__['SQL_QUERIES']()}")

        if os.path.dirname(sql_query_filepath := sql_query_items[-1]):
            # SQL_QUERY contains the path
            if not os.path.exists(sql_query_filepath):
                raise Exception(f"'{sql_query_filepath}' is not found")
            sql_query_item["SQL_QUERY"] = sql_query_filepath
        else:
            # SQL_QUERY contains just only file name+ext or file name only
            if not (sql_query_key := os.path.splitext(os.path.basename(sql_query_filepath.lower()))[0]) in found_sql_query_files:
                raise Exception(f"'{sql_query_key}' is not found in '{found_sql_query_files}'")
            sql_query_item["SQL_QUERY"] = found_sql_query_files[sql_query_key]

        # Save local params assosiated to SQL_QUERY to sql_query_item
        for param in sql_query_items[:-1]:
            key_value = param.upper().split('=', 1)
            param_key = key_value[0]
            if len(key_value) < 2:
                sql_query_item[param_key] = None
            else:
                sql_query_item[param_key] = local_params_key_value[param_key](key_value[1])

        # Inherit values from global __params__ for params, which was not defined localy
        for global_param_key in local_params_key_value:
            if not global_param_key in sql_query_item:
                if global_param_key == 'COLUMNS_QUANTITY':
                    sql_query_item[global_param_key] = __params__['COLUMNS_QUANTITY']()[i_sql_query]
                else:
                    sql_query_item[global_param_key] = __params__[global_param_key]()
        sql_queries.append(sql_query_item)

    # ##########################################################################
    # Init variables once per run
    # ##########################################################################
    if os.path.dirname(__params__['OUTPUT_FN_RELATED']()):
        filename_template = __params__['OUTPUT_FN_RELATED']()
    else:
        filename_template = os.path.join(__params__['DST_DIR'](), __params__['ROUTING_DIR'](), __params__['OUTPUT_FN_RELATED']())
    logging.info(f"{filename_template=}")
    filename_changers = re.findall(r"{(.*?)}", filename_template)

    if len(filename_changers) == 0:
        org_list = ["000"] # Fake ORG will not impact to anything, because of no filename_changers
    elif len(filename_changers) >= 1 and "ORG" in filename_changers:
        org_list = lambda_create_list(__params__['ORGLIST']())
    else:
        org_list = []

    db_connections = {}
    file_names = {}
    zipfile_handlers = {}
    file_handlers = {} # Is used only if __params__['CSV_GENERATOR']() == 'NATIVE'
    stream_handlers = {}
    file_rows_total_quantity = {}

    opened_streams = {}
    def open_stream(file_path: str, sql_query_item, header_row) -> tuple:
        # global opened_streams
        global __params__
        if file_path in opened_streams:
            opened_stream = opened_streams[file_path]['outstream']
            if sql_query_item['WRITE_HEADER'] and opened_streams[file_path]['queryrows'] == 0:
                mask_and_write_row(opened_stream, header_row, None, sql_query_item['DELIMITER'])
            return opened_stream

        logging.info(f"****** Creating '{file_path}'...")
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        if __params__['PACK']():
            output_file_handler = zipfile.ZipFile(file_path +  ".zip", mode="w",  compression=__params__['PACK'](), allowZip64=True, compresslevel=9)
            output_stream_handler  = output_file_handler.open(os.path.basename(file_path), "w")
        else:
            if __params__['CSV_GENERATOR']() == 'NATIVE':
                # Native CSV module
                output_file_handler   = open(file_path, mode='wt', newline=__params__['EOL'](), encoding='utf-8')
                output_stream_handler = csv.writer(output_file_handler, delimiter=sql_query_item['DELIMITER']() )
            else:
                output_file_handler = None
                output_stream_handler = open(file_path, mode='wb') # No encoding='utf-8', newline=__params__['EOL']() supported for BINARY mode

        if sql_query_item['WRITE_HEADER']:
            mask_and_write_row(output_stream_handler, header_row, None, sql_query_item['DELIMITER'])
        opened_streams.update({file_path: {
                                            'outstream':    output_stream_handler,  # Output stream. For CSV_GENERATOR=COMPLEX/SIMPLE file handler
                                            'outfile':      output_file_handler,    # Optional file handler for PACK/CSV_GENERATOR=NATIVE
                                            'lastrow':      None,                   # Buffer for last row
                                            'queryrows':    0,                      # Written rows count (without header) from current query
                                            'totalrows':    0,                      # Written rows total count (without header) from all queries
                                          }
        })
        return output_stream_handler

    # ##########################################################################
    # Loop per SQL files
    # ##########################################################################
    for sql_query_item in sql_queries:
        # ######################################################################
        # Init variables per each SQL file
        data_is_fetched = False
        for file_path in opened_streams:
            opened_streams[file_path]['lastrow']   = 0 # Buffer for last row
            opened_streams[file_path]['queryrows'] = 0 # Written rows count (without header) from current query

        sql_1 = pytl_core.utils.load_statement_from_file(sql_query_item["SQL_QUERY"], config)  # [*] 220621.2 = deniska = EK-3122: added ability to include into SQL files placeholders with complex logic based on config variable (together with pytl_core v2.7)
        sql_1_parm_dict = {}
        for key in (__params__.keys() | config.keys()):
            if re.search(":"+key+"\W", sql_1):
                sql_1_parm_dict[key] = __params__[key]() if key in __params__ else config[key]

        # ######################################################################
        # Fetch results per each SQL file
        if not sql_query_item['DB_SOURCE'] in db_connections:
            logging.info(f"****** Start connecting to '{sql_query_item['DB_SOURCE']}'...")
            db_connections[sql_query_item['DB_SOURCE']] = pytl_core.Connection(config[
                                                                                        {
                                                                                            'DWH': 'DB_DM_SRC_WLTURL',
                                                                                            'STG': 'DB_STG_SRC_WLTURL',
                                                                                            'OWS': 'DB_W4C_SRC_WLTURL'
                                                                                        }[sql_query_item['DB_SOURCE']]
                                                                                     ]
            )
        current_connection = db_connections[sql_query_item['DB_SOURCE']]
        logging.info(f"****** Start execution of SQL '{sql_query_item}'...")
        for iteration, batch in enumerate(current_connection.execute_select_batch(statement=sql_1, bind_vars=sql_1_parm_dict, pd_mode=False)):
            data_is_fetched = True
            # ##################################################################
            # Save header row based on SQL cursor metadata during 1st iteration
            if iteration == 0:
                if sql_query_item['ONLY_COLUMNS']:
                    header = sql_query_item['ONLY_COLUMNS']
                    n0debug("header")
                else:
                    header = [
                        item[0] for item in current_connection.current_cursor_metadata
                        if item[0] not in sql_query_item['SKIP_COLUMNS']
                    ]
                    # [:sql_query_item['COLUMNS_QUANTITY'][0]]  # [*] 220621.2 = deniska = EK-3122: added ability to cut header till config['COLUMNS_QUANTITY'][0] in case of config['WRITE_HEADER'] == True
                                                                # [-] 220929.1 = deniska = NICORE-56: Fixed the issue when if header is cutted, so the body is cutted as well
            # ##################################################################
            # Save fetched data into different files stream_handlers[org], depends of ORGLIST
            for row in batch:
                # Impossible to substitute ':' because of it is used in disk definition C:\
                opened_stream = open_stream(
                                    file_path := filename_template.format(**row).translate({ord(c):ord('_') for c in "\"'`^&|<>*? "}),
                                    sql_query_item,
                                    header[:sql_query_item['COLUMNS_QUANTITY'][0]] # [+] 220929.1 = deniska = NICORE-56: Fixed the issue when if header is cutted, so the body is cutted as well
                )

                if opened_streams[file_path]['queryrows']:
                    if opened_streams[file_path]['queryrows'] == 1:  # Written rows count (without header) from current query
                        max_columns = int(sql_query_item['COLUMNS_QUANTITY'][0])    # {max header (1st row) columns in query#n}
                    else:
                        max_columns = int(sql_query_item['COLUMNS_QUANTITY'][1])    # {max body columns in query#n}
                    mask_and_write_row(opened_stream, opened_streams[file_path]['lastrow'][0:max_columns], header[0:max_columns], sql_query_item['DELIMITER'])

                # Save the line to write at the next round of loop
                opened_streams[file_path]['lastrow']    = [column_value if (column_value:=row.get(key)) else '' for key in header]
                opened_streams[file_path]['queryrows'] += 1 # Written rows count (without header) from current query
                opened_streams[file_path]['totalrows'] += 1 # Written rows total count (without header) from all queries

        if data_is_fetched:
            # ##########################################################################
            # Save the last row (trailer)
            # ##########################################################################
            for file_path in opened_streams:
                if opened_streams[file_path]['queryrows']: # Written rows count (without header) from current query
                    # n0debug_calc(opened_streams[file_path]['queryrows'], f"opened_streams[{file_path}]['queryrows']")
                    max_columns = int(sql_query_item['COLUMNS_QUANTITY'][2]) # {max footer (last row) columns in query#n}
                    mask_and_write_row(opened_streams[file_path]['outstream'], opened_streams[file_path]['lastrow'][0:max_columns], header[0:max_columns], sql_query_item['DELIMITER'])
        elif __params__['CREATE_EMPTY_REPORT']():
            if sql_query_item['WRITE_HEADER']:
                # ##########################################################################
                # Save only header in case of no data fetched  if CREATE_EMPTY_REPORT and WRITE_HEADER are True
                # ##########################################################################
                if sql_query_item['ONLY_COLUMNS']:
                    header = sql_query_item['ONLY_COLUMNS']
                else:
                    # Create files with HEADER in case of no data fetched
                    sql_2 = "select t2.DUMMY_VALUE, t1.* from (" + sql_1 + ") t1 full outer join (select null as DUMMY_VALUE from dual) t2 on t2.DUMMY_VALUE = t1.ORG"
                    current_connection.execute_select_batch(statement=sql_2, bind_vars=sql_1_parm_dict, pd_mode=False)
                    # Remove DUMMY_VALUE and columns mentioned in SKIP_COLUMNS (ORG and other)
                    header = [
                        item[0] for item in current_connection.current_cursor_metadata
                        if item[0] not in (sql_query_item['SKIP_COLUMNS']|{"DUMMY_VALUE"})
                    ]
                    # [:sql_query_item['COLUMNS_QUANTITY'][0]]           # [*] 220621.2 = deniska = EK-3122: added ability to cut header till config['COLUMNS_QUANTITY'][0] in case of config['WRITE_HEADER'] == True
                                                                         # [-] 220929.1 = deniska = NICORE-56: Fixed the issue when if header is cutted, so the body is cutted as well
                header = header[:sql_query_item['COLUMNS_QUANTITY'][0]]  # [+] 220929.1 = deniska = NICORE-56: Fixed the issue when if header is cutted, so the body is cutted as well
            else:
                header = []

            row = {}
            flag_possible_to_generate_empty_reports = True
            for filename_changer in filename_changers:
                if filename_changer in __params__:
                    row.update({filename_changer: __params__[filename_changer]()})
                elif filename_changer in config:
                    row.update({filename_changer: config[filename_changer]})
                else:
                    logging.info(f"Impossible to generate empty files '{filename_template}', because of '{filename_changer}' must be returned from SQL selection.")
                    flag_possible_to_generate_empty_reports = False
            if flag_possible_to_generate_empty_reports:
                for org in org_list:
                    row.update({'ORG': org})
                    file_path = filename_template.format(**row)
                    if not file_path in opened_streams:
                        opened_stream = open_stream(file_path, sql_query_item, header)

    # ##########################################################################
    # Close destination files once per run
    # ##########################################################################
    saved_report_files = None
    if __params__['SAVE_REPORT_FILES']():
        saved_report_files = open(__params__['SAVE_REPORT_FILES'](), 'wt', newline=__params__['EOL'](), encoding='utf-8')

    for file_path in opened_streams:
        logging.info(f"****** Closing destination file '{file_path}'...")
        logging.info(f"***** {opened_streams[file_path]['totalrows']} (possible empty) rows were written {'(empty rows were skipped)' if not __params__['WRITE_EMPTY_ROWS']() else ''}.")
        if __params__['WRITE_EOF']():
            logging.info(f"***** EOF mark is written.")
            opened_streams[file_path]['outfile' if __params__['CSV_GENERATOR']() == 'NATIVE' else 'outstream'].write("\x1A".encode('UTF-8'))
        opened_streams[file_path]['outstream'].close()
        if opened_streams[file_path]['outfile']:
            opened_streams[file_path]['outfile'].close()
        # Delete empty files if CREATE_EMPTY_REPORT is False
        if not __params__['CREATE_EMPTY_REPORT']() and opened_streams[file_path]['queryrows'] < __params__['MINIMUM_ROWS']():
            Path(file_path).unlink(missing_ok=True)
            logging.info(f"****** Deleted '{file_path}' because of it contains {opened_streams[file_path]['queryrows']} rows with minimum {__params__['MINIMUM_ROWS']()}")
        else:
            if saved_report_files:
                saved_report_files.write(file_path + '\n')
    if saved_report_files:
        saved_report_files.close()
    for db_connection_name in db_connections:
        db_connections[db_connection_name].close()

