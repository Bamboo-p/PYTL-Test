begin
 
  execute immediate '
    merge into tlnd_jobs trgt
    using (
      select ''NIC_IS_In_TransactionFile'' as job_id, ''Transaction File processing - Corporate Card. INICE-131'' as job_desc from dual
	  union
	  select ''NIC_IS_Ou_TransactionFileReport'' as job_id, ''Transaction File processing Response Report - Corporate Card. INICE-114'' as job_desc from dual
    ) src
    on (trgt.job_id = src.job_id)
    when matched 
      then update set trgt.job_desc = src.job_desc
    when not matched
      then insert values (src.job_id, src.job_desc)
  ';
  
  merge into TLND_JOB_RELATIONS trgt
  using (
		  select 'NIC_IS_In_TransactionFile' as in_job_id, 'NIC_IS_Ou_TransactionFileReport' as out_job_id from dual
        )src
  on (trgt.in_job_id = src.in_job_id and trgt.out_job_id = src.out_job_id)
  when not matched
    then insert values (src.in_job_id, src.out_job_id)
  ;
  commit;
  
end;
