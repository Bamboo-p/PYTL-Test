delete from tlnd_jobs_current_values 
where record_status = 'OPEN'
and in_job_id = :job_name