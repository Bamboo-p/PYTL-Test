select * 
from tlnd_jobs_current_values 
where record_status =:status 
order by current_sequence_value desc