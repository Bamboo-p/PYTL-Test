select :ORG as ORG, 'PyTL_IS_SimpleReports demo = column1' as COL1, NULL as COL2, 'PyTL_IS_SimpleReports demo = column3' as COL3, NULL as COL4, 'PyTL_IS_SimpleReports demo = column5' as COL5 from dual


