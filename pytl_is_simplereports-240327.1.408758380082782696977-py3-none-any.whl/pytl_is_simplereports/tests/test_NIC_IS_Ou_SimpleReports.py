"""
Planned tests for the job:  NIC_IS_Ou_SimpleReports.py


Seems that tests should check specified requirements fulfillment for a job.
As we still don't have clear list of reqs from BA, we'll test it out of general considerations:

two groups, each has normal- and wrong-input checks:
- tests for data (good, bad, cause an exception, have illegal characters, etc.)
- tests for input args (positive, negative, others)

each test has regular set of checks for:
1) job runnability,
2) output files generation (log and destination files),
3) matching data withing log or dst files with reference.

All DB operations are mocked at the db-wrapper level, and should not be tested here
(the wrapper will be tested as a part of the pytl core).

The list of tests with checks:
- test with correct input data and args (single ORG): no exceptions, log without errors, one output file match
- test with correct input data and args (multi ORG): no exceptions, log without errors, two output file match
- test with wrong input args (missed ORG): exception, log with errors, no output files
- test with wrong input args (wrong DB_SOURCE): exception, log with errors, no output files
- test with wrong input data (multi ORG mismatch): no exceptions, log without errors, one output file missed, one match
- test with wrong input data (headers mismatch): exception, log with errors, no output files
- test with wrong input data (illegal characters): no exceptions, log without errors, one output file match


A job test files structure (required):
./ -- current working directory (.../pytl_jobs(repo)/pytl_jobs/jobs_group/job_name/.)
./job.py -- a job under the test
./tests/test_job.py -- this file, a handler (main) for all the job tests.
./tests/fixtures/job__test_data.json -- all data for the tests
./TEST_IO/ -- the dirs generated for input, output, and other files of the job
./../../../tests/fixtures/ -- common files for all tests
./../../../pytl_core -- common files for all jobs
./../../../pytl_env -- working environment scripts, including .bat files for the tests launching

The tests configuration consists of:
1) config_defaults variables - to inject additional settings into job config (not via command-line args).
2) test_data variable and job__test_data.json file - to provide command-line args, input and reference data for tests.
3) any fixture written here and passed to tests

this caption is for an example of a job testing. all comments may be removed on tests scaling.
"""


import sys
from pathlib import Path
import pytest


# to use pytl_core and tests from src,
# add repo root to search paths at first place before importing
sys.path.insert(0, str(Path(__file__).parents[3]))
from tests.fixtures.job_src_fixtures import job_tester


# An alternative to a job "command_line_args", will be set before the args parsing
# It injects some settings auto-taken from test file name (mandatory: set JOB_FILE instead of auto-detection in config)
# Config defaults are the same for all tests for the job, command-line args should be specified for each dataset
config_defaults= {
    "JOB_FILE": str(Path(__file__)).replace(str(Path('tests') /'test_'),''),
    "ENV": "--skip",
    "DB_DM_SRC_WLTURL": "any_value_required_due_to_ENV_skipped_and_DB_mocked",
    "WORKDIR_PATH": "{{JOB_DIR}.parent}/TEST_IO/{JOB_NAME}_py/*work_dirs*",
}


# Path to datasets for all tests of the job
# accepts any: single value or iterable (list, tuple, set) of Path_obj or string types
# multiple files from iterable will be merged
path_to_test_data = Path(__file__).parent /'fixtures'/'NIC_IS_Ou_SimpleReports__test_data.json'

"""
# Example of additional mocking of some function return
@pytest.fixture
def mocking_example(mocker):
    mocker.patch('os.getcwd', return_value='neverdir')


# Example of more additional setups
@pytest.fixture
def arrange_example(mocking_example):
    import os
    return os.getcwd() == 'neverdir'


# Example of additional test checks
@pytest.fixture
def assertion_example(arrange_example, job_tester):

    # the first check
    assert arrange_example, "if arrange_example is not True, this error message will be shown"

    # the second check
    config_size = len(job_tester.config)

    # this will log to same job execution log and be displayed in terminal if any assertions Fails
    import logging
    logging.debug(f"len of the config dict is {config_size}")

    assert config_size == 38, f"config has a wrong size of {config_size} instead of 38"


# Example of testing the normal job output (two test cases, with additional (dummy) checks from above)
@pytest.mark.parametrize('cfg_defaults', [config_defaults])#, indirect=True)
@pytest.mark.parametrize('test_data',[path_to_test_data])
@pytest.mark.parametrize('test_case_name', [ # dataset names from test data
    'pos__correct_args_and_data__single_ORG',
    'pos__correct_args_and_data__multi_ORG',
])
def test_job__NIC_IS_Ou_SimpleReport__positive(job_tester, assertion_example):
    job_tester.check_all()


# Example of testing the negative job output (wrong args)
@pytest.mark.parametrize('cfg_defaults', [config_defaults])
@pytest.mark.parametrize('test_data',[path_to_test_data])
@pytest.mark.parametrize('test_case_name', [ # dataset names from test data
    'neg__wrong_args__missed_ORG',
    'neg__wrong_args__wrong_DB_SOURCE',
    'neg__wrong_data__headers_mismatch',
])
def test_job__NIC_IS_Ou_SimpleReport__negative_1(job_tester):
    job_tester.check_all()


# Example of testing the negative job output (wrong data)
# (actually, the job doest process this errors)
@pytest.mark.parametrize('cfg_defaults', [config_defaults])
@pytest.mark.parametrize('test_data',[path_to_test_data])
@pytest.mark.parametrize('test_case_name', [ # dataset names from test data
    'neg__wrong_data__multi_ORG_mismatch',
    'neg__wrong_data__illegal_characters',
])
def test_job__NIC_IS_Ou_SimpleReport__negative_2(job_tester):
    job_tester.check_all()
"""

# Example of testing the negative job output (wrong data)
# (actually, the job doest process this errors)
@pytest.mark.parametrize('cfg_defaults', [config_defaults])
@pytest.mark.parametrize('test_data',[path_to_test_data])
@pytest.mark.parametrize('test_case_name', [ # dataset names from test data
    'pos__correct_args_and_data__single_ORG',
    'pos__correct_args_and_data__multi_ORG',
    'neg__wrong_args__missed_ORG',
    'neg__wrong_args__wrong_DB_SOURCE',
    'neg__wrong_data__headers_mismatch',
    'neg__wrong_data__multi_ORG_mismatch',
    'neg__wrong_data__illegal_characters',
])
def test_job__NIC_IS_Ou_SimpleReport__negative_2(job_tester):
    job_tester.check_all()