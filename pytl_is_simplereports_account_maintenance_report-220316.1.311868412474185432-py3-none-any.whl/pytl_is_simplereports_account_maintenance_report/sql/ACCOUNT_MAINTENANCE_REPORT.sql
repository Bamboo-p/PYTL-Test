/*
* 30-12-2021: Rekha/Bh: OPKSAIC-2751: enhancing existing standard report to add Tiqmo requirements
                            1. Added alternate number logic to enhance report to EXID in the report based on input parameter
                            2. New input parameter RETURN_EXID introduced to fetch alternate id instead of PAN
                               possible inputs : RETURN_EXID=YES - fetches alternate id instead of card number
                                                 RETURN_EXID=NO - fetches card number
                                                 RETURN_EXID=null - fetches card number
* 13-01-2022: Rekha/Bh: OPKSAIC-2751: removed dependency on OPT_REPORTS  package and Made generic approach for logo and product name
* 14-02-2022: DenisKa : OPKSAIC-3226: fixed the issue with running under users different from OWS.
16-01-2022 : OPKSAIC-3246 : RETURN_EXID is spitted into RETURN_EXID_CARD / RETURN_EXID_CONTRACT
                            For Tiqmo RETURN_EXID_CONTRACT is not applicable , but default value is NO
* 18-03-2022: Shalini: ALMB-701 : added Block code classifier used for NIC group of banks and AECB STATUS TYPE classifier
*/
WITH auth_type as (
    select /*+ NO_MERGE MATERIALIZE */ id 
     From ows.td_auth_type
    where code        = 'EXID'
      and amnd_state  = 'A'
    ),
inst as(
select /*+ NO_MERGE MATERIALIZE */
       id institution_id,bank_code code,name
                      from (select fi.bank_code,
                                   fi.posting_in,
                                   fi.id,
                                   fi2.bank_code bank_code_posting,
                                   fi.name
                            from ows.f_i fi
                                 join ows.f_i fi2 on fi.posting_in = fi2.id
                            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
                            ) inst
                      start with inst.bank_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                                      from dual 
                                                      connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
                                                      )
                      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
    ),
exid as (
 select /*+ NO_MERGE MATERIALIZE */
        e.auth_idt,
        c.contract_number,
		c.con_cat
   from ows.acnt_contract c
   join inst 
     on institution_id = c.f_i
   join ows.td_auth_sch e
     on e.acnt_contract__id = c.id
    and e.amnd_state        = 'A'
    and e.is_ready          = 'Y'        
   join auth_type at1
     on e.auth_type  = at1.id
  where c.amnd_state = 'A'),
 T AS
  (SELECT
    /*+ materialize */
    DISTINCT aa.amnd_prev
  FROM ows.acnt_contract aa
  JOIN inst inst on institution_id=aa.f_i
  WHERE aa.amnd_date >= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')
    AND aa.amnd_date  < TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy') + 1
    AND aa.con_cat    = 'A'
  ),
  a1 AS
  (SELECT decode(a0.amnd_state, 'A',9999999999,a0.ID) row_id ,
    a0.* ,
    ct.NAME ct_tr_title ,
    cs.NAME contr_status_desc ,
    -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
    ap.name product_desc,
    ap.code product_code,
    -- [*][end] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
    inst.code bank_code
  FROM ows.acnt_contract a0
  JOIN inst inst on institution_id=a0.f_i
  LEFT JOIN ows.contr_status cs
  ON cs.ID         = a0.contr_status
  AND cs.amnd_state='A'
  AND cs.con_cat   = a0.con_cat
  JOIN ows.appl_product AP
  ON AP.internal_code = a0.product
  AND AP.amnd_state   = 'A'
  AND AP.f_i          = a0.f_i
  LEFT JOIN ows.client_title ct
  ON a0.tr_title     = ct.ID
  AND ct.amnd_state  ='A'
  WHERE a0.amnd_prev  IN
    (SELECT T.amnd_prev FROM T
    )
  ORDER BY a0.amnd_prev,
    a0.amnd_date DESC
  ) ,
  ac AS
  (SELECT row_number () OVER(PARTITION BY a1.amnd_prev ORDER BY a1.amnd_date DESC, a1.row_id DESC) AS rn,
    a1.*
  FROM a1
  ORDER BY a1.amnd_prev,
    a1.amnd_date DESC,
    a1.row_id DESC
  ) ,
  ts AS
  (SELECT diff.bank_code ,
  diff.contract_number AS contract_number ,
  diff.product_logo,
  diff.product_name,
    diff.field_description ,
    diff.changed_from ,
    diff.changed_to ,
    diff.amnd_date AS amnd_date_stamp ,
    o.user_id      AS upd_amnd_officer ,
    diff.amnd_prev ,
    '1_ACCD' grp
  FROM
    (SELECT ps.*
    FROM
      (SELECT ac.rn ,
        row_id ,
        LEAD(ac.amnd_prev) OVER(PARTITION BY ac.amnd_prev ORDER BY amnd_date DESC, row_id DESC) AS is_first ,
        ac.amnd_date ,
        ac.amnd_state ,
        ac.amnd_prev ,
        ac.amnd_officer ,
        ac.f_i ,
        ac.bank_code ,
        ac.contract_number ,
        ac.product_code                AS product_logo,
        ac.product_desc                AS product_name,
        to_char(ac.pcat)               AS pcatn ,
        to_char(ac.con_cat)            AS con_catn ,
        to_char(ac.terminal_category)  AS terminal_categoryn ,
        to_char(ac.ccat)               AS ccatn ,
        to_char(ac.branch)             AS branchn ,
        to_char(ac.service_group)      AS service_groupn ,
        to_char(ac.contract_number)    AS contract_numbern ,
        to_char(ac.base_relation)      AS base_relationn ,
        to_char(ac.contract_name)      AS contract_namen ,
        to_char(ac.comment_text)       AS comment_textn ,
        to_char(ac.relation_tag)       AS relation_tagn ,
        to_char(ac.contr_type)         AS contr_typen ,
        to_char(ac.old_pack)           AS old_packn ,
        to_char(ac.channel)            AS channeln ,
        to_char(ac.old_scheme)         AS old_schemen ,
        to_char(ac.product_desc)       AS productn ,
        to_char(ac.parent_product)     AS parent_productn ,
        to_char(ac.product_prev)       AS product_prevn ,
        to_char(ac.main_product)       AS main_productn ,
        to_char(ac.liab_category)      AS liab_categoryn ,
        to_char(ac.client_type)        AS client_typen ,
        to_char(ac.liab_contract)      AS liab_contractn ,
        to_char(ac.liab_contract_prev) AS liab_contract_prevn ,
        to_char(ac.billing_contract)   AS billing_contractn ,
        to_char(ac.behavior_group)     AS behavior_groupn ,
        to_char(ac.behavior_type)      AS behavior_typen ,
        to_char(ac.behavior_type_prev) AS behavior_type_prevn ,
        to_char(ac.check_available)    AS check_availablen ,
        to_char(ac.check_usage)        AS check_usagen ,
        to_char(ac.curr)               AS currn ,
        to_char(ac.old_curr)           AS old_currn ,
        /*TO_CHAR(ac.SHARED_BLOCKED)     AS SHARED_BLOCKEDn ,Removed for SAIBI-1663*/
        to_char(ac.auth_limit_amount * - 1) AS credit_limitn,/* Added for SAIBI-1663*/
        to_char(ac.date_open)          AS date_openn ,
        to_char(ac.date_expire)        AS date_expiren ,
        to_char(ac.last_billing_date)  AS last_billing_daten ,
        to_char(ac.next_billing_date)  AS next_billing_daten ,
        to_char(ac.last_scan)          AS last_scann ,
        to_char(ac.card_expire)        AS card_expiren ,
        to_char(ac.production_status)  AS production_statusn ,
        to_char(ac.rbs_member_id)      AS rbs_member_idn ,
        to_char(ac.rbs_number)         AS rbs_numbern ,
        to_char(ac.report_type)        AS report_typen ,
        to_char(ac.max_pin_attempts)   AS max_pin_attemptsn ,
        to_char(ac.pin_attempts)       AS pin_attemptsn ,
        to_char(ac.risk_scheme)        AS risk_schemen ,
        to_char(ac.chip_scheme)        AS chip_schemen ,
        to_char(ac.risk_factor)        AS risk_factorn ,
        to_char(ac.risk_factor_prev)   AS risk_factor_prevn ,
        to_char(ac.contr_status_desc)  AS contr_statusn ,
        to_char(ac.merchant_id)        AS merchant_idn ,
        to_char(ac.ct_tr_title)        AS tr_titlen ,
        to_char(ac.tr_company)         AS tr_companyn ,
        to_char(ac.tr_country)         AS tr_countryn ,
        to_char(ac.tr_first_nam)       AS tr_first_namn ,
        to_char(ac.tr_last_nam)        AS tr_last_namn ,
        to_char(ac.tr_sic)             AS tr_sicn,
        /*Add_Info*/
        regexp_substr(ac.add_info_01,'(APPR_LIM+)=([^;]+);',1,1,'',2) appr_limn ,
        regexp_substr(ac.add_info_01,'(ALLOC_LIM_PERC+)=([^;]+);',1,1,'',2) alloc_lim_percn,
        regexp_substr(ac.add_info_04,'(DD_NUM+)=([^;]+);',1,1,'',2) dd_numn ,
        regexp_substr(ac.add_info_04,'(DD_DAY+)=([^;]+);',1,1,'',2) dd_dayn ,
        regexp_substr(ac.add_info_04,'(DD_PCNT+)=([^;]+);',1,1,'',2) dd_pcntn ,
        LEAD(to_char(ac.pcat)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)               AS pcato ,
        LEAD(to_char(ac.con_cat)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)            AS con_cato ,
        LEAD(to_char(ac.terminal_category)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)  AS terminal_categoryo ,
        LEAD(to_char(ac.ccat)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)               AS ccato ,
        LEAD(to_char(ac.branch)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)             AS brancho ,
        LEAD(to_char(ac.service_group)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)      AS service_groupo ,
        LEAD(to_char(ac.contract_number)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)    AS contract_numbero ,
        LEAD(to_char(ac.base_relation)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)      AS base_relationo ,
        LEAD(to_char(ac.contract_name)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)      AS contract_nameo ,
        LEAD(to_char(ac.comment_text)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)       AS comment_texto ,
        LEAD(to_char(ac.relation_tag)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)       AS relation_tago ,
        LEAD(to_char(ac.contr_type)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)         AS contr_typeo ,
        LEAD(to_char(ac.old_pack)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)           AS old_packo ,
        LEAD(to_char(ac.channel)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)            AS channelo ,
        LEAD(to_char(ac.old_scheme)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)         AS old_schemeo ,
        LEAD(to_char(ac.product_desc)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)       AS producto ,
        LEAD(to_char(ac.parent_product)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)     AS parent_producto ,
        LEAD(to_char(ac.product_prev)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)       AS product_prevo ,
        LEAD(to_char(ac.main_product)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)       AS main_producto ,
        LEAD(to_char(ac.liab_category)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)      AS liab_categoryo ,
        LEAD(to_char(ac.client_type)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)        AS client_typeo ,
        LEAD(to_char(ac.liab_contract)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)      AS liab_contracto ,
        LEAD(to_char(ac.liab_contract_prev)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS liab_contract_prevo ,
        LEAD(to_char(ac.billing_contract)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)   AS billing_contracto ,
        LEAD(to_char(ac.behavior_group)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)     AS behavior_groupo ,
        LEAD(to_char(ac.behavior_type)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)      AS behavior_typeo ,
        LEAD(to_char(ac.behavior_type_prev)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS behavior_type_prevo ,
        LEAD(to_char(ac.check_available)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)    AS check_availableo ,
        LEAD(to_char(ac.check_usage)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)        AS check_usageo ,
        LEAD(to_char(ac.curr)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)               AS curro ,
        LEAD(to_char(ac.old_curr)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)           AS old_curro ,
       /* lead(TO_CHAR(ac.SHARED_BLOCKED)) over(partition BY ac.AMND_PREV order by ac.AMND_DATE DESC, row_id DESC)     AS SHARED_BLOCKEDo , Removed for SAIBI-1663*/
        LEAD(to_char(ac.auth_limit_amount * - 1)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS credit_limito ,/*Added for SAIBI-1663*/
        LEAD(to_char(ac.date_open)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)          AS date_openo ,
        LEAD(to_char(ac.date_expire)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)        AS date_expireo ,
        LEAD(to_char(ac.last_billing_date)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)  AS last_billing_dateo ,
        LEAD(to_char(ac.next_billing_date)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)  AS next_billing_dateo ,
        LEAD(to_char(ac.card_expire)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)        AS card_expireo ,
        LEAD(to_char(ac.production_status)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)  AS production_statuso ,
        LEAD(to_char(ac.rbs_member_id)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)      AS rbs_member_ido ,
        LEAD(to_char(ac.rbs_number)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)         AS rbs_numbero ,
        LEAD(to_char(ac.report_type)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)        AS report_typeo ,
        LEAD(to_char(ac.max_pin_attempts)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)   AS max_pin_attemptso ,
        LEAD(to_char(ac.pin_attempts)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)       AS pin_attemptso ,
        LEAD(to_char(ac.risk_scheme)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)        AS risk_schemeo ,
        LEAD(to_char(ac.chip_scheme)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)        AS chip_schemeo ,
        LEAD(to_char(ac.risk_factor)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)        AS risk_factoro ,
        LEAD(to_char(ac.risk_factor_prev)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)   AS risk_factor_prevo ,
        LEAD(to_char(ac.contr_status_desc)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)  AS contr_statuso ,
        LEAD(to_char(ac.merchant_id)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)        AS merchant_ido ,
        LEAD(to_char(ac.ct_tr_title)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)        AS tr_titleo ,
        LEAD(to_char(ac.tr_company)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)         AS tr_companyo ,
        LEAD(to_char(ac.tr_country)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)         AS tr_countryo ,
        LEAD(to_char(ac.tr_first_nam)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)       AS tr_first_namo ,
        LEAD(to_char(ac.tr_last_nam)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)        AS tr_last_namo ,
        LEAD(to_char(ac.tr_sic)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)             AS tr_sico
        /*Add_Info*/
        ,
        LEAD(regexp_substr(ac.add_info_01,'(ALLOC_LIM_PERC+)=([^;]+);',1,1,'',2)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)    AS alloc_lim_perco ,
        LEAD(regexp_substr(ac.add_info_01,'(APPR_LIM+)=([^;]+);',1,1,'',2)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)          AS appr_limo ,
        LEAD(regexp_substr(ac.add_info_04,'(DD_NUM+)=([^;]+);',1,1,'',2)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)            AS dd_numo ,
        LEAD(regexp_substr(ac.add_info_04,'(DD_DAY+)=([^;]+);',1,1,'',2)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)            AS dd_dayo ,
        LEAD(regexp_substr(ac.add_info_04,'(DD_PCNT+)=([^;]+);',1,1,'',2)) OVER(PARTITION BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC)           AS dd_pcnto
      FROM ac
      ) UNPIVOT ( (changed_from, changed_to) 
      FOR field_description IN ( 
                  (pcato , pcatn) AS 'PCAT',
                  (con_cato , con_catn) AS 'CON_CAT' ,
                  (terminal_categoryo , terminal_categoryn) AS 'TERMINAL_CATEGORY' ,
                  (brancho , branchn) AS 'BRANCH' ,
                  (service_groupo , service_groupn) AS 'SERVICE_GROUP' ,
                  (contract_numbero , contract_numbern) AS 'CONTRACT_NUMBER' ,
                  (base_relationo , base_relationn) AS 'BASE_RELATION' ,
                  (contract_nameo , contract_namen) AS 'CONTRACT_NAME' ,
                  (comment_texto , comment_textn) AS 'COMMENT_TEXT' ,
                  (relation_tago , relation_tagn) AS 'RELATION_TAG' ,
                  (old_packo , old_packn) AS 'OLD_PACK' ,
                  (channelo , channeln) AS 'CHANNEL' ,
                  (old_schemeo , old_schemen) AS 'OLD_SCHEME' ,
                  (producto , productn) AS 'PRODUCT' ,
                  (parent_producto , parent_productn) AS 'PARENT_PRODUCT' ,
                  (liab_categoryo , liab_categoryn) AS 'LIAB_CATEGORY' ,
                  (client_typeo , client_typen) AS 'CLIENT_TYPE' ,
                  (liab_contracto , liab_contractn) AS 'LIAB_CONTRACT' ,
                  (liab_contract_prevo , liab_contract_prevn) AS 'LIAB_CONTRACT_PREV' ,
                  (billing_contracto , billing_contractn) AS 'BILLING_CONTRACT' ,
                  (behavior_groupo , behavior_groupn) AS 'BEHAVIOR_GROUP' ,
                  (behavior_typeo , behavior_typen) AS 'BEHAVIOR_TYPE' ,
                  (behavior_type_prevo , behavior_type_prevn) AS 'BEHAVIOR_TYPE_PREV' ,
                  (check_availableo , check_availablen) AS 'CHECK_AVAILABLE' ,
                  (check_usageo , check_usagen) AS 'CHECK_USAGE' ,
                  (curro , currn) AS 'CURR' ,
                  (old_curro , old_currn) AS 'OLD_CURR' ,
                  /*(SHARED_BLOCKEDo , SHARED_BLOCKEDn) AS 'SHARED_BLOCKED' ,Removed for SAIBI-1663*/
                  (credit_limito,credit_limitn) AS 'CREDIT_LIMIT',/* Added for SAIBI-1663*/
                  (date_openo , date_openn) AS 'DATE_OPEN' ,
                  (date_expireo , date_expiren) AS 'DATE_EXPIRE' ,
                  (last_billing_dateo , last_billing_daten) AS 'LAST_BILLING_DATE' ,
                  (next_billing_dateo , next_billing_daten) AS 'NEXT_BILLING_DATE' ,
                  (card_expireo , card_expiren) AS 'CARD_EXPIRE',
                  (production_statuso , production_statusn) AS 'PRODUCTION_STATUS' ,
                  (rbs_member_ido , rbs_member_idn) AS 'RBS_MEMBER_ID' ,
                  (rbs_numbero , rbs_numbern) AS 'RBS_NUMBER' ,
                  (report_typeo , report_typen) AS 'REPORT_TYPE' ,
                  (max_pin_attemptso , max_pin_attemptsn) AS 'MAX_PIN_ATTEMPTS' ,
                  (pin_attemptso , pin_attemptsn) AS 'PIN_ATTEMPTS' ,
                  (risk_schemeo , risk_schemen) AS 'RISK_SCHEME' ,
                  (chip_schemeo , chip_schemen) AS 'CHIP_SCHEME' ,
                  (risk_factoro , risk_factorn) AS 'RISK_FACTOR' ,
                  (risk_factor_prevo , risk_factor_prevn) AS 'RISK_FACTOR_PREV',
                  (merchant_ido , merchant_idn) AS 'MERCHANT_ID' ,
                  (tr_titleo , tr_titlen) AS 'TR_TITLE' ,
                  (tr_companyo , tr_companyn) AS 'TR_COMPANY' ,
                  (tr_countryo , tr_countryn) AS 'TR_COUNTRY' ,
                  (tr_first_namo , tr_first_namn) AS 'TR_FIRST_NAM' ,
                  (tr_last_namo , tr_last_namn) AS 'TR_LAST_NA' ,
                  (tr_sico , tr_sicn) AS 'TR_SIC',
                  /*Add_Info*/
                  (alloc_lim_perco, alloc_lim_percn) AS 'ALLOC_LIM_PERC',
                  (appr_limo, appr_limn) AS 'APPR_LIM' ,
                  (dd_numo, dd_numn) AS 'DD_NUM' ,
                  (dd_dayo, dd_dayn) AS 'DD_DAY' ,
                  (dd_pcnto, dd_pcntn) AS 'DD_PCNT' ) 
                  ) ps
  WHERE ps.amnd_date >= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')
   AND ps.amnd_date    < TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')+1
    ) diff
  JOIN ows.officer o
  ON o.amnd_state                     = 'A'
  AND o.ID                            = diff.amnd_officer
  WHERE (nvl(diff.changed_from, '0') <> nvl(diff.changed_to, '0')
  OR diff.amnd_state                  = 'C')
  AND diff.is_first                  IS NOT NULL
  ORDER BY f_i ,
    product_logo ,
    contract_number ,
    amnd_prev ,
    field_description ,
    amnd_date_stamp DESC
  ) 
  ,
  cls_q AS
  (
   SELECT inst.code bank_code ,
    ac.contract_number ,
    -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
    ap.code as product_logo ,
    ap.name as product_name,
    -- [*][end] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
    CASE
      WHEN cst.code LIKE 'BC_AC_DEC_M-'
        ||inst.code
        ||'-CPY'
      THEN 'BLOCK-CODE ACCOUNT'
      WHEN cst.code LIKE 'BCODE-A1-'
        ||inst.code 
        OR cst.code LIKE 'BCC-ACC1-'||inst.code -- [+] 220318.1 = Shalini = ALMB-701 : added Block code classifier used for NIC group of banks
      THEN 'BLOCK-CODE 1'
      WHEN cst.code LIKE 'BCODE-A2-'
        ||inst.code 
        OR cst.code LIKE 'BCC-ACC2-'||inst.code -- [+] 220318.1 = Shalini = ALMB-701 : added Block code classifier used for NIC group of banks
      THEN 'BLOCK-CODE 2'
      ELSE UPPER(cst.NAME )
    END field_description ,
    CASE
      WHEN (
        cst.code LIKE  'CONTR_STATUS'
        OR cst.code LIKE  'BFA_ACCOUNT_STATUS'
        OR cst.code LIKE  'AMF_WAIVE_ACC'
        OR cst.code LIKE  'INTEREST_WAIVE_PE'
        OR cst.code LIKE  'LPF_WAIVE_PE'
        OR cst.code LIKE  'OVL_WAIVE_PE'
        OR cst.code LIKE  'STMT_FEE_WAIVE_PERS'
        OR cst.code LIKE  'CARD_TARIFF'
        OR cst.code LIKE  'STMT_FLAG_PE'
        OR cst.code LIKE  'STMT_FEE_WAIVE_PE'
        OR cst.code LIKE  'MMF_WAIVE_CARD_PE'
        OR cst.code LIKE  'AMF_WAIVE_CARD_PE'
        OR cst.code LIKE  'BILLING_DAY'
        OR cst.code LIKE  'MMF_WAIVE_ACC'
        OR cst.code LIKE  'MTP_FLAG_PE'
        OR cst.code LIKE  'LTY_ACCR_PE'
        OR cst.code LIKE  'PORTAL_ACCESS_FLAG_PE'
        OR cst.code LIKE  'SCF_FLAG_PE'
        OR cst.code LIKE 'NSF_WAIVE_PE'
        OR cst.code LIKE 'FINANCE_CHARGES_PE'
        OR cst.code LIKE 'JF_ACC_WAIVE_PE'
        OR cst.code LIKE 'INS_WAIVE_PE'
        OR cst.code LIKE 'RE_ORDER_WAIVE_PE'
        OR cst.code LIKE 'RE_ISSUE_WAIVE_PE'
        OR cst.code LIKE 'INS_ENROLMENT-01'
        OR cst.code LIKE 'INS_ENROLMENT-02'
        OR cst.code LIKE 'INS_ENROLMENT-03'
        OR cst.code LIKE 'INS_ENROLMENT-04'
        OR cst.code LIKE 'INS_ENROLMENT-05'
        OR cst.code LIKE 'INS_ENROLMENT-06'
        OR cst.code LIKE 'INS_ENROLMENT-07'
        OR cst.code LIKE 'INS_ENROLMENT-08'
        OR cst.code LIKE 'INS_ENROLMENT-09'
        OR cst.code LIKE 'INS_ENROLMENT-10'
        OR cst.code LIKE 'INS_ENROLMENT-11'
        OR cst.code LIKE 'INS_ENROLMENT-12'
        OR cst.code LIKE 'DIRECT_DEBIT'
        OR cst.code LIKE 'LTY_ENROLMENT'
        OR cst.code LIKE 'SMS_ENROLLMENT'
        -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : added logo classifier
        OR cst.code LIKE 'LOGO'
        -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : added logo classifier
        OR cst.code LIKE 'AECB_STATUS_TYPE' -- [+] 220318.1 = Shalini = ALMB-701 : added AECB STATUS TYPE classifier
      )
      THEN csv_o.NAME
      WHEN (cst.code LIKE 'BCODE-A1-'
        ||inst.code
      OR cst.code LIKE 'BCODE-A2-'
        ||inst.code
      OR cst.code LIKE 'BC_AC_DEC_M_'
        ||inst.code
        ||'_CPY'
      -- [+] [begin] 220318.1 = Shalini = ALMB-701 : added Block code classifier used for NIC group of banks
      OR cst.code LIKE 'BCC-ACC1-'
       ||inst.code
      OR cst.code LIKE 'BCC-ACC2-'
       ||inst.code
      -- [+] [end] 220318.1 = Shalini = ALMB-701 : added Block code classifier used for NIC group of banks
       )
      THEN decode(to_char(csv_o.code),'_', NULL,csv_o.code)
      ELSE decode(to_char(csv_o.code),'_', NULL,csv_o.code)
    END changed_from ,
    CASE
      WHEN (cst.code LIKE  'CONTR_STATUS'
            OR cst.code LIKE  'BFA_ACCOUNT_STATUS'
            OR cst.code LIKE  'AMF_WAIVE_ACC'
            OR cst.code LIKE  'INTEREST_WAIVE_PE'
            OR cst.code LIKE  'LPF_WAIVE_PE'
            OR cst.code LIKE  'OVL_WAIVE_PE'
            OR cst.code LIKE  'STMT_FEE_WAIVE_PERS'
            OR cst.code LIKE  'CARD_TARIFF'
            OR cst.code LIKE  'STMT_FLAG_PE'
            OR cst.code LIKE  'STMT_FEE_WAIVE_PE'
            OR cst.code LIKE  'MMF_WAIVE_CARD_PE'
            OR cst.code LIKE  'AMF_WAIVE_CARD_PE'
            OR cst.code LIKE  'BILLING_DAY'
            OR cst.code LIKE  'MMF_WAIVE_ACC'
            OR cst.code LIKE  'MTP_FLAG_PE'
            OR cst.code LIKE  'LTY_ACCR_PE'
            OR cst.code LIKE  'PORTAL_ACCESS_FLAG_PE'
            OR cst.code LIKE  'SCF_FLAG_PE'
            OR cst.code LIKE 'NSF_WAIVE_PE'
            OR cst.code LIKE 'FINANCE_CHARGES_PE'
            OR cst.code LIKE 'JF_ACC_WAIVE_PE'
            OR cst.code LIKE 'INS_WAIVE_PE'
            OR cst.code LIKE 'RE_ORDER_WAIVE_PE'
            OR cst.code LIKE 'RE_ISSUE_WAIVE_PE'
            OR cst.code LIKE 'INS_ENROLMENT-01'
            OR cst.code LIKE 'INS_ENROLMENT-02'
            OR cst.code LIKE 'INS_ENROLMENT-03'
            OR cst.code LIKE 'INS_ENROLMENT-04'
            OR cst.code LIKE 'INS_ENROLMENT-05'
            OR cst.code LIKE 'INS_ENROLMENT-06'
            OR cst.code LIKE 'INS_ENROLMENT-07'
            OR cst.code LIKE 'INS_ENROLMENT-08'
            OR cst.code LIKE 'INS_ENROLMENT-09'
            OR cst.code LIKE 'INS_ENROLMENT-10'
            OR cst.code LIKE 'INS_ENROLMENT-11'
            OR cst.code LIKE 'INS_ENROLMENT-12'
            OR cst.code LIKE 'DIRECT_DEBIT'
            OR cst.code LIKE 'LTY_ENROLMENT'
            OR cst.code LIKE 'SMS_ENROLLMENT'
            -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : added logo classifier
            OR cst.code LIKE 'LOGO'
            -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : added logo classifier
            OR cst.code LIKE 'AECB_STATUS_TYPE' -- [+] 220318.1 = Shalini = ALMB-701 : added AECB STATUS TYPE classifier
      )
      THEN csv_n.NAME
      WHEN (cst.code LIKE 'BCODE-A1-'
        ||inst.code
      OR cst.code LIKE 'BCODE-A2-'
        ||inst.code
      OR cst.code LIKE 'BC_AC_DEC_M_'
        ||inst.code
        ||'_CPY'
     -- [+] [begin] 220318.1 = Shalini = ALMB-701 : added Block code classifier used for NIC group of banks
      OR cst.code LIKE 'BCC-ACC1-'
        ||inst.code
     OR cst.code LIKE 'BCC-ACC2-'
       ||inst.code
     -- [+] [end] 220318.1 = Shalini = ALMB-701 : added Block code classifier used for NIC group of banks
     )
      THEN decode(to_char(csv_n.code),'_', NULL,csv_n.code)
      ELSE decode(to_char(csv_n.code),'_', NULL,csv_n.code)
    END changed_to ,
    CL.status_date amnd_date_stamp ,
    o.user_id upd_amnd_officer
    /*,cst.CON_CAT ,cst.code */
    ,
    cst.code
    ,
    '2_CLS_Q' grp
  FROM ows.acnt_contract ac
  JOIN inst inst on institution_id=ac.f_i
  AND ac.amnd_state='A'
  AND ac.con_cat   ='A'
  JOIN ows.cs_status_log CL
  ON ac.ID         = CL.acnt_contract__oid
  AND ac.amnd_state='A'
  JOIN ows.officer o
  ON o.ID         = CL.officer
  AND o.amnd_state='A'
  JOIN ows.cs_status_type cst
  ON cst.amnd_state='A'
  AND cst.ID       = CL.status_type
  JOIN ows.cs_status_value csv_o
  ON csv_o.ID         =CL.status_value_prev
  AND csv_o.amnd_state='A'
  AND cst.ID          = csv_o.cs_status_type__oid
  JOIN ows.cs_status_value csv_n
  ON csv_n.ID         =CL.status_value
  AND csv_n.amnd_state='A'
  AND cst.ID          = csv_n.cs_status_type__oid
  JOIN ows.appl_product AP
  ON AP.internal_code = ac.product
  AND AP.amnd_state   = 'A'
  AND AP.f_i          = ac.f_i
  AND cst.ID          = CL.status_type
  WHERE ac.date_open   <= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')
 AND CL.status_date >= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')
 AND CL.status_date  < TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy') + 1
  /*   BaseSegment Maint Check  */
  AND ac.con_cat='A'
  AND ( cst.code LIKE 'BC_AC_DEC_M_'
    ||inst.code
    ||'_CPY'                            
  OR cst.code LIKE 'BCODE-A1-'
    ||inst.code                       
  OR cst.code LIKE 'BCODE-A2-'
    ||inst.code
  -- [+] [begin] 220318.1 = Shalini =ALMB-701 : added Block code classifier used for NIC group of banks
  OR cst.code LIKE 'BCC-ACC1-'
    ||inst.code
  OR cst.code LIKE 'BCC-ACC2-'
    ||inst.code
  -- [+] [end] 220318.1 = Shalini = ALMB-701 : added Block code classifier used for NIC group of banks
    OR cst.code LIKE  'CONTR_STATUS'
    OR cst.code LIKE  'BFA_ACCOUNT_STATUS'
    OR cst.code LIKE  'AMF_WAIVE_ACC'
    OR cst.code LIKE  'INTEREST_WAIVE_PE'
    OR cst.code LIKE  'LPF_WAIVE_PE'
    OR cst.code LIKE  'OVL_WAIVE_PE'
    OR cst.code LIKE  'STMT_FEE_WAIVE_PERS'
    OR cst.code LIKE  'CARD_TARIFF'
    OR cst.code LIKE  'STMT_FLAG_PE'
    OR cst.code LIKE  'STMT_FEE_WAIVE_PE'
    OR cst.code LIKE  'MMF_WAIVE_CARD_PE'
    OR cst.code LIKE  'AMF_WAIVE_CARD_PE'
    OR cst.code LIKE  'BILLING_DAY'
    OR cst.code LIKE  'MMF_WAIVE_ACC'
    OR cst.code LIKE  'MTP_FLAG_PE'
    OR cst.code LIKE  'LTY_ACCR_PE'
    OR cst.code LIKE  'PORTAL_ACCESS_FLAG_PE'
    OR cst.code LIKE  'SCF_FLAG_PE'
    OR cst.code LIKE 'NSF_WAIVE_PE'
    OR cst.code LIKE 'FINANCE_CHARGES_PE'
    OR cst.code LIKE 'JF_ACC_WAIVE_PE'
    OR cst.code LIKE 'INS_WAIVE_PE'
    OR cst.code LIKE 'RE_ORDER_WAIVE_PE'
    OR cst.code LIKE 'RE_ISSUE_WAIVE_PE'
    OR cst.code LIKE 'INS_ENROLMENT-01'
    OR cst.code LIKE 'INS_ENROLMENT-02'
    OR cst.code LIKE 'INS_ENROLMENT-03'
    OR cst.code LIKE 'INS_ENROLMENT-04'
    OR cst.code LIKE 'INS_ENROLMENT-05'
    OR cst.code LIKE 'INS_ENROLMENT-06'
    OR cst.code LIKE 'INS_ENROLMENT-07'
    OR cst.code LIKE 'INS_ENROLMENT-08'
    OR cst.code LIKE 'INS_ENROLMENT-09'
    OR cst.code LIKE 'INS_ENROLMENT-10'
    OR cst.code LIKE 'INS_ENROLMENT-11'
    OR cst.code LIKE 'INS_ENROLMENT-12'
    OR cst.code LIKE 'DIRECT_DEBIT'
    OR cst.code LIKE 'LTY_ENROLMENT'
    OR cst.code LIKE 'SMS_ENROLLMENT'
    -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : added logo classifier
    OR cst.code LIKE 'LOGO'
    -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : added logo classifier
    OR cst.code LIKE 'AECB_STATUS_TYPE' -- [+] 220318.1 = Shalini = ALMB-701 : added AECB STATUS TYPE classifier
    )
  ),
/*  20191112.004 */
ins_contract AS(
SELECT /*+ no_merge ordered */
       inst.code bank_code,
       C.ID,
       C.contract_number,
       -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
       ap.code as product_logo ,
       ap.name as product_name
       -- [*][end] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
  FROM ows.acnt_contract C
  JOIN inst inst on institution_id=c.f_i
  JOIN ows.appl_product AP 
    ON AP.internal_code  = C.product  
   AND AP.amnd_state = 'A' 
   AND AP.f_i = C.f_i
 WHERE C.amnd_state = 'A'
),
changed_contract_lim AS(
SELECT /*+ no_merge */
       DISTINCT 
       bank_code,
       u.contract,
       C.contract_number,
       product_logo ,
       product_name
  FROM ows.usage_templ_appr u
  JOIN ins_contract C
    ON C.ID = u.contract
 WHERE TRUNC(u.record_date) = TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')
),
limiter_history AS(
SELECT /*+ no_merge ordered */
       bank_code,
       u.ID,
       u.record_date AS record_date,
       u.max_amount  AS max_amountn,
       u.max_number  AS max_numbern,
       u.max_pcnt    AS max_pcntn, 
       u.max_single_amount AS max_singl_amntn,
       LAG(u.ID) OVER (PARTITION BY u.contract ORDER BY u.record_date) AS prev_id,
       LAG(u.max_amount) OVER (PARTITION BY u.contract ORDER BY u.record_date) AS max_amounto,
       LAG(u.max_number) OVER (PARTITION BY u.contract ORDER BY u.record_date) AS max_numbero,
       LAG(u.max_pcnt) OVER (PARTITION BY u.contract ORDER BY u.record_date) AS max_pcnto,
       LAG(u.max_single_amount) OVER (PARTITION BY u.contract ORDER BY u.record_date) AS max_singl_amnto,
       C.contract_number,
       C.product_logo,
       C.product_name,
       u.officer
  FROM ows.usage_templ_appr u
  JOIN changed_contract_lim C
    ON u.contract = C.contract
 WHERE usage_code = 'CASH_USAGE' 
), 
cash_usage AS(  
SELECT 
       diff.bank_code,
       diff.product_logo,
       diff.product_name,
       diff.contract_number AS contract_number,
       diff.field_description ,
       diff.changed_from ,
       diff.changed_to,
       diff.record_date AS amnd_date_stamp,
       o.user_id        AS upd_amnd_officer ,
       '3_LIM' grp       
  FROM (
  SELECT H.*
    FROM limiter_history H
  UNPIVOT ( 
      (changed_from, changed_to) 
      FOR field_description IN (
      (max_amounto, max_amountn)         AS 'CASH_USAGE(MAX_AMOUNT)',
      (max_numbero, max_numbern)         AS 'CASH_USAGE(MAX_NUMBER)',
      (max_pcnto, max_pcntn)             AS 'CASH_USAGE(MAX_PCNT)',
      (max_singl_amnto, max_singl_amntn) AS 'CASH_USAGE(MAX_SINGLE_AMOUNT)')
      ) H
    ) diff
  JOIN ows.officer o
    ON o.ID = diff.officer
   AND o.amnd_state = 'A'
 WHERE nvl(diff.changed_from,0) <> nvl(diff.changed_to,0)
   AND TRUNC(diff.record_date) = TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy') 
),
new_rec_add as
 (
select inst.code bank_code,
       act.contract_number                      as contract_number, 
       (select min(user_id) 
          from ows.officer o 
         where o.amnd_state='A' 
          and o.id= act.amnd_officer
          )                                     as upd_amnd_officer,
       act.amnd_date                            as amnd_date_stamp,
       'NEW RECORD ADDED'                       as field_description,
       null                                     as changed_from ,
       act.contract_number                      as changed_to,
       -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
       ap.code as product_logo ,
       ap.name as product_name,
       -- [*][end] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
       '5_NEW' grp
    from ows.acnt_contract act  
    join inst inst
      on inst.institution_id                 = act.f_i    
    join ows.appl_product ap 
      on ap.internal_code     = act.product 
     and ap.amnd_state        = 'A'
     and nvl(instr(ap.liab_category,'Y'),0) = 0
   where act.pcat             = 'C'
     and act.con_cat          = 'A'
     and act.amnd_state       = 'A'
     and trunc(act.amnd_date) = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')     
     and not exists ( select /*+ no_merge */
                             act.contract_number 
                        from ows.acnt_contract act_in
                        join inst inst
                          on inst.institution_id                     = act_in.f_i
                       where act_in.pcat              = act.pcat
                         and act_in.contract_number   = act.contract_number
                         and trunc(act_in.amnd_date) <  TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
                         and act_in.amnd_state        = 'I' )
),
appl_list as 
(select /*+ no_merge parallel(appl)*/
appl.*,inst.code bank_code
from  ows.adv_appl appl 
join inst on appl.f_i = inst.institution_id
where appl.amnd_state = 'A'
and appl.amnd_date >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
and appl.amnd_date < to_Date(:P_REPORT_DATE,'DD-MM-YYYY') + 1

and upper(appl.objecT_for) = 'CONTRACT'
and upper(appl.wf_stage)   = 'CLOSE'
) , cr_limit as
(
SELECT 
    inst.code bank_code,
    acnt.contract_number    AS contract_number,
    -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
    prd.code as product_logo,
    prd.name as product_name,
    -- [*][end] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
    ch.trans_amount         AS new_value,
    LEAD(ch.trans_amount) OVER(
        PARTITION BY ch.acnt_contract__oid
        ORDER BY
            ch.posting_date DESC
    ) AS old_value,
    ROW_NUMBER() OVER(
        PARTITION BY ch.acnt_contract__oid
        ORDER BY
            ch.posting_date DESC
    ) AS rn,
    (
        SELECT
            user_id
        FROM
            ows.officer
        WHERE
            id = appl.amnd_officer
            AND amnd_state = 'A'
    ) AS amnd_officer,
    appl.amnd_date    
FROM
    ows.appl_list appl
    JOIN ows.credit_history ch ON ch.service_class = 'P'
                                  AND ch.acnt_contract__oid = appl.object_for_id
                                  AND appl.object_type = 'Limit'
                                  AND appl.creation_type in ('IMPORT','ENTRY')
    JOIN ows.acnt_contract acnt ON acnt.amnd_state = 'A'
                                   AND acnt.id = ch.acnt_contract__oid
    join inst on acnt.f_i = inst.institution_id
    JOIN ows.appl_product prd ON prd.internal_code = acnt.product
                                 AND prd.amnd_state = 'A' 
 )

/*  20191112.004 */
SELECT 
  a.bank_code "ORG",
  case when exid.con_cat = 'C' then 
  decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',exid.auth_idt, a.contract_number) else
  decode(upper(substr(nvl(:RETURN_EXID_CONTRACT,'N'),1,1)), 'Y',exid.auth_idt, a.contract_number) end "ACCOUNT NUMBER",
  a.product_logo "PRODUCT LOGO",
  a.product_name "PRODUCT NAME",
  a.field_description "FIELD",
  a.changed_from "FROM",
  a.changed_to "TO",
  to_char(a.amnd_date_stamp,'dd-mm-yyyy') "DATE",
  to_char(a.amnd_date_stamp,'HH24:MI:SS') "TIMESTAMP",
  a.upd_amnd_officer "OFFICER"
FROM  (
   SELECT 
    bank_code,
    product_logo,
    product_name,
    contract_number,
    upd_amnd_officer,
    amnd_date_stamp,
    field_description,
    changed_from ,
    changed_to,
    grp
  FROM ts
UNION ALL
  SELECT 
    bank_code,
    product_logo,
    product_name,
    contract_number ,
    upd_amnd_officer,
    amnd_date_stamp,
    field_description,
    changed_from ,
    changed_to,
    grp
  FROM cls_q
 UNION ALL
   SELECT 
    bank_code,
    product_logo,
    product_name,
    contract_number ,
    upd_amnd_officer,
    amnd_date_stamp,
    field_description,
    nvl(to_char(changed_from),0) AS changed_from ,
    nvl(to_char(changed_to),0) AS changed_to,
    grp
  FROM cash_usage
  UNION ALL
   SELECT 
        bank_code,
        product_logo,
        product_name,
        contract_number,
        upd_amnd_officer,
        amnd_date_stamp,
        field_description,
        changed_from AS changed_from ,
        changed_to   AS changed_to,
        grp
   FROM new_rec_add
   union all
   SELECT  
          bank_code,
          product_logo,
          product_name,
          cr.contract_number,
          amnd_officer,
          amnd_date,
          'CREDIT_LIMIT' field,
          to_char(cr.old_value) as changed_from,
          to_char(cr.new_value) as changed_to,
            '4_CL' grp
    FROM cr_limit cr
    where rn = 1
  ) a 
  left join exid 
         on exid.contract_number = a.contract_number
ORDER BY 
  a.bank_code,
  a.product_logo,
  a.contract_number,
  a.grp,
  a.field_description