__version__ = "240308.1"
__job_name__ = "PyTL_IS_SimpleReports_ACCOUNTS_DUMP"
__bat_files__ = ["NIC_IS_Ou_AccountsDump.bat"]

