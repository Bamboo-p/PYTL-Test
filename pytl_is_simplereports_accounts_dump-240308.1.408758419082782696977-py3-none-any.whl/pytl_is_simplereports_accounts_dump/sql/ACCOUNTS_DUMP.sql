/*
* 220215.7 = DenisKa = OPKSAIC-3226: fixed the issue with running under users different from OWS.
* 220222.1 = DenisKa = ALMB-352: NIC_IS_Ou_AccountsDump_lookup.sql@ows/NIC_IS_Ou_AccountsDump.sql@dwh are rewritten as PyTL_IS_SimpleReports_ACCOUNTS_DUMP@dwh
* 220228.1 = DenisKa = ALMB-352: Optimized PyTL_IS_SimpleReports_ACCOUNTS_DUMP@dwh without view
* 220307.1 = Shalini = ALMB-663: removed hard coded DB link, added DM view 
* 220712.1 = Bharath = OPKSAIC-4608: Alternate Id (EXID) logic added
* 230424.1 = Santosh = NICORE-435: Added base_currency and parent_contract_number
* 240308.1 = Santosh = NICORE-1231: Added P_DATE_FORMAT parameter
*/
with
fi AS (
    SELECT /*+ NO_MERGE MATERIALIZE */
        id          as institution_id,
        branch_code as code,
        name,
        add_info
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code   branch_code_posting,
                dwd_institution.name,
                dwd_institution.add_info
            FROM
                dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    start with inst.branch_code in (
        select trim(regexp_substr(:ORG, '[^,]+', 1, level))
        from dual
        connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
    )        
    CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
),
-- [+][begin] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
contract_ext_nums as (
	select /*+no_merge materialize */
	       dca.contract_idt,
		   dca.attr_value contract_exid
	  from dwa_contract_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CONTRACT'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	),
-- [+][end] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
plans_components as(
    select * from (
        select distinct 
            fi.code||acc_templ.code                             as code,
            sy_convert.get_tag_value(template_details, 'PLAN')  as plan,
            sy_convert.get_tag_value(template_details, 'COMP')  as component
        from
            V_C$acc_templ acc_templ
            join fi on fi.institution_id=acc_templ.f_i where amnd_state = 'A'
    ) where plan is not null and component is not null
)
SELECT /*+ PARALLEL(balance 8) PARALLEL(acnt 8) */
    fi.code                 as org,
    fi.code                 as institution_branch_code,
    fi.name                 as institution_name,
    -- [+][begin] 220712.2 = Bharath : OPKSAIC-4608 : Alternate ID logic added
    decode(upper(substr(nvl(:RETURN_EXID_CONTRACT,'N'),1,1)), 'Y',cen.contract_exid, acnt.personal_account) AS contract_number,
	-- [+][end] 220712.2 = Bharath : OPKSAIC-4608 : Alternate ID logic added
    ag.role_code,
    ag.role_name,
    ag.type_code,
    ag.type_name,
    balance.balance,
    to_char(balance.date_not_null_balance,:P_DATE_FORMAT) as date_not_null_balance,
    balance.interest_rate,
    balance.predicted_interest
    ,plans_components.plan    
    ,plans_components.component
    -- [+][begin] 230424.1 = Santosh = NICORE-435: Added base_currency and parent_contract_number
    ,acnt.base_currency
    ,pc.personal_account as parent_contract_number
    -- [+][end] 230424.1 = Santosh = NICORE-435: Added base_currency and parent_contract_number
FROM
    dwf_account_balance balance
    JOIN dwd_contract acnt ON balance.contract_idt = acnt.record_idt
                              AND acnt.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                              AND acnt.record_date_to   >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    JOIN fi ON fi.institution_id = acnt.institution_id
    JOIN dwd_account_group ag ON balance.account_group_id = ag.id
    -- [+][begin] 230424.1 = Santosh = NICORE-435: Added base_currency and parent_contract_number
    left join dwd_contract pc
        on acnt.parent_contract_idt  = pc.record_idt
       and pc.record_date_from   <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
       and pc.record_date_to     >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    -- [+][end] 230424.1 = Santosh = NICORE-435: Added base_currency and parent_contract_number
    left join plans_components on plans_components.code = fi.code || ag.type_code
    -- [+][begin] 220712.2 = Bharath : OPKSAIC-4608 : Alternate ID logic changed
    left join contract_ext_nums cen on acnt.record_idt = cen.contract_idt
	-- [+][end] 220712.2 = Bharath : OPKSAIC-4608 : Alternate ID logic added
WHERE
    balance.banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    and balance.balance<>0
