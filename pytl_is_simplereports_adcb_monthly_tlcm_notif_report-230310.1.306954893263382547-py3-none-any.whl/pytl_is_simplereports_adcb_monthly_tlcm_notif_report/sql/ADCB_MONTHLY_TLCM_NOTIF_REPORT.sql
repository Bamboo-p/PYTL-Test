/*
* Version history:
* 230301.1 = TatianaO = ADCB-10553: Initial version
* 230310.1 = Shalini  = ADCB-10724: Summary recird update
*/
with org_list
as
(
    select id
         , bank_code
         , name
      from (select fi.bank_code,
                   fi.posting_in,
                   fi.id,
                   fi2.bank_code as bank_code_posting,
                   fi.name
            from ows.f_i fi
                 join ows.f_i fi2 on fi.posting_in = fi2.id
            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
            ) inst
      start with inst.bank_code in (select trim(regexp_substr( :ORG, '[^,]+', 1, level)) org
                                      from dual
                                      connect by regexp_substr( :ORG, '[^,]+', 1, level) is not null
                                   )
      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
)
select
      "ORG",
      nvl("API_DATE",'Grand Total')         AS "Date", --230310.1 = ADCB-10724
      sum("MDES Token Update Resume")       AS "MDES Token Update Resume",
      sum("MDES Token Update Suspend")      AS "MDES Token Update Suspend",
      sum("MDES Token Update Deactivate")   AS "MDES Token Update Deactivate",
      sum("MDES PAN Update")                AS "MDES PAN Update",
      sum("VDEP Token Update Resume")       AS "VDEP Token Update Resume",
      sum("VDEP Token Update Suspend")      AS "VDEP Token Update Suspend",
      sum("VDEP Token Update Deactivate")   AS "VDEP Token Update Deactivate",
      sum("VDEP PAN Update")                AS "VDEP PAN Update",
      sum("Grand Total")                    AS "Grand Total"
  from(
       select "ORG",
              coalesce("API REQUEST TYPE", 'Grand Total') AS "API REQUEST TYPE",
              "API_DATE",
              count(1)                                    AS "COUNT"
         from (
               select   org_list.bank_code                            AS "ORG",
                        trim(req_group.name || ' ' ||req_code.name)   AS "API REQUEST TYPE",
                        to_char(trunc(req.posting_date))              AS "API_DATE"--230310.1 = ADCB-10724
                 from ows.remote_file_req req
                 left outer join ows.sy_std_handbook req_group on (req_group.code = req.request_group
                                                                                            and req_group.group_code = 'REMOTE_FILE_REQUEST__REQ_GROUP'
                                                                                            and req_group.filter1 = req.channel
                                                                                          )
                 left outer join ows.sy_std_handbook req_code on (req_code.code = req.request_code
                                                                               and req_code.group_code = 'REMOTE_FILE_REQUEST__REQ_CODE'
                                                                               and req_code.filter1 = req.request_group
                                                                             )
                 join ows.acnt_contract acnt on (acnt.contract_number = req.card_number
                                                                            and acnt.amnd_state = 'A'
                                                                        )
                 join org_list on (acnt.f_i = org_list.id)
                where req.file_code in ('MCC106','PAN', 'TK', 'CS') and req.amnd_state = 'A'
                  and req.outward_status in ('J', 'Y', 'S', 'N')
                  and trunc(req.posting_date) BETWEEN add_months(to_date(:P_REPORT_DATE,'dd-MM-yyyy'), -1) + 1 AND to_date(:P_REPORT_DATE,'dd-MM-yyyy')
              )
        group by grouping sets (("ORG", "API_DATE"), ("ORG", "API_DATE", "API REQUEST TYPE"))
      )
 pivot
 (
  sum("COUNT")
  for "API REQUEST TYPE" in ('MDES PAN Update'              AS "MDES PAN Update",
                             'MDES Token Update Resume'     AS "MDES Token Update Resume",
                             'MDES Token Update Suspend'    AS "MDES Token Update Suspend",
                             'MDES Token Update Deactivate' AS "MDES Token Update Deactivate",
                             'VDEP PAN Update'              AS "VDEP PAN Update",
                             'VDEP Token Update Resume'     AS "VDEP Token Update Resume",
                             'VDEP Token Update Suspend'    AS "VDEP Token Update Suspend",
                             'VDEP Token Update Deactivate' AS "VDEP Token Update Deactivate",
                             'Grand Total'                  AS "Grand Total"
                            )
 )
 group by grouping sets (("ORG", "API_DATE"), ("ORG"))
