__version__ = "240307.1"
__job_name__ = "PyTL_IS_SimpleReports_ALM_AECB_Extract_CCD"
__bat_files__ = []

