/*
* AECB CCD EXTRACT = ALM_AECB_Extract_CCD.sql
*
* Version history:
* 20211005.1 = Shalini = ALMAS-70  :  001 - Initial development
* 20211025.1 = Shalini = ALMAS-507 :  002 - Changes for SecurityType,SecuredContractFlag,StatementDueAmount fields
* 20211027.1 = Shalini = ALMAS-507 :  003 - Mapping changes for SecuredContractFlag,ProviderApplicationNo,ApplicationReferenceNumber tag values as per latest SDM mapping
* 20211031.1 = Shalini = ALMAS-507 :  004 - Contract status date field changes
* 2023012.1  = Shalini = ALMAS-847 : Refactoring of query
* 20230113.1 = Shalini = ALMAS-847 : Mapping changes for ApplicationReferenceNumber and exclusion of replaced cards from report
* 20230116.1 = Shalini = ALMAS-847 : Mapping and logic changes for amount related fields and OpenDate
* 20230123.1 = Shalini = ALMAS-847 : New client requirement changes
* 20230124.1 = Shalini = ALMAS-847 : Query changes for Cardused flag
* 20230214.1 = Shalini = ALMAS-912 : Exclusion of corporate products
* 20230331.1 = Shalini = ALMAS-983 : Added domain_code filter for tarriff
* 20230928.1 = Shalini = ALMAS-1087 : Logic changes to tarr subquery
* 20240216.1 = Santosh = NICORE-1035 : Logic change to ovveride txn code and name	
* 20240307.1 = Bharath = ALMAS-1145 : Changes to eliminate Purged cards from Day 2
*/
with
inst AS (
    SELECT /*+ NO_MERGE MATERIALIZE */
        id          as institution_id,
        branch_code as org_code,
        name,
        add_info
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code   branch_code_posting,
                dwd_institution.name,
                dwd_institution.add_info
            FROM
                dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    start with inst.branch_code in (
        select trim(regexp_substr(:ORG, '[^,]+', 1, level))
        from dual
        connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
    )
    CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
),

product as (
SELECT /*+ no_merge materialize */
    p.product_id,
    substr(p.code, 1, 3) AS logo,
    p.code,
    p.name
FROM
    v_dwr_product p
    JOIN inst ON inst.org_code = nvl(substr(p.code, 5, 3), '0')
WHERE
    p.class_code = 'BASE_REPORTS'
    AND p.type_code = 'LOGO'
	AND nvl(instr(p.add_info,'CORP_PROD=Y'),0)=0 --[*] 230214.1 = ALMAS-912
    ),

contracts as (
SELECT /*+ no_merge materialize use_index(DWD_CONTRACT_INST_IDX dc) */
    DECODE(p.logo, NULL, dc.parent_contract_idt, dc.record_idt) AS main_contract_idt,
    dc.personal_account,
    dc.record_idt,
    dc.client_idt,
    DECODE(dc.base_currency, curr.code, curr.name) AS base_currency,
    dc.date_open,
    dc.date_close,
    dc.add_info,
    p.name,
    p.logo,
    dc.record_date_from,
    status_id,
    i.org_code,
    sy_convert.get_tag_value(dip.add_info,'IS_ISLAMIC') as islamic_flag,
    dc.institution_id

FROM
    dwd_contract dc
    JOIN inst i ON dc.institution_id = i.institution_id
    JOIN product p ON p.product_id = dc.product_id --[*] 230214.1 = ALMAS-912
    LEFT JOIN dwd_currency curr ON dc.base_currency = curr.code
    LEFT JOIN DWD_INT_PRODUCT dip
    on p.product_id=dip.product_id
    and dip.record_state='A'
WHERE
    dc.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND dc.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
      and dc.client_category='P'
      ),
bal as(
SELECT /*+ no_merge materialize */
    ag.account_group_id,
    ag.type_code
FROM
    v_dwr_account_group ag
WHERE
    ag.class_code = 'BALANCE_TYPE'
    AND ag.type_code  in ('TOTAL_BALANCE','PAST_DUE','TOTAL_DUE')
     ),
balances as (
SELECT /*+ no_merge use_index(DWF_ACC_BALANCE_INST_IDX b) ordered full(b) hash(b c) use_hash(b ag) */
    c.record_idt,
    SUM(CASE WHEN ag.type_code = 'TOTAL_BALANCE' THEN b.balance ELSE 0 END) AS total_balance,
    SUM(CASE WHEN ag.type_code = 'PAST_DUE' THEN b.balance ELSE 0 END) AS past_due,
    SUM(CASE WHEN ag.type_code = 'TOTAL_DUE' THEN b.balance ELSE 0 END) AS total_due
FROM
    dwf_account_balance b
    JOIN inst ON inst.institution_id=b.institution_id
    JOIN contracts c ON c.record_idt = b.contract_idt
    JOIN bal ag ON ag.account_group_id = b.account_group_id
WHERE
    b.banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    AND b.institution_id = inst.institution_id
GROUP BY
    c.record_idt
     ),
last_operations AS
  (SELECT /*+ no_merge materialize */
            operation_type_id,
            type_code,
            code
  FROM v_dwr_operation_type
  WHERE class_code = 'LAST_ACTIVITY_MARTS'
  AND type_code   IN ('LAST_OPER_LTD','TRANS_DT')
  AND code        IN ('TRANS_DT','RETAIL','PAYMENT')
  ),

last_payment as (SELECT /*+ ordered use_hash(entry l) */
                contract_idt,
                MAX(CASE WHEN value_code = 'PAYMENT'   THEN operation_date END) AS last_payment_date,
                MAX(CASE WHEN value_code = 'PAYMENT'   THEN amount END) AS last_payment_amount,
                MAX(CASE WHEN value_code = 'TRANS_DT'  THEN amount END) AS last_debit_amount
             FROM (SELECT NVL(entry.contract_idt, l.contract_idt)       AS contract_idt,
                          NVL(entry.type_code, l.type_code)             AS type_code,
                          NVL(entry.code, l.value_code)                 AS value_code,
                          NVL(entry.operation_date, l.operation_date)   AS operation_date,
                          NVL(entry.amount, l.amount)                   AS amount
                   FROM (SELECT /*+ no_merge index(l dwm_last_oper_inst_idx) */
                             l.contract_idt,
                             l.type_code,
                             l.value_code,
                             l.operation_date,
                             l.amount
                          FROM dwm_last_operation l
                          JOIN inst i
                            ON i.institution_id  = l.institution_id
                         WHERE l.banking_date    = add_months(last_day(to_date(:P_REPORT_DATE,'dd-mm-yyyy')),-1)
                           AND l.type_code IN ('TURNOVERS','TRANS_DT')
                           AND l.value_code IN ('TRANS_DT','RETAIL','PAYMENT')
                         ) l
        FULL OUTER JOIN (SELECT /*+ no_merge use_index(DWF_ACCOUNT_ENTRY_INST_IDX e) */
                                 e.contract_idt,
                                 MAX(e.credit-e.debit) keep (dense_rank FIRST ORDER BY banking_date DESC, primary_entry_idt DESC) AS amount,
                                 MAX(e.banking_date) AS operation_date,
                                 op.type_code,
                                 op.code
                             FROM dwf_account_entry e
                             JOIN inst i
                               ON i.institution_id = e.institution_id
                             JOIN last_operations op
                               ON op.operation_type_id = e.operation_type_id
                            WHERE e.banking_date      > add_months(last_day(to_date(:P_REPORT_DATE,'dd-mm-yyyy')),-1)
                              AND e.banking_date      <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
                          GROUP BY e.contract_idt,
                                 op.type_code,
                                 op.code
                           ) entry
                         ON entry.contract_idt = l.contract_idt
                        AND entry.type_code     = l.type_code
                        AND entry.code          = l.value_code
                        )
                   GROUP BY contract_idt)
,Attr_code as (
SELECT /*+ use_index(dca DWA_CNTR_ATTR_DATE_TO_IDX)*/
    dca.contract_idt,
    max(case when da.type_code = 'DLQ_LEVEL'                 then da.code else null end) AS dlq_level,
    max(case when da.type_code = 'DIRECT_DEBIT' then dca.attr_date_from else null end) as direct_debit_date,
    max(case when da.type_Code = 'BFA_ACCOUNT_STATUS' then
                  case when da.code in ('9')
                  then 'C' else 'A' end
                  else null end) as account_status,
    max(case when da.type_code = 'BFA_ACCOUNT_STATUS' and da.code ='9'
             then dca.attr_date_from
             else null
             end) as close_date,
    max(case when da.type_code = 'AECB_STATUS_TYPE'                 then da.code else null end) AS aecb_status,
    max(case when da.type_code = 'AECB_STATUS_TYPE' then dca.attr_date_from else null end) as aecb_status_date,
--[+] begin 230123.1 = ALMAS-847 
    max(case when da.type_code = 'BLOCK_CODE_ACC2_'||:ORG and da.code in ('B','C','D','E','H') then da.code else null end) AS acc2_blk,
    to_char(max(case when da.type_code = 'BLOCK_CODE_ACC2_'||:ORG and da.code in ('B','C','D','E','H') then dca.attr_date_from else null end),'dd-mm-yyyy') AS acc2_blk_date
--[+] end 230123.1 = ALMAS-847 
FROM
    dwa_contract_attribute dca
    JOIN dwd_attribute da ON da.id = dca.attr_id
    AND da.type_code IN ('DLQ_LEVEL','DIRECT_DEBIT','BFA_ACCOUNT_STATUS','AECB_STATUS_TYPE','BLOCK_CODE_ACC2_'||:ORG) --[+] 230123.1 = ALMAS-847 
    JOIN contracts c ON c.record_idt = dca.contract_idt
WHERE
    dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND dca.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
GROUP BY
    dca.contract_idt
)
,
--[+] begin 230123.1 = ALMAS-847 
Attr_card as (
SELECT /*+ use_index(dca DWA_CNTR_ATTR_DATE_TO_IDX)*/
    dca.card_idt,
    max(case when da.type_code = 'BLOCK_CODE_CARD_'||:ORG and da.code in ('B','C','D','E','F') then da.code else null end) AS card_blk,
    to_char(max(case when da.type_code = 'BLOCK_CODE_CARD_'||:ORG   and da.code in ('B','C','D','E','F') then dca.attr_date_from else null end),'dd-mm-yyyy') AS card_blk_date,
    to_char(max(case when da.type_code = 'PETRA_CARD_STATUS' and da.code in ('P') then dca.attr_date_from else null end),'dd-mm-yyyy') AS card_purge_date,
    max(case when da.type_code = 'PETRA_CARD_STATUS' and da.code in ('P') then da.code else null end) AS card_purge_code,
    max(case when da.type_code = 'PETRA_CARD_STATUS' then da.code else null end) AS card_status
FROM
    dwa_card_attribute dca
    JOIN dwd_attribute da ON da.id = dca.attr_id
    AND da.type_code IN ('BLOCK_CODE_CARD_'||:ORG,'PETRA_CARD_STATUS')
WHERE
    dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND dca.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
   
GROUP BY
    dca.card_idt
),
--[+] end 230123.1 = ALMAS-847
crlimit as (
SELECT /*+ no_merge use_index(dwf_limit_inst_idx lim) */
    contract_idt,
    amount   AS credit_limit
FROM
    dwf_contract_limit lim
    JOIN inst i ON i.institution_id = lim.institution_id
WHERE
    lim.banking_date = TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND lim.type_code = 'FIN_LIMIT'
),

tarr as (
SELECT
    repayment_percent,
    substr(dt.domain, 1, 3) AS orgcd
    ,p.logo --[+]230928.1 = ALMAS-1087
FROM
    dwd_ageing_tariff dat
    JOIN dwd_tariff dt ON dat.record_idt = dt.record_idt
    JOIN inst ON org_code=substr(dt.domain, 1, 3)
    join product p on dt.domain_code=p.logo --[+]230928.1 = ALMAS-1087
WHERE
    dat.record_state = 'A'
    AND dt.record_state = 'A'
    AND dt.type_code = 'MTP_TARIFF'
    AND substr(dt.domain, 1, 3) = org_code
--	AND substr(dt.domain_code, 1, 3) = org_code --[+]230331.1 = ALMAS-983 --[-]230928.1 = ALMAS-1087
),
ot as(
SELECT /*+ materialize*/
           default_conf.add_info,
           default_conf.operation_type_code,
		   default_conf.operation_type_id,
		   default_conf.direction,
           coalesce(org_conf.code, default_conf.code) as txn_code,
		   coalesce(org_conf.name, default_conf.name) as txn_name
      FROM (select operation_type_code, operation_type_id, direction, code, name 
              from v_dwr_operation_type op
              where class_code = 'NIC_TXN_DESC'
                and type_code = :ORG || '_TXN_DESC'
			) org_conf
			FULL OUTER JOIN (select operation_type_code, operation_type_id , direction, code, name, add_info 
                               from v_dwr_operation_type op
                              where class_code = 'NIC_TXN_DESC'
                                and type_code = 'NIC_TXN_DESC'
							) default_conf
			ON (org_conf.operation_type_code = default_conf.operation_type_code)
),
amnt_month as
(
SELECT /*+no_merge use_index(DWF_ACCOUNT_ENTRY_INST_IDX ae)*/
    SUM(ae.debit) as amt_spent,
    ae.contract_idt
FROM
    dwf_account_entry ae
    JOIN inst i ON i.institution_id = ae.institution_id
    JOIN  ot ON ot.operation_type_id = ae.operation_type_id
    AND nvl(instr(ot.add_info,'CTD=Y;'),0)>0
WHERE ae.banking_date > add_months(last_day(to_date(:P_REPORT_DATE,'dd-mm-yyyy')),-1)
AND ae.banking_date      <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
group by ae.contract_idt
),

  billing as(
select /*+ no_merge materialize */
                     contract_idt,
                     max(due_date) due_date,
                     max(case when rn=1 then period_start_date end) period_start_date,
                     max(case when rn=1 then billing_date end) billing_date,
                     max(case when rn=2 and due_date <= to_date(:P_REPORT_DATE,'dd-mm-yyyy') then due_date
                              when rn=3 then due_date end) prev_due_date
                from (

                select /*+ use_index (DWF_CNTR_BILL_INST_IDX dcb)*/
                             contract_idt,
                             due_date,
                             period_start_date,
                             billing_date,
                             dcb.add_info,
                             row_number() over(partition by contract_idt order by billing_date desc) rn
                        from dwf_contract_billing dcb
                        join inst on inst.institution_id = dcb.institution_id
                        join contracts cp on cp.record_idt = dcb.contract_idt
                       where dcb.billing_date >= add_months(to_date(:P_REPORT_DATE,'dd-mm-yyyy'), -2)
                         and dcb.period_start_date <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')

                         )
               where rn in (1,2,3)
               group by contract_idt
),
ctd as
(
SELECT /*+no_merge use_index(DWF_ACCOUNT_ENTRY_INST_IDX ae)*/
    SUM(ae.debit) as ctd_amount,
    ae.contract_idt

FROM
    dwf_account_entry ae
    JOIN inst i ON i.institution_id = ae.institution_id
     JOIN ot ON ot.operation_type_id = ae.operation_type_id
    join billing on ae.contract_idt=billing.contract_idt
    AND nvl(instr(ot.add_info,'CTD=Y;'),0)>0
WHERE ae.BILLING_DATE >= billing.period_start_date
AND ae.banking_date      <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
group by ae.contract_idt
),

entries as (
SELECT /*+ no_merge use_index(ae DWF_ACCOUNT_ENTRY_INST_IDX) use_hash(ae op) */
    ae.*
FROM
    dwf_account_entry ae
    JOIN inst i on i.institution_id=ae.institution_id
    JOIN billing ON billing.contract_idt = ae.contract_idt
WHERE
    ae.banking_date >= billing.period_start_date
    AND ae.banking_date <= billing.billing_date
               ),
ent_1 as(
Select count(1) as counter,
ae.contract_idt
from entries ae
join ot on ot.operation_type_id = ae.operation_type_id
and ot.direction=-1
GROUP BY ae.contract_idt
)
,DPD_levels as (select delq_bill.contract_idt,
                    (case  WHEN attr.dlq_level IN ('0','1') THEN '0'
                           else
                           nvl(to_char((to_date(:P_REPORT_DATE,'dd-mm-yyyy') - delq_bill.prev_due_date) + ((to_number(attr.dlq_level) - 2)*30 )),'0')
                    end) DPD
              from
                    attr_code attr
                    join billing delq_bill on delq_bill.contract_idt = attr.contract_idt

  ),
events as (
    SELECT
    contract_idt,
    case when decision_result = 'F' then '1' else '0' end as fraud_flag,
    nvl(decision_date, bk_decision_date) as fraud_flag_date
FROM
    (
        SELECT /*no_merge use_index(DWF_CNTR_EVENT_INST_IDX dce) */
            dce.contract_idt    AS contract_idt,
            et.group_code       AS decision_code,
            et.code             AS decision_result,
            et.name             AS decision_result_name,
            dce.record_date     AS decision_date,
            dce.activate_date   AS bk_decision_date,
            ROW_NUMBER() OVER(PARTITION BY dce.contract_idt, et.group_code ORDER BY nvl(dce.record_date, activate_date) DESC) AS rn
        FROM
            dwf_contract_event dce
            JOIN inst i ON i.institution_id = dce.institution_id
            JOIN dwd_event_type et ON et.id = dce.event_type_id
                                      AND et.group_code = 'BLOCK_CODE_ACC1'
                                      AND code = 'F'

    )
    WHERE
    rn = 1
    ),

main_data as(
     SELECT /*+ no_merge use_index(DWD_CARD_INST_IDX dc) use_hash(c dcl) no_query_transformation*/
      c.personal_account,
    C.org_code AS ORG,
    cd.pan                   AS ProviderContractNo,
    c.base_currency          AS OriginalCurrency,
    to_char(to_date(:P_REPORT_DATE, 'dd-mm-yyyy'),'mmyyyy') AS ReferenceDate,
    'CREDIT CARD' AS ContractType,
    case when CARD_BLK is not null or ACC2_BLK is not null or card_purge_code is not null then 'C' else attr.account_status end AS ActiveFlag, --[*]  230123.1 = ALMAS-847
	--[*] begin 230116.1 = ALMAS-847
    case when cd.lost_card_idt is not null then to_char(c.date_open, 'ddmmyyyy')
    else to_char(cd.opening_date, 'ddmmyyyy') end AS OpenDate,
	--[*] end 230116.1 = ALMAS-847
    --to_char(close_date, 'ddmmyyyy') AS ClosedDate,
    case when CARD_BLK is not null then card_blk_date
         when card_purge_code is not null then card_purge_date
         when ACC2_BLK is not null then acc2_blk_date 
         else to_char(close_date,'dd-mm-yyyy') end as ClosedDate,
    attr.aecb_status AS ContractStatus,
    to_char(attr.aecb_status_date,'ddmmyyyy') AS ContractStatusDate,
    'CAS' AS methodofpayment,
    'M' AS paymentfrequency,
    abs(crlim.credit_limit) AS creditlimit,
    lpad(tarr.repayment_percent,2,'0')   AS MinimumPaymentPercentage, --[*]  230123.1 = ALMAS-847
    --[*] begin 230116.1 = ALMAS-847
    trim(round(nvl(abs(ba.total_balance),0))) AS Balance,
    round(nvl(abs(ba.past_due),0)) AS OverdueAmount,
    --[*] end 230116.1 = ALMAS-847
    case when (ent_1.counter > 0 and NVL(ctd.ctd_amount,0)>0)  then '1' else '0' end  as CardUsedFlag, --[*]  230124.1 = ALMAS-847
    LPAD(TO_CHAR(round(NVL(ctd.ctd_amount,0)),'FM9999999990'),12,'0') as AmountSpentInMonth, --[*]  230123.1 = ALMAS-847
    case when nvl(ba.total_due,0)>=nvl(lp.last_payment_amount,0)
    then '1' else '0' end as MinimumPaymentFlag,
    (case when dl.DPD between 0 and 5 then 0
                when dl.DPD between 6 and 29 then 1
                when dl.DPD between 30 and 59 then 2
                when dl.DPD between 60 and 89 then 3
                when dl.DPD between 90 and 119 then 4
                when dl.DPD between 120 and 149 then 5
                when dl.DPD between 150 and 179 then 6
                when dl.DPD > 180 then 7
           end) as DaysPaymentDelay
           ,' ' AS IslamicContractFlag --[*]  230123.1 = ALMAS-847,nvl(c.islamic_flag,'N') AS IslamicContractFlag
           ,case when nvl(sy_convert.get_tag_value(appl_info.ADD_INFO_02,'SEC_CH_IND'),'0') in ('C','F')
           THEN 'Y' else 'N' end as SecuredContractFlag
           ,'' as LastStatementMinDue
           ,'' as LastPaidAmount
           ,sy_convert.get_tag_value(appl_info.ADD_INFO_02,'SCORE_APPL_NR') as ProviderApplicationNo
           ,'' as SecurityType
           , nvl(e.fraud_flag,0)  as FraudFlag
           , to_char(e.fraud_flag_date,'DDMMYYYY')   as FraudFlagDate
           ,'' AS SecurityTypeRemoveFlag
--[*] begin 230123.1 = ALMAS-847
           ,'' as PaymentDueDate --,to_char(billing.due_date,'DDMMYYYY') as PaymentDueDate
		   --[*] begin 230116.1 = ALMAS-847
		   ,'' as StatementDueAmount --,LPAD(TO_CHAR(round(NVL((ba.total_due*-1),0)),'FM999999990'),12,' ') as StatementDueAmount
           ,'' as ActualPaymentAmount --,LPAD(TO_CHAR(round(NVL(lp.last_payment_amount,0)),'FM999999990'),12,' ') as ActualPaymentAmount
		   --[*] end 230116.1 = ALMAS-847
--[*] end 230123.1 = ALMAS-847
           ,decode(nvl(sy_convert.get_tag_value(c.ADD_INFO,'RECARD'),'N'),'Y',sy_convert.get_tag_value(appl_info1.ADD_INFO_02,'EXT_ID_1'),c.personal_account) as ApplicationReferenceNumber --[*] 230112.1 = ALMAS-847

FROM
    contracts c
    JOIN dwd_card cd ON c.record_idt = cd.main_contract_idt
                        AND nvl(cd.main_card_flag, 'N') = 'Y'
    JOIN inst i ON i.institution_id=cd.institution_id
    left join balances ba ON ba.record_idt = c.record_idt
    left join last_payment lp on lp.contract_idt = c.record_idt
    LEFT JOIN attr_code attr ON ( attr.contract_idt = c.record_idt )
    LEFT JOIN crlimit crlim ON crlim.contract_idt = c.record_idt
    JOIN tarr ON c.logo = tarr.logo --[*]230928.1 = ALMAS-1087
     left join amnt_month am on am.contract_idt=c.record_idt
     LEFT JOIN billing ON billing.contract_idt = c.record_idt
     left join ctd on ctd.contract_idt=c.record_idt
    LEFT JOIN ent_1 on ent_1.contract_idt = c.record_idt
    LEFT JOIN DPD_levels dl ON dl.contract_idt = c.record_idt
    LEFT JOIN events e on e.contract_idt = C.record_idt
    JOIN dwd_client cl
    ON cl.record_idt       = c.client_idt
    AND cl.institution_id=i.institution_id
    LEFT JOIN opt_dwd_appl_info  appl_info ON appl_info.client_idt = cl.record_idt
    AND appl_info.add_info_type in ('CLIENT_DET_1')
    AND appl_info.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND appl_info.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
	--[+] begin 230112.1 = ALMAS-847
	LEFT JOIN opt_dwd_appl_info  appl_info1
    ON appl_info1.contract_idt = c.record_idt
    AND appl_info1.add_info_type in ('CONTR_DET_1')
    AND appl_info1.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND appl_info1.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
	--[+] end 230112.1 = ALMAS-847
	--[+] begin 230123.1 = ALMAS-847
	LEFT JOIN Attr_card attr_c on
    cd.record_idt=attr_c.card_idt
    --[+] end 230123.1 = ALMAS-847
WHERE
    cd.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND cd.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    and cl.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND cl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
	AND cd.plastic_status!='C' --[+] 230112.1 = ALMAS-847
--[+] begin 230123.1 = ALMAS-847 
	AND ((CARD_BLK_DATE IS NOT NULL AND TO_DATE(CARD_BLK_DATE,'DD-MM-YYYY') >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')) OR CARD_BLK IS NULL)
    AND ((CARD_PURGE_DATE IS NOT NULL AND TO_DATE(CARD_PURGE_DATE,'DD-MM-YYYY') >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')) OR CARD_PURGE_CODE IS NULL)
    AND ((attr.ACC2_BLK_DATE IS NOT NULL AND to_DATE(attr.ACC2_BLK_DATE,'DD-MM-YYYY') >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')) OR attr.ACC2_BLK IS NULL)
    and attr_c.card_status not in ('N','TC')
--[+] end 230123.1 = ALMAS-847 
)
Select
      ORG
      ,rpad(nvl(ProviderContractNo,'0'),35,' ')
      ||rpad(nvl(OriginalCurrency,' '),3,' ')
      ||rpad(ReferenceDate,6,' ')
      ||rpad(ContractType,12,' ')
      ||rpad(nvl(ActiveFlag,'A'),1,' ')
      ||rpad(OpenDate,8,' ')
      ||rpad(nvl(replace(ClosedDate,'-',''),' '),8,' ')
      ||rpad(nvl(ContractStatus,' '),1,' ')
      ||rpad(nvl(ContractStatusDate,' '),8,' ')
      ||MethodOfPayment
      ||PaymentFrequency
      ||lpad(CreditLimit,12,'0')
      ||rpad(MinimumPaymentPercentage,2,' ')
      ||lpad(Balance,12,'0')
      ||lpad(OverdueAmount,12,'0')
      ||CardUsedFlag
      ||lpad(AmountSpentInMonth,12,'0')
      ||rpad(nvl(MinimumPaymentFlag,' '),1,' ')
      ||nvl(DaysPaymentDelay,'0')
      ||IslamicContractFlag
      ||SecuredContractFlag
      ||rpad(nvl(LastStatementMinDue,' '),12,' ')
      ||rpad(nvl(LastPaidAmount,' '),12,' ')
      ||rpad(nvl(ProviderApplicationNo,' '),35,' ')
      ||rpad(nvl(SecurityType,' '),100,' ')
      ||rpad(nvl(FraudFlag,' '),100,' ')
      ||rpad(nvl(FraudFlagDate,' '),8,' ')
      ||rpad(nvl(SecurityTypeRemoveFlag,' '),100,' ')
      ||rpad(nvl(PaymentDueDate,' '),8,' ')
      ||rpad(nvl(StatementDueAmount,' '),12,' ')
      ||rpad(nvl(ActualPaymentAmount,' '),12,' ')
      ||rpad(ltrim(ApplicationReferenceNumber,'0'),35,' ') as "DETAILS"
from main_data