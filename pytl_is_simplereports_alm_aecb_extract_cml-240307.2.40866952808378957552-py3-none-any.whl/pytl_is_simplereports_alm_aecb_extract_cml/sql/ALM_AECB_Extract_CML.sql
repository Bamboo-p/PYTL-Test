/*
* AECB CML EXTRACT = ALM_AECB_Extract_CML.sql
*
* Version history:
* 20211005.1 = Shalini = ALMAS-70  :  001 - Initial development
* 20230112.1 = Shalini = ALMAS-847 : Refactoring of query
* 20230116.1 = Shalini = ALMAS-847 : Mapping changes for ApplicationReferenceNumber
* 20230214.1 = Shalini = ALMAS-912 : Exclusion of corporate products
* 20240307.1 = Bharath = ALMAS-1145 : Changes to eliminate Purged cards from Day 2
*/
WITH inst AS (
    SELECT /*+ no_merge materialize */
        institution_id,
        code AS org_code,
        name
    FROM
        v_dwr_institution
    WHERE
            class_code = 'BASE_REPORTS'
        AND type_code = 'BANK_DESC'
        AND code = :ORG
),
--[+] begin 230214.1 = ALMAS-912
product as (
SELECT /*+ no_merge materialize */
    p.product_id,
    substr(p.code, 1, 3) AS logo,
    p.code,
    p.name
FROM
    v_dwr_product p
    JOIN inst ON inst.org_code = nvl(substr(p.code, 5, 3), '0')
WHERE
    p.class_code = 'BASE_REPORTS'
    AND p.type_code = 'LOGO'
	AND nvl(instr(p.add_info,'CORP_PROD=Y'),0)=0
    ),
--[+] end 230214.1 = ALMAS-912
Attr_code as (
SELECT /*+ index(dca DWA_CNTR_ATTR_DATE_TO_IDX)*/
    dca.contract_idt,
    max(case when da.type_Code = 'BFA_ACCOUNT_STATUS' then
                  case when da.code in ('9')
                  then 'C' else 'A' end
                  else null end) as account_status
FROM
    dwa_contract_attribute dca
    JOIN dwd_attribute da ON da.id = dca.attr_id
    AND da.type_code IN ('BFA_ACCOUNT_STATUS')
WHERE
    dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND dca.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
GROUP BY
    dca.contract_idt
),
--[+] begin 230123.1 = ALMAS-847 
Attr_card as (
SELECT /*+ use_index(dca DWA_CNTR_ATTR_DATE_TO_IDX)*/
    dca.card_idt,
    max(case when da.type_code = 'BLOCK_CODE_CARD_'||:ORG  and da.code in ('B','C','D','E','F') then da.code else null end) AS card_blk,
    to_char(max(case when da.type_code = 'BLOCK_CODE_CARD_'||:ORG   and da.code in ('B','C','D','E','F') then dca.attr_date_from else null end),'dd-mm-yyyy') AS card_blk_date,
    to_char(max(case when da.type_code = 'PETRA_CARD_STATUS' and da.code in ('P') then dca.attr_date_from else null end),'dd-mm-yyyy') AS card_purge_date,
    max(case when da.type_code = 'PETRA_CARD_STATUS' and da.code in ('P') then da.code else null end) AS card_purge_code,
    max(case when da.type_code = 'PETRA_CARD_STATUS' then da.code else null end) AS card_status
FROM
    dwa_card_attribute dca
    JOIN dwd_attribute da ON da.id = dca.attr_id
    AND da.type_code IN ('BLOCK_CODE_CARD_'||:ORG,'PETRA_CARD_STATUS')
WHERE
    dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND dca.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
   
GROUP BY
    dca.card_idt
)
,Attr_cnt as (
SELECT /*+ use_index(dca DWA_CNTR_ATTR_DATE_TO_IDX)*/
    dca.contract_idt,
    max(case when da.type_code = 'BLOCK_CODE_ACC2_'||:ORG and da.code in ('B','C','D','E','H') then da.code else null end) AS acc2_blk,
    to_char(max(case when da.type_code = 'BLOCK_CODE_ACC2_'||:ORG and da.code in ('B','C','D','E','H') then dca.attr_date_from else null end),'dd-mm-yyyy') AS acc2_blk_date
FROM
    dwa_contract_attribute dca
    JOIN dwd_attribute da ON da.id = dca.attr_id
    AND da.type_code IN ('BLOCK_CODE_ACC2_'||:ORG)
WHERE
    dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND dca.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
GROUP BY
    dca.contract_idt
),
--[+] end 230123.1 = ALMAS-847 
main_data AS (
    SELECT /*+ no_merge ordered materialize */
        i.org_code                                    as ORG,
        rpad(nvl(cd.pan, '0'), 35, ' ')               as ProviderContractNo,
        rpad(nvl(cl.client_number, '0'), 16, ' ')     as ProviderSubjectNo,
        rpad(nvl(case when CARD_BLK is not null or ACC2_BLK is not null or card_purge_code is not null then 'C' else attr.account_status  end ,'A'),2,' ') AS Role, --[*] 230123.1 = ALMAS-847 
        --[*] 230116.1 = ALMAS-847
        decode(nvl(sy_convert.get_tag_value(c.ADD_INFO,'RECARD'),'N'),'Y',sy_convert.get_tag_value(appl_info.ADD_INFO_02,'EXT_ID_1')
		,c.personal_account) as ApplicationReferenceNumber
        --[*] 230116.1 = ALMAS-847
    FROM
             dwd_contract c
        JOIN inst i ON i.institution_id = c.institution_id
		JOIN product p ON p.product_id = c.product_id --[*] 230214.1 = ALMAS-912
        JOIN dwd_card cd ON c.record_idt = cd.main_contract_idt
        JOIN dwd_client cl ON cl.record_idt = c.client_idt
                              AND nvl(cd.main_card_flag, 'N') = 'Y'
        LEFT JOIN attr_code attr ON c.record_idt = attr.contract_idt
        LEFT JOIN opt_dwd_appl_info appl_info ON appl_info.contract_idt = c.record_idt --[*] 230116.1 = ALMAS-847
		--[*] begin 230214.1 = ALMAS-912
		AND appl_info.add_info_type IN ( 'CONTR_DET_1' )
        AND appl_info.record_date_from <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
        AND appl_info.record_date_to >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
		--[*] end 230214.1 = ALMAS-912
        LEFT JOIN Attr_card attr_c on cd.record_idt=attr_c.card_idt --[+] begin 230123.1 = ALMAS-847
		LEFT JOIN Attr_cnt attr_cn on c.record_idt=attr_cn.contract_idt --[+] begin 230123.1 = ALMAS-847

    WHERE
            c.record_date_from <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
        AND c.record_date_to >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
        AND cd.record_date_from <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
        AND cd.record_date_to >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
        AND cl.record_date_from <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
        AND cl.record_date_to >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
        --[+] begin 230123.1 = ALMAS-847
        AND cd.plastic_status!='C'
	    AND ((CARD_BLK_DATE IS NOT NULL AND TO_DATE(CARD_BLK_DATE,'DD-MM-YYYY') >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')) OR CARD_BLK IS NULL)
        AND ((CARD_PURGE_DATE IS NOT NULL AND TO_DATE(CARD_PURGE_DATE,'DD-MM-YYYY') >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')) OR CARD_PURGE_CODE IS NULL)
        AND ((attr_cn.ACC2_BLK_DATE IS NOT NULL AND to_DATE(attr_cn.ACC2_BLK_DATE,'DD-MM-YYYY') >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')) OR attr_cn.ACC2_BLK IS NULL)
		AND attr_c.card_status not in ('N','TC')
        --[+] end 230123.1 = ALMAS-847
)
SELECT
    org                           AS "ORG",
    ProviderContractNo
    || ProviderSubjectNo
    || Role
    || rpad(ltrim(ApplicationReferenceNumber,'0'),35,' ') AS "DETAILS"  --[*] 230123.1 = ALMAS-847
FROM
    main_data