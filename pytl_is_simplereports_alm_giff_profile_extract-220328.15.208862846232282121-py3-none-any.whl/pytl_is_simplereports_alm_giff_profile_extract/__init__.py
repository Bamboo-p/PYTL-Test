__version__ = "220328.15"
__job_name__ = "PyTL_IS_SimpleReports_ALM_GIFF_PROFILE_EXTRACT"
__bat_files__ = []

