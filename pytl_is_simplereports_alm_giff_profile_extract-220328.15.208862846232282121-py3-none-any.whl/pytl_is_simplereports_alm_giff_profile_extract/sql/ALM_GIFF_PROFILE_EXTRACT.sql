/*
* ALMAS-45: GIIFT - Profile creation extract = ALM_GIFF_PROFILE_EXTRACT.sql
*
* Version history:
* 20211008.1 = Shalini = ALMAS-45:   001 - Initial development
* 20211027.2 = Shalini = ALMAS-531:  002 - Passport number tag changes
*/
WITH ins AS
(
    SELECT      /*+ no_merge materialize */
        code   AS branch_code,
        name   AS bank_name,
        institution_id
    FROM v_dwr_institution
    WHERE class_code = 'BASE_REPORTS'
    AND type_code = 'BANK_DESC'
    AND code = :ORG
)
,
client as
(
Select * /*+ no_merge materialize */
from(
Select
cl.record_idt,
cl.record_date_from,
cl.record_date_to
,cl.client_number
,cl.client_category
,decode(clt.code,'CLIENT_PRIV','Private','CLIENT_COMM','Commercial','') as Customer_Type
,cl.first_name||cl.middle_name||cl.last_name as Member_Name
,to_char(cl.birth_date,'ddmmyyyy')as DOB
,cl.gender
,cl.citizenship
,cl.COUNTRY_CODE
,sy_convert.get_tag_value(cl.add_info,'PASSP_NR') as Passport_Number --[*]211027.2 = Shalini = ALMAS-531
,cl.language as
,cl.record_state
,row_number() over (partition by cl.RECORD_IDT order by nvl(cl.RECORD_DATE_FROM, to_date('01.01.1900', 'dd.mm.yyyy')) asc) as cl_rn
from dwd_client cl
join ins
on ins.institution_id=cl.institution_id
LEFT JOIN dwd_client_type clt ON cl.client_type_id = clt.id
)

WHERE record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
AND  record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')

),
addr as(
SELECT /*+ no_merge materialize */
CLIENT_IDT,
MAX(addr_rn) addr_rn
,MAX(record_date_from) record_date_from
,MAX(record_date_to) record_date_to
,MAX(address_line_1)address_line_1
,MAX(address_line_2)address_line_2
,MAX(address_line_3)address_line_3
,MAX(phone)phone
,MAX(phone_mobile)phone_mobile
,MAX(phone_home)phone_home
,MAX(EMAIL)EMAIL
FROM(
        SELECT /*+ no_merge materialize */
            MAX(da.record_date_from) as record_date_from,
            MAX(da.record_date_to) as record_date_to,
            da.client_idt,
            MAX(CASE
                WHEN dat.code = 'STMT_ADDR' THEN address_line_1
                ELSE NULL
            END) as address_line_1,
            MAX(CASE
                WHEN dat.code = 'STMT_ADDR' THEN address_line_2
                ELSE NULL
            END) as address_line_2,
            MAX(CASE
                WHEN dat.code = 'STMT_ADDR' THEN address_line_3
                ELSE NULL
            END) as address_line_3,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN phone
                ELSE NULL
            END) as phone,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN phone_home
                ELSE NULL
            END) as phone_home,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN phone_mobile
                ELSE NULL
            END) as phone_mobile,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN e_mail
                ELSE NULL
            END) as email
            ,row_number() over (partition by DA.RECORD_IDT order by nvl(DA.RECORD_DATE_FROM, to_date('01.01.1900', 'dd.mm.yyyy')) ASC)AS addr_rn
            FROM
            dwd_address da
            JOIN ins ON ins.institution_id = da.institution_id
            JOIN dwd_address_type dat ON da.address_type_id = dat.id
        WHERE
            dat.code IN (
                'STMT_ADDR',
                'ADD_SMS_1'
            )
            AND da.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
            AND da.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        GROUP BY
            da.client_idt, DA.RECORD_IDT,DA.RECORD_DATE_FROM
)
    WHERE record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
    AND  record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    GROUP BY CLIENT_IDT)
,corp_cif_1 as(
select
c.RECORD_IDT , cl.client_number
from dwd_contract c
join dwd_client cl
on cl.record_idt=c.client_idt
JOIN ins ON ins.institution_id = c.institution_id
WHERE c.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
    AND c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    and cl.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
    AND  cl.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    and cl.institution_id=ins.institution_id
AND PARENT_CONTRACT_IDT IS NULL
AND C.CLIENT_CATEGORY='C'
),
corp_cif_2 as(
Select
c.RECORD_IDT , cl.client_number,corp_cif_1.client_number as cif_number
from dwd_contract c
join dwd_client cl
on cl.record_idt=c.client_idt
JOIN ins ON ins.institution_id = c.institution_id
join corp_cif_1
on CORP_CIF_1.RECORD_IDT=C.parent_contract_idt
WHERE c.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
    AND c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    and cl.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
    AND  cl.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    and cl.institution_id=ins.institution_id
),
attr as(
                    select /*+ no_merge use_hash(dca da) */
                        dca.contract_idt,
                        max(case when da.type_code = 'BLOCK_CODE_ACC1_'||:ORG     then da.code            else null end) as bc1,
                        max(case when da.type_code = 'BLOCK_CODE_ACC2_'||:ORG     then da.code            else null end) as bc2

                   from dwa_contract_attribute dca
                   join dwd_attribute da
                     on da.id = dca.attr_id
                    and da.type_code in ('BLOCK_CODE_ACC1_'||:ORG, 'BLOCK_CODE_ACC2_'||:ORG)
                  where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                    and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
               group by dca.contract_idt
               ),
main_data as
(
select
case when (cl_rn=1 and addr_rn=1 )then 'N'
WHEN (attr.bc1 in('K','Q','X','Y','Z') or attr.bc2 in('G','H')) THEN 'B'
WHEN (attr.bc2 in ('B','C','D','E')) THEN 'C'
WHEN (cl_rn>1 or addr_rn>1) THEN 'U'
END as "ACTION TYPE"
,cl.client_number AS "BASE NUMBER"
,'DEFAULT' AS "CUSTOMER SEGMENT"
,Customer_Type as "CUSTOMER TYPE"
,Member_Name as "MEMBER NAME"
,addr.address_line_1||addr.address_line_2||addr.address_line_3 as "MEMBER ADDRESS"
,COALESCE(addr.phone_mobile, addr.phone,addr.phone_home) as "MOBILE NUMBER"
,addr.email as  "E-MAIL ADDRESS"
,DOB as "DATE OF BIRTH"
,cl.gender as "GENDER"
,cl.citizenship as "NATIONALITY"
,cl.COUNTRY_CODE as "NATIONAL IDENTITY"
,Passport_Number as "PASSPORT NUMBER"
,cl.language as "PREFERRED LANGUAGE"
,'' as "ADDITIONAL DETAILS 1"
,'' as "ADDITIONAL DETAILS 2"
,'~' as "FILLER"

from client cl
JOIN DWD_CONTRACT C
ON CL.RECORD_IDT=C.CLIENT_IDT
and C.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
and C.record_date_to   >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
left join addr ON addr.client_idt = cl.record_idt
left join attr on c.record_idt= attr.contract_idt

WHERE cl.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
AND ( cl.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
            OR addr.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
AND C.parent_contract_idt is null

union all

select
case when (cl_rn=1 and addr_rn=1 )then 'N'
WHEN (attr.bc1 in('K','Q','X','Y','Z') or attr.bc2 in('G','H')) THEN 'B'
WHEN (attr.bc2 in ('B','C','D','E')) THEN 'C'
WHEN (cl_rn>1 or addr_rn>1) THEN 'U'
END as "ACTION TYPE"
,CORP_CIF_1.client_number as "BASE NUMBER"
,'DEFAULT' AS "CUSTOMER SEGMENT"
,Customer_Type as "CUSTOMER TYPE"
,Member_Name as "MEMBER NAME"
,addr.address_line_1||addr.address_line_2||addr.address_line_3 as "MEMBER ADDRESS"
,COALESCE(addr.phone_mobile, addr.phone,addr.phone_home) as "MOBILE NUMBER"
,addr.email as  "E-MAIL ADDRESS"
,DOB as "DATE OF BIRTH"
,cl.gender as "GENDER"
,cl.citizenship as "NATIONALITY"
,cl.COUNTRY_CODE as "NATIONAL IDENTITY"
,Passport_Number as "PASSPORT NUMBER"
,cl.language as "PREFERRED LANGUAGE"
,'' as "ADDITIONAL DETAILS 1"
,'' as "ADDITIONAL DETAILS 2"
,'~' as "FILLER"

from client cl
JOIN DWD_CONTRACT C
ON CL.RECORD_IDT=C.CLIENT_IDT
and C.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
and C.record_date_to   >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
JOIN CORP_CIF_1 ON
CORP_CIF_1.RECORD_IDT=C.parent_contract_idt
left join addr ON addr.client_idt = cl.record_idt
left join attr on c.record_idt= attr.contract_idt
WHERE cl.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
AND ( cl.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
            OR addr.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )

union all

select
case when (cl_rn=1 and addr_rn=1 )then 'N'
WHEN (attr.bc1 in('K','Q','X','Y','Z') or attr.bc2 in('G','H')) THEN 'B'
WHEN (attr.bc2 in ('B','C','D','E')) THEN 'C'
WHEN (cl_rn>1 or addr_rn>1) THEN 'U'
END as "ACTION TYPE"
,CORP_CIF_2.client_number as "BASE NUMBER"
,'DEFAULT' AS "CUSTOMER SEGMENT"
,Customer_Type as "CUSTOMER TYPE"
,Member_Name as "MEMBER NAME"
,addr.address_line_1||addr.address_line_2||addr.address_line_3 as "MEMBER ADDRESS"
,COALESCE(addr.phone_mobile, addr.phone,addr.phone_home) as "MOBILE NUMBER"
,addr.email as  "E-MAIL ADDRESS"
,DOB as "DATE OF BIRTH"
,cl.gender as "GENDER"
,cl.citizenship as "NATIONALITY"
,cl.COUNTRY_CODE as "NATIONAL IDENTITY"
,Passport_Number as "PASSPORT NUMBER"
,cl.language as "PREFERRED LANGUAGE"
,'' as "ADDITIONAL DETAILS 1"
,'' as "ADDITIONAL DETAILS 2"
,'~' as "FILLER"

from client cl
JOIN DWD_CONTRACT C
ON CL.RECORD_IDT=C.CLIENT_IDT
and C.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
and C.record_date_to   >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
JOIN CORP_CIF_2 ON
CORP_CIF_2.RECORD_IDT=C.parent_contract_idt
left join addr ON addr.client_idt = cl.record_idt
left join attr on c.record_idt= attr.contract_idt
WHERE cl.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
AND ( cl.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
            OR addr.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
)
select
:ORG as "ORG",
ROWNUM as RecordNumber,
md.*
from main_data md
