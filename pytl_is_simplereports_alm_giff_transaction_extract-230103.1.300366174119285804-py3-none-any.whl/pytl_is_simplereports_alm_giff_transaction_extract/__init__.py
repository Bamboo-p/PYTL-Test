__version__ = "230103.1"
__job_name__ = "PyTL_IS_SimpleReports_ALM_GIFF_TRANSACTION_EXTRACT"
__bat_files__ = []

