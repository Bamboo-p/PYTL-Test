/*
* ALMAS-46: GIIFT - Transaction extract file = ALM_GIFF_TRANSACTION_EXTRACT.sql
*
* Version history:
* 20211008.1 = Shalini = ALMAS-46 :   001 - Initial development
* 20211102.2 = Shalini = ALMAS-540:   002 - RECORDNUMBER field added and excluded fees from extract
* 20221221.1 = Shalini = ALMAS-785: Refactoring of query and bin mapping changes
* 20221222.1 = Shalini = ALMAS-785 : Excluded fee transaction
* 20230103.1 = Shalini = ALMAS-844 : Mapping changes for Base_number
*/WITH ins AS (
    SELECT      /*+ no_merge materialize */
        code AS branch_code,
        name AS bank_name,
        institution_id
    FROM
        v_dwr_institution
    WHERE
            class_code = 'BASE_REPORTS'
        AND type_code = 'BANK_DESC'
        AND code = :ORG
), corp_cif_1 AS (
    SELECT
        c.record_idt,
        cl.client_number
    FROM
             dwd_contract c
        JOIN dwd_client cl ON cl.record_idt = c.client_idt
        JOIN ins ON ins.institution_id = c.institution_id
    WHERE
            c.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND c.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND cl.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND cl.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND cl.institution_id = ins.institution_id
        AND parent_contract_idt IS NULL
        AND c.client_category = 'C'
), corp_cif_2 AS (
    SELECT
        c.record_idt,
        cl.client_number,
        corp_cif_1.client_number AS cif_number
    FROM
             dwd_contract c
        JOIN dwd_client cl ON cl.record_idt = c.client_idt
        JOIN ins ON ins.institution_id = c.institution_id
        JOIN corp_cif_1 ON corp_cif_1.record_idt = c.parent_contract_idt
    WHERE
            c.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND c.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND cl.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND cl.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND cl.institution_id = ins.institution_id
)
SELECT
    c.ORG                                                                                         AS "ORG",
    ROWNUM                                                                                        AS "RECORDNUMBER" --[+]211102.2 = Shalini = ALMAS-540
    --begin[*]230103.1 = ALMAS-844
    ,decode(c.parent_contract_idt, NULL, cl.client_number, 
	nvl(corp_cif2.client_number,cl.client_number))                                                AS "BASE NUMBER",
	--end[*]230103.1 = ALMAS-844
    'CC'                                                                                          AS "ACCRUAL CHANNEL",
    dcp.bin                                                                                       AS "BIN NUMBER",
    c.logo || c.pct_tariff                                                                        AS "PRODUCT CODE",
    sy_convert.get_tag_value(appl_info.add_info_02, 'SALES_DET_1')                                AS "DEAL CODE" --begin[*]211102.2 = Shalini = ALMAS-540
    ,
    to_char(tr.trans_date, 'DDMMYYYY')                                                            AS "TRANSACTION DATE",
    to_char(tr.trans_date, 'hh:mm:ss')                                                            AS "TRANSACTION TIME",
    tr.trans_arn                                                                                  AS "TRANSACTION ID",
    tr.merchant                                                                                   AS "MERCHANT ID",
    tr.trans_mcc                                                                                  AS "MERCHANT CATEGORY CODE",
    tr.trans_details                                                                              AS "MERCHANT NAME",
    tr.trans_city                                                                                 AS "MERCHANT CITY",
    tr.trans_country_code                                                                         AS "MERCHANT COUNTRY",
    ''                                                                                            AS "TERMINAL-ID",
    decode(direction, '-1', 'DR', '1', 'CR')                                                      AS "TRANSACTION TYPE",
    tr.txn_code                                                                                   AS "TRANSACTION CODE",
    tr.amount * ( - 1 )                                                                           AS "TRANSACTION AMOUNT (QR)",
    decode(tr.is_fee, 1, decode(tr.trans_currency, c.base_currency, NULL, tr.trans_amount), NULL) "SOURCE AMOUNT",
    decode(tr.is_fee, 1, decode(tr.trans_currency, c.base_currency, NULL, curr.name), NULL)       AS "SOURCE CURRENCY",
    '0'                                                                                           AS "NATIONAL ID",
    ''                                                                                            AS "ADDITIONAL DETAILS 1",
    ''                                                                                            AS "ADDITIONAL DETAILS 2",
    '~'                                                                                           AS "FILLER"
FROM
         opt_dm_nice_contract_info c
    JOIN dwd_client cl ON c.client_idt = cl.record_idt
         AND cl.record_date_from <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
         AND cl.record_date_to >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
    JOIN ins ON ins.branch_code = c.ORG
         AND c.banking_date = to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
         AND ins.institution_id=cl.institution_id
    JOIN opt_dm_nice_transaction_info tr ON c.record_idt = tr.contract_idt
         AND tr.banking_date = to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
         AND sy_convert.get_tag_value(tr.oper_type_add_info, 'STMT_TURNOVERS') <> 'FEE' --[+]211102.2 = Shalini = ALMAS-540
         and tr.oper_type_add_info not like '%GEN=Y;%'
		 AND branch_code = tr.ORG
    JOIN dwd_card cd ON cd.record_idt = c.primary_card_idt
         AND cd.record_date_from <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
         AND cd.record_date_to >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
         AND ins.institution_id=cd.institution_id
    JOIN dwd_card_product  dcp ON dcp.id = cd.card_product_id
         AND dcp.record_state = 'A'
    LEFT JOIN dwd_currency curr ON curr.code = tr.trans_currency
         AND curr.record_date_from <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
         AND curr.record_date_to >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
         AND curr.record_state <> 'C'
    LEFT JOIN corp_cif_1 corp_cif2 ON corp_cif2.record_idt = c.parent_contract_idt
--begin[+]211102.2 = Shalini = ALMAS-540
    LEFT JOIN opt_dwd_appl_info appl_info ON appl_info.client_idt = cl.record_idt
        AND appl_info.add_info_type IN ( 'CLIENT_DET_1' )
--end[+]211102.2 = Shalini = ALMAS-540