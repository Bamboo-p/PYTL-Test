with INSTITUTION as 
      (
      select /*+ no_merge materialize */ 
		id,
		branch_code code,
		name
					  from (select dwd_institution.branch_code,
								   dwd_institution.posting_institution_id,
								   dwd_institution.id,
								   dwd_institution2.branch_code branch_code_posting,
                                   dwd_institution.name
							from dwd_institution
								 join dwd_institution dwd_institution2 on dwd_institution.posting_institution_id = dwd_institution2.id
							where dwd_institution.record_state = 'A'
							) inst
					  start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
													  from dual 
													  connect by regexp_substr(:ORG , '[^,]+', 1, level) is not null
													  )
					  connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2      
      )
	  
SELECT /*+ no_merge leading(CON INS PRD CL) */
		INS.code "ORG",
	   CL.COMPANY_NAME "COMPANY NAME",
	   CON.PERSONAL_ACCOUNT AS "ACCOUNT NUMBER",
	   substr(PRD.CODE,1,3) AS "PRODUC LOGO",
	   PRD.NAME 			AS "PRODUCT NAME",                       
	   CL.SHORT_NAME 		AS "SHORT NAME",
	   (SELECT TO_CHAR(max(CNB.BILLING_DATE),'DD') 
			FROM DWF_CONTRACT_BILLING CNB
		   WHERE CON.RECORD_IDT=CNB.CONTRACT_IDT) AS "BILLING CYCLE DATE",
		TO_CHAR(CON.DATE_OPEN, 'DD-MM-YYYY') 		AS "OPENED",
	   NVL(CNL.AMOUNT,0) 	AS "CREDIT LIMIT",
	   DECODE (CON.BASE_CURRENCY,CURR.CODE,CURR.NAME) AS "CURRENCY",
	   PAR.PERSONAL_ACCOUNT AS "MAIN CONTRACT",
       sy_convert.get_tag_value(CL.ADD_INFO,'SALES_MG') AS "SALES AGENT"
       
FROM DWD_CONTRACT CON
JOIN INSTITUTION INS
	ON CON.INSTITUTION_ID = INS.ID
JOIN V_DWR_PRODUCT PRD
	ON CON.PRODUCT_ID = PRD.PRODUCT_ID
JOIN DWD_CLIENT CL
	ON CON.CLIENT_IDT = CL.RECORD_IDT 
LEFT JOIN DWF_CONTRACT_LIMIT CNL
	ON CNL.CONTRACT_IDT=CON.RECORD_IDT 
	AND TRUNC(CNL.BANKING_DATE) = to_date(:P_REPORT_DATE,'DD-MM-YYYY')	
	AND CNL.TYPE_CODE = 'FIN_LIMIT'
JOIN DWD_CURRENCY CURR
	ON CURR.CODE=CON.BASE_CURRENCY
	AND CURR.RECORD_STATE='A'
LEFT JOIN DWD_CONTRACT PAR
	ON CON.PARENT_CONTRACT_IDT=PAR.RECORD_IDT
	AND PAR.RECORD_STATE='A'
WHERE to_date(:P_REPORT_DATE,'DD-MM-YYYY')	 BETWEEN CON.RECORD_DATE_FROM AND CON.RECORD_DATE_TO
AND CON.RECORD_STATE <> 'C'
AND TRUNC(CON.DATE_OPEN) = to_date(:P_REPORT_DATE,'DD-MM-YYYY')	
AND PRD.CLASS_CODE = 'BASE_REPORTS'
AND PRD.TYPE_CODE='LOGO'
AND CL.RECORD_STATE <> 'C'
AND CL.CLIENT_CATEGORY='P'