__version__ = "221110.1"
__job_name__ = "PyTL_IS_SimpleReports_APPLE_PAY_INACTIVE_TOKENS_SMS"
__bat_files__ = []

