__version__ = "231016.1" 
__job_name__ = "PyTL_IS_SimpleReports_AQ_ADCB_MERCHANT_DUMP"
__bat_files__ = []