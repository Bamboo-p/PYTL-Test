/*
* Code for AQ_ADCB_MERCH_DUMP
* PyTL_IS_SimpleReports_AQ_ADCB_MERCH_DUMP = AQ_ADCB_MERCH_DUMP.sql
* Version history:
* 230515.1 : angajalak : ADCBA-1376: Initial development
* 230601.3 : angajalak : ADCBA-1376: Tariff Schema Prefix added (merged with development branch)
* 230601.4 : deniska   : ADCBA-1376: Removing redaundant spaces (included into release 23.2.4)
* 230609.1 : angajalak : PRD-24209 : code changes for mcc and amex_id
* 231016.1 : PadalaS   : ADCBA-1424: Updated code to fetch CBK Contact name from Payment address in position 2222
*/

WITH /*Python job: PyTL_IS_SimpleReports_AQ_ADCB_MERCHANT_DUMP */ inst as
 (select /*+ no_merge materialize */ * from v_dwr_institution i
    WHERE i.code          = :ORG
    AND i.class_code    = 'ACQ_REPORTS'
    AND i.type_code     = 'FI_NAME'),
  ctr_attributes as (
  select /*+ leading(dca) use_hash(dca da) */
    dca.contract_idt,
    MAX(DECODE(da.type_code, 'MERCH_BLOCK_CODE', DECODE(da.code, 'HOLD', 'H', 'CLOSED', 'C'))) block_code,
    MAX(DECODE(da.type_code, 'ACQ_ACPT_VISA', da.code)) acpt_visa,
    MAX(DECODE(da.type_code, 'ACQ_ACPT_MC', da.code)) acpt_mc,
    MAX(DECODE(da.type_code, 'ACQ_ACPT_DCI', da.code)) acpt_dci,
    MAX(DECODE(da.type_code, 'ACQ_ACPT_JCB', da.code)) acpt_jcb,
    MAX(DECODE(da.type_code, 'ACQ_ACPT_CUP', da.code)) acpt_cup,
    MAX(DECODE(da.type_code, 'ACQ_ACPT_AMEX', da.code)) acpt_amex,
    MAX(DECODE(da.type_code, 'ACQ_ACPT_MQ', da.code)) acpt_mq,
    MAX(DECODE(da.type_code, 'ACQ_COMM_STTLM', da.code)) comm_sttl,
    MAX(DECODE(da.type_code, 'ACQ_MISC_STTL', da.code)) misc_sttl,
    MAX(DECODE(da.type_code, 'ACQ_MMF', da.code)) mmf,
    MAX(DECODE(da.type_code, 'MERCH_BLOCK_CODE', DECODE(code, 'CLOSED', dca.attr_date_from, NULL))) date_close,
    MAX(DECODE(da.type_code, 'ACQ_VATCOM_MERCH', da.code)) vatcom_flag,
    MAX(DECODE(da.type_code, 'ACQ_VATFEE_MERCH', da.code)) vatfee_flag,
    MAX(DECODE(da.type_code, 'ACQ_MERCH_DCC', da.code)) dcc_type
  FROM dwa_contract_attribute dca
  JOIN dwd_attribute da ON dca.attr_id = da.id
    AND da.type_code IN ('MERCH_BLOCK_CODE', 'ACQ_ACPT_VISA', 'ACQ_ACPT_MC', 'ACQ_ACPT_DCI', 'ACQ_ACPT_JCB', 'ACQ_ACPT_CUP',
      'ACQ_ACPT_AMEX', 'ACQ_ACPT_MQ', 'ACQ_COMM_STTLM', 'ACQ_MISC_STTL', 'ACQ_MMF', 'ACQ_MERCH_DCC', 'ACQ_VATCOM_MERCH', 'ACQ_VATFEE_MERCH')
  WHERE to_date(:P_BANK_DATE,'DD-MM-YYYY') BETWEEN dca.ATTR_DATE_FROM AND dca.ATTR_DATE_TO
  GROUP BY dca.contract_idt
 ),
  affiliated_clients AS
  (SELECT /*+ no_merge leading(a, at, inst, cl) use_hash(a at) use_hash(cl a) */ *
  FROM
    (SELECT a.contract_idt,
      cl.ident_number,
      at.code
    FROM dwd_affiliation a
    JOIN dwd_affiliation_type at
    ON at.id = a.affiliation_type_id
    AND to_date(:P_BANK_DATE,'DD-MM-YYYY') BETWEEN at.record_date_from AND at.record_date_to
    AND at.code IN ('CHAINID1', 'CHAINID2')
    JOIN dwd_client cl
    ON cl.record_idt                      = a.affiliated_client_idt
    ) t pivot(MAX(ident_number) FOR code IN('CHAINID1' CHAIN_ID1, 'CHAINID2' CHAIN_ID2))
  ),
  acq_contracts AS
  (SELECT /*+ no_merge materialize */ record_idt AS device_idt,
    type,
    org,
    CASE
      WHEN type = 'D'
      THEN to_number(trim(SUBSTR(idts,instr(idts,'|',1,2) + 1,instr(idts,'|',1,3) - instr(idts,'|',1,2) - 1)))
      ELSE record_idt
    END AS merch_id,
    CASE
      WHEN type = 'D'
      THEN trim(SUBSTR(accs,instr(accs,'|',1,2) + 1,instr(accs,'|',1,3)- instr(accs,'|',1,2) - 1))
      WHEN type = 'M'
      THEN personal_account
      ELSE NULL
    END AS merch_acc,
    CASE
      WHEN type = 'D'
      THEN to_number(trim(SUBSTR(idts,instr(idts,'|',1,1) + 1,instr(idts,'|',1,2) - instr(idts,'|',1,1) - 1 )))
      WHEN type = 'M'
      THEN to_number(trim(SUBSTR(idts,instr(idts,'|',1,2) + 1,instr(idts,'|',1,3) - instr(idts,'|',1,2) - 1)))
      WHEN type = 'C'
      THEN record_idt
      ELSE NULL
    END AS shoprite_id,
    CASE
      WHEN type = 'D'
      THEN trim(SUBSTR(accs,instr(accs,'|',1,1) + 1,instr(accs,'|',1,2)- instr(accs,'|',1,1) - 1))
      WHEN type = 'M'
      THEN trim(SUBSTR(accs,instr(accs,'|',1,2) + 1,instr(accs,'|',1,3)- instr(accs,'|',1,2) - 1))
      WHEN type = 'C'
      THEN personal_account
      ELSE NULL
    END AS shoprite_acc,
    dba_name,
    date_open  AS merch_date_open,
    date_close AS merch_date_close,
    currency   AS merch_currency,
    status     AS device_status,
    status     AS merch_status,
    status     AS shoprite_status,
    CASE
      WHEN type = 'D'
      THEN trim(SUBSTR(add_info,instr(add_info,'|',1,2) + 1,instr(add_info,'|',1,3)- instr(add_info,'|',1,2) -1))
      ELSE merch_add_info
    END AS merch_add_info,
    int_product_idt,
    root,
    c_order
  FROM
    (SELECT /*+ leading(attr, cattr) use_hash(c i) index(cattr, DWA_CNTR_ATTR_DATE_TO_IDX) */ c.record_idt,
      i.name                         AS org,
      DECODE(s.code, '00', '1', 'C') AS status,
      CASE
        WHEN attr.code = 'DEVICE'
        THEN 'D'
        WHEN attr.code = 'MERCHANT'
        THEN 'M'
        WHEN attr.code = 'SHOPRITE'
        THEN 'C'
        ELSE NULL
      END AS type,
      CASE
        WHEN attr.code = 'DEVICE'
        THEN 1
        WHEN attr.code = 'MERCHANT'
        THEN 2
        WHEN attr.code = 'SHOPRITE'
        THEN 3
        ELSE NULL
      END                                 AS c_order,
      connect_by_root(c.personal_account) AS root,
      c.personal_account,
      c.name AS dba_name,
      DECODE(level,2,'|'
      ||sys_connect_by_path(c.record_idt,'|'),sys_connect_by_path(c.record_idt,'|')) idts,
      DECODE(level,2,'|'
      ||sys_connect_by_path(c.personal_account,'|'),sys_connect_by_path(c.personal_account,'|')) accs,
      NVL(TO_CHAR(c.date_open,'yyyymmdd'),'00000000') date_open,
      NVL(TO_CHAR(c.date_close,'yyyymmdd'),'00000000') date_close,
      cur.name currency,
      c.add_info AS merch_add_info,
      c.int_product_idt,
      DECODE(level,2,'|'
      ||sys_connect_by_path(DECODE(attr.code,'MERCHANT',c.add_info,''),'|'),sys_connect_by_path(DECODE(attr.code,'MERCHANT',c.add_info,''),'|')) add_info
    FROM
    dwa_contract_attribute cattr
    JOIN dwd_attribute attr
    ON attr.id         = cattr.attr_id
    AND attr.type_code = 'ACQ_LVL'
    AND to_date(:P_BANK_DATE,'DD-MM-YYYY') BETWEEN attr.record_date_from AND attr.record_date_to
    AND to_date(:P_BANK_DATE,'DD-MM-YYYY') BETWEEN cattr.attr_date_from AND cattr.attr_date_to
    JOIN dwd_contract c
    ON cattr.contract_idt = c.record_idt
    JOIN inst i
    ON i.institution_id = c.institution_id
    JOIN dwd_contract_status s
    ON s.id = c.status_id
    AND to_date(:P_BANK_DATE,'DD-MM-YYYY') BETWEEN c.record_date_from AND c.record_date_to
    JOIN dwd_currency cur
    ON cur.code = c.base_currency
    AND to_date(:P_BANK_DATE,'DD-MM-YYYY') BETWEEN cur.record_date_from AND cur.record_date_to
      /*WHERE  attr.code = 'DEVICE'*/
      START WITH c.parent_contract_idt IS NULL
      CONNECT BY PRIOR c.record_idt     = c.parent_contract_idt
    )
    /*order by root, c_order*/
  ),
  pers_tariffs AS
  (SELECT /*+ no_merge materialize */ pers.contract_number,
    MAX(DECODE(pers.trf_code, 'ACQ_VAT_RATE', pers.fee_rate, NULL)) AS acq_vat_rate,
    MAX(DECODE(pers.trf_code, 'ACQ_DCC_MRK', pers.fee_rate, NULL))  AS acq_dcc_mrk,
    MAX(DECODE(pers.trf_code, 'ACQ_DCC_REV', pers.fee_rate, NULL))  AS acq_dcc_rev

  FROM opt_v_acq_prsnl_trf_dwh pers
  WHERE pers.trf_code  IN ('ACQ_VAT_RATE','ACQ_DCC_MRK','ACQ_DCC_REV')
  AND pers.record_state = 'A'
  GROUP BY pers.contract_number
  ),
  other_tariffs AS
  (SELECT /*+ no_merge materialize leading(t, ct, st) use_hash(t ct) */
    ct.contract_idt,
    MAX(DECODE(t.type_code, 'ACQ_VAT_RATE', st.fee_rate_value, NULL))       AS acq_vat_rate,
    MAX(DECODE(t.type_code, 'ACQ_DCC_MRK', st.fee_rate_value, NULL))        AS acq_dcc_mrk,
    MAX(DECODE(t.type_code, 'ACQ_DCC_REV', st.fee_rate_value, NULL))        AS acq_dcc_rev,

    MAX(DECODE(t.code, 'VIDOMPRDBMNL', st.fee_rate_value, NULL))        AS VIDOMPRDBMNL_FEE,
    MAX(DECODE(t.code, 'VIDOMPRDBELEC', st.fee_rate_value, NULL))        AS VIDOMPRDBELEC_FEE,
    MAX(DECODE(t.code, 'MCDOMPRDBMNL', st.fee_rate_value, NULL))        AS MCDOMPRDBMNL_FEE,
    MAX(DECODE(t.code, 'MCDOMPRDBELEC', st.fee_rate_value, NULL))        AS MCDOMPRDBELEC_FEE,
    MAX(DECODE(t.code, 'VIDOMSTDBMNL', st.fee_rate_value, NULL))        AS VIDOMSTDBMNL_FEE,
    MAX(DECODE(t.code, 'VIDOMSTDBELEC', st.fee_rate_value, NULL))        AS VIDOMSTDBELEC_FEE,
    MAX(DECODE(t.code, 'MCDOMSTDBMNL', st.fee_rate_value, NULL))        AS MCDOMSTDBMNL_FEE,
    MAX(DECODE(t.code, 'MCDOMSTDBELEC', st.fee_rate_value, NULL))        AS MCDOMSTDBELEC_FEE,
    MAX(DECODE(t.code, 'CUPDOMSTDBMNL', st.fee_rate_value, NULL))        AS CUPDOMSTDBMNL_FEE,
    MAX(DECODE(t.code, 'CUPDOMSTDBELEC', st.fee_rate_value, NULL))        AS CUPDOMSTDBELEC_FEE

    FROM dwh.dwa_contract_tariff ct
  join dwh.dwd_tariff t on ct.tariff_idt = t.record_idt
  AND ct.active_state = 'A'
  AND to_date(:P_BANK_DATE,'DD-MM-YYYY') BETWEEN ct.active_date_from and ct.active_date_to
  LEFT JOIN dwd_service_tariff st
  ON st.record_idt                                  = t.record_idt
  AND st.record_state                               = 'A'
  WHERE (SUBSTR(t.domain, 0, instr(t.domain, '-')    -1)= :ORG  OR SUBSTR(t.domain, 0, 3) = :ORG )
  AND (t.type_code  IN ('ACQ_VAT_RATE','ACQ_DCC_MRK','ACQ_DCC_REV')
  OR t.code IN ('VIDOMPRDBMNL','VIDOMPRDBELEC',
  'MCDOMPRDBMNL','MCDOMPRDBELEC','VIDOMSTDBMNL','VIDOMSTDBELEC','MCDOMSTDBMNL','MCDOMSTDBELEC','CUPDOMSTDBMNL','CUPDOMSTDBELEC'))
  AND t.record_state    = 'A'
  GROUP BY ct.contract_idt
  ),
cntr_addr AS
  (SELECT /*Talend job: ADCB_AQ_MerchDumpFile (getContractAddr)*/
/*+ no_merge leading(i, dat, da) use_hash(da dat) */
    da.contract_idt AS contract_idt,
    MAX(decode(dat.code, 'STMT_ADDR', da.address_line_1)) address_line_1,
    MAX(decode(dat.code, 'STMT_ADDR', da.address_line_2)) address_line_2,
    MAX(decode(dat.code, 'STMT_ADDR', da.address_line_3)) address_line_3,
    MAX(decode(dat.code, 'STMT_ADDR', da.address_line_4)) address_line_4,
    MAX(decode(dat.code, 'STMT_ADDR', da.city)) city,
    MAX(decode(dat.code, 'STMT_ADDR', da.state)) state,
    MAX(decode(dat.code, 'STMT_ADDR', da.country)) country,
    MAX(decode(dat.code, 'STMT_ADDR', da.address_zip)) address_zip,
    MAX(decode(dat.code, 'STMT_ADDR', regexp_substr(da.add_info, '(FIRST_NAME+)=([^;]+);', 1, 1, '', 2))) AS first_name,
    MAX(decode(dat.code, 'STMT_ADDR', da.phone)) phone,
    MAX(decode(dat.code, 'STMT_ADDR', da.fax)) fax,
    MAX(decode(dat.code, 'STMT_ADDR', da.e_mail)) e_mail,
	MAX(decode(dat.code, 'PAYM_ADDR', regexp_substr(da.add_info, '(FIRST_NAME+)=([^;]+);', 1, 1, '', 2))) AS CBK_first_name ----- [+][begin] 231016.1 = PadalaS = ADCBA-1424
 FROM dwd_contract_address da
  JOIN dwd_institution i
   ON  i.id = da.institution_id
   AND i.code = :ORG
   AND to_date(:P_BANK_DATE,'DD-MM-YYYY') BETWEEN i.record_date_from AND i.record_date_to
   AND to_date(:P_BANK_DATE,'DD-MM-YYYY') BETWEEN da.record_date_from AND da.record_date_to
  JOIN dwd_address_type dat
   ON  dat.id = da.address_type_id
   AND dat.code in ('STMT_ADDR', 'PAYM_ADDR')
   AND to_date(:P_BANK_DATE,'DD-MM-YYYY') BETWEEN dat.record_date_from AND dat.record_date_to
 WHERE 1 = 1
  GROUP BY da.contract_idt ),
  cntr_tariff AS (
 SELECT /*Talend job: ADCB_AQ_MerchDumpFile (getContractTariffs)*/
       contract_idt,
       to_char(NVL(TRNS_FEE,0),'FM0999.00') TRNS_FEE,
       to_char(NVL(TERM_RNTL_FEE,0),'FM0999.00') TERM_RNTL_FEE,
       to_char(NVL(ACQ_MEM,0),'FM0999.00') ACQ_MEM,
       to_char(NVL(SIM_FEE,0),'FM0999.00') SIM_FEE,
       to_char(NVL(CHRGBCK_FEE,0),'FM0999.00') CHRGBCK_FEE,
       to_char(NVL(STARTUP_FEE,0),'FM0999.00') STARTUP_FEE,
       to_char(NVL(FRAUD_FEE,0),'FM0999.00') FRAUD_FEE ,
       to_char(NVL(STMT_FEE,0),'FM0999.00') STMT_FEE,
       to_char(NVL(GPRS_FEE,0),'FM0999.00') GPRS_FEE,
       to_char(NVL(INS_FEE,0),'FM0999.00') INS_FEE
  FROM
(SELECT /*+ leading(trf, ctr, i, strf) use_hash(tr ctr) */ ctr.contract_idt, trf.type_code code, strf.FEE_BASE_AMOUNT
       FROM dwa_contract_tariff ctr
       JOIN dwd_institution i
        ON i.id = ctr.institution_id
        AND i.code = :ORG
        AND to_date(:P_BANK_DATE,'DD-MM-YYYY') BETWEEN i.record_date_from and i.record_date_to
        AND i.record_state = 'A'
       JOIN dwd_tariff trf
        ON trf.record_idt = ctr.tariff_idt
        AND trf.type_code IN ('TRANS_FEE','TERMINAL_RENTAL_FEE','ACQ_MMBR_FEE','SIM_FEE','CHARGEBACK_FEE','STARTUP_FEE','FRAUD_HAND_FEE','ACQ_STMT_FEE','GPRS_FEE','INS_FEE')
        AND to_date(:P_BANK_DATE,'DD-MM-YYYY') between trf.record_date_from and trf.record_date_to
        AND trf.record_state != 'C'
        JOIN  dwd_service_tariff strf
        ON strf.record_idt = trf.record_idt
        AND to_date(:P_BANK_DATE,'DD-MM-YYYY') >= strf.activation_date
        AND to_date(:P_BANK_DATE,'DD-MM-YYYY') between strf.record_date_from and strf.record_date_to
        AND strf.record_state != 'C'
        WHERE to_date(:P_BANK_DATE,'DD-MM-YYYY') between ctr.active_date_from and ctr.active_date_to
        AND ctr.active_state != 'C'
        ) t
        PIVOT (MAX(FEE_BASE_AMOUNT) FOR code IN ('TRANS_FEE' TRNS_FEE,'TERMINAL_RENTAL_FEE' TERM_RNTL_FEE,'ACQ_MMBR_FEE' ACQ_MEM,'SIM_FEE' SIM_FEE,
                                            'CHARGEBACK_FEE' CHRGBCK_FEE,'STARTUP_FEE' STARTUP_FEE,'FRAUD_HAND_FEE' FRAUD_FEE,'ACQ_STMT_FEE' STMT_FEE,'GPRS_FEE' GPRS_FEE, 'INS_FEE' INS_FEE ))
         ),
  all_contrs AS (
SELECT /*+ no_merge leading(pers, c, attr) use_hash(c pers) use_hash(c attr) */ c.device_idt As device_idt,
  c.merch_id AS merch_id,
  c.shoprite_id AS shoprite_id,
  c.org AS org,
  dev.device_number AS device_number,
  c.merch_acc AS merch_acc,
  c.shoprite_acc AS shoprite_acc,
  a.chain_id1 AS chain_id1,
  a.chain_id2 AS chain_id2,
  dba_name AS dba_name,
  coalesce(p.merch_mcc,dev.mcc) AS mcc,        ----- [*]230609.1 = angajalak = PRD-24209
  c.device_status AS device_status,
  c.merch_status AS merch_status,
  c.shoprite_status AS shoprite_status,
  c.merch_date_open AS merch_date_open,
  NVL(TO_CHAR(attr.date_close,'yyyymmdd'),'00000000') AS date_close,
  attr.block_code AS block_code,
  ca.contract_idt AS contract_idt,
  ca.address_line_1 AS address_line_1,
  ca.address_line_2 AS address_line_2,
  ca.address_line_3 AS address_line_3,
  ca.address_line_4 AS address_line_4,
  ca.city AS city,
  ca.state AS state_1,
  ca.country AS country,
  ca.address_zip AS address_zip,
  ca.first_name AS first_name,
  ca.phone AS phone,
  ca.fax AS fax,
  ca.e_mail AS e_mail,
  ca.CBK_first_name as CBK_first_name,
  ctf.TRNS_FEE AS TRNS_FEE,
  ctf.TERM_RNTL_FEE AS TERM_RNTL_FEE,
  ctf.ACQ_MEM AS ACQ_MEM,
  ctf.contract_idt AS trf_contract_idt,
  ctf.SIM_FEE AS SIM_FEE,
  ctf.CHRGBCK_FEE AS CHRGBCK_FEE,
  ctf.STARTUP_FEE AS STARTUP_FEE,
  ctf.FRAUD_FEE AS FRAUD_FEE,
  ctf.STMT_FEE AS STMT_FEE,
  ctf.GPRS_FEE AS GPRS_FEE,
  ctf.INS_FEE AS INS_FEE,
  SUBSTR(c.merch_add_info, instr(c.merch_add_info, 'CREDITACCT=')+11, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'CREDITACCT='))-instr(c.merch_add_info, 'CREDITACCT=')-11)) AS creditacc,
  SUBSTR(c.merch_add_info, instr(c.merch_add_info, 'DEBITACCT=')+10, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'DEBITACCT='))-instr(c.merch_add_info, 'DEBITACCT=')-10)) AS debitacc,
  c.merch_currency AS merch_currency,
  DECODE(c.type,'C',' ',COALESCE(attr.acpt_visa,'N')) acpt_visa,
  DECODE(c.type,'C',' ',COALESCE(attr.acpt_mc,'N')) acpt_mc,
  DECODE(c.type,'C',' ',COALESCE(attr.acpt_dci,'N')) acpt_dci,
  DECODE(c.type,'C',' ',COALESCE(attr.acpt_jcb,'N')) acpt_jcb,
  DECODE(c.type,'C',' ',COALESCE(attr.acpt_cup,'N')) acpt_cup,
  DECODE(c.type,'C',' ',COALESCE(attr.acpt_amex,'N')) acpt_amex,
  DECODE(c.type,'C',' ',COALESCE(attr.acpt_mq,'N')) acpt_mq,
  DECODE(c.type,'C',' ',SUBSTR(c.merch_add_info, instr(c.merch_add_info, 'MERCHANT_BILLING=')+17, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'MERCHANT_BILLING='))-instr(c.merch_add_info, 'MERCHANT_BILLING=')-17))) merch_bill_tag,
  SUBSTR(c.merch_add_info, instr(c.merch_add_info, 'DAY02=')+6, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'DAY02='))-instr(c.merch_add_info, 'DAY02=')-6)) day02_tag,
  attr.comm_sttl AS comm_sttl,
  to_char(to_date(sy_convert.get_tag_value(c.merch_add_info,'LST_CHRG_MRCHMF'),'YYYY-MM-DD HH24:MI:SS'),'YYYYMMDD') AS LST_CHRG_MRCHMF,
  REPLACE(sy_convert.get_tag_value(c.merch_add_info,'VISA'),'VISA_') visa_tag,
  REPLACE(sy_convert.get_tag_value(c.merch_add_info,'VPR'),'VPR_') vpr_tag,
  REPLACE(sy_convert.get_tag_value(c.merch_add_info,'VPI'),'VPI_') vpi_tag,
  REPLACE(sy_convert.get_tag_value(c.merch_add_info,'MC'),'MC_') mc_tag,
  REPLACE(sy_convert.get_tag_value(c.merch_add_info,'MPR'),'MPR_') mpr_tag,
  REPLACE(sy_convert.get_tag_value(c.merch_add_info,'MPI'),'MPI_') mpi_tag,
  REPLACE(sy_convert.get_tag_value(c.merch_add_info,'JCB'),'JCB_') jcb_tag,
  REPLACE(sy_convert.get_tag_value(c.merch_add_info,'DCI'),'DCI_') dci_tag,
  REPLACE(sy_convert.get_tag_value(c.merch_add_info,'CUP'),'CUP_') upi_tag,
  REPLACE(sy_convert.get_tag_value(c.merch_add_info,'MER'),'MER_') mer_tag,

  case
  when REPLACE(sy_convert.get_tag_value(c.merch_add_info,'VISA'),'VISA_') is null then ' '                  ----- [+][begin] 230601.3 = angajalak = ADCBA-1376
  else 'VISA_' || REPLACE(sy_convert.get_tag_value(c.merch_add_info,'VISA'),'VISA_') end as visa_tag_1,
  case
  when REPLACE(sy_convert.get_tag_value(c.merch_add_info,'VPR'),'VPR_') is null then ' '
  else 'VPR_' || REPLACE(sy_convert.get_tag_value(c.merch_add_info,'VPR'),'VPR_') end as vpr_tag_1,
  case
  when REPLACE(sy_convert.get_tag_value(c.merch_add_info,'VPI'),'VPI_') is null then ' '
  else 'VPI_' || REPLACE(sy_convert.get_tag_value(c.merch_add_info,'VPI'),'VPI_') end as vpi_tag_1,
  case
  when REPLACE(sy_convert.get_tag_value(c.merch_add_info,'MC'),'MC_') is null then ' '
  else 'MC_' || REPLACE(sy_convert.get_tag_value(c.merch_add_info,'MC'),'MC_') end as mc_tag_1,
  case
  when REPLACE(sy_convert.get_tag_value(c.merch_add_info,'MPR'),'MPR_') is null then ' '
  else 'MPR_' || REPLACE(sy_convert.get_tag_value(c.merch_add_info,'MPR'),'MPR_') end as mpr_tag_1,
  case
  when REPLACE(sy_convert.get_tag_value(c.merch_add_info,'MPI'),'MPI_') is null then ' '
  else 'MPI_' || REPLACE(sy_convert.get_tag_value(c.merch_add_info,'MPI'),'MPI_') end as mpi_tag_1,
  case
  when REPLACE(sy_convert.get_tag_value(c.merch_add_info,'JCB'),'JCB_') is null then ' '
  else 'JCB_' || REPLACE(sy_convert.get_tag_value(c.merch_add_info,'JCB'),'JCB_') end as jcb_tag_1,
  case
  when REPLACE(sy_convert.get_tag_value(c.merch_add_info,'DCI'),'DCI_') is null then ' '
  else 'DCI_' || REPLACE(sy_convert.get_tag_value(c.merch_add_info,'DCI'),'DCI_') end as dci_tag_1,
  case
  when REPLACE(sy_convert.get_tag_value(c.merch_add_info,'CUP'),'CUP_') is null then ' '
  else 'CUP_' || REPLACE(sy_convert.get_tag_value(c.merch_add_info,'CUP'),'CUP_') end as upi_tag_1,
  case
  when REPLACE(sy_convert.get_tag_value(c.merch_add_info,'MER'),'MER_') is null then ' '
  else 'MER_' || REPLACE(sy_convert.get_tag_value(c.merch_add_info,'MER'),'MER_') end as mer_tag_1,      ----- [+][end] 230601.3 = angajalak = ADCBA-1376

  SUBSTR(c.merch_add_info, instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_01=')+21, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_01='))-instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_01=')-21)) risk_class_tag,
  SUBSTR(c.merch_add_info, instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_03=')+21, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_03='))-instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_03=')-21)) collaterals_tag,
  SUBSTR(c.merch_add_info, instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_04=')+21, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_04='))-instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_04=')-21)) rm_name_tag,
  SUBSTR(c.merch_add_info, instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_05=')+21, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_05='))-instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_05=')-21)) custom_1_tag,
  SUBSTR(c.merch_add_info, instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_06=')+21, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_06='))-instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_06=')-21)) custom_2_tag,
  SUBSTR(c.merch_add_info, instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_07=')+21, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_07='))-instr(c.merch_add_info, 'ACQ_ACNT_ADD_INFO_07=')-21)) custom_3_tag,
  attr.misc_sttl AS misc_sttl,
  NVL(attr.mmf, 'N') mmf,
  SUBSTR(SUBSTR(c.merch_add_info, instr(c.merch_add_info, 'ROUT_CODE=')+10, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'ROUT_CODE='))-instr(c.merch_add_info, 'ROUT_CODE=')-10)),1,15) rout_code_tag,
  coalesce(p.mcc_amid_tag, SUBSTR(dev.add_info, instr(dev.add_info, 'AMEX_ID=')+8, (instr(dev.add_info, ';', instr(dev.add_info, 'AMEX_ID='))-instr(dev.add_info, 'AMEX_ID=')-8))) amid_tag,   ----- [*]230609.1 = angajalak = PRD-24209
  c.type AS type_1,
  NVL(attr.dcc_type, 'ND') dcc_type,
  NVL(attr.vatcom_flag, 'Y') vatcom_flag,
  NVL(attr.vatfee_flag, 'Y') vatfee_flag,
  SUBSTR(c.merch_add_info, instr(c.merch_add_info, 'VATREG=')+7, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'VATREG='))-instr(c.merch_add_info, 'VATREG=')-7)) vat_reg,
  NVL(pers.acq_vat_rate, st.acq_vat_rate) vat_rate,
  DECODE(attr.dcc_type, 'PP', 'Y', 'N') AS dcc_enabled,
  NVL(pers.acq_dcc_mrk, st.acq_dcc_mrk) dcc_mrk,
  NVL(pers.acq_dcc_rev, st.acq_dcc_rev) dcc_merch_perc,
  NVL(replace(SUBSTR(c.merch_add_info, instr(c.merch_add_info, ';MER=')+5, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'MER='))-instr(c.merch_add_info, ';MER=')-5)),'MER_'),'') MER,
  NVL(replace(SUBSTR(c.merch_add_info, instr(c.merch_add_info, ';QPR=')+5, (instr(c.merch_add_info, ';', instr(c.merch_add_info, 'QPR='))-instr(c.merch_add_info, ';QPR=')-5)), 'QPR_'),'') QPR,

  NVL(st.VIDOMPRDBMNL_FEE, '')  AS TR_VDPDMNL_FEE,
  NVL(st.VIDOMPRDBELEC_FEE, '') AS TR_VDPDELEC_FEE,
  NVL(st.MCDOMPRDBMNL_FEE, '')  AS TR_MCDPDMNL_FEE,
  NVL(st.MCDOMPRDBELEC_FEE, '') AS TR_MCDPDELEC_FEE,
  NVL(st.VIDOMSTDBMNL_FEE, '')  AS TR_VDSDMNL_FEE,
  NVL(st.VIDOMSTDBELEC_FEE, '') AS TR_VDSDELEC_FEE,
  NVL(st.MCDOMSTDBMNL_FEE, '')  AS TR_MCDSDMNL_FEE,
  NVL(st.MCDOMSTDBELEC_FEE, '') AS TR_MCDSDELEC_FEE,
  NVL(st.CUPDOMSTDBMNL_FEE, '') AS TR_UPIDSDMNL_FEE,
  NVL(st.CUPDOMSTDBELEC_FEE, '')    AS TR_UPIDSDELEC_FEE

FROM acq_contracts c
LEFT JOIN dwd_device dev
ON dev.record_idt = c.device_idt
AND to_date(:P_BANK_DATE,'DD-MM-YYYY') BETWEEN dev.record_date_from AND dev.record_date_to
LEFT JOIN affiliated_clients a
ON a.contract_idt = c.merch_id
LEFT JOIN ctr_attributes attr
ON attr.contract_idt = c.merch_id
LEFT JOIN other_tariffs st
ON st.contract_idt = c.device_idt
Left JOIN cntr_addr ca
ON ca.contract_idt = c.merch_id
Left JOIN cntr_tariff ctf
ON ctf.contract_idt = c.device_idt
LEFT JOIN pers_tariffs pers
ON pers.contract_number = c.merch_acc
LEFT JOIN (SELECT                               ----- [+][begin] 230609.1 = angajalak = PRD-24209
			dvc.main_contract_idt,
            MAX(dvc.mcc) as merch_mcc,
			MAX(SUBSTR(dvc.add_info, instr(dvc.add_info, 'AMEX_ID=')+8, (instr(dvc.add_info, ';', instr(dvc.add_info, 'AMEX_ID='))-instr(dvc.add_info, 'AMEX_ID=')-8))) mcc_amid_tag
        FROM
            dwh.dwd_device dvc
        WHERE
                dvc.record_state = 'A' 
		group by dvc.main_contract_idt) p
ON p.main_contract_idt = c.merch_id              ----- [+][end] 230609.1 = angajalak = PRD-24209
ORDER BY c.root,
  c.merch_acc nulls last,
  c.c_order)


  select
:ORG AS ORG,
 lpad(rownum,9,'0') || DUMPP AS DUMPP
from(

select
  'FH0MM0001'|| to_char(sysdate,'ddMMyyyy')||to_char(sysdate,'HHMM')||'PRO160' as DUMPP from dual
union all
select
'BH'||rpad(n.name,4,' ')||'9999999999999999999999999999' as DUMPP from v_dwr_institution n
WHERE n.code          = :ORG
    AND n.class_code    = 'ACQ_REPORTS'
    AND n.type_code     = 'FI_NAME'
union all
select
        *
        from
        (
            select
            DUMPP
            from
            (
                select
                rpad(nvl(replace(type_1,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(org,CHR(13),''),' '),4,' ')
                ||
                 rpad(nvl(replace(device_number,CHR(13),''), ' '),15,' ')
                ||
                rpad(nvl(replace(merch_acc,CHR(13),''),' '),15,' ')
                ||
                 rpad(nvl(replace(shoprite_acc,CHR(13),''),' '),15,' ')
                ||
                 rpad(nvl(replace(chain_id1,CHR(13),''),' '),15,' ')
                ||
                 rpad(nvl(replace(chain_id2,CHR(13),''),' '),15,' ')
                ||
                 rpad(nvl(replace(dba_name,CHR(13),''),' '),40,' ')
                ||
                 rpad(nvl(replace(mcc,CHR(13),''),' '),4,' ')
                ||
                 rpad(nvl(replace(address_line_1,CHR(13),''),' '),40,' ')
                ||
                 rpad(nvl(replace(address_line_2,CHR(13),''),' '),40,' ')
                ||
                 rpad(nvl(replace(address_line_3,CHR(13),''),' '),40,' ')
                ||
                 rpad(nvl(replace(address_line_4,CHR(13),''),' '),40,' ')
                ||
                 rpad(nvl(replace(city,CHR(13),''),' '),30,' ')
                ||
                 rpad(nvl(replace(state_1,CHR(13),''),' '),3,' ')
                ||
                 rpad(nvl(replace(country,CHR(13),''),' '),3,' ')
                ||
                 rpad(nvl(replace(address_zip,CHR(13),''),' '),16,' ')
                ||
                 rpad(nvl(replace(first_name,CHR(13),''),' '),40,' ')
                ||
                 rpad(nvl(replace(phone,CHR(13),''),' '),20,' ')
                ||
                 rpad(nvl(replace(fax,CHR(13),''),' '),20,' ')
                ||
                 rpad(nvl(replace(e_mail,CHR(13),''),' '),40,' ')
                ||
                 rpad(nvl(replace(device_status,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(merch_status,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(shoprite_status,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(merch_date_open,CHR(13),''),' '),8,' ')
                ||
                 rpad(nvl(replace(date_close,CHR(13),''),' '),8,' ')
                ||
                 rpad(nvl(replace(block_code,CHR(13),''),' '),2,' ')
                ||
                 rpad(nvl(replace(creditacc,CHR(13),''),' '),25,' ')
                ||
                 rpad(nvl(replace(debitacc,CHR(13),''),' '),25,' ')
                ||
                 rpad(nvl(replace(merch_currency,CHR(13),''),' '),3,' ')
                ||
                 rpad(nvl(replace(acpt_visa,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(acpt_mc,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(acpt_dci,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(acpt_jcb,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(acpt_cup,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(acpt_amex,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(acpt_mq,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(merch_bill_tag,CHR(13),''),' '),2,' ')
                ||
                 rpad(nvl(replace(decode(comm_sttl, 'M1' , 'M' , 'D'),CHR(13),''),' '),2,' ')
                ||
                 rpad(nvl(replace(rout_code_tag,CHR(13),''),' '),10,' ')
                ||
                 rpad(nvl(replace(amid_tag,CHR(13),''),' '),15,' ')
                ||
                 rpad(nvl(replace(risk_class_tag,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(collaterals_tag,CHR(13),''),' '),5,' ')
                ||
                 rpad(nvl(replace(rm_name_tag,CHR(13),''),' '),30,' ')
                ||
                 rpad(nvl(replace(custom_1_tag,CHR(13),''),' '),10,' ')
                ||
                 rpad(nvl(replace(custom_2_tag,CHR(13),''),' '),10,' ')
                ||
                 rpad(nvl(replace(custom_3_tag,CHR(13),''),' '),10,' ')
                ||
                 rpad(nvl(replace(dcc_enabled,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(to_char(dcc_mrk,'FM999999990D00'),CHR(13),''),'0.00'),4,'0.00')
                ||
                 rpad(nvl(replace(to_char(dcc_merch_perc,'FM999999990D00'),CHR(13),''),'0.00'),4,'0.00')
                ||
                 rpad(nvl(replace(visa_tag || vpr_tag || vpi_tag,CHR(13),''),' '),200,' ')
                ||
                 rpad(nvl(replace(mc_tag || mpr_tag || mpi_tag,CHR(13),''),' '), 200,' ')
                ||
                 rpad(nvl(replace(jcb_tag,CHR(13),''),' '),100,' ')
                ||
                 rpad(nvl(replace(dci_tag,CHR(13),''),' '),100,' ')
                ||
                 rpad(nvl(replace(upi_tag,CHR(13),''),' '),100,' ')
                ||
                 rpad(nvl(replace(MER||QPR,CHR(13),''),' '),100,' ')
                ||
                 rpad(nvl(replace(to_char(TR_VDPDMNL_FEE),CHR(13),'') || ',' ||replace(to_char(TR_VDPDELEC_FEE),CHR(13),'')|| ',' ||replace(to_char(TR_MCDPDMNL_FEE),CHR(13),'')|| ','||replace(to_char(TR_MCDPDELEC_FEE),CHR(13),'')|| ',' ||replace(to_char(TR_VDSDMNL_FEE),CHR(13),'')|| ','||replace(to_char(TR_VDSDELEC_FEE),CHR(13),'')|| ','||replace(to_char(TR_MCDSDMNL_FEE),CHR(13),'')|| ','||replace(to_char(TR_MCDSDELEC_FEE),CHR(13),'')|| ','||replace(to_char(TR_UPIDSDMNL_FEE),CHR(13),'')|| ','||replace(to_char(TR_UPIDSDELEC_FEE),CHR(13),''),' '),100,' ')
                ||
                 rpad(' ', 100,' ')
                ||
                 rpad(nvl(replace(vat_reg,CHR(13),''),' '),20,' ')
                ||
                 lpad(nvl(replace(to_char(vat_rate,'FM999999990D00'),CHR(13),''),'0.00'),5,'0')
                ||
                 rpad(nvl(replace(vatfee_flag,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(vatcom_flag,CHR(13),''),' '),1,' ')
                ||
                 rpad(' ',73,' ')
                ||
                 rpad(nvl(replace(TRNS_FEE,CHR(13),''),'0000.00'),7,' ')
                ||
                 rpad(nvl(replace(STMT_FEE,CHR(13),''),'0000.00'),7,' ')
                ||
                 rpad(nvl(replace(TERM_RNTL_FEE,CHR(13),''),'0000.00'),7,' ')
                ||
                 rpad(' ',2,' ')
                ||
                 rpad(nvl(replace(ACQ_MEM,CHR(13),''),'0000.00'),7,' ')
                ||
                 rpad(nvl(replace(mmf,CHR(13),''),' '),2,' ')
                ||
                 rpad(nvl(replace(TERM_RNTL_FEE,CHR(13),''),'0000.00'),7,' ')
                ||
                 rpad(nvl(replace(SIM_FEE,CHR(13),''),'0000.00'),7,' ')
                ||
                 rpad(nvl(replace(CHRGBCK_FEE,CHR(13),''),'0000.00'),7,' ')
                ||
                 rpad(nvl(replace(STARTUP_FEE,CHR(13),''),'0000.00'),7,' ')
                ||
                 rpad(nvl(replace(FRAUD_FEE,CHR(13),''),'0000.00'),7,' ')
                ||
                 rpad(nvl(replace(GPRS_FEE,CHR(13),''),'0000.00'),7,' ')
                ||
                 rpad(nvl(replace(dcc_type,CHR(13),''),' '),25,' ')
                ||
                 rpad(nvl(replace(visa_tag_1,CHR(13),''),' '),20,' ')                ----- [*][begin] 230601.3 = angajalak = ADCBA-1376
                ||
                 rpad(nvl(replace(vpr_tag_1,CHR(13),''),' '),20,' ')
                ||
                 rpad(nvl(replace(vpi_tag_1,CHR(13),''),' '),20,' ')
                ||
                 rpad(nvl(replace(mc_tag_1,CHR(13),''),' '),20,' ')
                ||
                 rpad(nvl(replace(mpr_tag_1,CHR(13),''),' '),20,' ')
                ||
                 rpad(nvl(replace(mpi_tag_1,CHR(13),''),' '),20,' ')
                ||
                 rpad(nvl(replace(dci_tag_1,CHR(13),''),' '),20,' ')
                ||
                 rpad(nvl(replace(jcb_tag_1,CHR(13),''),' '),20,' ')
                ||
                 rpad(nvl(replace(upi_tag_1,CHR(13),''),' '),20,' ')
                ||
                 rpad(nvl(replace(mer_tag_1,CHR(13),''),' '),20,' ')                ----- [*][end] 230601.3 = angajalak = ADCBA-1376
                ||
                 rpad(nvl(replace(to_char(dcc_merch_perc,'FM999999990D09'),CHR(13),''),' '),4,' ')
                ||
                 rpad(nvl(replace(dcc_type,CHR(13),''),' '),1,' ')
                ||
                 rpad(nvl(replace(chain_id1,CHR(13),''),' '),12,' ')
                ||
                 rpad(nvl(replace(chain_id2,CHR(13),''),' '),12,' ')
                ||
                 rpad(nvl(replace(vat_reg,CHR(13),''),' '),15,' ')
                ||
                 rpad(nvl(replace(e_mail,CHR(13),''),' '),40,' ')
                ||
                 rpad(nvl(replace(first_name,CHR(13),''),' '),40,' ')
                ||
                 rpad(nvl(replace(LST_CHRG_MRCHMF,CHR(13),''),' '),8,' ')
                ||
                rpad(nvl(replace(to_char(TR_VDSDELEC_FEE),CHR(13),''),' '),5,' ')
                ||
                 rpad(nvl(replace(to_char(TR_VDSDMNL_FEE),CHR(13),''),' '),5,' ')
                ||
                 rpad(nvl(replace(to_char(TR_VDPDELEC_FEE),CHR(13),''),' '),5,' ')
                ||
                 rpad(nvl(replace(to_char(TR_VDPDMNL_FEE),CHR(13),''),' '),5,' ')
                ||
                 rpad(nvl(replace(to_char(TR_MCDSDELEC_FEE),CHR(13),''),' '),5,' ')
                ||
                 rpad(nvl(replace(to_char(TR_MCDSDMNL_FEE),CHR(13),''),' '),5,' ')
                ||
                 rpad(nvl(replace(to_char(TR_MCDPDELEC_FEE),CHR(13),''),' '),5,' ')
                ||
                 rpad(nvl(replace(to_char(TR_MCDPDMNL_FEE),CHR(13),''),' '),5,' ')
                ||
                 rpad(nvl(replace(CBK_first_name,CHR(13),''),' '),40,' ')
                ||
                 rpad(' ',439,' ')  DUMPP
                 from all_contrs
                 ))
union all
select
        'BT'||lpad(count(1),20,'0') as DUMPP from all_contrs
union all
select
       'FT'||'0000000'||lpad(count(1),9,'0')||'0'|| to_char(sysdate,'ddMMyyyy')||to_char(sysdate,'HHMM') as DUMPP
from all_contrs
)