/*
* CODE FOR AQ_ALIPAY_RTA_EXTRACT
* PYTL_IS_SIMPLEREPORTS_AQ_ALIPAY_RTA_EXTRACT = AQ_ALIPAY_RTA_EXTRACT.SQL
* VERSION HISTORY:
* 230512.1 : NIBOA-8424 : PADALAS  : INITIAL DEVELOPMENT
* 230515.1 : NIBOA-8424 : PADALAS  : UPDATED CODE TO FETCH RTA MERCHANTS
* 230515.2 : NIBOA-8424 : NIBOA-8486 : PADALAS  : UPDATED CODE TO FETCH RTA MERCHANTS
* 230517.1 : NIBOA-8424 : Tunned SQL code for better performance
* 230626.1 : NIBOA-8609 : Addition of filter RTA_MERCH_CODE = 'Y', to fetch RTA merchant only
*/WITH inst AS (
    SELECT
    /*+ no_merge */
        id
    FROM
        dwd_institution
    WHERE
            record_state = 'A'
        AND code = :ORG
), oper AS (
    SELECT
     /*+ materialize */
        op.operation_type_id,
        op.name,
        op.code,
        op.purpose,
        CASE
            WHEN nvl(tot.type_total, '') = 'TOTAL_TRANSACTIONS' THEN
                'TRAN'
            WHEN op.code = 'VAT'                                THEN
                'VAT'
            WHEN instr(op.purpose, ',VAT_ON_FEE,') > 0          THEN
                'VAT'
            WHEN instr(op.purpose, ',TRANS_FEE,') > 0           THEN
                'TRANS_FEE'
            WHEN instr(op.purpose, ',COMM,') > 0                THEN
                'COMM'
            WHEN instr(op.purpose, ',REBATE,') > 0              THEN
                'REBATE'
        END AS type,
        CASE
            WHEN op.code IN ( 'RETAIL', 'REFUND_REV', 'CASH', 'XLS_REV', 'XLS_SALE',
                              'CASHBACK', 'QR_SALE', 'QR_REFUND_REV' ) THEN
                'SALE'
            WHEN op.code IN ( 'CASH_REV', 'CASHBACK_REV', 'QR_SALE_REV' ) THEN
                'SALE REV'
            WHEN op.code IN ( 'XLS_FUND', 'XLS_REFUND', 'QR_REFUND' ) THEN
                'REFUND'
            ELSE
                replace(replace(replace(replace(replace(replace(op.name, 'MANL', 'M'), 'CHBK', 'C'), 'DCC REFUND', 'DCC REF'), '-SALE',
                ''), 'REFUNDS', 'REFUND'), 'SALES', 'SALE')
        END AS new_name
    FROM
        (
            SELECT
       /*+ no_merge */
                op.operation_type_id       AS operation_type_id,
                op.operation_type_code     AS operation_type_code,
                op.code                    AS code,
                ','
                ||
                LISTAGG(op.type_code, ',') WITHIN GROUP(
                    ORDER BY
                        op.type_code
                    )
                || ','                     AS purpose,
                nvl(MIN(op.name), op.code) AS name
            FROM
                (
                    SELECT
                        op.operation_type_id,
                        op.operation_type_code,
                        op.name,
                        op.code,
                        op.sort_order,
                        op.type_code
                    FROM
                        v_dwr_operation_type op
                    WHERE
                        op.class_code = 'ACQ_SETTLEMENT_REPORT'
                ) op
            GROUP BY
                op.operation_type_id,
                op.operation_type_code,
                op.code
        ) op
        LEFT JOIN (
            SELECT
       /*+ no_merge */
                operation_type_id AS operation_type_id,
                code              AS type_total
            FROM
                v_dwr_operation_type
            WHERE
                    class_code = 'ACQ_REPORTS'
                AND type_code = 'DA_TOTALS'
        ) tot ON tot.operation_type_id = op.operation_type_id
    WHERE
        nvl(tot.type_total, '') = 'TOTAL_TRANSACTIONS'
        OR instr(op.purpose, ',COMM_CODE,') > 0
), trans_entr AS (
    SELECT
        /*+no_merge index(e DWF_ACCOUNT_ENTRY_DOC_IDX) use_hash(i) swap_join_inputs(i) pq_distribute(i none broadcast) use_hash(oper) swap_join_inputs(oper) pq_distribute(oper none broadcast)*/
        op.new_name,
        op.code,
        round(e.credit - e.debit, 2) AS amnt,
        e.primary_doc_idt,
        e.fee_rate_value,
        e.contract_idt,
        e.tariff_idt
    FROM
             inst i
        JOIN dwf_account_entry e ON i.id = e.institution_id
        JOIN (
            SELECT /*+no_merge*/
                operation_type_id,
                new_name,
                code
            FROM
                oper op
            WHERE
                op.type = 'TRAN'
        )                 op ON op.operation_type_id = e.operation_type_id
    WHERE
        e.banking_date BETWEEN decode(:P_REPORT_TYPE, 'D', to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'W', to_date(:P_REPORT_DATE, 'DD-MM-YYYY') -
        7, 'M', add_months(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), - 1) + 1) AND to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
), addr AS (
    SELECT
         /*+no_merge full(merch_addr) use_hash(inst) swap_join_inputs(inst) pq_distribute(inst none broadcast) use_hash(adr) swap_join_inputs(adr) pq_distribute(merch_addr broadcast none)*/
        coalesce(merch_addr.address_line_2, 'NA')                                        AS location,
        coalesce(merch_addr.phone, merch_addr.phone_home, merch_addr.phone_mobile, 'NA') AS telephone,
        merch_addr.contract_idt                                                          AS contract_idt,
        merch_addr.address_line_1                                                        AS merch_name,
        merch_addr.e_mail                                                                AS email,
        merch_addr.state,
        adr.code
    FROM
             dwd_contract_address merch_addr
        JOIN (
            SELECT /*+no_merge*/
                id
            FROM
                inst
        ) inst ON inst.id = merch_addr.institution_id
        JOIN (
            SELECT /*+no_merge*/
                id,
                code
            FROM
                dwd_address_type adr
            WHERE
                adr.code IN ( 'STMT_ADDR', 'PST_ADDR' )
                AND adr.record_state = 'A'
        ) adr ON merch_addr.address_type_id = adr.id
    WHERE
        to_date(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN merch_addr.record_date_from AND merch_addr.record_date_to
        AND merch_addr.record_state != 'C'
), chains AS (
    SELECT
    /*+ NO_MERGE use_hash(dft) swap_join_inputs(dft) pq_distribute(dach broadcast none) use_hash(inst) swap_join_inputs(inst) pq_distribute(inst none broadcast)*/
        dach.contract_idt,
        dc.ident_number                                                                                                                                                                        AS
        chainid_1,
        substr(dc.add_info, instr(dc.add_info, 'CHAIN_GROUPS_CODE=') + 18,(instr(dc.add_info, ';', instr(dc.add_info, 'CHAIN_GROUPS_CODE=')) -
        instr(dc.add_info, 'CHAIN_GROUPS_CODE=') - 18)) AS gc_chain1
    FROM
             dwd_affiliation dach
        JOIN (
            SELECT 
                  /*+no_merge*/
                dft.id
            FROM
                dwd_affiliation_type dft
            WHERE
                dft.code IN ( 'CHAINID_1' )
                AND dft.record_state != 'C'
                AND to_date(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN dft.record_date_from AND dft.record_date_to
        )          dft ON dach.affiliation_type_id = dft.id
        JOIN dwd_client dc ON dc.record_idt = dach.affiliated_client_idt
                              AND dc.record_state != 'C'
                              AND to_date(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN dc.record_date_from AND dc.record_date_to
        JOIN inst ON inst.id = dc.institution_id
    WHERE
            dach.record_state != 'C'
        AND to_date(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN dach.record_date_from AND dach.record_date_to
), itar AS (
    SELECT
    /*+ materialize*/
        st.fee_rate_value AS vat_rate
    FROM
             dwd_tariff t
        JOIN dwd_service_tariff st ON st.record_idt = t.record_idt
                                      AND st.record_state != 'C'
                                      AND to_date(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN t.record_date_from AND t.record_date_to
                                      AND to_date(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN st.record_date_from AND st.record_date_to
    WHERE
            t.record_state != 'C'
        AND t.type_code = 'ACQ_VAT_RATE'
        AND t.role = 'SERVICE'
        AND substr(t.domain, 0, instr(t.domain, '-') - 1) = :ORG
), cattr AS (
    SELECT /*+ no_merge use_hash(attr) swap_join_inputs(attr) pq_distribute(attr none broadcast)*/
        cattr.contract_idt,
        attr.code,
        attr.type_code
    FROM
             dwa_contract_attribute cattr
        JOIN dwd_attribute attr ON attr.id = cattr.attr_id
                                   AND to_date(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN attr.record_date_from AND attr.record_date_to
                                   AND attr.type_code IN ( 'ACQ_LVL', 'ACQ_RTA_MERCH' )
                                   AND attr.record_state != 'C'
    WHERE
        to_date(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN cattr.attr_date_from AND cattr.attr_date_to
        AND cattr.active_state = 'A'
), cntr AS (
    SELECT
                /*+ NO_MERGE leading(dca cntr) use_hash(cntr) use_hash(inst) swap_join_inputs(inst) pq_distribute(inst none broadcast) use_hash(itar) swap_join_inputs(itar) pq_distribute(itar none broadcast) 
                    use_hash(dca) swap_join_inputs(dca) pq_distribute(cntr hash hash)  use_hash(rta_merch) swap_join_inputs(rta_merch) use_hash(chains) swap_join_inputs(chains)
                    use_hash(merch_addr) swap_join_inputs(merch_addr)
                */
        cntr.personal_account    AS personal_account,
        cntr.record_idt          AS record_idt,
        cntr.parent_contract_idt AS parent_contract_idt,
        dca.code                 AS code,
        dca.type_code            AS type_code,
        chains.chainid_1         AS master_chain1,
        merch_addr.merch_name    AS merchant_name,
        merch_addr.location      AS location,
        merch_addr.telephone     AS telephone,
        merch_addr.email         AS email,
        (
            SELECT /*+no_merge*/
                vat_rate
            FROM
                itar
        )                        AS vat_rate,
        rta_merch.code           AS rta_merch
    FROM
             dwd_contract cntr
        JOIN inst ON inst.id = cntr.institution_id
        JOIN (
            SELECT 
                        /*+no_merge*/
                code,
                type_code,
                contract_idt
            FROM
                cattr dca
            WHERE
                dca.code IN ( 'DEVICE', 'MERCHANT' )
        )     dca ON cntr.record_idt = dca.contract_idt
        LEFT JOIN cattr rta_merch ON rta_merch.contract_idt = cntr.record_idt
                                     AND rta_merch.type_code = 'ACQ_RTA_MERCH'
        LEFT JOIN chains ON cntr.record_idt = chains.contract_idt
        LEFT JOIN addr  merch_addr ON merch_addr.contract_idt = cntr.record_idt
                                     AND merch_addr.code = 'STMT_ADDR'
    WHERE
        to_date(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN cntr.record_date_from AND cntr.record_date_to
        AND cntr.record_state != 'C'
), tr_sales AS (
    SELECT
        /*+NO_MERG*/
        t.trans_rrn,
        t.auth_code,
        t.source_contract_idt,
        t.target_number
    FROM
        (
            SELECT /*+ NO_MERGE full(t) use_hash(tt2) swap_join_inputs(tt2) pq_distribute(t broadcast none) use_hash(i2) swap_join_inputs(i2) pq_distribute(i2 none broadcast)*/
                t.trans_rrn,
                t.auth_code,
                t.source_contract_idt,
                t.target_number,
                DENSE_RANK()
                OVER(PARTITION BY t.auth_code, t.source_contract_idt, t.target_number
                     ORDER BY
                         t.banking_date DESC, t.trans_rrn DESC, t.doc_idt DESC
                ) AS rn
            FROM
                     dwf_transaction t
                JOIN (
                    SELECT /*+no_merge*/
                        id
                    FROM
                        dwd_transaction_type tt2
                    WHERE
                            tt2.record_state = 'A'
                        AND to_date(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN tt2.record_date_from AND tt2.record_date_to
                        AND tt2.code IN ( 'R1-P', 'U1-P', 'DCCR1-P', 'K1-R', 'DCCK1-R' )
                )    tt2 ON tt2.id = t.transaction_type_id
                JOIN inst i2 ON i2.id = t.institution_id
            WHERE
                t.banking_date BETWEEN decode(:P_REPORT_TYPE, 'D', to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'W', to_date(:P_REPORT_DATE,
                'DD-MM-YYYY') - 7, 'M', add_months(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), - 1) + 1) AND to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        ) t
    WHERE
        rn = 1
), tr AS (
    SELECT
        /*+ materialize */
        tr.doc_idt,
        tr.trans_currency,
        tr.settl_currency,
        tr.card_brand_id,
        tr.trans_conditions_id,
        trans_rrn,
        tr.trans_arn,
        tr.trans_date,
        tr.settl_amount,
        tr.banking_date,
        tr.auth_code,
        tr.source_number,
        tr.target_number,
        tr.source_contract_idt,
        replace(replace(substr(tr.add_info, instr(tr.add_info, 'RI_TIP_AMOUNT=') + 14,(instr(tr.add_info, ';', instr(tr.add_info, 'RI_TIP_AMOUNT=')) -
        instr(tr.add_info, 'RI_TIP_AMOUNT=') - 14)), CHR(10)), CHR(13)) AS tip_amount,
        replace(replace(substr(tr.add_info, instr(tr.add_info, 'RI_TAG_ID=') + 10,(instr(tr.add_info, ';', instr(tr.add_info, 'RI_TAG_ID=')) -
        instr(tr.add_info, 'RI_TAG_ID=') - 10)), CHR(10)), CHR(13))             AS tag_id,
        replace(replace(substr(tr.add_info, instr(tr.add_info, 'DRIVER_ID=') + 10,(instr(tr.add_info, ';', instr(tr.add_info, 'DRIVER_ID=')) -
        instr(tr.add_info, 'DRIVER_ID=') - 10)), CHR(10)), CHR(13))             AS driver_id,
        nvl(substr(tr.add_info, instr(tr.add_info, 'DOMESTIC=') + 9,(instr(tr.add_info, ';', instr(tr.add_info, 'DOMESTIC=')) - instr(
        tr.add_info, 'DOMESTIC=') - 9)), 'N')                                            AS domestic,
        substr(tr.add_info, instr(tr.add_info, 'ORDER_ID=') + 9,(instr(tr.add_info, ';', instr(tr.add_info, 'ORDER_ID=')) - instr(tr.
        add_info, 'ORDER_ID=') - 9))                                                      AS order_id,
        CASE
            WHEN instr(tr.add_info, 'QR_TRAN=Y;') > 0 THEN
                'Y'
            ELSE
                'N'
        END                                                                                                                                                                                                            AS
        qr_enabled,
        substr(tr.add_info, instr(tr.add_info, 'DOMESTIC=') + 9,(instr(tr.add_info, ';', instr(tr.add_info, 'DOMESTIC=')) - instr(tr.
        add_info, 'DOMESTIC=') - 9))                                                      AS domestic_2,
        CASE
            WHEN instr(tr.add_info, 'ALI_PAY=Y;') > 0 THEN
                'ALIPAY'
            ELSE
                NULL
        END                                                                                                                                                                                                            AS
        channel
    FROM
        (
            SELECT
                /*+ materialize leading(tr) full(tr) use_hash(i) swap_join_inputs(i) pq_distribute(tr broadcast none) use_hash(tr2) swap_join_inputs(tr)*/
                tr.doc_idt,
                tr.trans_currency,
                tr.settl_currency,
                tr.card_brand_id,
                tr.trans_conditions_id,
                tr.trans_rrn,
                tr.trans_arn,
                tr.trans_date,
                tr.settl_amount,
                tr.banking_date,
                tr.auth_code,
                tr.source_number,
                tr.target_number,
                tr.source_contract_idt,
                tr.source_message_code,
                ';' || tr.add_info AS add_info
            FROM
                     dwf_transaction tr
                JOIN inst     i ON i.id = tr.institution_id
                LEFT JOIN tr_sales tr2 ON tr2.auth_code = tr.auth_code
                                          AND tr2.source_contract_idt = tr.source_contract_idt
                                          AND tr2.target_number = tr.target_number
            WHERE
                tr.banking_date BETWEEN decode(:P_REPORT_TYPE, 'D', to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'W', to_date(:P_REPORT_DATE,
                'DD-MM-YYYY') - 7, 'M', add_months(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), - 1) + 1) AND to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                AND nvl(tr.target_channel, 'NO') != 'X'
                AND instr(tr.add_info, 'ALI_PAY=Y;') > 0
        ) tr
), all_items AS (
    SELECT
        /*+materialize leading(tr device cntr) use_hash(curr) swap_join_inputs(curr) pq_distribute(curr none broadcast)
           use_hash(br) swap_join_inputs(br) pq_distribute(br none broadcast) no_swap_join_inputs(cntr) no_swap_join_inputs(device)
         */
        cntr.personal_account                                                                             AS merchant_id,
        cntr.master_chain1,
        cntr.record_idt                                                                                   AS contract_idt,
        cntr.merchant_name,
        cntr.location,
        cntr.telephone,
        cntr.email,
        decode(tr.contract_idt, tr.source_contract_idt, tr.source_number, tr.target_number)               AS terminal_id,
        tr.trans_rrn                                                                                      AS txn_seq_no,
        curr.name                                                                                         AS trans_curr,
        to_char(tr.trans_date, 'DD/MM/YYYY')                                                              AS txn_date,
        br.payment_scheme                                                                                 AS card_type,
        decode(tr.contract_idt, tr.source_contract_idt, tr.target_number, tr.source_number)               AS card_no,
        length(TRIM(decode(tr.contract_idt, tr.source_contract_idt, tr.target_number, tr.source_number))) AS card_no_length,
        tr.auth_code                                                                                      AS auth_code,
        tr.amnt                                                                                           AS txn_amount,
        tr.trans_rrn                                                                                      AS ret_ref_no,
        to_char(tr.trans_date, 'HH24:MI:SS')                                                              AS time,
        tr.new_name                                                                                       AS trn_typ,
        tr.trans_arn,
        tr.doc_idt,
        tr.trans_rrn,
        tr.tip_amount,
        CASE
            WHEN tr.new_name IN ( 'SALE REV', 'REFUND', 'DCC REF', 'DCC REV' ) THEN
                to_number(nvl(tr.tip_amount, 0)) * ( - 1 )
            ELSE
                to_number(nvl(tr.tip_amount, 0))
        END                                                                                               tip_amount_1,
        tr.tag_id,
        tr.domestic_2,
        tr.channel,
        tr.qr_enabled,
        tr.driver_id
    FROM
             (
            SELECT
               /*+no_merge leading(tr) use_nl(op) push_pred(op)*/
                tr.*,
                op.*
            FROM
                     tr
                JOIN trans_entr op ON tr.doc_idt = op.primary_doc_idt
        ) tr
        JOIN cntr device ON device.record_idt = tr.contract_idt
        JOIN (
            SELECT /*+no_merge*/
                *
            FROM
                cntr
            WHERE
                cntr.master_chain1 IS NOT NULL
			AND cntr.rta_merch = 'Y'	-- [+] 230626.1 = PrabirK = NIBOA-8609	
        )    cntr ON device.parent_contract_idt = cntr.record_idt
        JOIN (
            SELECT /*+no_merge full(curr)*/
                code,
                name
            FROM
                dwd_currency curr
            WHERE
                curr.record_state = 'A'
        )    curr ON curr.code = tr.trans_currency
        LEFT JOIN (
            SELECT /*+no_merge full(br)*/
                id,
                payment_scheme
            FROM
                dwd_card_brand br
            WHERE
                br.record_date_to = TO_DATE('01012100', 'ddmmyyyy')
        )    br ON br.id = tr.card_brand_id
), tots AS (
    SELECT
        /*+ materialize */
        substr(merchant_id, - 9)   AS t_merchant_id,
        substr(master_chain1, - 9) AS t_master_chain1,
        contract_idt,
        COUNT(1)                   AS count_by_merch,
        SUM(txn_amount)            AS tot_amount,
        nvl(SUM(tip_amount_1), 0)  AS tot_tip
    FROM
        all_items
    GROUP BY
        contract_idt,
        substr(merchant_id, - 9),
        substr(master_chain1, - 9)
), full_q AS (
    SELECT
        /*+ materialize */
        substr(merchant_id, - 9)         AS merchant_id,
        substr(master_chain1, - 9)       AS master_chain1,
        merchant_name,
        location,
        telephone,
        TRIM(substr(terminal_id, 1, 12)) AS terminal_id,
        substr(txn_seq_no, 3, 10)        AS seq_no,
        trans_curr,
        txn_date,
        CASE
            WHEN channel = 'ALIPAY' THEN
                'ALIPAY'
            ELSE
                upper(substr(card_type, 1, decode(instr(card_type, ' ', 1), 0, length(card_type), instr(card_type, ' ', 1) - 1)))
        END                              AS card_type,
        substr(card_no, 1, 6)
        || lpad('X', decode(card_no_length, 13, 3, 14, 4,
                            15, 5, 16, 6, 17,
                            7, 18, 8, 19, 9,
                            3), 'X')
        || substr(card_no, - 4)          AS card_no,
        auth_code,
        trn_typ,
        txn_amount,
        ret_ref_no,
        time,
        nvl(tip_amount, 0)               AS tip_amount,
        tag_id,
        driver_id,
        trans_arn,
        1                                AS row_by_merch
    FROM
        all_items
)
SELECT
    /*+parallel(8)*/
    *
FROM
    (
        SELECT
            /*+no_merge*/
            :ORG   AS org,
            merchant_id,
            master_chain1,
            summ,
            orderby,
            rec_order,
            ROWNUM AS rn
        FROM
            (
                SELECT
                    /*+no_merge*/
                    merchant_id,
                    master_chain1,
                    2      AS rec_order,
                    2      AS orderby,
                    lpad(ROW_NUMBER()
                         OVER(PARTITION BY merchant_id
                              ORDER BY
                                  merchant_id
                         ), 5, '0')
                    || ';'
                    || rpad(nvl(merchant_id, ' '), 12, ' ')
                    || ';'
                    || rpad(nvl(master_chain1, ' '), 9, ' ')
                    || ';'
                    || rpad(nvl(merchant_name, ' '), 40, ' ')
                    || ';'
                    || rpad(nvl(location, ' '), 40, ' ')
                    || ';'
                    || rpad(nvl(telephone, ' '), 15, ' ')
                    || ';'
                    || rpad(nvl(terminal_id, ' '), 12, ' ')
                    || ';'
                    || rpad(nvl(seq_no, ' '), 10, ' ')
                    || ';'
                    || rpad(nvl(trans_curr, ' '), 5, ' ')
                    || ';'
                    || rpad(nvl(txn_date, ' '), 10, ' ')
                    || ';'
                    || rpad(nvl(card_type, ' '), 15, ' ')
                    || ';'
                    || rpad(nvl(card_no, ' '), 19, ' ')
                    || ';'
                    || rpad(nvl(auth_code, ' '), 13, ' ')
                    || ';'
                    || rpad(nvl(trn_typ, ' '), 8, ' ')
                    || ';'
                    || lpad(TRIM(to_char(nvl(txn_amount, 0), '999999999990.99')), 12, ' ')
                    || ';'
                    || rpad(nvl(ret_ref_no, ' '), 12, ' ')
                    || ';'
                    || rpad(nvl(time, ' '), 8, ' ')
                    || ';'
                    || lpad(TRIM(to_char(nvl(tip_amount, 0), '999999999990.99')), 7, ' ')
                    || ';'
                    || rpad(nvl(tag_id, ' '), 10, ' ')
                    || ';'
                    || rpad(nvl(driver_id, ' '), 12, ' ')
                    || ';'
                    || rpad(nvl(trans_arn, ' '), 23, ' ')
                    || ';' AS summ
                FROM
                    full_q
            )
        UNION ALL
        SELECT
            /*+no_merge*/
            :ORG AS org,
            t_merchant_id,
            t_master_chain1,
            lpad(count_by_merch, 5, '0')
            || ';            ;000000000;MERCHANT TOTALS >>>                     ;                                        ;               ;            ;          ;     ;          ;               ;                   ;             ;        ;'
            || lpad(TRIM(to_char(nvl(tot_amount, 0), '999999999990.99')), 12, ' ')
            || ';            ;        ;'
            || lpad(TRIM(to_char(nvl(tot_tip, 0), '999999999990.99')), 7, ' ')
            || ';          ;            ;                       ;',
            5    orderby,
            1    AS rec_order,
            1    AS rn
        FROM
            tots
        UNION ALL
        SELECT
            /*+no_merge*/
            :ORG AS org,
            merchant_id,
            master_chain1,
            'SRL  ;MERCHANT ID ;CHAIN-ID ;MERCHANT NAME                           ;LOCATION                                ;TELEPHONE      ;TERMINAL    ;SEQUENCE  ;TRAN ;TRAN      ;CARD           ;CREDIT CARD        ;AUTHORIZATION;TRAN    ;       SALES;REFERENCE NO;--TIME--;  TIP  ;    TAG   ;   DRIVER   ;ARN                    ;'
            || CHR(13)
            || CHR(10)
            || 'NO.  ;            ;         ;                                        ;                                        ;               ;ID          ;NUMBER    ;CURR.;DATE      ;TYPE           ;NUMBER             ;CODE         ;TYPE    ;      AMOUNT;            ;HH:MM:SS;AMOUNT ;     ID   ;   ID       ;                       ;',
            1    AS orderby,
            1    AS rec_order,
            1    AS rn
        FROM
            full_q
        GROUP BY
            merchant_id,
            master_chain1
    )
ORDER BY
    merchant_id,
    orderby,
    rec_order,
    rn