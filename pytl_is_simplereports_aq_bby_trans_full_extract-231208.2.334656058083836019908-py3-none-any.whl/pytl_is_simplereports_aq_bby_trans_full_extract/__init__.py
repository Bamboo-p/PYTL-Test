__version__ = "231208.2" 
__job_name__ = "PyTL_IS_SimpleReports_AQ_BBY_TRANS_FULL_EXTRACT"
__bat_files__ = []