/*
* Code for PyTL_IS_SimpleReports_AQ_BBY_TRANS_FULL_EXTRACT
* PyTL_IS_SimpleReports_AQ_BBY_TRANS_FULL_EXTRACT = AQ_BBY_TRANS_FULL_EXTRACT.sql
* Version history:
* 230620.1 : BBY-2934 : PrabirK  : Initial development
* 230707.1 : BBY-2959 : PrabirK  : Changing the auth subquery fetching date condition and joining condition with contract
* 230718.1 : BBY-2959 : PrabirK  : Trans_type and Posting status addition to report query
* 230718.2 : BBY-2934 : PrabirK  : Remove ROUND() from query
* 231208.1 : BBY-3169 : PadalaSK  : Fetching amnd_date from authorization instead of trans_date
* 231208.2 : BBY-3169 : PadalaSK  : Increased length of merchant_name fields from 25chars to 40chars
*/

with
inst as 
(
select /*+ no_merge materialize */
       code
      ,id
from dwh.dwd_institution
where record_state = 'A'
and code = :ORG
)
,oper AS
  (select /*+ no_merge materialize */
          op.operation_type_id
         ,op.name
         ,op.code
         ,op.purpose
         ,case
            when NVL(tot.type_total,'') = 'TOTAL_TRANSACTIONS'
            then 'TRAN'
            when op.code = 'VAT'
            then 'VAT'
            when instr(op.purpose, ',VAT_ON_FEE,') > 0
            then 'VAT'
            when instr(op.purpose, ',TRANS_FEE,') > 0
            then 'TRANS_FEE'
            when instr(op.purpose, ',COMM,') > 0
            then 'COMM'
            when instr(op.purpose, ',REBATE,') > 0
            then 'REBATE'
          end as type
         ,case
            when op.code IN ('RETAIL','REFUND_REV','CASH','XLS_REV','XLS_SALE','CASHBACK','QR_SALE','QR_REFUND_REV')
            then 'SALE'
            when op.code IN ('CASH_REV','CASHBACK_REV','QR_SALE_REV')
            then 'SALE REV'
            when op.code IN ('XLS_FUND','XLS_REFUND','QR_REFUND')
            then 'REFUND'
            else replace(replace(replace(replace(replace(replace(op.NAME, 'MANL', 'M'), 'CHBK', 'C'), 'DCC REFUND', 'DCC REF'), '-SALE', ''), 'REFUNDS', 'REFUND'), 'SALES', 'SALE')
          end as new_name
    from
    (select /*+ inline no_merge materialize */
      op.operation_type_id   as operation_type_id
     ,op.operation_type_code as operation_type_code
     ,op.code                as code
     ,','
      || listagg(op.type_code, ',') within group (order by op.type_code)
      || ','                     as purpose
     ,nvl(min(op.name), op.code) as NAME
     from
      (select op.operation_type_id
             ,op.operation_type_code
             ,op.NAME
             ,op.code
             ,op.sort_order
             ,op.type_code
       from v_dwr_operation_type op
       where op.class_code = 'ACQ_SETTLEMENT_REPORT'
      ) op
     group by op.operation_type_id
             ,op.operation_type_code
             ,op.code
    )op
    left join
    (select /*+ no_merge materialize */
            operation_type_id as operation_type_id
           ,code              as type_total
     from v_dwr_operation_type
     where class_code = 'ACQ_REPORTS'
     and type_code    = 'DA_TOTALS'
    ) tot
    on tot.operation_type_id = op.operation_type_id
    where NVL(tot.type_total,'') = 'TOTAL_TRANSACTIONS'
    or instr(op.purpose, ',COMM_CODE,') > 0
)
,contract as
(
select cntr.record_idt
      ,cntr.personal_account
from dwh.dwd_contract cntr
join inst
on inst.id = cntr.institution_id
where cntr.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
and cntr.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
and cntr.parent_contract_idt is null
) 
,address as
(
select dca.contract_idt
      ,max(decode(dat.code, 'STMT_ADDR', dca.address_line_1, null)) as merchant_name
      ,max(decode(dat.code, 'STMT_ADDR', dca.address_line_2, null)) as location
from dwh.dwd_contract_address dca
join dwh.dwd_address_type dat
on dca.address_type_id = dat.id
and dat.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
and dat.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
join inst 
on dca.institution_id = inst.id
where dca.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
and dca.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
group by dca.contract_idt
)
,auth as
(
select vma.doc_id
      ,vma.merchant
      ,vma.source_cntr_number
      ,vma.trans_mcc
      ,vma.trans_date
      ,vma.target_cntr_number
      ,vma.auth_code
      ,vma.trans_type
      ,vma.trans_amount
      ,vma.trans_currency
	  ,vma.trans_details
      ,vma.trans_rrn
      ,vma.trans_arn
      ,vma.trans_response_code
      ,vma.trans_cond_code
	  ,substr(vma.add_info, instr(vma.add_info, 'PDS0052=')+8, (instr(vma.add_info, ';', instr(vma.add_info, 'PDS0052='))-instr(vma.add_info, 'PDS0052=')-8)) as ucaf
	  ,substr(vma.add_info, instr(vma.add_info, 'MPGSOrderId=')+12, (instr(vma.add_info, ';', instr(vma.add_info, 'MPGSOrderId='))-instr(vma.add_info, 'MPGSOrderId=')-12)) as order_id
      ,case
        when trcond.condition_list like '%CONTACTLESS%' then '07'
		when trcond.condition_list like '%KEY_ENTRY%' or condition_list like '%SECURE_CODE%' then '01'
		when trcond.condition_list like '%READ_CHIP%' then '05'
		when trcond.condition_list like '%READ_TRACK%' and trcond.condition_list like '%TERM_TRACK%' and vma.add_info like '%DT_INP_MODE=B%' then '02' 
        when condition_list like '%READ_TRACK%' and condition_list like '%TERM_TRACK%'   then '90'
		else ' ' 		
       end as entry_mode
	  ,vma.posting_date
      ,case 
        when (substr(vma.add_info, instr(vma.add_info, 'PREAUTH=')+8, (instr(vma.add_info, ';', instr(vma.add_info, 'PREAUTH='))-instr(vma.add_info, 'PREAUTH=')-8)) = 'Y')
              or (substr(vma.add_info, instr(vma.add_info, 'PREAUTH_COMP=')+13, (instr(vma.add_info, ';', instr(vma.add_info, 'PREAUTH_COMP='))-instr(vma.add_info, 'PREAUTH_COMP=')-13)) = 'Y')
        then 'PREAUTH'
        else null
       end as auth_trans -- [*] 230718.1 = PrabirK = BBY-2959
	  ,vma.posting_status -- [*] 230718.1 = PrabirK = BBY-2959
from dwh.v_c$v_mp_authorization vma
left join dwh.dwd_trans_conditions trcond 
on vma.trans_condition = trcond.id
and trcond.record_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
and trcond.record_date_to >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
where trunc(amnd_date) = to_date(:P_REPORT_DATE,'dd-mm-yyyy') -- [*] 230707.1 = PrabirK = BBY-2959, 231208.1 = PadalaSK = BBY-3169
)
,trans as
(
select t.doc_idt
      ,t.card_brand_id
      ,substr(t.add_info, instr(t.add_info, 'PDS0052=')+8, (instr(t.add_info, ';', instr(t.add_info, 'PDS0052='))-instr(t.add_info, 'PDS0052=')-8)) as ucaf
      ,substr(t.add_info, instr(t.add_info, 'MDE4837_3=')+10, (instr(t.add_info, ';', instr(t.add_info, 'MDE4837_3='))-instr(t.add_info, 'MDE4837_3=')-10)) as mc_sub_crd_acptr_id
      ,substr(t.add_info, instr(t.add_info, 'VF104_2_56_2=')+13, (instr(t.add_info, ';', instr(t.add_info, 'VF104_2_56_2='))-instr(t.add_info, 'VF104_2_56_2=')-13)) as vs_sub_crd_acptr_id
	  ,substr(t.add_info, instr(t.add_info, 'MPGSOrderId=')+12, (instr(t.add_info, ';', instr(t.add_info, 'MPGSOrderId='))-instr(t.add_info, 'MPGSOrderId=')-12)) as order_id
	  ,case
        when trcond.condition_list like '%CONTACTLESS%' then '07'
		when trcond.condition_list like '%KEY_ENTRY%' or condition_list like '%SECURE_CODE%' then '01'
		when trcond.condition_list like '%READ_CHIP%' then '05'
		when trcond.condition_list like '%READ_TRACK%' and trcond.condition_list like '%TERM_TRACK%' and t.add_info like '%DT_INP_MODE=B%' then '02' 
        when condition_list like '%READ_TRACK%' and condition_list like '%TERM_TRACK%'   then '90'
		else ' ' 		
       end as entry_mode
      ,case 
        when instr(t.add_info, 'CARD_AFS=D;') > 0 then 'DEBIT' 
        when instr(t.add_info, 'CARD_AFS=C;') > 0 then 'CREDIT'
       else null
       end as card_usage
      ,case 
        when instr(t.add_info, 'DOMESTIC=Y;') > 0 then 'YES'
       else 'NO'
       end as domestic
	  ,upper(substr(card_brand.payment_scheme,1,decode(instr(card_brand.payment_scheme,' ',1),0,length(card_brand.payment_scheme),instr(card_brand.payment_scheme,' ',1)-1))) card_type
      ,t.trans_details
      ,t.source_number
      ,t.target_number
      ,t.auth_code
      ,t.trans_currency
      ,t.trans_date
	  ,t.posting_status
from dwh.dwf_transaction t
join inst i 
on i.id = t.institution_id
left join dwh.dwd_trans_conditions trcond 
on t.trans_conditions_id = trcond.id
and trcond.record_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
and trcond.record_date_to >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
left join dwh.dwd_card_brand card_brand
on card_brand.id = t.card_brand_id
and card_brand.record_state = 'A'
where t.banking_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy')
)
,trans_entr as
(
select
    /*+ ordered no_merge use_hash(e i) use_hash(e op) */
     op.type
    ,op.new_name
    ,op.code
    ,e.credit - e.debit AS amnt -- [*] 230718.2 = PrabirK = BBY-2934
    ,e.primary_doc_idt
    ,e.contract_idt
    ,e.fee_rate_value
from inst i
join dwf_account_entry e
on i.id = e.institution_id
join oper op
on op.operation_type_id = e.operation_type_id
where banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
)
,comm_sql AS
(
select
    /*+ no_merge materialize */
    trans_entr.primary_doc_idt
   ,max(decode(trans_entr.type,'COMM',trans_entr.fee_rate_value, NULL)) fee_rate_value
   ,sum(decode(trans_entr.type,'COMM',amnt,0)) comm
   ,sum(decode(trans_entr.type,'TRANS_FEE',amnt,0)) trans_fee
   ,sum(decode(trans_entr.code,'VAT',amnt,0)) vat
   ,sum(decode(trans_entr.code,'VAT_ON_FEE',amnt,0)) vat_on_fee
from trans_entr
where trans_entr.TYPE IN ('COMM','VAT','TRANS_FEE')
group by trans_entr.primary_doc_idt
)
,settlement as
(
select doc_idt 
from opt_dwf_settlement 
where settlement_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY') 
group by doc_idt
)

select :ORG as org
      ,dump.stmnt
from (
select 'SRLNO;MERCHANT ID ;CHAIN-ID ;MERCHANT NAME                           ;LOCATION                                ;TERM ID ;STORE ID    ;MCC ;SUB MERCHANT NAME                       ;SUB MCC;UCAF;SUB CARD ACCEPTOR ID;TRAN DATE ;TRN TIME;CARD TYPE ;CARD USAGE;DOMESTIC;CREDIT CARD NUMBER ;AUTH CD;TRAN TYPE      ;TRAN AMOUNT    ;CCY;COMM AMT  ;VAT COMM  ;TRANS FEE ;VAT ON FEE;NET AMOUNT     ;RRN         ;ORDER  ID                       ;ACQUIRER REFERENCE NUMBER;RESP CODE;COND CODE;ENT MODE ;APPROVED/DECLINED;PROCESSED;SETTLED;' as stmnt
from dual
union all
select --auth.doc_id,
      lpad(rownum,5,0)
      ||';'||
      rpad(auth.merchant,12,' ')
      ||';'||
      rpad(' ',9,' ')
      ||';'||
      rpad(nvl(adrs.merchant_name,' '),40,' ') -- [*] 231208.2 = PadalaSK = BBY-3169
      ||';'||
      rpad(nvl(adrs.location,' '),40,' ')
      ||';'||
      rpad(coalesce(trans.source_number,auth.source_cntr_number),8,' ')
      ||';'||
      rpad(' ',12,' ')
      ||';'||
      rpad(auth.trans_mcc,4,' ')
      ||';'||
      rpad(nvl(coalesce(trans.trans_details,auth.trans_details),' '),40,' ')  -- [*] 231208.2 = PadalaSK = BBY-3169
      ||';'||
      rpad(auth.trans_mcc,7,' ')
      ||';'||
      rpad(nvl(coalesce(trans.ucaf,trans.ucaf),' '),4,' ')
      ||';'||
      rpad(nvl(case 
             when trans.card_type = 'VISA' then vs_sub_crd_acptr_id
             when trans.card_type = 'MASTERCARD' then mc_sub_crd_acptr_id
            end,auth.merchant),20,' ')
      ||';'||
      rpad(to_char(nvl(trans.trans_date,auth.trans_date),'DD/MM/YYYY'),10,' ')
      ||';'||
      rpad(to_char(nvl(trans.trans_date,auth.trans_date),'HH24:MI:SS'),8,' ')
      ||';'||
      rpad(nvl(trans.card_type,' '),10,' ')
      ||';'||
      rpad(nvl(trans.card_usage,' '),10,' ')
      ||';'||
      rpad(nvl(trans.domestic,' '),8,' ')
      ||';'||
      rpad(nvl(trans.target_number,auth.target_cntr_number),19,' ')
      ||';'||
      rpad(nvl(coalesce(trans.auth_code,auth.auth_code),' '),7,' ')
      ||';'||
      rpad(nvl(coalesce(trans_entr.new_name,auth.auth_trans),' '),15, ' ') -- [*] 230718.1 = PrabirK = BBY-2959
      ||';'||
      lpad(to_char(nvl(trans_entr.amnt,auth.trans_amount),'FM999999990D000999999'),15, ' ')
      ||';'||
      lpad(nvl(curr.name,' '),3, ' ')
      ||';'||
      lpad(to_char(nvl(comm_sql.comm,0),'FM999999990D000999999'),10,' ')
      ||';'||
      lpad(to_char(nvl(comm_sql.vat,0),'FM999999990D000999999'),10,' ')
      ||';'||
      lpad(to_char(nvl(comm_sql.trans_fee,0),'FM999999990D000999999'),10,' ')
      ||';'||
      lpad(to_char(nvl(comm_sql.vat_on_fee,0),'FM999999990D000999999'),10,' ')
      ||';'||
      lpad(to_char(nvl(trans_entr.amnt,auth.trans_amount)+nvl(comm_sql.comm,0)+nvl(comm_sql.vat,0)+nvl(comm_sql.trans_fee,0)+nvl(comm_sql.vat_on_fee,0),'FM999999990D000999999'),15,' ')
      ||';'||
      rpad(nvl(auth.trans_rrn,' '),12,' ')
      ||';'||
      rpad(nvl(trans.order_id,' '),32,' ')
      ||';'||
      rpad(nvl(auth.trans_arn,' '),25,' ')
      ||';'||
      rpad(auth.trans_response_code,9,' ')
      ||';'||
      rpad(auth.trans_cond_code,9,' ')
      ||';'||
      lpad(nvl(coalesce(trans.entry_mode,auth.entry_mode),' '),9,' ')
      ||';'||
      lpad(nvl(case 
            when coalesce(trans.posting_status,auth.posting_status) in ('D','E','J','S') then 'DECLINED' 
            else 'APPROVED' 
           end,' '),17,' ') -- [*] 230718.1 = PrabirK = BBY-2959
      ||';'||
      lpad(nvl(case 
            when trans.doc_idt is not null then 'YES' 
            else 'NO' 
           end,' '),9,' ')
      ||';'||
      lpad(nvl(case 
            when settlement.doc_idt is not null then 'YES' 
            else 'NO' 
           end,' '),7,' ')
      ||';' as stmnt
from auth
join contract cntr -- [*] 230707.1 = PrabirK = BBY-2959
on cntr.personal_account = auth.merchant
left join trans
on trans.doc_idt = auth.doc_id
left join address adrs
on adrs.contract_idt = cntr.record_idt
left join trans_entr
on trans_entr.primary_doc_idt = trans.doc_idt
left join comm_sql
on comm_sql.primary_doc_idt = trans_entr.primary_doc_idt
left join settlement 
on settlement.doc_idt = trans.doc_idt
left join dwh.dwd_currency curr
on curr.code = auth.trans_currency
) dump