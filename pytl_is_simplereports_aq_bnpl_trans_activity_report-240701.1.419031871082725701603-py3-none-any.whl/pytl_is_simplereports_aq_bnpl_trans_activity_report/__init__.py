__version__ = "240701.1" 
__job_name__ = "PyTL_IS_SimpleReports_AQ_BNPL_TRANS_ACTIVITY_REPORT"
__bat_files__ = []