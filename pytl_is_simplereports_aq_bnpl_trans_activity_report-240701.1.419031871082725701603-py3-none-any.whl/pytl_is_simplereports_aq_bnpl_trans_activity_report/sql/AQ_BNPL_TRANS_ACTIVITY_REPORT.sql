/*
* Code for AQ_BNPL_TRANS_ACTIVITY_REPORT
* PyTL_IS_SimpleReports_AQ_BNPL_TRANS_ACTIVITY_REPORT = AQ_BNPL_TRANS_ACTIVITY_REPORT.sql
* Version history:
* 230719.1 : NIIN-321 : PrabirK  : Initial development
* 230725.1 : NIIN-352 : PrabirK  : Change the Opeartion type name
* 230731.1 : NIIN-321 : PrabirK  : Date from logic change, ORG addition, SQL adjustment
* 231127.1 : PRD-25670 : PrabirK : SQL Condition change for Contract, Settlement and HINT addition
* 231129.1 : PRD-25670 : PrabirK : Correction of bnpl_instl_fee_flag indicator addition
* 231130.1 : PRD-25670 : PrabirK : Change OPERATION join condition to LEFT JOIN
* 240226.1 : NIBOA-9501: HamzaHendi : adding visa installment and vat on visa installment fee
* 240416.1 : NIBOA-9501: PrabirK : Tunned the query
* 240508.1 : PRD-27284 : maksimsk : fixed performance
* 240524.1 : PRD-27284 : PrabirK : Removed BNPL Installment and VISA installment Classifier checking
* 240701.1 : PRD-27284 : PrabirK : Report SQL tunning
*/
WITH institution AS (
    SELECT /*+ no_merge materialize */
        id,
        name
    FROM
        dwh.dwd_institution
    WHERE
            record_state = 'A'
        AND code = :ORG
)
, operation_type AS (
    SELECT /*+ no_merge materialize */
        operation_type_id,
        operation_type_code,
        name,
        type_code,
        ','
        || listagg(type_code, ',') within GROUP (
        ORDER BY type_code)
        || ',' AS purpose
    FROM
        dwh.v_dwr_operation_type
    WHERE
            class_code = 'ACQ_SETTLEMENT_REPORT'
        AND type_code in ('TRANS',
                          'MC_BNPL_INST_FEE','VAT_MC_BNPL_INST_FEE',
                          'VISA_INSTL_FEE','VAT_VISA_INSTL_FEE')
   GROUP BY operation_type_id,
            operation_type_code,
            name,
            type_code
), client AS (
    SELECT /*+ no_merge leading(inst, cl) */
        cl.record_idt,
        cl.company_department,
        cl.ident_number
    FROM
             dwh.dwd_client cl
        JOIN institution inst ON inst.id = cl.institution_id
    WHERE
            cl.record_date_from <= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
        AND cl.record_date_to >= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
), contract AS (
    SELECT /*+ no_merge  */
        cntr.personal_account,
        cntr.record_idt,
        cntr.parent_contract_idt,
        cntr.institution_id,
        cntr.company_department,
        cntr.m_billing_type,
        cntr.day,
        cntr.day2,
        cntr.twice_per_week_settlement,
        cntr.twice_per_month_settlement,
        cntr.fortnightly_sttlm,
        CASE
            WHEN cntr.m_billing_type = 'D' THEN
                to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
            WHEN cntr.m_billing_type = 'W'
                 AND nvl(cntr.fortnightly_sttlm, 'N') = 'Y'
                 AND to_char(to_date(:P_BANKING_DATE, 'DD-MM-YYYY'), 'd') = cntr.day THEN
                to_date(:P_BANKING_DATE, 'DD-MM-YYYY') - 13
            WHEN cntr.m_billing_type = 'W'
                 AND nvl(cntr.day2, 0) = 0
                 AND to_char(to_date(:P_BANKING_DATE, 'DD-MM-YYYY'), 'd') = cntr.day THEN
                to_date(:P_BANKING_DATE, 'DD-MM-YYYY') - 6
            WHEN cntr.m_billing_type = 'W'
                 AND nvl(cntr.twice_per_week_settlement, 'N') = 'Y' THEN
                    CASE
                        WHEN to_char(to_date(:P_BANKING_DATE, 'DD-MM-YYYY'), 'd') = cntr.day  THEN
                            to_date(:P_BANKING_DATE, 'DD-MM-YYYY') - ( 6 - ( cntr.day2 - cntr.day ) )
                        WHEN to_char(to_date(:P_BANKING_DATE, 'DD-MM-YYYY'), 'd') = cntr.day2 THEN
                            to_date(:P_BANKING_DATE, 'DD-MM-YYYY') - ( cntr.day2 - cntr.day ) + 1
                        ELSE
                            NULL
                    END
            WHEN cntr.m_billing_type = 'M'
                 AND nvl(cntr.twice_per_month_settlement, 'N') = 'Y' THEN
                    CASE
                        WHEN cntr.day > cntr.day2 THEN
                                CASE
                                    WHEN EXTRACT(DAY FROM to_date(:P_BANKING_DATE, 'DD-MM-YYYY')) = cntr.day  THEN
                                        to_date(:P_BANKING_DATE, 'DD-MM-YYYY') - ( cntr.day - cntr.day2 )
                                    WHEN EXTRACT(DAY FROM to_date(:P_BANKING_DATE, 'DD-MM-YYYY')) = cntr.day2 THEN
                                        add_months(to_date(:P_BANKING_DATE, 'DD-MM-YYYY'), - 1) + ( cntr.day - cntr.day2 )
                                    ELSE
                                        NULL
                                END
                        WHEN cntr.day < cntr.day2 THEN
                                CASE
                                    WHEN EXTRACT(DAY FROM to_date(:P_BANKING_DATE, 'DD-MM-YYYY')) = cntr.day2 THEN
                                        to_date(:P_BANKING_DATE, 'DD-MM-YYYY') - ( cntr.day2 - cntr.day )
                                    WHEN EXTRACT(DAY FROM to_date(:P_BANKING_DATE, 'DD-MM-YYYY')) = day       THEN
                                        add_months(to_date(:P_BANKING_DATE, 'DD-MM-YYYY'), - 1) + ( cntr.day2 - cntr.day )
                                    ELSE
                                        NULL
                                END
                    END
            WHEN cntr.m_billing_type = 'M'
                 AND ( EXTRACT(DAY FROM to_date(:P_BANKING_DATE, 'DD-MM-YYYY')) = nvl(cntr.day, 0)
                       OR nvl(cntr.day, 0) = 0 ) THEN
                add_months(to_date(:P_BANKING_DATE, 'DD-MM-YYYY'), - 1)
            ELSE
                NULL
        END                                    AS date_from, -- [+] 230731.1 = PrabirK = NIIN-321
        to_date(:P_BANKING_DATE, 'DD-MM-YYYY') AS date_to,
        date_open,
        cntr_role
    FROM
        (
            SELECT /*+ no_merge leading(attr c cl) use_hash(attr c) */
                c.personal_account,
                c.record_idt,
                c.parent_contract_idt,
                c.institution_id,
                c.date_open,
                cl.company_department,
                replace(replace(substr(c.add_info, instr(c.add_info, 'MERCHANT_BILLING=') + 17,(instr(c.add_info, ';', instr(c.add_info,
                'MERCHANT_BILLING=')) - instr(c.add_info, 'MERCHANT_BILLING=') - 17)), CHR(13)), CHR(10)) AS m_billing_type,
                replace(replace(substr(c.add_info, instr(c.add_info, 'DAY=') + 4,(instr(c.add_info, ';', instr(c.add_info, 'DAY=')) -
                instr(c.add_info, 'DAY=') - 4)), CHR(13)), CHR(10))                                          AS day,
                replace(replace(substr(c.add_info, instr(c.add_info, 'DAY2=') + 5,(instr(c.add_info, ';', instr(c.add_info, 'DAY2=')) -
                instr(c.add_info, 'DAY2=') - 5)), CHR(13)), CHR(10))                                       AS day2,
                attr.twice_per_week_settlement,
                attr.twice_per_month_settlement,
                attr.fortnightly_sttlm,
                attr.cntr_role
            FROM
                     dwh.dwd_contract c
                JOIN institution i ON i.id = c.institution_id
                LEFT JOIN (
                    SELECT /*+ no_merge leading(da dca) use_hash(da dca) */
                        contract_idt,
                         MAX(
                            CASE
                                WHEN da.type_code = 'ACQ_LVL' THEN
                                    da.code
                                ELSE
                                    NULL
                            END
                        ) AS cntr_role,
                        MAX(
                            CASE
                                WHEN da.type_code = 'TWICE_PER_WEEK_SETTLEMENT' THEN
                                    da.code
                                ELSE
                                    NULL
                            END
                        ) AS twice_per_week_settlement,
                        MAX(
                            CASE
                                WHEN da.type_code = 'TWICE_PER_MONTH_SETTLEMENT' THEN
                                    da.code
                                ELSE
                                    NULL
                            END
                        ) AS twice_per_month_settlement,
                        MAX(
                            CASE
                                WHEN da.type_code = 'FORTNIGHTLY_STTLM' THEN
                                    da.code
                                ELSE
                                    NULL
                            END
                        ) AS fortnightly_sttlm
                    FROM
                             dwh.dwa_contract_attribute dca
                        JOIN dwh.dwd_attribute da ON da.id = dca.attr_id
                                                 AND da.type_code IN ( 'ACQ_LVL','ACQ_COMM_STTLM', 'TWICE_PER_WEEK_SETTLEMENT', 'DCC_SETTL_BW',
                                                 'TWICE_PER_MONTH_SETTLEMENT', 'FORTNIGHTLY_STTLM' )
                                                 AND da.record_date_from <= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
                                                 AND da.record_date_to >= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
                    WHERE
                            dca.attr_date_from <= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
                        AND dca.attr_date_to >= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
                    GROUP BY
                        dca.contract_idt
                )           attr ON attr.contract_idt = c.record_idt
                LEFT JOIN client      cl ON cl.record_idt = c.client_idt
                WHERE
                    c.record_date_from <= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
                AND c.record_date_to >= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
                AND c.record_state != 'C'
           ) cntr
), chain AS (
    SELECT /*+ no_merge leading(client) */
        daf.contract_idt,
        MAX(decode(daft.code, 'CHAINID_1', dcl.ident_number, NULL)) AS ident_number
    FROM
             dwh.dwd_affiliation daf
        JOIN dwh.dwd_affiliation_type daft ON daf.affiliation_type_id = daft.id
                                          AND daft.code = 'CHAINID_1'
                                          AND daft.record_state = 'A'
        JOIN client           dcl ON daf.affiliated_client_idt = dcl.record_idt
    WHERE
            daf.record_date_from <= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
        AND daf.record_date_to >= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
    GROUP BY
        daf.contract_idt
), address AS (
    SELECT /*+ no_merge use_hash(inst) swap_join_inputs(inst) pq_distribute(inst none broadcast)*/
        decode(ova.delivery_type, 'Email', 'E', 'Fax', 'F',
               'N')    AS delivery_type,
        ova.phone,
        ova.fax,
        ova.first_name AS address_line_1,
        ova.address_line_2,
        ova.address_line_3,
        ova.address_line_4,
        ova.location,
        ova.e_mail,
        ova.contract_idt,
        ova.client_idt,
        ova.address_type_code,
        ova.state
    FROM
             dwh.opt_v_address ova
        JOIN institution inst ON inst.id = ova.institution_id
    WHERE
        ova.address_type_code IN ( 'STMT_ADDR', 'PST_ADDR' )
        AND ova.record_date_from <= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
        AND ova.record_date_to >= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
), settlement AS (
    SELECT /*+ no_merge leading(cntr setl) use_hash(cntr setl) */
        setl.merchant_idt,
        setl.doc_idt
    FROM
             dwh.opt_dwf_settlement setl
        JOIN institution ins ON ins.id = setl.institution_id
        JOIN contract cntr ON cntr.record_idt = setl.merchant_idt
                          AND cntr.cntr_role = 'MERCHANT'
                      --  AND ( cntr.bnpl_instl_fee_flag = 'Y' or cntr.visa_instl_fee_flag = 'Y')
        JOIN operation_type opt ON opt.type_code = setl.sttl_type  
                          AND opt.type_code in ('MC_BNPL_INST_FEE','VISA_INSTL_FEE')
    WHERE
        setl.settlement_date = to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
    GROUP BY
        setl.merchant_idt,
        setl.doc_idt
), entry AS (
    SELECT /*+ no_merge leading(s) index(ent DWF_ACCOUNT_ENTRY_DOC_IDX) */
        s.merchant_idt,
        ent.primary_doc_idt,
        ent.contract_idt,
        ent.credit - ent.debit  AS amnt,
        opt.operation_type_code AS oper_code,
        opt.name                AS oper_name,
        opt.type_code           AS oper_group
    FROM
             dwh.dwf_account_entry ent
        JOIN institution ins ON ins.id = ent.institution_id
		JOIN (
            SELECT
                 doc_idt, merchant_idt
            FROM
                settlement
        )           s ON s.doc_idt = ent.primary_doc_idt
        JOIN operation_type opt ON opt.operation_type_id = ent.operation_type_id
    WHERE
            ent.banking_date >= add_months(to_date(:P_BANKING_DATE, 'DD-MM-YYYY'), - 2)
        AND ent.banking_date <= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
), transaction AS (
    SELECT /*+ no_merge leading(s trn) index(trn DWF_TRANSACTION_DOCID_IDX)  */
        trn.doc_idt,
        trn.trans_date,
        trn.target_number,
        trn.trans_arn,
        trn.auth_code,
        trn.trans_amount,
        trn.transaction_type_id
    FROM
             dwh.dwf_transaction trn
        JOIN institution ins ON ins.id = trn.institution_id
        JOIN (
            SELECT
                doc_idt
            FROM
                settlement
        )           s ON s.doc_idt = trn.doc_idt
    WHERE
            trn.banking_date >= add_months(to_date(:P_BANKING_DATE, 'DD-MM-YYYY'), - 2)
        AND trn.banking_date <= to_date(:P_BANKING_DATE, 'DD-MM-YYYY')
), full_q AS (
    SELECT /*+ no_merge leading(entr mer ins tran) use_hash(entr mer ins tran) */
        mer.personal_account                                                                  AS merchant,
        to_char(tran.trans_date, 'DD/MM')                                                     AS trans_date,
        entr.terminal,
        CASE
            WHEN tran.target_number IS NULL THEN
                '      XXXXXX'
            ELSE
                substr(tran.target_number, 1, 6)
                || lpad('X', decode(length(TRIM(tran.target_number)), 13, 3, 14, 4,
                                    15, 5, 16, 6, 17,
                                    7, 18, 8, 19, 9,
                                    3), 'X')
                || substr(tran.target_number, - 4)
        END                                                                                   AS card_number,
        tran.trans_arn,
        tran.auth_code,
        nvl(entr.trans_amount, 0)                                                             AS trans_amount,
        nvl(entr.bnpl_fee, 0)                                                                 AS bnpl_fee,
        nvl(entr.vat_bnpl_fee, 0)                                                             AS vat_bnpl_fee,
        ( ( nvl(entr.trans_amount, 0) ) + nvl(entr.bnpl_fee, 0) + nvl(entr.vat_bnpl_fee, 0))  AS net_amount,
        ins.name                                                                              AS inst_name,
        nvl(mer.company_department, '00000')                                                  AS agent_code,
        adrs.delivery_type,
        adrs.address_line_1,
        adrs.address_line_2,
        adrs.address_line_3,
        adrs.address_line_4,
        adrs.phone,
        adrs.fax,
        adrs.e_mail,
        mer.date_to,
        coalesce(
            CASE
                WHEN mer.date_open > mer.date_from THEN
                    mer.date_open
                ELSE
                    mer.date_from
            END, mer.date_open)                                                                      AS date_from,
        tran.doc_idt,
        entr.oper_name,
        nvl(chain.ident_number, '000000000')                                                  AS ident_number,
        nvl(entr.visa_inst_fee, 0)                                                            AS visa_inst_fee,
        nvl(entr.vat_visa_inst_fee, 0)                                                        AS vat_visa_inst_fee
    FROM
             (
            SELECT
                e.merchant_idt,
                e.terminal,
                e.doc_idt,
                SUM(
                    CASE
                        WHEN e.oper_group IN ('TRANS') THEN
                            e.amnt
                        ELSE
                            0
                    END
                ) AS trans_amount,
                SUM(
                    CASE
                        WHEN e.oper_group IN('MC_BNPL_INST_FEE') THEN
                            e.amnt
                        ELSE
                            0
                    END
                ) AS bnpl_fee,
                SUM(
                    CASE
                        WHEN e.oper_group IN('VAT_MC_BNPL_INST_FEE') THEN
                            e.amnt
                        ELSE
                            0
                    END
                ) AS vat_bnpl_fee, 
                MAX(
                    CASE
                        WHEN e.oper_group IN ('TRANS') THEN
                            e.oper_name
                        ELSE
                            NULL
                    END
                ) AS oper_name,
                SUM(
                    CASE
                        WHEN e.oper_group IN('VISA_INSTL_FEE') THEN
                            e.amnt
                        ELSE
                            0
                    END
                ) AS visa_inst_fee,
                SUM(
                    CASE
                        WHEN e.oper_group IN('VAT_VISA_INSTL_FEE') THEN
                            e.amnt
                        ELSE
                            0
                    END
                ) AS vat_visa_inst_fee    
            FROM
                (
                    SELECT /*+ no_merge leading(ent dev) use_hash(ent dev) */
                        ent.merchant_idt,
                        dev.personal_account AS terminal,
                        ent.primary_doc_idt  doc_idt,
                        ent.amnt,
                        ent.oper_code,
                        ent.oper_name,
                        ent.oper_group
                    FROM
                             entry ent
                        JOIN contract dev ON dev.record_idt = ent.contract_idt
                                             AND dev.cntr_role = 'DEVICE'
                ) e
            GROUP BY
                e.merchant_idt,
                e.terminal,
                e.doc_idt
        ) entr
        JOIN contract    mer ON mer.record_idt = entr.merchant_idt
		                    AND mer.cntr_role = 'MERCHANT'
        JOIN institution ins ON ins.id = mer.institution_id
        JOIN transaction tran ON tran.doc_idt = entr.doc_idt
        LEFT JOIN address adrs ON adrs.contract_idt = mer.record_idt
                                  AND adrs.address_type_code = 'STMT_ADDR'
        LEFT JOIN chain ON chain.contract_idt = mer.record_idt
		-- WHERE ( mer.bnpl_instl_fee_flag = 'Y' or mer.visa_instl_fee_flag = 'Y')
), totals AS (
    SELECT
        merchant,
        COUNT(doc_idt)    AS total_num_pos,
        SUM(trans_amount) AS total_pos,
        SUM(bnpl_fee)     AS total_bnpl_fee,
        SUM(vat_bnpl_fee) AS total_vat_bnpl_fee,
        SUM(visa_inst_fee)     AS total_visa_inst_fee,
        SUM(vat_visa_inst_fee) AS total_vat_visa_inst_fee
    FROM
        full_q
   WHERE
        ( bnpl_fee <> 0
          OR vat_bnpl_fee <> 0 
          OR visa_inst_fee <> 0
          OR vat_visa_inst_fee <> 0) 
    GROUP BY
        merchant
)  

SELECT
    :ORG AS org, -- [+] 230731.1 = PrabirK = NIIN-321
    summ
FROM
    (
        SELECT
            merchant,
            summ,
            orderby,
            rec_order,
            ROWNUM AS rn
        FROM
            (
                SELECT
                    merchant,
                    2                                                                AS rec_order,
                    2                                                                AS orderby,
                    rpad(nvl(to_char(trans_date), ' '), 5, ' ')
                    || ' '
                    || rpad(nvl(terminal, ' '), 8, ' ')
                    || ' '
                    || rpad(nvl(card_number, ' '), 13, ' ')
                    || ' '
                    || rpad(nvl(oper_name, ' '), 15, ' ')
                    || ' '
                    || rpad(nvl(trans_arn, ' '), 23, ' ')
                    || '  '
                    || rpad(nvl(auth_code, ' '), 6, ' ')
                    || ' '
                    || lpad(TRIM(to_char((trans_amount), '999999999990.99')), 14, ' ')
                    || ' '
                    || lpad(TRIM(to_char((bnpl_fee), '999999999990.99')), 14, ' ')
                    || ' '
                    || lpad(TRIM(to_char((vat_bnpl_fee), '999999999990.99')), 14, ' ')
                    || ' '
                    || lpad(TRIM(to_char((net_amount), '999999999990.99')), 14, ' ') AS summ
                FROM
                    full_q
                WHERE
                    ( bnpl_fee <> 0
                      OR vat_bnpl_fee <> 0
                      OR visa_inst_fee <> 0
                      OR vat_visa_inst_fee <> 0) 
                ORDER BY
                    terminal NULLS LAST,
                    trans_arn NULLS LAST,
                    oper_name
            )
        UNION ALL
        SELECT
            merchant,
            lpad('-', 147, '-')
            || CHR(13)
            || CHR(10)
            || '  GRAND TOTAL OF POS TRANSACTIONS :'
            || lpad(TRIM(lpad(nvl(total_num_pos, 0), 5, 0)), 31, ' ')
            || CHR(13)
            || CHR(10)
            || '  GRAND TOTAL VALUE OF POS TRANSACTIONS :'
            || lpad(TRIM(to_char(nvl(total_pos, 0), '999999999990.99')), 25, ' ')
            || CHR(13)
            || CHR(10)
            || '  BNPL INSTALLMENT FEE:'
            || lpad(TRIM(to_char(nvl(total_bnpl_fee, 0), '999999999990.99')), 43, ' ')
            || CHR(13)
            || CHR(10)
            || '  VAT ON BNPL INSTALLMENT FEE:'
            || lpad(TRIM(to_char(nvl(total_vat_bnpl_fee, 0), '999999999990.99')), 36, ' ')
            || CHR(13)
            || CHR(10)
            || '  VISA INSTALLMENT FEE:'
            || lpad(TRIM(to_char(nvl(total_visa_inst_fee, 0), '999999999990.99')), 43, ' ')
            || CHR(13)
            || CHR(10)
            || '  VAT ON VISA INSTALLMENT FEE:'
            || lpad(TRIM(to_char(nvl(total_vat_visa_inst_fee, 0), '999999999990.99')), 36, ' ')  
            || CHR(13)
            || CHR(10)
            || lpad('-', 70, '-')
            || CHR(13)
            || CHR(10)
            || 'NET PAYABLE / RECEIVABLE OF BNPL TXN'
            || lpad(TRIM(to_char(nvl(total_pos + total_bnpl_fee + total_vat_bnpl_fee + total_visa_inst_fee + total_vat_visa_inst_fee, 0), '999999999990.99')), 30, ' ')
            || CHR(13)
            || CHR(10)
            || lpad('-', 70, '-')
            || CHR(13)
            || CHR(10)
            || 'END OF REPORT' AS summ,
            5                  AS orderby,
            1                  AS rec_order,
            1                  AS rn
        FROM
            totals
        UNION ALL
        SELECT
            merchant,
            lpad(' ', 55, ' ')
            || upper(MAX(inst_name))
            || CHR(13)
            || CHR(10)
            || '                                                          MERCHANT MC BNPL ACTIVITY                                       PAGE'
            || lpad(DENSE_RANK()
                    OVER(
                ORDER BY
                    merchant
                    ), 9, ' ')
            || CHR(13)
            || CHR(10)
            || '                                                          COMPUTERISED FAX/EMAIL     ('
            || MAX(delivery_type)
            || ')            PROC DATE '
            || to_char(sysdate, 'DD/MM/YYYY')
            || '  TIME '
            || to_char(systimestamp, 'HH.MI.SS')
            || CHR(13)
            || CHR(10)
            || '  MERCHANT NO :  '
            || rpad(merchant, 98, ' ')
            || 'AGENT CODE '
            || MAX(agent_code)
            || CHR(13)
            || CHR(10)
            || '  ADDRESS     :  '
            || rpad(coalesce(MAX(address_line_1), 'NA'), 95, ' ')
            || 'PHONE '
            || nvl(MAX(phone), 'NA')
            || CHR(13)
            || CHR(10)
            || '                 '
            || rpad(coalesce(MAX(address_line_2), 'NA'), 95, ' ')
            || 'FAX   '
            || coalesce(MAX(fax), 'NA')
            || CHR(13)
            || CHR(10)
            || '                 '
            || coalesce(MAX(address_line_3), 'NA')
            || CHR(13)
            || CHR(10)
            || '                 '
            || rpad(coalesce(MAX(address_line_4), 'NA'), 80, ' ')
            || CHR(13)
            || CHR(10)
            || '  EMAIL       :  '
            || coalesce(MAX(e_mail), 'NA')
            || CHR(13)
            || CHR(10)
            || '  CHAIN ID    :  '
            || rpad(MAX(ident_number), 24, ' ')
            || 'MERCHANT TRANSACTION ACTIVITY FROM '
            || to_char(MAX(date_from), 'DD/MM/YYYY')
            || ' TO '
            || to_char(MAX(date_to), 'DD/MM/YYYY')
            || CHR(13)
            || CHR(10)
            || lpad('-', 147, '-')
            || CHR(13)
            || CHR(10)
            || 'DTOF   TRMNL   CARD NUMBER       TYPE         ACQ REF NBR              AUTH           TRAN       BNPL FEE            VAT            NET'
            || CHR(13)
            || CHR(10)
            || 'TRN    ID                                                              CODE            AMT            AMT            AMT            AMT'
            || CHR(13)
            || CHR(10)
            || lpad('-', 147, '-') AS summ,
            1                      AS orderby,
            1                      AS rec_order,
            1                      AS rn
        FROM
            full_q
       WHERE
            ( bnpl_fee <> 0
              OR vat_bnpl_fee <> 0       
              OR visa_inst_fee <> 0
              OR vat_visa_inst_fee <> 0) 
        GROUP BY
            merchant
    )
ORDER BY
    merchant,
    orderby,
    rec_order,
    rn