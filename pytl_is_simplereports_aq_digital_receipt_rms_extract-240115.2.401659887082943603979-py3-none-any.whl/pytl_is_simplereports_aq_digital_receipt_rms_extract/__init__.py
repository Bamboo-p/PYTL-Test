__version__ = "240115.2" 
__job_name__ = "PyTL_IS_SimpleReports_AQ_DIGITAL_RECEIPT_RMS_EXTRACT"
__bat_files__ = []