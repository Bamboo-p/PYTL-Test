/*
* Code for AQ_DIGITAL_RECEIPT_RMS_EXTRACT
* PyTL_IS_SimpleReports_AQ_DIGITAL_RECEIPT_RMS_EXTRACT = AQ_DIGITAL_RECEIPT_RMS_EXTRACT.sql
* Version history:
* 230830.1 : NIINT-3782 : PrabirK : Initial version : Digital Receipt RMS Extract for Chains, Merchants and Terminals
*                       Input Params : ORG : Bank code needs to be passed , exmple - 200 
* 					                 P_BANKING_DATE : Date needs to be passed in DD-MM-YYYY format
* 									 P_REPORT_TYPE : Report Type needs to be passed, example - CHAIN/MERCHANT/TERMINAL
* 230906.1 : NIINT-3782 : PrabirK : Modification in amnd_flag value logic
* 230907.1 : NIINT-3782 : PrabirK : Modification in SQL
* 230911.1 : NIINT-3782 : PrabirK : Logic change on ACTION field and addition of Hints
* 230911.2 : NIINT-3782 : PrabirK : Report moved from excelreport to simplereport (csv)
* 230911.3 : NIINT-3782 : PrabirK : SQL code modification at WHERE clause
* 231129.1 : NIINT-4142 : PrabirK : SQL code modification and HINT addition
* 231203.1 : NIINT-4142 : PrabirK : SQL code modification
* 231208.1 : NIINT-4142 : PrabirK : Correction in MERCHANT Role condition
* 231208.2 : NIINT-4142 : PrabirK : Replacie ORDERED Hint with LEADING Hint
* 240105.1 : NIINT-4344 : PrabirK : Change in SQL to fetch DISTINCT records
* 240115.1 : NIINT-4344 : PrabirK : Condition change for Terminal extract
* 240115.2 : NIINT-4344 : PrabirK : Condition change for Terminal extract
*/
with 
inst as (
select  /*+ no_merge */
        id
       ,code
       ,name
from dwh.dwd_institution
where record_state = 'A'
and code = :ORG
),
contract as (
select  /*+ no_merge leading(dca da dc) */
        dc.record_idt as contract_idt
       ,dc.personal_account
       ,dc.date_open
       ,da.code
       ,decode(da.code,'DEVICE',dc.parent_contract_idt,'MERCHANT',dc.record_idt,dc.record_idt) as parent_contract_idt
       ,inst.code as organization_id
from dwh.dwa_contract_attribute dca
join dwh.dwd_attribute da
on da.id = dca.attr_id
and da.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and da.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and da.type_code = 'ACQ_LVL'
and da.code in ('MERCHANT','DEVICE')
join dwh.dwd_contract dc
on dc.record_idt = dca.contract_idt
and dc.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dc.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY') 
join inst
on inst.id = dc.institution_id
where dca.attr_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dca.attr_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dca.active_state = 'A'
and instr(dc.personal_account,'POS') = 0
),
chain as (
select  /*+ no_merge leading(cntr dff dft clnt) use_hash(cntr dff) */
        cntr.contract_idt
       ,clnt.record_idt as client_idt
       ,clnt.ident_number as chain_id
       ,clnt.company_name as chain_name
       ,clnt.creation_date
from contract cntr
join dwd_affiliation dff
on dff.contract_idt = cntr.contract_idt
and dff.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dff.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dff.institution_id in (select /*+ no_merge */ id from inst)
join dwd_affiliation_type dft
on dft.id = dff.affiliation_type_id
and dft.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dft.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dft.code = 'CHAINID_1'
join dwd_client clnt
on clnt.record_idt = dff.affiliated_client_idt
and clnt.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and clnt.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and clnt.institution_id in (select /*+ no_merge */ id from inst)
where cntr.code = 'MERCHANT'
),
cntr_attr as (
select /*+ no_merge leading(cattr1 cattr2) use_hash(cattr1 cattr2) */
        cattr1.contract_idt
       ,cattr1.code
       ,case
         when cattr1.attr_date_from = to_date(:P_BANKING_DATE,'DD-MM-YYYY') --[*] 230907.1 = PrabirK = NIINT-3782 
          and cattr1.code <> nvl(cattr2.code,'N')
         then 'Y'
         else 'N'
        end as amnd_flag
from (select /*+ no_merge leading(da1 dca1) use_hash(da1 dca1) no_push_pred */
               dca1.contract_idt
              ,dca1.attr_date_from 
              ,da1.code
from dwa_contract_attribute dca1
join dwh.dwd_attribute da1
on da1.id = dca1.attr_id
and da1.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and da1.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and da1.type_code = 'DIGITAL_RCPTS_ENBL'
and da1.code = 'Y'
where dca1.attr_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dca1.attr_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dca1.active_state = 'A') cattr1
left join (select /*+ no_merge leading(da2 dca2) use_hash(da2 dca2) no_push_pred */
                  dca2.contract_idt
                 ,dca2.attr_date_from 
                 ,da2.code
from dwa_contract_attribute dca2
join dwh.dwd_attribute da2
on da2.id = dca2.attr_id
and da2.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and da2.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and da2.type_code = 'DIGITAL_RCPTS_ENBL'
where dca2.attr_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')-1
and dca2.attr_date_to = to_date(:P_BANKING_DATE,'DD-MM-YYYY')-1) cattr2
on cattr2.contract_idt = cattr1.contract_idt
),
merchantattr as (
select /*+ no_merge leading(attr cntr) use_hash(attr cntr) */
         cntr.contract_idt
        ,attr.code
        ,attr.amnd_flag
from contract cntr
join cntr_attr attr
on attr.contract_idt = cntr.contract_idt
where cntr.code = 'MERCHANT'
),
chain_attr as (
select /*+ no_merge leading(chattr1 chattr2) use_hash(chattr1 chattr2) */
          chattr1.client_idt
         ,chattr1.code
         ,case
           when chattr1.attr_date_from = to_date(:P_BANKING_DATE,'DD-MM-YYYY') --[*] 230907.1 = PrabirK = NIINT-3782
            and chattr1.code <> nvl(chattr2.code,'N')
           then 'Y'
           else 'N'
          end as amnd_flag
from (select /*+ no_merge leading(da1 dclntattr1) use_hash(da1 dclntattr1) no_push_pred */
              dclntattr1.client_idt
             ,da1.code
             ,dclntattr1.attr_date_from
from dwa_client_attribute dclntattr1
join dwh.dwd_attribute da1
on da1.id = dclntattr1.attr_id
and da1.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and da1.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and da1.type_code = 'DIGITALCL_RCPTS_ENBL'
and da1.code = 'Y'
where dclntattr1.attr_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dclntattr1.attr_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dclntattr1.active_state = 'A') chattr1
left join (select /*+ no_merge leading(da2 dclntattr2) use_hash(da2 dclntattr2) no_push_pred */
                   dclntattr2.client_idt
                  ,da2.code
                  ,dclntattr2.attr_date_from
from dwa_client_attribute dclntattr2
join dwh.dwd_attribute da2
on da2.id = dclntattr2.attr_id
and da2.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and da2.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and da2.type_code = 'DIGITALCL_RCPTS_ENBL'
where dclntattr2.attr_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')-1
and dclntattr2.attr_date_to = to_date(:P_BANKING_DATE,'DD-MM-YYYY')-1) chattr2
on chattr2.client_idt = chattr1.client_idt
),
chainattr as (
select /*+ no_merge leading(cha ch) use_hash(cha ch) */
         ch.contract_idt
        ,ch.client_idt
        ,cha.code
        ,cha.amnd_flag
from chain ch
join chain_attr cha
on cha.client_idt = ch.client_idt
),
mer_demographic_curr as (
select /*+ no_merge leading(mattr dcadrs1 dadrtyp1 mcc1) use_hash(dcadrs1 mcc1) */
        dcadrs1.contract_idt
       ,dcadrs1.record_date_from
       ,coalesce(dcadrs1.address_line_1, 'NA') as merchant_name
       ,coalesce(dcadrs1.phone, dcadrs1.phone_home, dcadrs1.phone_mobile, 'NA') as phone
       ,coalesce(dcadrs1.address_line_2, 'NA') as address
       ,coalesce(dcadrs1.e_mail, 'NA') as email
       ,mcc1.mcc_date_from
       ,mcc1.mcc_id
from dwh.dwd_contract_address dcadrs1
join merchantattr mattr
on mattr.contract_idt = dcadrs1.contract_idt
join dwh.dwd_address_type dadrtyp1
on dadrtyp1.id = dcadrs1.address_type_id
and dadrtyp1.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dadrtyp1.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dadrtyp1.code = 'STMT_ADDR'
left join (select /*+ no_merge */
                   dvc.main_contract_idt
                  ,max(dvc.mcc) as mcc_id
                  ,max(dvc.record_date_from) as mcc_date_from 
from dwh.dwd_device dvc
join merchantattr mattr
on mattr.contract_idt = dvc.main_contract_idt
where dvc.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dvc.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dvc.institution_id in (select /*+ no_merge */ id from inst)
group by dvc.main_contract_idt) mcc1
on mcc1.main_contract_idt = dcadrs1.contract_idt
where dcadrs1.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dcadrs1.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dcadrs1.institution_id in (select /*+ no_merge */ id from inst)
),
mer_demographic_prev as (
select /*+ no_merge leading(mattr dcadrs1 dadrtyp1 mcc1) use_hash(dcadrs1 mcc1) */
        dcadrs2.contract_idt
       ,dcadrs2.record_date_from
       ,coalesce(dcadrs2.address_line_1, 'NA') as merchant_name
       ,coalesce(dcadrs2.phone, dcadrs2.phone_home, dcadrs2.phone_mobile, 'NA') as phone
       ,coalesce(dcadrs2.address_line_2, 'NA') as address
       ,coalesce(dcadrs2.e_mail, 'NA') as email
       ,mcc2.mcc_date_from
       ,mcc2.mcc_id
from dwh.dwd_contract_address dcadrs2
join merchantattr mattr
on mattr.contract_idt = dcadrs2.contract_idt
join dwh.dwd_address_type dadrtyp2
on dadrtyp2.id = dcadrs2.address_type_id
and dadrtyp2.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dadrtyp2.record_date_to >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
and dadrtyp2.code = 'STMT_ADDR'
left join (select /*+ no_merge */
                   dvc.main_contract_idt
                  ,max(dvc.mcc) as mcc_id
                  ,max(dvc.record_date_from) as mcc_date_from 
from dwh.dwd_device dvc
join merchantattr mattr
on mattr.contract_idt = dvc.main_contract_idt
where dvc.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')-1
and dvc.record_date_to = to_date(:P_BANKING_DATE,'DD-MM-YYYY')-1
and dvc.institution_id in (select /*+ no_merge */ id from inst)
group by dvc.main_contract_idt) mcc2
on mcc2.main_contract_idt = dcadrs2.contract_idt
where dcadrs2.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')-1
and dcadrs2.record_date_to = to_date(:P_BANKING_DATE,'DD-MM-YYYY')-1
and dcadrs2.institution_id in (select /*+ no_merge */ id from inst)
),
merdemographic as (
select /*+ no_merge */
        curr.contract_idt
       ,case
         when (curr.record_date_from = to_date(:P_BANKING_DATE,'DD-MM-YYYY')
               and (nvl(curr.merchant_name,'NA') <> nvl(prev.merchant_name,'NA')
                 or nvl(curr.phone,'NA') <> nvl(prev.phone,'NA')
                 or nvl(curr.address,'NA') <> nvl(prev.address,'NA')
                 or nvl(curr.email,'NA') <> nvl(prev.email,'NA')
                   )
               ) or
              (curr.mcc_date_from = to_date(:P_BANKING_DATE,'DD-MM-YYYY')
               and nvl(curr.mcc_id,'NA') <> nvl(prev.mcc_id,'NA')
               ) 
         then 'Y' 
         else 'N'
        end as amnd_flag
from mer_demographic_curr curr
left join mer_demographic_prev prev
on prev.contract_idt = curr.contract_idt
),
deviceattr as (
select /*+ no_merge leading(attr cntr) use_hash(attr cntr) */
         cntr.parent_contract_idt
        ,cntr.contract_idt
        ,attr.code
        ,attr.amnd_flag
from contract cntr
join cntr_attr attr
on attr.contract_idt = cntr.contract_idt
where cntr.code = 'DEVICE'
),
final as (
select /*+ no_merge */
        mer.organization_id
       ,dev.personal_account as tid
       ,mer.personal_account as merchant_id
       ,demo_curr.merchant_name
       ,demo_curr.phone
       ,demo_curr.address
       ,demo_curr.email
       ,demo_curr.mcc_id
       ,chain.chain_id
       ,chain.chain_name
       ,coalesce(mattr.amnd_flag,'N') as mattr_amnd_flag
       ,coalesce(cattr.amnd_flag,'N') as cattr_amnd_flag
       ,coalesce(mdemo.amnd_flag,'N') as mdemo_amnd_flag
       ,coalesce(dattr.amnd_flag,'N') as dattr_amnd_flag
       ,mer.date_open as merchant_open_date
	   ,dev.code as role
from contract mer
left join contract dev
on dev.parent_contract_idt = mer.contract_idt
left join mer_demographic_curr demo_curr
on demo_curr.contract_idt = mer.contract_idt
left join chain
on chain.contract_idt = mer.contract_idt
left join merchantattr mattr
on mattr.contract_idt = mer.contract_idt
left join chainattr cattr
on cattr.contract_idt = mer.contract_idt
left join merdemographic mdemo
on mdemo.contract_idt = mer.contract_idt
left join deviceattr dattr
on dattr.contract_idt = dev.contract_idt
where mer.code = 'MERCHANT'
),
final_dump as (
select null as tid
      ,null as merchant_id
      ,null as merchant_name
      ,null as phone
      ,null as address
      ,null as email
      ,null as mcc_id
      ,chain_id
      ,chain_name
      ,organization_id
      ,'Add' as action
from final
where :P_REPORT_TYPE = 'CHAIN'
and (cattr_amnd_flag = 'Y' or mattr_amnd_flag = 'Y')
and role = 'MERCHANT'
group by chain_id
        ,chain_name
        ,organization_id
		
UNION

select 
       null as tid
	  ,merchant_id
      ,merchant_name
      ,phone
      ,address
      ,email
      ,mcc_id
      ,chain_id
      ,chain_name
      ,organization_id
	  ,action
from (
select
       merchant_id
      ,merchant_name
      ,phone
      ,address
      ,email
      ,mcc_id
      ,chain_id
      ,chain_name
      ,organization_id
      ,case
         when mattr_amnd_flag = 'Y'
         then 'Add'
         when mdemo_amnd_flag = 'Y'
         then 'Update'
       end as action
from final
where :P_REPORT_TYPE = 'MERCHANT'
and role = 'MERCHANT'
and ((mdemo_amnd_flag = 'Y' and merchant_open_date <> to_date(:P_BANKING_DATE,'DD-MM-YYYY')) or (mattr_amnd_flag = 'Y'))
)
group by merchant_id
        ,merchant_name
        ,phone
        ,address
        ,email
        ,mcc_id
        ,chain_id
        ,chain_name
        ,organization_id
        ,action

UNION

select tid
      ,merchant_id
      ,merchant_name
      ,phone
      ,address
      ,email
      ,mcc_id
      ,chain_id
      ,chain_name
      ,organization_id
      ,'Add' as action
from final
where :P_REPORT_TYPE = 'TERMINAL'
and role = 'DEVICE'
and (mattr_amnd_flag = 'Y' or (dattr_amnd_flag = 'Y' and merchant_name is not null))
group by tid
        ,merchant_id
        ,merchant_name
        ,phone
        ,address
        ,email
        ,mcc_id
        ,chain_id
        ,chain_name
        ,organization_id
)

select  
        :ORG as org
       ,tid
       ,merchant_id
       ,merchant_name
       ,phone
       ,address
       ,email
       ,mcc_id
       ,chain_id
       ,chain_name
       ,organization_id
       ,action
from final_dump