__version__ = "230224.1" 
__job_name__ = "PyTL_IS_SimpleReports_AQ_IPP_DA_REPORT"
__bat_files__ = []