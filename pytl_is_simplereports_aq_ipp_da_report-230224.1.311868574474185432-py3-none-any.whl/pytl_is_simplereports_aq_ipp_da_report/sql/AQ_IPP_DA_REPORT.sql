/*
* Code for AQ_IPP_DA_REPORT
* PyTL_IS_SimpleReports_AQ_IPP_DA_REPORT = AQ_IPP_DA_REPORT.sql
* Version history:
* 230224.1 : NIBOA-8187 : PrabirK  : Initial development
*/
WITH inst AS (
    SELECT /*+ no_merge materialize */
        code AS inst_code,
        name AS inst_name,
        id   AS inst_id
    FROM
        dwh.dwd_institution
    WHERE
            record_state = 'A'
        AND code = :ORG
), trans_type AS (
    SELECT
        transaction_type_id   AS trans_type_id,
        transaction_type_code AS trans_type_code,
        code                  AS type,
        add_info
    FROM
        dwh.v_dwr_transaction_type
    WHERE
            class_code = 'ACQ_REPORTS'
        AND type_code = 'ENBD_IPP_DA_REPORT'
), trans AS (
    SELECT /*+ no_merge materialize */
        dao.contract_idt,
        dao.doc_idt,
        dao.trans_date,
        dao.contra_ident_number,
        dao.trans_arn,
        dao.auth_code,
        TRIM(dwh.sy_convert.get_tag_value(trt.add_info, 'DIRECTION')) * dao.trans_amount AS trans_amount,
        trt.type,
        dao.banking_date                                                                 date_to,
        dao.banking_date                                                                 date_from
    FROM
             dwf_acq_operation dao
        JOIN inst ON dao.institution_id = inst.inst_id
        JOIN trans_type trt ON dao.transaction_type_id = trt.trans_type_id
    WHERE
        dao.banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
), contract AS (
    SELECT /*+ no_merge materialize */
        cntr.record_idt,
        cntr.parent_contract_idt,
        cntr.personal_account,
        cntr.institution_id,
        NULL AS company_department
    FROM
             dwh.dwd_contract cntr
        JOIN inst ON inst.inst_id = cntr.institution_id
                     AND cntr.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                     AND cntr.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
), chain AS (
    SELECT /*+ no_merge materialize */
        daf.contract_idt,
        MAX(decode(daft.code, 'CHAINID_1', dcl.ident_number, NULL)) AS ident_number
    FROM
             dwd_affiliation daf
        JOIN dwd_affiliation_type daft ON daf.affiliation_type_id = daft.id
                                          AND daft.code = 'CHAINID_1'
                                          AND daft.record_state = 'A'
        JOIN dwd_client           dcl ON daf.affiliated_client_idt = dcl.record_idt
                               AND dcl.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                               AND dcl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    WHERE
            daf.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND daf.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    GROUP BY
        daf.contract_idt
), ova AS (
    SELECT /*+ no_merge materialize */
        decode(ova.delivery_type, 'Email', 'E', 'Fax', 'F',
               'N')    AS delivery_type,
        ova.phone,
        ova.fax,
        ova.first_name AS address_line_1,
        ova.address_line_2,
        ova.address_line_3,
        ova.address_line_4,
        ova.location,
        ova.e_mail,
        ova.contract_idt,
        ova.client_idt,
        ova.address_type_code,
        ova.state
    FROM
             opt_v_address ova
        JOIN inst ON inst.inst_id = ova.institution_id
    WHERE
        ova.address_type_code IN ( 'STMT_ADDR', 'PST_ADDR' )
        AND ova.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND ova.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
), full_q AS (
    SELECT /*+ no_merge materialize */
        merch.personal_account                 AS merchant,
        dev.personal_account                   AS terminal,
        to_char(trans.trans_date, 'DD/MM')     AS trans_date,
        CASE
            WHEN trans.contra_ident_number IS NULL THEN
                '      XXXXXX'
            ELSE
                substr(trans.contra_ident_number, 1, 6)
                || lpad('X', decode(length(TRIM(trans.contra_ident_number)), 13, 3, 14, 4,
                                    15, 5, 16, 6, 17,
                                    7, 18, 8, 19, 9,
                                    3), 'X')
                || substr(trans.contra_ident_number, - 4)
        END                                    AS card_number,
        trans.type                             AS type,
        trans.trans_arn                        AS acq_ref_number,
        trans.auth_code,
        trans.trans_amount,
        NULL                                   AS disc_amount,
        NULL                                   AS disc_type,
        NULL                                   AS trans_fee,
        NULL                                   AS vat_amount,
        inst.inst_name,
        nvl(merch.company_department, '00000') AS agent_code,  --- need to check
        ova.delivery_type                      AS delivery_type, --- need to check
        ova.address_line_1,
        ova.address_line_2,
        ova.address_line_3,
        ova.address_line_4,
        ova.phone,
        ova.fax,
        ova.e_mail,
        nvl(chain.ident_number, '000000000')   AS ident_number,
        trans.date_to,
        trans.date_from,
        trans.doc_idt
    FROM
             contract dev
        JOIN contract merch ON dev.parent_contract_idt = merch.record_idt
        JOIN inst ON dev.institution_id = inst.inst_id
        JOIN trans ON dev.record_idt = trans.contract_idt
        LEFT JOIN ova ON dev.parent_contract_idt = ova.contract_idt
                         AND address_type_code = 'STMT_ADDR'
        LEFT JOIN chain ON dev.parent_contract_idt = chain.contract_idt
), totals AS (
    SELECT /*+ no_merge materialize */
        merchant,
        COUNT(doc_idt)    AS total_num_pos,
        SUM(trans_amount) AS total_pos,
        0                 AS total_comm,
        0                 AS total_vat,
        0                 AS total_fee,
        0                 AS total_adj,
        0                 AS total_cbk,
        0                 AS total_fraud,
        0                 AS total_cash,
        0                 AS total_rebate,
        0                 AS total_emi_rec_h
    FROM
        full_q
    GROUP BY
        merchant
)
SELECT
    *
FROM
    (
        SELECT
            merchant,
            summ,
            orderby,
            rec_order,
            ROWNUM AS rn
        FROM
            (
                SELECT
                    merchant,
                    2                                                                                                                                         AS
                    rec_order,
                    2                                                                                                                                         AS
                    orderby,
                    rpad(nvl(to_char(trans_date), ' '), 5, ' ')
                    || ' '
                    || rpad(nvl(terminal, ' '), 8, ' ')
                    || ' '
                    || rpad(nvl(
                        CASE
                            WHEN card_number IS NULL THEN
                                '      XXXXXX'
                            ELSE
                                substr(card_number, 1, 6)
                                || lpad('X', decode(length(TRIM(card_number)), 13, 3, 14, 4,
                                                    15, 5, 16, 6, 17,
                                                    7, 18, 8, 19, 9,
                                                    3), 'X')
                                || substr(card_number, - 4)
                        END, ' '), 13, ' ')
                    || ' '
                    || rpad(nvl(type, ' '), 15, ' ')
                    || ' '
                    || rpad(nvl(acq_ref_number, ' '), 23, ' ')
                    || ' '
                    || rpad(nvl(auth_code, ' '), 6, ' ')
                    || ' '
                    || lpad(TRIM(to_char((trans_amount), '999999999990.99')), 11, ' ')
                    || ' '
                    || lpad(TRIM(to_char(nvl(disc_amount, 0), '999999999990.99')), 11, ' ')
                    || ' '
                    || rpad(nvl(disc_type, ' '), 9, ' ')
                    || ' '
                    || lpad(TRIM(to_char(nvl(trans_fee, 0), '999999999990.99')), 11, ' ')
                    || ' '
                    || lpad(TRIM(to_char(nvl(vat_amount, 0), '999999999990.99')), 11, ' ')
                    || ' '
                    || lpad(TRIM(to_char((nvl(trans_amount, 0) + nvl(trans_fee, 0) + nvl(disc_amount, 0) + nvl(vat_amount, 0)), '999999999990.99')),
                    11, ' ') AS summ
                FROM
                    full_q
                ORDER BY
                    terminal NULLS LAST,
                    acq_ref_number NULLS LAST,
                    disc_type NULLS LAST,
                    type
            )
        UNION ALL
        SELECT
            merchant,
            lpad('-', 147, '-')
            || CHR(13)
            || CHR(10)
            || '  GRAND TOTAL OF POS TRANSACTIONS :             '
            || lpad(TRIM(lpad(nvl(total_num_pos, 0), 5, 0)), 18, ' ')
            || CHR(13)
            || CHR(10)
            || '  GRAND TOTAL VALUE OF POS TRANSACTIONS :       '
            || lpad(TRIM(to_char(nvl(total_pos, 0), '999999999990.99')), 18, ' ')
            || CHR(13)
            || CHR(10)
            || '  GRAND TOTAL VALUE OF COMMISSION :             '
            || lpad(TRIM(to_char(nvl(total_comm, 0), '999999999990.99')), 18, ' ')
            || CHR(13)
            || CHR(10)
            || '  GRAND TOTAL VALUE OF VAT :                    '
            || lpad(TRIM(to_char(nvl(total_vat, 0), '999999999990.99')), 18, ' ')
            || CHR(13)
            || CHR(10)
            || '  GRAND TOTAL VALUE OF FEE TRANSACTIONS :       '
            || lpad(TRIM(to_char(nvl(total_fee, 0), '999999999990.99')), 18, ' ')
            || CHR(13)
            || CHR(10)
            || '  GRAND TOTAL VALUE OF ADJUSTMENT TRANSACTIONS :'
            || lpad(TRIM(to_char(nvl(total_adj, 0), '999999999990.99')), 18, ' ')
            || CHR(13)
            || CHR(10)
            || '  VALUE OF CHARGEBACK TRANSACTIONS :            '
            || lpad(TRIM(to_char(nvl(total_cbk, 0), '999999999990.99')), 18, ' ')
            || CHR(13)
            || CHR(10)
            || '  VALUE OF SUSPENDED TRANSACTIONS :             '
            || lpad(TRIM(to_char(nvl(total_fraud, 0), '999999999990.99')), 18, ' ')
            || CHR(13)
            || CHR(10)
            || '  GRAND TOTAL OF CASH (PWCB):                   '
            || lpad(TRIM(to_char(nvl(total_cash, 0), '999999999990.99')), 18, ' ')
            || CHR(13)
            || CHR(10)
            || '  GRAND TOTAL OF REBATE :                       '
            || lpad(TRIM(to_char(nvl(total_rebate, 0), '999999999990.99')), 18, ' ')
            || CHR(13)
            || CHR(10)
            || '  LOAN INSTALLMENT RECOVERY:                    '
            || lpad(TRIM(to_char(nvl(total_emi_rec_h, 0), '999999999990.99')), 18, ' ')
            || CHR(13)
            || CHR(10)
            || lpad('-', 70, '-')
            || CHR(13)
            || CHR(10)
            || 'NET PAYABLE / RECEIVABLE                        '
            || lpad(TRIM(to_char(nvl(total_pos + total_comm + total_vat + total_fee + total_adj + total_cbk + total_fraud + total_cash +
            total_rebate + total_emi_rec_h, 0), '999999999990.99')), 18, ' ')
            || CHR(13)
            || CHR(10)
            || lpad('-', 70, '-')
            || CHR(13)
            || CHR(10)
            || 'END OF REPORT',
            5 orderby,
            1 AS rec_order,
            1 AS rn
        FROM
            totals
        UNION ALL
        SELECT
            merchant,
            lpad(' ', 55, ' ')
            || upper(MAX(inst_name))
            || CHR(13)
            || CHR(10)
            || '                                                   MERCHANT TRANSACTION ACTIVITY                                       PAGE'
            || lpad(DENSE_RANK()
                    OVER(
                ORDER BY
                    merchant
                    ), 9, ' ')
            || CHR(13)
            || CHR(10)
            || '                                                       COMPUTERISED FAX/EMAIL     ('
            || MAX(delivery_type)
            || ')            PROC DATE '
            || to_char(sysdate, 'DD/MM/YYYY')
            || '  TIME '
            || to_char(systimestamp, 'HH.MI.SS')
            || CHR(13)
            || CHR(10)
            || '  MERCHANT NO :  '
            || rpad(merchant, 95, ' ')
            || 'AGENT CODE '
            || MAX(agent_code)
            || CHR(13)
            || CHR(10)
            || '  ADDRESS     :  '
            || rpad(coalesce(MAX(address_line_1), 'NA'), 92, ' ')
            || 'PHONE '
            || nvl(MAX(phone), 'NA')
            || CHR(13)
            || CHR(10)
            || '                 '
            || rpad(coalesce(MAX(address_line_2), 'NA'), 92, ' ')
            || 'FAX   '
            || coalesce(MAX(fax), 'NA')
            || CHR(13)
            || CHR(10)
            || '                 '
            || coalesce(MAX(address_line_3), 'NA')
            || CHR(13)
            || CHR(10)
            || '                 '
            || rpad(coalesce(MAX(address_line_4), 'NA'), 80, ' ')
            || CHR(13)
            || CHR(10)
            || '  EMAIL       :  '
            || coalesce(MAX(e_mail), 'NA')
            || CHR(13)
            || CHR(10)
            || '  CHAIN ID    :  '
            || rpad(MAX(ident_number), 24, ' ')
            || 'MERCHANT TRANSACTION ACTIVITY FROM '
            || to_char(MAX(date_from), 'DD/MM/YYYY')
            || ' TO '
            || to_char(MAX(date_to), 'DD/MM/YYYY')
            || CHR(13)
            || CHR(10)
            || lpad('-', 147, '-')
            || CHR(13)
            || CHR(10)
            || 'DTOF   TRMNL   CARD NUMBER       TYPE         ACQ REF NBR              AUTH      TRAN         DISC   DISC            TXN         VAT        NET'
            || CHR(13)
            || CHR(10)
            || 'TRN    ID                                                              CODE       AMT         AMT    TYPE            FEE         AMT        AMT'
            || CHR(13)
            || CHR(10)
            || lpad('-', 147, '-'),
            1 AS orderby,
            1 AS rec_order,
            1 AS rn
        FROM
            full_q
        GROUP BY
            merchant
    )
ORDER BY
    merchant,
    orderby,
    rec_order,
    rn