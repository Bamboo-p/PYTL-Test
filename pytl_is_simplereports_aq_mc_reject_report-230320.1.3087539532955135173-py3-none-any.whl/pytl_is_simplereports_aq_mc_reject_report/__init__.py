__version__ = "230320.1" 
__job_name__ = "PyTL_IS_SimpleReports_AQ_MC_REJECT_REPORT"
__bat_files__ = []