/*
* Code for AQ_MC_REJECT_REPORT
* PyTL_IS_SimpleReports_AQ_MC_REJECT_REPORT = AQ_MC_REJECT_REPORT.sql
* Version history:
* 20221017.1 : NIBOA-7882 : PrabirK  : Initial development
* 20221207.1 : NIBOA-7882 : Padala.Kumar  : Added OWS as prefix to the table name
* 20221220.1 : NIBOA-8047 : PrabirK  : SQL Code changes
* 20221223.1 : NIBOA-8047 : PrabirK  : Added OWS as prefix to currency table
* 20230309.1 : NIBOA-8280 : PrabirK  : Formatting the field to handle comma for REASON_CODE
* 20230320.1 : NIBOA-8280 : PrabirK  : Changing SQL code to fetch data for all FIs
*/
WITH inst AS (
    SELECT /*+ no_merge materialize */
        id,
        bank_code org,
        name
    FROM
        ows.f_i
    WHERE
            amnd_state = 'A'
        AND bank_code IN (
            SELECT
                TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL
        )
)
SELECT /*+ parallel(rdoc,8) */
    inst.org,
	-- [*][begin] 20221220.1 = PrabirK = NIBOA-8047
    (
        SELECT
            rtt.name
        FROM
            ows.trans_type rtt
        WHERE
                rtt.id = rdoc.trans_type
            AND rtt.amnd_state = 'A'
    ) AS trans_type,
    '"'||(
     SELECT 
         hbook.name
     FROM 
         ows.sy_std_handbook hbook 
     WHERE 
             hbook.amnd_state = 'A' 
         AND hbook.group_code = 'DOC_REJECT_REASON' 
         AND hbook.filter2 = rdoc.rej_data
         AND hbook.code = rdoc.reason_code
     )||'"' AS reason_code, -- [*] 20230309.1 = PrabirK = NIBOA-8280
    rdoc.reason_details,
    rdoc.source_number,
    CASE
     WHEN rdoc.target_number IS NULL THEN ' ' -- [*] 20230320.1 = PrabirK = NIBOA-8280
     ELSE SUBSTR(rdoc.target_number,1,6)
           || lpad('X',DECODE(length(trim(rdoc.target_number)),13,3,14,4,15,5,16,6,17,7,18,8,19,9,3),'X')
           || SUBSTR(rdoc.target_number,-4)
    END AS target_number,
    '="'||rdoc.acq_ref_number||'"' AS acq_ref_number,
    (
        SELECT
            finfo.file_name
        FROM
            ows.file_info finfo
        WHERE
            finfo.id = rdoc.file_info__id
    ) AS file_info,
    rdoc.file_id,
    rdoc.batch_id,
    '="'||rdoc.message_id||'"' AS message_id,
    (
        SELECT
            tt.name
        FROM
            ows.trans_type tt
        WHERE
                tt.id = rdoc.prev_trans_type
            AND tt.amnd_state = 'A'
    ) AS prev_trans_type,
    rdoc.request_category,
    '="'||trim(to_char(rdoc.trans_amount, '999999999990.99'))||'"' AS trans_amount,
    (select curr.name from ows.currency curr where curr.amnd_state = 'A' and curr.code = rdoc.trans_curr) AS trans_curr, -- [*] 20221223.1 = PrabirK = NIBOA-8047
    '="'||trim(to_char(rdoc.recons_amount, '999999999990.99'))||'"' AS recons_amount,
    (select curr.name from ows.currency curr where curr.amnd_state = 'A' and curr.code = rdoc.recons_curr) AS recons_curr, -- [*] 20221223.1 = PrabirK = NIBOA-8047
	-- [*][end] 20221220.1 = PrabirK = NIBOA-8047
    rdoc.creation_date,
    rdoc.outward_status
FROM
    -- [*][begin] 20230320.1 = PrabirK = NIBOA-8280
    inst
    LEFT JOIN (
        SELECT
            acnt.f_i,
            rdoc.trans_type,
            rdoc.rej_data,
            rdoc.reason_code,
            rdoc.reason_details,
            rdoc.source_number,
            rdoc.target_number,
            rdoc.acq_ref_number,
            rdoc.file_info__id,
            rdoc.file_id,
            rdoc.batch_id,
            rdoc.message_id,
            rdoc.prev_trans_type,
            rdoc.request_category,
            rdoc.trans_amount,
            rdoc.trans_curr,
            rdoc.recons_amount,
            rdoc.recons_curr,
            rdoc.creation_date,
            rdoc.outward_status
        FROM
                 ows.reject_doc    rdoc
            JOIN ows.doc           doc ON rdoc.doc__id = doc.id
            JOIN ows.acnt_contract acnt ON doc.merchant_id = acnt.contract_number
                                           AND acnt.amnd_state = 'A'
        WHERE
                rdoc.creation_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
            AND rdoc.channel = 'E'
            AND rdoc.reason_code != '0362'
            AND rdoc.outward_status NOT IN ( 'N', 'S' )
    ) rdoc ON rdoc.f_i = inst.id
	-- [*][end] 20230320.1 = PrabirK = NIBOA-8280