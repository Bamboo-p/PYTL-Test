/*
* Code for AQ_MERCHANT_ON_BOARDING_EP_FILE.sql
* PyTL_IS_SimpleReports_AQ_MERCHANT_ON_BOARDING_EP_FILE.sql = AQ_MERCHANT_ON_BOARDING_EP_FILE.sql.sql
* Version history:
* 231011.1 : ENBD-25171 : PadalaS  : Initial development
* 231026.1 : ENBD-25171 : PadalaS  : Updated POS & ECOM values wrt way4
* 231027.1 : ENBDA-245  : PadalaS  : Updated SQL code to fetch only MID details and updated logic for ECOM & POS
* 231030.1 : ENBDA-245  : PadalaS  : Updated SQL code to fetch records based on date_open
* 231107.1 : ENBDA-247  : PadalaS  : Updated SQL code to be in sync with amendment - added additional 2 pipes for BNPL changes
* 240327.1 : NIBOA-9858 : PadalaS  : Updated SQL code to include ACQ_INSTPP_FLAG classifier
* 240327.2 : NIBOA-9858 : PadalaS  : Updated classifier code to ACQ_VISA_INST_FEE_FLAG
* 240416.1 : NIBOA-9959 : PrabirK  : Modified SQL code to incorporate VISA Installment flag
* 240416.2 : NIBOA-9959 : PrabirK  : FIID addition
* 240417.1 : NIBOA-9959 : PrabirK  : Adding date range for contract table
* 240429.1 : NIINT-4969 : PrabirK  : Updated Contract add info tag ORIG_MERCH_COUNTRY
* 240430.1 : NIBOA-10004: Khader   : Updated SQL code to fetch Money send new required fields
*/
select
:ORG as ORG,
'EP|A|' || RETAILER_ID || '|' ||
:FIID
||'|N|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||N||||||||||||||||||||||||||||||||||||||||||||10|11|12|14|21||||||||||||||||3|D|B|' || PREAUTH_DEST ||'|'|| POSTAUTH_DEST ||'|||'||ACQ_VISA_INST_FEE_FLAG ||'|'||'|'|| ORIG_MERCH_COUNTRY ||'|'||MC_MONEY_SEND_EN||'|'||MC_MONEY_SEND_TTI||'|'||MC_MONEY_SEND_MCC||'|'||MC_MONEY_SEND_DB_FLG||'|'||MC_MONEY_SEND_CR_FLG||'|'||MC_MONEY_SEND_PP_FLG||'|'||MC_MONEY_SEND_TXN_PTH||'|' as EP_Record
from (
with inst as (
select /*+ no_merge materialize */
id, code, name
from dwh.dwd_institution
where record_state = 'A'
  and code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
               from dual
               connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
               )
)
, contracts as (
select /*+ no_merge use_hash(attr cn) use_nl(cn inst) */
       inst.code as bank_code,
       cn.personal_account,
       cn.record_idt,
       cn.date_open,
       cn.parent_contract_idt,
       attr.mer_code,
       attr.acq_visa_inst_fee_flag,
       NVL(substr(cn.add_info, instr(cn.add_info, 'ECOMM_IDT=')+10, (instr(cn.add_info, ';', instr(cn.add_info, 'ECOMM_IDT='))-instr(cn.add_info, 'ECOMM_IDT=')-10)), 'NA') as ECOMM_IDT,
       NVL(substr(cn.add_info, instr(cn.add_info, 'AEMO=')+5, (instr(cn.add_info, ';', instr(cn.add_info, 'AEMO='))-instr(cn.add_info, 'AEMO=')-5)), 'NA') as DOB_AEMO,
       case when cn.date_open = to_date(:P_REPORT_DATE, 'dd-mm-yyyy') then 'Y' else 'N' end amnd_flag,
       (select c.name from dwd_currency c where c.code = cn.base_currency and c.record_state = 'A') as currency,
	   substr(cn.add_info, instr(cn.add_info, 'ORIG_MERCH_COUNTRY=')+19, (instr(cn.add_info, ';', instr(cn.add_info, 'ORIG_MERCH_COUNTRY='))-instr(cn.add_info, 'ORIG_MERCH_COUNTRY=')-19)) as ORIG_MERCH_COUNTRY
from dwh.dwd_contract cn
join inst on inst.id = cn.institution_id
join (select /*+ no_merge use_hash(dca da) */
       dca.contract_idt,
       max(case when da.type_code = 'ACQ_LVL' then da.code else null end) as mer_code,
       max(case when da.type_code = 'ACQ_VISA_INST_FEE_FLAG' then da.code else null end) as acq_visa_inst_fee_flag
from dwh.dwa_contract_attribute dca
join dwh.dwd_attribute da
on da.id = dca.attr_id
and da.type_code in ('ACQ_LVL','ACQ_VISA_INST_FEE_FLAG' )
and da.record_date_from <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
and da.record_date_to >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
where dca.attr_date_from <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
and dca.attr_date_to >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
group by dca.contract_idt) attr
on attr.contract_idt = cn.record_idt
where to_date(:P_REPORT_DATE, 'dd-mm-yyyy') BETWEEN cn.record_date_from AND cn.record_date_to
and cn.record_state <> 'C'
)
select /*+ no_merge */
/* merchant level */
mer.PERSONAL_ACCOUNT as RETAILER_ID,
mer.date_open as date_open,
nvl(mer.ACQ_VISA_INST_FEE_FLAG,'N') as ACQ_VISA_INST_FEE_FLAG,
case
  when mer.bank_code = '200' then 'Q6-BRPR'
  when mer.bank_code = '454' then 'Q2-BRPR'
  when mer.bank_code in ('210','201','209','213','202','203','204','205','207','208') then 'Q5-BRPR'
  when mer.bank_code in ('221','459') then 'Q7-BRPR'
  else ''
end as PREAUTH_DEST, --[+] This field would have default value's based on FI
case
  when mer.bank_code = '200' then 'Q6-BRPO'
  when mer.bank_code = '454' then 'Q2-BRPO'
  when mer.bank_code in ('210','201','209','213','202','203','204','205','207','208') then 'Q5-BRPO'
  when mer.bank_code in ('221','459') then 'Q7-BRPO'
  else ''
end as POSTAUTH_DEST, --[+] This field would have default value's based on FI
mer.ORIG_MERCH_COUNTRY,
null MC_MONEY_SEND_EN, 
null MC_MONEY_SEND_TTI,
null MC_MONEY_SEND_MCC,
null MC_MONEY_SEND_DB_FLG,
null MC_MONEY_SEND_CR_FLG,
null MC_MONEY_SEND_PP_FLG,
null MC_MONEY_SEND_TXN_PTH
from contracts mer
    where mer.mer_code = 'MERCHANT'
    AND 1 = (case
            when :IS_POS = 'Y'
             AND mer.ECOMM_IDT = 'NGPOS'
            then 1
            when :IS_POS = 'N'
             AND mer.ECOMM_IDT = 'NGECOM'
            then 1
           end
       )
  AND mer.DOB_AEMO != 'Y'
  )
where date_open = to_date(:P_REPORT_DATE, 'dd-mm-yyyy')