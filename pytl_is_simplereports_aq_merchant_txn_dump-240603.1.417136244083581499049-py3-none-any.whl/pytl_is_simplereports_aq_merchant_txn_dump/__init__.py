__version__ = "240603.1"
__job_name__ = "PyTL_IS_SimpleReports_AQ_MERCHANT_TXN_DUMP"
__bat_files__ = ["PyTL_AQ_MERCHANT_TXN_DUMP.bat"]

