__version__ = "220926.1"
__job_name__ = "PyTL_IS_SimpleReports_AQ_NEW_PARAMETER_FILE"
__bat_files__ = []

