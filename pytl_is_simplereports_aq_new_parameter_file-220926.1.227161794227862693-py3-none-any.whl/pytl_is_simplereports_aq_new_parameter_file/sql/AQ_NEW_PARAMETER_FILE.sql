/*
* Code for AQ_NEW_PARAMETER_FILE
* PyTL_IS_SimpleReports_AQ_NEW_PARAMETER_FILE = AQ_NEW_PARAMETER_FILE.sql
* Version history:
* 20220830.1 : NIBOA-7684 : RakeshG  : Initial development
*/

WITH 
subquery_inst AS (
          SELECT /*+ no_merge materialize */
                 id,
                 name,
                 code
            FROM dwh.DWD_INSTITUTION
           WHERE code = :ORG
             AND record_state = 'A'
),  
subquery_chains AS (
            SELECT /*+ no_merge materialize leading(inst dft dach dc) index_combine(dach DWD_AFFL_INST_IDX DWD_AFFL_TYPE_IDX) */
                   dach.contract_idt,
                   dc.ident_number as chainid 
              FROM dwh.DWD_AFFILIATION dach
              JOIN subquery_inst inst ON dach.institution_id = inst.id
              JOIN dwh.DWD_AFFILIATION_TYPE dft ON dach.affiliation_type_id = dft.id
                                      AND dft.code = 'CHAINID_3'
                                      AND dach.record_state != 'C'
                                      AND dft.record_state != 'C'
                                      AND to_date(:P_REPORT_DATE, 'dd-mm-yyyy') BETWEEN dach.record_date_from AND dach.record_date_to
                                      AND to_date(:P_REPORT_DATE, 'dd-mm-yyyy') BETWEEN dft.record_date_from  AND dft.record_date_to
              JOIN dwh.DWD_CLIENT dc ON dc.record_idt = dach.affiliated_client_idt
                                    AND dc.record_state != 'C'
                                    AND to_date(:P_REPORT_DATE, 'dd-mm-yyyy') BETWEEN dc.record_date_from AND dc.record_date_to
             WHERE instr(dc.add_info, 'CHAIN_GROUPS_CODE=REFERRAL;') > 0
), 
subquery_addr AS (
          SELECT /*+ no_merge */
                 c.contract_idt,
                 da.address_line_1
            FROM subquery_chains c
            JOIN dwd_contract_address da ON c.contract_idt = da.contract_idt
                                     AND to_date(:P_REPORT_DATE, 'dd-mm-yyyy') BETWEEN da.record_date_from AND da.record_date_to
                                     AND da.record_state <> 'C'
            JOIN dwd_address_type dat ON da.address_type_id = dat.id
                                  AND dat.code = 'STMT_ADDR'
),
subquery_tar AS (
         SELECT	/*+ no_merge */
                t.domain                                                       AS contract_idt,
                MAX(decode(t.type_code, 'ACQ_PSP_DOM', st.fee_rate_value, 0))  AS acq_psp_dom,
                MAX(decode(t.type_code, 'ACQ_PSP_INT', st.fee_rate_value, 0))  AS acq_psp_int,
                MAX(decode(t.type_code, 'ACQ_PSP_FIX', st.fee_base_amount, 0)) AS acq_psp_fix
           FROM dwh.DWD_TARIFF t
           JOIN dwh.DWD_SERVICE_TARIFF st ON st.record_idt = t.record_idt
                                         AND TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy') BETWEEN st.record_date_from AND st.record_date_to
                                         AND st.record_state != 'C'
           where t.record_state != 'C'
             AND t.role = 'SERVICE'
             AND t.type_code IN ( 'ACQ_PSP_DOM', 'ACQ_PSP_INT', 'ACQ_PSP_FIX' )
             AND TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy') BETWEEN t.record_date_from AND t.record_date_to
       GROUP BY t.domain
)
, subquery_contracts AS (
        SELECT /*+ no_merge materialize leading(inst cntr attr cattr) use_nl(attr cattr) index(cattr DWA_CNTR_ATTR_DATE_TO_IDX) */
               inst.code AS org,
               cntr.record_idt,
               cntr.personal_account,
               cntr.base_currency,
               substr(cntr.add_info, instr(cntr.add_info, 'ACQ_PSP_NAME=') + 13,(instr(cntr.add_info, ';', instr(cntr.add_info,'ACQ_PSP_NAME=')) -   instr(cntr.add_info, 'ACQ_PSP_NAME=') - 13)) AS psp_name,
               tar.contract_idt,
               tar.acq_psp_dom,
               tar.acq_psp_int,
               tar.acq_psp_fix
          FROM dwh.DWD_CONTRACT cntr
          JOIN subquery_inst inst ON inst.id = cntr.institution_id     
          JOIN dwh.DWA_CONTRACT_ATTRIBUTE cattr ON cntr.record_idt = cattr.contract_idt
                                               AND cattr.active_state = 'A'
                                               AND to_date(:P_REPORT_DATE, 'dd-mm-yyyy') BETWEEN cattr.attr_date_from AND cattr.attr_date_to
          JOIN dwh.DWD_ATTRIBUTE attr ON attr.id = cattr.attr_id
                                     AND to_date(:P_REPORT_DATE, 'dd-mm-yyyy') BETWEEN attr.record_date_from AND attr.record_date_to
                                     AND attr.type_code = 'ACQ_LVL'
                                     AND attr.code = 'MERCHANT'
     LEFT JOIN subquery_tar tar  ON tar.contract_idt = cntr.personal_account
         WHERE to_date(:P_REPORT_DATE, 'dd-mm-yyyy') BETWEEN cntr.record_date_from AND cntr.record_date_to
           AND cntr.record_state != 'C'
)
        SELECT /*+ leading(ch cn) use_hash(ch cn) */
               cn.org              AS ORG,
               cn.psp_name         AS psp_partner_name,
               ch.chainid          AS psp_chainid,
               cn.org              AS FI,
               cn.personal_account AS MID,
               c.name              AS currency,
               addr.address_line_1 AS merchant_name,
               cn.acq_psp_dom      AS psp_margin_dom,
               cn.acq_psp_int      AS psp_margin_int,
               cn.acq_psp_fix      AS psp_margin_fix    
          FROM subquery_chains ch
          JOIN subquery_contracts cn ON ch.contract_idt = cn.record_idt
     LEFT JOIN subquery_addr addr ON addr.contract_idt = cn.record_idt
     left join dwh.DWD_CURRENCY c on c.code = cn.base_currency and c.recorD_state = 'A'