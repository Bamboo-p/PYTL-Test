/*
* NIBO REFUND REPORT
*
* Version history:
* 221109.1 = RabindraSi = NIBOA-7879 : Initial Version
* 221206.2 = RabindraSi = NIBOA-8030 : Added new column serial number and PG_NO will get fetched for PTLF and NGEN
* 221209.3 = RabindraSi = NIBOA-8030 : data format update to make it compatible with CSV
* 230913.4 = Aleksandr Podrezov = PRD-24549  : Refactoring and performance tuning
* 230915.5 = RabindraSi  =  NIBOA-8818  : Added DCC Credit and DCC Retail Reversal to the extract
*/
WITH inst AS
  (SELECT
    /*+ no_merge */
    ID, CODE
  FROM dwd_institution
  WHERE record_state = 'A'
  AND code = :ORG
  ),
chains AS
  (SELECT    
    /*+ no_merge leading(dach dft dc) full(dach) full(dft) use_hash(dft) swap_join_inputs(dft) use_nl(dc) use_hash(inst) swap_join_inputs(inst)*/
    dach.contract_idt,
    dc.ident_number, --221206.2
    max(SUBSTR(dc.add_info, instr(dc.add_info, 'CHAIN_GROUPS_CODE=')+18, (instr(dc.add_info, ';', instr(dc.add_info, 'CHAIN_GROUPS_CODE='))-instr(dc.add_info, 'CHAIN_GROUPS_CODE=')-18))) as chain_group,
    max(SUBSTR(dc.add_info, instr(dc.add_info, 'CHAIN_REFUND_FLAG=')+18, (instr(dc.add_info, ';', instr(dc.add_info, 'CHAIN_REFUND_FLAG='))-instr(dc.add_info, 'CHAIN_REFUND_FLAG=')-18))) as refund_flag -- 221206.2
  FROM dwd_affiliation dach
  JOIN dwd_affiliation_type dft
  ON dach.affiliation_type_id = dft.ID
  AND dft.code IN ('CHAINID_1','CHAINID_2') 
  AND dft.record_state != 'C' 
  AND to_date(:P_REPORT_DATE,'dd-mm-yyyy') BETWEEN dft.record_date_from AND dft.record_date_to
  JOIN dwd_client dc
  ON dc.record_idt = dach.affiliated_client_idt
  AND dc.record_state != 'C'  
  AND to_date(:P_REPORT_DATE,'dd-mm-yyyy') BETWEEN dc.record_date_from AND dc.record_date_to
  AND SUBSTR(dc.add_info, instr(dc.add_info, 'CHAIN_REFUND_FLAG=')+18, (instr(dc.add_info, ';', instr(dc.add_info, 'CHAIN_REFUND_FLAG='))-instr(dc.add_info, 'CHAIN_REFUND_FLAG=')-18)) = 'Y'
  JOIN inst
  ON inst.ID = dc.institution_id  
  WHERE  
      to_date(:P_REPORT_DATE,'dd-mm-yyyy') BETWEEN dach.record_date_from AND dach.record_date_to
      AND dach.record_state != 'C'
  group by dach.contract_idt, dc.ident_number --221206.2
  )
 ,cntr AS
  (SELECT /*+ materialize use_hash(da) swap_join_inputs(da) use_hash(ch) swap_join_inputs(ch) use_nl(cntr) use_hash(inst) swap_join_inputs(inst) leading(dca da cntr)*/
    cntr.personal_account,
    cntr.record_idt,
    decode(da.code, 'MERCHANT', cntr.record_idt, 'DEVICE', cntr.parent_contract_idt) as contract_idt,
    cntr.parent_contract_idt,
    cntr.base_currency,
    da.code,
    ch.ident_number,
    ch.chain_group,
    ch.refund_flag
   FROM dwa_contract_attribute dca
   JOIN 
    (
         select 
              /*+ no_merge full(attr)*/
              attr.id,
			  attr.code
         from 
              dwd_attribute attr
         where 
            to_date(:P_REPORT_DATE,'dd-mm-yyyy') BETWEEN attr.record_date_from AND attr.record_date_to
            AND attr.type_code     = 'ACQ_LVL'
            AND attr.code          IN ('MERCHANT', 'DEVICE')
            AND attr.record_state != 'C'           
    ) da
	ON da.id = dca.attr_id  
    JOIN dwd_contract cntr
    ON cntr.record_idt = dca.contract_idt
      AND to_date(:P_REPORT_DATE,'dd-mm-yyyy') BETWEEN cntr.record_date_from AND cntr.record_date_to
      AND cntr.record_state != 'C'
    JOIN inst
    ON inst.id = cntr.institution_id
    LEFT JOIN chains ch
    ON ch.contract_idt = cntr.record_idt
    WHERE to_date(:P_REPORT_DATE,'dd-mm-yyyy') BETWEEN dca.attr_date_from AND dca.attr_date_to
    AND dca.active_state = 'A'
)
,trans_type as
(select /*+ no_merge full(dtt)*/
        dtt.id,
        dtt.name as txn_name,
        dtt.code as txn_code,
        case 
          when dtt.code in ('R1-R','K1-R','DCCR1-R','DCCK1-R') then 'REVERSE'
          when dtt.code in ('K1-P','DCCK1-P') then 'REFUND'
          when dtt.code in ('R1-P','DCCR1-P') then 'SALE'
        end txn_code_group
  from dwd_transaction_type dtt
  where dtt.record_state = 'A'
  and dtt.code in ('R1-R','K1-R','K1-P','R1-P','DCCR1-R','DCCR1-P','DCCK1-R','DCCK1-P')                  
),
trans as
(select /*+ no_merge full(dt) use_hash(i) swap_join_inputs(i) use_hash(tt) swap_join_inputs(tt) */
        dt.doc_idt,
        dt.source_contract_idt, 
        dt.target_contract_idt,
        dt.target_number, 
        dt.source_number,
        dt.trans_rrn,
        dt.trans_arn,
        trunc(dt.trans_date) as trans_date,
        dt.trans_amount,
        dt.banking_date,
        dt.direction,
        dt.auth_code,
        REPLACE(REPLACE(SUBSTR(dt.add_info, instr(dt.add_info, 'ACQ_PRD_1=')+10, (instr(dt.add_info, ';', instr(dt.add_info, 'ACQ_PRD_1='))-instr(dt.add_info, 'ACQ_PRD_1=')-10)), chr(10)), chr(13)) as acquirer_data,
        case 
         when instr(dt.add_info, 'PTLF=Y;') > 0
         and SUBSTR(dt.add_info, instr(dt.add_info, 'SOURCE_FIID=')+12, (instr(dt.add_info, ';', instr(dt.add_info, 'SOURCE_FIID='))-instr(dt.add_info, 'SOURCE_FIID=')-12)) = 'NGEN'
  	     then 'NGEN'
  	     when instr(dt.add_info, 'MIGS=Y;') > 0
  	     then 'COMTRUST'
  	     when instr(dt.add_info, 'DP_PORTAL=Y;') > 0
  	     then 'DP_PORTAL'
         when instr(dt.add_info, 'TDE=Y;') > 0
  	     then 'MANUAL'
         else 'N/A'
  	    end as sale_txn_source,
        case 
         when instr(dt.add_info, 'PTLF=Y;') > 0
         then 'NGEN'
         when instr(dt.add_info, 'MIGS=Y;') > 0
         then 'COMTRUST'
         when instr(dt.add_info, 'DP_PORTAL=Y;') > 0
         then 'DP_PORTAL'
         when instr(dt.add_info, 'TDE=Y;') > 0
         then 'MANUAL'
         else 'N/A'
        end as refund_txn_source,
        tt.txn_name,
        tt.txn_code,
        tt.txn_code_group
 from dwf_transaction dt
 join inst i
 on i.id = dt.institution_id
 join (select /*+ no_merge*/ * from trans_type tt where tt.txn_code in ('R1-R','K1-R','K1-P','R1-P','DCCR1-R','DCCR1-P','DCCK1-R','DCCK1-P')) tt
    on tt.id = dt.transaction_type_id 
 where 
    dt.banking_date >= (to_date(:P_REPORT_DATE,'dd-mm-yyyy') - :P_DAYS_AGO)
    and dt.banking_date < to_date(:P_REPORT_DATE,'dd-mm-yyyy')
)
,view_contr as
(
SELECT /*+materialize leading(cntr) use_hash(dev)*/
       cntr.personal_account as merchant_number,
       cntr.record_idt as contract_idt,
       cntr.chain_group,
       cntr.ident_number as chain_id,       
       dev.record_idt       
FROM cntr
JOIN cntr dev
ON dev.contract_idt = cntr.record_idt
WHERE cntr.code = 'MERCHANT'
  and cntr.ident_number is not null
)
,trans_refund as
(SELECT /*+ materialize use_hash(cntr) swap_join_inputs(cntr)*/
       cntr.merchant_number,
       cntr.contract_idt,
       cntr.chain_group,
       cntr.chain_id,
       tr.doc_idt,
       DECODE(cntr.record_idt, tr.source_contract_idt, tr.target_number, tr.source_number) AS card_number,
       tr.txn_name,
       tr.txn_code,
       tr.txn_code_group,
       tr.trans_rrn,
       tr.trans_arn,
       tr.trans_date,
       tr.trans_amount,
       tr.banking_date,
       tr.direction,
       tr.auth_code,
       tr.acquirer_data,
       tr.refund_txn_source as txn_source
FROM view_contr cntr
JOIN (select /*+ no_merge*/ * from trans tr where tr.txn_code in ('R1-R','K1-R','K1-P','DCCR1-R','DCCK1-R','DCCK1-P')) tr
ON (cntr.record_idt = tr.source_contract_idt)
union all
SELECT /*+ materialize use_hash(cntr) swap_join_inputs(cntr)*/
       cntr.merchant_number,
       cntr.contract_idt,
       cntr.chain_group,
       cntr.chain_id,
       tr.doc_idt,
       DECODE(cntr.record_idt, tr.source_contract_idt, tr.target_number, tr.source_number) AS card_number,
       tr.txn_name,
       tr.txn_code,
       tr.txn_code_group,
       tr.trans_rrn,
       tr.trans_arn,
       tr.trans_date,
       tr.trans_amount,
       tr.banking_date,
       tr.direction,
       tr.auth_code,
       tr.acquirer_data,
       tr.refund_txn_source as txn_source
FROM view_contr cntr
JOIN (select /*+ no_merge*/ * from trans tr where tr.txn_code in ('R1-R','K1-R','K1-P','DCCR1-R','DCCK1-R','DCCK1-P')) tr
ON (cntr.record_idt = tr.target_contract_idt)
)
,trans_sale as
(SELECT /*+ no_merge leading(cntr) use_hash(tr) swap_join_inputs(cntr)*/
       cntr.merchant_number,
       cntr.contract_idt,
       cntr.chain_group,
       cntr.chain_id,
       tr.doc_idt,
  	   DECODE(cntr.record_idt, tr.source_contract_idt, tr.target_number, tr.source_number) AS card_number,
       tr.txn_name,
       tr.txn_code,
       tr.trans_rrn,
       tr.trans_arn,
       tr.trans_date,
       tr.trans_amount,
       tr.banking_date,
       tr.direction,
       tr.auth_code,
       tr.acquirer_data,
       tr.sale_txn_source as txn_source
FROM view_contr cntr
JOIN trans tr
ON (cntr.record_idt = tr.source_contract_idt)
AND tr.txn_code in ('R1-P','DCCR1-P')
union all
SELECT /*+ no_merge leading(cntr) use_hash(tr) swap_join_inputs(cntr)*/
       cntr.merchant_number,
       cntr.contract_idt,
       cntr.chain_group,
       cntr.chain_id,
       tr.doc_idt,
  	   DECODE(cntr.record_idt, tr.source_contract_idt, tr.target_number, tr.source_number) AS card_number,
       tr.txn_name,
       tr.txn_code,
       tr.trans_rrn,
       tr.trans_arn,
       tr.trans_date,
       tr.trans_amount,
       tr.banking_date,
       tr.direction,
       tr.auth_code,
       tr.acquirer_data,
       tr.sale_txn_source as txn_source
FROM view_contr cntr
JOIN trans tr
ON (cntr.record_idt = tr.target_contract_idt)
AND tr.txn_code in ('R1-P','DCCR1-P')
)
,full_t as 
(select /*+ no_merge leading(tr)*/
    tr.merchant_number,
  	tr.chain_group,
    tr.chain_id, --221206.2
  	tr.doc_idt,
  	tr.txn_code,
  	tr.banking_date,
  	tr.trans_date,
  	tr.txn_source,
  	tr.txn_name,
  	case
  	when tr.txn_source = 'NGEN' then tr.trans_rrn
  	when tr.txn_source = 'COMTRUST' then tr.acquirer_data
  	end as pg_number,
  	case
  	when trf.txn_source = 'NGEN' then trf.trans_rrn
  	when trf.txn_source = 'COMTRUST' then trf.acquirer_data
  	end as pg_number_rf,
  	case
  	when trv.txn_source = 'NGEN' then trv.trans_rrn
  	when trv.txn_source = 'COMTRUST' then trv.acquirer_data
  	end as pg_number_rv,
  	tr.trans_rrn,
  	tr.acquirer_data,
  	tr.auth_code,
  	tr.trans_amount,
  	tr.card_number,
  	tr.trans_arn
from trans_refund tr
left join trans_sale trf
on tr.card_number = trf.card_number
and tr.trans_date = trf.trans_date
and tr.auth_code = trf.auth_code
and tr.txn_code_group = 'REFUND'
left join trans_sale trv
on tr.card_number = trv.card_number
and tr.contract_idt = trv.contract_idt
and tr.trans_date = trv.trans_date
and tr.auth_code = trv.auth_code
and tr.txn_code_group = 'REVERSE' 
and tr.trans_arn = trv.trans_arn
)
SELECT 
  /*+ parallel(2) */
  :ORG as ORG, 
  row_number() over (partition by chain_id order by chain_id) as serial_no, --221206.2
  chain_id, --221206.2
  '="'||coalesce(pg_number,pg_number_rf,pg_number_rv)||'"' as  pg_number, --221209.3
  auth_code,
  to_char(banking_date, 'dd/mm/yyyy') as banking_date,
  trans_amount,
  SUBSTR(card_number,1,6) || lpad('*',6,'*') || SUBSTR(card_number,-4) AS card_number,
  to_char(trans_date, 'dd/mm/yyyy') as trans_date,
  '="'||trans_arn||'"' as refund_ref_no, --221209.3
  '="'||merchant_number||'"' as merchant_number --221209.3
  FROM full_t