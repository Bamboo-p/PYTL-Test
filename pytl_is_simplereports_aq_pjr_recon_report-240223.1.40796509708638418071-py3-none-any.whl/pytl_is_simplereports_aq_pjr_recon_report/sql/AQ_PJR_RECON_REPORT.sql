/*
* Code for AQ_PJR_RECON_REPORT
* PyTL_IS_SimpleReports_AQ_PJR_RECON_REPORT = AQ_PJR_RECON_REPORT.sql
* Version history:
* 20220823.1 : NIBOA-7674 : PrabirK  : Initial development
* 20220825.1 : NIBOA-7674 : PrabirK  : Transaction Type details modification
* 20220916.1 : NIBOA-7774 : PrabirK  : Change the SQL for PAY_AMOUNT_TO_MERCHANT field
* 20240223.1 : PRD-25710  : DenisG   : performance improvements
*/
WITH inst AS (
    SELECT
    /*+ no_merge */
        id
    FROM
        dwd_institution
    WHERE
            record_state = 'A'
        AND code = :ORG
), oper AS (
    SELECT
        /*+ inline  */
        op.operation_type_id,
        op.name,
        op.code,
        op.purpose,
        CASE
            WHEN nvl(tot.type_total, '') = 'TOTAL_TRANSACTIONS' THEN
                'TRAN'
            WHEN op.code = 'VAT'                                THEN
                'VAT'
            WHEN instr(op.purpose, ',VAT_ON_FEE,') > 0          THEN
                'VAT'
            WHEN instr(op.purpose, ',TRANS_FEE,') > 0           THEN
                'TRANS_FEE'
            WHEN instr(op.purpose, ',COMM,') > 0                THEN
                'COMM'
            WHEN instr(op.purpose, ',REBATE,') > 0              THEN
                'REBATE'
        END AS type,
    -- [*][begin] 20220825.1 = PrabirK = NIBOA-7674
        CASE
            WHEN op.code IN ( 'RETAIL', 'CASH', 'XLS_REV', 'XLS_SALE', 'CASHBACK',
                              'DCC_RETAIL', 'M_CR_ADJ_DCC', 'CR_CBK_ADJ_DCC', 'QR_SALE' ) THEN
                'SALE'
            WHEN op.code IN ( 'CASH_REV', 'CASHBACK_REV', 'QR_SALE_REV' ) THEN
                'SALE REV'
            WHEN op.code IN ( 'XLS_FUND', 'XLS_REFUND', 'DCC_CREDIT', 'M_DT_ADJ_DCC', 'DB_CBK_ADJ_DCC',
                              'DCC_RETAIL_REV', 'RETAIL_REV', 'QR_REFUND' ) THEN
                'REFUND'
            WHEN op.code IN ( 'REFUND_REV', 'DCC_CREDIT_REV', 'QR_REFUND_REV' ) THEN
                'REFUND REV'
            ELSE
                replace(replace(replace(replace(replace(replace(op.name, 'MANL', 'M'), 'CHBK', 'C'), 'DCC REFUND', 'DCC REF'), '-SALE',
                ''), 'REFUNDS', 'REFUND'), 'SALES', 'SALE')
        END AS new_name
    -- [*][end]  20220825.1 = PrabirK = NIBOA-7674
    FROM
        (
            SELECT
                /*+ inline  */
                op.operation_type_id       AS operation_type_id,
                op.operation_type_code     AS operation_type_code,
                op.code                    AS code,
                ','
                ||
                LISTAGG(op.type_code, ',') WITHIN GROUP(
                    ORDER BY
                        op.type_code
                    )
                || ','                     AS purpose,
                nvl(MIN(op.name), op.code) AS name
            FROM
                (
                    SELECT
                        op.operation_type_id,
                        op.operation_type_code,
                        op.name,
                        op.code,
                        op.sort_order,
                        op.type_code
                    FROM
                        v_dwr_operation_type op
                    WHERE
                        op.class_code = 'ACQ_SETTLEMENT_REPORT'
                ) op
            GROUP BY
                op.operation_type_id,
                op.operation_type_code,
                op.code
        ) op
        LEFT JOIN (
            SELECT
                /*+ inline */
                operation_type_id AS operation_type_id,
                code              AS type_total
            FROM
                v_dwr_operation_type
            WHERE
                    class_code = 'ACQ_REPORTS'
                AND type_code = 'DA_TOTALS'
        ) tot ON tot.operation_type_id = op.operation_type_id
    WHERE
        nvl(tot.type_total, '') = 'TOTAL_TRANSACTIONS'
        OR instr(op.purpose, ',COMM_CODE,') > 0
), trans_entr AS (
    SELECT
        /*+ no_merge use_hash(i) swap_join_inputs(i) pq_distribute(e broadcast none) use_hash(op) swap_join_inputs(op) pq_distribute(op none broadcast)*/
        op.type,
        op.new_name,
        op.code,
        round(e.credit - e.debit, 2) AS amnt,
        e.primary_doc_idt,
        e.fee_rate_value,
        e.contract_idt
    FROM
             inst i
        JOIN dwf_account_entry e ON i.id = e.institution_id and banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        JOIN oper              op ON op.operation_type_id = e.operation_type_id
)
, comm_sql AS (
    SELECT
    /*+ no_merge */
        trans_entr.primary_doc_idt,
        MAX(decode(trans_entr.type, 'COMM', trans_entr.fee_rate_value, NULL)) fee_rate_value,
        SUM(decode(trans_entr.type, 'COMM', amnt, 0))                         comm,
        SUM(decode(trans_entr.type, 'TRANS_FEE', amnt, 0))                    trans_fee,
        SUM(decode(trans_entr.code, 'VAT', amnt, 0))                          vat,
        SUM(decode(trans_entr.code, 'VAT_ON_FEE', amnt, 0))                   vat_on_fee
    FROM
        trans_entr
    WHERE
        trans_entr.type IN ( 'COMM', 'VAT', 'TRANS_FEE' )
    GROUP BY
        trans_entr.primary_doc_idt
)
, addr AS (
    SELECT
    /*+ no_merge no_push_pred(merch_addr) use_hash(inst) swap_join_inputs(inst) pq_distribute(inst none broadcast)*/
        coalesce(merch_addr.address_line_2, 'NA')                                                        AS location,
        coalesce(merch_addr.phone, merch_addr.phone_home, merch_addr.phone_mobile, 'NA')                 AS telephone,
        decode(merch_addr.address_type_code, 'PST_ADDR', merch_addr.client_idt, merch_addr.contract_idt) AS contract_idt,
        merch_addr.address_line_1                                                                        AS merch_name,
        merch_addr.e_mail                                                                                AS email,
        merch_addr.state,
        merch_addr.address_type_code
    FROM
             opt_v_address merch_addr
        JOIN inst ON inst.id = merch_addr.institution_id
    WHERE
        merch_addr.address_type_code IN ( 'STMT_ADDR', 'PST_ADDR' )
        AND TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN merch_addr.record_date_from AND merch_addr.record_date_to
        AND merch_addr.record_state != 'C'
)
, chains AS (
    SELECT
        /*+ no_merge leading(dach) use_hash(dft) swap_join_inputs(dft) pq_distribute(dft none broadcast)
            use_hash(inst) swap_join_inputs(inst) pq_distribute(inst none broadcast)
            use_hash(addr) swap_join_inputs(addr) pq_distribute(addr none broadcast)
            use_nl(dach dc)
        */
        dach.contract_idt,
        MAX(decode(dft.code, 'CHAINID_1', dc.ident_number, NULL))                                                                                                                                                                        AS
        chainid_1,
        MAX(
            CASE
                WHEN decode(dft.code, 'CHAINID_1', dc.ident_number, NULL) IS NOT NULL
                     AND addr.state = 'D' THEN
                    'OTH_DTR'
                ELSE
                    decode(dft.code, 'CHAINID_1', substr(dc.add_info, instr(dc.add_info, 'CHAIN_GROUPS_CODE=') + 18,(instr(dc.add_info,
                    ';', instr(dc.add_info, 'CHAIN_GROUPS_CODE=')) - instr(dc.add_info, 'CHAIN_GROUPS_CODE=') - 18)), NULL)
            END
        )                                                                                                                                                                                                                                AS
        chainid_1_gc,
        MAX(decode(dft.code, 'CHAINID_2', dc.ident_number, NULL))                                                                                                                                                                        AS
        chainid_2,
        MAX(decode(dft.code, 'CHAINID_2', substr(dc.add_info, instr(dc.add_info, 'CHAIN_GROUPS_CODE=') + 18,(instr(dc.add_info, ';', instr(
        dc.add_info, 'CHAIN_GROUPS_CODE=')) - instr(dc.add_info, 'CHAIN_GROUPS_CODE=') - 18)), NULL)) AS chainid_2_gc,
        MAX(
            CASE
                WHEN dft.code IN('CHAINID_4', 'CHAINID4') THEN
                    dc.ident_number
                ELSE
                    NULL
            END
        )                                                                                                                                                                                                                                AS
        chainid_4,
        MAX(decode(dft.code, 'CHAINID_1', addr.state, NULL))                                                                                                                                                                             AS
        addr_state
    FROM
        dwd_affiliation dach
        JOIN dwd_affiliation_type dft ON dach.affiliation_type_id = dft.id
                                         AND dft.code IN ( 'CHAINID_1', 'CHAINID_2', 'CHAINID_4', 'CHAINID4' )
                                         AND dach.record_state != 'C'
                                         AND dft.record_state != 'C'                                         
                                         AND TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN dft.record_date_from AND dft.record_date_to        
        JOIN dwd_client           dc ON dc.record_idt = dach.affiliated_client_idt
                              AND dc.record_state != 'C'
                              AND TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN dc.record_date_from AND dc.record_date_to
                              AND dc.ident_number = '200100462143'      
        JOIN inst ON inst.id = dc.institution_id       
        LEFT JOIN addr ON addr.contract_idt = dc.record_idt
                          AND addr.address_type_code = 'PST_ADDR'        
    where
        TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN dach.record_date_from AND dach.record_date_to
    GROUP BY
        dach.contract_idt
)
, card_brand AS (
    SELECT
    /*+ no_merge */
        'PREMIUM'                                              AS code,
        cb.code                                                card_brand_code,
        SUM(decode(v.type_code, 'NI_DOM_IPS_CARD_TYPE', 1, 0)) ni_dom_ips_card_type,
        SUM(decode(v.type_code, 'NI_INT_IPS_CARD_TYPE', 1, 0)) ni_int_ips_card_type,
        SUM(decode(v.type_code, 'NI_SUP_IPS_CARD_TYPE', 1, 0)) ni_sup_ips_card_type
    FROM
        v_dwr_lowest_level v,
        dwd_card_brand     cb
    WHERE
        v.type_code IN ( 'NI_DOM_IPS_CARD_TYPE', 'NI_INT_IPS_CARD_TYPE', 'NI_SUP_IPS_CARD_TYPE' )
        AND cb.record_state = 'A'
        AND cb.id = v.dim_record_id
    GROUP BY
        cb.code
)
, tar AS (
    --111 707
    SELECT
    /*+ no_merge NO_GBY_PUSHDOWN leading(st) swap_join_inputs(t) no_px_join_filter(st)*/
        t.domain                                                        AS contract_idt,
        substr(t.domain, 0, instr(t.domain, '-') - 1)                   AS code,
        MAX(decode(t.type_code, 'TRANS_FEE', st.fee_base_amount, 0))    AS tran_fee_tar,
        MAX(decode(t.type_code, 'ACQ_STMT_FEE', st.fee_base_amount, 0)) AS stmt_fee_tar
    FROM
        dwd_tariff t
        JOIN dwd_service_tariff st ON st.record_idt = t.record_idt
                                      AND st.record_state != 'C'
                                      AND TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN st.record_date_from AND st.record_date_to
    WHERE
        t.record_state != 'C'
        AND t.role = 'SERVICE'
        AND t.type_code IN ( 'TRANS_FEE', 'ACQ_STMT_FEE' )
        AND TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN t.record_date_from AND t.record_date_to
    GROUP BY
        t.domain
)
, itar AS (
    SELECT
    /*+ materialize leading(st) swap_join_inputs(t) no_px_join_filter(st)*/
        st.fee_rate_value AS vat_rate
    FROM
        dwd_tariff t
        JOIN dwd_service_tariff st ON st.record_idt = t.record_idt
                                      AND st.record_state != 'C'
                                      AND TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN st.record_date_from AND st.record_date_to
    WHERE
      t.record_state != 'C'
      AND t.type_code = 'ACQ_VAT_RATE'
      AND t.role = 'SERVICE'
      AND TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN t.record_date_from AND t.record_date_to 
      AND substr(t.domain, 0, instr(t.domain, '-') - 1) = :ORG
      AND t.record_state != 'C'    
)
, cattr AS (
    SELECT
        /*+inline leading(cattr) index(cattr DWA_CNTR_ATTR_DATE_TO_IDX)*/
        cattr.contract_idt,
        attr.code,
        attr.type_code
    FROM
        dwa_contract_attribute cattr
        INNER JOIN dwd_attribute attr ON attr.id = cattr.attr_id
                                         AND TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN attr.record_date_from AND attr.record_date_to
                                         AND attr.type_code IN ( 'ACQ_LVL', 'ACQ_MULTICUR', 'ACQ_VATCOM_MERCH', 'ACQ_COMM_STTLM', 'ACQ_INT_RPRC')
    where
       TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN cattr.attr_date_from AND cattr.attr_date_to
       AND cattr.active_state = 'A'    
)
, cntr AS (
    SELECT
        /*+ materialize*/
        cntr.personal_account,
        cntr.record_idt,
        cntr.parent_contract_idt,
        replace(replace(substr(cntr.add_info, instr(cntr.add_info, ';MERCH_TYPE=') + 12,(instr(cntr.add_info, ';', instr(cntr.add_info,
        ';MERCH_TYPE=') + 1) - instr(cntr.add_info, ';MERCH_TYPE=') - 12)), CHR(10)), CHR(13)) AS store_type,
        replace(replace(substr(cntr.add_info, instr(cntr.add_info, ';CREDITACCT=') + 12,(instr(cntr.add_info, ';', instr(cntr.add_info,
        ';CREDITACCT=') + 1) - instr(cntr.add_info, ';CREDITACCT=') - 12)), CHR(10)), CHR(13)) AS bank_account,
        cntr.code,
        cntr.type_code,
        cntr.mult,
        cntr.tran_fee_tar,
        cntr.stmt_fee_tar,
        cntr.master_chain4,
        cntr.gc_chain1,
        cntr.master_chain1,
        cntr.gc_chain2,
        cntr.chain2,
        cntr.addr_state,
        cntr.merchant_name,
        cntr.location,
        cntr.telephone,
        cntr.email,
        cntr.vat_rate,
        cntr.vatcomm,
        cntr.commfreq,
        cntr.rprc
    FROM
        (
            SELECT
                /*+ no_merge ordered full(cntr) use_hash(inst) swap_join_inputs(inst) pq_distribute(cntr broadcast none)
                    use_nl(dca) push_pred(dca)
                    use_nl(mult) push_pred(mult)
                    use_nl(vatcomm) push_pred(vatcomm)
                    use_nl(commfreq) push_pred(commfreq)
                    use_nl(rp) push_pred(rp)         
                    use_hash(tar) swap_join_inputs(tar) pq_distribute(tar broadcast none)
                    use_hash(itar) swap_join_inputs(itar) pq_distribute(itar broadcast none)
                    use_hash(chains) swap_join_inputs(chains) pq_distribute(chains broadcast none)
                    use_hash(addr) swap_join_inputs(addr) pq_distribute(addr broadcast none)
                */
                cntr.personal_account,
                cntr.record_idt,
                cntr.parent_contract_idt,
                ';' || cntr.add_info     AS add_info,
                dca.code,
                dca.type_code,
                mult.code                AS mult,
                nvl(tar.tran_fee_tar, 0) AS tran_fee_tar,
                nvl(tar.stmt_fee_tar, 0) AS stmt_fee_tar,
                chains.chainid_4         AS master_chain4,
                chains.chainid_1_gc      AS gc_chain1,
                chains.chainid_1         AS master_chain1,
                chains.chainid_2_gc      AS gc_chain2,
                chains.chainid_2         AS chain2,
                chains.addr_state,
                merch_addr.merch_name    AS merchant_name,
                merch_addr.location,
                merch_addr.telephone,
                merch_addr.email,
                itar.vat_rate,
                nvl(vatcomm.code, 'Y')   AS vatcomm,
                commfreq.code            AS commfreq,
                nvl(rp.code, 'Y')        AS rprc
            FROM
                dwd_contract cntr
                JOIN inst ON inst.id = cntr.institution_id
                JOIN cattr dca ON cntr.record_idt = dca.contract_idt
                                  AND dca.code IN ( 'DEVICE', 'MERCHANT' )
                LEFT JOIN cattr mult ON mult.contract_idt = cntr.record_idt
                                        AND mult.type_code = 'ACQ_MULTICUR'
                LEFT JOIN cattr vatcomm ON vatcomm.contract_idt = cntr.record_idt
                                           AND vatcomm.type_code = 'ACQ_VATCOM_MERCH'
                LEFT JOIN cattr commfreq ON commfreq.contract_idt = cntr.record_idt
                                            AND commfreq.type_code = 'ACQ_COMM_STTLM'
                LEFT JOIN cattr rp ON rp.contract_idt = cntr.record_idt
                                      AND rp.type_code = 'ACQ_INT_RPRC'
                LEFT JOIN tar ON tar.contract_idt = cntr.personal_account                
                LEFT JOIN chains ON cntr.record_idt = chains.contract_idt
                LEFT JOIN addr  merch_addr ON merch_addr.contract_idt = cntr.record_idt
                                             AND merch_addr.address_type_code = 'STMT_ADDR'
                left JOIN itar ON 1 = 1                                             
            Where
                 TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN cntr.record_date_from AND cntr.record_date_to
                 AND cntr.record_state != 'C'
        ) cntr
)
, tr_sales AS (
    SELECT
        /*+ no_merge*/
        t.trans_rrn,
        t.auth_code,
        t.source_contract_idt,
        t.target_number
    FROM
        (
            SELECT /*+ no_merge use_hash(tt2) swap_join_inputs(tt2) pq_distribute(tt2 broadcast none) 
                       use_hash(inst) swap_join_inputs(inst) pq_distribute(inst broadcast none) 
                       index(t DWF_TRANSACTION_SCNTR_IDX)
                   */
                t.trans_rrn,
                t.auth_code,
                t.source_contract_idt,
                t.target_number,
                DENSE_RANK()
                OVER(PARTITION BY t.auth_code, t.source_contract_idt, t.target_number
                     ORDER BY
                         t.banking_date DESC, t.trans_rrn DESC, t.doc_idt DESC
                ) AS rn
            FROM
                     dwf_transaction t
                JOIN dwd_transaction_type tt2 ON tt2.id = t.transaction_type_id
                                AND tt2.code IN ( 'R1-P', 'U1-P', 'DCCR1-P', 'K1-R', 'DCCK1-R' )
                                AND tt2.record_state = 'A'
                                AND TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN tt2.record_date_from AND tt2.record_date_to                
                JOIN inst                 i2 ON i2.id = t.institution_id
            WHERE
                t.banking_date BETWEEN add_months(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'), - 3) AND TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        ) t
    WHERE
        rn = 1
)
, tr AS (
    SELECT
    /*+ no_merge*/
    /*tr.*,*/
        tr.doc_idt,
        tr.trans_currency,
        tr.settl_currency,
        tr.card_brand_id,
        tr.trans_conditions_id,
        nvl(tr.trans_rrn, tr.trans_rrn_orig)                                                                                                                                                                                 AS
        trans_rrn,
        tr.trans_arn,
        tr.trans_date,
        tr.settl_amount,
        tr.banking_date,
        tr.direction,
        tr.auth_code,
        tr.source_number,
        tr.target_number,
        tr.source_contract_idt,
        tr.settlement_date,
        CASE
            WHEN instr(tr.add_info, 'FROM_CYBERSOURCE') > 0 THEN
                'Y'
            ELSE
                'N'
        END                                                                                                                                                                                                                  AS
        tc33,
        CASE
            WHEN tr.source_message_code LIKE 'IATA%' THEN
                'Y'
            ELSE
                'N'
        END                                                                                                                                                                                                                  AS
        bsp,
        CASE
            WHEN tr.source_message_code LIKE '%ARC%' THEN
                'Y'
            ELSE
                'N'
        END                                                                                                                                                                                                                  AS
        arc,
        substr(tr.add_info, instr(tr.add_info, 'TRADE_CODE=') + 11,(instr(tr.add_info, ';', instr(tr.add_info, 'TRADE_CODE=')) - instr(
        tr.add_info, 'TRADE_CODE=') - 11))                                                    AS dept_code,
        substr(tr.add_info, instr(tr.add_info, 'GN_UNIQUE_ID=') + 13,(instr(tr.add_info, ';', instr(tr.add_info, 'GN_UNIQUE_ID=')) - instr(
        tr.add_info, 'GN_UNIQUE_ID=') - 13))                                              AS gn_unique_id,
        substr(tr.add_info, instr(tr.add_info, 'CS_REQ_REC_ID=') + 14,(instr(tr.add_info, ';', instr(tr.add_info, 'CS_REQ_REC_ID=')) -
        instr(tr.add_info, 'CS_REQ_REC_ID=') - 14))                                           AS cs_req_rec_id,
        replace(replace(substr(tr.add_info, instr(tr.add_info, 'RI_TIP_AMOUNT=') + 14,(instr(tr.add_info, ';', instr(tr.add_info, 'RI_TIP_AMOUNT=')) -
        instr(tr.add_info, 'RI_TIP_AMOUNT=') - 14)), CHR(10)), CHR(13))       AS tip_amount,
        replace(replace(substr(tr.add_info, instr(tr.add_info, 'RI_TAG_ID=') + 10,(instr(tr.add_info, ';', instr(tr.add_info, 'RI_TAG_ID=')) -
        instr(tr.add_info, 'RI_TAG_ID=') - 10)), CHR(10)), CHR(13))                   AS tag_id,
        replace(replace(substr(tr.add_info, instr(tr.add_info, 'RI_DRIVER_ID=') + 13,(instr(tr.add_info, ';', instr(tr.add_info, 'RI_DRIVER_ID=')) -
        instr(tr.add_info, 'RI_DRIVER_ID=') - 13)), CHR(10)), CHR(13))          AS driver_id,
        replace(replace(substr(tr.add_info, instr(tr.add_info, 'RI_CARD_ID=') + 11,(instr(tr.add_info, ';', instr(tr.add_info, 'RI_CARD_ID=')) -
        instr(tr.add_info, 'RI_CARD_ID=') - 11)), CHR(10)), CHR(13))                AS card_id,
        CASE
            WHEN trunc(tr.banking_date) - trunc(tr.banking_date, 'iw') < 4 THEN
                tr.banking_date + 6 - ( trunc(tr.banking_date) - trunc(tr.banking_date, 'iw') )
            ELSE
                tr.banking_date + 13 - ( trunc(tr.banking_date) - trunc(tr.banking_date, 'iw') )
        END                                                                                                                                                                                                                  AS
        settl_date_trnpfus,
        substr(tr.add_info, instr(tr.add_info, 'ARC_TACN=') + 9,(instr(tr.add_info, ';', instr(tr.add_info, 'ARC_TACN=')) - instr(tr.
        add_info, 'ARC_TACN=') - 9))                                                            AS arc_tacn,
        substr(tr.add_info, instr(tr.add_info, 'AI_F270=') + 8,(instr(tr.add_info, ';', instr(tr.add_info, 'AI_F270=')) - instr(tr.add_info,
        'AI_F270=') - 8))                                                               AS ai_f270,
        substr(tr.add_info, instr(tr.add_info, 'AI_F268=') + 8,(instr(tr.add_info, ';', instr(tr.add_info, 'AI_F268=')) - instr(tr.add_info,
        'AI_F268=') - 8))                                                               AS ai_f268,
        substr(tr.add_info, instr(tr.add_info, 'PURCH_ID=') + 9,(instr(tr.add_info, ';', instr(tr.add_info, 'PURCH_ID=')) - instr(tr.
        add_info, 'PURCH_ID=') - 9))                                                            AS purch_id,
        substr(tr.add_info, instr(tr.add_info, 'GWAY_IDT=') + 9,(instr(tr.add_info, ';', instr(tr.add_info, 'GWAY_IDT=')) - instr(tr.
        add_info, 'GWAY_IDT=') - 9))                                                            AS gway_idt,
        nvl(substr(tr.add_info, instr(tr.add_info, 'MIGS=') + 5,(instr(tr.add_info, ';', instr(tr.add_info, 'MIGS=')) - instr(tr.add_info,
        'MIGS=') - 5)), 'N')                                                              AS migs,
        nvl(substr(tr.add_info, instr(tr.add_info, 'PTLF=') + 5,(instr(tr.add_info, ';', instr(tr.add_info, 'PTLF=')) - instr(tr.add_info,
        'PTLF=') - 5)), 'N')                                                              AS ptlf,
        nvl(substr(tr.add_info, instr(tr.add_info, 'DOMESTIC=') + 9,(instr(tr.add_info, ';', instr(tr.add_info, 'DOMESTIC=')) - instr(
        tr.add_info, 'DOMESTIC=') - 9)), 'N')                                                  AS domestic,
        rpad(replace(replace(substr(tr.add_info, instr(tr.add_info, 'ACQ_PRD_1=') + 10,(instr(tr.add_info, ';', instr(tr.add_info, 'ACQ_PRD_1=')) -
        instr(tr.add_info, 'ACQ_PRD_1=') - 10)), CHR(10)), CHR(13)), 34, ' ')
        || rpad(replace(replace(substr(tr.add_info, instr(tr.add_info, 'ACQ_PRD_2=') + 10,(instr(tr.add_info, ';', instr(tr.add_info,
        'ACQ_PRD_2=')) - instr(tr.add_info, 'ACQ_PRD_2=') - 10)), CHR(10)), CHR(13)), 15, ' ') AS acquirer_data,
        nvl(substr(tr.add_info, instr(tr.add_info, 'TCASHBACK_AMOUNT=') + 17,(instr(tr.add_info, ';', instr(tr.add_info, 'TCASHBACK_AMOUNT=')) -
        instr(tr.add_info, 'TCASHBACK_AMOUNT=') - 17)), 0) / 100                    AS pwcb_cashback,
        round(nvl(to_number(substr(tr.add_info, instr(tr.add_info, ';NIDT_AMOUNT=') + 13,(instr(tr.add_info, ';', instr(tr.add_info, ';NIDT_AMOUNT=') +
        1) - instr(tr.add_info, ';NIDT_AMOUNT=') - 13))), 0), 2)             AS nidt_amount,
        round(nvl(to_number(substr(tr.add_info, instr(tr.add_info, ';NIOO_AMOUNT=') + 13,(instr(tr.add_info, ';', instr(tr.add_info, ';NIOO_AMOUNT=') +
        1) - instr(tr.add_info, ';NIOO_AMOUNT=') - 13))), 0), 2)             AS nioo_amount,
        round(nvl(to_number(substr(tr.add_info, instr(tr.add_info, ';NIMID_AMOUNT=') + 14,(instr(tr.add_info, ';', instr(tr.add_info,
        ';NIMID_AMOUNT=') + 1) - instr(tr.add_info, ';NIMID_AMOUNT=') - 14))), 0), 2)          AS nimid_amount,
        round(nvl(to_number(substr(tr.add_info, instr(tr.add_info, 'VAT_NIDT_AMOUNT=') + 16,(instr(tr.add_info, ';', instr(tr.add_info,
        'VAT_NIDT_AMOUNT=')) - instr(tr.add_info, 'VAT_NIDT_AMOUNT=') - 16))), 0), 2)        AS vat_nidt_amount,
        round(nvl(to_number(substr(tr.add_info, instr(tr.add_info, 'VAT_NIOO_AMOUNT=') + 16,(instr(tr.add_info, ';', instr(tr.add_info,
        'VAT_NIOO_AMOUNT=')) - instr(tr.add_info, 'VAT_NIOO_AMOUNT=') - 16))), 0), 2)        AS vat_nioo_amount,
        round(nvl(to_number(substr(tr.add_info, instr(tr.add_info, 'VAT_NIMID_AMOUNT=') + 17,(instr(tr.add_info, ';', instr(tr.add_info,
        'VAT_NIMID_AMOUNT=')) - instr(tr.add_info, 'VAT_NIMID_AMOUNT=') - 17))), 0), 2)     AS vat_nimid_amount,
        substr(tr.add_info, instr(tr.add_info, 'MPGSOrderId=') + 12,(instr(tr.add_info, ';', instr(tr.add_info, 'MPGSOrderId=')) - instr(
        tr.add_info, 'MPGSOrderId=') - 12))                                                 AS mpgsorderid,
        nvl(substr(tr.add_info, instr(tr.add_info, 'UPI_ECOMM=') + 10,(instr(tr.add_info, ';', instr(tr.add_info, 'UPI_ECOMM=')) - instr(
        tr.add_info, 'UPI_ECOMM=') - 10)), 'N')                                             AS upi_ecomm,
        substr(tr.add_info, instr(tr.add_info, 'ORDER_ID=') + 9,(instr(tr.add_info, ';', instr(tr.add_info, 'ORDER_ID=')) - instr(tr.
        add_info, 'ORDER_ID=') - 9))                                                            AS order_id,
        substr(tr.add_info, instr(tr.add_info, 'V1_TKN_RQ_ID=') + 13,(instr(tr.add_info, ';', instr(tr.add_info, 'V1_TKN_RQ_ID=')) - instr(
        tr.add_info, 'V1_TKN_RQ_ID=') - 13))                                              AS v1_tkn_rq_id,
        CASE
            WHEN instr(tr.add_info, 'QR_TRAN=Y;') > 0 THEN
                'Y'
            ELSE
                'N'
        END                                                                                                                                                                                                                  AS
        qr_enabled,
        substr(tr.add_info, instr(tr.add_info, 'DOMESTIC=') + 9,(instr(tr.add_info, ';', instr(tr.add_info, 'DOMESTIC=')) - instr(tr.
        add_info, 'DOMESTIC=') - 9))                                                            AS domestic_2,
        substr(tr.add_info, instr(tr.add_info, 'CARD_AFS=') + 9,(instr(tr.add_info, ';', instr(tr.add_info, 'CARD_AFS=')) - instr(tr.
        add_info, 'CARD_AFS=') - 9))                                                            AS card_afs,
        substr(tr.add_info, instr(tr.add_info, 'GNUSRFLD1=') + 10,(instr(tr.add_info, ';', instr(tr.add_info, 'GNUSRFLD1=')) - instr(
        tr.add_info, 'GNUSRFLD1=') - 10))                                                       AS gnusrfld1,
        CASE
            WHEN instr(tr.add_info, 'CARD_AFS=D;') > 0 THEN
                'DEBIT'
            ELSE
                NULL
        END                                                                                                                                                                                                                  AS
        card_usage,
        tr.area_code,
        substr(tr.add_info, instr(tr.add_info, 'SOURCE_FIID=') + 12,(instr(tr.add_info, ';', instr(tr.add_info, 'SOURCE_FIID=')) - instr(
        tr.add_info, 'SOURCE_FIID=') - 12))                                                 AS source_fiid,
        CASE
            WHEN instr(tr.add_info, 'PTLF=Y;') > 0          THEN
                'PTLF'
            WHEN instr(tr.add_info, 'MIGS=Y;') > 0          THEN
                'MIGS'
            WHEN instr(tr.add_info, 'WE_CHAT=Y;') > 0       THEN
                'WECHAT'
            WHEN instr(tr.add_info, 'ALI_PAY=Y;') > 0       THEN
                'ALIPAY'
            WHEN instr(tr.add_info, 'FROM_CYBERSOURCE') > 0 THEN
                'CYBERSOURCE'
            WHEN instr(tr.add_info, 'DCC=FEXCO') > 0        THEN
                'FEXCO'
            WHEN instr(tr.add_info, 'DCC=PP;') > 0          THEN
                'PLANET PAYMENT'
            WHEN instr(tr.add_info, 'TDE=Y;') > 0           THEN
                'MANUAL ENTRY'
            WHEN instr(tr.add_info, 'UPI_ECOMM=Y;') > 0     THEN
                'UPI_ECOMM'
            WHEN instr(tr.add_info, 'TERRAPAY=Y;') > 0      THEN
                'TERRAPAY'
            ELSE
                NULL
        END                                                                                                                                                                                                                  AS
        channel,
        substr(tr.add_info, instr(tr.add_info, 'NM_STAN=') + 8,(instr(tr.add_info, ';', instr(tr.add_info, 'NM_STAN=')) - instr(tr.add_info,
        'NM_STAN=') - 8))                                                               AS nm_stan
    FROM
        (
            SELECT
               /*+ no_merge leading(tr) use_NL(tr) index(tr DWF_TRANSACTION_DOCID_IDX)
                   use_hash(i) swap_join_inputs(i) pq_distribute(i none broadcast) 
                   use_nl(ac) push_pred(ac) 
                   use_nl(tr2) push_pred(tr2) 
                */
                tr.doc_idt,
                tr.trans_currency,
                tr.settl_currency,
                tr.card_brand_id,
                tr.trans_conditions_id,
                tr.trans_rrn,
                tr2.trans_rrn      AS trans_rrn_orig,
                tr.trans_arn,
                tr.trans_date,
                tr.settl_amount,
                tr.banking_date,
                tr.direction,
                tr.auth_code,
                tr.source_number,
                tr.target_number,
                tr.source_contract_idt,
                tr.settlement_date,
                tr.source_message_code,
                ';' || tr.add_info AS add_info,
                CASE
                    WHEN ac.country_code = tr.trans_country_code THEN
                        'Domestic'
                    WHEN ac.country_code = 'ARE'                 THEN
                        'GCC'
                    WHEN ac.country_code = 'KWT'                 THEN
                        'GCC'
                    WHEN ac.country_code = 'BHR'                 THEN
                        'GCC'
                    WHEN ac.country_code = 'OMN'                 THEN
                        'GCC'
                    WHEN ac.country_code = 'QAT'                 THEN
                        'GCC'
                    WHEN ac.country_code = 'SAU'                 THEN
                        'GCC'
                    ELSE
                        NULL
                END                AS area_code
            FROM
                dwf_transaction tr
                JOIN inst          i ON i.id = tr.institution_id
                LEFT JOIN (select /*+no_merge*/ * from dwd_bin_table ac where ac.record_state != 'C'
                                              AND TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') BETWEEN ac.record_date_from AND ac.record_date_to ) ac ON tr.bin_table_idt = ac.record_idt                                              
                LEFT JOIN tr_sales      tr2 ON tr2.auth_code = tr.auth_code
                                          AND tr2.source_contract_idt = tr.source_contract_idt
                                          AND tr2.target_number = tr.target_number
            WHERE
                tr.banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                AND nvl(tr.target_channel, 'NO') != 'X'
        ) tr
)    
, all_items AS (
    SELECT
    /*+ no_merge ordered use_hash(device) swap_join_inputs(cntr) 
        use_nl(tr) push_pred(tr)
        use_nl(op) push_pred(op)
    */
        cntr.personal_account                                                                             AS merchant_id,
        cntr.record_idt                                                                                   AS contract_idt,
        cntr.merchant_name,
        cntr.location,
        cntr.telephone,
        cntr.email,
        decode(op.contract_idt, tr.source_contract_idt, tr.source_number, tr.target_number)               AS terminal_id,
        tr.trans_rrn                                                                                      AS txn_seq_no,
        settl_curr.name                                                                                   AS settl_curr,
        curr.name                                                                                         AS trans_curr,
        to_char(tr.trans_date, 'dd/mm/yyyy')                                                              AS txn_date,
        to_char(tr.trans_date, 'dd')                                                                      AS txn_day,
        to_char(tr.trans_date, 'HH24:MI')                                                                 AS txn_hhmm,
        to_char(tr.settlement_date, 'dd/mm/yyyy')                                                         AS settlement_date,
        br.payment_scheme                                                                                 AS card_type,
        decode(op.contract_idt, tr.source_contract_idt, tr.target_number, tr.source_number)               AS card_no,
        length(TRIM(decode(op.contract_idt, tr.source_contract_idt, tr.target_number, tr.source_number))) AS card_no_length,
        tr.auth_code                                                                                      AS auth_code,
        op.amnt                                                                                           AS txn_amount,
        nvl(comm_sql.comm, 0)                                                                             AS commission,
        op.amnt + nvl(comm_sql.comm, 0) + (
            CASE
                WHEN cntr.commfreq = 'M1'
                     AND cntr.vatcomm = 'Y'
                     AND nvl(comm_sql.vat, 0) = 0 THEN
                    nvl(round(nvl(comm_sql.comm, 0) * cntr.vat_rate / 100, 2), nvl(comm_sql.comm, 0))
                ELSE
                    nvl(comm_sql.vat, 0)
            END
        )                                                                                                 AS net_amount,
        op.amnt + nvl(comm_sql.comm, 0) + nvl(comm_sql.vat_on_fee, 0) + nvl(comm_sql.trans_fee, 0) + (
            CASE
                WHEN cntr.commfreq = 'M1'
                     AND cntr.vatcomm = 'Y'
                     AND nvl(comm_sql.vat, 0) = 0 THEN
                    nvl(round(nvl(comm_sql.comm, 0) * cntr.vat_rate / 100, 2), nvl(comm_sql.comm, 0))
                ELSE
                    nvl(comm_sql.vat, 0)
            END
        )                                                                                                 AS total_net_amount,
        tr.acquirer_data,
        tr.trans_rrn                                                                                      AS ret_ref_no,
        cntr.store_type,
        cntr.bank_account,
        to_char(tr.trans_date, 'HH24:MI:SS')                                                              AS time,
        cntr.master_chain4,
        cntr.gc_chain1,
        cntr.master_chain1,
        tr.pwcb_cashback,
        nvl(comm_sql.trans_fee, 0)                                                                        AS trans_fee,
        CASE
            WHEN cntr.commfreq = 'M1'
                 AND cntr.vatcomm = 'Y'
                 AND nvl(comm_sql.vat, 0) = 0 THEN
                nvl(round(nvl(comm_sql.comm, 0) * cntr.vat_rate / 100, 2), nvl(comm_sql.comm, 0))
            ELSE
                nvl(comm_sql.vat, 0)
        END                                                                                               AS vat,
        nvl(comm_sql.vat_on_fee, 0)                                                                       AS vat_on_fee,
        CASE
            WHEN crd.ni_sup_ips_card_type != 0
                 AND nvl(br.payment_scheme_code, 'NA') = 'E' THEN
                'M/TVL'
            WHEN crd.ni_sup_ips_card_type != 0
                 AND nvl(br.payment_scheme_code, 'NA') = 'V' THEN
                'V/TVL'
            WHEN crd.ni_int_ips_card_type != 0
                 AND cntr.rprc = 'Y'
                 AND tr.domestic != 'Y' THEN
                'PREMIUM'
            WHEN crd.ni_dom_ips_card_type != 0 THEN
                'PREMIUM'
            ELSE
                'STANDARD'
        END                                                                                               AS trn_typ,
        CASE
            WHEN crd.ni_sup_ips_card_type != 0
                 AND nvl(br.payment_scheme_code, 'NA') = 'E' THEN
                'MT'
            WHEN crd.ni_sup_ips_card_type != 0
                 AND nvl(br.payment_scheme_code, 'NA') = 'V' THEN
                'VT'
            WHEN crd.ni_int_ips_card_type != 0
                 AND cntr.rprc = 'Y'
                 AND tr.domestic != 'Y' THEN
                'P'
            WHEN crd.ni_dom_ips_card_type != 0 THEN
                'P'
            ELSE
                'S'
        END                                                                                               AS pr_st,
        CASE
            WHEN op.code IN ( 'DCC_RETAIL', 'M_CR_ADJ_DCC', 'CR_CBK_ADJ_DCC', 'CASHBACK', 'DCC_CREDIT_REV' ) THEN
                'SALE'
            WHEN op.code IN ( 'CASHBACK_REV' ) THEN
                'SALE REV'
            WHEN op.code IN ( 'DCC_CREDIT', 'M_DT_ADJ_DCC', 'DB_CBK_ADJ_DCC', 'DCC_RETAIL_REV' ) THEN
                'REFUND'
            ELSE
                op.new_name
        END                                                                                               AS oper_group,
        decode(tr.direction, 1, 'C', 'D')                                                                 AS tran_ind,
        decode(tr.direction, 1, 'D', 'C')                                                                 AS comm_ind,
        op.new_name                                                                                       AS oper_name,
        CASE
            WHEN trcond.condition_list LIKE '%,KEY_ENTRY,%' THEN
                'M'
            ELSE
                'E'
        END                                                                                               AS man_elec,
        comm_sql.fee_rate_value,
        tr.banking_date,
        tr.settl_amount,
        to_char(tr.trans_date, 'ddmmyyyy')                                                                AS undel_date,
        to_char(tr.trans_date, 'HH24:MI')                                                                 AS short_time,
        cntr.gc_chain2,
        cntr.chain2,
        tr.trans_currency,
        CASE
            WHEN op.code = 'CASH'           THEN
                '030'
            WHEN op.code = 'CASH_REV'       THEN
                '031'
            WHEN op.code IN ( 'CASHBACK', 'CASHBACK_REV' ) THEN
                '046'
            WHEN op.code IN ( 'DCC_RETAIL', 'DCC_CREDIT_REV' ) THEN
                '050'
            WHEN op.code IN ( 'DCC_CREDIT', 'DCC_RETAIL_REV' ) THEN
                '051'
            WHEN op.code = 'CR_CBK_ADJ_DCC' THEN
                '052'
            WHEN op.code = 'DB_CBK_ADJ_DCC' THEN
                '053'
            WHEN op.code = 'M_CR_ADJ_DCC'   THEN
                '054'
            WHEN op.code = 'M_DT_ADJ_DCC'   THEN
                '055'
            WHEN op.code IN ( 'RETAIL', 'REFUND_REV', 'XLS_REV', 'XLS_SALE' )
                 AND nvl(br.payment_scheme_code, 'NA') = 'H' THEN
                '140'
            WHEN op.code IN ( 'REFUND', 'XLS_REFUND', 'XLS_FUND', 'RETAIL_REV' )
                 AND nvl(br.payment_scheme_code, 'NA') = 'H' THEN
                '141'
            WHEN op.code IN ( 'RETAIL', 'REFUND_REV', 'XLS_REV', 'XLS_SALE' )
                 AND nvl(br.payment_scheme_code, 'NA') != 'H' THEN
                '040'
            WHEN op.code IN ( 'REFUND', 'XLS_REFUND', 'XLS_FUND', 'RETAIL_REV' )
                 AND nvl(br.payment_scheme_code, 'NA') != 'H' THEN
                '041'
            ELSE
                NULL
        END                                                                                               AS trans_code,
        cntr.tran_fee_tar,
        cntr.stmt_fee_tar,
        CASE
            WHEN op.new_name IN ( 'SALE', 'REFUND', 'SALE REV' ) THEN
                    CASE
                        WHEN trcond.condition_list LIKE '%,KEY_ENTRY,%' THEN
                            'MANUAL'
                        ELSE
                            'ELECTR'
                    END
            ELSE
                op.new_name
        END                                                                                               AS rlg_oper_name,
        CASE
            WHEN nvl(br.payment_scheme_code, 'NA') = 'E' THEN
                    CASE
                        WHEN crd.ni_sup_ips_card_type != 0 THEN
                            'M/TVL'
                        WHEN crd.ni_int_ips_card_type != 0
                             AND cntr.rprc = 'Y'
                             AND tr.domestic != 'Y' THEN
                            'MC-PREM'
                        WHEN crd.ni_dom_ips_card_type != 0 THEN
                            'MC-PREM'
                        ELSE
                            'MC-STND'
                    END
            WHEN nvl(br.payment_scheme_code, 'NA') = 'V' THEN
                    CASE
                        WHEN crd.ni_sup_ips_card_type != 0 THEN
                            'V/TVL'
                        WHEN crd.ni_int_ips_card_type != 0
                             AND cntr.rprc = 'Y'
                             AND tr.domestic != 'Y' THEN
                            'VISA-PREM'
                        WHEN crd.ni_dom_ips_card_type != 0 THEN
                            'VISA-PREM'
                        ELSE
                            'VISA-STND'
                    END
            ELSE
                CASE
                    WHEN br.payment_scheme_code = 'O' THEN
                            'PRIVATE LABEL'
                    ELSE
                        upper(substr(br.payment_scheme, 1, decode(instr(br.payment_scheme, ' ', 1), 0, length(br.payment_scheme), instr(
                        br.payment_scheme, ' ', 1) - 1)))
                END
        END                                                                                               AS crd_pr_st,
        br.payment_scheme_code,
        tr.trans_arn,
        tr.doc_idt,
        nvl(tr.dept_code, 'N')                                                                            AS dept_code,
        decode(op.new_name, 'SALE', - 1, 1) * tr.nidt_amount                                              AS nidt_amount,
        decode(op.new_name, 'SALE', - 1, 1) * tr.nioo_amount                                              AS nioo_amount,
        decode(op.new_name, 'SALE', - 1, 1) * tr.nimid_amount                                             AS nimid_amount,
        decode(op.new_name, 'SALE', - 1, 1) * nvl(
            CASE
                WHEN tr.vat_nidt_amount = 0 THEN
                    decode(tr.nimid_amount, 0.05, - 1, 1) *(nvl(comm_sql.vat, 0) - round((tr.nimid_amount * cntr.vat_rate) / 100, 2))
                ELSE
                    to_number(tr.vat_nidt_amount)
            END, 0)                                                                                              AS vat_nidt_amount,
        decode(op.new_name, 'SALE', - 1, 1) * nvl(
            CASE
                WHEN tr.vat_nioo_amount = 0 THEN
                    nvl(comm_sql.vat, 0) - round((tr.nimid_amount * cntr.vat_rate) / 100, 2)
                ELSE
                    to_number(tr.vat_nioo_amount)
            END, 0)                                                                                              AS vat_nioo_amount,
        decode(op.new_name, 'SALE', - 1, 1) * nvl(
            CASE
                WHEN tr.vat_nimid_amount = 0
                     AND tr.nimid_amount != 0 THEN
                    round((tr.nimid_amount * cntr.vat_rate) / 100, 2)
                ELSE
                    to_number(tr.vat_nimid_amount)
            END, 0)                                                                                              AS vat_nimid_amount,
        decode(tr.domestic, 'Y', 'DMST', 'INTL')                                                          AS dom_int,
        tr.migs,
        tr.ptlf,
        tr.tc33,
        tr.bsp,
        tr.arc,
        tr.arc_tacn,
        tr.ai_f270,
        tr.ai_f268,
        tr.purch_id,
        tr.gway_idt,
        tr.trans_rrn,
        tr.cs_req_rec_id,
        tr.tip_amount,
        tr.tag_id,
        tr.driver_id,
        tr.card_id,
        tr.settl_date_trnpfus,
        cntr.mult,
        tr.gn_unique_id,
        cntr.vat_rate,
        cntr.addr_state,
        tr.mpgsorderid,
        tr.order_id,
        tr.upi_ecomm,
        tr.v1_tkn_rq_id,
        tr.qr_enabled,
        tr.domestic_2,
        tr.card_afs,
        tr.card_usage,
        tr.area_code                                                                                      AS area,
        tr.source_fiid,
        tr.channel,
        tr.gnusrfld1,
        tr.nm_stan
    FROM
             cntr
        JOIN cntr                 device ON device.parent_contract_idt = cntr.record_idt
                            AND cntr.type_code = 'ACQ_LVL'
                            AND cntr.code = 'MERCHANT'
        JOIN (
                SELECT
                    /*+ no_merge use_hash(i) swap_join_inputs(i) pq_distribute(e broadcast none) use_hash(op) swap_join_inputs(op) pq_distribute(op none broadcast)*/
                    op.type,
                    op.new_name,
                    op.code,
                    round(e.credit - e.debit, 2) AS amnt,
                    e.primary_doc_idt,
                    e.fee_rate_value,
                    e.contract_idt
                FROM
                         inst i
                    JOIN dwf_account_entry e ON i.id = e.institution_id and banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                    JOIN oper              op ON op.operation_type_id = e.operation_type_id and op.type = 'TRAN'       
        )                    op ON device.record_idt = op.contract_idt
        JOIN tr ON tr.doc_idt = op.primary_doc_idt
        JOIN (select /*+no_merge*/ * from dwd_currency curr where curr.record_state = 'A') curr ON curr.code = tr.trans_currency                                  
        JOIN (select /*+no_merge*/ * from dwd_currency settl_curr where settl_curr.record_state = 'A') settl_curr ON settl_curr.code = tr.settl_currency                                   
        LEFT JOIN dwd_card_brand       br ON br.id = tr.card_brand_id
        LEFT JOIN card_brand           crd ON br.code = crd.card_brand_code
        LEFT JOIN (select /*+no_merge*/ * from dwd_trans_conditions trcond where trcond.record_state = 'A') trcond ON tr.trans_conditions_id = trcond.id                                                 
        LEFT JOIN comm_sql ON comm_sql.primary_doc_idt = op.primary_doc_idt
)
SELECT
  /*+parallel(8)*/
    :ORG                                                          AS ORG,
    'DT'                                                          AS HD,
    merchant_id                                                   AS MERCHANT_ID,
    TRIM(substr(terminal_id, 1, 12))                              AS TERMINAL_ID,
    substr(gnusrfld1, 1, 3)                                       AS BATCH_NUMBER,
    substr(txn_seq_no, 3, 10)                                     AS SEQ_NUMBER,
    txn_date                                                      AS TRANSACTION_DATE,
    time                                                          AS TRANSACTION_TIME,
	-- [*][begin] 20220825.1 = PrabirK = NIBOA-7674
    decode(oper_name, 'SALE', 'PRCH', 'SALE REV', 'REVL',
           'REFUND', 'RFND', 'REFUND REV', 'RFND REV', oper_name) AS TRANSACTION_TYPE,
	-- [*][end]   20220825.1 = PrabirK = NIBOA-7674
    substr(card_no, 1, 6)
    || lpad('X', decode(card_no_length, 13, 3, 14, 4,
                        15, 5, 16, 6, 17,
                        7, 18, 8, 19, 9,
                        3), 'X')
    || substr(card_no, - 4)                                       AS CARD_NUMBER,
    auth_code                                                     AS AUTHORIZATION_CODE,
    card_type                                                     AS CARD_ISSUER,
    rlg_oper_name                                                 AS CAPTURE_DETAIL,
    fee_rate_value                                                AS MDR_COMISSION_RATE,
    txn_amount                                                    AS TRANS_AMOUNT_SRC_CNTR,
    trans_curr                                                    AS TRANS_CURR_SRC_CNTR,
    txn_amount                                                    AS TRANS_AMOUNT_IN_AED,
    trans_curr                                                    AS TRANS_CURR_IN_AED,
    commission                                                    AS MDR_COMISSION_AMOUNT,
    trans_curr                                                    AS TRANS_CURR_IN_AED_1,
    vat                                                           AS VAT_AMOUNT,
    trans_curr                                                    AS TRANS_CURR_IN_AED_2,
    NULL                                                          AS LOYALTY_NAME,
    nvl(NULL, 0)                                                  AS LOYALTY_RATE,
    nvl(NULL, 0)                                                  AS LOYALTY_AMOUNT,
    nvl(NULL, 'AED')                                              AS LOYALTY_CURRENCY,
    NULL                                                          AS LOYALTY_NAME1,
    nvl(NULL, 0)                                                  AS LOYALTY_RATE1,
    nvl(NULL, 0)                                                  AS LOYALTY_AMOUNT1,
    nvl(NULL, 'AED')                                              AS LOYALTY_CURRENCY1,
    NULL                                                          AS LOYALTY_NAME2,
    nvl(NULL, 0)                                                  AS LOYALTY_RATE2,
    nvl(NULL, 0)                                                  AS LOYALTY_AMOUNT2,
    nvl(NULL, 'AED')                                              AS LOYALTY_CURRENCY2,
    txn_amount + commission + vat								  AS PAY_AMOUNT_TO_MERCHANT, -- [*] 20220916.1 = PrabirK = NIBOA-7774
    (
        SELECT
            c.name
        FROM
            dwd_currency c
        WHERE
                c.code = trans_currency
            AND c.record_state = 'A'
    )                                                             AS PAY_AMT_CURR_IN_AED,
    NULL                                                          AS CARDHOLDER_AMOUNT,
    NULL                                                          AS CARDHOLDER_CURRENCY,
    NULL                                                          AS SUBVENTION_AMOUNT,
    NULL                                                          AS SUBVENTION_CURRENCY,
    NULL                                                          AS REFRENCE_NUMBER_BLANK,
    NULL                                                          AS DESCRIPTION_BLANK,
    nvl(NULL, 0)                                                  AS DESCRIPTION_BLANK_1,
    NULL                                                          AS DESCRIPTION_BLANK_2,
    ret_ref_no                                                    AS TRANSACTION_REFER_NUM,
    CASE
        WHEN migs = 'Y' THEN
            mpgsorderid
        ELSE
            NULL
    END                                                           AS MIGS_ORDER_REF_NUM,
    NULL                                                          AS MIGS_CBYS_TRANSACTION_REF_NUM,
    NULL                                                          AS MIGS_CBYS_CUSTOMER_REF_NUM,
    nm_stan                                                       AS STAN_NUMBER,
    dom_int                                                       AS TRANSACTION_REGION,
    NULL                                                          AS RECEIPT_NUMBER,
    trans_arn                                                     AS ARN_RETRIEVAL_NUMBER,
    NULL                                                          AS PEND_INDICATOR_BLANK,
    TRIM(bank_account)                                            AS MERCHANT_ACCOUNT_NUMBER,
    trans_fee                                                     AS TRANX_FEE,
    vat_on_fee                                                    AS TRANX_FEE_VAT,
    txn_date                                                      AS TRANX_DATE
FROM
    all_items
WHERE
    gc_chain2 = 'FLN'
    OR master_chain1 IS NOT NULL
ORDER BY
    all_items.merchant_id,
    all_items.card_type
