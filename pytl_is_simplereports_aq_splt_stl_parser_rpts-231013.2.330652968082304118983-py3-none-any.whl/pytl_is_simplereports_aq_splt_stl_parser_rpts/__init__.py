__version__ = "231013.2" 
__job_name__ = "PyTL_IS_SimpleReports_AQ_SPLT_STL_PARSER_RPTS"
__bat_files__ = []