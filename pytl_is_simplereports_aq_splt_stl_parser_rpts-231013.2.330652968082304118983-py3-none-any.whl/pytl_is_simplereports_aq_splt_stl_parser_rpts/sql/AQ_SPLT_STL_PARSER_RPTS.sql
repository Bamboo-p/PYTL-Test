/*
* Code for AQ_SPLT_STL_PARSER_RPTS
* PyTL_IS_SimpleReports_AQ_SPLT_STL_PARSER_RPTS = AQ_SPLT_STL_PARSER_RPTS.sql
* Version history:
* 231002.1 : NIBOA-8602 : PrabirK  : Initial development
* 231004.1 : NIBOA-8968 : PrabirK  : Logic change for split_servc_fee_chrg
* 231009.1 : NIBOA-8602 : PrabirK  : Excluded transaction when service fee amount is empty
* 231012.1 : NIBOA-8602 : PrabirK  : Removed extract filter from  cntr_trans subquery
* 231013.1 : NIBOA-8602 : PrabirK  : File name changed
* 231013.2 : NIBOA-8602 : PrabirK  : Formatting of columns
*/
WITH inst AS (
    SELECT /*+ no_merge */
        id
    FROM
        dwh.dwd_institution
    WHERE
            record_state = 'A'
        AND code = :ORG
), oper AS (
    SELECT /*+ no_merge materialize */
         op.operation_type_id
        ,op.operation_type_code
        ,op.code
        ,op.purpose
        ,CASE
            WHEN nvl(tot.type_total, '') = 'TOTAL_TRANSACTIONS' THEN
                'TRAN'
            WHEN op.code = 'VAT'                                THEN
                'VAT'
            WHEN instr(op.purpose, ',VAT_ON_FEE,') > 0          THEN
                'VAT'
            WHEN instr(op.purpose, ',TRANS_FEE,') > 0           THEN
                'TRANS_FEE'
            WHEN instr(op.purpose, ',COMM,') > 0                THEN
                'COMM'
            WHEN instr(op.purpose, ',REBATE,') > 0              THEN
                'REBATE'
         END AS type
    FROM
        (
            SELECT /*+ inline no_merge materialize */
                 op.operation_type_id       AS operation_type_id
                ,op.operation_type_code     AS operation_type_code
                ,op.code                    AS code
                ,','
                ||
                LISTAGG(op.type_code, ',') WITHIN GROUP(
                    ORDER BY
                        op.type_code
                    )
                || ','                      AS purpose
                ,nvl(MIN(op.name), op.code) AS name
            FROM
                (
                    SELECT
                         op.operation_type_id
                        ,op.operation_type_code
                        ,op.name
                        ,op.code
                        ,op.sort_order
                        ,op.type_code
                    FROM
                        dwh.v_dwr_operation_type op
                    WHERE
                        op.class_code = 'ACQ_SETTLEMENT_REPORT'
                ) op
            GROUP BY
                 op.operation_type_id
                ,op.operation_type_code
                ,op.code
        ) op
        LEFT JOIN (
            SELECT /*+ no_merge materialize */
                 operation_type_id AS operation_type_id
                ,code              AS type_total
            FROM
                dwh.v_dwr_operation_type
            WHERE
                    class_code = 'ACQ_REPORTS'
                AND type_code = 'DA_TOTALS'
        ) tot ON tot.operation_type_id = op.operation_type_id
    WHERE
        nvl(tot.type_total, '') = 'TOTAL_TRANSACTIONS'
        OR instr(op.purpose, ',COMM_CODE,') > 0
), contr_attr AS (
    SELECT /*+ no_merge leading(attr dca) */
         dca.contract_idt
        ,attr.type_code
        ,attr.code
    FROM
             dwh.dwa_contract_attribute dca
        JOIN dwh.dwd_attribute attr ON attr.id = dca.attr_id
                                       AND TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') BETWEEN attr.record_date_from AND attr.record_date_to
                                       AND TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') BETWEEN dca.attr_date_from AND dca.attr_date_to
                                       AND dca.active_state = 'A'
                                       AND attr.type_code IN ( 'ACQ_SPLIT_SETTLEMENT_FLAG' )
                                       AND attr.record_state != 'C'
), trans_type AS (
    SELECT /*+ materialize */
         id
        ,code
        ,name
        ,request_category
        ,direction
        ,CASE
            WHEN code IN ( 'R1-P', 'DCCR1-P', 'K1-R', 'DCCK1-R' ) THEN
                'SALE'
            WHEN code IN ( 'K1-P', 'DCCK1-P', 'R1-R', 'DCCR1-R' ) THEN
                'REFUND'
         END AS type_group
    FROM
        dwh.dwd_transaction_type
    WHERE
            record_state = 'A'
        AND service_class = 'T'
        AND request_category IN ( 'R', 'P' )
        AND code IN ( 'R1-P', 'R1-R', 'K1-P', 'K1-R', 'DCCR1-P',
                      'DCCR1-R', 'DCCK1-P', 'DCCK1-R' )
), tar AS (
    SELECT  /*+ no_merge */
         t.domain                                                       AS contract_idt
        ,MAX(decode(t.type_code, 'ACQ_MRFA_SS', st.fee_base_amount, 0)) AS merchant_serv_shr_fix
        ,MAX(decode(t.type_code, 'ACQ_MMPR_SS', st.fee_rate_value, 0))  AS merchant_serv_shr_per
    FROM
             dwh.dwd_tariff t
        JOIN dwh.dwd_service_tariff st ON st.record_idt = t.record_idt
                                      AND st.record_state != 'C'
                                      AND t.record_state != 'C'
                                      AND t.role = 'SERVICE'
                                      AND t.type_code IN ( 'ACQ_MRFA_SS', 'ACQ_MMPR_SS' )
                                      AND TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') BETWEEN t.record_date_from AND t.record_date_to
                                      AND TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') BETWEEN st.record_date_from AND st.record_date_to
    GROUP BY
        t.domain
), addrs AS (
    SELECT
         ova.contract_idt
        ,ova.address_line_1
        ,ova.address_line_2
    FROM
             dwh.opt_v_address ova
        JOIN inst ON inst.id = ova.institution_id
                     AND TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') BETWEEN ova.record_date_from AND ova.record_date_to
                     AND ova.record_state != 'C'
    WHERE
        ova.address_type_code = 'STMT_ADDR'
), contracts AS (
    SELECT /*+ no_merge ordered use_hash(attr dca) use_hash(cntr inst) ordered index(cntr DWD_CONTRACT_IDT_IDX) */
         cntr.personal_account
        ,cntr.record_idt
        ,dca.contract_idt
        ,decode(attr.code, 'MERCHANT', cntr.record_idt, cntr.parent_contract_idt) AS parent_contract_idt
        ,attr.code
        ,tar.merchant_serv_shr_fix
        ,tar.merchant_serv_shr_per
        ,nvl(ca.code, 'N')                                                        AS acq_split_settlement_flag
        ,substr(cntr.add_info, instr(cntr.add_info, 'PAY_MODE=') + 9,(instr(cntr.add_info, ';', instr(cntr.add_info, 'PAY_MODE=')) - instr(
         cntr.add_info, 'PAY_MODE=') - 9))                                        AS pay_mode
        ,substr(cntr.add_info, instr(cntr.add_info, 'SPSETL=') + 7,(instr(cntr.add_info, ';', instr(cntr.add_info, 'SPSETL=')) - instr(
         cntr.add_info, 'SPSETL=') - 7))                                          AS spsetl
        ,substr(cntr.add_info, instr(cntr.add_info, 'CREDITACCT=') + 11,(instr(cntr.add_info, ';', instr(cntr.add_info, 'CREDITACCT=')) -
         instr(cntr.add_info, 'CREDITACCT=') - 11))                               AS iban_acnt_nmbr
        ,addrs.address_line_1
        ,addrs.address_line_2
    FROM
             dwh.dwd_contract cntr
        JOIN inst ON inst.id = cntr.institution_id
                     AND TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') BETWEEN cntr.record_date_from AND cntr.record_date_to
                     AND cntr.record_state != 'C'
        LEFT JOIN tar ON tar.contract_idt = cntr.personal_account
        JOIN dwh.dwa_contract_attribute dca ON cntr.record_idt = dca.contract_idt
        JOIN dwh.dwd_attribute          attr ON attr.id = dca.attr_id
                                       AND TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') BETWEEN attr.record_date_from AND attr.record_date_to
                                       AND TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') BETWEEN dca.attr_date_from AND dca.attr_date_to
                                       AND dca.active_state = 'A'
                                       AND attr.type_code IN ( 'ACQ_LVL' )
                                       AND attr.code IN ( 'MERCHANT', 'DEVICE' )
                                       AND attr.record_state != 'C'
        LEFT JOIN contr_attr                 ca ON ca.contract_idt = cntr.record_idt
        LEFT JOIN addrs ON addrs.contract_idt = cntr.record_idt
), cntr AS (
    SELECT /*+ materialize no_merge leading(ch cntr) */
         cn.contract_idt
        ,dev.contract_idt AS record_idt
        ,cn.personal_account
        ,cn.merchant_serv_shr_fix
        ,cn.merchant_serv_shr_per
        ,cn.acq_split_settlement_flag
        ,cn.pay_mode
        ,cn.spsetl
        ,cn.iban_acnt_nmbr
		,cn.address_line_1
		,cn.address_line_2
    FROM
             contracts cn
        JOIN contracts dev ON dev.parent_contract_idt = cn.contract_idt
                              AND cn.code = 'MERCHANT'
							  AND cn.acq_split_settlement_flag = 'Y'
), entr AS (
    SELECT
  /*+ no_merge materialize leading(cntr e) index(e DWF_ACCOUNT_ENTRY_CONT_IDX) parallel(e 4) */
         e.primary_doc_idt                                          AS doc_idt
        ,SUM(decode(op.type, 'TRAN',(e.credit - e.debit), 0))       AS trans_amount
        ,SUM(decode(op.type, 'COMM',(e.credit - e.debit), 0))       AS comm
        ,SUM(decode(op.type, 'TRANS_FEE',(e.credit - e.debit), 0))  AS fee
        ,SUM(decode(op.code, 'VAT',(e.credit - e.debit), 0))        AS vat_on_comm
        ,SUM(decode(op.code, 'VAT_ON_FEE',(e.credit - e.debit), 0)) AS vat_on_fee
    FROM
             cntr
        JOIN dwh.dwf_account_entry e ON e.contract_idt = cntr.record_idt
                                    AND e.banking_date >= trunc(add_months(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'), - 1), 'MM')
                                    AND e.banking_date <= last_day(add_months(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'), - 1))
        JOIN oper              op ON op.operation_type_id = e.operation_type_id
                        AND op.type IN ( 'TRAN', 'COMM', 'VAT', 'TRANS_FEE' )
        JOIN inst ON inst.id = e.institution_id
    GROUP BY
        e.primary_doc_idt
), cntr_trans as (
    SELECT /*+ no_merge materialize leading(cntr tr) index(tr DWF_TRANSACTION_SCNTR_IDX) parallel(tr 4) */
         tr.doc_idt
        ,tr.banking_date
        ,tt.code
        ,tt.type_group
        ,tt.request_category
        ,cntr.personal_account
        ,cntr.contract_idt
        ,cntr.merchant_serv_shr_fix
        ,cntr.merchant_serv_shr_per
        ,cntr.pay_mode
        ,cntr.spsetl
        ,cntr.iban_acnt_nmbr
        ,substr(tr.add_info, instr(tr.add_info, 'SERVFEE_AMOUNT=') + 15,(instr(tr.add_info, ';', instr(tr.add_info, 'SERVFEE_AMOUNT=')) -
         instr(tr.add_info, 'SERVFEE_AMOUNT=') - 15)) AS split_servc_fee_chrg
        ,curr.name                                    AS curr_name
        ,cntr.address_line_1
        ,cntr.address_line_2
    FROM
             cntr
        JOIN dwh.dwf_transaction tr ON tr.source_contract_idt = cntr.record_idt
                                    --   AND cntr.acq_split_settlement_flag = 'Y' -- [*] 231012.1 = PrabirK = NIBOA-8602
                                           AND tr.banking_date >= trunc(add_months(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'), - 1), 'MM')
                                               AND tr.banking_date <= last_day(add_months(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'), - 1))
        JOIN trans_type          tt ON tt.id = tr.transaction_type_id
        JOIN inst                i ON i.id = tr.institution_id
        JOIN dwh.dwd_currency    curr ON curr.code = tr.trans_currency
                                      AND curr.record_state = 'A'
        LEFT JOIN addrs ON addrs.contract_idt = cntr.contract_idt
		WHERE instr(tr.add_info, 'SERVFEE_AMOUNT=')> 0 -- [*] 231009.1 = PrabirK = NIBOA-8602
), all_items AS (
    SELECT
         tr.personal_account
        ,tr.iban_acnt_nmbr
		,tr.address_line_1
		,tr.address_line_2
        ,decode(tr.type_group, 'SALE', 1, 0)    AS sale_item
        ,decode(tr.type_group, 'REFUND', 1, 0)  AS refund_item
        ,CASE
            WHEN tr.type_group = 'SALE' THEN
                entr.trans_amount
            ELSE
                0
         END                                    AS sale_amount
        ,CASE
            WHEN tr.type_group = 'REFUND' THEN
                entr.trans_amount
            ELSE
                0
         END                                    AS refund_amount
        ,tr.merchant_serv_shr_fix               AS fee_base
        ,tr.merchant_serv_shr_per               AS fee_pcnt
        ,tr.pay_mode
        ,tr.spsetl
        ,decode(tr.type_group, 'SALE', tr.split_servc_fee_chrg, 0)   AS ser_sale_item    -- [*] 231004.1 = PrabirK = NIBOA-8968
		,decode(tr.type_group, 'REFUND', tr.split_servc_fee_chrg, 0) AS ser_refund_item  -- [*] 231004.1 = PrabirK = NIBOA-8968
        ,tr.curr_name
    FROM
             cntr_trans tr
        JOIN entr ON entr.doc_idt = tr.doc_idt
), full AS (
    SELECT
         personal_account
        ,iban_acnt_nmbr
		,address_line_1
		,address_line_2
        ,SUM(sale_item)            AS sale_cnt
        ,SUM(refund_item)          AS refund_cnt
        ,SUM(sale_amount)          AS sale_amount
        ,SUM(refund_amount)        AS refund_amount
        ,fee_base                  AS fixed_rate
        ,fee_pcnt                  AS fixed_pcnt
        ,pay_mode
        ,spsetl
        ,SUM(ser_sale_item)        AS sale_service_fee
		,SUM(ser_refund_item)      AS refund_service_fee
        ,curr_name
    FROM
        all_items
    GROUP BY
         personal_account
        ,iban_acnt_nmbr
		,address_line_1
		,address_line_2
        ,pay_mode
        ,spsetl
        ,fee_base
        ,fee_pcnt
        ,curr_name
), full_t AS (
    SELECT
         org
        ,personal_account                           AS merchant_id
        ,iban_acnt_nmbr
		,address_line_1
		,address_line_2
        ,pay_mode
        ,to_char(SUM(net_amount), 'FM999999990D00') AS net_amount
        ,curr_name
    FROM
        (
            SELECT
                 :ORG AS org
                ,personal_account
                ,iban_acnt_nmbr
				,address_line_1
				,address_line_2
                ,pay_mode
                ,CASE
                    WHEN spsetl = 'P' THEN
                        ( ( ( sale_amount - sale_service_fee ) - ( abs(refund_amount) - refund_service_fee ) ) * ( fixed_pcnt / 100 ) )
                    WHEN spsetl = 'F' THEN
                        ( ( sale_cnt - refund_cnt ) * fixed_rate )
                    WHEN spsetl = 'B' THEN
                        ( ( ( sale_amount - sale_service_fee ) - ( abs(refund_amount) - refund_service_fee ) ) * ( fixed_pcnt / 100 ) ) + ( (
                    sale_cnt - refund_cnt ) * fixed_rate )
                 END   AS net_amount
                ,curr_name
            FROM
                full
            WHERE
                pay_mode IS NOT NULL
        )
    WHERE 
    	ABS(net_amount) > 0
    GROUP BY
         org
        ,personal_account
        ,iban_acnt_nmbr
		,address_line_1
		,address_line_2
        ,pay_mode
        ,curr_name
), final AS (
    SELECT
         org
        ,'TXNDET'
         || ','
		 || 'P'
         || merchant_id
         || to_char(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'), 'DDD')
         || ',,'
         || address_line_1
         || ',,,,'
         || iban_acnt_nmbr
         || ','
         || CASE
             WHEN pay_mode IN ( 'FN', 'EQ' ) THEN
                     'TR'
             ELSE
                 pay_mode
            END
         || ','
         || net_amount
         || ','
         || curr_name
         || ','
         || address_line_2
         || ','
         || 'ARE'
         || ',,,,,,,'
         || 'ARE'
         || ','
         || 'NI POS SETT '
         || TO_CHAR(TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY'),'DDMMYY')
         || ' '
         || merchant_id
         || ',,,POS,,,,,,,,,,,,'        AS summ
        ,pay_mode                       AS report_pay_mode
        ,curr_name
        ,'NI'
         || 'S'
         || to_char(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'), 'YYMMDD')
         || pay_mode
         || '1'
         || curr_name                   AS txn_report_type
        ,'NI'
         || 'S'
         || to_char(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'), 'YYMMDD')
         ||
         CASE
             WHEN pay_mode IN ( 'FN', 'EQ' ) THEN
                     'TR'
             ELSE
                 pay_mode
         END
         || curr_name
         || '1'                          AS txn_report_group
        ,CASE 
		    WHEN :ORG = '200' THEN
			        'NI'
			WHEN :ORG = '221' THEN
			        'CB'
            ELSE
                    NULL
         END					
         || 'SF' -- [*] 231013.1 = PrabirK = NIBOA-8602
		 || 
         CASE
             WHEN pay_mode IN ( 'FN', 'EQ' ) THEN
                     'TR'
             ELSE
                 pay_mode
         END
         || curr_name
         || to_char(to_date(sysdate, 'DD-MM-YYYY'), 'DDMMYY')
         || '1'
         || '_NISETL_ENF_'
         || to_char(sysdate, 'YYYYMMDD')
         || 'T'
         || to_char(sysdate, 'HH24MISS') AS parser_file_name
    FROM
        full_t
), total AS (
    SELECT
         org
        ,txn_report_type
        ,txn_report_group
        ,parser_file_name
        ,curr_name
        ,COUNT(txn_report_type) AS pay_count
    FROM
        final
    GROUP BY
         org
        ,txn_report_type
        ,txn_report_group
        ,parser_file_name
        ,curr_name
), total_group AS (
    SELECT
         org
        ,txn_report_group
        ,parser_file_name
        ,COUNT(txn_report_group) AS pay_group_count
    FROM
        total
    GROUP BY
         org
        ,txn_report_group
        ,parser_file_name
), total_record AS (
    SELECT
         tg.org
        ,tg.txn_report_group
        ,tg.parser_file_name
        ,tg.pay_group_count + tt.pay_count + 1 AS record_count
    FROM
             total_group tg
        JOIN (
            SELECT
                 txn_report_group
                ,SUM(pay_count) AS pay_count
            FROM
                total
            GROUP BY
                txn_report_group
        ) tt ON tt.txn_report_group = tg.txn_report_group
)

SELECT
     org
    ,parser_file_name
    ,summ
FROM
    (
        SELECT
             fin.org
            ,fin.parser_file_name
            ,fin.txn_report_group
            ,fin.txn_report_type
            ,fin.summ               AS summ
            ,3                      AS record_order
            ,3                      AS orderby
            ,ROWNUM                 AS rn
        FROM
            final fin
        UNION
        SELECT
             tot.org
            ,tot.parser_file_name
            ,tot.txn_report_group
            ,tot.txn_report_type
            ,'TXNHDR'
             || ','
             || tot.txn_report_type
             || ','
             || 'BEN'
             || ','
             || tot.pay_count
             || ','
             || '!<<REC>>!'
             || ','
             || '0'
             || ','
             || 'C'
             || ','
             ||
             CASE
                     WHEN tot.curr_name = 'AED' THEN
                         '1011333911713'
                     WHEN tot.curr_name = 'USD' THEN
                         '1021333911705'
                     ELSE
                         NULL
             END
             || ','
             || tot.curr_name
             || ','
             || 'UAE'
             || ','
             || ',,,0,,,,,0,D,E,MerchantSettlementUnit@Network.ae,C,,,,,,,'  AS summ
            ,2                                                               AS record_order
            ,2                                                               AS orderby
            ,2                                                               AS rn
        FROM
            total tot
        UNION
        SELECT
             tgr.org
            ,tgr.parser_file_name
            ,tgr.txn_report_group
            ,NULL                                                            AS txn_report_type
            ,'FILHDR'
             || ','
             || tgr.txn_report_group
             || ','
             || 'NISETL'
             || ','
             || tgr.pay_group_count
             || ','
             || ttr.record_count
             || ','
             || to_char(sysdate, 'DD-MM-YYYY')
             || ','
             || to_char(sysdate, 'HH24:MI:SS')
             || ','
             || 'P,E,MerchantSettlementUnit@Network.ae,C'                    AS summ
            ,1                                                               AS record_order
            ,1                                                               AS orderby
            ,1                                                               AS rn
        FROM
                 total_group tgr
            JOIN total_record ttr ON ttr.txn_report_group = tgr.txn_report_group
                                     AND ttr.org = tgr.org
                                     AND ttr.parser_file_name = tgr.parser_file_name
    )
ORDER BY
     org
    ,parser_file_name
    ,txn_report_group
    ,txn_report_type NULLS FIRST
    ,orderby
    ,record_order
    ,rn