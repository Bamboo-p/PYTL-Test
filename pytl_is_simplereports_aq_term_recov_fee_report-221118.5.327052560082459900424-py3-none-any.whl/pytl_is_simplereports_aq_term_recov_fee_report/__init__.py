__version__ = "221118.5"
__job_name__ = "PyTL_IS_SimpleReports_AQ_TERM_RECOV_FEE_REPORT"
__bat_files__ = []
