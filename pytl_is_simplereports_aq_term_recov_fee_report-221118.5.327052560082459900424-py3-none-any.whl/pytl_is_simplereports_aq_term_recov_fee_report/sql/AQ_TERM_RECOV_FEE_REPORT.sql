/*
* NIBO TERMINAL RECOVERY FEE REPORT
*
* Version history:
* 221003.1 = RabindraSi = NIIN-182 : Initial Version
* 221108.2 = RabindraSi = NIIN-237 : Fixed to fetch correct records
* 221116.3 = PrabirK    = NIIN-237 : Changing the Report SQL from DWH to WAY4
* 221117.4 = PrabirK    = NIIN-237 : Adding Schema name to WAY4 Tables
* 221118.5 = PrabirK    = NIIN-237 : Adding Schema name to Functions
*/

WITH inst AS (
    SELECT /*+ no_merge materialize */
        fi.name,
        fi.bank_code,
        fi.id                   AS institution_id,
        ';' || fi.special_parms AS add_info
    FROM
        ows.f_i fi -- [*] 221117.4 = PrabirK = NIIN-237
    WHERE
            fi.amnd_state = 'A'
        AND fi.bank_code = :ORG
)
SELECT
    :ORG                                                                                                     AS ORG,
    MAX(dev.contract_number)                                                                                 AS TID,
    MAX(mer.contract_number)                                                                                 AS MID,
    MAX(nvl(tdata.min_rq_amount, 0))                                                                         AS TERMINAL_RECOVERY_AMOUNT,
    MAX(
        CASE
            WHEN bal.available <= 0 THEN
                tdata.min_rq_amount
            ELSE
                nvl(tdata.min_rq_amount, 0) - bal.available
        END
    )                                                                                                        AS RECOVERED_BY_CURRENT_DEV,
    MAX(
        CASE
            WHEN csv.code = 'R'
                 AND bal.available > 0 THEN
                tdata.min_rq_amount
            ELSE
                nvl(to_number(ows.glob.get_tag_value(dev.add_info_04, 'DTCR')), 0)   -- [*] 221118.5 = PrabirK = NIIN-237
        END
    )                                                                                                        AS RECOVERED_BY_OTHER_TIDS,
    MAX(
        CASE
            WHEN bal.available <= 0 THEN
                tdata.min_rq_amount
            ELSE
                nvl(tdata.min_rq_amount, 0) - bal.available
        END
    ) + MAX(
        CASE
            WHEN csv.code = 'R'
                 AND bal.available > 0 THEN
                tdata.min_rq_amount
            ELSE
                nvl(to_number(ows.glob.get_tag_value(dev.add_info_04, 'DTCR')), 0)   -- [*] 221118.5 = PrabirK = NIIN-237
        END
    )                                                                                                        AS RECOVERED_UNTIL_TODAY,
    MAX(nvl(tdata.min_rq_amount, 0)) - ( MAX(
        CASE
            WHEN bal.available <= 0 THEN
                tdata.min_rq_amount
            ELSE
                nvl(tdata.min_rq_amount, 0) - bal.available
        END
    ) + MAX(
        CASE
            WHEN csv.code = 'R'
                 AND bal.available > 0 THEN
                tdata.min_rq_amount
            ELSE
                nvl(to_number(ows.glob.get_tag_value(dev.add_info_04, 'DTCR')), 0)   -- [*] 221118.5 = PrabirK = NIIN-237
        END
    ) )                                                                                                      AS PENDING_TO_RECOVER,
    MAX(greatest(to_char(bal.state_date, 'ddmmyyyy'), nvl(ows.glob.get_tag_value(dev.add_info_04, 'DTCRD'), 0))) AS LAST_CHARGE_DATE  -- [*] 221118.5 = PrabirK = NIIN-237
FROM 
    -- [*] [begin] 221117.4 = PrabirK = NIIN-237
         ows.acnt_contract dev
    JOIN ows.acnt_contract   mer ON mer.id = dev.liab_contract
    JOIN inst ON inst.institution_id = dev.f_i
    JOIN ows.cs_status_log   csl ON csl.acnt_contract__oid = dev.id
    JOIN ows.cs_status_type  cst ON cst.id = csl.status_type
                               AND cst.code = 'ACQ_DEV_TC'
    JOIN ows.cs_status_value csv ON cst.id = csv.cs_status_type__oid
                                AND csv.amnd_state = 'A'
                                AND csl.status_value = csv.id
    JOIN ows.acnt_balance    bal ON bal.acnt_contract__oid = dev.id
                             AND bal.balance_type_code = 'DEV_TERMINAL_COST'
    LEFT JOIN ows.add_pack_inc    td ON td.acnt_contract__oid = dev.id
                                 AND td.is_active = 'Y'
                                 AND pack_type = 'OWN_DOMAIN'
    LEFT JOIN ows.tariff          t ON t.tariff_domain__oid = td.add_pack
                          AND t.table_code_from = 'MISC_DEV_TC'
                          AND t.amnd_state = 'A'
    LEFT JOIN ows.tariff_data     tdata ON tdata.tariff__oid = t.id
                                   AND tdata.amnd_state = 'A'
                                   AND tdata.is_active = 'Y'
	-- [*] [end] 221117.4 = PrabirK = NIIN-237
WHERE
        1 = 1
    AND dev.amnd_state = 'A'
    AND mer.amnd_state = 'A'
    AND mer.f_i = dev.f_i
    AND csl.bank_date >= add_months(to_date(:P_REPORT_DATE, 'dd-mm-yyyy'), - 3)
    AND bank_date_to >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
GROUP BY
    dev.id
ORDER BY
    MID,
    TID