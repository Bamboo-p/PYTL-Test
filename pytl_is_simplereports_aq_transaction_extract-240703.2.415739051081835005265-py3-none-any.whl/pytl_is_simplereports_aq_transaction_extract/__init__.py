__version__ = "240703.2" 
__job_name__ = "PyTL_IS_SimpleReports_AQ_TRANSACTION_EXTRACT"
__bat_files__ = []