/*
* CODE FOR AQ_TRANSACTION_EXTRACT
* PYTL_IS_SIMPLEREPORTS_AQ_TRANSACTION_EXTRACT = AQ_TRANSACTION_EXTRACT.SQL
* VERSION HISTORY:
* 230607.1 : NIBOA-8556 : PADALAS  : INITIAL DEVELOPMENT
* 230720.1 : NIBOA-8615 : PADALAS  : UPDATED CODE TO HAVE FEE & ADJUSTMENT TRANSACTIONS
* 230727.1 : NIBOA-8615 : PADALAS  : UPDATED CODE TO REMOVE DUPLICATE DOC ID'S WHICH ARE LINKED
* 230728.1 : NIBOA-8615 : PADALAS  : RECOMMIT - UPDATED CODE TO REMOVE DUPLICATE DOC ID'S WHICH ARE LINKED
* 230731.1 : NIBOA-8615 : PADALAS  : UPDATED CARD_USAGE & AREA_CODE LOGIC
* 230807.1 : NIBOA-8615 : PADALAS  : RE-UPDATED AREA_CODE LOGIC
* 240226.1 : NIBOA-9646 : PADALAS  : UPDATE IN CARD_TYPE LOGIC 
* 240703.2 : NIBOA-10238 : PADALAS  : UPDATED LOGIC FOR CARD_TYPE TO INCLUDE JAYWAN DETAILS TO FETCH & ADDED VAT DETAILS TO FETCH
*/
WITH inst AS
  (SELECT
    /*+ no_merge materialize */
    id
  FROM dwd_institution
  WHERE record_state = 'A'
  AND code           = :ORG
  ),
  oper AS
  (SELECT
    /*+ no_merge materialize */
    op.operation_type_id,
    op.NAME,
    op.code,
    op.purpose,
    CASE
      WHEN op.code = 'VAT'
      THEN 'VAT'
      WHEN instr(op.purpose, ',VAT_ON_FEE,') > 0
      THEN 'VAT_ON_FEE'
      WHEN instr(op.purpose, ',VAT_ON_REFUND_FEE,') > 0
      THEN 'VAT_ON_FEE'
      WHEN op.code in ('VAT_ON_AUTHFEE','VAT_ON_DISPFEE')
      THEN 'VAT_ON_FEE'
      WHEN instr(op.purpose, ',COMM,') > 0
      THEN 'COMM'
      WHEN instr(op.purpose, ',TRANS_FEE,') > 0
      THEN 'TRANS_FEE'
      WHEN op.code in ('DEVC_TERMCOSTREC_FEE','VAT_TERMCOSTREC_FEE')
      THEN 'TERM_REC_FEE'
    END AS TYPE,
    CASE
      WHEN op.code IN ('RETAIL','REFUND_REV','CASH','XLS_REV','XLS_SALE','DCC_RETAIL','M_CR_ADJ_DCC','CR_CBK_ADJ_DCC','DCC_CREDIT_REV','QR_SALE','QR_REFUND_REV')
      THEN 'SALE'
      WHEN op.code IN ('CASH_REV','RETAIL_REV','QR_SALE_REV')
      THEN 'SALE REV'
      WHEN op.code IN ('XLS_FUND','XLS_REFUND','DCC_CREDIT','M_DT_ADJ_DCC','DB_CBK_ADJ_DCC','DCC_RETAIL_REV','REFUND','QR_REFUND')
      THEN 'REFUND'
      WHEN op.code = 'MMF'
      THEN 'MBR FEE'
      WHEN op.code = 'STATEMENT_FEE'
      THEN 'STMT FEE'
      WHEN op.code = 'REFUND_FEE'
      THEN 'REF FEE'
      WHEN instr(op.purpose, ',COMM,') > 0
      THEN 'COMM'
      WHEN op.code = 'FRD_CR_ADJ'
      THEN 'FRD CR'
      WHEN op.code = 'FRD_DB_ADJ'
      THEN 'FRD DB'
      WHEN op.code = 'FRAUD_FEE'
      THEN 'FRD FEE'
      WHEN op.code = 'ACQ_AUTH_FEE'
      THEN 'AUTH FEE'
      WHEN op.code = 'ACQ_AUTH_FEE_REV'
      THEN 'AUTH REV'
      WHEN op.code = 'ACQ_DISPUTE_FEE'
      THEN 'DISP FEE'
      ELSE REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(op.name, 'SUBVENTION', 'SUBV'), 'CREDIT', 'CR'), 'DEBIT', 'DB'), ' ADJ', ''), 'CHARGEBACK', 'CHBK'), 'MANUAL', 'M'), ' DR', ' DB'),
                          'STARTUP FEE', 'SETUP FEE') ,'INT SETUP FEE', 'INT SETP')
    END AS trans_type,
    CASE
      WHEN instr(op.purpose, ',ACCOUNTED,') > 0
      OR op.code LIKE 'REBATE%'
      OR op.code in ('ACQ_AUTH_FEE','ACQ_DISPUTE_FEE','ACQ_AUTH_FEE_REV')
      OR op.code IN ('FRD_CR_ADJ','FRD_DB_ADJ')
      THEN 1
      ELSE 0
    END AS accounted,
    CASE
      WHEN instr(op.purpose, ',COMM,') > 0
      THEN
        CASE
          WHEN op.code IN ('CASHBACK_COMM','CASH_COMM','DCC_RETAIL_COMM','CR_COMM_REV','DCC_CREDIT_COMM_REV','M_CR_ADJ_COMM_DCC','R_COMM')
          THEN 'MIN DISC'
          ELSE 'DISC REF'
        END
      WHEN instr(op.purpose, ',TRANS_FEE,') > 0
      THEN 'TRANS_FEE'
      WHEN op.code in ('DEVC_TERMCOSTREC_FEE','VAT_TERMCOSTREC_FEE')
      THEN 'TERM REC FEE'
      ELSE NULL
    END AS comm_type,
    CASE
      WHEN instr(op.purpose, ',CARD_NUMBER,') > 0
      THEN 1
      ELSE 0
    END AS card_flag
  FROM
    (SELECT
      /*+ no_merge */
      op.operation_type_id   AS operation_type_id,
      op.operation_type_code AS operation_type_code,
      op.code                AS code,
      ','
      || listagg(op.type_code, ',') WITHIN GROUP (
    ORDER BY op.type_code)
      || ','                     AS purpose,
      NVL(MIN(op.NAME), op.code) AS NAME
    FROM
      (SELECT op.operation_type_id,
        op.operation_type_code,
        op.NAME,
        op.code,
        op.sort_order,
        op.type_code
      FROM v_dwr_operation_type op
      WHERE op.class_code = 'ACQ_SETTLEMENT_REPORT'
      ) op
    GROUP BY op.operation_type_id,
      op.operation_type_code,
      op.code
    ) op
  LEFT JOIN
    (SELECT
      /*+ no_merge */
      operation_type_id AS operation_type_id,
      code              AS type_total
    FROM v_dwr_operation_type
    WHERE class_code = 'ACQ_REPORTS'
    AND type_code    = 'DA_TOTALS'
    ) tot
  ON tot.operation_type_id = op.operation_type_id
  WHERE op.code NOT LIKE '%RTA%'
  AND (instr(op.purpose, ',COMM_CODE,') > 0
  OR instr(op.purpose, ',ACCOUNTED,')   > 0
  OR op.code        IN ('VAT_ON_REFUND_FEE','FRD_CR_ADJ','FRD_DB_ADJ','DEVC_TERMCOSTREC_FEE','VAT_TERMCOSTREC_FEE'))
  ),
  acnt_entry as
  (SELECT
      /*+ no_merge materialize use_hash(e i) */
      e.*
    FROM dwf_account_entry e
    JOIN inst i
    ON i.ID = e.institution_id
    WHERE banking_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  ),
  comm_sql_gr AS
  (SELECT
    /*+ no_merge use_hash(entr op) */
    entr.contract_idt,
    entr.primary_doc_idt,
    MAX(DECODE(op.TYPE,'COMM',entr.fee_rate_value, NULL)) fee_rate_value,
    SUM (DECODE(op.comm_type,'MIN DISC',credit-debit,0)) min_disc,
    SUM (DECODE(op.comm_type,'DISC REF',credit-debit,0)) disc_ref,
    SUM (DECODE(op.type,'TRANS_FEE',credit    -debit,0)) trans_fee,
    SUM (DECODE(op.code,'VAT',credit          -debit,0)) vat_comm,
    SUM (DECODE(op.TYPE,'VAT_ON_FEE',credit   -debit,0)) VAT_ON_FEE,
    SUM (DECODE(op.code,'DEVC_TERMCOSTREC_FEE',credit   -debit,0)) TERM_REC_FEE,
    SUM (DECODE(op.code,'VAT_TERMCOSTREC_FEE',credit   -debit,0)) VAT_TERM_REC_FEE
  FROM
    acnt_entry entr
  JOIN oper op
  ON op.operation_type_id = entr.operation_type_id
  AND op.TYPE   IN ('COMM','VAT', 'TRANS_FEE','VAT_ON_FEE')
  GROUP BY entr.primary_doc_idt,
    entr.contract_idt
  ),
  comm_sql AS
  (SELECT
    /*+ no_merge materialize */
    primary_doc_idt,
    MAX(fee_rate_value)                           AS fee_rate_value,
    SUM(NVL(min_disc,0)  + NVL(disc_ref,0))       AS comm,
    SUM(NVL(vat_comm,0)) + SUM(NVL(vat_on_fee,0)) AS vat,
    SUM(NVL(vat_comm,0))                          AS vat_comm,
    SUM(NVL(vat_on_fee,0))                        AS vat_on_fee
  FROM comm_sql_gr
  GROUP BY primary_doc_idt
  ),
  contract AS
  (SELECT
    /*+ no_merge materialize ordered(cattr attr cn) */
    cn.record_idt,
    cn.personal_account,
    DECODE(attr.code, 'MERCHANT', cn.record_idt, cn.parent_contract_idt) AS parent_contract_idt,
    attr.code,
    cn.add_info
  FROM dwd_contract cn
  INNER JOIN inst ins
  ON cn.institution_id = ins.ID
  INNER JOIN dwa_contract_attribute cattr
  ON cn.record_idt = cattr.contract_idt
  AND to_date(:P_REPORT_DATE,'dd-mm-yyyy') BETWEEN cattr.attr_date_from AND cattr.attr_date_to
  INNER JOIN dwd_attribute attr
  ON attr.ID = cattr.attr_id
  AND to_date(:P_REPORT_DATE,'dd-mm-yyyy') BETWEEN attr.record_date_from AND attr.record_date_to
  AND attr.type_code = 'ACQ_LVL'
  AND attr.code     IN ('DEVICE', 'MERCHANT')
  WHERE to_date(:P_REPORT_DATE,'dd-mm-yyyy') BETWEEN cn.record_date_from AND cn.record_date_to
  ),
  addr AS
  (SELECT
    /*+ no_merge */
  COALESCE(merch_addr.address_line_2,'NA') AS merch_location,
  merch_addr.contract_idt,
  COALESCE(merch_addr.phone,merch_addr.phone_home,merch_addr.phone_mobile,'NA') AS telephone,
  merch_addr.address_line_1                                                     AS merch_name
  FROM opt_v_address merch_addr
  WHERE merch_addr.record_state != 'C'
  AND merch_addr.address_type_code = 'STMT_ADDR'
  AND to_date(:P_REPORT_DATE,'dd-mm-yyyy') BETWEEN merch_addr.record_date_from AND merch_addr.record_date_to
  ),
  card_brand AS
  (SELECT
    /*+ no_merge */
    cb.code card_brand_code,
    SUM(DECODE(v.type_code,'NI_DOM_IPS_CARD_TYPE',1,0)) ni_dom_ips_card_type,
    SUM(DECODE(v.type_code,'NI_INT_IPS_CARD_TYPE',1,0)) ni_int_ips_card_type,
    SUM(DECODE(v.type_code,'NI_SUP_IPS_CARD_TYPE',1,0)) ni_sup_ips_card_type
  FROM v_dwr_lowest_level v,
    dwd_card_brand cb
  WHERE v.type_code  IN ('NI_DOM_IPS_CARD_TYPE','NI_INT_IPS_CARD_TYPE','NI_SUP_IPS_CARD_TYPE')
  AND cb.record_state = 'A'
  AND cb.ID = v.dim_record_id
  GROUP BY cb.code
  ),
  contr_addr as (
    SELECT /*+ ordered no_merge materialize use_hash(device cntr) use_hash(cntr ad) */
    cntr.record_idt as contract_idt,
    ad.merch_name,
    ad.merch_location,
    ad.telephone
  FROM contract cntr
  JOIN addr ad ON ad.contract_idt = cntr.record_idt
  WHERE cntr.code   = 'MERCHANT'
  ),
  all_items AS
  (SELECT /*+ ordered no_merge use_hash(device cntr) use_hash(device op) use_hash(cntr merch_addr) use_hash(op tr) use_hash(tr comm_sql) use_hash(tr br) use_hash(br crd) use_hash(tr trcond) use_hash(tr curr) */
    cntr.personal_account       AS merchant_id,
    cntr.record_idt             AS contract_idt,
    merch_addr.merch_name       AS merchant_name,
    merch_addr.merch_location,
    merch_addr.telephone,
    DECODE(op.card_flag, 1, DECODE(op.contract_idt, tr.source_contract_idt, tr.source_number, tr.target_number),'') AS  terminal_id,
    tr.trans_rrn,
    tr.trans_arn,
    curr.NAME                   AS trans_curr,
    TO_CHAR(NVL(tr.trans_date,to_date(:P_REPORT_DATE,'dd-mm-yyyy')),'dd/mm/yyyy')   AS  txn_date,
    TO_CHAR(NVL(tr.banking_date,to_date(:P_REPORT_DATE,'dd-mm-yyyy')),'dd/mm/yyyy') AS  banking_date,
    DECODE(op.card_flag, 1, DECODE(op.contract_idt, tr.source_contract_idt, tr.target_number, tr.source_number),'') AS  card_no,
    LENGTH(trim(DECODE(op.contract_idt, tr.source_contract_idt, tr.target_number, tr.source_number)))   AS  card_no_length,
    tr.auth_code                AS auth_code,
    op.amnt                     AS  txn_amount,
    NVL(case when op.code in ('ACQ_AUTH_FEE', 'ACQ_DISPUTE_FEE', 'ACQ_AUTH_FEE_REV') then 0 else comm_sql.comm end, 0)  AS commission,
    op.amnt + NVL(case when op.code in ('ACQ_AUTH_FEE', 'ACQ_DISPUTE_FEE', 'ACQ_AUTH_FEE_REV') then 0 else comm_sql.comm end, 0) +
    NVL(case when op.code in ('ACQ_AUTH_FEE', 'ACQ_DISPUTE_FEE', 'ACQ_AUTH_FEE_REV') then comm_sql.vat_on_fee else comm_sql.vat end, 0) + op.vat        AS net_amount,
    REPLACE(REPLACE(substr(cntr.add_info, instr(cntr.add_info, 'CREDITACCT=')+11,
            (instr(cntr.add_info, ';', instr(cntr.add_info, 'CREDITACCT='))-instr(cntr.add_info, 'CREDITACCT=')-11)), chr(10)), chr(13))     AS bank_account,
    TO_CHAR(tr.trans_date, 'HH24:MI:SS')        AS txn_time,
    NVL(substr(tr.add_info, instr(tr.add_info, 'TCASHBACK_AMOUNT=')+17,
            (instr(tr.add_info, ';', instr(tr.add_info, 'TCASHBACK_AMOUNT='))-instr(tr.add_info, 'TCASHBACK_AMOUNT=')-17)),0)/100       AS pwcb_cashback,
    REPLACE(REPLACE(substr(tr.add_info, instr(tr.add_info, 'ACQDAT=')+7,
            (instr(tr.add_info, ';', instr(tr.add_info, 'ACQDAT='))-instr(tr.add_info, 'ACQDAT=')-7)), chr(10)), chr(13))       AS acquirer_data,
    REPLACE(REPLACE(substr(cntr.add_info, instr(cntr.add_info, 'MERCH_TYPE=')+11,
            (instr(cntr.add_info, ';', instr(cntr.add_info, 'MERCH_TYPE='))-instr(cntr.add_info, 'MERCH_TYPE=')-11)), chr(10)), chr(13))     AS merch_type,
    NVL(DECODE(op.code,'CR_CBK_ADJ',comm_sql.vat_comm,'DB_CBK_ADJ',comm_sql.vat_comm,'CB_FEE',comm_sql.vat_on_fee,'ACQ_AUTH_FEE',comm_sql.vat_on_fee,
    'ACQ_DISPUTE_FEE',comm_sql.vat_on_fee,'ACQ_AUTH_FEE_REV',comm_sql.vat_on_fee,comm_sql.vat), 0) + op.vat AS vat,
    CASE
      WHEN crd.ni_sup_ips_card_type != 0
      AND NVL(br.payment_scheme_code,'NA') = 'E'
      THEN 'M/TVL'
      WHEN crd.ni_sup_ips_card_type != 0
      AND NVL(br.payment_scheme_code,'NA') = 'V'
      THEN 'V/TVL'
      WHEN crd.ni_int_ips_card_type != 0
      AND NVL(substr(cntr.add_info, instr(cntr.add_info, 'ACQ_INT_RPRC=')+13,
            (instr(cntr.add_info, ';', instr(cntr.add_info, 'ACQ_INT_RPRC='))-instr(cntr.add_info, 'ACQ_INT_RPRC=')-13)),'N') = 'Y'
      AND NVL(substr(tr.add_info, instr(tr.add_info, 'DOMESTIC=')+9,
            (instr(tr.add_info, ';', instr(tr.add_info, 'DOMESTIC='))-instr(tr.add_info, 'DOMESTIC=')-9)),'N') != 'Y'
      THEN 'P'
      WHEN crd.ni_dom_ips_card_type != 0
      THEN 'P'
      ELSE 'S'
    END AS trn_typ,
    CASE
      WHEN trcond.condition_list LIKE '%,KEY_ENTRY,%'
      THEN 'MAN'
      ELSE 'ELC'
    END AS man_elec,
    op.trans_type,
    CASE
	WHEN tr.target_channel = 'JAYWAN'
    THEN 'JAYWAN'
    WHEN tr.target_channel = 'NPCI'
    THEN 'NPCI QR'
    WHEN tr.target_channel = '7'
    AND tr.crdtyp = 'CB'
    AND bt.bin_details like '%CBUAE%'
    THEN 'Internal CBUAE'
    WHEN bt.channel = 'V'
    AND tr.QR_ENABLED = 'Y'
    THEN 'VISA QR'
    WHEN bt.channel = 'E'
    AND tr.QR_ENABLED = 'Y'
    THEN 'MC QR'
    WHEN tr.target_channel = '8'
    THEN 'ALP'
    WHEN tr.target_channel = 'Z'
    THEN 'WEC'
    WHEN tr.target_channel = 'TP'
    THEN 'TERRAPAY'
    WHEN tr.target_channel IN ('7','O')
    AND tr.reward_seqv     IS NOT NULL
    THEN 'INTERNAL '
      || upper(tr.reward_seqv)
    WHEN tr.target_channel = '7'
    AND bt.ips_product_idn = 'PRIVATE'
    THEN 'INTERNAL P/L'
    WHEN tr.target_channel = '7'
    AND bt.channel         = 'E'
    THEN 'INTERNAL MC'
    WHEN tr.target_channel = '7'
    AND bt.channel         = 'V'
    THEN 'INTERNAL VISA'
    WHEN tr.target_channel = '7'
    AND bt.channel         = 'C'
    THEN 'INTERNAL DINERS'
    WHEN tr.target_channel = 'e'
    AND bt.channel         = 'E'
    THEN 'OUR MC'
    WHEN tr.target_channel = 'v'
    AND bt.channel         = 'V'
    THEN 'OUR VISA'
    WHEN tr.target_channel = 'c'
    AND bt.channel         = 'C'
    THEN 'OUR DINERS'
    WHEN tr.target_channel = '1'
    AND bt.channel         = 'E'
    THEN 'VPLUS MC'
    WHEN tr.target_channel = '1'
    AND bt.channel         = 'V'
    THEN 'VPLUS VISA'
    WHEN tr.target_channel = '1'
    AND bt.channel         = 'C'
    THEN 'VPLUS DINERS'
    WHEN bt.channel       = 'E'
    AND tr.target_channel = 'D'
    AND tr.crdfiid        = 'MDS'
    AND tr.crdtyp         = 'P8'
    THEN 'MDS'
    WHEN bt.channel = 'E'
    THEN 'M/C'
    WHEN bt.channel = 'V'
    THEN 'VISA'||decode(op.code, 'AFT', ' AFT', 'AFT_REV', ' AFT')
    WHEN bt.channel = 'C'
    THEN 'DINER'
    WHEN bt.channel = 'J'
    THEN 'JCB'
    WHEN bt.channel = 'H'
    THEN 'CUP'
    WHEN bt.channel = 'Q'
    THEN 'MERCU'
    WHEN bt.channel = 'D'
    THEN 'MDS'
    WHEN bt.ips_product_idn = 'PRIVATE'
    THEN 'P/L'
    WHEN tr.target_channel = 'NPCI'
    THEN 'NPCI QR'
    ELSE NULL
  END card_type,
    NVL(substr(tr.add_info, instr(tr.add_info, 'MIGS=')+5,
            (instr(tr.add_info, ';', instr(tr.add_info, 'MIGS='))-instr(tr.add_info, 'MIGS=')-5)),'N') AS migs,
    NVL(substr(tr.add_info, instr(tr.add_info, 'PTLF=')+5,
            (instr(tr.add_info, ';', instr(tr.add_info, 'PTLF='))-instr(tr.add_info, 'PTLF=')-5)),'N') AS ptlf,
    CASE
      WHEN instr(tr.add_info, 'FROM_CYBERSOURCE') > 0
      THEN 'Y'
      ELSE 'N'
    END AS tc33,
    CASE
      WHEN tr.source_message_code LIKE 'IATA%'
      THEN 'Y'
      ELSE 'N'
    END             AS bsp,
    CASE
      WHEN tr.source_message_code LIKE '%ARC%'
      THEN 'Y'
      ELSE 'N'
    END             AS arc,
    substr(tr.add_info, instr(tr.add_info, 'AI_F270=')+8,
            (instr(tr.add_info, ';', instr(tr.add_info, 'AI_F270='))-instr(tr.add_info, 'AI_F270=')-8))  AS ai_f270,
    substr(tr.add_info, instr(tr.add_info, 'AI_F268=')+8,
            (instr(tr.add_info, ';', instr(tr.add_info, 'AI_F268='))-instr(tr.add_info, 'AI_F268=')-8))  AS ai_f268,
    substr(tr.add_info, instr(tr.add_info, 'PURCH_ID=')+9,
            (instr(tr.add_info, ';', instr(tr.add_info, 'PURCH_ID='))-instr(tr.add_info, 'PURCH_ID=')-9)) AS purch_id,
    substr(tr.add_info, instr(tr.add_info, 'CS_REQ_REC_ID=')+14,
            (instr(tr.add_info, ';', instr(tr.add_info, 'CS_REQ_REC_ID='))-instr(tr.add_info, 'CS_REQ_REC_ID=')-14))                                     AS cs_req_rec_id,
    REPLACE(REPLACE(substr(tr.add_info, instr(tr.add_info, 'RI_TIP_AMOUNT=')+14,
            (instr(tr.add_info, ';', instr(tr.add_info, 'RI_TIP_AMOUNT='))-instr(tr.add_info, 'RI_TIP_AMOUNT=')-14)), chr(10)), chr(13)) AS tip_amount,
    REPLACE(REPLACE(substr(tr.add_info, instr(tr.add_info, 'RI_TAG_ID=')+10,
            (instr(tr.add_info, ';', instr(tr.add_info, 'RI_TAG_ID='))-instr(tr.add_info, 'RI_TAG_ID=')-10)), chr(10)), chr(13))     AS tag_id,
    REPLACE(REPLACE(substr(tr.add_info, instr(tr.add_info, 'RI_DRIVER_ID=')+13,
            (instr(tr.add_info, ';', instr(tr.add_info, 'RI_DRIVER_ID='))-instr(tr.add_info, 'RI_DRIVER_ID=')-13)), chr(10)), chr(13))  AS driver_id,
    REPLACE(REPLACE(substr(tr.add_info, instr(tr.add_info, 'RI_CARD_ID=')+11,
            (instr(tr.add_info, ';', instr(tr.add_info, 'RI_CARD_ID='))-instr(tr.add_info, 'RI_CARD_ID=')-11)), chr(10)), chr(13))    AS card_id,
    substr(tr.add_info, instr(tr.add_info, 'TXN_DETAIL=')+11, (instr(tr.add_info, ';', instr(tr.add_info, 'TXN_DETAIL='))-instr(tr.add_info, 'TXN_DETAIL=')-11)) AS txn_detail,
    REPLACE(REPLACE(substr(tr.add_info, instr(tr.add_info, 'DOMESTIC=')+9, (instr(tr.add_info, ';', instr(tr.add_info, 'DOMESTIC='))-instr(tr.add_info, 'DOMESTIC=')-9)), chr(10)), chr(13)) AS DOMESTIC_2,
    SUBSTR(tr.add_info, instr(tr.add_info, 'GNUSRFLD1=')+10, (instr(tr.add_info, ';', instr(tr.add_info, 'GNUSRFLD1='))-instr(tr.add_info, 'GNUSRFLD1=')-10)) AS GNUSRFLD1,
   case when instr(tr.add_info, 'CARD_AFS=D;') > 0 then 'DEBIT'
     when instr(tr.add_info, 'CARD_AFS=C;') > 0 then 'CREDIT'
     when instr(tr.add_info, 'CARD_AFS=P;') > 0 then 'PREPAID'
     when instr(tr.add_info, 'CARD_AFS=R;') > 0 then 'DEF DEBIT'
     when instr(tr.add_info, 'CARD_AFS=H;') > 0 then 'CHARGE'
     when instr(tr.add_info, 'CARD_AFS=N;') > 0 then 'NON MC'
     else null
    end AS CARD_USAGE,
    SUBSTR(tr.add_info, instr(tr.add_info, 'V1_TKN_RQ_ID=') +13, (instr(tr.add_info, ';', instr(tr.add_info, 'V1_TKN_RQ_ID='))-instr(tr.add_info, 'V1_TKN_RQ_ID=')-13)) AS v1_tkn_rq_id,
    SUBSTR(tr.add_info, instr(tr.add_info, 'MPGSOrderId=')  +12, (instr(tr.add_info, ';', instr(tr.add_info, 'MPGSOrderId='))-instr(tr.add_info, 'MPGSOrderId=')-12)) AS MPGSOrderId,
    SUBSTR(tr.add_info, instr(tr.add_info, 'SOURCE_FIID=')+12, (instr(tr.add_info, ';', instr(tr.add_info, 'SOURCE_FIID='))-instr(tr.add_info, 'SOURCE_FIID=')-12)) AS SOURCE_FIID,
     SUBSTR(tr.add_info, instr(tr.add_info, 'GN_UNIQUE_ID=')    +13, (instr(tr.add_info, ';', instr(tr.add_info, 'GN_UNIQUE_ID='))-instr(tr.add_info, 'GN_UNIQUE_ID=')-13))                       AS gn_unique_id,
     NVL(SUBSTR(tr.add_info, instr(tr.add_info, 'UPI_ECOMM=') +10, (instr(tr.add_info, ';', instr(tr.add_info, 'UPI_ECOMM='))-instr(tr.add_info, 'UPI_ECOMM=')-10)),'N')                             AS UPI_ECOMM,
    SUBSTR(tr.add_info, instr(tr.add_info, 'ORDER_ID=') +9, (instr(tr.add_info, ';', instr(tr.add_info, 'ORDER_ID='))-instr(tr.add_info, 'ORDER_ID=')-9)) AS ORDER_ID,
    CASE
      WHEN crd.ni_sup_ips_card_type != 0
      AND NVL(br.payment_scheme_code,'NA') = 'E'
      THEN 'M/TVL'
      WHEN crd.ni_sup_ips_card_type != 0
      AND NVL(br.payment_scheme_code,'NA') = 'V'
      THEN 'V/TVL'
      WHEN crd.ni_int_ips_card_type != 0
      AND NVL(substr(cntr.add_info, instr(cntr.add_info, 'ACQ_INT_RPRC=')+13,
            (instr(cntr.add_info, ';', instr(cntr.add_info, 'ACQ_INT_RPRC='))-instr(cntr.add_info, 'ACQ_INT_RPRC=')-13)),'N') = 'Y'
            AND NVL(substr(tr.add_info, instr(tr.add_info, 'DOMESTIC=')+9,
            (instr(tr.add_info, ';', instr(tr.add_info, 'DOMESTIC='))-instr(tr.add_info, 'DOMESTIC=')-9)),'N') != 'Y'
      THEN 'PREMIUM'
      WHEN crd.ni_dom_ips_card_type != 0
      THEN 'PREMIUM'
      ELSE 'STANDARD'
    END AS disc_type,
    case
      when ac.COUNTRY_CODE=tr.TRANS_COUNTRY_CODE then 'Domestic'
      when ac.COUNTRY_CODE = 'ARE' then 'GCC'
      when ac.COUNTRY_CODE = 'KWT' then 'GCC'
      when ac.COUNTRY_CODE = 'BHR' then 'GCC'
      when ac.COUNTRY_CODE = 'OMN' then 'GCC'
      when ac.COUNTRY_CODE = 'QAT' then 'GCC'
      when ac.COUNTRY_CODE = 'SAU' then 'GCC'
    else null
   end as AREA
  FROM contract device
  JOIN contract cntr
  ON device.parent_contract_idt = cntr.record_idt
  AND cntr.code                 = 'MERCHANT'
  JOIN
    (SELECT /*+ no_merge use_hash(trans_entr op) */ op.code,
      op.trans_type,
      trans_entr.credit - trans_entr.debit AS amnt,
      0                                    AS vat,
      trans_entr.primary_doc_idt,
      trans_entr.contract_idt,
      op.card_flag
    FROM
      acnt_entry trans_entr
    JOIN oper op
    ON op.operation_type_id = trans_entr.operation_type_id
    AND op.accounted    = 1
    UNION
    SELECT 'MIN DISC' AS code,
      'MIN DISC'      AS trans_type,
      SUM(min_disc)   AS amnt,
      SUM(vat_comm)   AS vat,
      0               AS doc_idt,
      contract_idt,
      0 AS card_flag
    FROM comm_sql_gr
    WHERE min_disc != 0
    GROUP BY contract_idt
    UNION
    SELECT 'DISC REF' AS code,
      'DISC REF'      AS trans_type,
      SUM(disc_ref)   AS amnt,
      SUM(vat_comm)   AS vat,
      0               AS doc_idt,
      contract_idt,
      0 AS card_flag
    FROM comm_sql_gr
    WHERE disc_ref != 0
    GROUP BY contract_idt
    UNION
    SELECT 'TRAN FEE' AS code,
      'TRAN FEE'      AS trans_type,
      SUM(trans_fee)  AS amnt,
      SUM(vat_on_fee) AS vat,
      0               AS doc_idt,
      contract_idt,
      0 AS card_flag
    FROM comm_sql_gr
    WHERE trans_fee != 0
    GROUP BY contract_idt
    UNION
    SELECT 'TERM REC FEE' AS code,
      'TERM REC FEE'      AS trans_type,
      SUM(TERM_REC_FEE)  AS amnt,
      SUM(VAT_TERM_REC_FEE) AS vat,
      0               AS doc_idt,
      contract_idt,
      0 AS card_flag
    FROM comm_sql_gr
    WHERE (TERM_REC_FEE != 0 OR VAT_TERM_REC_FEE !=0)
    GROUP BY contract_idt
    ) op ON op.contract_idt = device.record_idt
  LEFT JOIN contr_addr merch_addr
  ON merch_addr.contract_idt = cntr.record_idt
  LEFT JOIN
    (SELECT
      /*+ no_merge */
      tr.*,
      SUBSTR(tr.add_info, instr(tr.add_info, 'REWARD_SEQV=')+12, (instr(tr.add_info, ';', instr(tr.add_info, 'REWARD_SEQV='))-instr(tr.add_info, 'REWARD_SEQV=')-12)) AS reward_seqv,
    SUBSTR(tr.add_info, instr(tr.add_info, 'CRDFIID=')    +8, (instr(tr.add_info, ';', instr(tr.add_info, 'CRDFIID='))-instr(tr.add_info, 'CRDFIID=')-8))           AS crdfiid,
    SUBSTR(tr.add_info, instr(tr.add_info, 'CRDTYP=')     +7, (instr(tr.add_info, ';', instr(tr.add_info, 'CRDTYP='))-instr(tr.add_info, 'CRDTYP=')-7))             AS crdtyp,
    case when instr(tr.add_info, 'QR_TRAN=Y;') > 0 then 'Y' else 'N' end AS QR_ENABLED
    FROM dwf_transaction tr
    JOIN inst i
    ON i.ID               = tr.institution_id
    WHERE tr.banking_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy')
    ) tr ON tr.doc_idt    = op.primary_doc_idt  
  LEFT JOIN dwd_currency curr
  ON curr.code          = tr.trans_currency
  AND curr.record_state = 'A'
  LEFT JOIN dwd_bin_table bt
  ON bt.record_idt    = tr.bin_table_idt
  AND bt.record_state = 'A'
  LEFT JOIN dwd_card_brand br
  ON br.ID = tr.card_brand_id
  LEFT JOIN card_brand crd
  ON br.code = crd.card_brand_code
  LEFT JOIN dwd_trans_conditions trcond
  ON tr.trans_conditions_id = trcond.ID
  LEFT JOIN comm_sql
  ON comm_sql.primary_doc_idt = tr.doc_idt
  LEFT JOIN DWD_BIN_TABLE ac
  ON tr.BIN_TABLE_IDT=ac.record_idt
  AND ac.record_state != 'C'
  AND to_date(:P_REPORT_DATE,'dd-mm-yyyy') between ac.record_date_from and ac.record_date_to
  WHERE NVL(br.payment_scheme_code,'NO') != 'X'
  ),
full_q AS (
SELECT
substr(merchant_id, - 9)  AS merchant_id,
  '' AS master_chain1,
  merchant_name,
  merch_location,
   telephone,
     SUBSTR(terminal_id,1,12) AS terminal_id,
       SUBSTR(trans_rrn,3,10) AS seq_no,
  NVL(trans_curr, 'AED') AS trans_curr,
    txn_date,
    CASE
    WHEN trans_type LIKE 'SUBV%'
    THEN trans_type
    ELSE NULL
  END AS subv,
  card_type,
  CASE
    WHEN card_no IS NULL
    THEN '      XXXXXX'
    ELSE SUBSTR(card_no,1,6)
      || lpad('X',DECODE(card_no_length,13,3,14,4,15,5,16,6,17,7,18,8,19,9,3),'X')
      || SUBSTR(card_no,-4)
  END                     AS card_no,
  banking_date,
    auth_code,
    case
   when trans_type in ('MIS FEE','MIS FEE REV')
    then txn_detail
   else trans_type
   end AS trans_type,
  txn_amount,
  commission,
    vat,
  net_amount,
    CASE
    WHEN arc = 'Y' THEN ai_f270
    WHEN migs = 'Y'
    THEN
      CASE
        WHEN acquirer_data IS NULL
        THEN rpad(SUBSTR(ai_f270,0,13),34,' ')
          || SUBSTR(ai_f268,0,6)
        ELSE acquirer_data
      END
    WHEN bsp = 'Y'
    THEN SUBSTR(ai_f270,0,13)
    WHEN ptlf = 'Y'
    THEN rpad(tip_amount,12,' ')
      || rpad(driver_id,10,' ')
      || rpad(tag_id,10,' ')
      || rpad(card_id,17,' ')
    WHEN tc33 = 'Y'
    THEN
      CASE
        WHEN trans_rrn IS NULL
        THEN
          CASE
            WHEN purch_id IS NULL
            THEN
              CASE
                WHEN cs_req_rec_id IS NULL
                THEN SUBSTR(ai_f270,0,13)
                ELSE rpad(cs_req_rec_id,26,' ')
              END
            ELSE rpad(purch_id,25,' ')
              || lpad(SUBSTR(purch_id,6,12),12,' ')
          END
        ELSE rpad(purch_id,25,' ')
          || rpad(trans_rrn,12,' ')
      END
    ELSE acquirer_data
  END        AS acqdat,
  trans_rrn as ret_ref_no,
  lpad(merch_type,2,'0') AS store_type,
  bank_account,
   txn_time,
     NVL(bank_account,'NO ACCT') AS iban,
     disc_type,
      case
   when trans_type in ('SALE REV','REFUND')
    then NVL(tip_amount/100,'0.00')*(-1)
   else NVL(tip_amount/100,'0.00')
  end AS tip_amount,
    tag_id,
  driver_id,
   NVL(pwcb_cashback,'0.00')                                 AS pwcb_cashback,
     case
    when migs='Y' then MPGSOrderId
    when ptlf='Y' and SOURCE_FIID = 'NGEN' then purch_id
    when ptlf='Y' and SOURCE_FIID != 'NGEN' then gn_unique_id
    when UPI_ECOMM='Y' then ORDER_ID
    else null
  end order_ref,
    v1_tkn_rq_id,
CARD_USAGE,
  trans_arn,
  GNUSRFLD1 as batnum,
 CASE
      WHEN (DOMESTIC_2 = 'Y' OR AREA = 'Domestic') THEN 'Domestic'
      WHEN AREA = 'GCC' THEN 'GCC'
      WHEN DOMESTIC_2 = 'N' THEN 'Intl'
      ELSE ''
    END AS AREA_CODE
 FROM all_items
),
tots AS
  (SELECT
    /*+ materialize */
    substr(merchant_id, - 9)   AS t_merchant_id,
    contract_idt,
    COUNT(1)                                                               AS count_by_merch,
    SUM(txn_amount)                                                        AS tot_amount,
    SUM(commission)                                                        AS tot_commission,
    SUM(vat)                                                               AS tot_vat_comm,
    SUM(net_amount)                                                        AS tot_net_amount,
    NVL(SUM(tip_amount),0)                                                 AS tot_tip
  FROM all_items
      GROUP BY
        contract_idt,
        substr(merchant_id, - 9)
  )
SELECT
    /*+parallel(8)*/
    *
FROM
    (
        SELECT
            /*+no_merge*/
            :ORG   AS org,
            merchant_id,
            summ,
            orderby,
            rec_order,
            ROWNUM AS rn
        FROM
            (
                SELECT
                    /*+no_merge*/
                    merchant_id,
                    2      AS rec_order,
                    2      AS orderby,
                    lpad(ROW_NUMBER()
                         OVER(PARTITION BY merchant_id
                              ORDER BY
                                  merchant_id
                         ), 5, '0')
                    || ';'
                    || rpad(nvl(merchant_id, ' '), 11, ' ')
                    || ';'
                    || rpad(nvl(master_chain1, ' '), 9, ' ')
                    || ';'
                    || rpad(nvl(merchant_name, ' '), 40, ' ')
                    || ';'
                    || rpad(nvl(merch_location, ' '), 40, ' ')
                    || ';'
                    || rpad(nvl(telephone, ' '), 15, ' ')
                    || ';'
                    || rpad(nvl(terminal_id, ' '), 12, ' ')
                    || ';'
                    || rpad(nvl(seq_no, ' '), 10, ' ')
                    || ';'
                    || rpad(nvl(trans_curr, ' '), 5, ' ')
                    || ';'
                    || rpad(nvl(txn_date, ' '), 10, ' ')
                    || ';'
                    || rpad(nvl(card_type, ' '), 15, ' ')
                    || ';'
                    || rpad(nvl(card_no, ' '), 19, ' ')
                    || ';'
                    || rpad(nvl(auth_code, ' '), 13, ' ')
                    || ';'
                    || rpad(nvl(trans_type, ' '), 8, ' ')
                    || ';'
                    || lpad(TRIM(to_char(nvl(txn_amount, 0), '999999999990.99')), 12, ' ')
                    || ';'
                    || lpad(TRIM(to_char(nvl(commission, 0), '999999999990.99')), 10, ' ')
                    || ';'
                    || lpad(TRIM(to_char(nvl(vat, 0), '999999999990.99')), 10, ' ')
                    || ';'
                    || lpad(TRIM(to_char(nvl(net_amount, 0), '999999999990.99')), 12, ' ')
                    || ';'
                    || rpad(nvl(acqdat, ' '), 49, ' ')
                    || ';'
                    || rpad(nvl(ret_ref_no, ' '), 12, ' ')
                    || ';'
                    || rpad(nvl(store_type, ' '), 2, '0')
                    || ';'
                    || rpad(nvl(bank_account, ' '), 15, ' ')
                    || ';'
                    || rpad(nvl(txn_time, ' '), 8, ' ')
                    || ';'
                    || rpad(nvl(iban, ' '), 30, ' ')
                    || ';'
                    || rpad(nvl(disc_type, ' '), 10, ' ')
                    || ';'
                    || lpad(nvl('', ' '), 9, ' ')
                    || ';'
                    || lpad(TRIM(to_char(nvl(tip_amount, 0), '999999999990.99')), 7, ' ')
                    || ';'
                    || rpad(nvl(tag_id, ' '), 10, ' ')
                    || ';'
                    || rpad(nvl(driver_id, ' '), 10, ' ')
                    || ';'
                    || lpad(TRIM(to_char(nvl(pwcb_cashback, 0), '999999999990.99')), 8, ' ')
                    || ';'
                    || rpad(nvl(order_ref, ' '), 40, ' ')
                    || ';'
                    || rpad(nvl(v1_tkn_rq_id, ' '), 28, ' ')
                    || ';'
                    || rpad(nvl(area_code, ' '), 8, ' ')
                    || ';'
                    || rpad(nvl(CARD_USAGE, ' '), 10, ' ')
                    || ';'
                    || rpad(nvl(trans_arn, ' '), 23, ' ')
                    || ';'
                    || rpad(nvl(batnum, ' '), 3, ' ')
                    || ';'      AS summ
                FROM
                    full_q
            )
        UNION ALL
        SELECT
            /*+no_merge*/
            :ORG AS org,
            t_merchant_id,
            lpad(count_by_merch, 5, '0')
            || ';           ;000000000;MERCHANT TOTALS >>>                     ;                                        ;               ;            ;          ;     ;          ;               ;                   ;             ;        ;'
            || lpad(TRIM(to_char(nvl(tot_amount, 0), '999999999990.99')), 12, ' ')
            || ';'
            || lpad(TRIM(to_char(nvl(tot_commission, 0), '999999999990.99')), 10, ' ')
            || ';'
            || lpad(TRIM(to_char(nvl(tot_vat_comm, 0), '999999999990.99')), 10, ' ')
            || ';'
            || lpad(TRIM(to_char(nvl(tot_net_amount, 0), '999999999990.99')), 12, ' ')
            || ';                                                 ;            ;  ;               ;  :  :  ;                              ;          ;'
            || lpad(nvl('', ' '), 9, ' ')
            || ';'
            || lpad(TRIM(to_char(nvl(tot_tip, 0), '999999999990.99')), 7, ' ')
            || ';          ;          ;        ;                                        ;                            ;        ;          ;                       ;   ;',
            5    orderby,
            1    AS rec_order,
            1    AS rn
        FROM
            tots
        UNION ALL
        SELECT
            /*+no_merge*/
            :ORG AS org,
            merchant_id,
            'SRL  ;MERCHANT ID;CHAIN-ID ;MERCHANT NAME                           ;LOCATION                                ;TELEPHONE      ;TERMINAL    ;SEQUENCE  ;TRAN ;TRAN      ;CARD           ;CREDIT CARD        ;AUTHORIZATION;TRAN    ;       SALES;COMMISSION;       VAT;         NET;ACQUIRER DATA                                    ;REFERENCE NO;TY;BANK ACCOUNT   ;--TIME--;BANK ACCOUNT 30B              ;DISC TYPE ; MASTER  ;  TIP  ;    TAG   ;   DRIVER ;  PWCB  ;ORDER REFERENCE                         ;TOKEN                       ;AREA    ;CARD USAGE;ARN                    ;BAT;'
            || CHR(13)
            || CHR(10)
            || 'NO.  ;           ;         ;                                        ;                                        ;               ;ID          ;NUMBER    ;CURR.;DATE      ;TYPE           ;NUMBER             ;CODE         ;TYPE    ;      AMOUNT;          ;    AMOUNT;      AMOUNT;                                                 ;            ;  ;               ;HH:MM:SS;                                         ;CHAIN-ID ;AMOUNT ;     ID   ;   ID     ;CASHBACK;                                        ;TRAN ID                     ;        ;          ;                       ;NUM;',
            1    AS orderby,
            1    AS rec_order,
            1    AS rn
        FROM
            full_q
        GROUP BY
            merchant_id
    )
ORDER BY
    merchant_id,
    orderby,
    rec_order,
    rn