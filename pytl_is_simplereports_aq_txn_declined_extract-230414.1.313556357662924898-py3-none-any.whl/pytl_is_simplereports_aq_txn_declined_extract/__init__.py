__version__ = "230414.1"
__job_name__ = "PyTL_IS_SimpleReports_AQ_TXN_DECLINED_EXTRACT"
__bat_files__ = []
