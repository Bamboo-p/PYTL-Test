/*
* Code for AQ_TXN_DECLINED_EXTRACT
* PyTL_IS_SimpleReports_AQ_TXN_DECLINED_EXTRACT = AQ_TXN_DECLINED_EXTRACT.sql
* Version history:
* 230414.1 : PRD-23767 : PrabirK  : Initial development
*/
WITH inst AS (
    SELECT /*+ no_merge materialize */
        id        AS inst_id
        ,bank_code org
        ,name

    FROM
        ows.f_i

    WHERE
            amnd_state = 'A'
        AND bank_code IN (
            SELECT
                TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org

            FROM
                dual

            CONNECT BY
                regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL
        )
), doc_info AS (
    SELECT /*+ no_merge materialize */
        c.f_i                                           AS inst_id
        ,d.amnd_date
        ,d.id
		,d.ret_ref_number
        ,d.acq_ref_number
        ,d.auth_code
        ,d.is_authorization
        ,d.trans_type
        ,d.request_category
        ,d.source_channel
        ,d.source_number
        ,d.source_contract
        ,d.target_channel
        ,d.target_number
        ,d.target_contract
        ,d.merchant_id
        ,d.sic_code
        ,d.trans_date
        ,d.trans_amount
        ,d.trans_curr
        ,d.trans_country
        ,d.recons_amount
        ,d.recons_curr
        ,d.posting_date
        ,d.posting_status
        ,d.outward_status
        ,ows.glob.get_tag_value(d.add_info, 'AUTHDOCID') AS authdocid
        ,d.return_code
		,d.trans_details

    FROM
             ows.doc d

        JOIN ows.acnt_contract c ON d.merchant_id = c.contract_number

                                    AND c.amnd_state = 'A'
    WHERE
            d.amnd_state = 'A'
        AND d.id IN (
            SELECT /* +PARALLEL(10) */
                pm.doc__id

            FROM
                ows.process_mess pm

            WHERE
                    pm.object_type = 'DOC'
                AND pm.message_type = 'E'
                AND pm.message_name = '147-Transaction Not Allowed where same Auth code already found, DOC is declined'
                AND trunc(pm.message_date) = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        )
        AND trunc(d.amnd_date) = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND d.is_authorization = 'N'
        AND d.request_category = 'P'
)
SELECT /* +PARALLEL(10) */
    i.org
	,di.amnd_date
    ,'="'||di.id||'"' AS doc_id
	,'="'||di.ret_ref_number||'"' AS ret_ref_number
    ,'="'||di.acq_ref_number||'"' AS acq_ref_number
	,'="'||di.merchant_id||'"' AS merchant_id
	,CASE

        WHEN di.target_number IS NULL THEN

            ' '
        ELSE

            substr(di.target_number, 1, 6)
            || lpad('X', decode(length(TRIM(di.target_number)), 13, 3, 14, 4,
                                15, 5, 16, 6, 17,
                                7, 18, 8, 19, 9,
                                3), 'X')
            || substr(di.target_number, - 4)
    END   AS target_number
    ,di.auth_code
	,di.trans_amount
	,(
        SELECT
            MIN(name)
        FROM
            ows.currency

        WHERE
                amnd_state = 'A'
            AND code = di.trans_curr

     )     AS trans_curr
	,di.trans_date
	,di.trans_details
	,(
        SELECT
            MIN(display_value)
        FROM
            ows.meta_lb_pair

        WHERE
                listbox_name = 'Doc Posting Status'
            AND data_value = di.posting_status

     )     AS posting_status
	,di.return_code
    ,(
        SELECT
            MIN(display_value)
        FROM
            ows.meta_lb_pair

        WHERE
                listbox_name = 'Is Authorisation'
            AND data_value = di.is_authorization

     )     AS is_authorisation
	,(
        SELECT
            MIN(name)
        FROM
            ows.trans_type

        WHERE
                amnd_state = 'A'
            AND id = di.trans_type

     )     AS transaction_type
    ,(
        SELECT
            MIN(display_value)
        FROM
            ows.meta_lb_pair

        WHERE
                listbox_name = 'Request Category'
            AND data_value = di.request_category

     )     AS request_category
    ,(
        SELECT
            MIN(name)
        FROM
            ows.mess_channel

        WHERE
                amnd_state = 'A'
            AND code = di.source_channel

     )     AS source_channel
    ,di.source_number
    ,(
        SELECT
            MIN(name)
        FROM
            ows.mess_channel

        WHERE
                amnd_state = 'A'
            AND code = di.target_channel

     )     AS target_channel
    ,di.sic_code
    ,(
        SELECT
            MIN(name)
        FROM
            ows.country

        WHERE
                amnd_state = 'A'
            AND code = di.trans_country

     )     AS country
    ,di.posting_date
    ,(
        SELECT
            MIN(display_value)
        FROM
            ows.meta_lb_pair

        WHERE
                listbox_name = 'Outward Status'
            AND data_value = di.outward_status

     )     AS outward_status
    ,di.authdocid
 
FROM
    inst     i
    LEFT JOIN doc_info di ON di.inst_id = i.inst_id