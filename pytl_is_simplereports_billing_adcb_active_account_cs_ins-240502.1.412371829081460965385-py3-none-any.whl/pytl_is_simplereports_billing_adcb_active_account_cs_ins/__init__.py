__version__ = "240502.1"
__job_name__ = "PyTL_IS_SimpleReports_BILLING_ADCB_ACTIVE_ACCOUNT_CS_INS"
__bat_files__ = []
