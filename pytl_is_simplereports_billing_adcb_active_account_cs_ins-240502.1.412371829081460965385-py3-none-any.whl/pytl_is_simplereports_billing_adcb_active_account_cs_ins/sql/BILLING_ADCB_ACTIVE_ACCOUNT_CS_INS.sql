WITH 
/*
* CODE FOR CS ACTIVE ACCOUNTS WITH ACTIVE CREDIT SHIED REPORT
* PyTL_IS_SimpleReports_BILLING_ADCB_ACTIVE_ACCOUNT_CS_INS = BILLING_ADCB_ACTIVE_ACCOUNT_CS_INS.sql
* Parameters:
    ORG                = 020
    P_REPORT_DATE      = 'DD-MM-YYYY' = SYSDATE -1
* VERSION HISTORY:
* 231023.1 = SANKALP GUPTA = ADCB-11006 : Active Accounts with Active credit shied report
* 231025.1 = KOKILA J = ADCB-11105 : Product column logic change
* 231031.1 = KOKILA J = ADCB-11113 : look up end logic change
* 231101.1 = KOKILA J = ADCB-11127 : look up end logic change
* 231128.1 = KOKILA J = ADCB-11174 : Client number mapping change to reg number
* 231212.1 = KOKILA J = ADCB-11173 : OCCUPATION mapping change and status change
* 240108.1 = KOKILA J = ADCB-11247 : Changing Activity status condition
* 240314.1 = KOKILA J = ADCB-11337 : Removing GP where Condition
* 240502.1 = KOKILA J = ADCB-11414 : Bin logic change
*/
inst AS (
    SELECT /*+ no_merge materialize */
        institution_id,
        code,
        to_date(:P_BANK_DATE,'dd-mm-yyyy') P_BANK_DATE
    FROM
        v_dwr_institution
    WHERE
        code IN ( :ORG )
        AND type_code = 'BANK_DESC'
        AND class_code = 'BASE_REPORTS'
)
,pd AS (
    SELECT /*+ no_merge materialize */
        sg.type_code
      , sg.code
      , sg.name
    FROM
        opt_v_suppl_group sg
    WHERE
            1 = 1
        AND sg.type_code = '020_BIN_PRODUCT'
        AND sg.code = '020_BIN_PRODUCT_ISLAMIC'
)
, it AS (
    SELECT 
        /*+ no_merge parallel(4) */
        e.contract_idt
      , e.banking_date
      , MAX(e.debit - e.credit)
          OVER(PARTITION BY contract_idt, e.banking_date
               ORDER BY
                   e.banking_date DESC
          ) ins_amt
    FROM
             dwf_account_entry e
        JOIN v_dwr_operation_type o ON e.operation_type_id = o.operation_type_id
                                       AND o.type_code = 'TXN_CODE'
                                       AND o.class_code = :ORG || '_TXN_CODE'
    WHERE
            1 = 1
        AND e.institution_id = (
            SELECT
                institution_id
            FROM
                inst
        )
        AND e.banking_date > (
            SELECT
                MAX(add_months(P_BANK_DATE, - 1))
            FROM
                inst
        )   --one Months to Scan
        AND e.banking_date <= (
            SELECT
                MAX(P_BANK_DATE)
            FROM
                inst
        )     --Banking_date

        AND e.fee_code= 'INS_PREMIUM_01-CHARGE' 
        AND o.add_info like  '%CS_INSURANCE_REP=FEE_CHARGE%' 
)
,con_attr as 
( 
    select * from
	(select dca.contract_idt,
	       to_char(dca.attr_date_from, 'YYYY-MM-DD') as attr_date_from,
		   ROW_NUMBER() over ( partition by dca.contract_idt order by active_date_to desc) as rn
	FROM
    dwa_contract_attribute     dca 
    JOIN dwd_attribute              da ON dca.attr_id = da.id
                             AND da.record_state = 'A'
                             AND da.type_code = 'PETRA_INS_ENROLLMENT_01'
							 AND da.code='F'
                             AND (SELECT p_bank_date FROM inst) BETWEEN dca.attr_date_from AND dca.attr_date_to) conatt
	where conatt.rn=1						 
)
, con_all as (
            SELECT /*+ no_merge */
                con.org
              , to_char(con.billing_date,'DD')                                                                                                                            billing_cycle
              , substr(con.personal_account, 4, 6)                                                                                                                        card_bin	 
              , cl.ident_number                                                                                                                                           cif_no 
              , cl.first_name
                  || ' '
                  || cl.middle_name
                  || ' '
                  || cl.last_name                                                                                                                                         cust_name 
              , con.client_category                                                                                                                                       cust_type	 
              , to_char(cl.birth_date, 'YYYY-MM-DD')                                                                                                                      dob	 
              , trunc(months_between(inst.P_BANK_DATE, birth_date)/ 12)                                                                                                            age 
              , cl.ident_number                                                                                                                                           customer_id  
              , con.total_balance                                                                                                                                         os_balance	
              , NULL                                                                                                                                                      emirates_id	 
              , substr(cl.add_info, instr(cl.add_info, 'PASS_NUM=') + 9,(instr(cl.add_info, ';', instr(cl.add_info, 'PASS_NUM=')) - instr(cl.add_info,
              'PASS_NUM=') - 9)) 																																		  passport_no	
              , co.code_2char                                                                                                                                             nationality	 
              , cl.gender                                                                                                                                                 gender 
              , cl.position                                                                                                                                               position	
              , it.ins_amt                                                                                                                                                    ins_premium  
              , NULL                                                                                                                                                      benef_name 
              , NULL                                                                                                                                                      benef_nationality 
              , dca.attr_date_from                                                                                                                                        enrollment_date  
              , dc.name                                                                                                                                                   currency	 
              , CASE 
                    WHEN instr(pd.name, substr(primary_pan, 1, 6)) > 0 then
                       'Islamic'
                      ELSE
                        'Conventional'
                  END                                                                                                                                                     product
              , dce.decision_date    AS free_lookup_start
              
                , n_dip.code as n_logo_code
                , o_dip.code as o_logo_code
                , substr(o_dip.code,9,3) as o_logo
                , substr(n_dip.ADD_INFO, instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=') + 20,(instr(n_dip.ADD_INFO, ';', instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=')) - instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=') - 20)) n_gp
                , substr(n_dip.ADD_INFO, instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=') + 25,(instr(n_dip.ADD_INFO, ';', instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=')) - instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=') - 25)) n_gp_type
                , substr(o_dip.ADD_INFO, instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=') + 20,(instr(o_dip.ADD_INFO, ';', instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=')) - instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=') - 20)) o_gp
                , substr(o_dip.ADD_INFO, instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=') + 25,(instr(o_dip.ADD_INFO, ';', instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=')) - instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=') - 25)) o_gp_type
                , con.billing_date
                , dce.enddate
                , con.main_contract_idt contract_idt
                , inst.P_BANK_DATE
             FROM inst 
                JOIN opt_dm_petra_contract_info con on inst.code = con.org
                JOIN dwd_client             cl ON cl.record_idt = con.client_idt
                                      AND inst.P_BANK_DATE BETWEEN cl.record_date_from AND cl.record_date_to
                                      AND cl.institution_id =inst.institution_id
                                      AND cl.record_state <> 'C'
                JOIN con_attr dca ON con.main_contract_idt = dca.contract_idt
                left JOIN it ON con.main_contract_idt = it.contract_idt
                JOIN pd ON 1 = 1
                JOIN  dwd_int_product n_dip on 1=1 and n_dip.record_idt = con.INT_PRODUCT_IDT  
                                        AND inst.P_BANK_DATE between  n_dip.RECORD_DATE_FROM  and n_dip.RECORD_DATE_TO 
                                        AND n_dip.record_state <> 'C'
                                        AND n_dip.institution_id=inst.institution_id
                left JOIN  dwd_int_product o_dip on 1=1 and o_dip.code=substr(con.contract_info, instr(con.contract_info, 'ACTRAN_LOGO=') + 12,(instr(con.contract_info, ';', instr(con.contract_info, 'ACTRAN_LOGO=')) - instr(con.contract_info, 'ACTRAN_LOGO=') - 12))
                                        AND inst.P_BANK_DATE between  o_dip.RECORD_DATE_FROM  and o_dip.RECORD_DATE_TO 
                                        AND o_dip.record_state <> 'C' 
                                        AND o_dip.institution_id=inst.institution_id
                                        	JOIN  dwd_currency	          dc ON dc.code=con.base_currency   
                                AND inst.P_BANK_DATE BETWEEN dc.record_date_from AND dc.record_date_to
								AND dc.record_state <> 'C'	
                LEFT JOIN dwd_country co       ON co.code          = cl.citizenship
                               AND inst.P_BANK_DATE between  co.RECORD_DATE_FROM  and co.RECORD_DATE_TO 
                               AND co.record_state <> 'C'
                LEFT JOIN (
                        SELECT 
                                            dt.banking_date,
                                            e.contract_idt,
                                            e.decision_code,
                                            e.decision_result,
                                            e.decision_result_name,
                                            e.decision_date,
                                            e.enddate
                                        FROM
                                            (SELECT 
                                                  banking_date,
                                                  contract_idt,
                                                  decision_code,
                                                  decision_result,
                                                  decision_result_name,
                                                  LEAD(banking_date, 1) OVER (partition BY contract_idt, decision_code ORDER BY banking_date) date_to,
                                                  decision_date,
                                                  rn
                                                  ,enddate
                                                FROM
                                                      (SELECT  /*+ no_merge use_hash(dce det) swap_join_inputs(dce) pq_distribute(dce  broadcast none) */
                                                        dce.activate_date                                                                                            AS banking_date,
                                                        dce.contract_idt                                                                                                   AS contract_idt,
                                                        det.group_code                                                                                                     AS decision_code,
                                                        det.code                                                                                                           AS decision_result,
                                                        det.name                                                                                                           AS decision_result_name,
                                                        dce.record_date                                                                                                    AS decision_date,
                                                        row_number() over (partition BY dce.contract_idt, det.group_code, dce.activate_date order by dce.record_date DESC) AS rn
                                                        ,to_date(substr(dce.details, instr(dce.details, 'ENDDATE=') + 8,(instr(dce.details, ';', instr(dce.details, 'ENDDATE=')) -
                                                                        instr(dce.details, 'ENDDATE=') - 8)), 'dd-mm-yyyy') enddate
                                                      FROM dwf_contract_event dce
                                                      JOIN  inst on dce.institution_id = inst.institution_id      
                                                      JOIN dwd_event_type det
                                                      ON det.id              = dce.event_type_id
                                                      AND det.record_state   = 'A'
                                                      AND det.record_date_to = to_date('2100-01-01','YYYY-MM-DD')
                                                      AND det.record_source  = 'W4EVENT_TYPE'
                                                      AND det.GROUP_CODE  = 'DWD_EVENT_TYPE_CONTRACT_ET'
                                                      AND det.code  like  'RC-INS_ENROLMENT-01-F-GR_TIMER'
                                                      AND det.dimension_code = 'DWD_CONTRACT'
                                                      )
                                                WHERE rn = 1
                                            ) e
                                          JOIN dwd_banking_date dt
                                          ON dt.banking_date >= e.banking_date
                                          AND dt.banking_date < NVL(e.date_to, to_date('01-JAN-2100', 'DD-MON-YYYY'))
                        )     dce ON con.main_contract_idt = dce.contract_idt  and dce.banking_date =  inst.P_BANK_DATE 
            WHERE con.org = :ORG 
                AND con.banking_date = inst.P_BANK_DATE 
                AND con.insurance_01 = 'F' 
				AND con.activity_status not in  ('9','8','T')
)
, in_sql as(
        select 
            org 
            ,billing_cycle
            ,card_bin	 
            ,cif_no 
            ,cust_name 
            ,cust_type	 
            ,dob	 
            ,age 
            ,customer_id  as customer_no
            ,os_balance	
            ,emirates_id	 
            ,passport_no	
            ,nationality	 
            ,gender 
            ,position	
            ,ins_premium  
            ,benef_name 
            ,benef_nationality 
            ,enrollment_date  
            ,currency	 
            ,product
            ,free_lookup_start
            ,billing_date
            , case when n_logo_code<>o_logo_code and o_logo_code is not null
                then o_gp 
                else 
                   n_gp
                end as gp
            , case when n_logo_code<>o_logo_code and o_logo_code is not null
                then o_gp_type 
                else 
                   n_gp_type
                end as gp_type
            , p_bank_date
            , enddate
            , contract_idt
                        
        from con_all
)
,ee_cacl as (
    select /*+ no_merge */
           org 
          ,billing_cycle
          ,card_bin	 
          ,cif_no 
          ,cust_name 
          ,cust_type	 
          ,dob	 
          ,age 
          ,customer_no
          ,os_balance	
          ,emirates_id	 
          ,passport_no	
          ,nationality	 
          ,gender 
          ,position	
          ,ins_premium  
          ,benef_name 
          ,benef_nationality 
          ,enrollment_date  
          ,currency	 
          ,product
          ,free_lookup_start
          ,billing_date
        , CASE 
			WHEN gp_type ='M' THEN
				add_months(billing_date, gp - trunc(months_between(billing_date ,free_lookup_start)) -1 )
			WHEN gp_type ='B' THEN
				add_months(billing_date, gp - trunc(months_between(billing_date ,free_lookup_start)))  
			WHEN gp_type ='F' THEN
				enddate  
		   ELSE
				NULL
			END AS free_lookup_end
        , p_bank_date
        , trunc(months_between(billing_date ,free_lookup_start)) mb
        , contract_idt
        from in_sql
        where 1=1
       -- and gp is not null
       -- and gp_type in ('M','B','F')
           )
,m_sql as (
        SELECT   /*+ no_merge */
        org, 
		billing_cycle, 
		card_bin, 
		cif_no, 
		cust_name, 
		cust_type,
		dob, 
		age, 
		customer_no,
        os_balance,
		emirates_id, 
		passport_no, 
		nationality, 
		gender, 
		position, 
		ins_premium, 
		benef_name,
		benef_nationality,
        enrollment_date,
		currency,
		product,
		free_lookup_start,
		billing_date,
		free_lookup_end,
		p_bank_date,
        contract_idt
        FROM
            ee_cacl
)
select 
           org
		  ,billing_cycle
		  ,CASE
               WHEN m_sql.P_BANK_DATE between free_lookup_start and free_lookup_end then 'Y'
               ELSE 'N'
           END  as free_lookup_period                                                                                                                                                  
          ,card_bin	 
          ,cif_no 
          ,cust_name 
          ,cust_type	 
          ,dob	 
          ,age 
          ,customer_no  
          ,os_balance	
          ,emirates_id	 
          ,passport_no	
          ,nationality	 
          ,gender 
          ,' '	as OCCUPATION
          ,CASE
               WHEN m_sql.P_BANK_DATE between free_lookup_start and free_lookup_end 
               THEN 0
               ELSE ins_premium END  as ins_premium  
          ,benef_name 
          ,benef_nationality 
          ,enrollment_date  
          ,currency	 
          ,product	
from m_sql
	join inst on m_sql.org = inst.code