__version__ = "231102.1"
__job_name__ = "PyTL_IS_SimpleReports_BILLING_ADCB_INS_AUTO_REV_EXCEPTION"
__bat_files__ = []
