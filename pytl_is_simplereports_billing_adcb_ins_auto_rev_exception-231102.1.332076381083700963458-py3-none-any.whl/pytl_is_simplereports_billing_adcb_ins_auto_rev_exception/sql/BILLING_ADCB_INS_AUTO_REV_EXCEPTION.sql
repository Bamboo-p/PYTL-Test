WITH
/*
* CODE FOR CS AUTO REVERSAL FOR MORE THAN 2 CONSECUTIVE BILLING CYCLES REPORT
* PyTL_IS_SimpleReports_BILLING_ADCB_INS_AUTO_REV_EXCEPTION=BILLING_ADCB_INS_AUTO_REV_EXCEPTION.SQL
* Parameters:
    ORG                = '020' 
    P_BANK_DATE      = 'DD-MM-YYYY' = SYSDATE -1
* VERSION HISTORY:
* 231023.1 = SANKALP GUPTA = ADCB-11005 : CS Auto Reversal Exception Report
* 231026.1 = KOKILA J = ADCB-11113 : look up end logic change
* 231101.1 = KOKILA J = ADCB-11127 : look up end logic change
* 231102.1 = SANKALP  = ADCB-11127 : look up end logic change
*/
inst as (
          SELECT /*+ materialize no_merge */
               distinct 
               inst.institution_id
               ,inst.code
               ,trunc(TO_DATE(:P_BANK_DATE,'dd-mm-yyyy')) p_report_date --Parameter : Report generation date
               ,to_number( nvl( sg.name, 3 ) ) max_range  /* DM Configuration*/
          FROM
               v_dwr_institution inst
          LEFT JOIN opt_v_suppl_group sg on 1=1 
               AND  substr(sg.code,-3) = inst.code
               AND sg.type_code = 'INSURANCE_AUTO_REV_MAX_CNT'
               AND sg.code like 'INSURANCE_AUTO_REV_MAX_CNT%'
          WHERE
            inst.code = :ORG  
            AND inst.type_code = 'BANK_DESC'
                 AND inst.class_code = 'BASE_REPORTS'
)
,dce as (  
    SELECT 
        dt.banking_date,
        e.contract_idt,
        e.decision_date,
        e.decision_date_prev,
        e.enddate
                  FROM
                    (
                    SELECT 
                          banking_date,
                          contract_idt,
                          LEAD(banking_date, 1) OVER (partition BY contract_idt ORDER BY banking_date) date_to,
                          lag(decision_date) OVER (partition BY contract_idt ORDER BY Decision_Date) decision_date_prev,
                          decision_date,
                          rn
                          ,enddate
                        FROM
                              (SELECT  /*+ no_merge use_hash(dce det) swap_join_inputs(dce) pq_distribute(dce  broadcast none) */
                                dce.activate_date                                                                                            AS banking_date,
                                dce.contract_idt                                                                                                   AS contract_idt,
                                dce.record_date                                                                                                    AS decision_date,
                                row_number() over (partition BY dce.contract_idt, det.group_code, dce.activate_date order by dce.record_date DESC) AS rn
                                ,to_date(substr(dce.details, instr(dce.details, 'ENDDATE=') + 8,(instr(dce.details, ';', instr(dce.details, 'ENDDATE=')) -
                                                instr(dce.details, 'ENDDATE=') - 8)), 'dd-mm-yyyy') enddate
                              FROM dwf_contract_event dce
                              JOIN  inst on dce.institution_id = inst.institution_id      
                              JOIN dwd_event_type det
                              ON det.id              = dce.event_type_id
                              AND det.record_state   = 'A'
                              AND det.record_date_to = to_date('2100-01-01','YYYY-MM-DD')
                              AND det.record_source  = 'W4EVENT_TYPE'
                              AND det.group_code  = 'DWD_EVENT_TYPE_CONTRACT_ET'
                              AND det.code  like  'RC-INS_ENROLMENT-01-F-GR_TIMER'
                              AND det.dimension_code = 'DWD_CONTRACT'
                              )
                        WHERE rn = 1
                  ) e
                  JOIN dwd_banking_date dt
                  ON dt.banking_date >= e.banking_date
                  AND dt.banking_date < NVL(e.date_to, to_date('01-JAN-2100', 'DD-MON-YYYY'))
)  
,ins_rev_trans as (
        select 
            /*+ parallel(4) */
            o.code
            , e.contract_idt
            , e.banking_date 
            , e.fee_code, o.Operation_Type_Code
            , abs( e.debit -E.credit ) amount
            , e.primary_doc_idt
            from dwf_account_entry e  
            join v_dwr_operation_type o on  e.operation_type_id = o.operation_type_id and o.type_code = 'TXN_CODE' and o.class_code = :ORG||'_TXN_CODE' 
            where  1=1
            and e.institution_id = (select institution_id from inst )
            and e.banking_date >=  (select  max(add_months( trunc(p_report_date  ,'MM')  , - max_range ))  from inst)   --Limit the number of Months to Scan
            and e.banking_date <= (select  max( p_report_date )  from inst)     --Banking_date
            and e.fee_code= 'INS_PREMIUM_01-REV' 
            and o.add_info like  '%CS_INSURANCE_REP=FEE_REV%' 
)
,ins_rev_tran_gp_range_sql as (
    Select 
		 irt_gp.primary_doc_idt
		,irt_gp.code
		,irt_gp.contract_idt
		,irt_gp.banking_date
		,irt_gp.fee_code
		,irt_gp.operation_type_code
		,irt_gp.amount
		,irt_gp.last_amount
		,irt_gp.banking_date_max
		,irt_gp.rn_in
		,enddate
		,case when n_logo_code<>o_logo_code and o_logo_code is not null
              then o_gp 
         else 
              n_gp
         end as gp
        , case when n_logo_code<>o_logo_code and o_logo_code is not null
               then o_gp_type 
          else 
               n_gp_type
          end as gp_type
        , case when n_logo_code<>o_logo_code and o_logo_code is not null
               then substr(o_logo_code,9,3) 
          else 
                substr(n_logo_code,9,3) 
          end as o_logo
	    , irt_gp.p_report_date
        ,free_lookup_start
        ,free_lookup_start_prev
        ,billing_date
	From(
            select 
                    primary_doc_idt
                    , irt.code
                    , con.main_contract_idt as contract_idt
                    , irt.banking_date
                    , irt.fee_code
                    , irt.operation_type_code
                    , irt.amount
                    , FIRST_VALUE(irt.amount) OVER ( PARTITION BY irt.contract_idt ORDER BY irt.banking_date desc ) last_amount
                    , FIRST_VALUE(irt.BANKING_DATE) OVER ( PARTITION BY irt.contract_idt  ORDER BY irt.banking_date desc ) banking_date_max
                    , row_number() OVER( PARTITION BY irt.contract_idt ORDER BY irt.Banking_Date  ) rn_in
                    , n_dip.code as n_logo_code
                    , o_dip.code as o_logo_code
                    , substr(o_dip.code,9,3) as o_logo
                    , substr(n_dip.ADD_INFO, instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=') + 20,(instr(n_dip.ADD_INFO, ';', instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=')) - instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=') - 20)) n_gp
                    , substr(n_dip.ADD_INFO, instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=') + 25,(instr(n_dip.ADD_INFO, ';', instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=')) - instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=') - 25)) n_gp_type
                    , substr(o_dip.ADD_INFO, instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=') + 20,(instr(o_dip.ADD_INFO, ';', instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=')) - instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=') - 20)) o_gp
                    , substr(o_dip.ADD_INFO, instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=') + 25,(instr(o_dip.ADD_INFO, ';', instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=')) - instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=') - 25)) o_gp_type
                    , inst.p_report_date
                    , con.billing_date
                    , dce.enddate
                    , dce.decision_date    AS free_lookup_start
                    , dce.decision_date_prev  AS free_lookup_start_prev
            FROM ins_rev_trans irt
             JOIN  opt_dm_petra_contract_info con on irt.contract_idt = con.main_contract_idt
             JOIN inst on con.org=inst.code 
             LEFT JOIN  dwd_int_product n_dip on n_dip.record_idt = con.int_product_idt
                         AND inst.p_report_date between  n_dip.record_date_from  and n_dip.record_date_to
                         AND n_dip.record_state <> 'C'
                         AND n_dip.institution_id=inst.institution_id	 
             LEFT JOIN  dwd_int_product o_dip on 1=1 and o_dip.code=substr(con.contract_info, instr(con.contract_info, 'ACTRAN_LOGO=') + 12,(instr(con.contract_info, ';', instr(con.contract_info, 'ACTRAN_LOGO=')) - instr(con.contract_info, 'ACTRAN_LOGO=') - 12))
                        AND inst.p_report_date between  o_dip.record_date_from  and o_dip.record_date_to 
                        AND o_dip.record_state <> 'C' 
                        AND o_dip.institution_id=inst.institution_id	 
             JOIN dce ON con.main_contract_idt = dce.contract_idt  and dce.banking_date =  inst.P_REPORT_DATE
              /*  where  con.main_contract_idt = 502767952 */ 
    ) irt_gp
)	
,ins_rev_tran_gp_range as (
    Select 
		 irt_gp.primary_doc_idt
		,irt_gp.CODE
		,irt_gp.CONTRACT_IDT
		,irt_gp.BANKING_DATE
		,irt_gp.FEE_CODE
		,irt_gp.OPERATION_TYPE_CODE
		,irt_gp.AMOUNT
		,irt_gp.LAST_AMOUNT
		,irt_gp.BANKING_DATE_max
		,irt_gp.rn_in

        ,free_lookup_start_prev
        ,CASE 
            WHEN gp_type ='M' THEN
                add_months(billing_date, gp - trunc(months_between(billing_date ,free_lookup_start_prev)) -1 )
            WHEN gp_type ='B' THEN
                add_months(billing_date, gp - trunc(months_between(billing_date ,free_lookup_start_prev)))  
            WHEN gp_type ='F' THEN
                enddate  
        ELSE
           NULL
        END AS free_lookup_end_prev  
        
        ,free_lookup_start
        ,CASE 
            WHEN gp_type ='M' THEN
                add_months(billing_date, gp - trunc(months_between(billing_date ,free_lookup_start)) -1 )
            WHEN gp_type ='B' THEN
                add_months(billing_date, gp - trunc(months_between(billing_date ,free_lookup_start)))  
            WHEN gp_type ='F' THEN
                enddate  
        ELSE
           NULL
        END AS free_lookup_end
        , irt_gp.p_report_date	
        ,gp_type
        ,gp
	From ins_rev_tran_gp_range_sql irt_gp
)
,ins_rev_trans_det as (
    select 
            code
            ,contract_idt
            ,banking_date
            ,fee_code
            ,operation_type_code
            ,amount, ins_rev_amt
            ,ins_auto_rev_count
            ,rn
            ,cnt
            ,free_lookup_end
            ,free_lookup_start
            ,free_lookup_start_prev
            ,free_lookup_end_prev
            from (
                     select 
                             primary_doc_idt
                            ,CODE
                            ,CONTRACT_IDT
                            ,BANKING_DATE
                            ,FEE_CODE
                            ,OPERATION_TYPE_CODE
                            ,AMOUNT
                            ,LAST_AMOUNT ins_rev_amt
                            ,rn_in ins_auto_rev_count
                            ,ROW_NUMBER() OVER( PARTITION BY CONTRACT_IDT  ORDER BY rn_in desc, BANKING_DATE desc ) RN
                            ,count(0) OVER( PARTITION BY CONTRACT_IDT ) cnt
                            ,free_lookup_start
                            ,max(free_lookup_end) OVER( PARTITION BY CONTRACT_IDT) free_lookup_end
                            
                            ,free_lookup_start_prev
                            ,max(free_lookup_end_prev) OVER( PARTITION BY CONTRACT_IDT) free_lookup_end_prev
                            
                            ,gp_type
                            ,gp
                            from (
                                        select 
                                             irt.primary_doc_idt
                                            ,irt.CODE
                                            ,irt.CONTRACT_IDT
                                            ,irt.BANKING_DATE
                                            ,irt.FEE_CODE
                                            ,irt.OPERATION_TYPE_CODE
                                            ,irt.AMOUNT
                                            ,irt.LAST_AMOUNT
                                            ,irt.BANKING_DATE_max
                                            ,irt.rn_in
                                            ,irt.free_lookup_end
                                            ,irt.free_lookup_end_prev
											
                                            ,free_lookup_start
                                            ,free_lookup_start_prev
                                            ,irt.p_report_date
                                            ,gp_type
                                            ,gp
                                        FROM ins_rev_tran_gp_range irt
                                ) irt_m
                                where 1=1
                                and  irt_m.BANKING_DATE > ( case when FREE_LOOKUP_END_PREV is not null then FREE_LOOKUP_END_PREV else FREE_LOOKUP_END end  )
                      )
                where
				rn = 1 
)
SELECT
    cl.client_number      AS reg_nbr
    ,con.personal_account AS account_nbr
    ,con.logo
    ,pd.name              AS ins_product_name
    ,CASE
        WHEN con.insurance_01 = 'F' THEN
            to_char(free_lookup_start,'YYYY-MM-DD')
        ELSE
            NULL
    END                  AS ins_activ_date
    
    /* In case previous ins_activ_date 
    ,free_lookup_start_prev  ,free_lookup_end_prev */
    
    ,to_char(con.billing_date,'YYYY-MM-DD') as billing_date
    ,CASE WHEN inst.p_report_date BETWEEN free_lookup_start and free_lookup_end
          THEN 'ACTIVE'
          ELSE 'NOT ACTIVE' END as free_lookup_status
    ,ot.ins_rev_amt
FROM inst 
    JOIN opt_dm_petra_contract_info con on inst.code = con.org
    JOIN dwd_client             cl ON cl.record_idt = con.client_idt
                          AND inst.p_report_date BETWEEN cl.record_date_from AND cl.record_date_to
                          AND cl.record_state <> 'C'
                          AND cl.institution_id =inst.institution_id
    JOIN dwa_contract_attribute dca ON con.main_contract_idt = dca.contract_idt
    JOIN dwd_attribute          da ON dca.attr_id = da.id
                             AND da.record_state = 'A'
                             AND da.type_code = 'PETRA_INS_ENROLLMENT_01'
                             AND inst.p_report_date BETWEEN dca.attr_date_from AND dca.attr_date_to
    JOIN (
           SELECT
                    code,
                    contract_idt,
                    banking_date,
                    fee_code,
                    operation_type_code,
                    amount,
                    ins_rev_amt,
                    ins_auto_rev_count,
                    rn,
                    cnt,
                    free_lookup_start,
                    free_lookup_end,
                    free_lookup_start_prev,
                    free_lookup_end_prev
                FROM
                    ins_rev_trans_det
    )                      ot ON ot.contract_idt = con.main_contract_idt
    LEFT JOIN (
                        SELECT /*+ materialize */
                            sg.name,
                            sg.code
                        FROM
                            opt_v_suppl_group sg
                        WHERE
                            sg.type_code = 'INSURANCE_DESC'
                    ) pd ON 1 = 1
                        AND pd.code = con.org
                                      || '_'
                                      ||
                                      CASE
                                          WHEN da.type_code LIKE 'PETRA_INS_ENROLLMENT%' THEN
                                              substr(da.type_code, - 2)
                                      END
                                      || '_'
                                      || con.logo
WHERE 1=1
AND con.banking_date = inst.p_report_date
AND con.insurance_01 = 'F'
AND con.billing_date <= con.banking_date