WITH 
/*
* CODE FOR ADCB INS FREELOOKUP BC
* PyTL_IS_SimpleReports_BILLING_ADCB_INS_FREELOOKUP=BILLING_ADCB_INS_FREELOOKUP.SQL
* Parameters:
    ORG                = '020' or '021,022,023'
    P_BANK_DATE        = 'DD-MM-YYYY' = SYSDATE
* VERSION HISTORY:
* 231023.2 = SANKALP GUPTA = ADCB-11064 : BILLING_ADCB_INS_FREELOOKUP
* 231029.1 = SANKALP GUPTA = ADCB-11113 : FREE_LOOKUP_END, FREE_LOOKUP_ACTUAL_END extraction logic change
* 231101.1 = SANKALP GUPTA = ADCB-11127 : FREE_LOOKUP_END, FREE_LOOKUP_ACTUAL_END extraction logic change
* 231120.1 = Kokila J = ADCB-11161 : where condition change
* 231212.1 = KOKILA J = ADCB-11228 : Changes in the case conditions
* 240102.1 = KOKILA J = ADCB-11228 : start date changes
* 240108.1 = KOKILA J = ADCB-11228 : Start date logic on billing date
*/
inst AS (
    SELECT /*+ no_merge materialize */
        institution_id,
        code,
        to_date(:P_BANK_DATE,'dd-mm-yyyy') P_BANK_DATE
    FROM
        v_dwr_institution
    WHERE
        code IN ( :ORG )
        AND type_code = 'BANK_DESC'
        AND class_code = 'BASE_REPORTS'
)
, con_all as (
            SELECT /*+ no_merge */
                con.org
                , cl.client_number     AS reg_nbr
                , con.logo
                , con.personal_account AS account_nbr
                , con.billing_date
                , pd.name              AS ins_product_name
                , con.insurance_01     AS ins_product_status
                , dce.decision_date    AS free_lookup_start
                , n_dip.code as n_logo_code
                , o_dip.code as o_logo_code
                , substr(o_dip.code,9,3) as o_logo
                , substr(n_dip.ADD_INFO, instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=') + 20,(instr(n_dip.ADD_INFO, ';', instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=')) - instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=') - 20)) n_gp
                , substr(n_dip.ADD_INFO, instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=') + 25,(instr(n_dip.ADD_INFO, ';', instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=')) - instr(n_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=') - 25)) n_gp_type
                , substr(o_dip.ADD_INFO, instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=') + 20,(instr(o_dip.ADD_INFO, ';', instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=')) - instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_01=') - 20)) o_gp
                , substr(o_dip.ADD_INFO, instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=') + 25,(instr(o_dip.ADD_INFO, ';', instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=')) - instr(o_dip.ADD_INFO, 'INS_GRACE_PERIOD_TYPE_01=') - 25)) o_gp_type
                , dce.enddate
                , con.main_contract_idt contract_idt
                , inst.P_BANK_DATE 
				, con.date_open
             FROM inst 
                JOIN opt_dm_petra_contract_info con on inst.code = con.org
                JOIN dwd_client             cl ON cl.record_idt = con.client_idt
                                      AND inst.P_BANK_DATE BETWEEN cl.record_date_from AND cl.record_date_to
                                      AND cl.institution_id =inst.institution_id
                JOIN  dwa_contract_attribute dca ON con.main_contract_idt = dca.contract_idt 
                JOIN dwd_attribute          da ON dca.attr_id = da.id
                                         AND da.record_state = 'A'
                                         AND da.type_code = 'PETRA_INS_ENROLLMENT_01'
                                         AND inst.P_BANK_DATE BETWEEN dca.attr_date_from AND dca.attr_date_to
                 JOIN  dwd_int_product n_dip on 1=1 and n_dip.record_idt = con.INT_PRODUCT_IDT  
                                        AND inst.P_BANK_DATE between  n_dip.RECORD_DATE_FROM  and n_dip.RECORD_DATE_TO 
                                        AND n_dip.record_state <> 'C'
                                        AND n_dip.institution_id=inst.institution_id
                left JOIN  dwd_int_product o_dip on 1=1 and o_dip.code=substr(con.contract_info, instr(con.contract_info, 'ACTRAN_LOGO=') + 12,(instr(con.contract_info, ';', instr(con.contract_info, 'ACTRAN_LOGO=')) - instr(con.contract_info, 'ACTRAN_LOGO=') - 12))
                                        AND inst.P_BANK_DATE between  o_dip.RECORD_DATE_FROM  and o_dip.RECORD_DATE_TO 
                                        AND o_dip.record_state <> 'C' 
                                        AND o_dip.institution_id=inst.institution_id
                LEFT JOIN (
                        SELECT 
                                            dt.banking_date,
                                            e.contract_idt,
                                            e.decision_code,
                                            e.decision_result,
                                            e.decision_result_name,
                                            e.decision_date,
                                            e.enddate
                                        FROM
                                            (SELECT 
                                                  banking_date,
                                                  contract_idt,
                                                  decision_code,
                                                  decision_result,
                                                  decision_result_name,
                                                  LEAD(banking_date, 1) OVER (partition BY contract_idt, decision_code ORDER BY banking_date) date_to,
                                                  decision_date,
                                                  rn
                                                  ,enddate
                                                FROM
                                                      (SELECT  /*+ no_merge use_hash(dce det) swap_join_inputs(dce) pq_distribute(dce  broadcast none) */
                                                        dce.activate_date                                                                                            AS banking_date,
                                                        dce.contract_idt                                                                                                   AS contract_idt,
                                                        det.group_code                                                                                                     AS decision_code,
                                                        det.code                                                                                                           AS decision_result,
                                                        det.name                                                                                                           AS decision_result_name,
                                                        dce.activate_date                                                                                                  AS decision_date,
                                                        row_number() over (partition BY dce.contract_idt, det.group_code, dce.activate_date order by dce.record_date DESC) AS rn
                                                        ,to_date(substr(dce.details, instr(dce.details, 'ENDDATE=') + 8,(instr(dce.details, ';', instr(dce.details, 'ENDDATE=')) -
                                                                        instr(dce.details, 'ENDDATE=') - 8)), 'dd-mm-yyyy') enddate
                                                      FROM dwf_contract_event dce
                                                      JOIN  inst on dce.institution_id = inst.institution_id      
                                                      JOIN dwd_event_type det
                                                      ON det.id              = dce.event_type_id
                                                      AND det.record_state   = 'A'
                                                      AND det.record_date_to = to_date('2100-01-01','YYYY-MM-DD')
                                                      AND det.record_source  = 'W4EVENT_TYPE'
                                                      AND det.GROUP_CODE  = 'DWD_EVENT_TYPE_CONTRACT_ET'
                                                      AND det.code  like  'RC-INS_ENROLMENT-01-F-GR_TIMER'
                                                      AND det.dimension_code = 'DWD_CONTRACT'
                                                      )
                                                WHERE rn = 1
                                            ) e
                                          JOIN dwd_banking_date dt
                                          ON dt.banking_date >= e.banking_date
                                          AND dt.banking_date < NVL(e.date_to, to_date('01-JAN-2100', 'DD-MON-YYYY'))
                        )     dce ON con.main_contract_idt = dce.contract_idt  and dce.banking_date =  inst.P_BANK_DATE 
            LEFT JOIN (
                                SELECT /*+ materialize */
                                    sg.name,
                                    sg.code
                                FROM
                                    opt_v_suppl_group sg
                                WHERE
                                    sg.type_code = 'INSURANCE_DESC'
                            )                      pd ON 1 = 1
                                                        AND pd.code = con.org
                                                                      || '_'
                                                                      ||
                                                                      CASE
                                                                          WHEN da.type_code LIKE 'PETRA_INS_ENROLLMENT%' THEN
                                                                              substr(da.type_code, - 2)
                                                                      END
                                                                      || '_'
                                                                      || con.logo
            WHERE con.org IN ( :ORG )
                AND con.billing_date = inst.P_BANK_DATE 
                AND con.insurance_01 = 'F'
)

, in_sql as(
        select 
                org
                , reg_nbr
                , logo
                , account_nbr
                , billing_date
                , ins_product_name
                , ins_product_status
                , case 
                    when date_open = free_lookup_start and to_char(billing_date,'dd')=to_char(free_lookup_start,'dd') and billing_date > free_lookup_start then
                        add_months( free_lookup_start,1)
                    else
                        free_lookup_start
                    end free_lookup_start
                , enddate
                , contract_idt
                , p_bank_date
                , case when n_logo_code<>o_logo_code and o_logo_code is not null and o_gp is not null
                    then o_gp 
                    else 
                       n_gp
                    end as gp
                , case when n_logo_code<>o_logo_code and o_logo_code is not null and o_gp is not null
                    then o_gp_type 
                    else 
                       n_gp_type
                    end as gp_type
                , n_gp
                , n_gp_type
                , o_gp
                , o_gp_type
                , n_logo_code
                , o_logo_code
                , o_logo
        from con_all
)
,ee_cacl as (
    select /*+ no_merge */
          org
        , reg_nbr
        , logo
        , account_nbr
        , billing_date
        , ins_product_name
        , ins_product_status
        , free_lookup_start
        , gp_type
        , gp
        , CASE 
			WHEN gp_type ='M' THEN
				add_months(billing_date, gp - trunc(months_between(billing_date ,free_lookup_start)) -1 )
			WHEN gp_type ='B' THEN
				add_months(billing_date, gp - trunc(months_between(billing_date ,free_lookup_start)))  
			WHEN gp_type ='F' THEN
				enddate  
		   ELSE
				NULL
			END AS free_lookup_end
        , contract_idt
        , p_bank_date
        , trunc(months_between(billing_date ,free_lookup_start)) mb
        from in_sql
        where 1=1
        and gp is not null
        and gp_type in ('M','B','F')
        )
,m_sql as (
        SELECT   /*+ no_merge */
            org
          , reg_nbr
          , logo
          , account_nbr
          , ins_product_name
          , ins_product_status
          , free_lookup_start
          , billing_date
          , free_lookup_end
          , gp_type
          , gp
          , contract_idt
          , p_bank_date
          , mb
        FROM
            ee_cacl
        WHERE
            p_bank_date BETWEEN trunc(free_lookup_start) AND trunc(free_lookup_end)
)
select 
    org
    , reg_nbr
    , logo
    , account_nbr
    , to_char(billing_date,'YYYY-MM-DD') as billing_date
    , ins_product_name
    , ins_product_status
    , to_char(free_lookup_start,'YYYY-MM-DD') as free_lookup_start
    , to_char(free_lookup_end,'YYYY-MM-DD') as free_lookup_end
    , to_char( CASE WHEN inst.P_BANK_DATE = free_lookup_end
                          THEN inst.P_BANK_DATE 
                          ELSE   null
                          END ,'YYYY-MM-DD')  AS free_lookup_actual_end
from m_sql
join inst on m_sql.org = inst.code