__version__ = "240108.1"
__job_name__ = "PyTL_IS_SimpleReports_BILLING_ADCB_INS_REV_FREELOOKUP"
__bat_files__ = []
