__version__ = "230202.1"
__job_name__ = "PyTL_IS_SimpleReports_BILLING_INSTALMENT"
__bat_files__ = []

