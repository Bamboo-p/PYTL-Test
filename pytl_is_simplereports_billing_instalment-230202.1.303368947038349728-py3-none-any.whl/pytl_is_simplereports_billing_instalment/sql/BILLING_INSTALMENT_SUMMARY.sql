/*
* Billing Installment summary report = BILLING_INSTALMENT_SUMMARY.sql
*
* Version History
* 211122.1 = SergeiM = ENG-4099: Initial development
* 220421.1 = Shalini = ALMB-768: Updated P_REPORT_DATE filter.
* 220425.1 = Shalini = ALMB-768: Replaced comma with space in Plan Description field data
* 230202.1 = Shalini = ANFE-185: Logic changes to exclude 'REVISED installments and column names updated to uppercase
*/
 with 
inst as 
(select /*+ materialize*/
        id,
        branch_code 
    from dwd_institution 
  where branch_code = :ORG
    and record_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
    and record_date_to >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')),

plan_booking as
  (select  /*+ materialize */
      t.* 
 from opt_dwd_plan_type t
 join inst
   on inst.id=t.institution_id
  and t.record_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  and t.record_date_to >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  ),
products as (
    select /*+ materialize */
            name,
            substr(code,1,3) logo,
            product_id
       from v_dwr_product
      where class_code = 'BASE_REPORTS' and type_code = 'LOGO'),

contract as 
     (select  
             c.record_idt, 
             c.personal_account,
             c.product_id,
             inst.branch_code org
        from dwd_contract c
        join inst
          on c.institution_id=inst.id
		
       where c.record_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
         and c.record_date_to >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
),
cards as 
     (select  
             c.record_idt, 
             c.pan
        from dwd_card c
        join inst
          on c.institution_id=inst.id
   
       where c.record_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
         and c.record_date_to >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
)

select /*+ leading(ins)  */
        c.org "ORG",
        c.org "FI CODE/ORG",
        p.logo "PRODUCT CODE/LOGO",
        p.name "PRODUCT NAME",
        --lpad(substr(ins.add_info, instr(ins.add_info, '_') + 1, instr(ins.add_info, ':') - instr(ins.add_info, '_') - 1),5,0) "Instalment Plan number",
        --ins.scheme_option_code "Instalment Plan number",
        sy_convert.get_tag_value(ins.add_info, 'PLAN_NR') "INSTALMENT PLAN NUMBER",
        replace(p_b.plan_name,',',' ') "PLAN DESCRIPTION", --[*] 220425 = ALMB-768
        count(ins.creation_date) "TOTAL COUNT OF NEW INST PLAN"
  from dwd_instalment ins
  join inst
    on inst.id = ins.institution_id
  join contract c
    on c.record_idt=ins.contract_idt
  join dwd_instl_status st
    on ins.status_id = st.id
   and st.code not in ('Z','REVISED') --[*] 230202.1 = ANFE-185
  left join products p
    on p.product_id = c.product_id
  join plan_booking p_b
    --on p_b.plan_number = ins.scheme_option_code
    on p_b.plan_number = sy_convert.get_tag_value(ins.add_info, 'PLAN_NR')
  left join cards crd
    on crd.record_idt=ins.card_idt
 where ins.creation_date between add_months(to_date(:P_REPORT_DATE,'dd-mm-yyyy'),-1)+1 and to_date(:P_REPORT_DATE,'dd-mm-yyyy') --[*] 220421 = ALMB-768
   and ins.record_state = 'A'
group by
        c.org,
        p.logo,
        p.name,
        --ins.add_info,
        --ins.scheme_option_code,
        sy_convert.get_tag_value(ins.add_info, 'PLAN_NR'),
        p_b.plan_name
        