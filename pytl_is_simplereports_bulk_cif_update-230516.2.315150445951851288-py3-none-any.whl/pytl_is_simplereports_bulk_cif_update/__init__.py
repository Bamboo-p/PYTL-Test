__version__ = "230516.2"
__job_name__ = "PyTL_IS_SimpleReports_BULK_CIF_UPDATE"
__bat_files__ = ["PyTL_IS_BULK_CIF_UPDATE.bat"]

