/*
230314.1: AntonZh: NICORE-528: Initial development
230315.1: AntonZh: NICORE-528: Query update
230321.1: AntonZh: NICORE-528: Query update
230323.1: AntonZh: NICORE-528: Removing filter for BANK_CODE:
                               In this case records with not correct BANK_CODE will be shown in the reponse file.
230324.2: AntonZh: NICORE-528: Added field INCOMING_FILE_NAME into outgoing CSV file
230329.2: AntonZh: NICORE-528: Added 2 new statuses L, O
230405.1:  AntonZh: NICORE-528: Added additional response codes
230405.2:  AntonZh: NICORE-528: Typo fixed
230509.1:  AntonZh: EIB-9633: Change status model, add fiel Action, change field isclientexist
*/
select
    t.BANK_CODE                                         as ORG
    ,t.ID
    ,t.INCOMING_FILE_NAME
    ,t.LOAD_UNIQUE_ID
    ,t.BANK_CODE
    ,t.CONTRACT_NUMBER
    ,t.CONTRACT_ROLE
    ,t.CIF_OLD
    ,t.CIF_NEW
    ,t.SUFFIX_ORIGINAL
    ,t.SUFFIX_NEW
    ,t.LAST_NAME
    ,t.IS_CLIENT_EXIST
    ,to_char(t.AMND_DATE, 'YYYY-MM-DD')                 as AMND_DATE
    ,to_char(t.LOAD_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS') as LOAD_TIMESTAMP
    ,t.BATCH
    ,t.ACTION
    ,t.STATUS                                           as STATUS_CODE
    ,case
        when t.STATUS = 'P' then 'SUCCESSFULLY PROCESSED'
        when t.STATUS = 'W' then 'AWAITING FOR PROCESSING'
        when t.STATUS = 'F' then 'ERROR: PROCESSING IS NOT FINISHED'
        when t.STATUS = 'E' then 'ERROR: INCOMING FILE VALIDATION FAILED'
        else 'OTHER STATUS'
    end                                                 as STATUS_DESC
    ,t.STATUS_TEXT                                      as ERROR_MSG
from
    OWS.OPT_BULK_CIF_UPDATE t
where
    t.LOAD_UNIQUE_ID = :P_LOAD_UNIQUE_ID
    -- and t.BANK_CODE = ;ORG  -- [-] 230323.1
