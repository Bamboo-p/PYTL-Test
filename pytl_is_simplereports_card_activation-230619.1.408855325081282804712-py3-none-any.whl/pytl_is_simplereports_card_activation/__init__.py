__version__ = "230619.1"
__job_name__ = "PyTL_IS_SimpleReports_CARD_ACTIVATION"
__bat_files__ = []

