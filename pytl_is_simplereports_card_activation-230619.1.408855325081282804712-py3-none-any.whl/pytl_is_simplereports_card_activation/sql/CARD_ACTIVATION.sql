/*
* 220215.10 = DenisKa = OPKSAIC-3226: fixed the issue with running under users different from OWS.
* 220712.1 = Bharath = OPKSAIC-4608: Alternate Id (EXID) logic added
* 230619.1 = ErnestH = NICORE-653: Join correction
*/
with inst as(
select id institution_id,bank_code code,name
                      from (select fi.bank_code,
                                   fi.posting_in,
                                   fi.id,
                                   fi2.bank_code bank_code_posting,
                                   fi.name
                            from ows.f_i fi
                                 join ows.f_i fi2 on fi.posting_in = fi2.id
                            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
                            ) inst
                      start with inst.bank_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                                      from dual 
                                                      connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
                                                      )
                      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2),
-- [+][begin] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
auth_type as (
    select /*+ no_merge materialize */ id 
     From ows.td_auth_type
    where code        = 'EXID'
      and amnd_state  = 'A'
    ),
exid as (
 select /*+ no_merge materialize */
        e.auth_idt,
        e.acnt_contract__id, -- [*] 230619.1 = ErnestH = NICORE-653: Join correction
		c.con_cat
   from ows.acnt_contract c
   join inst ins 
     on ins.institution_id = c.f_i
   join ows.td_auth_sch e
     on e.acnt_contract__id = c.id
    and e.amnd_state        = 'A'
    and e.is_ready          = 'Y'        
   join auth_type at1
     on e.auth_type  = at1.id
  where c.amnd_state = 'A'
  )
-- [+][end] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
select
fi.code "ORG",
-- [+][begin] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',exid.auth_idt, ac.contract_number) "CARD NUMBER", 
-- [+][end] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
cl.client_number "CLIENT NUMBER",
ci.card_name "CARDHOLDER NAME",
ci.company_name "COMPANY NAME",
pe.name "ACTION STATUS",
o.name "USER NAME",
to_char(ua.record_date,'dd-mm-yyyy') "ACTIVATION DATE"
from ows.usage_action ua
join ows.event_type et on et.id = ua.event_type and et.amnd_state='A' and et.code in ( 'ACTIVATE_CARD-PLASTIC','UNLOCK_PLASTIC','CARD_ACTIVATED') and ua.con_cat='C' and posting_status ='C' /* and ua.custom_event_code = 'ACTIVATE_CARD_PETRA' */
join ows.acnt_contract ac on ac.id = ua.acnt_contract__id and ac.amnd_state='A' and ac.con_cat='C'
join inst fi on fi.institution_id=ac.f_i
join ows.client cl on cl.id = ac.client__id and cl.amnd_state='A'
join ows.acnt_contract con on con.id = ac.acnt_contract__oid and con.amnd_state = 'A' and con.con_cat = 'A'
join ows.card_info ci on ci.acnt_contract__oid=ua.acnt_contract__id and ci.status ='A'
join ows.prod_event pe on ci.production_event = pe.code and pe.amnd_State = 'A'
join ows.process_log pl on pl.id = ua.process_log__id
left join ows.officer o on o.id = pl.started_by and o.amnd_state='A'
-- [+][begin] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
left join exid on exid.acnt_contract__id = ac.id -- [*] 230619.1 = ErnestH = NICORE-653: Join correction
-- [+][end] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
where 1=1
and trunc(ua.record_date) = to_date(:P_REPORT_DATE,'DD-MM-YYYY')
and ci.production_type not in (1,0)
