__version__ = "220304.1"
__job_name__ = "PyTL_IS_SimpleReports_CARD_CONTROL"
__bat_files__ = []

