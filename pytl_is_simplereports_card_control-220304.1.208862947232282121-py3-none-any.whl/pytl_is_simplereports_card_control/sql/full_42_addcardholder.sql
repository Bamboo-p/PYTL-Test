with
attr as (
    select /*+ no_merge materialize */
        id
      , code
    from
        dwd_attribute
    where
        record_state       = 'A'
        and dimension_code = 'DWD_CARD'
        and type_code      = :ATTR_TYPE_CODE  -- 'PETRA_NCONTROL_REPORT'
        and code           = 'Y'
)
,
inst as (
    select /*+ no_merge materialize */
        institution_id as id
      , name
    from
        v_dwr_institution
    where
        type_code = :INST_TYPE_CODE  -- 'NCONTROL_DESC'
        and name  = :REPOSITORY_NAME
    union
    select
        id
      , sy_convert.get_tag_value(add_info, 'NC_REPO')
    from
        dwd_institution
    where
        sy_convert.get_tag_value(add_info, 'NC_REPO') = :REPOSITORY_NAME
)
,
main_sql as (
    select /*+ no_merge leading(cat) full(dc) use_hash(cat dc) use_hash(cat inst) use_hash(dc c_prd) use_hash(dc ac_i_prd) use_hash(dc cl) */
        dc.pan                                                          as card_number
      , dc.expiry_date                                                  as card_exdt
      , addr.mobile                                                     as cl_mobile
      , sy_convert.get_tag_value(ac_i_prd.add_info, 'NC_HOME_PROFILE')  as home_profile
      , sy_convert.get_tag_value(ac_i_prd.add_info, 'NC_ACC_PROFILE')   as acc_profile
      , inst.name                                                       as inst_name
      , cl.title                                                        as cl_title
      , cl.first_name                                                   as cl_first_name
      , last_name                                                       as cl_last_name
      , addr.e_mail                                                     as cl_e_mail
    from
        dwa_card_attribute cat
        inner join attr on
                attr.id                     = cat.attr_id
                and cat.attr_date_from      <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                and cat.attr_date_to        >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        inner join dwd_card dc on
                dc.record_idt               = cat.card_idt
                and dc.record_date_from     <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                and dc.record_date_to       >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        inner join inst on
                inst.id = dc.institution_id
        inner join dwd_contract cnt on
                cnt.record_idt = dc.main_contract_idt
        inner join dwd_int_product ac_i_prd on
                cnt.int_product_idt = ac_i_prd.record_idt
        inner join dwd_client cl on
                cl.record_idt           = dc.client_idt
                and cl.record_date_From     <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                and cl.record_date_to       >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        left join (
                select
                    da.client_idt
                  , da.e_mail
                  , da.address_zip  as mobile
                from
                    dwd_address da
                    inner join dwd_address_type dat on
                            dat.id       = da.address_type_id
                            and dat.code = 'ADD_SMS_1'
                where
                    da.record_date_from     <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                    and da.record_date_to   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        ) addr on addr.client_idt = cl.record_idt
    where
        ac_i_prd.record_date_to             >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and ac_i_prd.record_date_from       <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and cnt.record_date_to              >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and cnt.record_date_from            <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and dc.expiry_date                  >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY') -- ECCBAU-5073
)
,
mmm as (
-- 42 == Add cardholder
    select
        '42'                                                                                as ROW_TYPE
      , to_char(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'YYMMDD') || lpad(ROWNUM, 8, '0')    as ROW_ID
      , regexp_replace(main_sql.cl_mobile, '[^0-9]+', '')                                   as MOBILE
      , main_sql.cl_title                                                                   as TITLE
      , replace(main_sql.cl_first_name, ',', ' ')                                           as FIRST_NAME
      , replace(main_sql.cl_last_name, ',', ' ')                                            as LAST_NAME
      , trim(replace(main_sql.cl_e_mail, ',', ''))                                          as E_MAIL
      , main_sql.card_number                                                                as CARD_NUMBER
      , ''                                                                                  as EMPTY1
      , main_sql.inst_name                                                                  as INST_NAME
    from
        main_sql
)
select * from (
    select
-- will be excluded from result with "SKIP_COLUMNS=ORDER_AFTER_UNION"
        1                                                                                   as ORDER_AFTER_UNION
-- will be excluded from result automaticaly
      , :ORG                                                                                as ORG
      , '01'                                                                                as ROW_TYPE
      , to_char(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'),'YYMMDD')                             as ROW_ID
      , 'Way4'                                                                              as MOBILE
      , ''                                                                                  as TITLE
      , ''                                                                                  as FIRST_NAME
      , ''                                                                                  as LAST_NAME
      , ''                                                                                  as E_MAIL
      , ''                                                                                  as CARD_NUMBER
      , ''                                                                                  as EMPTY1
      , ''                                                                                  as INST_NAME
    from dual
-- body
union
    select
-- will be excluded from result with "SKIP_COLUMNS=ORDER_AFTER_UNION"
        2 as ORDER_AFTER_UNION
-- will be excluded from result automaticaly
      , :ORG as ORG
      , mmm.*
    from
        mmm
-- trailer
union
    select
-- will be excluded from result with "SKIP_COLUMNS=ORDER_AFTER_UNION"
        3                                                                                   as ORDER_AFTER_UNION
-- will be excluded from result automaticaly
      , :ORG                                                                                as ORG
      , '02'                                                                                as ROW_TYPE
      , lpad(count(1),5,'0')                                                                as ROW_ID
      , ''                                                                                  as MOBILE
      , ''                                                                                  as TITLE
      , ''                                                                                  as FIRST_NAME
      , ''                                                                                  as LAST_NAME
      , ''                                                                                  as E_MAIL
      , ''                                                                                  as CARD_NUMBER
      , ''                                                                                  as EMPTY1
      , ''                                                                                  as INST_NAME
    from mmm
) order by ORDER_AFTER_UNION, ROW_ID
