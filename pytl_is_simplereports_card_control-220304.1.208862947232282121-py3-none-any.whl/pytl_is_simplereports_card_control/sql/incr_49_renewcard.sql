with
attr as (
    select /*+ no_merge materialize */
        id
      , code
    from
        dwd_attribute
    where
        record_state       = 'A'
        and dimension_code = 'DWD_CARD'
        and type_code      = :ATTR_TYPE_CODE  -- 'PETRA_NCONTROL_REPORT'

)
,
inst as (
    select /*+ no_merge materialize */
        institution_id as id
      , name
    from
        v_dwr_institution
    where
        type_code = :INST_TYPE_CODE  -- 'NCONTROL_DESC'
        and name  = :REPOSITORY_NAME
    union
    select
        id
      , sy_convert.get_tag_value(add_info, 'NC_REPO')
    from
        dwd_institution
    where
        sy_convert.get_tag_value(add_info, 'NC_REPO') = :REPOSITORY_NAME
)
,
card_prev as (
    select /*+ no_merge leading(c) use_hash(c inst) use_hash(c card_prev)*/
        card_prev.*
    from
        dwd_card c
        join inst on
                inst.id = c.institution_id
        left join dwd_card card_prev on
                c.pan = card_prev.pan
                and (
                    c.expiry_date   <> card_prev.expiry_date
                    or c.client_idt <> card_prev.client_idt
                )
    where
        card_prev.record_date_to = to_date(:P_REPORT_DATE, 'DD-MM-YYYY') - 1
        and c.record_date_from  <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and c.record_date_to    >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
)
,
main_sql as (
    select /*+ no_merge use_hash(dca cc) use_hash(cc cl)*/
        cc.*
      , dca.attr_code                                                                      as report_attr
      , dca.attr_prev_code                                                                 as report_attr_prev
      , dca.attr_date_from                                                                 as report_attr_from
      , cc.opening_date                                                                    as card_open_date
      , to_char(cc.expiry_date, 'YYMM')                                                    as card_exdt
      , to_char(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'YYMMDD') || lpad (ROWNUM, 14, '0') as eho_data
      , cc.pan                                                                             as card_number
      , sy_convert.get_tag_value(ac_i_prd.add_info, 'NC_HOME_PROFILE')                     as home_profile
      , sy_convert.get_tag_value(ac_i_prd.add_info, 'NC_ACC_PROFILE')                      as acc_profile
      , inst.name                                                                          as inst_name
      , cl.record_idt                                                                      as cl_id
      , replace(cl.first_name, ',', ' ')                                                   as cl_first_name
      , replace(cl.last_name, ',', ' ')                                                    as cl_last_name
      , cl.title                                                                           as cl_title
      , trim(replace (addr.e_mail, ',', ''))                                               as cl_e_mail
      , regexp_replace(addr.mobile, '[^0-9]+', '')                                         as cl_mobile
      , cl_prev.record_idt                                                                 as cl_prev_id
      , replace(cl_prev.first_name, ',', ' ')                                              as cl_prev_first_name
      , replace(cl_prev.last_name, ',', ' ')                                               as cl_prev_last_name
      , cl_prev.title                                                                      as cl_prev_title
      , trim(replace(addr_prev.e_mail, ',', ''))                                           as cl_prev_e_mail
      , regexp_replace(addr_prev.mobile, '[^0-9]+', '')                                    as cl_prev_mobile
      , addr_prev.client_idt                                                               as cl_prev_cltidt
      , case
            when (
                card_prev.record_idt is not null
                and cc.expiry_date   <> card_prev.expiry_date
            )
                then 'Y'
                else 'N'
        end                                                                                as renew_flag
      , case
            when prev_plastic.card_idt is not null
                then 'Y'
                else 'N'
        end                                                                                as activation_flag
      , addr.record_date_from                                                              as curr_addr_record_date_from
    from (
        select /*+ no_merge */
            dca.card_idt
          , dca.attr_date_from
          , dca.attr_date_to
          , attr.code                                                                      as attr_code
          , dca_prev.code                                                                  as attr_prev_code
        from
            dwa_card_attribute dca
            join attr on
                    attr.id = dca.attr_id
            left join (
                    select
                        dca2.card_idt
                      , attr2.code
                    from
                        dwa_card_attribute dca2
                        join attr attr2 on
                                attr2.id = dca2.attr_id
                    where
                        dca2.attr_date_to = to_date(:P_REPORT_DATE, 'DD-MM-YYYY' ) - 1
            ) dca_prev on
                    dca.card_idt = dca_prev.card_idt
        ) dca
        join dwd_card cc on
                cc.record_idt = dca.card_idt
        join dwd_contract cnt on
                cnt.record_idt = cc.main_contract_idt
        join dwd_int_product ac_i_prd on
                cnt.int_product_idt = ac_i_prd.record_idt
        join inst on
                inst.id = cc.institution_id
        join dwd_client cl on
                cl.record_idt = cc.client_idt
        left join dwa_card_attribute dca_prev on
                dca.card_idt         = dca_prev.card_idt
                and dca.attr_date_to = to_date(:P_REPORT_DATE, 'DD-MM-YYYY' ) - 1
        left join card_prev on
                card_prev.pan = cc.pan
        left join dwd_client cl_prev on (
-- on cl_prev.record_idt = cc.client_idt
-- and cl_prev.record_date_to = to_date(:P_REPORT_DATE, 'DD-MM-YYYY') - 1
                    cl_prev.record_idt = cl.record_idt
                    and (
                        card_prev.record_idt       is null
                        or cc.client_idt           =  card_prev.client_idt
                    )
                    and cl_prev.record_date_to     =  to_date(:P_REPORT_DATE, 'DD-MM-YYYY' ) - 1
                )
                or
                (
                    cl_prev.record_idt             =  card_prev.client_idt
                    and cc.client_idt              <> card_prev.client_idt
                    and cl_prev.record_date_from   <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY' ) - 1
                    and cl_prev.record_date_to     >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY' ) - 1
                )
        left join (
                select
                    da.client_idt
                  , da.e_mail
                  , da.address_zip as mobile
                  , da.record_date_from
                from
                    dwd_address da
                    join dwd_address_type dat on
                            dat.id       = da.address_type_id
                            and dat.code = 'ADD_SMS_1'
                where
                    da.record_date_from            <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                    and da.record_date_to          >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        ) addr on
                addr.client_idt = cl.record_idt
        left join (
                select
                    da.client_idt
                  , da.e_mail
                  , da.address_zip as mobile
                  , da.record_date_from
                  , da.record_date_to
                from
                    dwd_address da
                    join dwd_address_type dat on
                            dat.id       = da.address_type_id
                            and dat.code = 'ADD_SMS_1'
                where
                    da.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY' ) - 1
        ) addr_prev on
                (
                    addr_prev.client_idt           =  cl.record_idt
                    and addr_prev.record_date_to   =  to_date(:P_REPORT_DATE, 'DD-MM-YYYY' ) - 1
                )
                or
                (
                    addr_prev.client_idt           =  card_prev.client_idt
                    and cc.client_idt              <> card_prev.client_idt
                    and addr_prev.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY' ) - 1
                    and addr_prev.record_date_to   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY' ) - 1
                )
        left join (
                select
                    dce.card_idt
                from
                    dwf_card_event dce
                    join dwd_event_type det on
                            dce.activate_date        =  to_date(:P_REPORT_DATE, 'DD-MM-YYYY' )
                            and det.code             =  'UNLOCK_PLASTIC'
                            and dce.event_type_id    =  det.id
                    join dwd_plastic old on
                            old.card_idt             =  dce.card_idt
                            and old.plastic_status   =  'C'
                            and old.record_date_to   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY' )
                            and old.record_date_from =  to_date(:P_REPORT_DATE, 'DD-MM-YYYY' )
                    join dwd_plastic new on
                            new.card_idt             =  dce.card_idt
                            and new.plastic_status   =  'A'
                            and new.record_date_to   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY' )
                            and new.record_date_from =  to_date(:P_REPORT_DATE, 'DD-MM-YYYY' )
                            and new.prev_record_idt  =  old.record_idt
                            and new.expiry_date      <> old.expiry_date
        ) prev_plastic on
                prev_plastic.card_idt = dca.card_idt
    where
        dca.attr_date_from   <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and dca.attr_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and (
            dca.attr_code = 'Y'
            or (
                dca.attr_date_from     = to_date(:P_REPORT_DATE, 'DD-MM-YYYY' )
                and dca.attr_code      = 'N'
                and dca.attr_prev_code = 'Y'
            )
        )
        and cc.record_date_to         >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and cc.record_date_from       <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and ac_i_prd.record_date_to   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and ac_i_prd.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and cnt.record_date_to        >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and cnt.record_date_from      <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and cl.record_date_to         >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and cl.record_date_from       <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
)
,
mmm as (
-- 49 == Renew card
    select
        '49'                                                                                as ROW_TYPE
      , to_char(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'YYMMDD') || lpad(ROWNUM, 8, '0')    as ROW_ID
      , main_sql.card_number                                                                as CARD_NUMBER
      , ''                                                                                  as EMPTY1
      , main_sql.card_number                                                                as CARD_NUMBER2
      , ''                                                                                  as EMPTY2
      , main_sql.card_exdt                                                                  as CARD_EXPIRY
      , 'N'                                                                                 as ALWAYS_N
      , main_sql.inst_name                                                                  as INST_NAME
/*                                                                                          
      , '' -- Synchronize number of result columns
      , '' -- Synchronize number of result columns
*/
    from
        main_sql
    where
        main_sql.renew_flag = 'Y'
)
select * from (
    select
-- will be excluded from result with "SKIP_COLUMNS=ORDER_AFTER_UNION"
        1                                                                                   as ORDER_AFTER_UNION
-- will be excluded from result automaticaly
      , :ORG                                                                                as ORG
      , '01'                                                                                as ROW_TYPE
      , to_char(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'),'YYMMDD')                             as ROW_ID
      , 'Way4'                                                                              as CARD_NUMBER
      , ''                                                                                  as EMPTY1
      , ''                                                                                  as CARD_NUMBER2
      , ''                                                                                  as EMPTY2
      , ''                                                                                  as CARD_EXPIRY
      , ''                                                                                  as ALWAYS_N
      , ''                                                                                  as INST_NAME
    from dual
-- body
union
    select
-- will be excluded from result with "SKIP_COLUMNS=ORDER_AFTER_UNION"
        2 as ORDER_AFTER_UNION
-- will be excluded from result automaticaly
      , :ORG as ORG
      , mmm.*
    from
        mmm
-- trailer
union
    select
-- will be excluded from result with "SKIP_COLUMNS=ORDER_AFTER_UNION"
        3                                                                                   as ORDER_AFTER_UNION
-- will be excluded from result automaticaly
      , :ORG                                                                                as ORG
      , '02'                                                                                as ROW_TYPE
      , lpad(count(1),5,'0')                                                                as ROW_ID
      , ''                                                                                  as CARD_NUMBER
      , ''                                                                                  as EMPTY1
      , ''                                                                                  as CARD_NUMBER2
      , ''                                                                                  as EMPTY2
      , ''                                                                                  as CARD_EXPIRY
      , ''                                                                                  as ALWAYS_N
      , ''                                                                                  as INST_NAME
    from mmm
) order by ORDER_AFTER_UNION, ROW_ID
