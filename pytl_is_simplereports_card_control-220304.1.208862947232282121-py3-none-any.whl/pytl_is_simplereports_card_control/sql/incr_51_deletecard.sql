with
attr as (
    select /*+ no_merge materialize */
        id
      , code
    from
        dwd_attribute
    where
        record_state       = 'A'
        and dimension_code = 'DWD_CARD'
        and type_code      = :ATTR_TYPE_CODE  -- 'PETRA_NCONTROL_REPORT'

)
,
inst as (
    select /*+ no_merge materialize */
        institution_id as id
      , name
    from
        v_dwr_institution
    where
        type_code = :INST_TYPE_CODE  -- 'NCONTROL_DESC'
        and name  = :REPOSITORY_NAME
    union
    select
        id
      , sy_convert.get_tag_value(add_info, 'NC_REPO')
    from
        dwd_institution
    where
        sy_convert.get_tag_value(add_info, 'NC_REPO') = :REPOSITORY_NAME
)
,
crd_cnt as (
    select /*+ no_merge materialize */
        c.client_idt
      , count(1) as card_count
    from
        dwd_card c
        join inst on
                c.institution_id = inst.id
        join dwa_card_attribute ct on
                ct.card_idt = c.record_idt
        join attr on
                attr.id       = ct.attr_id
                and attr.code = 'Y'
    where
        c.record_date_from    <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and c.record_date_to  >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and ct.attr_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and ct.attr_date_to   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    group by
        c.client_idt
)
,
del_sql as (
    select /*+ no_merge */
        cc.*
      , dca.new_attr_code                                                                  as report_attr
      , dca.card_idt
      , dca.prev_from
      , dca.prev_to
      , dca.prev_attr_code
      , dca.new_from
      , dca.new_to
      , dca.new_attr_code
      , 'ACC#' || cc.pan                                                                   as eho_data
      , cc.pan                                                                             as card_number
      , regexp_replace(addr.mobile, '[^0-9]+', '')                                         as cl_mobile
      , inst.name                                                                          as inst_name
      , crd_cnt.card_count
    from (
        select /*+ no_merge */
            dca_p.card_idt
          , dca_p.attr_date_from                                                           as prev_from
          , dca_p.attr_date_to                                                             as prev_to
          , attr_p.code                                                                    as prev_attr_code
          , dca_n.attr_date_from                                                           as new_from
          , dca_n.attr_date_to                                                             as new_to
          , attr_n.code                                                                    as new_attr_code
        from
            dwa_card_attribute dca_p
            left join dwa_card_attribute dca_n on
                    dca_p.card_idt           =  dca_n.card_idt
                    and dca_p.attr_date_to   <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY') - 1
                    and dca_n.attr_date_from =  to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                    and dca_n.attr_date_to   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
            join attr attr_p on
                    attr_p.id = dca_p.attr_id
            join attr attr_n on
                    attr_n.id = dca_n.attr_id
    ) dca
        join dwd_card cc on
                cc.record_date_to            >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY' )
                and cc.record_date_from      <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY' )
                and cc.record_idt            =  dca.card_idt
        join dwd_contract cnt on
                cnt.record_idt = cc.main_contract_idt
        join dwd_int_product ac_i_prd on
                cnt.int_product_idt = ac_i_prd.record_idt
        join inst on
                inst.id = cc.institution_id
        join dwd_client cl on
                cl.record_idt = cc.client_idt
        left join crd_cnt on
                crd_cnt.client_idt = cl.record_idt
        left join (
                select
                    da.client_idt
                  , da.e_mail
                  , da.address_zip as mobile
                from
                    dwd_address da
                    join dwd_address_type dat on
                            dat.id       = da.address_type_id
                            and dat.code = 'ADD_SMS_1'
                where
                    da.record_date_from   <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY' )
                    and da.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY' )
        ) addr on
                addr.client_idt = cl.record_idt
    where
        1                             =  1
        and dca.prev_to               <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY') - 1
        and dca.prev_attr_code        =  'Y'
        and dca.new_from              =  to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and dca.new_to                >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and dca.new_attr_code         =  'N'
        and cl.record_date_to         >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and cl.record_date_from       <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and ac_i_prd.record_date_to   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and ac_i_prd.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and cnt.record_date_to        >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and cnt.record_date_from      <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
)
,
mmm as (
-- 51 == Delete card
    select
        '51'                                                                                as ROW_TYPE
      , to_char(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), 'YYMMDD') || lpad(ROWNUM, 8, '0')    as ROW_ID
      , del_sql.card_number                                                                 as CARD_NUMBER
      , ''                                                                                  as EMPTY1
      , del_sql.inst_name                                                                   as INST_NAME
/*
      , '' -- Synchronize number of result columns
      , '' -- Synchronize number of result columns
      , '' -- Synchronize number of result columns
      , '' -- Synchronize number of result columns
      , '' -- Synchronize number of result columns
      , '' -- Synchronize number of result columns
*/
    from
        del_sql
    where
        del_sql.new_from        = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        and del_sql.report_attr = 'N'
)
select * from (
    select
-- will be excluded from result with "SKIP_COLUMNS=ORDER_AFTER_UNION"
        1                                                                                   as ORDER_AFTER_UNION
-- will be excluded from result automaticaly
      , :ORG                                                                                as ORG
      , '01'                                                                                as ROW_TYPE
      , to_char(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'),'YYMMDD')                             as ROW_ID
      , 'Way4'                                                                              as CARD_NUMBER
      , ''                                                                                  as EMPTY1
      , ''                                                                                  as INST_NAME
    from dual
-- body
union
    select
-- will be excluded from result with "SKIP_COLUMNS=ORDER_AFTER_UNION"
        2 as ORDER_AFTER_UNION
-- will be excluded from result automaticaly
      , :ORG as ORG
      , mmm.*
    from
        mmm
-- trailer
union
    select
-- will be excluded from result with "SKIP_COLUMNS=ORDER_AFTER_UNION"
        3                                                                                   as ORDER_AFTER_UNION
-- will be excluded from result automaticaly
      , :ORG                                                                                as ORG
      , '02'                                                                                as ROW_TYPE
      , lpad(count(1),5,'0')                                                                as ROW_ID
      , ''                                                                                  as CARD_NUMBER
      , ''                                                                                  as EMPTY1
      , ''                                                                                  as INST_NAME
    from mmm
) order by ORDER_AFTER_UNION, ROW_ID
