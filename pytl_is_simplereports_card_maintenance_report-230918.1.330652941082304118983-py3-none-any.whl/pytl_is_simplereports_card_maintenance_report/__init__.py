__version__ = "230918.1"
__job_name__ = "PyTL_IS_SimpleReports_CARD_MAINTENANCE_REPORT"
__bat_files__ = []

