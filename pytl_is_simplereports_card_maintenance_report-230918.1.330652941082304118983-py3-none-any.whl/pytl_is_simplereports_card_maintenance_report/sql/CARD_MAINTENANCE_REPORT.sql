/*
* STANDARD EMBOSSER MAINTENANCE REPORT
*
* Version history:
* 210321.1 = Nikita Fomin = ENG-3193: adding NIC_IS_Ou_SimpleReports. Initial development.
* 210920.1 = Santosh Kumar Singh = ALMAS-384: changed join to correctly fetch card_info (ALMAS-384,ALMAS-115,ALMAS-120).
* 211230.2 = Bharath : OPKSAIC-2751 : enhancing existing standard report to add Tiqmo requirements
                            1. Added alternate number logic to enhance report to EXID in the report based on input parameter
                            2. New input parameter RETURN_EXID introduced to fetch alternate id instead of PAN
                               possible inputs : RETURN_EXID=YES - fetches alternate id instead of card number
                                                 RETURN_EXID=NO - fetches card number
                                                 RETURN_EXID=null - fetches card number
* 220112.2 = Bharath : OPKSAIC-2751 : removed dependency on OPT_REPORTS package and Made generic approach for logo and product name
* 220215.2 = DenisKa = OPKSAIC-3226: fixed the issue with running under users different from OWS.
* 17-01-2022 : OPKSAIC-3246 : RETURN_EXID is spitted into RETURN_EXID_CARD / RETURN_EXID_CONTRACT
                            For Tiqmo RETURN_EXID_CONTRACT is not applicable , but default value is NO
* 220328.1 = Shalini = ALMB-695 : Added supplementary credit limit percentage field
* 220331.1 = Shalini = ALMB-695 : Reordered SUPPL_CR_LIM_PCNT field
* 220714.2 = Santosh = OPKSAIC-4620 : Logic change to read classifier name
* 220714.3 = DenisKa = OPKSAIC-4620 : Beautification of the code
* 230918.1 = Shalini = ALMB-1048 : Logic correction in cls_q subquery to avoid duplicates
*/
WITH auth_type as (
    select /*+ NO_MERGE MATERIALIZE */ id
     From ows.td_auth_type
    where code        = 'EXID'
      and amnd_state  = 'A'
    ),
ins AS
    (
        select id,bank_code,name,branch_code
                      from (select fi.bank_code,
                                   fi.posting_in,
                                   fi.id,
                                   fi.branch_code,
                                   fi2.bank_code bank_code_posting,
                                   fi.name
                            from ows.f_i fi
                                 join ows.f_i fi2 on fi.posting_in = fi2.id
                            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
                            ) inst
                      start with inst.bank_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                                      from dual
                                                      connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
                                                      )
                      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
    ),
exid as (
 select /*+ NO_MERGE MATERIALIZE */
        e.auth_idt,
        c.contract_number,
        c.con_cat
   from ows.acnt_contract c
   join ins
     on ins.id = c.f_i
   join ows.td_auth_sch e
     on e.acnt_contract__id = c.id
    and e.amnd_state        = 'A'
    and e.is_ready          = 'Y'
   join auth_type at1
     on e.auth_type  = at1.id
  where c.amnd_state = 'A'),
    T AS (
        SELECT /*+ materialize */
               DISTINCT ca.amnd_prev
          FROM ows.acnt_contract ca
          JOIN ins
            ON ca.f_i=ins.ID
         WHERE ca.amnd_date >= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')
           AND ca.amnd_date <  TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy') + 1
           AND ca.con_cat = 'C'
        ),
    c1 AS (
        SELECT /*+ NO_MERGE */
               ins.bank_code,
               decode(c0.amnd_state, 'A',9999999999, c0.ID) row_id ,
               c0.* ,
               cs.NAME contr_status_desc,
               -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
               ap.name product_name,
               ap.code product_logo,
               -- [*][end] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
               pls.card_name                                                    as cardholder_name,
               nvl(pls.company_name,' ')                                        as company_name
          FROM ows.acnt_contract c0
          JOIN ins
             ON ins.ID= c0.f_i
         LEFT JOIN ows.contr_status cs
                      ON cs.ID = c0.contr_status
                     AND cs.amnd_state = 'A'
                     AND cs.con_cat   = c0.con_cat
         LEFT JOIN ows.card_info pls -- [*] 210920.1 = Santosh Kumar Singh = ALMAS-384: changed join to correctly fetch card_info (ALMAS-384,ALMAS-115,ALMAS-120).
             on c0.id = pls.acnt_contract__oid
          JOIN ows.appl_product AP
                ON AP.internal_code = c0.product
               AND AP.amnd_state  = 'A'
               AND AP.f_i         = ins.ID
         WHERE c0.amnd_prev IN (SELECT T.amnd_prev FROM T )
         ORDER BY c0.amnd_prev,
                  c0.amnd_date DESC
    ),
    cc AS
     (
        SELECT /*+ NO_MERGE */
               row_number () OVER (PARTITION BY c1.amnd_prev ORDER BY c1.amnd_date DESC, c1.row_id DESC) AS rn,
               c1.*
          FROM c1
         ORDER BY c1.amnd_prev,
                  c1.amnd_date DESC,
                  c1.row_id DESC
        ),
    ts AS (
    SELECT /*+ NO_MERGE */
           bank_code,
           diff.product_name,
           diff.product_logo,
           diff.cardholder_name,
           diff.company_name,
           diff.contract_number AS contract_number ,
           diff.field_description ,
           diff.changed_from ,
           diff.changed_to ,
           diff.amnd_date amnd_date_stamp ,
           o.user_id AS upd_amnd_officer ,
           diff.amnd_prev ,
           '2_CARD'grp
      FROM
          (
            SELECT
              ps.*
            FROM
              (
                SELECT
                  bank_code,
                  cc.rn ,
                  row_id ,
                  LEAD(cc.amnd_prev) OVER(PARTITION BY cc.amnd_prev ORDER BY amnd_date DESC, row_id DESC) AS is_first ,
                  cc.amnd_date ,
                  cc.amnd_state ,
                  cc.amnd_prev ,
                  cc.amnd_officer ,
                  cc.contract_number ,
                  cc.product_name,
                  cc.product_logo,
                  cc.cardholder_name,
                  cc.company_name,
                  cc.cardholder_name as cardholder_namen,
                  cc.company_name as company_namen,
                  cc.tr_first_nam               AS tr_first_namn ,
                  cc.tr_last_nam                AS tr_last_namn ,
                  cc.tr_company                 AS tr_companyn ,
                  cc.contract_name              AS contract_namen ,
                  cc.card_expire                AS card_expiren ,
                  to_char(cc.contr_status_desc) AS contr_status_descn ,
                  ows.sy_convert.get_tag_value(cc.add_info_02,'CARD_CL_PCNT') AS suppl_cr_pcntn, --[+] 220328.1 = ALMB-695
                  LEAD(cc.tr_first_nam) OVER(PARTITION BY cc.amnd_prev ORDER BY cc.amnd_date DESC, row_id DESC) AS tr_first_namo ,
                  LEAD(cc.cardholder_name) OVER(PARTITION BY cc.amnd_prev ORDER BY cc.amnd_date DESC, row_id DESC) AS cardholder_nameo ,
                  LEAD(cc.company_name) OVER(PARTITION BY cc.amnd_prev ORDER BY cc.amnd_date DESC, row_id DESC) AS company_nameo ,
                  LEAD(cc.tr_last_nam) OVER(PARTITION BY cc.amnd_prev ORDER BY cc.amnd_date DESC, row_id DESC) AS tr_last_namo ,
                  LEAD(cc.tr_company) OVER(PARTITION BY cc.amnd_prev ORDER BY cc.amnd_date DESC, row_id DESC) AS tr_companyo ,
                  LEAD(cc.contract_name) OVER(PARTITION BY cc.amnd_prev ORDER BY cc.amnd_date DESC, row_id DESC) AS contract_nameo ,
                  LEAD(cc.card_expire) OVER(PARTITION BY cc.amnd_prev ORDER BY cc.amnd_date DESC, row_id DESC) AS card_expireo ,
                  LEAD(to_char(cc.contr_status_desc)) OVER(PARTITION BY cc.amnd_prev ORDER BY cc.amnd_date DESC, row_id DESC) AS contr_status_desco ,
                  LEAD(ows.sy_convert.get_tag_value(cc.add_info_02,'CARD_CL_PCNT')) OVER(PARTITION BY cc.amnd_prev ORDER BY cc.amnd_date DESC, row_id DESC) AS suppl_cr_pcnto --[+] 220328.1 = ALMB-695
               FROM cc
              )
              UNPIVOT ( (changed_from, changed_to) FOR field_description IN (
              (tr_first_namo, tr_first_namn)         AS 'TR_FIRST_NAM' ,
              (cardholder_nameo, cardholder_namen)    AS 'TR_CARD_HOLDER_NAME' ,
              (company_nameo, company_namen)             AS 'TR_COMPANY_NAME' ,
              (tr_last_namo, tr_last_namn)           AS 'TR_LAST_NAM' ,
              (tr_companyo,  tr_companyn)            AS 'TR_COMPANY' ,
              (contract_nameo, contract_namen)       AS 'CONTRACT_NAME' ,
              (card_expireo,card_expiren)            AS 'CARD_EXPIRE',
              (contr_status_desco,contr_status_descn) AS 'CONTR_STATUS_CSR' ,
              (suppl_cr_pcnto,suppl_cr_pcntn)        AS 'SUPPL_CR_LIM_PCNT' --[+] 220328.1 = ALMB-695 --[*] 220331.1 = ALMB-695
               )) ps

            WHERE ps.amnd_date >= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')
              AND ps.amnd_date < TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy') + 1
          ) diff
        JOIN ows.officer o
          ON o.amnd_state = 'A'
         AND o.ID = diff.amnd_officer
       WHERE ( nvl(diff.changed_from, '0') <> nvl(diff.changed_to, '0')
          OR diff.amnd_state             = 'C' )
         AND diff.is_first IS NOT NULL
        ORDER BY
          contract_number ,
          amnd_prev ,
          field_description ,
          amnd_date_stamp DESC
      )  ,
  cls_q AS
  (
    select * from ( --[+] 230918.1 = ALMB-1048
    SELECT
      ins.bank_code,
      cc.CONTRACT_NUMBER ,
      -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
      ap.name product_name,
      ap.code product_logo,
      -- [*][end] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
      pls.card_name                                                    as cardholder_name,
      nvl(pls.company_name,' ')                                        as company_name,
      CASE
        WHEN cst.code LIKE 'BC_CR_DEC_M-'||ins.BANK_CODE||'-CPY' THEN 'BLOCK-CODE CARD'
        ELSE upper(cst.name )
      END field_description ,
      CASE
        -- [*][begin] 220714.3 = DenisKa = OPKSAIC-4620 : Beautification of the code
        WHEN cst.code in (
            'CONTR_STATUS'
            ,'BFC_CARD_STATUS'
            -- [*][begin] 220714.2 = Santosh = OPKSAIC-4620 : Logic change to read classifier name
            ,'MMF_WAIVE_CARD_PE'
            ,'AMF_WAIVE_CARD_PE'
            ,'NCONTROL_ENROLMENT'
            -- [*][end]   220714.2 = Santosh = OPKSAIC-4620 : Logic change to read classifier name
        )
        THEN csv_o.NAME
        -- [*][end] 220714.3 = DenisKa = OPKSAIC-4620 : Beautification of the code
        WHEN
          (
            cst.code LIKE 'BCODE-C1-'
            ||ins.BANK_CODE
          OR cst.code LIKE 'BC_CR_DEC_M_'
            ||ins.bank_code
            ||'_CPY'
          )
        THEN DECODE(TO_CHAR(csv_o.CODE),'_', NULL,csv_o.CODE)
        ELSE DECODE(TO_CHAR(csv_o.CODE),'_', NULL,csv_o.CODE)
      END Changed_from ,
      CASE
        -- [*][begin] 220714.3 = DenisKa = OPKSAIC-4620 : Beautification of the code
        WHEN cst.code in (
            'CONTR_STATUS'
            ,'BFC_CARD_STATUS'
            ,'MMF_WAIVE_CARD_PE'
            ,'AMF_WAIVE_CARD_PE'
            ,'NCONTROL_ENROLMENT'
        )
        -- [*][end] 220714.3 = DenisKa = OPKSAIC-4620 : Beautification of the code
        THEN csv_n.NAME
        WHEN
          (
            cst.code LIKE 'BCODE-C1-'
            ||ins.BANK_CODE
          OR cst.code LIKE 'BC_CR_DEC_M_'
            ||ins.bank_code
            ||'_CPY'
          )
        THEN DECODE(TO_CHAR(csv_n.CODE),'_', NULL,csv_n.CODE)
        ELSE DECODE(TO_CHAR(csv_n.CODE),'_', NULL,csv_n.CODE)
      END Changed_to ,
      cl.status_date AMND_DATE_STAMP ,
      o.USER_ID UPD_AMND_OFFICER ,
      '3_CLS' grp
       ,row_number () OVER (PARTITION BY pls.acnt_contract__oid,cst.code,csv_n.CODE ORDER BY  pls.id DESC) AS rn  --[+]230918.1 = ALMB-1048
    FROM ows.acnt_contract cc
    JOIN ins
      ON ins.id= cc.f_i
    join ows.card_info pls
          on cc.id = pls.acnt_contract__oid
    JOIN ows.cs_status_log cl
      ON cc.id          = cl.acnt_contract__oid
     AND cc.amnd_state='A'
    JOIN ows.officer o
      ON o.id          = cl.officer
     AND o.amnd_state='A'
    JOIN ows.cs_status_type cst
      ON cst.amnd_state = 'A'
     AND cst.id      = cl.status_type
    JOIN ows.cs_status_value csv_o
      ON csv_o.id          =cl.status_value_prev
     AND csv_o.amnd_state='A'
     AND cst.id          = csv_o.cs_status_type__oid
    JOIN ows.cs_status_value csv_n
      ON csv_n.id          =cl.status_value
     AND csv_n.amnd_state='A'
     AND cst.id          = csv_n.cs_status_type__oid
    JOIN ows.appl_product ap
      ON ap.INTERNAL_CODE = cc.PRODUCT
     AND ap.AMND_STATE  = 'A'
     AND ap.F_I         = ins.id
     AND cst.id         = cl.status_type
     AND cl.status_date >= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')
     AND cl.status_date <  TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy') + 1
      /* Embosser Maint Check */
     AND cc.con_cat='C'
     AND
      (
        cst.code LIKE 'BC_CR_DEC_M_'
        ||ins.bank_code
        ||'_CPY'
        /* 16.3 */
      OR cst.code LIKE 'BCODE-C1-'
        ||ins.bank_code
        /* 16.5 */
      OR cst.code LIKE 'CONTR_STATUS'
        /* 16.3/16.5 */
      OR cst.code LIKE 'BFC_CARD_STATUS'

      OR cst.code LIKE 'MMF_WAIVE_CARD_PE'
      OR cst.code LIKE 'AMF_WAIVE_CARD_PE'
      OR cst.code LIKE 'NCONTROL_ENROLMENT'

      )
    ORDER BY
      1,
      contract_number,
      field_description,
      AMND_DATE_STAMP DESC
--[+] begin 230918.1 = ALMB-1048
  ) 
  where rn=1
--[+]end 230918.1 = ALMB-1048
    ) ,
pin_q AS
        (
        SELECT
          ins.bank_code,
          -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
          ap.name product_name,
          ap.code product_logo,
          -- [*][end] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
          ci.card_name                                                    as cardholder_name,
          nvl(ci.company_name,' ')                                        as company_name,
          cc.contract_number
            ,aci.production_event field_description
            ,CASE
                WHEN aci.production_event  = 'PLRE_PINK_NOFEE' THEN
                '*--N E W - P L A S T I C--*'
                WHEN aci.production_event  = 'PLRE_PINK' THEN
                '*--N E W - P L A S T I C--*'
                WHEN aci.production_event  = 'PINPR_NOFEE' THEN
                '*--N E W - P I N--*'
                WHEN aci.production_event  = 'PINPR' THEN
                '*--N E W - P I N--*'
            WHEN aci.production_event  = 'REISS' THEN
                '*--R E - I S S U E--*'
                ELSE
                aci.production_event
                END changed_from
            ,CASE
                WHEN aci.production_event  = 'PLRE_PINK_NOFEE' THEN
                'Plast.Reiss. - KeepPIN - NoFee'|| CASE WHEN cc.card_expire IS NOT NULL THEN ' ['||cc.card_expire||']' END
                WHEN aci.production_event  = 'PLRE_PINK' THEN
                'Plast.Reiss. - KeepPIN'|| CASE WHEN cc.card_expire IS NOT NULL THEN ' ['||cc.card_expire||']' END
                WHEN aci.production_event  = 'PINPR_NOFEE' THEN
                'Pin Reiss. - NoFee'
                WHEN aci.production_event  = 'PINPR' THEN
                'Pin Reiss.'
            WHEN aci.production_event  = 'REISS' THEN
                'Re-Issue'
                ELSE
                aci.production_event
                END changed_to
            ,aci.amnd_date amnd_date_stamp
            ,o.user_id upd_amnd_officer
            ,'4_PIN_Q' grp
        FROM ows.card_info ci
        JOIN ows.acnt_contract cc ON ci.acnt_contract__oid  = cc.ID AND cc.amnd_state='A' AND cc.con_cat='C'
        JOIN ows.appl_card_info aci ON aci.card_info_id = ci.ID AND aci.amnd_state='A' AND
        ( aci.production_event LIKE 'PLRE_PINK%'  OR aci.production_event LIKE 'PINPR%' OR  aci.production_event LIKE '%REISS%' )
        JOIN ows.officer o ON o.amnd_state='A' AND o.ID=aci.amnd_officer
        JOIN ows.appl_product AP ON AP.internal_code  = cc.product
                      AND AP.amnd_state = 'A'
                      AND AP.f_i = cc.f_i
                      JOIN ins  ON cc.f_i = ins.ID
        WHERE 1=1
        AND aci.amnd_date >= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')
        AND aci.amnd_date <   TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy') + 1
        ORDER BY 1, contract_number, field_description, amnd_date_stamp DESC
        ),
new_recs as (
select INS.bank_code,
       acn.contract_number,
       -- [*][begin] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
       ap.name product_name,
       ap.code product_logo,
       -- [*][end] 220112.1 = Bharath = OPKSAIC-2751 : Query update to remove dependency on UAE standard package and Made generic approach for logo and product name
       pls.card_name                                                    as cardholder_name,
       nvl(pls.company_name,' ')                                        as company_name,
       'NEW RECORD ADDED'  as FIELD_DESCRIPTION,
       null as CHANGED_FROM ,
       acn.contract_number as CHANGED_TO,
       acn.amnd_date  as AMND_DATE_STAMP,
       (select min(user_id) from ows.officer o where o.amnd_state='A' and o.id= acn.amnd_officer) as UPD_AMND_OFFICER,
        '1_NEW_Q' grp
  from ows.acnt_contract acn
   JOIN INS
      ON ins.id=acn.f_I
   join ows.card_info pls
             on acn.id = pls.acnt_contract__oid
   join ows.appl_product ap on ap.internal_code  = acn.product
              and ap.amnd_state = 'A'
              and ap.f_i = acn.f_i
 where acn.amnd_prev in
    (
    select rec_sel.amnd_prev
    from (select act.amnd_prev, count(act.amnd_prev) from ows.acnt_contract act, ows.f_i fi
    where fi.id = act.F_I
       and fi.AMND_STATE = 'A'
       and fi.bank_code = ins.branch_code
       and act.con_cat ='C'
       and act.pcat = 'C'
    group by act.amnd_prev having count(act.amnd_prev) = 1 ) rec_sel
    )
     and acn.amnd_state = 'A'
     and acn.amnd_date >= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')
      and acn.amnd_date < TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy') + 1
 order by acn.amnd_prev, acn.amnd_date
 )
    SELECT
          a.bank_code       "ORG",
          case when exid.con_cat = 'C' then
          decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',exid.auth_idt, a.contract_number) else
          decode(upper(substr(nvl(:RETURN_EXID_CONTRACT,'N'),1,1)), 'Y',exid.auth_idt, a.contract_number) end as "CARD NUMBER",
          a.cardholder_name "CARDHOLDER NAME",
          a.company_name    "COMPANY NAME",
          a.product_logo    "PRODUCT LOGO",
          a.product_name    "PRODUCT NAME",
          a.field_description "FIELD",
          a.changed_from      "FROM",
          a.changed_to        "TO",
          to_char(a.amnd_date_stamp,'dd-mm-yyyy') "DATE",
          to_char(a.amnd_date_stamp,'HH24:MI:SS') "TIMESTAMP",
          a.upd_amnd_officer "OFFICER"
     from (select bank_code,
                  contract_number,
                  cardholder_name,
                  company_name,
                  product_logo,
                  product_name,
                  grp,
                  field_description,
                  changed_from ,
                  changed_to,
                  amnd_date_stamp,
                  upd_amnd_officer
             from ts
        union all
           select bank_code,
                  contract_number card_number,
                  cardholder_name,
                  company_name,
                  product_logo,
                  product_name,
                  grp,
                  field_description,
                  changed_from,
                  changed_to,
                  amnd_date_stamp,
                  upd_amnd_officer
             from cls_q
        union all
           select bank_code,
                  contract_number,
                  cardholder_name,
                  company_name,
                  product_logo,
                  product_name,
                  grp,
                  field_description,
                  changed_from,
                  changed_to,
                  amnd_date_stamp,
                  upd_amnd_officer
             from pin_q
        union all
           select n.bank_code,
                  n.contract_number,
                  n.cardholder_name,
                  n.company_name,
                  n.product_logo,
                  n.product_name,
                  n.grp,
                  n.field_description,
                  n.changed_from,
                  case when exid.con_cat = 'C' then
                  decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',exid.auth_idt, n.changed_to) else
                  decode(upper(substr(nvl(:RETURN_EXID_CONTRACT,'N'),1,1)), 'Y',exid.auth_idt, n.changed_to) end changed_to,
                  n.amnd_date_stamp,
                  n.upd_amnd_officer
             from new_recs n
        left join exid
               on exid.contract_number = n.changed_to
      )  a
 left join exid
        on exid.contract_number = a.contract_number
 order by a.bank_code,
          a.contract_number,
          a.grp,
          a.field_description,
          a.amnd_date_stamp
