__version__ = "220712.6"
__job_name__ = "PyTL_IS_SimpleReports_CARD_PRODUCTION"
__bat_files__ = []

