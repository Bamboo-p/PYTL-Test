/*
* 220215.12 = DenisKa = OPKSAIC-3226: fixed the issue with running under users different from OWS.
* 220317.1  = Shalini = ALMB-692: mapping changes for company_name field, entire product name extracted, fixed the issue of duplicates to get the most recent record of the p_report_date
* 220712.1 = Bharath = OPKSAIC-4608: Alternate Id (EXID) logic added
*/
with inst as(
select id institution_id,bank_code code,name
                      from (select fi.bank_code,
                                   fi.posting_in,
                                   fi.id,
                                   fi2.bank_code bank_code_posting,
                                   fi.name
                            from ows.f_i fi
                                 join ows.f_i fi2 on fi.posting_in = fi2.id
                            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
                            ) inst
                      start with inst.bank_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                                      from dual
                                                      connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
                                                      )
                      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2),
-- [+][begin] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
auth_type as (
    select /*+ no_merge materialize */ id 
     From ows.td_auth_type
    where code        = 'EXID'
      and amnd_state  = 'A'
    ),
exid as (
 select /*+ no_merge materialize */
        e.auth_idt,
        c.contract_number,
		c.con_cat
   from ows.acnt_contract c
   join inst ins 
     on ins.institution_id = c.f_i
   join ows.td_auth_sch e
     on e.acnt_contract__id = c.id
    and e.amnd_state        = 'A'
    and e.is_ready          = 'Y'        
   join auth_type at1
     on e.auth_type  = at1.id
  where c.amnd_state = 'A'
  )
-- [+][end] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
select
   i.code                                                                                                    "ORG",
   -- [+][begin] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
   decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',exid.auth_idt, card.contract_number)              "CARD NUMBER", 
   -- [+][end] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
   substr(ap.code,1,11) || ' '                                                                               "PRODUCT LOGO",
   /*rpad(
     substr(
            ap.name, 12,
            coalesce(
                to_number(
                    decode(
                        instr(ap.name,' ',1,4)/1,
                        0, null, 
                        instr(ap.name,' ',1,4)
                    ) - 1
                ),
                length(ap.name)
            ) - 11
     ),
     20,
     ' '
   )                                                                                                         "PRODUCT NAME",*/
   ap.name                                                                                                   "PRODUCT NAME",
   rpad(pls.card_name,30,' ')                                                                                "CARDHOLDER NAME",
   rpad(nvl(card.tr_company,' '),30,' ') || ' '                                                              "COMPANY NAME",
   to_char(ows.sy_convert.last_day_month(ows.sy_convert.fr_yymm(pls.card_expire)),'DD-MM-YYYY')              "EXPIRY DATE",
   to_char(pls.date_from,'DD-MM-YYYY')                                                                       "CREATION DATE",
   case when pls.status in ('A', 'C') then 'YES' else 'NO' end                                               "IS ACTIVATED"
from ows.acnt_contract cac
   join ows.acnt_contract card
        on cac.id = card.acnt_contract__oid
	--[+][begin] 220317.1 = Shalini = ALMB-692 : Query changes to discard to fetch latest record for particular P_REPORT_DATE
   join (select * 
         from  ( select ci.*,
                   ROW_NUMBER() OVER(PARTITION BY ACNT_CONTRACT__OID ORDER BY id desc) as rn
                from ows.card_info ci
                where date_from = to_date(:P_REPORT_DATE,'DD-MM-YYYY')
				and status != 'I'
                and production_type not in (0,1)
                )
         where rn=1)pls
	--[+][end] 220317.1 = Shalini = ALMB-692 : Query changes to discard to fetch latest record for particular P_REPORT_DATE
        on card.id = pls.acnt_contract__oid
   join ows.appl_product ap
        on card.product = internal_code
  join inst i on cac.f_i = i.institution_id
  -- [+][begin] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
  left join exid on exid.contract_number = card.contract_number
  -- [+][end] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
where 1=1
     and cac.amnd_state = 'A'
     and card.amnd_state = 'A'
     and ap.amnd_state = 'A'
