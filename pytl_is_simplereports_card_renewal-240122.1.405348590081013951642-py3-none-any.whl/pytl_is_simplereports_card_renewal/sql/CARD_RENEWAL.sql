/*
* Version history:
* 230606.1 = ErnestH = NICORE-122: Alternate Id (EXID) logic added
* 240122.1 = Shalini = IB-777: Logic changes for Product name

*/

with inst as(
select id institution_id,bank_code code,name
                      from (select fi.bank_code,
                                   fi.posting_in,
                                   fi.id,
                                   fi2.bank_code bank_code_posting,
                                   fi.name
                            from ows.f_i fi
                                 join ows.f_i fi2 on fi.posting_in = fi2.id
                            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
                            ) inst
                      start with inst.bank_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                                      from dual 
                                                      connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
                                                      )
                      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2)
, auth_type as (
    select /*+ NO_MERGE MATERIALIZE */ id 
     From ows.td_auth_type
    where code        = 'EXID'
      and amnd_state  = 'A')
, exid as (
 select /*+ NO_MERGE MATERIALIZE */
        e.auth_idt,
        c.contract_number,
        c.con_cat
   from ows.acnt_contract c
   join inst 
     on institution_id = c.f_i
   join ows.td_auth_sch e
     on e.acnt_contract__id = c.id
    and e.amnd_state        = 'A'
    and e.is_ready          = 'Y'        
   join auth_type at1
     on e.auth_type  = at1.id
  where c.amnd_state = 'A'
    and c.card_expire is not null)
select
  i.code "ORG",
   decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',exid.auth_idt, card.contract_number)            "CARD NUMBER",
   substr(ap.code,1,11) || ' '                                                                               "PRODUCT LOGO",
--[*] 240122.1 = IB-777
--   rpad(substr(ap.name,12,coalesce(to_number(decode(instr(ap.name,' ',1,4)/1,0,null,
--   instr(ap.name,' ',1,4))-1),length(ap.name))-11),20,' ')                                                   "PRODUCT NAME",
   ap.name                                                                                                    "PRODUCT NAME",
--[*] 240122.1 = IB-777
   rpad(pls.card_name,30,' ')                                                                                "CARDHOLDER NAME",
   rpad(nvl(pls.company_name,' '),30,' ') || ' '                                                             "COMPANY NAME",
       to_char(ows.sy_convert.last_day_month(ows.sy_convert.fr_yymm(pls.card_expire)),'DD-MM-YYYY')          "EXPIRY DATE",
   to_char(pls.date_from,'DD-MM-YYYY')                                                                       "CREATION DATE",
   case when pls.status in ('A', 'C') then 'YES' else 'NO' end                                               "IS ACTIVATED"
from ows.acnt_contract cac
   join ows.acnt_contract card 
        on cac.id = card.acnt_contract__oid
   left join exid 
        on exid.contract_number = card.contract_number
   join ows.card_info pls 
        on card.id = pls.acnt_contract__oid
   join ows.appl_product ap 
        on card.product = internal_code
  join inst i on cac.f_i = i.institution_id
where 1=1
     and cac.amnd_state = 'A' 
     and card.amnd_state = 'A'
   and ap.amnd_state = 'A' 
     and pls.status != 'I' 
     and pls.production_type not in (0,1)
     and pls.date_from = to_date(:P_REPORT_DATE,'DD-MM-YYYY')
     and pls.production_event like 'RENEXP%'