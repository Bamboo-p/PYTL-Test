__version__ = "220719.1"
__job_name__ = "PyTL_IS_SimpleReports_CARD_STATUS_CHANGE"
__bat_files__ = []

