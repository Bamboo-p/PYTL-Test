/*
09-12-2021 : OPKSAIC-1442 : enhancing existing standard report to add KSA requirements
                            1. Added alternate number logic to enhance report to EXID in the report based on input parameter
					        2. New input parameter RETURN_EXID introduced to fetch alternate id instead of PAN
							   possible inputs : RETURN_EXID=Y - fetches alternate id instead of card number
												 RETURN_EXID=N - fetches card number
												 RETURN_EXID=null - fetches card number
16-01-2022 : OPKSAIC-3246 : RETURN_EXID is spitted into RETURN_EXID_CARD / RETURN_EXID_CONTRACT
                            For Tiqmo RETURN_EXID_CONTRACT is not applicable , but default value is NO
* 220712.1 = Bharath = OPKSAIC-4608: Alternate Id (EXID) logic added
* 220719.1 = Santosh Kumar Singh = OPKSAIC-4608: Remove redaundant closing of comment
*/
with inst as (     
	select /*+ no_merge materialize */ 
          id,
		  branch_code,
		  name inst_name
     from (select dwd_institution.branch_code,
				  dwd_institution.posting_institution_id,
				  dwd_institution.id,
				  dwd_institution2.branch_code branch_code_posting,
                  dwd_institution.name
			 from dwd_institution
			 join dwd_institution dwd_institution2 
			   on dwd_institution.posting_institution_id = dwd_institution2.id
		    where dwd_institution.record_state = 'A'
		   ) inst
	   start with inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
										 from dual 
								   connect by regexp_substr(:ORGLIST , '[^,]+', 1, level) is not null
									  )
					        connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
	),
products as (
	select /*+ no_merge materialize */
           *
      from v_dwr_product p
      join inst i 
	    on substr(p.code, 5, 3) = i.branch_code
     where class_code = 'BASE_REPORTS' 
       and type_code = 'LOGO'
	),
contracts as (
	select /*+ no_merge ordered use_hash(c i) use_hash(c p) */
          c.record_idt,
          p.name product_name,
		  c.personal_account,
          substr(p.product_code,1,11) logo
     from dwd_contract c
	 join inst i
       on i.id                = c.institution_id
	 join products p
	   on p.product_id        = c.product_id
	where c.record_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	  and c.record_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
      and c.client_category   = 'P'
	) , 
cards as (
	select /*+ no_merge index(c dwd_card_inst_idx)*/
          inst.branch_code,
		  c.record_idt,
          c.pan,
          ct.product_name,
          ct.logo,
          c.opening_date,
          c.expiry_date,
		  l.client_number,
		  ct.personal_account,
          (select max(evt.name) keep (dense_rank last order by evv.record_date)
             from dwd_event_type evt
             join dwf_card_event evv 
			   on evt.id             = evv.event_type_id
            where evt.dimension_code = 'DWD_CARD' 
			  and evt.group_code     = 'CONTR_STATUS' 
			  and evv.card_idt       = c.record_idt 
			  and evv.activate_date  < TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
			) old_card_status,
           (select max(evt.name) keep (dense_rank last order by evv.record_date)
             from dwd_event_type evt
             join dwf_card_event evv 
			   on evt.id             = evv.event_type_id
            where evt.dimension_code = 'DWD_CARD' 
			  and evt.group_code     = 'CONTR_STATUS' 
			  and evv.card_idt       = c.record_idt 
			  and evv.activate_date  = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
			)  new_card_status,
           trim(c.embossed_first_name || ' ' || c.embossed_last_name) as embossing_name
      from dwd_card c 
      join inst
        on c.institution_id    = inst.id
      join contracts ct
        on ct.record_idt       = c.main_contract_idt
      join dwd_client l
	    on c.client_idt        =l.record_idt
     where c.record_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
       and c.record_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
       and l.record_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
       and l.record_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	),
ext_nums as (
	select /*+no_merge materialize */
	       dca.card_idt,
		   dca.attr_value exid
	  from dwa_card_attribute dca
	  join dwd_attribute da
	    on dca.attr_id = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CARD'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	),
-- [+][begin] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
contract_ext_nums as (
	select /*+no_merge materialize */
	       dca.contract_idt,
		   dca.attr_value contract_exid
	  from dwa_contract_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CONTRACT'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	)
-- [+][end] 220712.1 = Bharath : OPKSAIC-4608 : Alternate ID logic added
	select c.branch_code   					                  "ORG",
	       decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',e.exid, c.pan) as "CARD NUMBER",
		   c.logo          					                  "PRODUCT LOGO",
		   c.product_name  					                  "PRODUCT NAME",
		   to_char(c.expiry_date, 'dd-mm-yyyy')               "EXPIRY DATE",
		   to_char(c.opening_date, 'dd-mm-yyyy')              "CREATION DATE",
		   c.old_card_status 					              "OLD CARD STATUS",
		   c.new_card_status 					              "NEW CARD STATUS",
		   c.embossing_name  					              "CARDHOLDER NAME",
		   -- [+][begin] 220712.2 = Bharath : OPKSAIC-4608 : Alternate ID logic added
		   decode(upper(substr(nvl(:RETURN_EXID_CONTRACT,'N'),1,1)), 'Y',cen.contract_exid, c.personal_account) "ACCOUNT NUMBER",
		   -- [+][end] 220712.2 = Bharath : OPKSAIC-4608 : Alternate ID logic added
		   c.client_number                                    "CUSTOMER NUMBER"
	  from cards c
 left join ext_nums e
        on c.record_idt = e.card_idt
 -- [+][begin] 220712.2 = Bharath : OPKSAIC-4608 : Alternate ID logic changed
 left join contract_ext_nums cen 
        on c.record_idt = cen.contract_idt
 -- [+][end] 220712.2 = Bharath : OPKSAIC-4608 : Alternate ID logic added
     where c.new_card_status is not null