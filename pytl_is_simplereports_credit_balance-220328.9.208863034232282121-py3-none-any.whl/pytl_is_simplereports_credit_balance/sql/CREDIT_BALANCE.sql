/* Credit balance report
	001.08092021 shalini:ALMAS-116 :Initial Development
*/
with inst as 
      (
      select /*+ no_merge materialize */ 
		id ,
		branch_code code,
		name
					  from (select dwd_institution.branch_code,
								   dwd_institution.posting_institution_id,
								   dwd_institution.id,
								   dwd_institution2.branch_code branch_code_posting,
                                   dwd_institution.name
							from dwd_institution
								 join dwd_institution dwd_institution2 on dwd_institution.posting_institution_id = dwd_institution2.id
							where dwd_institution.record_state = 'A'
							) inst
					  start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
													  from dual 
													  connect by regexp_substr(:ORG , '[^,]+', 1, level) is not null
													  )
					  connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2      
      ),
prod as
(select /*+ no_merge materialize */
         substr(vdp.code, 1, 3) as logo, vdp.product_id
    from v_dwr_product vdp
   where vdp.type_code = 'LOGO'
     and vdp.class_code = 'BASE_REPORTS'),
oper as
(select /*+ no_merge materialize */
         op.operation_type_id, op.code
    from v_dwr_operation_type op
   where op.class_code = 'LAST_ACTIVITY_MARTS' 
     and op.type_code = 'LAST_OPER_LTD'),
bal as
(select /*+ no_merge materialize */
         ag.account_group_id, ag.type_code
    from v_dwr_account_group ag
   where ag.class_code = 'BALANCE_TYPE'
     and ag.type_code in ('TOTAL_BALANCE', 'DEPOSIT')),
     
base_cbr as
(select  dc.code as "ORG",
         vdp.logo as "Logo",
         dc.personal_account  as "Account Number",
         dc.client_short_name as "Short Name",
         lim.amount as "Credit Limit",
         dc.total_balance as "Credit Balance",
         decode(dc.deposit_date, null, 0, ceil(TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') - dc.deposit_date)) as "DAYS",
         decode(b.bc1, '_', null, b.bc1) as "Block Code 1",
         decode(b.bc2, '_', null, b.bc2) as "Block Code 2",
         nvl(da.code, a.name) as "Status"
         
    from (select /*+ leading (dc vdi b) */
                 vdi.id,
                 vdi.code,
                 dc.record_idt,
                 dc.personal_account,
                 dc.client_short_name,
                 dc.product_id,
                 sum(decode(ag.type_code, 'TOTAL_BALANCE', b.balance, 0)) as total_balance,
                 min(decode(ag.type_code, 'DEPOSIT', b.date_not_null_balance, null)) as deposit_date
            from dwd_contract dc
            join inst vdi on dc.institution_id = vdi.id
            join dwf_account_balance b on b.contract_idt = dc.record_idt
            join bal ag on ag.account_group_id = b.account_group_id
			join dwd_client dcl on  dcl.record_idt = dc.client_idt and  dcl.record_state='A'
			join dwd_client_type  dct ON dcl.client_type_id= dct.id and  dct.record_state='A' 
            and dct.code in ('CLIENT_PRIV','CLIENT_COMM')
           where 
			 dc.record_state = 'A'
             and dc.record_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
             and dc.record_date_to >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
             and b.banking_date = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
           group by vdi.id, dc.product_id, dc.record_idt, dc.personal_account, dc.client_short_name,vdi.code) dc
    join prod vdp on dc.product_id = vdp.product_id
    join dwf_contract_limit lim on lim.contract_idt = dc.record_idt
                                    and lim.banking_date = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
                                    and lim.type_code = 'FIN_LIMIT'
    join dwd_attribute a on a.dimension_code = 'DWD_CONTRACT'
                        and a.record_state = 'A'
                        and a.type_code = 'BFA_ACCOUNT_STATUS' /*PEI-1698*/
                        and a.used_as_default = 'Y'
    left outer join (select a.name code, a.type_idt, da.contract_idt
                      from dwa_contract_attribute da
                      join dwd_attribute a on da.attr_id = a.id
                                          and a.dimension_code = 'DWD_CONTRACT'
                                          and a.record_state = 'A'
                                          and a.type_code = 'BFA_ACCOUNT_STATUS'
                                          and da.attr_date_from <= trunc(TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY'))
                                          and attr_date_to >= trunc(TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY'))) da 
                  on da.contract_idt = dc.record_idt and da.type_idt = a.type_idt
    left outer join (select oc.contract_idt,
                           max(decode(oc.decision_code, 'BLOCK_CODE_ACC1', oc.decision_result)) as bc1,
                           max(decode(oc.decision_code, 'BLOCK_CODE_ACC2', oc.decision_result)) as bc2
                      from opt_v_contract_decision oc
                     where oc.decision_code in ('BLOCK_CODE_ACC1', 'BLOCK_CODE_ACC2')
                       and oc.banking_date = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
                     group by oc.contract_idt) b on b.contract_idt = dc.record_idt
  where dc.total_balance > 0)
  select b.*
  from base_cbr b
order by 1, 2, 5
