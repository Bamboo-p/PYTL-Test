__version__ = "220216.4"
__job_name__ = "PyTL_IS_SimpleReports_CREDIT_LIMIT_CHANGE_REPORT"
__bat_files__ = []

