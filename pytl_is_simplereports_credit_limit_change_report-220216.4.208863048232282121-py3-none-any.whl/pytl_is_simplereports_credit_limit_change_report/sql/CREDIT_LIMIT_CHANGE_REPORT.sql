/*
* STANDARD CREDIT LIMIT CHANGE REPORT REPORT
*
* Version history:
* 210906.1 = Santosh Kumar Singh = ALMAS-383: Logic correction for BANKING_DATE
* 211021.2 = Santosh Kumar Singh = ENG-3964: Removed logic for prev_amount != 0
* 220321.3 = Shalini = ALMB-698: Renamed COMPANY NAME field to SHORT NAME 
*/
with 
org_list as(
select regexp_substr(:ORG,'[^,]+', 1, level) orgs from dual
   connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null ) ,
inst as
(select /*+ no_merge materialize */
         vdi.institution_id, vdi.code as orgcd, vdi.code || ' - ' || upper(vdi.name) as org, vdi.name
    from v_dwr_institution vdi
	Join org_list ol
      on vdi.code = ol.orgs
   where class_code = 'BASE_REPORTS' 
     and type_code  = 'BANK_DESC' 
     --and vdi.code in ( :ORG)
	 ),
contract as 
(select /*+ no_merge materialize */
                  dc.record_idt,
				  dc.personal_account,
				  dc.client_idt,
                  dc.client_short_name,
				  dc.institution_id,
				  dc.product_id,
				  inst.orgcd
             from dwd_contract dc
			 Join inst on inst.institution_id = dc.institution_id
            where dc.record_date_from <= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
              and dc.record_date_to   >= to_date(:P_REPORT_DATE,'dd-MM-yyyy')),              
prod as
(select /*+ no_merge materialize */
         vdp.product_id, vdp.code as prdcd, substr(vdp.code, 1, 3) as logo, ltrim(vdp.product_name, '0') as Prdname
    from v_dwr_product vdp
   where vdp.type_code = 'LOGO'
     and vdp.class_code = 'BASE_REPORTS'),
     
bal as 
(select /*+ no_merge materialize */
         ag.account_group_id, ag.type_code
    from v_dwr_account_group ag
   where ag.class_code = 'BALANCE_TYPE'
     and ag.type_code = 'TOTAL_BALANCE'),
     
contract_limit as 
(select /*+ no_merge materialize*/
                contract_idt, amount, banking_date,  prev_amount,
                lag(banking_date,1) over (partition by contract_idt order by banking_date) as prev_min_date
            from (select /*+ index_combine (l dwf_limit_inst_idx dwf_limit_type_idx)*/ 
                        amount,
                        contract_idt,
                        banking_date,
                        lag(amount,1) over (partition by contract_idt order by banking_date) as prev_amount
                   from dwf_contract_limit l
                   join inst vdi 
                     on l.institution_id = vdi.institution_id
                  where type_code    = 'FIN_LIMIT' )
          where nvl(amount, 0)      !=  nvl(prev_amount, 0)
            --and nvl(prev_amount, 0) != 0 -- [-] 211021.2 = Santosh Kumar Singh = ENG-3964
			and banking_date >= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
            and banking_date <= to_date(:P_REPORT_DATE,'dd-MM-yyyy'))
      
  select /*+ ordered use_hash(dc cl) use_hash(dc l) use_hash(dc vdp) use_hash(dc balance) use_hash(dc attr) */
            dc.orgcd as org,
            cl.short_name as "SHORT NAME", --[*] 220321.3 = ALMB-698 = Renamed COMPANY NAME field to SHORT NAME 
            dc.personal_account as "CONTRACT NUMBER",
            dc.client_short_name as "CARDHOLDER NAME",
            decode(attr.bc1, '_', null, attr.bc1) as "BLOCK CODE 1",
            decode(attr.bc2, '_', null, attr.bc2) as "BLOCK CODE 2",
            nvl(l.prev_amount, 0) as "PRIOR CREDIT LIMIT",
            nvl(l.amount, 0) as "CURRENT CREDIT LIMIT",
            nvl(balance.total_balance, 0) as "CURRENT BALANCE",
-- [+][begin] 211021.2 = Santosh Kumar Singh = ENG-3964
            CASE WHEN nvl(prev_amount,0) = 0 THEN  concat('+',100)||'%'
            ELSE
            replace(concat('+',trunc(((nvl(l.amount, 0)- nvl(l.prev_amount, 0))/nvl(l.prev_amount, 0))*100,3)),'+-','-')||'%' END "INCREASE/DECREASE%"       
-- [+][end] 211021.2 = Santosh Kumar Singh = ENG-3964             
    --from dwd_contract dc
	from contract dc
    join dwd_client cl
    on cl.record_idt        = dc.client_idt
   and cl.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
   and cl.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')   
   join contract_limit l on l.contract_idt = dc.record_idt 
   join prod vdp on dc.product_id = vdp.product_id
    left join (select /*+ use_hash (b ag) full(b) */
                      b.contract_idt, 
                      sum(b.balance) as total_balance
                 from dwf_account_balance b
                 join bal ag on ag.account_group_id = b.account_group_id
                where b.banking_date = to_date(:P_REPORT_DATE,'dd-MM-yyyy')
                group by b.contract_idt) balance on balance.contract_idt = dc.record_idt
    left join (select /*+ no_merge use_hash(dca dc) use_hash(dca da)*/
                              dca.contract_idt,
                              max(case when da.type_code like 'BLOCK_CODE_ACC1_' || dc.orgcd   then da.code else null end) as bc1,
                              max(case when da.type_code like 'BLOCK_CODE_ACC2_' || dc.orgcd   then da.code else null end) as bc2
                        from dwa_contract_attribute dca
                        join dwd_attribute da
                          on da.id               = dca.attr_id
                        join contract dc
                         on dca.contract_idt = dc.record_idt 
                        and da.type_code in( 'BLOCK_CODE_ACC1_' || dc.orgcd , 'BLOCK_CODE_ACC2_' || dc.orgcd )						
					   where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy') 
                         and dca.attr_date_to >= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy') 
                  group by dca.contract_idt
                        ) attr 
              on attr.contract_idt = dc.record_idt