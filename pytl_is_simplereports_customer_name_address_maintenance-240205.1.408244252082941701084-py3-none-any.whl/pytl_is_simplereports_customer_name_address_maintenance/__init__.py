__version__ = "240205.1"
__job_name__ = "PyTL_IS_SimpleReports_CUSTOMER_NAME_ADDRESS_MAINTENANCE"
__bat_files__ = []

