/*
* STANDARD CUSTOMER NAME AND ADDRESS CHANGE REPORT
*
* Version history:
* 210321.1 = Nikita Fomin = ENG-3193: adding NIC_IS_Ou_SimpleReports. Initial development.
* 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
* 211230.3 = Bharath = OPKSAIC-2751 : Generic job NIC and Tiqmo
* 220215.1 = DenisKa = OPKSAIC-3226: fixed the issue with running under users different from OWS.
* 220318.1 = Shalini = ALMB-696: Added multiple fields TITLE,LANGUAGE,SMS_EMAIL,ADD_DATE_01,ID_TYPE,ID_EXPIRY_DATE,EMP_POSITION,PRSNT_ZIP_CODE,PRMNT_ZIP_CODE
* 220321.1 = Shalini = ALMB-696: TITLE,LANGUAGE logic changes
* 220322.1 = Shalini = ALMB-696: ID_TYPE mapping changes
* 221208.1 = Shalini = ALMAS-754 : Mapping correction for EMP_DET_1,EMP_NR,EMP_SALARY fields
* 230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
* 240205.1 = Shalini = AJM-5021  : INCOME field mapping correction , field addition and redundant joins removed
*/

with ins as(
select /*+ NO_MERGE MATERIALIZE */ id,bank_code,name
                      from (select fi.bank_code,
                                   fi.posting_in,
                                   fi.id,
                                   fi2.bank_code bank_code_posting,
                                   fi.name
                            from ows.f_i fi
                                 join ows.f_i fi2 on fi.posting_in = fi2.id
                            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
                            ) inst
                      start with inst.bank_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                                      from dual
                                                      connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
                                                      )
                      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
),
changed_client as(
select /*+ NO_MERGE */
       DISTINCT c.amnd_prev
  from ows.client c
  join ins
    on ins.id=c.f_I
 where c.amnd_date >= trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy'))
   and c.amnd_date < trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy')) + 1
),
change_history as(
select /*+ NO_MERGE */
        c.amnd_prev,
        c.id,
        c.amnd_date  as rec_date_from,
        nvl(
         LAG(c.amnd_date) OVER (PARTITION BY c.amnd_prev ORDER BY c.amnd_date desc),trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy')) + 1
        )            as rec_date_to
  from ows.client c
  join ins
    on ins.id = c.f_I
 where c.amnd_prev in ( select amnd_prev from changed_client )
),
client_maint as (
select diff.bank_code,
       diff.client_number,
       diff.field_description,
       changed_from,
       changed_to,
       to_char(diff.amnd_date,'DD-MM-YYYY') as date_stamp,
       to_char(diff.amnd_date,'HH24:MI:SS') as time_stamp,
       o.user_id as user_name
  from (select *
          from (select ins.bank_code,
                       lp.amnd_date,
                       lp.amnd_state,
                       nvl(client_number,reg_number) as client_number,
                       lp.amnd_officer,
                       lp.f_i as fi,
                       lp.amnd_prev,
                       lp.reg_number as IDENTIFICATIONn,
                       lp.FIRST_NAM as FIRST_NAMn,
                       lp.LAST_NAM as LAST_NAMn,
                       lp.MOTHER_S_NAM as MOTHER_S_NAMn,
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                       lp.BIRTH_NAM as BIRTH_NAMn,
                       lp.BIRTH_PLACE as BIRTH_PLACEn,
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                       to_char(lp.BIRTH_DATE, 'DD/MM/YYYY') as BIRTH_DATEn,
                       lp.GENDER as GENDERn,
                       to_char(lp.MARITAL_STATUS) as MARITAL_STATUSn,
                       lp.COMPANY_NAM as COMPANY_NAMn,
                       lp.CITIZENSHIP as CITIZENSHIPn,
                       lp.ADDRESS_ZIP as ADDRESS_ZIPn,
                       lp.COUNTRY as COUNTRYn, --[+]230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                       lp.STATE as STATEn,
                       lp.CITY as CITYn,
                       lp.ADDRESS_LINE_1 as ADDRESS_LINE_1n,
                       lp.ADDRESS_LINE_2 as ADDRESS_LINE_2n,
                       lp.ADDRESS_LINE_3 as ADDRESS_LINE_3n,
                       lp.ADDRESS_LINE_4 as ADDRESS_LINE_4n, --[+]230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                       lp.PHONE as PHONEn,
                       lp.PHONE_H as PHONE_Hn,
                       to_char(lp.ADD_DATE_02, 'DD/MM/YYYY') as ADD_DATE_02n,
                       lp.AMND_STATE as AMND_STATEn,
                       ows.sy_convert.get_tag_value(lp.add_info_01,'INCOME') as INCOMEn, --[*] 240205.1 = AJM-5021
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                       ows.sy_convert.get_tag_value(lp.add_info_01,'REL_NAME') as REL_NAMEn,
                       ows.sy_convert.get_tag_value(lp.add_info_01,'EMP_DET_1') as EMP_DETn,
                       ows.sy_convert.get_tag_value(lp.add_info_01,'EMP_NR') as EMP_NRn,
                       ows.sy_convert.get_tag_value(lp.add_info_01,'EMP_SALARY') as EMP_SALARYn,
-- [+][begin] 220318.1 = Shalini = ALMB-696: Added multiple fields
-- [+][begin] 220321.1 = Shalini = ALMB-696: Rewritten mappings
                       decode(to_char(lp.LANGUAGE),la.id,la.name,to_char(lp.LANGUAGE)) as LANGUAGEn,
                       decode(to_char(lp.TITLE),sa.id,sa.name,to_char(lp.TITLE)) as TITLEn,
-- [+][end] 220321.1 = Shalini = ALMB-696: Rewritten mappings
                       lp.REG_NUMBER_TYPE as ID_TYPEn, -- [*]220322.1 = Shalini = ALMB-696: Rewritten mappings
                       to_char(lp.ADD_DATE_01) as ID_EXPIRY_DATEn,
                       ows.sy_convert.get_tag_value(lp.add_info_01,'EMP_POSITION') as EMP_POSITIONn,
-- [+][end] 220318.1 = Shalini = ALMB-696: Added multiple fields
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                       lag(lp.reg_number) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as IDENTIFICATIONo,
                       lag(lp.AMND_PREV) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as is_first,
                       lag(ows.sy_convert.get_tag_value(lp.add_info_01,'REL_NAME')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as REL_NAMEo,
                       lag(ows.sy_convert.get_tag_value(lp.add_info_01,'SEC_AMT')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as CHECK_AMOUNTo,
                       lag(ows.sy_convert.get_tag_value(lp.add_info_03,'VISA_NBR')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as VISA_NBRo,
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
-- [*][begin] 221208.1 = ALMAS-754
                       lag(ows.sy_convert.get_tag_value(lp.add_info_01,'EMP_DET_1')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as EMP_DETo,
                       lag(ows.sy_convert.get_tag_value(lp.add_info_01,'EMP_NR')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as   EMP_NRo,
                       lag(ows.sy_convert.get_tag_value(lp.add_info_01,'EMP_SALARY')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as EMP_SALARYo,
-- [*][end] 221208.1 = ALMAS-754
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                       lag(lp.FIRST_NAM) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as FIRST_NAMo,
                       lag(lp.LAST_NAM) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as LAST_NAMo,
                       lag(lp.MOTHER_S_NAM) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as MOTHER_S_NAMo,  /* 20191031.004 */
                       lag(lp.BIRTH_NAM) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as BIRTH_NAMo,
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                       lag(lp.BIRTH_PLACE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as BIRTH_PLACEo,
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                       lag(to_char(lp.BIRTH_DATE, 'DD/MM/YYYY')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as BIRTH_DATEo,
                       lag(lp.GENDER) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as GENDERo,
                       lag(to_char(lp.MARITAL_STATUS)) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as MARITAL_STATUSo,
                       lag(lp.COMPANY_NAM) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as COMPANY_NAMo,
                       lag(lp.CITIZENSHIP) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as CITIZENSHIPo,
                       lag(lp.ADDRESS_ZIP) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as ADDRESS_ZIPo,
                       lag(lp.STATE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as STATEo,
                       lag(lp.CITY) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as CITYo,
                       lag(lp.COUNTRY) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as COUNTRYo,--[+]230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                       lag(lp.ADDRESS_LINE_1) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as ADDRESS_LINE_1o,
                       lag(lp.ADDRESS_LINE_2) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as ADDRESS_LINE_2o,
                       lag(lp.ADDRESS_LINE_3) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as ADDRESS_LINE_3o,
                       lag(lp.ADDRESS_LINE_4) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as ADDRESS_LINE_4o,--[+]230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                       lag(lp.PHONE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as PHONEo,
                       lag(lp.PHONE_H) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as PHONE_Ho,
                       lag(to_char(lp.ADD_DATE_02, 'DD/MM/YYYY')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as ADD_DATE_02o,
-- [+][begin] 220318.1 = Shalini = ALMB-696: Added multiple fields
-- [+][begin] 220321.1 = Shalini = ALMB-696: Rewritten mappings
                       lag(decode(to_char(lp.LANGUAGE),la.id,la.name,to_char(lp.LANGUAGE))) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as LANGUAGEo,
                       lag(decode(to_char(lp.TITLE),sa.id,sa.name,to_char(lp.TITLE))) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as TITLEo,
-- [+][end] 220321.1 = Shalini = ALMB-696: Rewritten mappings
                       lag(lp.REG_NUMBER_TYPE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as ID_TYPEo, -- [*] 220322.1 = Shalini = ALMB-696: Rewritten mappings
                       lag(to_char(lp.ADD_DATE_01)) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as ID_EXPIRY_DATEo,
-- [+][end] 220318.1 = Shalini = ALMB-696: Added multiple fields
                       lag(ows.sy_convert.get_tag_value(lp.add_info_01,'EMP_POSITION')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as EMP_POSITIONo,
                       lag(lp.AMND_STATE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as AMND_STATEo,
                       lag(ows.sy_convert.get_tag_value(lp.add_info_01,'INCOME')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as INCOMEo --[*] 240205.1 = AJM-5021
             from ows.client lp
             join ins
               on ins.id=lp.f_I
             join change_history t
               on t.id = lp.id
              and t.rec_date_to >= trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy'))
-- [-][begin] 240205.1 = Shalini = AJM-5021
--             left join ows.appl_info ai
--                   on t.amnd_prev = ai.client__oid
--                   and (ai.amnd_date >= t.rec_date_from and ai.amnd_date < t.rec_date_to)
-- [-][end] 240205.1 = Shalini = AJM-5021
-- [+][begin] 220321.1 = Shalini = ALMB-696: changes included to fetch language and title name
            join ows.salutation sa
                   on sa.id=lp.title
                   and sa.amnd_state='A'
            join ows.lang la
                   on la.id=lp.language
                   and la.amnd_state='A'
-- [+][end] 220321.1 = Shalini = ALMB-696: changes included to fetch language and title name
          )
        unpivot ((changed_from, changed_to) for
                   field_description in (
                                    (COMPANY_NAMo ,COMPANY_NAMn ) as 'MAKER_EMPLOYER',
                                    (IDENTIFICATIONo, IDENTIFICATIONn) as 'IDENTIFICATION',
                                    (FIRST_NAMo, FIRST_NAMn) as 'NAME_LINE_1',
                                    (LAST_NAMo, LAST_NAMn) as 'NAME_LINE_2',
                                    (MOTHER_S_NAMo, MOTHER_S_NAMn) as 'MOTHER_NAME',
                                    (BIRTH_NAMo, BIRTH_NAMn) as 'BIRTH_NAME',
                                    (BIRTH_PLACEo, BIRTH_PLACEn) as 'BIRTH_PLACE',
                                    (GENDERo, GENDERn) as 'GENDER',
                                    (MARITAL_STATUSo, MARITAL_STATUSn) as 'MARITAL_STATUS',
                                    (BIRTH_DATEo, BIRTH_DATEn) as 'BIRTH_DATE',
                                    (CITIZENSHIPo, CITIZENSHIPn) as 'NATIONALITY',
                                    (ADDRESS_ZIPo, ADDRESS_ZIPn) as 'ADDR_ZIP', --[*]230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                                    (STATEo, STATEn) as 'STATE',
                                    (CITYo, CITYn) as 'CITY',
--[*][begin] 230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                                    (COUNTRYo, COUNTRYn) as 'COUNTRY',        
                                    (ADDRESS_LINE_1o, ADDRESS_LINE_1n) as 'ADDRESS_1',
                                    (ADDRESS_LINE_2o, ADDRESS_LINE_2n) as 'ADDRESS_2',
                                    (ADDRESS_LINE_3o, ADDRESS_LINE_3n) as 'ADDRESS_3',
                                    (ADDRESS_LINE_4o, ADDRESS_LINE_4n) as 'ADDRESS_4',
--[*][end] 230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition                                     
                                    (PHONEo, PHONEn) as 'MAKER_WORK_PHONE',
                                    (PHONE_Ho, PHONE_Hn) as 'MAKER_HOME_PHONE',
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                                    (EMP_DETo, EMP_DETn) as 'EMP_DETAIL1',
                                    (EMP_NRo, EMP_NRn) as 'EMP_NUMBER',
                                    (EMP_SALARYo, EMP_SALARYn) as 'EMP_SALARY',
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
-- [*][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                                    (REL_NAMEo, REL_NAMEn) as 'RELATIVE_NAME',
-- [+][begin] 220318.1 = Shalini = ALMB-696: Added multiple fields
                                    (LANGUAGEo, LANGUAGEn) as 'LANGUAGE',
                                    (TITLEo, TITLEn) as 'TITLE',
                                    (ID_TYPEo, ID_TYPEn) as 'ID_TYPE',
                                    (ID_EXPIRY_DATEo, ID_EXPIRY_DATEn) as 'ID_EXPIRY_DATE',
                                    (EMP_POSITIONo,EMP_POSITIONn) as 'EMP_POSITION'
-- [+][end] 220318.1 = Shalini = ALMB-696: Added multiple fields
                                    , (INCOMEo,INCOMEn) as 'INCOME' --[+] 240205.1 = AJM-5021
                                    ))
-- [*][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
         where AMND_DATE > trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy'))
           and AMND_DATE <= trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy')) + 1
           ) diff
  join ows.officer o on o.id = diff.amnd_officer and o.amnd_state = 'A'
 where (nvl(changed_from, 0) <> nvl(changed_to, 0) or diff.amnd_state = 'C')
   and diff.is_first is not null
),
t as(
select /*+ NO_MERGE */
       DISTINCT ca.amnd_prev
  from ows.client c
  join ins
    on ins.id = c.f_I
  join ows.client_address ca
    on c.id = ca.client__oid
 where ca.AMND_DATE >= trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy'))
   and ca.AMND_DATE < trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy')) + 1
union all
select DISTINCT ca.amnd_prev
  from ows.acnt_contract c
  join ins
    on ins.id = c.f_I
  join ows.client_address ca
    on c.id = ca.acnt_contract__oid
 where ca.AMND_DATE >= trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy'))
   and ca.AMND_DATE < trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy')) + 1
),
addr_change_history as(
select /*+ NO_MERGE */
       a.amnd_prev,
       a.id,
       a.amnd_date  as rec_date_from,
       nvl(
         LAG(a.amnd_date) OVER (PARTITION BY a.amnd_prev ORDER BY a.amnd_date desc),trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy')) + 1
       )            as rec_date_to,
       a.code,
       a.name
  from ows.address_type a
),
addr_maint as
(
    select ins.bank_code,
           decode(diff.client__oid, null, aco.contract_number, nvl(co.client_number, co.reg_number)) as client_number,
           diff.field_description,
           changed_from,
           changed_to,
           to_char(diff.amnd_date,'DD-MM-YYYY') as date_stamp,
           to_char(diff.amnd_date,'HH24:MI:SS') as time_stamp,
           o.user_id as user_name
      from (select *
              from (select
                           lp.amnd_date,
                           lp.amnd_prev,
                           lp.amnd_officer,
                           lp.client__oid,
                           lp.acnt_contract__oid,
                           lp.FIRST_NAM as FIRST_NAMn,
                           lp.LAST_NAM as LAST_NAMn,
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                           lp.URL as URLn,
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                           case when adt.code='WORK' then lp.COUNTRY else null end as COUNTRYn, --[+]230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                           case when adt.code='PERMANENT' then lp.COUNTRY else null end as PRMNT_COUNTRYn,
                           case when adt.code='PRESENT' then lp.COUNTRY else null end as PRSNT_COUNTRYn,
                           case when adt.code='WORK' then lp.ADDRESS_ZIP else null end as ADDRESS_ZIPn,
                           case when adt.code='PERMANENT' then lp.ADDRESS_ZIP else null end as PRMNT_ZIPn,
                           case when adt.code='PRESENT' then lp.ADDRESS_ZIP else null end as PRSNT_ZIPn,
                           case when adt.code='ADD_SMS_1' then lp.ADDRESS_ZIP else null end as SMS_NOn,
                           case when adt.code='WORK' then lp.STATE else null end as STATEn,
                           case when adt.code='PERMANENT' then lp.STATE else null end as PRMNT_STATEn,
                           case when adt.code='PRESENT' then lp.STATE else null end as PRSNT_STATEn,
                           case when adt.code='WORK' then lp.CITY else null end as CITYn,
                           case when adt.code='PERMANENT' then lp.CITY else null end as PRMNT_CITYn,
                           case when adt.code='PRESENT' then lp.CITY else null end as PRSNT_CITYn,
                           case when adt.code='PERMANENT' then lp.LOCATION else null end as PRMNT_LOCATIONn,
                           case when adt.code='PRESENT' then lp.LOCATION else null end as PRSNT_LOCATIONn,
                           case when adt.code='WORK' then lp.ADDRESS_LINE_1 else null end as ADDRESS_LINE_1n,
                           case when adt.code='PERMANENT' then lp.ADDRESS_LINE_1 else null end as PRMNT_BLDG_NAMEn,
                           case when adt.code='PRESENT' then lp.ADDRESS_LINE_1 else null end as PRSNT_BLDG_NAMEn,
                           case when adt.code='WORK' then lp.ADDRESS_LINE_2 else null end as ADDRESS_LINE_2n,
                           case when adt.code='PERMANENT' then lp.ADDRESS_LINE_2 else null end as PRMNT_LNDLRD_NAMEn,
                           case when adt.code='PRESENT' then lp.ADDRESS_LINE_2 else null end as PRSNT_LNDLRD_NAMEn,
                           case when adt.code='WORK' then lp.ADDRESS_LINE_3 else null end as ADDRESS_LINE_3n,
                           case when adt.code='PERMANENT' then lp.ADDRESS_LINE_3 else null end as PRMNT_HOUSE_NUMBERn,
                           case when adt.code='PRESENT' then lp.ADDRESS_LINE_3 else null end as PRSNT_HOUSE_NBRn,
                           case when adt.code='WORK' then lp.ADDRESS_LINE_4 else null end as ADDRESS_LINE_4n,--[+]230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                           case when adt.code='PERMANENT' then lp.ADDRESS_LINE_4 else null end as PRMNT_STREETn,
                           case when adt.code='PRESENT' then lp.ADDRESS_LINE_4 else null end as PRSNT_STREETn,
                           case when adt.code='ADD_SMS_1' then lp.PHONE else null end as PHONEn,
                           case when adt.code='ADD_SMS_1' then lp.PHONE_H else null end as PHONE_Hn,
                           case when adt.code='STMT_ADDR' then lp.E_MAIL else null end as EMAILn,
-- [+][begin] 220318.1 = Shalini = ALMB-696: Added multiple fields
                           case when adt.code='ADD_SMS_1' then lp.E_MAIL else null end as SMS_EMAILn,
                           case when adt.code='WORK' then lp.ZIP_CODE else null end as ZIP_CODEn,
                           case when adt.code='PERMANENT' then lp.ZIP_CODE else null end as PRMNT_ZIP_CODEn,
                           case when adt.code='PRESENT' then lp.ZIP_CODE else null end as PRSNT_ZIP_CODEn,
-- [+][end] 220318.1 = Shalini = ALMB-696: Added multiple fields
                           /*POC1*/
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                           case when adt.code='POC1' then lp.BIRTH_NAM  else null end as     POC1_BIRTH_NAMn,
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                           case when adt.code='POC1' then lp.PHONE     else null end as      POC1_PHONE_Wn,
                           case when adt.code='POC1' then lp.PHONE_M   else null end as      POC1_PHONE_Mn,
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                           case when adt.code='POC1' then lp.PHONE_H   else null end as      POC1_PHONE_Hn,
                           case when adt.code='POC1' then lp.FAX       else null end as      POC1_FAXn,
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                           case when adt.code='POC1' then lp.E_MAIL else null end as         POC1_EMAILn,
                           CASE WHEN adt.code='POC1' THEN lp.ADDRESS_ZIP ELSE NULL END AS    POC1_ZIPn,
                           CASE WHEN adt.code='POC1' THEN lp.COUNTRY ELSE NULL END AS        POC1_COUNTRYn,
                           CASE WHEN adt.code='POC1' THEN lp.STATE ELSE NULL END AS          POC1_STATEn,
                           CASE WHEN adt.code='POC1' THEN lp.CITY ELSE NULL END AS           POC1_CITYn,
                           CASE WHEN adt.code='POC1' THEN lp.ADDRESS_LINE_1 ELSE NULL END AS POC1_ADR_LN1n,
                           CASE WHEN adt.code='POC1' THEN lp.ADDRESS_LINE_2 ELSE NULL END AS POC1_ADR_LN2n,
                           CASE WHEN adt.code='POC1' THEN lp.ADDRESS_LINE_3 ELSE NULL END AS POC1_ADR_LN3n,
                           CASE WHEN adt.code='POC1' THEN ows.sy_convert.get_tag_value(add_info, 'LE_NAME')
                                    ELSE NULL END AS POC1_LE_NAMEn,
                           CASE WHEN adt.code='POC1' THEN ows.sy_convert.get_tag_value(add_info, 'LE_NUMBER')
                                    ELSE NULL END AS POC1_LE_NUMBERn,
                           CASE WHEN adt.code='POC1' THEN ows.sy_convert.get_tag_value(add_info, 'DES')
                                    ELSE NULL END AS POC1_DESn,
                            /*POC2*/
                           case when adt.code='POC2' then lp.PHONE     else null end as      POC2_PHONE_Wn,
                           case when adt.code='POC2' then lp.PHONE_M   else null end as      POC2_PHONE_Mn,
                           case when adt.code='POC2' then lp.E_MAIL else null end as         POC2_EMAILn,
                           CASE WHEN adt.code='POC2' THEN lp.ADDRESS_ZIP ELSE NULL END AS    POC2_ZIPn,
                           CASE WHEN adt.code='POC2' THEN lp.COUNTRY ELSE NULL END AS        POC2_COUNTRYn,
                           CASE WHEN adt.code='POC2' THEN lp.STATE ELSE NULL END AS          POC2_STATEn,
                           CASE WHEN adt.code='POC2' THEN lp.CITY ELSE NULL END AS           POC2_CITYn,
                           CASE WHEN adt.code='POC2' THEN lp.ADDRESS_LINE_1 ELSE NULL END AS POC2_ADR_LN1n,
                           CASE WHEN adt.code='POC2' THEN lp.ADDRESS_LINE_2 ELSE NULL END AS POC2_ADR_LN2n,
                           CASE WHEN adt.code='POC2' THEN lp.ADDRESS_LINE_3 ELSE NULL END AS POC2_ADR_LN3n,
                           CASE WHEN adt.code='POC2' THEN ows.sy_convert.get_tag_value(add_info, 'LE_NAME')
                                    ELSE NULL END AS POC2_LE_NAMEn,
                           CASE WHEN adt.code='POC2' THEN ows.sy_convert.get_tag_value(add_info, 'LE_NUMBER')
                                    ELSE NULL END AS POC2_LE_NUMBERn,
                           CASE WHEN adt.code='POC2' THEN ows.sy_convert.get_tag_value(add_info, 'DES')
                                    ELSE NULL END AS POC2_DESn,

                           lp.AMND_STATE as AMND_STATE,
                           lag(lp.AMND_PREV) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as is_first,
                           lag(lp.FIRST_NAM) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as FIRST_NAMo,
                           lag(lp.LAST_NAM) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as LAST_NAMo,
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                           lag(lp.URL) over(partition by lp.AMND_PREV order by lp.AMND_DATE) as URLo,
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                           case when adt.code='WORK' then lag(lp.COUNTRY) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as COUNTRYo, --[+]230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                           case when adt.code='PERMANENT' then lag(lp.COUNTRY) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRMNT_COUNTRYo,
                           case when adt.code='PRESENT' then lag(lp.COUNTRY) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRSNT_COUNTRYo,
                           case when adt.code='WORK' then lag(lp.ADDRESS_ZIP) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as ADDRESS_ZIPo,
                           case when adt.code='PERMANENT' then lag(lp.ADDRESS_ZIP) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRMNT_ZIPo,
                           case when adt.code='PRESENT' then lag(lp.ADDRESS_ZIP) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRSNT_ZIPo,
                           case when adt.code='ADD_SMS_1' then lag(lp.ADDRESS_ZIP) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as SMS_NOo,
                           case when adt.code='WORK' then lag(lp.STATE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as STATEo,
                           case when adt.code='PERMANENT' then lag(lp.STATE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRMNT_STATEo,
                           case when adt.code='PRESENT' then lag(lp.STATE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRSNT_STATEo,
                           case when adt.code='WORK' then lag(lp.CITY) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as CITYo,
                           case when adt.code='PERMANENT' then lag(lp.CITY) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRMNT_CITYo,
                           case when adt.code='PRESENT' then lag(lp.CITY) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRSNT_CITYo,
                           case when adt.code='PERMANENT' then lag(lp.LOCATION) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRMNT_LOCATIONo,
                           case when adt.code='PRESENT' then lag(lp.LOCATION) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRSNT_LOCATIONo,
                           case when adt.code='WORK' then lag(lp.ADDRESS_LINE_1) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as ADDRESS_LINE_1o,
                           case when adt.code='PERMANENT' then lag(lp.ADDRESS_LINE_1) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRMNT_BLDG_NAMEo,
                           case when adt.code='PRESENT' then lag(lp.ADDRESS_LINE_1) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRSNT_BLDG_NAMEo,
                           case when adt.code='WORK' then lag(lp.ADDRESS_LINE_2) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as ADDRESS_LINE_2o,
                           case when adt.code='PERMANENT' then lag(lp.ADDRESS_LINE_2) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRMNT_LNDLRD_NAMEo,
                           case when adt.code='PRESENT' then lag(lp.ADDRESS_LINE_2) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRSNT_LNDLRD_NAMEo,
                           case when adt.code='WORK' then lag(lp.ADDRESS_LINE_3) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as ADDRESS_LINE_3o,
                           case when adt.code='PERMANENT' then lag(lp.ADDRESS_LINE_3) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRMNT_HOUSE_NUMBERo,
                           case when adt.code='PRESENT' then lag(lp.ADDRESS_LINE_3) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRSNT_HOUSE_NBRo,
                           case when adt.code='WORK' then lag(lp.ADDRESS_LINE_4) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as ADDRESS_LINE_4o,--[+]230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                           case when adt.code='PERMANENT' then lag(lp.ADDRESS_LINE_4) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRMNT_STREETo,
                           case when adt.code='PRESENT' then lag(lp.ADDRESS_LINE_4) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRSNT_STREETo,
                           case when adt.code='ADD_SMS_1' then lag(lp.PHONE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PHONEo,
                           case when adt.code='ADD_SMS_1' then lag(lp.PHONE_H) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PHONE_Ho,
                           case when adt.code='STMT_ADDR' then lag(lp.E_MAIL) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as EMAILo,
-- [+][begin] 220318.1 = Shalini = ALMB-696: Added multiple fields
                           case when adt.code='ADD_SMS_1' then lag(lp.E_MAIL) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as SMS_EMAILo,
                           case when adt.code='WORK' then lag(lp.ZIP_CODE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as ZIP_CODEo,--[+]230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                           case when adt.code='PERMANENT' then lag(lp.ZIP_CODE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRMNT_ZIP_CODEo,
                           case when adt.code='PRESENT' then lag(lp.ZIP_CODE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as PRSNT_ZIP_CODEo,
-- [+][end] 220318.1 = Shalini = ALMB-696: Added multiple fields
                           /*POC1 */
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                           case when adt.code='POC1' then lag(lp.BIRTH_NAM) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_BIRTH_NAMo,
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                           case when adt.code='POC1' then lag(lp.PHONE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_PHONE_Wo,
                           case when adt.code='POC1' then lag(lp.PHONE_M) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_PHONE_Mo,
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                           case when adt.code='POC1' then lag(lp.PHONE_H) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_PHONE_Ho,
                           case when adt.code='POC1' then lag(lp.FAX) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_FAXo,
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                           case when adt.code='POC1' then lag(lp.E_MAIL) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_EMAILo,
                           case when adt.code='POC1' then lag(lp.ADDRESS_ZIP) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_ZIPo,
                           case when adt.code='POC1' then lag(lp.COUNTRY) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_COUNTRYo,
                           case when adt.code='POC1' then lag(lp.STATE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_STATEo,
                           case when adt.code='POC1' then lag(lp.CITY) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_CITYo,
                           case when adt.code='POC1' then lag(lp.ADDRESS_LINE_1) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_ADR_LN1o,
                           case when adt.code='POC1' then lag(lp.ADDRESS_LINE_2) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_ADR_LN2o,
                           case when adt.code='POC1' then lag(lp.ADDRESS_LINE_3) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC1_ADR_LN3o,
                           case when adt.code='POC1' then lag(ows.sy_convert.get_tag_value(add_info, 'LE_NAME')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as     POC1_LE_NAMEo,
                           case when adt.code='POC1' then lag(ows.sy_convert.get_tag_value(add_info, 'LE_NUMBER')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as   POC1_LE_NUMBERo,
                           case when adt.code='POC1' then lag(ows.sy_convert.get_tag_value(add_info, 'DES')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as         POC1_DESo,
                           /*POC2*/
                           case when adt.code='POC2' then lag(lp.PHONE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC2_PHONE_Wo,
                           case when adt.code='POC2' then lag(lp.PHONE_M) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC2_PHONE_Mo,
                           case when adt.code='POC2' then lag(lp.E_MAIL) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC2_EMAILo,
                           case when adt.code='POC2' then lag(lp.ADDRESS_ZIP) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC2_ZIPo,
                           case when adt.code='POC2' then lag(lp.COUNTRY) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC2_COUNTRYo,
                           case when adt.code='POC2' then lag(lp.STATE) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC2_STATEo,
                           case when adt.code='POC2' then lag(lp.CITY) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC2_CITYo,
                           case when adt.code='POC2' then lag(lp.ADDRESS_LINE_1) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC2_ADR_LN1o,
                           case when adt.code='POC2' then lag(lp.ADDRESS_LINE_2) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC2_ADR_LN2o,
                           case when adt.code='POC2' then lag(lp.ADDRESS_LINE_3) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as POC2_ADR_LN3o,
                           case when adt.code='POC2' then lag(ows.sy_convert.get_tag_value(add_info, 'LE_NAME')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as     POC2_LE_NAMEo,
                           case when adt.code='POC2' then lag(ows.sy_convert.get_tag_value(add_info, 'LE_NUMBER')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as   POC2_LE_NUMBERo,
                           case when adt.code='POC2' then lag(ows.sy_convert.get_tag_value(add_info, 'DES')) over(partition by lp.AMND_PREV order by lp.AMND_DATE) else null end as         POC2_DESo

                     from ows.CLIENT_ADDRESS lp
                     join addr_change_history adt on lp.address_type = adt.amnd_prev
                      and (lp.amnd_date >= adt.rec_date_from and lp.amnd_date < adt.rec_date_to)
                     where (lp.AMND_PREV) in (select AMND_PREV from t))
            unpivot ((changed_from, changed_to) for field_description in
                           ((FIRST_NAMo, FIRST_NAMn) as 'NAME_LINE_1',
                            (LAST_NAMo, LAST_NAMn) as 'NAME_LINE_2',
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                            (URLo, URLn) as 'URL',
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                            (PRMNT_COUNTRYo, PRMNT_COUNTRYn) as 'PRMNT_COUNTRY',
                            (PRSNT_COUNTRYo, PRSNT_COUNTRYn) as 'PRSNT_COUNTRY',
                            (COUNTRYo, COUNTRYn) as 'COUNTRY',--[+]230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                            (ADDRESS_ZIPo, ADDRESS_ZIPn) as 'ADDR_ZIP',
                            (PRMNT_ZIPo, PRMNT_ZIPn) as 'PRMNT_ZIP',
                            (PRSNT_ZIPo, PRSNT_ZIPn) as 'PRSNT_ZIP',
                            (SMS_NOo, SMS_NOn) as 'SMS_MOBILE_NO',
                            (STATEo, STATEn) as 'STATE',
                            (PRMNT_STATEo, PRMNT_STATEn) as 'PRMNT_STATE',
                            (PRSNT_STATEo, PRSNT_STATEn) as 'PRSNT_STATE',
                            (CITYo, CITYn) as 'CITY',
                            (PRMNT_CITYo, PRMNT_CITYn) as 'PRMNT_CITY',
                            (PRSNT_CITYo, PRSNT_CITYn) as 'PRSNT_CITY',
                            (PRMNT_LOCATIONo, PRMNT_LOCATIONn) as 'PRMNT_LOCATION',
                            (PRSNT_LOCATIONo, PRSNT_LOCATIONn) as 'PRSNT_LOCATION',
                            (ADDRESS_LINE_1o, ADDRESS_LINE_1n) as 'ADDRESS_1',
                            (PRMNT_BLDG_NAMEo, PRMNT_BLDG_NAMEn) as 'PRMNT_BLDG_NAME',
                            (PRSNT_BLDG_NAMEo, PRSNT_BLDG_NAMEn) as 'PRSNT_BLDG_NAME',
                            (ADDRESS_LINE_2o, ADDRESS_LINE_2n) as 'ADDRESS_2',
                            (PRMNT_LNDLRD_NAMEo, PRMNT_LNDLRD_NAMEn) as 'PRMNT_LNDLRD_NAME',
                            (PRSNT_LNDLRD_NAMEo, PRSNT_LNDLRD_NAMEn) as 'PRSNT_LNDLRD_NAME',
                            (ADDRESS_LINE_3o, ADDRESS_LINE_3n) as 'ADDRESS_3',
                            (PRMNT_HOUSE_NUMBERo, PRMNT_HOUSE_NUMBERn) as 'PRMNT_HOUSE_NUMBER',
                            (PRSNT_HOUSE_NBRo, PRSNT_HOUSE_NBRn) as 'PRSNT_HOUSE_NBR',
                            (ADDRESS_LINE_4o, ADDRESS_LINE_4n) as 'ADDRESS_4',--[+]230815.1 = Santosh = ACBSA-415 : ADDRESS mapping correction and field addition
                            (PRMNT_STREETo, PRMNT_STREETn) as 'PRMNT_STREET',
                            (PRSNT_STREETo, PRSNT_STREETn) as 'PRSNT_STREET',
                            (PHONEo, PHONEn) as 'MAKER_WORK_PHONE',
                            (PHONE_Ho, PHONE_Hn) as 'MAKER_HOME_PHONE',
                            (EMAILo, EMAILn) as 'EMAIL',
-- [+][begin] 220318.1 = Shalini = ALMB-696: Added multiple fields
                            (SMS_EMAILo, SMS_EMAILn) as 'SMS_EMAIL', 
                            (ZIP_CODEo,ZIP_CODEn) as 'ZIP_CODE',
                            (PRMNT_ZIP_CODEo,PRMNT_ZIP_CODEn) as 'PRMNT_ZIP_CODE',
                            (PRSNT_ZIP_CODEo,PRSNT_ZIP_CODEN) as 'PRSNT_ZIP_CODE',
-- [+][end] 220318.1 = Shalini = ALMB-696: Added multiple fields
                            (POC1_BIRTH_NAMo, POC1_BIRTH_NAMn) as 'POC1_BIRTH_NAM',
                            (POC1_PHONE_Wo, POC1_PHONE_Wn) as 'POC1_PHONE_W',
                            (POC1_PHONE_Mo,POC1_PHONE_Mn) as 'POC1_PHONE_M',
-- [+][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                            (POC1_PHONE_Ho,POC1_PHONE_Hn) as 'POC1_PHONE_H',
                            (POC1_FAXo,POC1_FAXn) as 'POC1_FAX',
-- [+][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
-- [*][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                            (POC1_EMAILo,POC1_EMAILn) as 'POC1_EMAIL',
-- [*][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                            (POC1_ZIPo,POC1_ZIPn) as 'POC1_ZIP',
                            (POC1_COUNTRYo,POC1_COUNTRYn) as 'POC1_COUNTRY',
                            (POC1_STATEo,POC1_STATEn) as 'POC1_STATE',
                            (POC1_CITYo,POC1_CITYn) as 'POC1_CITY',
                            (POC1_ADR_LN1o,POC1_ADR_LN1n) as 'POC1_ADR_LN1',
                            (POC1_ADR_LN2o,POC1_ADR_LN2n) as 'POC1_ADR_LN2',
                            (POC1_ADR_LN3o,POC1_ADR_LN3n) as 'POC1_ADR_LN3',
                            (POC1_LE_NAMEo,POC1_LE_NAMEn) as 'POC1_LE_NAME',
                            (POC1_LE_NUMBERo,POC1_LE_NUMBERn) as 'POC1_LE_NUMBER',
                            (POC1_DESo,POC1_DESn) as 'POC1_DES',
                            (POC2_PHONE_Wo, POC2_PHONE_Wn) as 'POC2_PHONE_W',
                            (POC2_PHONE_Mo,POC2_PHONE_Mn) as 'POC2_PHONE_M',
-- [*][begin] 210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                            (POC2_EMAILo,POC2_EMAILn) as 'POC2_EMAIL',
-- [*][end]   210920.2 = Santosh Kumar Singh = ALMAS-384: Added multiple fields like Birth_Place,Contact_URL etc. (ALMAS-384,ALMAS-115,ALMAS-120).
                            (POC2_ZIPo,POC2_ZIPn) as 'POC2_ZIP',
                            (POC2_COUNTRYo,POC2_COUNTRYn) as 'POC2_COUNTRY',
                            (POC2_STATEo,POC2_STATEn) as 'POC2_STATE',
                            (POC2_CITYo,POC2_CITYn) as 'POC1_CITY',
                            (POC2_ADR_LN1o,POC2_ADR_LN1n) as 'POC2_ADR_LN1',
                            (POC2_ADR_LN2o,POC2_ADR_LN2n) as 'POC2_ADR_LN2',
                            (POC2_ADR_LN3o,POC2_ADR_LN3n) as 'POC2_ADR_LN3',
                            (POC2_LE_NAMEo,POC2_LE_NAMEn) as 'POC2_LE_NAME',
                            (POC2_LE_NUMBERo,POC2_LE_NUMBERn) as 'POC2_LE_NUMBER',
                            (POC2_DESo,POC2_DESn) as 'POC2_DES')
                            )
             where AMND_DATE >= trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy'))
               and AMND_DATE < trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy')) + 1
             ) diff
      join ows.officer o
        on o.amnd_state = 'A'
       and o.id = diff.amnd_officer
        left join ows.client co
               on co.id = diff.client__oid
        left join ins on co.f_i = ins.id
        left join ows.acnt_contract aco
               on aco.id = diff.acnt_contract__oid
     where (nvl(changed_from, 0) <> nvl(changed_to, 0) or diff.amnd_state = 'C')
       and is_first is not null
),
tt as (
select /*+ no_merge materialize*/
       DISTINCT c.amnd_prev
  from ows.client c
  join ins
    on ins.id             = c.f_i
 where trunc(c.amnd_date) = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
   and c.id               = c.amnd_prev
   ) ,
new_rec as
   (
        select bank_code,
               t.client_num_new                as client_number,
               'NEW RECORD ADDED'              as field_description,
               null                            as changed_from,
               to_char(t.client_num_new)       as changed_to,
               to_char(t.amnd_date,'DD-MM-YYYY')   as date_stamp,
               to_char(t.amnd_date,'HH24:MI:SS') as time_stamp,
               o.user_id                       as user_name
          from (select ins.bank_code,
                       lp.amnd_date,
                       lp.amnd_state,
                       lp.id,
                       nvl(client_number, reg_number) as client_num_new,
                       amnd_officer as username,
                       lp.f_i as fi,
                       lp.amnd_prev,
                       lag(lp.amnd_prev) over(partition by lp.amnd_prev order by lp.amnd_date) as is_first
                  from ows.client lp
                  join ins
                    on ins.id=lp.f_i
                 where (lp.amnd_prev) in (select amnd_prev from tt)
                 ) t
           join ows.officer o
             on o.id               = t.username
            and o.amnd_state       = 'A'
          where trunc(t.amnd_date) = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
            and is_first is null
            and t.amnd_state       = 'A'
            and exists (select /*+ no_merge */ 1
                          from ows.acnt_contract ac
                         where ac.client__id = t.amnd_prev
                           and ac.amnd_state = 'A')
    )

 SELECT
   bank_code "ORG",
   client_number "CLIENT NUMBER",
   field_description "FIELD",
   changed_from "FROM",
   changed_to "TO",
   date_stamp "DATE",
   time_stamp "TIMESTAMP",
   user_name "OFFICER"
  FROM client_maint
UNION ALL
 SELECT
   bank_code,
   client_number,
   field_description,
   changed_from,
   changed_to,
   date_stamp,
   time_stamp,
   user_name
  FROM addr_maint
union all
 SELECT
   bank_code,
   client_number,
   field_description,
   changed_from,
   changed_to,
   date_stamp,
   time_stamp,
   user_name
  FROM new_rec