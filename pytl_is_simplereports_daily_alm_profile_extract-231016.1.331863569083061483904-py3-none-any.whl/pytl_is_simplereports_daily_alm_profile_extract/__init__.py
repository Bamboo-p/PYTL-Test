__version__ = "231016.1"
__job_name__ = "PyTL_IS_SimpleReports_DAILY_ALM_PROFILE_EXTRACT"
__bat_files__ = []
