__version__ = "231009.1"
__job_name__ = "PyTL_IS_SimpleReports_DAILY_ALM_TRANSACTION_EXTRACT"
__bat_files__ = []
