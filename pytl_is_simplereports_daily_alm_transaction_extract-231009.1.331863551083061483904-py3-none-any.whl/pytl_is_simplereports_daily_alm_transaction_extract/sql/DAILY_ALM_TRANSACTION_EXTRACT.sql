/*
* CODE FOR ALMAS DAILY ALM PHYSICAL CARDS CONVERSION REPORTS
* PyTL_IS_SimpleReports_DAILY_ALM_TRANSACTION_EXTRACT=DAILY_ALM_TRANSACTION_EXTRACT.SQL
* Parameters:
    ORG                = '320'
    P_REPORT_DATE      = 'DD-MM-YYYY' = SYSDATE
* VERSION HISTORY:
* 221114.1 = KOKILA J = ALMAS-1069 : DAILY ALM TRANSACTION EXTRACT
* 231009.1 = KOKILA J = ALMAS-1083 : Space correction in the transaction time
*/
WITH ins AS (
    SELECT      /*+ no_merge materialize */
        code   AS branch_code,
        name   AS bank_name,
        institution_id
    FROM
        dwh.v_dwr_institution
    WHERE
        class_code = 'BASE_REPORTS'
        AND type_code = 'BANK_DESC'
        AND code = :ORG
),
cards AS (
    SELECT
        record_idt   AS card_idt,
        cd.client_idt
    FROM
        dwh.dwd_card cd
        JOIN ins i ON i.institution_id = cd.institution_id
    WHERE
        cd.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
        AND cd.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
)
SELECT
    c.org   AS org,
    lpad(ROWNUM, 6, 0) AS record_number,
    case when length(corp.root_corporate_id)<10 then rpad(nvl(lpad(corp.root_corporate_id,10,0), ' '), 15, ' ') 
	else rpad(nvl(corp.root_corporate_id, ' '), 15, ' ') end AS base_number,
    'CC' AS accrualchannel,
    rpad(nvl(substr(c.primary_pan, 1, 6), 0), 6, 0) AS bin_number,
    rpad(nvl(c.logo, 0), 30, ' ') AS product_code,
    rpad(' ', 20, ' ') AS deal_code,
    rpad(nvl(TO_CHAR(t.trans_date, 'DDMMYYYY'), 0), 8, 0) AS transaction_date,
    rpad(nvl(TO_CHAR(t.trans_date, 'hhmmss'), ' '), 7, ' ') AS transaction_time,
    rpad(nvl(t.trans_arn, ' '), 50, ' ') AS transaction_id,
    rpad(nvl(t.merchant, ' '), 30, ' ') AS merchant_id,
    rpad(nvl(t.trans_mcc, ' '), 30, ' ') AS merchant_category_code,
    rpad(nvl(t.trans_details, ' '), 50, ' ') AS merchant_name,
    rpad(nvl(t.trans_city, ' '), 50, ' ') AS merchant_city,
    rpad(nvl(t.trans_country_code, ' '), 50, ' ') AS merchant_country,
    rpad(' ', 30, ' ') AS terminal_id,
    rpad(nvl(DECODE(direction, '-1', 'DR', '1', 'CR'), ' '), 2, ' ') AS transaction_type,
    rpad(nvl(t.txn_code, ' '), 40, ' ') AS transaction_code,
    TO_CHAR(abs(t.amount), 'fm09999999D00') AS "TRANSACTION_AMOUNT(QR)",
    TO_CHAR(nvl(t.trans_amount, 0), 'fm09999999D00') AS source_amount,
    rpad(nvl(trans_currency, 0), 10, ' ') AS source_currency,
    lpad(' ', 16, ' ') AS national_id,
    lpad(' ', 50, ' ') AS additional_details_1,
    lpad(' ', 50, ' ')||'|'||'~' AS additional_details_2
FROM
    dwh.opt_dm_nice_transaction_info t
    JOIN ins ON ins.branch_code = t.org
                AND t.banking_date = TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
                AND sy_convert.get_tag_value(t.oper_type_add_info, 'TRANS_EXTRACT') = 'Y'
                AND branch_code = t.org
    JOIN cards dc ON dc.card_idt = t.card_idt
    LEFT JOIN dwh.opt_dm_nice_contract_hierarchy corp ON corp.contract_idt = t.contract_idt
	                                              AND corp.banking_date = TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
												  AND corp.org=:ORG
    JOIN dwh.opt_dm_nice_contract_info c ON t.contract_idt = c.record_idt
	                                 AND c.banking_date = TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
									 AND c.org=:ORG
    LEFT JOIN dwh.dwd_currency curr ON curr.code = t.trans_currency
                                   AND curr.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
                                   AND curr.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
                                   AND curr.record_state <> 'C'