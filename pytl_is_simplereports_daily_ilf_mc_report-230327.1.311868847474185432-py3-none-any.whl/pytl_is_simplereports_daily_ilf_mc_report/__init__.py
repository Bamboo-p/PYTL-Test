__version__ = "230327.1"
__job_name__ = "PyTL_IS_SimpleReports_DAILY_ILF_MC_REPORT"
__bat_files__ = []

