__version__ = "230419.1"
__job_name__ = "PyTL_IS_SimpleReports_DAILY_NEW_PROFILE_EXTRACT_REPORT"
__bat_files__ = []

