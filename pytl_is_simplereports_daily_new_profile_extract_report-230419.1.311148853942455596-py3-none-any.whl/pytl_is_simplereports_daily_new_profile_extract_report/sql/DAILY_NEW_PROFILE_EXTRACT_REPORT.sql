/*
* CODE FOR BOS DAILY TRANSACTION EXTRACT REPORT
* PyTL_IS_SimpleReports_DAILY_NEW_PROFILE_EXTRACT_REPORT=DAILY_NEW_PROFILE_EXTRACT_REPORT.SQL
* Parameters:
    :ORGLIST            = '006' or '021,022,023'
    :P_BANK_DATE        = 'DD-MM-YYYY' = SYSDATE
* VERSION HISTORY:
* 221114.1 = KOKILA J = BOS-273: NEW PROFILE EXTRACT CARD INITIAL VERSION
* 221123.1 = KOKILA J = BOS-273: Using only Account id column == 'EXID' instead of 'ICC_LTY_ID'; Added additional filters to acnt_contract to fetch only active card contracts.
* 221206.1 = KOKILA J = BOS-273: Join condition change
* 221207.1 = KOKILA J = BOS-273: Adding acnt_contract to Fetch account level details
* 221208.1 = KOKILA J = BOS-273: Adding Schema name to Function 
* 221209.1 = KOKILA J = BOS-273: Handling null value
* 221214.1 = KOKILA J = BOS-273: Added Account status in where condition
* 221215.1 = KOKILA J = BOS-273: Added Schema name
* 221215.2 = KOKILA J = BOS-273: Added Inactive status in card table
* 221223.1 = KOKILA J = BOS-273: Adding Zeros to the Account id Column
* 230213.1 = KOKILA J = BOS-341: MODIFY customer_account_number and card type
* 230222.1 = KOKILA J = BOS-350: Adding address type condition table
* 230223.1 = KOKILA J = BOS-351: Spliting the client subquery
* 230224.1 = KOKILA J = BOS-352: Removing client table in client subquery
* 230410.1 = KOKILA J = BOS-378: Adding row_number in contract and card_info to get last card or contract number
* 230419.1 = KOKILA J = BOS-378: Changing the client type sorting order
*/
WITH fi_subquery AS (
    SELECT
        id,
        branch_code
    FROM
        ows.f_i
    WHERE
        amnd_state = 'A'
        AND branch_code = :orglist
), clientaddress_subquery AS (
    SELECT
        caddr.e_mail        AS email,                   -- [*] 221206.1 = KOKILA J = BOS-273
        caddr.phone         AS mobile_number,            -- [*] 221207.1 = KOKILA J = BOS-273
        caddr.client__oid   AS client_id
    FROM
        ows.client_address caddr
        JOIN ows.address_type t ON t.amnd_state = 'A'
                                   AND caddr.amnd_state = 'A'
                                   AND caddr.address_type = t.id
                                   AND t.code = 'ADD_SMS_1'
), client_types AS (
    SELECT
        cl.id              AS client_id,
        cl.client_number   AS customer_account_number,   -- [*] 230213.1 = KOKILA J = BOS-341: MODIFY customer_account_number and card type
        cl.citizenship,
        cl.gender,
        TO_CHAR(birth_date, 'DDMMYYYY') AS dob,
        ms.code            AS marital_status,
        DECODE(cty.name, 'Private Resident', 'P', NULL) AS client_type -- [+] 230213.1 = KOKILA J = BOS-341: MODIFY customer_account_number and card type
    FROM
        ows.client cl
        LEFT JOIN ows.client_type cty ON cl.clt = cty.id
                                         AND cty.amnd_state = 'A'
        LEFT JOIN ows.marital_status ms ON ms.id = cl.marital_status
                                           AND ms.amnd_state = 'A'
    WHERE
        cl.amnd_state = 'A'
)
-- [+] End 221223.1 = KOKILA J = BOS-251
, product_subquery AS (
    SELECT
        ap.internal_code,
        lpad(replace(substr(ap.code, instr(ap.code, 'AMF') + 3, 3), '_', ''), 3, 0) AS logo
    FROM
        ows.appl_product ap
        JOIN fi_subquery ON ap.f_i = fi_subquery.id
                            AND ap.amnd_state = 'A'
)
SELECT
    org,
    record_number
    || client_id
    || account_id
    || bin
    || bin_segement
    || customer_account_number
    || substr(card_number, 4, 8)
    || '*****'
    || substr(card_number, 17, 3)
    || alternate_card_number
    || dob
    || embossing_name
    || account_block_code_1
    || account_block_code_2
    || account_status
    || pct
    || credit_limit
    || billing_cycle
    || mobile_number
    || email_id
    || product_code
    || app_user
    || nationality
    || gender
    || loyalty_currency
    || earns_allowed
    || redemption_allowed
    || customer_segment
    || card_type
    || maritual_status
    || filler AS text
FROM
    (
        SELECT
            TO_CHAR(TO_DATE(:p_bank_date, 'DD-MM-YYYY'), 'YYMMDD')
            || lpad(ROWNUM, 8, '0') AS record_number,  -- [*] 221207.1 = KOKILA J = BOS-273
            branch_code   AS client_id,
            branch_code   AS org,
            lpad(0, 20, '0') AS account_id,      -- [*] 221223.1 = KOKILA J = BOS-273
            substr(ac.contract_number, 1, 6) AS bin,             -- [*] 221207.1 = KOKILA J = BOS-273
            substr(ac.contract_number, 7, 2) AS bin_segement,    -- [*] 221207.1 = KOKILA J = BOS-273
            lpad(nvl(customer_account_number, 0), 16, 0) AS customer_account_number,
            lpad(ac.contract_number, 19, 0) AS card_number,
            lpad(' ', 16, ' ') AS alternate_card_number,
            lpad(nvl(dob, ' '), 8, ' ') AS dob,
            lpad(nvl(ci.card_name, ' '), 26, ' ') AS embossing_name,
            ' ' AS account_block_code_1,
            ' ' AS account_block_code_2,
            nvl(substr(ows.opt_util.get_cse_codename(ac.id, 'BFA_ACCOUNT_STATUS'), 1, 1), ' ') AS account_status,     -- [*] 221208.1 = KOKILA J = BOS-273
            '   ' AS pct,
            lpad(acc.shared_blocked, 9, 0) AS credit_limit,       -- [*] 221207.1 = KOKILA J = BOS-273
            TO_CHAR(ac.last_billing_date, 'dd') AS billing_cycle,
            lpad(nvl(mobile_number, ' '), 11, ' ') AS mobile_number,
            lpad(nvl(email, ' '), 40, ' ') AS email_id,
            ap.logo       AS product_code,
            ' ' AS app_user,
            lpad(nvl(citizenship, ' '), 3, ' ') AS nationality,
            lpad(nvl(gender, ' '), 1, ' ') AS gender,
            '   ' AS loyalty_currency,
            'Y' AS earns_allowed,
            'Y' AS redemption_allowed,
            '  ' AS customer_segment,
            nvl(ct.client_type, ' ') AS card_type,   -- [+] 230213.1 = KOKILA J = BOS-341: MODIFY customer_account_number and card type
            lpad(nvl(ct.marital_status, ' '), 2, ' ') AS maritual_status,
            lpad(' ', 40, ' ') AS filler
        FROM
            ows.acnt_contract acc
            JOIN fi_subquery fi ON acc.f_i = fi.id
                                   AND acc.amnd_state = 'A'
            JOIN (
                SELECT
                    ROW_NUMBER() OVER(
                        PARTITION BY acnt_contract__oid
                        ORDER BY
                            id DESC
                    ) AS rns,
                    ac.*
                FROM
                    ows.acnt_contract ac
                WHERE
                    ac.pcat = 'C'
                    AND ac.ccat = 'P'
                    AND ac.con_cat = 'C'
                    AND ac.amnd_state = 'A'
            ) ac ON acc.id = ac.acnt_contract__oid
                    AND rns = 1-- [+] 221207.1 = KOKILA J = BOS-273
                                          
                                          --
                                          -- [+] 221207.1 = KOKILA J = BOS-273
            JOIN (
                SELECT
                    ROW_NUMBER() OVER(
                        PARTITION BY acnt_contract__oid
                        ORDER BY
                            id DESC
                    ) AS rn,
                    acnt_contract__oid,
                    card_name
                FROM
                    ows.card_info
            ) ci ON ci.acnt_contract__oid = ac.id
                    AND ci.rn = 1
            JOIN ows.contr_status cs ON ac.contr_status = cs.id
                                        AND cs.amnd_state = 'A'
            LEFT JOIN clientaddress_subquery cl ON cl.client_id = ac.client__id  -- [*] 221206.1 = KOKILA J = BOS-273
            JOIN product_subquery ap ON ap.internal_code = acc.product      -- [*] 221207.1 = KOKILA J = BOS-273
            LEFT JOIN client_types ct ON ct.client_id = ac.client__id       --[+] 221223.1 = KOKILA J = BOS-251
        WHERE
            ( substr(ows.opt_util.get_cse_codename(ac.id, 'BFA_ACCOUNT_STATUS'), 1, 1) NOT IN (
                '8',
                '9'
            )
              OR acc.id IN (
                SELECT
                    ac.id
                FROM
                    ows.acnt_contract ac   -- [*] 221215.1 = KOKILA J = BOS-273
                WHERE
                    ac.amnd_state = 'A'
                    AND ( substr(ows.opt_util.get_cse_codename(ac.id, 'BFA_ACCOUNT_STATUS'), 1, 1) IN (
                        '8'
                    )
                          AND ows.acnt_api.str_date(ows.sy_convert.get_tag_value(ac.ext_data, 'ACTIVITY_DATE')) = TO_DATE(:p_bank_date
                          , 'DD-MM-YYYY') )
            ) )
        ORDER BY
            ct.client_type ASC  
    )