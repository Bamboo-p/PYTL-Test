__version__ = "230426.1"
__job_name__ = "PyTL_IS_SimpleReports_DAILY_TRANSACTION_EXTRACT_REPORT"
__bat_files__ = []

