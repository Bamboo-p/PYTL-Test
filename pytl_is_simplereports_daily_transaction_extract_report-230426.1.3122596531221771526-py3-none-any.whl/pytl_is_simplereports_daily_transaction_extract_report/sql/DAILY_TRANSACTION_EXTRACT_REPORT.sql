/*
* CODE FOR BOS DAILY TRANSACTION EXTRACT REPORT
* PyTL_IS_SimpleReports_DAILY_TRANSACTION_EXTRACT_REPORT=PyTL_IS_SimpleReports_DAILY_TRANSACTION_EXTRACT_REPORT.SQL
* Parameters:
    :ORGLIST            = '006' or '021,022,023'
    :P_BANK_DATE        = 'DD-MM-YYYY' = SYSDATE
* VERSION HISTORY:
* 221027.1 = KOKILA J = BOS-274: SMS INSTANT CARD INITIAL VERSION
* 221109.1 = KOKILA J = BOS-274: Adding sy_handbook in query
* 221124.1 = KOKILA J = BOS-274: deal_code is replaced with '     ', according updating requirements from BA in specification
* 221209.1 = KOKILA J = BOS-274: Customer account number removing substr
* 230118.1 = KOKILA J = BOS-335: Change in the transaction sign column
* 230213.1 = KOKILA J = BOS-342: Changing the customer_account_number Column 
* 230410.1 = KOKILA J = BOS-375: fetching card number from the doc table
* 230426.1 = KOKILA J = BOS-309: Mapping change transaction amount column
*/WITH fi_subquery AS (
    SELECT
        id,
        branch_code
    FROM
        ows.f_i
    WHERE
        amnd_state = 'A'
        AND branch_code = :orglist
), transcode_subquery AS (
    SELECT
        code
    FROM
        ows.sy_handbook
    WHERE
        name = 'BOS'
        AND filter = 'TXN_EXTRACT'
), client_subquery AS (
    SELECT
	   -- cl.reg_number    AS customer_account_number,   -- [-] 221209.1 = KOKILA J = BOS-342: Changing the customer_account_number Column 
        cl.client_number   AS customer_account_number,  -- [*] 221209.1 = KOKILA J = BOS-342: Changing the customer_account_number Column 
        cl.id              AS client_id
    FROM
        ows.client cl
        JOIN fi_subquery ON cl.f_i = fi_subquery.id
                            AND cl.amnd_state = 'A'
), product_subquery AS (
    SELECT
        ap.internal_code,
        lpad(replace(substr(ap.code, instr(ap.code, 'AMF') + 3, 3), '_', ''), 3, 0) AS logo
    FROM
        ows.appl_product ap
        JOIN fi_subquery ON ap.f_i = fi_subquery.id
                            AND ap.amnd_state = 'A'
)
SELECT
    org,
    record_number
    || client_id
    || bin
    || bin_segement
    || customer_account_number
    || substr(card_number, 4, 8)
    || '*****'
    || substr(card_number, 17, 3)
    || trans_date
    || trans_time
    || acq_id
    || merchant_id
    || merchant_category_code
    || merchant_name
    || merchant_city
    || merchnat_country
    || terminal_id
    || transaction_sign
    || transaction_id
    || transaction_amount
    || source_amount
    || source_curr
    || deal_code
    || transaction_code
    || transaction_type
    || product_code
    || tokenization
    || wallet_id
    || filler AS text
FROM
    (
        SELECT
            TO_CHAR(TO_DATE(:p_bank_date, 'DD-MM-YYYY'), 'DDMMYY')
            || lpad(ROWNUM, 8, '0') AS record_number,
            branch_code   AS client_id,
            branch_code   AS org,
            substr(ac.contract_number, 4, 6) AS bin,
            substr(ac.contract_number, 10, 2) AS bin_segement,
            lpad(nvl(customer_account_number, 0), 16, 0) AS customer_account_number,
            lpad(d.target_number, 19, 0) AS card_number,                      -- [*] 230118.1 = KOKILA J = BOS-375
            lpad(nvl(TO_CHAR(d.trans_date, 'ddmmyy'), '0'), 6, '0') AS trans_date,
            lpad(nvl(TO_CHAR(d.trans_date, 'hh24miss'), '0'), 8, '0') AS trans_time,
            lpad(' ', 15, ' ') AS acq_id,
            lpad(nvl(d.merchant_id, 0), 15, 0) AS merchant_id,
            lpad(nvl(d.sic_code, '0'), 4, '0') AS merchant_category_code,
            rpad(substr(nvl(otd.description, ' '), 0, 23), 23, ' ') AS merchant_name,
            rpad(substr(nvl(d.trans_city, ' '), 0, 14), 14, ' ') AS merchant_city,
            rpad(substr(nvl(d.trans_country, ' '), 0, 3), 3, ' ') AS merchnat_country,
            lpad(nvl(substr(source_number, 1, 16), 0), 16, 0) AS terminal_id,
            CASE
                WHEN m.direction = 1
                     AND m.local_amount < 0 THEN                                                                      -- [*] 230118.1 = KOKILA J = BOS-335
                      'D'
                WHEN m.direction = - 1
                     AND m.local_amount > 0 THEN                                                                      -- [*] 230118.1 = KOKILA J = BOS-335
                      'D'
                WHEN m.direction = - 1
                     AND m.local_amount < 0 THEN                                                                      -- [*] 230118.1 = KOKILA J = BOS-335
                      'C'
                WHEN m.direction = 1
                     AND m.local_amount > 0 THEN                                                                      -- [*] 230118.1 = KOKILA J = BOS-335
                      'C'
            END AS transaction_sign,
            lpad(coalesce(ret_ref_number, acq_ref_number, source_reg_num, '0'), 23, '0') AS transaction_id,
            lpad(abs(e.amount), 18, 0) AS transaction_amount,
            lpad(nvl(CASE
                WHEN d.settl_amount <> d.trans_amount THEN d.trans_amount
            END, 0), 18, 0) AS source_amount,
            lpad(nvl((
                SELECT
                    name
                FROM
                    ows.currency c
                WHERE
                    c.amnd_state = 'A'
                    AND c.code =(CASE
                        WHEN d.trans_amount <> d.settl_amount THEN d.trans_curr
                    END)
            ), ' '), 3, ' ') AS source_curr,
            '     ' AS deal_code, -- [*] 221124.1 = KOKILA J = BOS-274
            lpad(nvl(otd.txn_code, '0'), 4, '0') AS transaction_code,
            ' ' AS transaction_type,
            ap.logo       AS product_code,
            ' ' AS tokenization,
            '          ' AS wallet_id,
            lpad(' ', 55, ' ') AS filler
        FROM
            ows.opt_trans_dump otd
            JOIN ows.acnt_contract ac ON ac.id = otd.acnt_contract__oid
                                         AND ac.amnd_state = 'A'
                                         AND otd.post_date = TO_DATE(:p_bank_date, 'DD-MM-YYYY')
            JOIN transcode_subquery txn ON otd.txn_code = txn.code
            JOIN fi_subquery fi ON ac.f_i = fi.id
            JOIN client_subquery cl ON cl.client_id = ac.client__id
            JOIN product_subquery ap ON ap.internal_code = ac.product
            JOIN ows.entry e ON e.id = otd.entry__oid
            JOIN ows.m_transaction m ON m.id = e.m_transaction__id        -- [*] 230118.1 = KOKILA J = BOS-335
            JOIN ows.doc d ON d.id = e.doc_id
            JOIN ows.trans_type tt ON d.trans_type = tt.id
    )