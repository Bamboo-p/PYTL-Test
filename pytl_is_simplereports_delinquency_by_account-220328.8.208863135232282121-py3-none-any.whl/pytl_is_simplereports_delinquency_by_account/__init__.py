__version__ = "220328.8"
__job_name__ = "PyTL_IS_SimpleReports_DELINQUENCY_BY_ACCOUNT"
__bat_files__ = []

