/*
* Code to get totals for all delinquent accounts
*
* Version history:
* 210928.1 = Shalini = ALMAS-119: adding to NIC_IS_Ou_SimpleReports. Initial development
* 211019.2 = Shalini = ALMAS-504,ALMAS-133: Deliquency greater than and equals to 1 is extracted to report,CORP_PROD tag included
*/
with account_groups as
(select /*+ no_merge materialize */
        account_group_id, 
        case when type_code like 'OVD%' and to_number(substr(type_code, -2)) > 7 then 'OVD_08' else type_code end as type_code
   from v_dwr_account_group
  where class_code = 'BALANCE_TYPE' 
    and (type_code like 'OVD%' or type_code in ('TOTAL_BALANCE','TOTAL_DUE','DUE'))),
institutions as 
(select /*+ no_merge materialize */
        institution_id, code, name
   from v_dwr_institution
  where class_code = 'BASE_REPORTS' 
  and type_code = 'BANK_DESC' and code = :ORG),
products as
 (select /*+ no_merge materialize */
        p.product_id, p.code, p.name, substr(p.code, 1, 3) || ' ' || ltrim(p.product_name,'0') as logo
		,p.add_info -- [+] 211019.2 = Shalini = ALMAS-133 
   from v_dwr_product p
   join institutions i
     on i.code       = substr(p.code,5,3)
  where p.class_code = 'BASE_REPORTS' 
    and p.type_code  = 'LOGO'),
part_1 as 
(select /*+ no_merge materialize ordered*/
        c.record_idt,
		da.code
    from dwd_contract c
    join institutions i
	  on i.institution_id = c.institution_id
    join products p
      on c.product_id = p.product_id
	 and nvl(sy_convert.get_tag_value(p.add_info,'CORP_PROD'),'N')='Y' --[+]211019.2 = shalini = ALMAS-133
	/* --[-]begin 211019.2 = shalini = ALMAS-133
    join opt_v_suppl_group ag
      on nvl(instr(ag.name,substr(p.code,1,3)),0) > 0
     and ag.type_code = i.code||'_CORP_PRODUCT_CAT'
	--[-]end 211019.2 = shalini = ALMAS-133 */
	join dwa_contract_attribute dca 
      on c.record_idt = dca.contract_idt
    join dwd_attribute da
      on dca.attr_id  = da.id 
     and da.type_code = 'NIC_BILLING_LEVEL'
	 and da.record_state = 'A'
   where dca.attr_date_from <= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
     and dca.attr_date_to   >= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
     and c.record_date_from <= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
     and c.record_date_to   >= to_date(:P_REPORT_DATE,'dd-MM-yyyy'))
     ,
part_2 as
(select roots.record_idt as billing_acct from 
   (select distinct c.record_idt,
                    level as rn,
                    connect_by_root(c.record_idt) as root_record
		   From dwd_contract c
		   join institutions i
			 on i.institution_id    = c.institution_id
	  left join part_1 b
			 on c.record_idt        = b.record_idt
		    and c.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
		    and c.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
	 start with c.record_idt          = b.record_idt 
	 connect by c.parent_contract_idt = prior c.record_idt) roots
     join part_1 childs
       on roots.root_record = childs.record_idt
      and roots.rn          = childs.code),
contracts_full as
(select /*+ no_merge materialize ordered*/
        c.record_idt,
		c.client_short_name,
		c.base_currency,
		c.personal_account,
		c.product_id,
        c.institution_id
    from dwd_contract c
    join institutions i
	  on i.institution_id = c.institution_id
    join products p
      on c.product_id = p.product_id
	and nvl(sy_convert.get_tag_value(p.add_info,'CORP_PROD'),'N')='N' --[+]211019.2 = shalini = ALMAS-133
	/* --[-]begin 211019.2 = shalini = ALMAS-133
    join opt_v_suppl_group ag
      on nvl(instr(ag.name,substr(p.code,1,3)),0) = 0
     and ag.type_code = i.code||'_CORP_PRODUCT_CAT'
	 --[-]end 211019.2 = shalini = ALMAS-133 */
   where c.record_date_from <= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
     and c.record_date_to   >= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
union
 select /*+ no_merge materialize index(c dwd_contract_idt_idx) use_nl(cc)*/
        c.record_idt,
		c.client_short_name,
		c.base_currency,
		c.personal_account,
		c.product_id,
        c.institution_id
    from dwd_contract c
    join institutions i
	  on i.institution_id = c.institution_id
    join part_2 cc
	  on cc.billing_acct = c.record_idt
   where c.record_date_from <= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
     and c.record_date_to   >= to_date(:P_REPORT_DATE,'dd-MM-yyyy')),
     atr as
(select /*+ no_merge materialize */
	   max(case when da.type_code = 'DLQ_LEVEL'            then da.code else null end) as dl,
	   max(case when da.type_code = 'BFA_ACCOUNT_STATUS'   then da.code else null end) as ac,
	   max(case when da.type_code like 'BLOCK_CODE_ACC1_%' then da.code else null end) as bc1,
	   max(case when da.type_code like 'BLOCK_CODE_ACC2_%' then da.code else null end) as bc2
  from dwd_attribute da
 where record_state    = 'A' 
   and used_as_default = 'Y'
   and type_code in ('BLOCK_CODE_ACC1_'||:ORG, 'BLOCK_CODE_ACC2_'||:ORG,'DLQ_LEVEL','BFA_ACCOUNT_STATUS')
    ),
operation_types as
(select /*+ no_merge materialize */
        operation_type_id, type_code, code
   from v_dwr_operation_type
  where class_code = 'LAST_ACTIVITY_MARTS'
    and type_code = 'LAST_OPER_LTD'
    and code = 'PAYMENT')
select /*+ use_hash (b contracts) */
      -- substr(contracts.logo,1,3)                                                       as logo,     /*if needed use this field*/
	  -- substr(contracts.logo,5)                                                         as logo_name,/*if needed use this field*/
	   contracts.fi																	    as "ORG",
       contracts.personal_account                                                       as "ACCOUNT NUMBER",
       contracts.client_short_name												        as "SHORT NAME",                                                         
       decode(nvl(contracts.b1 ,a.bc1),'_',' ',nvl(contracts.b1,a.bc1))            	    as "BLOCK CODE 1",
       decode(nvl(contracts.b2 ,a.bc2),'_',' ',nvl(contracts.b2,a.bc2))            	    as "BLOCK CODE 2",
       contracts.cycle_due                                                              as "DELINQUENCY LEVEL",
       nvl(contracts.activity_status,a.ac)                                              as "ACCOUNT STATUS",
       to_char(contracts.billing_date,'dd-mm-yyyy')                                     as "STATEMENT DATE",
       to_char(contracts.last_payment_date,'dd-mm-yyyy')                                as "LAST PAYMENT DATE",
       to_char(nvl(b.current_balance,'0'),'FM999999990.90')                             as "CURRENT BALANCE",
       to_char(nvl(b.due,'0'),'FM999999990.90')                                         as "CURRENT AMOUNT DUE",
       to_char(nvl(contracts.last_payment_amount,'0'),'FM999999990.90')                 as "LAST PAYMENT AMOUNT",
       to_char(nvl(b.ovd_01,'0'),'FM999999990.90')                                      as "X-DAYS",
       to_char(nvl(b.ovd_02,'0'),'FM999999990.90')                                      as "30-DAYS",
       to_char(nvl(b.ovd_03,'0'),'FM999999990.90')                                      as "60-DAYS",
       to_char(nvl(b.ovd_04,'0'),'FM999999990.90')                                      as "90-DAYS",
       to_char(nvl(b.ovd_05,'0'),'FM999999990.90')                                      as "120-DAYSM",
       to_char(nvl(b.ovd_06,'0'),'FM999999990.90')                                      as "150-DAYSM",
       to_char(nvl(b.ovd_07,'0'),'FM999999990.90')                                      as "180-DAYSM",
	   (case when to_number(contracts.cycle_due) >= 9 then 
	   to_char(b.ovd_08,'FM999999990.90') else '0.00' end)         					    as "210-DAYS",
	   to_char(nvl(b.total_due,'0'),'FM999999990.90')									as "TOTAL DUE"
 		 
  from (select /*+ ordered no_merge use_hash(b inst) use_hash(b c) */
               contract_idt,
               sum(case when ag.type_code = 'TOTAL_BALANCE' then b.balance else 0 end) as current_balance,
               sum(case when ag.type_code = 'TOTAL_DUE' then b.balance else 0 end) as total_due,
               sum(case when ag.type_code = 'DUE' then b.balance else 0 end) as due,
               sum(case when ag.type_code = 'OVD_01' then b.balance else 0 end) as ovd_01,
               sum(case when ag.type_code = 'OVD_02' then b.balance else 0 end) as ovd_02,
               sum(case when ag.type_code = 'OVD_03' then b.balance else 0 end) as ovd_03,
               sum(case when ag.type_code = 'OVD_04' then b.balance else 0 end) as ovd_04,
               sum(case when ag.type_code = 'OVD_05' then b.balance else 0 end) as ovd_05,
               sum(case when ag.type_code = 'OVD_06' then b.balance else 0 end) as ovd_06,
               sum(case when ag.type_code = 'OVD_07' then b.balance else 0 end) as ovd_07,
               sum(case when ag.type_code = 'OVD_08' then b.balance else 0 end) as ovd_08
          from dwf_account_balance b
          join institutions inst
            on inst.institution_id = b.institution_id
		  join contracts_full c
		    on c.record_idt = b.contract_idt
          join account_groups ag
            on ag.account_group_id = b.account_group_id
         where banking_date = to_date(:P_REPORT_DATE,'dd-MM-yyyy')
      group by b.contract_idt) b
  join (select /*+ no_merge */
               c.client_short_name,
               i.code as fi,
               c.personal_account,
               p.logo,
			   decisions.activity_status,
			   decisions.cycle_due,
               decode(decisions.block_code_acc1, '_', null, decisions.block_code_acc1) as b1,
               decode(decisions.block_code_acc2, '_', null, decisions.block_code_acc2) as b2,
               c.product_id,
               dcb.billing_date,
               last_payment_date,
               last_payment_amount,
               c.record_idt
          from contracts_full c
          join institutions i
            on i.institution_id = c.institution_id
          join products p
            on p.product_id = c.product_id
          join dwf_contract_billing dcb
            on dcb.contract_idt = c.record_idt
           and dcb.billing_date >= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
           and dcb.period_start_date <= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
	  left join (select contract_idt,
						max(case when value_code = 'PAYMENT' then operation_date end) as last_payment_date,
						max(case when value_code = 'PAYMENT' then amount end) as last_payment_amount
				   from (select nvl(entry.contract_idt, l.contract_idt) as contract_idt,
								nvl(entry.type_code, l.type_code) as type_code,
								nvl(entry.code, l.value_code) as value_code,
								nvl(entry.operation_date, l.operation_date) as operation_date,
								nvl(entry.amount, l.amount) as amount
						 from (select l.contract_idt,
									  l.type_code,
									  l.value_code,
									  l.primary_doc_idt,
									  max(l.operation_date) as operation_date,
									  sum(l.amount) as amount
								 from dwm_last_operation l      
								 join dwd_institution inst
								   on inst.id = l.institution_id
								  and inst.branch_code = :ORG
								  and inst.record_state = 'A'
								where l.banking_date = add_months(last_day(to_date(:P_REPORT_DATE,'dd-MM-yyyy')),-1)
								  and l.type_code = 'LAST_OPER_LTD'
								  and l.value_code = 'PAYMENT'
							 group by l.contract_idt, l.type_code, l.value_code, l.primary_doc_idt) l
			  full outer join (select e.contract_idt,
									  max(e.credit-e.debit) keep (dense_rank first order by banking_date, primary_entry_idt desc) as amount,
									  max(e.banking_date) as operation_date,
									  op.type_code,
									  op.code
								 from dwf_account_entry e
								 join dwd_institution inst
								   on inst.id = e.institution_id
								  and inst.branch_code = :ORG
								  and inst.record_state = 'A'
								 join operation_types op
								   on op.operation_type_id = e.operation_type_id
								where e.banking_date >  add_months(last_day(to_date(:P_REPORT_DATE,'dd-MM-yyyy')),-1)
								  and e.banking_date <= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
							 group by e.contract_idt, op.type_code, op.code) entry
						   on entry.contract_idt = l.contract_idt
						  and entry.type_code    = l.type_code
						  and entry.code         = l.value_code)
			   group by contract_idt) ldate 
		 on c.record_idt = ldate.contract_idt
		
	  left join (select /*+ no_merge use_hash(dca da)*/
					   dca.contract_idt,
					   max(case when da.type_code like 'BLOCK_CODE_ACC1_%' then da.code else null end) as block_code_acc1,
					   max(case when da.type_code like 'BLOCK_CODE_ACC2_%' then da.code else null end) as block_code_acc2,
					   max(case when da.type_code = 'BFA_ACCOUNT_STATUS'   then da.code else null end) as activity_status,
					   max(case when da.type_code = 'DLQ_LEVEL'			   then da.code else null end) as cycle_due					   
				  from dwa_contract_attribute dca
				  join dwd_attribute da
					on da.id               = dca.attr_id
				   and da.record_state     = 'A'
				   and da.type_code       in ('BLOCK_CODE_ACC1_'||:ORG,'BLOCK_CODE_ACC2_'||:ORG,'BFA_ACCOUNT_STATUS','DLQ_LEVEL')				      
				 where dca.attr_date_from <= to_date(:P_REPORT_DATE,'dd-MM-yyyy') 
				   and dca.attr_date_to   >= to_date(:P_REPORT_DATE,'dd-MM-yyyy') 
			  group by dca.contract_idt) decisions
		 on decisions.contract_idt = c.record_idt 
         
           ) contracts
     on b.contract_idt = contracts.record_idt
     join(Select * from atr)a
           on 1=1
		 
    where b.total_due <> 0
	  and nvl(to_number(contracts.cycle_due),0) >= 1 --[*]211019.2 = shalini = ALMAS-504
 order by fi, logo, cycle_due