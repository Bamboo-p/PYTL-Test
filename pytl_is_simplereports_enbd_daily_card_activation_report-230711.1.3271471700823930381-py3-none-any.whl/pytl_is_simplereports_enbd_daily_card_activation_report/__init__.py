__version__ = "230711.1"
__job_name__ = "PyTL_IS_SimpleReports_ENBD_DAILY_CARD_ACTIVATION_REPORT"
__bat_files__ = []
