/*
* CODE FOR ENBD DAILY CARD ACTIVATION REPORT
* PyTL_IS_SimpleReports_ENBD_DAILY_CARD_ACTIVATION_REPORT=ENBD_DAILY_CARD_ACTIVATION_REPORT.SQL
* Parameters:
*           :ORG              = '033'
*           :P_REPORT_DATE    = 'DD-MM-YYYY'
*
* Version history:
* 221116.1 = RakeshG = ECCBAU-6075:Initial Version
* 221122.1 = RakeshG = ECCBAU-6164:Duplicate issue fixed, Mapping changes for TF_ATM,TF_ECOM,TF_POS,TF_TOKEN
* 230110.1 = RakeshG = ECCBAU-6210:Instant issuance phase 2, updated Mapping for TEMPORARY_LIMIT,DIGITAL_CARD and PHYSICAL_CARD
* 230711.1 = RakeshG = ECCBAU-6418:Mapping changes for PERMANENT Credit limit and temporary limit
*/

with cards_subquery1 as (  --[*] 221122.1 = ECCBAU-6164 RakeshG
SELECT /*+ materialize*/
       dce.card_idt      AS card_idt,
       dce.activate_date AS activation_date,
       sy_convert.get_tag_value(c.add_info, 'SRC_CHANNEL') as SRC_CHANNEL,
       row_number() over (partition by card_idt order by dce.activate_date desc) as rn, --[+] 221122.1 = ECCBAU-6164 RakeshG
       c.*
  FROM DWF_CARD_EVENT dce
  join DWD_INSTITUTION i  on i.record_State = 'A' and i.branch_code = :ORG
  JOIN DWD_EVENT_TYPE det on det.code = 'UNLOCK_PLASTIC'
                         and det.record_state = 'A'
  join DWD_CARD c on c.record_idt = dce.card_idt
   and c.record_Date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
   and c.record_DatE_to >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
   and c.record_State <> 'C'
 where dce.event_type_id = det.id
   and dce.institution_id = i.record_idt
   and dce.activate_date = to_date(:P_REPORT_DATE,'DD-MM-YYYY')
)
--[+] begin 221122.1 = ECCBAU-6164 RakeshG
,cards_subquery as (
select * from cards_subquery1 where rn = 1
)
--[+] end 221122.1 = ECCBAU-6164 RakeshG
,trans_flag_subquery as (
--[-] begin 221122.1 = ECCBAU-6164 RakeshG
/* select t.card_idt,
       max(case when substr(det.code,8,3) = 'ATM'   then substr(det.code,12,1) end ) as ATM_TXN,
       max(case when substr(det.code,8,3) = 'POS'   then substr(det.code,12,1) end ) as POS_TXN,
       max(case when substr(det.code,8,4) = 'ECOM'  then substr(det.code,13,1) end ) as ECOM_TXN,
       max(case when substr(det.code,8,5) = 'TOKEN' then substr(det.code,14,1) end ) as TOKEN_TXN
  from cards_subquery t
  join DWF_CARD_EVENT dce on t.card_idt = dce.card_idt
   and not instr(dce.details,'STATUS=Z;')>0
  join DWD_EVENT_TYPE det on det.group_code = 'TRANS_FLAG'
   and det.record_state = 'A'
  group by t.card_idt */
--[-] end 221122.1 = ECCBAU-6164 RakeshG
--[+] begin 221122.1 = ECCBAU-6164 RakeshG
select t.card_idt,
       max(case when t.type_code = 'TF_ATM' then t.code else null end) as ATM_TXN,
       max(case when t.type_code = 'TF_POS' then t.code else null end) as POS_TXN,
       max(case when t.type_code = 'TF_ECOM' then t.code else null end) as ECOM_TXN,
       max(case when t.type_code = 'TF_TOKEN' then t.code else null end) as TOKEN_TXN,
       max(case when t.type_code = 'VIRTUAL_CARD' then t.code else null end) as VIRTUAL_CARD             --[*] 230110.1 = ECCBAU-6210 RakeshG
from (select /*+ no_merge */
             a.id attr_id,
             a.code,
             a.type_code,
             da.card_idt,
             attr_date_from,
             attr_date_to,
             da.details
        from cards_subquery c
        join dwa_card_attribute da on da.card_idt = c.card_idt
        join dwd_attribute a on da.attr_id = a.id
         and (to_date(:P_REPORT_DATE,'DD-MM-YYYY') between da.attr_date_from and da.attr_date_to)
         and da.active_state != 'C'
         and a.type_code in ('TF_ATM','TF_POS','TF_ECOM','TF_TOKEN','VIRTUAL_CARD')) t group by card_idt --[*] 230110.1 = ECCBAU-6210 RakeshG
--[+] end 221122.1 = ECCBAU-6164 RakeshG
)
,attr_subquery as (
select /*+ materialize*/
        id, type_code,
        code
  from DWD_ATTRIBUTE da
 where da.record_state = 'A'
   and da.record_source = 'W4CS_DECISION'
   and da.dimension_code in ('DWD_CONTRACT','DWD_CARD')
   and (da.type_code like 'BLOCK_CODE_%'||:ORG)
)
,contr_attr_subquery as (
select /*+ materialize*/
       dca.contract_idt,
       dca.attr_date_from,
       dca.attr_date_to,
       da.type_code,
       da.code,
       lag(da.code) over (partition by dca.contract_idt, da.type_code order by dca.attr_date_from, dca.attr_date_to asc) as prev_code,
       lag(dca.attr_date_from) over (partition by dca.contract_idt, da.type_code order by dca.attr_date_from, dca.attr_date_to asc) as prev_Date_from
  from cards_subquery t
  join DWA_CONTRACT_ATTRIBUTE dca on dca.contract_idt = t.main_contract_idt
  join attr_subquery da on da.id = dca.attr_id
)
,contr_block_code_subquery as(
select /*+ materialize*/
       contract_idt
      ,max(case when dca.attr_date_to = to_date('01012100', 'DDMMYYYY') and type_code like 'BLOCK_CODE_ACC1_%' then dca.code else null end) as BC1
      ,max(case when dca.attr_date_to = to_date('01012100', 'DDMMYYYY') and type_code like 'BLOCK_CODE_ACC1_%' then dca.attr_date_from else null end) as BC1_date
      ,max(case when dca.attr_date_to = to_date('01012100', 'DDMMYYYY') and type_code like 'BLOCK_CODE_ACC2_%' then dca.code else null end) as BC2
      ,max(case when dca.attr_date_to = to_date('01012100', 'DDMMYYYY') and type_code like 'BLOCK_CODE_ACC2_%' then dca.attr_date_from else null end) as BC2_date
      ,max(case when dca.attr_date_to = to_date('01012100', 'DDMMYYYY') and type_code like 'BLOCK_CODE_ACC1_%' then dca.prev_code else null end) as prev_BC1
      ,max(case when dca.attr_date_to = to_date('01012100', 'DDMMYYYY') and type_code like 'BLOCK_CODE_ACC1_%' then dca.prev_Date_from else null end) as prev_BC1_date
      ,max(case when dca.attr_date_to = to_date('01012100', 'DDMMYYYY') and type_code like 'BLOCK_CODE_ACC2_%' then dca.prev_code else null end) as prev_BC2
      ,max(case when dca.attr_date_to = to_date('01012100', 'DDMMYYYY') and type_code like 'BLOCK_CODE_ACC2_%' then dca.prev_Date_from else null end) as prev_BC2_date
  from contr_attr_subquery dca
 group by dca.contract_idt
)
,crd_attr_subquery as (
select /*+ materialize*/
       dca.card_idt,
       dca.attr_date_from,
       dca.attr_date_to,
       da.type_code,
       da.code,
       lag(da.code) over (partition by dca.card_idt, da.type_code order by dca.attr_date_from, dca.attr_date_to asc) as prev_code,
       lag(dca.attr_date_from) over (partition by dca.card_idt, da.type_code order by dca.attr_date_from, dca.attr_date_to asc) as prev_Date_from
  from cards_subquery t
  join DWA_CARD_ATTRIBUTE dca on dca.card_idt = t.card_idt
  join attr_subquery da on da.id = dca.attr_id
)
,crd_block_code_subquery as (
select dca.card_idt
      ,max(case when dca.attr_date_to = to_date('01012100','DDMMYYYY') and type_code like 'BLOCK_CODE_CARD_%' then dca.code else null end) as BC
      ,max(case when dca.attr_date_to = to_date('01012100','DDMMYYYY') and type_code like 'BLOCK_CODE_CARD_%' then dca.attr_date_from else null end) as BC_date
      ,max(case when dca.attr_date_to = to_date('01012100','DDMMYYYY') and type_code like 'BLOCK_CODE_CARD_%' then dca.prev_code else null end) as prev_BC
      ,max(case when dca.attr_date_to = to_date('01012100','DDMMYYYY') and type_code like 'BLOCK_CODE_CARD_%' then dca.prev_Date_from else null end) as prev_BC_date
  from crd_attr_subquery dca
 group by dca.card_idt
)
--[-] Begin 230711.1 = ECCBAU-6418 RakeshG
--[+] Begin 230110.1 = ECCBAU-6210 RakeshG
--,Temp_cr_limit_subquery as (
--select /*+ no_merge */
--       t.card_idt,
--       nvl(decode(instr(dce.details, 'AMOUNT'), null, null, 0, null, substr(regexp_substr(dce.details, 'AMOUNT[^;]+'), 8)),0)/100 as temp_cr_limit
--  from cards_subquery t
--  join DWF_Contract_EVENT dce on t.main_contract_idt = dce.contract_idt
--  join DWD_EVENT_TYPE det on dce.event_type_id = det.id and det.code = 'CR_LIMIT_UPDATE'
--   and det.record_state = 'A'
--   and dce.activate_date = t.opening_Date                 --[*] 230711.1 = ECCBAU-6418 RakeshG
--)
--[+] end 230110.1 = ECCBAU-6210 RakeshG
--[-] end 230711.1 = ECCBAU-6418 RakeshG
--[+] Begin 230711.1 = ECCBAU-6418 RakeshG
,Perm_cr_limit_subquery as (
select /*+ no_merge ordered use_nl(l)*/
       cs.card_idt,
       l.contract_idt,
       l.full_amount as cr_limit,
       decode(l.prev_full_amount,0,null,l.prev_full_amount) as full_cr_limit,
       row_number() over(partition by cs.card_idt,l.contract_idt order by l.creation_date desc,l.cr_history_idt desc) as rn
from cards_subquery cs
join trans_flag_subquery t on t.card_idt = cs.card_idt
 and t.VIRTUAL_CARD in ('Y','F')
join dwf_credit_limit l on cs.main_contract_idt = l.contract_idt
 and l.action_type = 'FIN_LIMIT'
 and l.banking_Date = cs.opening_date
)
--[+] end 230711.1 = ECCBAU-6418 RakeshG
   select info.BANK_CODE                                                               as ORG,
          t.pan                                                                        as CARD_NUMBER,
          info.contract_number                                                         as ACCOUNT_NUMBER,
          info.client_number                                                           as CUSTOMER_NUMBER,
          NVL(trim(SUBSTR(t.embossed_first_name||' '||t.embossed_last_name,1,26)),' ') as EMBOSSING_NAME,
--          info.credit_limit                                                            as FULL_CREDIT_LIMIT,        --[-] 230711.1 = ECCBAU-6418 RakeshG
          NVL(DECODE(stf.virtual_card,'Y',p.full_cr_limit,'F',p.full_cr_limit),info.credit_limit)as FULL_CREDIT_LIMIT,          --[+] 230711.1 = ECCBAU-6418 RakeshG
--          temp.temp_cr_limit                                                           as TEMPORARY_LIMIT,          --[*] 230110.1 = ECCBAU-6210 RakeshG
          Case when stf.virtual_card in ('Y','F') and p.full_cr_limit is not null 
               then info.credit_limit 
          else 0 end                                                                   as TEMPORARY_LIMIT,            --[+] 230711.1 = ECCBAU-6418 RakeshG
          info.CLIENT_REG_NUMBER                                                       as CIF,
          DECODE(t.main_card_flag,'Y','Primary','N','Supplementary')                   as CARD_TYPE,
          td.ATTR_VALUE                                                                as REFERENCE_NUMBER,
          info.PRODUCT_NAME                                                            as PRODUCT_TYPE,
          cbc.bc1                                                                      as BLOCK_CODE1,
          cbc.bc1_date                                                                 as BLOCK_CODE1_DATE,
          cbc.prev_bc1                                                                 as PREV_BLOCK_CODE1,
          cbc.prev_bc1_date                                                            as PREV_BLOCK_CODE1_DATE,
          cbc.bc2                                                                      as BLOCK_CODE2,
          cbc.bc2_date                                                                 as BLOCK_CODE2_DATE,
          cbc.prev_bc2                                                                 as PREV_BLOCK_CODE2,
          cbc.prev_bc2_date                                                            as PREV_BLOCK_CODE2_DATE,
          scbc.bc                                                                      as CARD_BLOCK_CODE,
          scbc.bc_date                                                                 as CARD_BLOCK_CODE_DATE,
          scbc.prev_bc                                                                 as PREV_CARD_BLOCK_CODE,
          scbc.prev_bc_date                                                            as PREV_CARD_BLOCK_CODE_DATE,
          t.SRC_CHANNEL                                                                as SOURCE_CHANNEL,
          DECODE(stf.virtual_card,'Y','Y','F','Y','N')                                 as DIGITAL_CARD,               --[*] 230110.1 = ECCBAU-6210 RakeshG
          DECODE(stf.virtual_card,'Y','N','F','N','Y')                                 as PHYSICAL_CARD,              --[*] 230110.1 = ECCBAU-6210 RakeshG
--[*] begin 221122.1 = ECCBAU-6164 RakeshG
          nvl(stf.TOKEN_TXN,'N')                                                       as TOKENIZED_TXNS,
          nvl(stf.ECOM_TXN,'N')                                                        as ECOM_TXNS,
          nvl(stf.POS_TXN,'N')                                                         as POS_TXNS,
          nvl(stf.ATM_TXN,'N')                                                         as ATM_TXNS
--[*] end 221122.1 = ECCBAU-6164 RakeshG
     from cards_subquery t
     join OPT_DM_CONTRACT_INFO info on info.contract_idt = t.main_contract_idt and info.BANK_CODE = :ORG
left join Perm_cr_limit_subquery p on p.card_idt = t.card_idt and p.rn = 1                                            --[+] 230711.1 = ECCBAU-6418 RakeshG
left join OPT_DM_TD_AUTH_SCHEME td on td.contract_idt = t.card_idt and td.org = info.org and td.code = 'REF_NUMBER'
left join contr_block_code_subquery cbc on cbc.contract_idt = t.main_contract_idt
left join crd_block_code_subquery scbc on scbc.card_idt = t.card_idt
left join trans_flag_subquery stf on stf.card_idt = t.card_idt
--left join Temp_cr_limit_subquery temp on temp.card_idt = t.card_idt                                                 --[-] 230711.1 = ECCBAU-6418 RakeshG