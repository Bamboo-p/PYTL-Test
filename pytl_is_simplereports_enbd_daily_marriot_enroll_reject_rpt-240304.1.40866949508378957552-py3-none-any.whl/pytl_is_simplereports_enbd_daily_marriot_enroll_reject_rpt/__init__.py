__version__ = "240304.1"
__job_name__ = "PyTL_IS_SimpleReports_ENBD_DAILY_MARRIOT_ENROLL_REJECT_RPT"
__bat_files__ = []
