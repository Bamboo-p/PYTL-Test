/*
* CODE FOR ENBD_DAILY_MARRIOT_ENROLL_REJECT_RPT
* PyTL_IS_SimpleReports_ENBD_DAILY_MARRIOT_ENROLL_REJECT_RPT=ENBD_DAILY_MARRIOT_ENROLL_REJECT_RPT.sql
* Parameters:
*           :ORG          = '100'
*           :P_REPORT_DATE  = 'DD-MM-YYYY'
*           :P_SPGCODE_LIST = 'J,Y,B,L' This filter is used for the Different type of SPG_FLAG classifier code to be considered.
*
* Version history:
* 231112.1 = RakeshG = ENBD-25168:Initial Version
* 240304.1 = MohannadG = ENBD-26369 : Added middle name column
*/

WITH sq_spg_list AS (
       SELECT /*+ no_merge materialize*/
              TRIM(regexp_substr(:P_SPGCODE_LIST, '[^,]+', 1, level)) SPGCODE
         FROM dual
   CONNECT BY regexp_substr(:P_SPGCODE_LIST, '[^,]+', 1, level) IS NOT NULL
)
, sq_rej_cntr AS (
       SELECT /*+ no_merge materialize */
              attr.*
         FROM opt_dm_contract_attribute attr
         JOIN sq_spg_list spg on spg.spgcode = attr.spg_flag
        WHERE attr.spg_flag_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
          AND attr.org = :ORG
)
, sq_rej_resn AS (
       SELECT 
	          rc.contract_idt,
			  regexp_substr(details,'INPUT=RC_(.*?)(;|$)',1,1, NULL, 1) as rej_reason,
			  da.name
		 FROM sq_rej_cntr rc
		 JOIN dwa_contract_attribute ca ON ca.contract_idt = rc.contract_idt
          AND ca.attr_date_from = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
		 JOIN dwd_attribute da ON da.id = ca.attr_id
		  AND da.record_state = 'A'
		  AND da.type_code = 'SPG_FLAG'
		 JOIN sq_spg_list spg on spg.spgcode = da.code
)
, sq_cntr  AS (
       SELECT /*+ no_merge materialize */
              info.org,
              info.contract_idt,
              info.logo                AS product_code,
              info.contract_number     AS account_number,
              info.primary_card_number AS card_number,
              info.client_reg_number   AS cif,
              info.client_first_name,
              info.client_middle_name, --240304.1
              info.client_last_name,
              info.client_idt,
              rc.spg_flag,
              regexp_replace(a.STMT_ADDR_LINE_1,'[^[:alnum:][:space:],]','') as Permanent_building_name,
              a.STMT_CITY,
              a.E_MAIL
         FROM opt_dm_contract_info info
         JOIN sq_rej_cntr rc ON rc.contract_idt = info.contract_idt
          AND info.org = rc.org
         JOIN opt_dm_client_address a on info.client_idt = a.client_idt
)
, sq_card  AS (
       SELECT /*+ no_merge materialize */
              cc.record_idt AS card_idt,
              cc.opening_date,
              cc.effective_date,
              cc.pan,
              rc.contract_idt
         FROM sq_rej_cntr rc
         JOIN dwd_card cc ON cc.main_contract_idt = rc.contract_idt
          AND cc.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
          AND cc.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
          AND cc.main_card_flag = 'Y'
)
, sq_attr  AS (
       SELECT /*+ no_merge materialize */
              card_idt,
              contract_idt,
              trim(BOTH ' ' from ref_num) as ref_number,
              trim(BOTH ' ' from spg_num) as spg_number,
              ROW_NUMBER() OVER (PARTITION BY contract_idt ORDER BY opening_date desc,effective_date desc) as rn
         FROM (
       SELECT sc.card_idt,
              sc.opening_date,
              sc.effective_date,
              sc.pan,
              sc.contract_idt,
              MAX(CASE WHEN td.code = 'REF_NUMBER' THEN td.attr_value ELSE NULL END) AS ref_num,
              MAX(CASE WHEN td.code = 'SPG' THEN td.attr_value ELSE NULL END) AS spg_num
         FROM sq_card sc
         JOIN opt_dm_td_auth_scheme td ON td.contract_idt = sc.card_idt
          AND td.code IN ('REF_NUMBER','SPG')
          AND td.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
     GROUP BY sc.card_idt,sc.opening_date,sc.effective_date,sc.pan,sc.contract_idt)
)
       SELECT /*+ no_merge materialize */
              c.org,
			  c.product_code AS product_code,
              c.account_number,
              c.card_number,
              c.cif,
              a.ref_number,
              c.client_first_name,
              c.client_middle_name, --240304.1
              c.client_last_name,
              c.permanent_building_name,
              c.stmt_city,
              c.e_mail,
              r.name AS ISSUANCE_FLAG_STATUS,
              a.spg_number AS MARRIOTT_NUMBER,
			  substr(r.rej_reason,1,nvl(instr(r.rej_reason,':'),1)-1) AS RESPONSE_CODE,
			  nvl(substr(r.rej_reason,nvl(instr(r.rej_reason,':'),0)+1),'Exceptional case - Refer Way4 classifier') AS RESPONSE_STATUS
         FROM sq_cntr c
         JOIN sq_attr a ON a.contract_idt = c.contract_idt
          AND a.rn = 1
		 JOIN sq_rej_resn r on r.contracT_idt = c.contracT_idt