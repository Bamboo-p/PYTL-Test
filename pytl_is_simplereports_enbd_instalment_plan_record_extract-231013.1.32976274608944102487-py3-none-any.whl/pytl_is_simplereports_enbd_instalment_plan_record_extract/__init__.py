__version__ = "231013.1"
__job_name__ = "PyTL_IS_SimpleReports_ENBD_INSTALMENT_PLAN_RECORD_EXTRACT"
__bat_files__ = []

