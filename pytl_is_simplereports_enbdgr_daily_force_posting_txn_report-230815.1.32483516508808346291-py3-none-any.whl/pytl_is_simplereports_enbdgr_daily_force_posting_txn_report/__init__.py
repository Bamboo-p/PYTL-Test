__version__ = "230815.1"
__job_name__ = "PyTL_IS_SimpleReports_ENBDGR_DAILY_FORCE_POSTING_TXN_REPORT"
__bat_files__ = []
