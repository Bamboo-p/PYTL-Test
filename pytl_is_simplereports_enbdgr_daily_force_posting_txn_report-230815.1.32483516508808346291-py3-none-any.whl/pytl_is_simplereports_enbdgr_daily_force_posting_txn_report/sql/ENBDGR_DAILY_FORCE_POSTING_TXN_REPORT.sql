/*
* CODE FOR ENBDGR DAILY FORCE POSTING TXN REPORT
* PyTL_IS_SimpleReports_ENBDGR_DAILY_FORCE_POSTING_TXN_REPORT=ENBDGR_DAILY_FORCE_POSTING_TXN_REPORT.sql
* Parameters:
*           :ORG              = '100'
*           :P_REPORT_DATE    = 'DD-MM-YYYY'
*
* Version history:
* 230713.1 = RakeshG = ENBD-24717:Initial Version
* 230815.1 = RakeshG = ENBD-24944:Added ORG and BANK_CODE and default underscore for block codes, removed buf limit in condition
*/

WITH oper_types AS (
     SELECT /*+  materialize*/
            operation_type_id
       FROM v_dwr_operation_type
      WHERE class_code = :ORG || '_TXN_CODE'
        AND type_code = 'TXN_CODE'
        AND instr(add_info,'FORCE_POST_RPT=Y;') > 0
)
, trans AS (
     SELECT /*+ no_merge use_nl(op) nlj_prefetch(odt, 10000) */
            odt.*
       FROM opt_dm_transaction odt
       JOIN oper_types op ON op.operation_type_id = odt.operation_type_id
      WHERE odt.org = :ORG
        AND odt.banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
)
, decision AS (
     SELECT /*+ no_merge */
            contract_idt,
            nvl(MAX(CASE WHEN decision_code = 'BLOCK_CODE_ACC1' THEN decision_result END), '_') AS block_code_acc1,
            nvl(MAX(CASE WHEN decision_code = 'BLOCK_CODE_ACC2' THEN decision_result END), '_') AS block_code_acc2
       FROM opt_dm_contract_decision
      WHERE org = :ORG
        AND banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND decision_code in ('BLOCK_CODE_ACC1','BLOCK_CODE_ACC2')
   GROUP BY contract_idt
)
   SELECT /*+ ordered parallel(4) full(dci) use_hash(dci odt) use_hash(dci bal) use_hash(dci attr) use_hash(odt occd) */
          dci.org                                                             AS ORG,
          dci.bank_code                                                       AS BANK_CODE,           --[+] 230815.1 = RakeshG = ENBD-24944:Added ORG and BANK_CODE
          dci.contract_number                                                 AS account_number,
          to_char(dci.contract_date_open, 'dd/mm/yyyy')                       AS ac_open_date,
          nvl(dcd.block_code_acc1,'_')                                        AS ac_block_1,          --[+] 230815.1 = RakeshG = ENBD-24944:Default _
          nvl(dcd.block_code_acc2,'_')                                        AS ac_block_2,
          attr.activity_status                                                AS activity_status,
          credit_limit + ( ( credit_limit * ovl_threshold ) / 100 )           AS ac_cred_lim_buf_lim,
          dci.credit_limit                                                    AS ac_cred_lim,
          bal.total_balance                                                   AS ac_current_balance,
          dci.amount_available                                                AS ac_otb,
          to_char(odt.posting_date, 'mm/dd/yyyy')                             AS gl_date,
          to_char(odt.trans_date, 'mm/dd/yyyy hh:mm')                         AS trans_date,
          dci.primary_card_number                                             AS contract_for,
          occd.DECISION_RESULT                                                AS card_block_code,
          dtt.name                                                            AS plan_details,
          decode(dtt.request_category, 'P', 'Advice', 'R', 'Reversal',
                 'Q', 'Request', 'J', 'Adjustment', 'A',
                 'Part Advice')                                               AS request_cat,
          dci.base_currency                                                   AS currency,
          to_char(odt.amount, '99,99,99,999.99')                              AS amount,
          dtt.name                                                            AS trans_type,
          odt.trans_details                                                   AS gl_description,
          odt.trans_currency                                                  AS trans_curr,
          to_char(odt.trans_amount, '99,99,99,999.99')                        AS tran_amount,
          odt.settl_currency                                                  AS settl_curr,
          to_char(odt.settl_amount, '99,99,99,999.99')                        AS settl_amount,
          odt.trans_country_code                                              AS country,
          odt.trans_city                                                      AS city,
          odt.trans_details                                                   AS trans_details,
          odt.auth_code                                                       AS auth_code,
          odt.trans_rrn                                                       AS ret_ref_number,
          odt.trans_arn                                                       AS acq_ref_number,
          odt.trans_srn                                                       AS source_reg_num,
          nvl(sy_convert.get_tag_value(odt.add_info, 'LTY_BASE_AMOUNT'), '0') AS loyalty_amount,
          sy_convert.get_tag_value(odt.add_info, 'LTY_PGM')                   AS loyalty_program,
          CASE WHEN tr.trans_response_code IN ( '101', '95' )
               THEN 'Force posted'
          ELSE 'Normal' END                                                   AS force_posted

     FROM opt_dm_contract_info dci

     JOIN trans odt ON odt.contract_idt = dci.contract_idt

LEFT JOIN opt_dm_contract_balance bal ON bal.contract_idt = dci.contract_idt
      AND bal.org = :ORG
      AND bal.banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')

LEFT JOIN dwf_transaction tr ON tr.doc_idt = odt.doc_idt
      AND tr.institution_id = dci.posting_institution_id
      AND tr.banking_date   = odt.banking_date

LEFT JOIN opt_dm_contract_attribute attr ON attr.contract_idt = dci.contract_idt
      AND attr.org = :ORG
      AND attr.banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')

LEFT JOIN decision dcd ON dci.contract_idt = dcd.contract_idt

LEFT JOIN dwd_transaction_type dtt ON dtt.id = odt.transaction_type_id
      AND dtt.record_state = 'A'

LEFT JOIN opt_dm_card_decision occd on occd.card_idt = odt.card_idt
      AND occd.decision_code = 'BLOCK_CODE_CARD'
      AND occd.org = :ORG
      and occd.banking_Date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')

    WHERE ((bal.total_balance * (- 1) > dci.credit_limit)                                --[*] 230815.1 = RakeshG = ENBD-24944: removed buf limit
       OR (dcd.block_code_acc1 IN ('D', 'U', 'X') OR dcd.block_code_acc2 IN ('D', 'U', 'X')))
      AND tr.trans_response_code IN ('101','95')
      AND dci.org = :ORG
      AND dci.banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')