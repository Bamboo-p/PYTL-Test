/*
* CODE FOR ENBDGR DAILY HVR CREDIT EXTRACT
* PyTL_IS_SimpleReports_ENBDGR_DAILY_HVR_CREDIT_EXTRACT=ENBDGR_DAILY_HVR_CREDIT_EXTRACT.sql
* Parameters:
*           :ORGLIST              = '100,017'
*           :P_BANK_DATE          = 'DD-MM-YYYY'
*           :P_MSG_NAME           = 'Transaction Rejected due to Settlement amount above threshold;'
*
* Version history:
* 230724.1 = RakeshG = ENBD-24810:Initial Version
* 230731.1 = RakeshG = ENBD-24890:Added schema name for the tables, so that can be run using other users
* 230802.1 = RakeshG = ENBD-24904:Currency name instead of numberical code
*/

WITH inst as(
select /*+ NO_MERGE MATERIALIZE */
       id institution_id,bank_code code,name,bank_code_posting
                      from (select fi.bank_code,
                                   fi.posting_in,
                                   fi.id,
                                   fi2.bank_code bank_code_posting,
                                   fi.name
                            from ows.f_i fi
                                 join ows.f_i fi2 on fi.posting_in = fi2.id
                            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
                            ) inst
                      start with inst.bank_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                                      from dual
                                                      connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
                      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
)
,proc_mes AS (
    SELECT /*+ NO_MERGE MATERIALIZE */
           pm.doc__id,
           pm.message_name,
           row_number() over(partition by doc__id order by message_date desc) as rn
      FROM ows.process_mess pm
     WHERE pm.message_name = :P_MSG_NAME
       AND pm.message_date >= TO_DATE(:P_BANK_DATE, 'DD-MM-YYYY')
       AND pm.message_date < trunc(TO_DATE(:P_BANK_DATE, 'DD-MM-YYYY')) + 1
       AND pm.object_type  = 'DOC'
       AND pm.message_type = 'E'
)
    SELECT
           inst.bank_code_posting                 AS ORG,
           inst.code                              AS BANK_CODE,
           d.target_number                        AS CARD_NUMBER,
           ows.xwdoc('TRANS_TYPE', d.trans_type)  AS TXN_TYPE,
           d.trans_date                           AS TXN_DATE,
           d.settl_amount                         AS SETTL_AMOUNT,
           scurr.name                             AS SETTL_CURR,              --[*] 230802.1 = RakeshG = ENBD-24904:Currency name instead of numberical code
           d.trans_amount                         AS TRANS_AMOUNT,
           tcurr.name                             AS TRANS_CURR,              --[*] 230802.1 = RakeshG = ENBD-24904:Currency name instead of numberical code
           d.auth_code                            AS AUTH_CODE,
           d.acq_ref_number                       AS ARN,
           d.trans_details                        AS MERCHANT_NAME,
           d.trans_city                           AS MERCHANT_CITY,
           d.trans_country                        AS MERCHANT_COUNTRY,
           d.merchant_id                          AS MERCHANT_ID,
           d.sic_code                             AS MCC,
           pm.message_name                        AS REJECT_REASON

      FROM proc_mes pm

      JOIN ows.doc d ON d.id = pm.doc__id
       AND d.amnd_state = 'A'
       AND pm.rn = 1

      JOIN ows.acnt_contract ac ON d.target_number = ac.contract_number
       AND ac.amnd_state = 'A'

      JOIN inst ON ac.f_i = inst.institution_id

--[+] BEGIN 230802.1 = RakeshG = ENBD-24904:Currency name instead of numberical code

 LEFT JOIN ows.currency tcurr on tcurr.code = d.trans_curr
       AND tcurr.amnd_state = 'A'

 LEFT JOIN ows.currency scurr on scurr.code = d.settl_curr
       AND scurr.amnd_state = 'A'

--[+] END 230802.1 = RakeshG = ENBD-24904:Currency name instead of numberical code