/*
* CODE FOR ENBDGR DAILY HVR POSTPONE TXN REPORT
* PyTL_IS_SimpleReports_ENBDGR_DAILY_HVR_POSTPONE_TXN_RPT=ENBDGR_DAILY_HVR_POSTPONE_TXN_RPT.sql
* Parameters:
*           :ORGLIST              = '100,017'
*           :P_REPORT_DATE        = 'DD-MM-YYYY'
*           :P_TRANS_TYPE         = 'Credit'
* Version history:
* 230811.1 = RakeshG = ENBD-24773:Initial Version
* 230811.2 = RakeshG = ENBD-24773:Amnd date changes done,similar to HVR POSTPONE SUMMARY REPORT
*/

WITH inst AS (
    SELECT /*+ NO_MERGE MATERIALIZE */
        id        institution_id,
        bank_code code,
        name,
        bank_code_posting
    FROM
        (
            SELECT
                fi.bank_code,
                fi.posting_in,
                fi.id,
                fi2.bank_code bank_code_posting,
                fi.name
            FROM
                     ows.f_i fi
                JOIN ows.f_i fi2 ON fi.posting_in = fi2.id
            WHERE
                    fi.amnd_state = 'A'
                AND fi2.amnd_state = 'A'
        ) inst
    START WITH
        inst.bank_code IN (
            SELECT
                TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY decode(inst.posting_in, inst.id, NULL, inst.posting_in) = PRIOR inst.id
               AND level <= 2
)
--[+] begin 230811.2 = RakeshG = ENBD-24773
,ddate as (
select /*+ materialize */
       min(calendar_date) as from_Date,
       max(calendar_date) as rep_Date
  from ows.mp_consist_point
  where local_date in (to_date(:P_REPORT_DATE,'DD-MM-YYYY'),to_date(:P_REPORT_DATE,'DD-MM-YYYY')-1)
    and mp_consist_type__oid = (select min(id) from ows.mp_consist_type where code = 'END_DAY')
    )
--[+] end 230811.2 = RakeshG = ENBD-24773
SELECT
    inst.bank_code_posting                                                              AS org,
    inst.code                                                                           AS branch_code,
    substr(ows.opt_util.PRODUCT_CODE(acnt.product),9,3)                                 AS logo,
    ows.opt_util.PRODUCT_NAME(acnt.product)                                             AS product_name,
    cs.prefix                                                                           AS bin_number,
    acnt.contract_number                                                                AS account_number,
    acnt.shared_blocked                                                                 AS credit_limit,
    ows.opt_util.contract_decision_value_code(acnt.id, 'BLOCK_CODE_ACC1_' || inst.code) AS account_block_code_1,
    ows.opt_util.contract_decision_value_code(acnt.id, 'BLOCK_CODE_ACC2_' || inst.code) AS account_block_code_2,
    ows.opt_util.contract_decision_value_code(c.id, 'BLOCK_CODE_CARD_' || inst.code)    AS card_level_block_code,
    c.contract_number                                                                   AS card_number,
    to_char(d.posting_date, 'DDMMYYYY')                                                 AS effective_date,
    to_char(d.trans_date, 'DDMMYYYY')                                                   AS trans_date,
    tt.name                                                                             AS trans_type,
    'C'                                                                                 AS direction,
    d.trans_amount                                                                      AS total_amount,
    d.auth_code                                                                         AS auth_code,
    d.sic_code                                                                          AS mcc,
    d.merchant_id                                                                       AS merchant_id,
    d.ret_ref_number                                                                    AS rrn,
    d.trans_details                                                                     AS trans_details,
    d.trans_country                                                                     AS trans_country,
    mc.name                                                                             AS trans_channel,
    tcur.name                                                                           AS trans_currency,
    d.settl_amount                                                                      AS original_amount,
    scur.name                                                                           AS original_currency,
    d.acq_ref_number                                                                    AS arn,
    ows.xwdoc('RETURN_CODE', d.return_code)                                             AS reject_reason
FROM
         ows.doc d
	JOIN ddate dd on d.amnd_date between dd.from_Date and dd.rep_Date       --[+] 230811.2 = RakeshG = ENBD-24773
    JOIN ows.acnt_contract c ON c.contract_number = d.target_number
                            AND c.amnd_state = 'A'
                            AND c.is_ready <> 'C'
                            AND c.pcat = 'C'
                            AND c.con_cat = 'C'
    JOIN inst ON inst.institution_id = c.f_i
    JOIN ows.contr_subtype cs ON cs.id = c.contr_subtype__id
                             AND cs.amnd_state = 'A'
    JOIN ows.trans_type tt ON tt.id = d.trans_type
                             AND tt.name = :P_TRANS_TYPE
    JOIN ows.acnt_contract acnt ON acnt.id = c.acnt_contract__oid
                               AND acnt.amnd_state = 'A'
                               AND acnt.is_ready <> 'C'
                               AND acnt.pcat = 'C'
                               AND acnt.con_cat = 'A'
    LEFT JOIN ows.currency tcur ON tcur.code = d.trans_curr
                               AND tcur.amnd_state = 'A'
    LEFT JOIN ows.currency scur ON scur.code = d.settl_curr
                               AND scur.amnd_state = 'A'
    LEFT JOIN ows.mess_channel  mc ON mc.code = d.source_channel
                                  AND mc.amnd_state = 'A'
WHERE
        d.is_authorization = 'N'
    AND d.outward_status = 'A'
    AND d.posting_status = 'E'
    AND d.amnd_state = 'A'
ORDER BY
    inst.bank_code_posting,
    inst.code