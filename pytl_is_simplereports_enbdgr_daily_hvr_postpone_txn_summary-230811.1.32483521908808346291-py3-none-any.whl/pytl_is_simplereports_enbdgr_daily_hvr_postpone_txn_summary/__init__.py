__version__ = "230811.1"
__job_name__ = "PyTL_IS_SimpleReports_ENBDGR_DAILY_HVR_POSTPONE_TXN_SUMMARY"
__bat_files__ = []
