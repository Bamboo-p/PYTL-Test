/*
* CODE FOR ENBDGR DAILY HVR POSTPONE
* PyTL_IS_SimpleReports_ENBDGR_DAILY_HVR_POSTPONE_TXN_SUMMARY=ENBDGR_DAILY_HVR_POSTPONE_TXN_SUMMARY.sql
* Parameters:
*           :ORGLIST              = '100,017'
*           :P_REPORT_DATE        = 'DD-MM-YYYY'
*           :P_TRANS_TYPE         = 'Credit'
* Version history:
* 230724.1 = RakeshG = ENBD-24774:Initial Version
*/

WITH inst AS (
    SELECT /*+ NO_MERGE MATERIALIZE */
        id        institution_id,
        bank_code code,
        name,
        bank_code_posting
    FROM
        (
            SELECT
                fi.bank_code,
                fi.posting_in,
                fi.id,
                fi2.bank_code bank_code_posting,
                fi.name
            FROM
                     ows.f_i fi
                JOIN ows.f_i fi2 ON fi.posting_in = fi2.id
            WHERE
                    fi.amnd_state = 'A'
                AND fi2.amnd_state = 'A'
        ) inst
    START WITH
        inst.bank_code IN (
            SELECT
                TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY decode(inst.posting_in, inst.id, NULL, inst.posting_in) = PRIOR inst.id
               AND level <= 2
)
,ddate as (
select /*+ materialize */
       min(calendar_date) as from_Date,
       max(calendar_date) as rep_Date
  from ows.mp_consist_point
  where local_date in (to_date(:P_REPORT_DATE,'DD-MM-YYYY'),to_date(:P_REPORT_DATE,'DD-MM-YYYY')-1)
    and mp_consist_type__oid = (select min(id) from ows.mp_consist_type where code = 'END_DAY')
    )
SELECT
    inst.bank_code_posting                  AS org,
    inst.code                               AS branch_code,
    to_char(d.trans_date, 'DDMMYYYY')       AS trans_date,
    cs.prefix                               AS bin_number,
    SUM(d.settl_amount)                     AS total_amount,
    'CREDIT'                                AS credit,
    substr(p.code, 9, 3)                    AS logo,
    p.name                                  AS product_name,
    cur.name                                AS cardholder_currency,
    ows.xwdoc('RETURN_CODE', d.return_code) AS reject_reason
FROM
         ows.doc d
	JOIN ddate dd on d.amnd_date between from_Date and rep_Date
    JOIN ows.acnt_contract a ON a.contract_number = d.target_number
                                AND a.amnd_state = 'A'
                                AND a.is_ready <> 'C'
                                AND a.pcat = 'C'
                                AND a.con_cat = 'C'
    JOIN inst ON inst.institution_id = a.f_i
    JOIN ows.contr_subtype cs ON cs.id = a.contr_subtype__id
                                 AND cs.amnd_state = 'A'
    JOIN ows.appl_product p ON p.id = a.main_product
                               AND p.amnd_state = 'A'
    JOIN ows.trans_type tt ON tt.id = d.trans_type
                          AND tt.name = :P_TRANS_TYPE
    LEFT JOIN ows.currency cur ON cur.code = a.curr
                                  AND cur.amnd_state = 'A'
  WHERE d.is_authorization = 'N'
    AND d.outward_status = 'A'
    AND d.posting_status = 'E'
    AND d.amnd_state = 'A'
GROUP BY
    d.trans_date,
    cs.prefix,
    cur.name,
    inst.code,
    inst.bank_code_posting,
    d.return_code,
    substr(p.code, 9, 3),
    p.name
ORDER BY
    inst.bank_code_posting,
    inst.code