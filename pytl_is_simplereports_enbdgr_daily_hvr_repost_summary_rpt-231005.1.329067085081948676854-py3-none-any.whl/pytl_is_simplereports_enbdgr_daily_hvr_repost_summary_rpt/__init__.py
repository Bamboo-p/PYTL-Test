__version__ = "231005.1"
__job_name__ = "PyTL_IS_SimpleReports_ENBDGR_DAILY_HVR_REPOST_SUMMARY_RPT"
__bat_files__ = []
