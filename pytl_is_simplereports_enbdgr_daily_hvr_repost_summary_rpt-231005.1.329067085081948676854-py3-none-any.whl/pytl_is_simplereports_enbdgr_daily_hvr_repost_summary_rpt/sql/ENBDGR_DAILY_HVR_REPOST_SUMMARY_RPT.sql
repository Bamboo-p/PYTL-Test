/*
* CODE FOR ENBDGR DAILY HVR REPOST TRANS EXTRACT
* PyTL_IS_SimpleReports_ENBDGR_DAILY_HVR_REPOST_SUMMARY_RPT=ENBDGR_DAILY_HVR_REPOST_SUMMARY_RPT.sql
* Parameters:
*           :ORGLIST        = '100,017'
*           :P_REPORT_DATE  = 'DD-MM-YYYY'
*           :P_TXN_FILTER   = 'HIGH_VALUE_REPOST=Y;' This filter has been added in case the filter criteria is different for different orgs
*
* Version history:
* 230809.1 = RakeshG = ENBD-24775:Initial Version
* 230816.1 = RakeshG = ENBD-24947:Fixing issue to generate report for the 096 and posting status to be 'P'
* 231005.1 = RakeshG = ENBD-25141:Mapping change for total amount field from transaction amount to settlement amount of transaction
*/

WITH sq_inst AS (
    SELECT  /*+ no_merge materialize */
        inst.id,
        inst.branch_code,
        inst.branch_code_posting
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code branch_code_posting
            FROM
                     dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY decode(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
), sq_hvr_txn AS (
    SELECT /*+ NO_MERGE MATERIALIZE*/
        t.*
    FROM
             dwf_transaction t                                      --[*] 230816.1 = RakeshG = ENBD-24947:Fixing issue to generate report for the 096
        JOIN sq_inst inst ON inst.id = t.institution_id
    WHERE
            instr(t.add_info, :P_TXN_FILTER) > 0
        AND t.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND t.posting_status = 'P'                                   --[+] 230816.1 = RakeshG = ENBD-24947:Fixing posting status to be 'P'
), sq_add_info AS (
    SELECT /*+ ORDERED */
        t.banking_date,
        t.settl_amount,   --[*] 231005.1 = RakeshG = ENBD-25141:Mapping change for total amount field from transaction amount to settlement amount of transaction
        inst.branch_code_posting     AS org,
        inst.branch_code,
        dcp.bin,
        substr(nvl(p.product_code,pp.code), 9, 3) AS logo,
        nvl(p.name,pp.name) AS product_name,
        c.base_currency
    FROM
             sq_hvr_txn t
        JOIN dwd_card         c ON c.record_idt = t.target_card_idt
                           AND c.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                           AND c.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        JOIN sq_inst          inst ON inst.id = c.institution_id
        JOIN dwd_card_product dcp ON dcp.id = c.card_product_id
                                     AND dcp.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                                     AND dcp.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        JOIN dwd_product pp on pp.id = dcp.product_id
                                   AND pp.record_state = 'A'
   LEFT JOIN v_dwr_product    p ON p.product_id = dcp.product_id
                                AND p.type_code = 'LOGO'
)
SELECT
    i.org,
    i.branch_code,
    to_char(i.banking_date, 'DDMMYYYY')               AS banking_date,
    i.bin                                             AS bin,
    to_char(SUM(i.settl_amount), 'FM999999999999.00') AS total_amount, --[*] 231005.1 = RakeshG = ENBD-25141:Mapping change for total amount field from transaction amount to settlement amount of transaction
    'CREDIT'                                          AS transaction_type, --[*] 231005.1 = RakeshG = ENBD-25141:Mapping change from DEBIT to CREDIT
    i.logo                                            AS logo,
    i.product_name                                    AS product_name,
    c.name                                            AS card_holder_currency,
    'REPOST'                                          AS comments
FROM
    sq_add_info  i
    LEFT JOIN dwd_currency c ON c.code = i.base_currency
                                AND c.record_state = 'A'
GROUP BY
    i.org,
    i.branch_code,
    i.banking_date,
    i.bin,
    i.logo,
    i.product_name,
    c.name
ORDER BY
    i.org,
    i.branch_code,
    i.logo