__version__ = "231108.1"
__job_name__ = "PyTL_IS_SimpleReports_ENBDGR_DAILY_PAYMENT_SMS_EXTRACT"
__bat_files__ = []
