/*
* CODE FOR ENBD GROUP DAILY PAYMENT SMS EXTRACT
* PyTL_IS_SimpleReports_ENBDGR_DAILY_PAYMENT_SMS_EXTRACT=ENBDGR_DAILY_PAYMENT_SMS_EXTRACT.sql
* Parameters:
*           :ORG                  = '100'
*           :P_BANK_DATE          = 'DD-MM-YYYY'
*           :P_DELIMITER          = '|'
*           :P_SY_HANDBOOK_GRP_CODE = 'ENBD_CC_PAYM_SMS'
*           :P_EX_LOGO_LIST       = '033_045,033_046'
*
* Version history:
* 230131.1 = RakeshG = ENBD-24334:Initial Version
* 230518.1 = RakeshG = PRD-24031:Added Exclude Logo list
* 231030.1 = RakeshG = ENBD-25321:P_EX_LOGO_LIST parameter changes to take bank_code as well
* 231108.1 = RakeshG = ENBD-25496:logo and bank_code mapping correction
*/

WITH trans_code AS (
    SELECT /*+ materialize*/
           hb.filter AS code
      FROM v_c$sy_handbook hb
     WHERE hb.amnd_state = 'A'
       AND hb.group_code = :P_SY_HANDBOOK_GRP_CODE
)
, txn_list AS (
    SELECT /*+ no_merge use_hash(t) use_hash(tc) swap_join_inputs(tc) pq_distribute(tc broadcast none) */
           t.contract_idt,
           t.card_idt,
           t.txn_code,
           regexp_replace(to_char(abs(t.amount), 'FM9999999.00'), '[^0-9]') AS amount,
           CASE
               WHEN t.trans_date IS NOT NULL
                    AND ( t.trans_details = 'Standing payment order'
                          OR t.service_class = 'M' )
                    OR t.trans_date IS NULL THEN
                   to_char(t.banking_date, 'ddmmyyyy')
               ELSE
                   to_char(t.trans_date, 'ddmmyyyy')
           END                                                              AS trans_date,
           t.trans_details,
           t.service_class,
           t.banking_date,
           t.txn_description
      FROM opt_dm_transaction t
      JOIN trans_code tc ON tc.code = t.txn_code
     WHERE t.org = :ORG
       AND t.banking_date = to_date(:P_BANK_DATE, 'DD-MM-YYYY')
)
--[+] Begin 230518.1 = PRD-24031 RakeshG
, exclude_logo AS (
--     SELECT substr(ex_logo,1,3) as logo,substr(ex_logo,5,3) as bank_code FROM ( --[*] 231030.1 = PRD-24031 RakeshG ENBD-25321:P_EX_LOGO_LIST parameter changes
     SELECT substr(ex_logo,1,3) as bank_code,substr(ex_logo,5,3) as logo FROM ( --[*] 231108.1 = RakeshG = ENBD-25496:logo and bank_code mapping correction
	 SELECT /*+ no_merge materialize*/
         TRIM(regexp_substr(:P_EX_LOGO_LIST, '[^,]+', 1, level)) ex_logo
     FROM
         dual
     CONNECT BY
         regexp_substr(:P_EX_LOGO_LIST, '[^,]+', 1, level) IS NOT NULL
		 )
)
--[+] End 230518.1 = PRD-24031 RakeshG
    SELECT /*+ ordered */
           ci.org,
           lpad(nvl(c.pan, ci.contract_number), 19, 0)
           || :P_DELIMITER
           || lpad(ci.base_currency, 3, ' ')
           || :P_DELIMITER
           || lpad(dt.txn_code, 3, ' ')
           || :P_DELIMITER
           || lpad(dt.amount, 11, 0)
           || :P_DELIMITER
           || lpad(trans_date, 8, ' ')
           || :P_DELIMITER
           || rpad(substr(dt.txn_description, 1, 40), 40, ' ')
           || :P_DELIMITER AS details
      FROM txn_list dt
      JOIN opt_dm_contract_info ci ON ci.contract_idt = dt.contract_idt
                                  AND ci.banking_date = to_date(:P_BANK_DATE, 'DD-MM-YYYY')
                                  AND ci.org = :ORG 
 LEFT JOIN dwd_card c ON c.record_idt = dt.card_idt
                     AND c.record_date_from <= to_date(:P_BANK_DATE, 'DD-MM-YYYY')
                     AND c.record_date_to >= to_date(:P_BANK_DATE, 'DD-MM-YYYY')
--[+] End 230518.1 = PRD-24031 RakeshG
 LEFT JOIN exclude_logo ex ON ex.logo = ci.logo and ex.bank_code = ci.bank_code --[*] 231030.1 = PRD-24031 RakeshG ENBD-25321:P_EX_LOGO_LIST parameter changes
     WHERE ex.logo is null
--[+] End 230518.1 = PRD-24031 RakeshG