/*
* Code for ICC Corporate SMS REPORT
* PyTL_IS_SimpleReports_ENBDGR_ICC_CORP_SMS_REPORT=ENBDGR_ICC_CORP_SMS_REPORT.sql
* Version history:
* 220601.1 : EIB-8974: Kokila J : Initial Version
* 220712.1 : EIB-8974: Shalini  : Query updated as per requirement
* 220801.1 : EIB-9202: Shalini  : Mapping changes for mobile_nbr field
* 220817.1 : EIB-9250: Shalini  : Added additional filter to fetch only records which has contract open date same as p_report_date
*/
with inst as (
        select /*+ materialize */
              institution_id as id,
              code as org
         from v_dwr_institution
        where class_code = 'BASE_REPORTS'
          and type_code  = 'BANK_DESC'
          and code       = :ORG
            )
        ,corp_icc_logo as (
            select /*+ materialize */
                   substr(code, 9, 3) prdcode
            from dwd_int_product
             join inst i
            on i.org=substr(code, 1, 3)
            where instr(add_info,'REF_NUMBER='||:LTY_CODE||';') > 0
            and record_state = 'A'
            and code_2 = 'COR'
            ),
        corp as
         (
        select /*+ use_index(DWD_CONTRACT_INST_IDX c) */
         c.record_idt contract_idt
        ,c.institution_id
        ,c.personal_account as account_number
        ,substr(c.personal_account,1,6) as bin
        from dwd_contract c
        join inst i
        on i.id=c.institution_id
        and c.client_category='C'
        and c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        and c.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
         ),
        corp_lty as (
        select /*+ use_hash(dca c) */
           c.contract_idt,
           dca.attr_date_from,
           dca.attr_date_to,
           dca.attr_value,
           attr.code
      from corp c
      join dwa_contract_attribute dca
        on dca.contract_idt = c.contract_idt
           and dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
           and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
      join dwd_attribute attr
        on dca.attr_id         = attr.id
       and attr.record_source = 'W4TD_DOMAIN'
       and attr.record_state='A'
       and code = :LTY_CODE
       )
select /*+ no_merge use_hash(dci corp) */
i.org                                        AS ORG,
to_char(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'),'DDMMYY')||lpad(rownum,8,'0') AS "RECORD NUMBER ",
lpad(substr(corp.account_number,4,6),6,' ')  As "BIN   ",
lpad(cl.ATTR_VALUE,11,' ')                   As "CUSTACNTNUM",
lpad(ltrim(dca.PHONE_MOBILE,'0'),9,' ')       As "MOBILENBR",--[*] 220801 : EIB-9202
lpad(tac.ATTR_VALUE,11,' ')                  AS "CARDLTYID  ",
lpad(' ',28,' ')                             AS "FILLER-1                    ",
lpad(' ',40,' ')                             AS "FILLER-2                                ",
lpad(' ',40,' ')                             AS "FILLER-3                                "

from opt_dm_contract_info dci
JOIN inst i on i.id=dci.institution_id
join corp_icc_logo cl on cl.prdcode=dci.logo
join corp on corp.contract_idt=dci.parent_contract_idt
join corp_lty cl on cl.contract_idt = corp.contract_idt
join opt_dm_TD_AUTH_SCHEME tac on dci.CONTRACT_IDT=tac.CONTRACT_IDT
join opt_dm_client_address dca on dci.CLIENT_IDT= dca.CLIENT_IDT
/* Removed because there is no account transfer scenario for Corporate
left join (select contract_idt,new_logo,prev_logo,previous_number,new_number,account_transfer_date,activation_date
           from opt_dm_account_transfer where org=:ORG) trf on trf.contract_idt=dci.contract_idt
           where dci.banking_date = TO_DATE(:P_REPORT_DATE,'dd-mm-yyyy')
*/
and tac.code = :LTY_CODE
and tac.banking_date = TO_DATE(:P_REPORT_DATE,'dd-mm-yyyy')
and dca.banking_date= TO_DATE(:P_REPORT_DATE,'dd-mm-yyyy')
and dci.contract_date_open= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') --[+] 220817 : EIB-9250 