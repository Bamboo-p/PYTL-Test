__version__ = "231114.1"
__job_name__ = "PyTL_IS_SimpleReports_ENBDGR_ICC_CORP_TRANS_EXTRACT_REPORT"
__bat_files__ = []

