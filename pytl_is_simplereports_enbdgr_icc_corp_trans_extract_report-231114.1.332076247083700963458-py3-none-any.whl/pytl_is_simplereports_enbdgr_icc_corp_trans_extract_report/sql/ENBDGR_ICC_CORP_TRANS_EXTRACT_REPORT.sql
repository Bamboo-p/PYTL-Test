/*
* Code for ICC CORPORATE TRANSACTION EXTRACT REPORT
* PyTL_IS_SimpleReports_ENBDGR_ICC_CORP_TRANSCTION_EXTRACT_REPORT=ENBDGR_ICC_CORP_TRANSCTION_EXTRACT_REPORT.sql
* Version history:
* 220601.1 : EIB-8969 : Kokila J - Initial Version
* 220713.1 : EIB-8969 : Shalini  - Updated query as per requirement
* 220725.1 : EIB-9168 : Shalini  - Updated lpad() for required fields
* 220725.2 : EIB-9168 : Shalini  - Updated mapping tran_date and tran_time required fields
* 220729.1 : EIB-9189 : Shalini  - Mapping changes for source_currency and source_amount
* 220729.2 : EIB-9189 : DenisKa  - Some beautifications
* 231003.1 : ECCBAU-6634 : RakeshG - Fixed logic to work even for the 8 digit bin
* 231114.1 : PRD-25685 : RakeshG - Fixed duplicate bin records issue
*/
with 
     v_dc as (
        select /*+ materialize */
              operation_type_id,
              direction
         from v_dwr_operation_type
        where class_code = :ORG||'_TXN_CODE'
          and type_code  = 'TXN_CODE'
          and nvl(instr(add_info,'ICC_EXTRACT=N'),0) = 0
             ),
        inst as (
        select /*+ materialize */
              institution_id as id,
              code as org
         from v_dwr_institution
        where class_code = 'BASE_REPORTS'
          and type_code  = 'BANK_DESC'
          and code       = :ORG
            )
        ,corp_icc_logo as (
            select /*+ materialize */
                   substr(code, 9, 3) prdcode 
            from dwd_int_product
             join inst i
            on i.org=substr(code, 1, 3) 
            where instr(add_info,'REF_NUMBER='||:LTY_CODE||';') > 0
            and record_state = 'A'
            and code_2 = 'COR'
            ),
        card_product_int as (
        select /*+ materialize */
              length(dcp.bin) as bin_length,                      --[+]231003.1 : ECCBAU-6634 : RakeshG - Fixed logic to work even for the 8 digit bin
              row_number() over(partition by dcp.bin order by dcp.code) as rn, --[+]231114.1 : PRD-25685 : RakeshG - Fixed duplicate bin records issue
			  dcp.*                                               --[*]231003.1 : ECCBAU-6634 : RakeshG - Fixed logic to work even for the 8 digit bin
         from dwd_card_int_product dcp
         JOIN inst i on i.id=dcp.institution_id
        where record_state     <> 'C'
          and record_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
          and record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
          and substr(code,9,3) in (select prdcode from corp_icc_logo)
            ),
        corp as
         (
        select /*+ use_index(DWD_CONTRACT_INST_IDX c) */
         c.record_idt contract_idt
        ,c.institution_id
        ,c.personal_account as account_number
        ,substr(c.personal_account,1,6) as bin
        from dwd_contract c
        join inst i
        on i.id=c.institution_id
        and c.client_category='C'
        and c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        and c.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
         ),
        corp_lty as (
        select /*+ use_hash(dca c) */
           c.contract_idt,
           dca.attr_date_from,
           dca.attr_date_to,
           dca.attr_value,
           attr.code
      from corp c
      join dwa_contract_attribute dca
        on dca.contract_idt = c.contract_idt
           and dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
           and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
      join dwd_attribute attr
        on dca.attr_id         = attr.id
       and attr.record_source = 'W4TD_DOMAIN'
       and attr.record_state='A'
       and code = :LTY_CODE
       ),  
      odt1 as (select /*+ materialize ordered index_ss(odt OPT_DM_TRANSACTION_IDX)*/
                     odt.*
                from opt_dm_transaction odt
                join v_dc 
                  on v_dc.operation_type_id = odt.operation_type_id
               where odt.org          = :ORG 
                 and odt.banking_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy')),
      auth as (select /*+ materialize use_hash(iss i) */
                                      min(trans_date) as trans_date, doc_idt
                                 from dwf_iss_operation iss
                                 join inst i 
                                   on i.id = iss.institution_id 
                                where iss.auth_status = 'M'
                                  and iss.banking_date >= to_date(:P_REPORT_DATE,'dd-mm-yyyy') - 10
                                group by doc_idt
                              ),
      dt as (select  /*+ materialize ordered use_nl(t) index(t DWF_TRANSACTION_INST_IDX) use_hash(t iss) */
                             t.doc_idt, 
                             auth.trans_date, 
                             t.source_number,
                             t.target_number,
                             t.target_card_idt,
                             t.add_info,
                             t.TRANS_CURRENCY,
                             t.SETTL_CURRENCY
                        from inst i
                        join dwf_transaction t
                          on i.id = t.institution_id
                   left join auth
                            on auth.doc_idt = t.previous_doc_idt
--[*] [begin] 231003.1 ECCBAU-6634 : RakeshG - Fixed logic to work even for the 8 digit bin
                   left join card_product_int trg on substr(ltrim(t.target_number,'0'),1,trg.bin_length) = trg.bin and trg.rn = 1 --[*]231114.1 : PRD-25685 : RakeshG - Fixed duplicate bin records issue
                   left join card_product_int src on substr(ltrim(t.SOURCE_number,'0'),1,src.bin_length) = src.bin and src.rn = 1 --[*]231114.1 : PRD-25685 : RakeshG - Fixed duplicate bin records issue
                       where t.banking_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy')
                         and (t.target_number is null 
--                        or substr(ltrim(t.target_number,'0'),1,6) in (select bin from card_product_int)                            
--                        or substr(ltrim(t.SOURCE_number,'0'),1,6) in (select bin from card_product_int))  
                          or trg.bin is not null
                          or src.bin is not null)
--[*] [end] 231003.1 ECCBAU-6634 : RakeshG - Fixed logic to work even for the 8 digit bin
                       ),
        odt_dt as (select /*+ materialize */
                     sy_convert.get_tag_value(odt.add_info, 'INST_PLAN_ID') as inst_plan_id,
                     odt.* ,
                     dt.source_number,
                     dt.target_number,
                     dt.target_card_idt,
                     dt.trans_date as auth_date,
                     dt.add_info as add_info_1                     
                from odt1 odt 
                join dt 
                  on odt.doc_idt = dt.doc_idt 
                ),
                instalments as (
        select /*+ materialize*/*
        from (
        select /*+ ordered use_hash(ins i) */
              ins.doc_idt,
              ins.original_instl_idt,
              ins.principal,
              ins.scheme_option_name,
              ins.record_idt,
              ins.contract_idt,
              ins.add_info,
              ins.record_date_from,
              row_number() over(partition by ins.record_idt order by ins.record_date_from asc) rn
         from dwd_instalment ins
         join inst i
           on i.id                = ins.institution_id 
         join dwd_instl_status status 
           on ins.status_id       = status.id
        where status.code        <> 'Z'
          and status.record_state = 'A'
          and ins.record_state    = 'A'
            )
            where rn = 1
            ),

        odt as (select /*+ materialize */
                         odt.*,
                         nvl(i.scheme_option_name, i1.scheme_option_name) scheme_option_name
                    from odt_dt odt
                    left join instalments i 
                      on i.contract_idt = odt.contract_idt
                     and i.original_instl_idt = odt.inst_plan_id
                    left join instalments i1 
                      on i1.principal = abs(odt.amount) 
                      and odt.doc_idt = i1.doc_idt 
                ),
                otd as (select /*+ materialize */
                    id,
                    case when ','||otd.condition_list||',' like '%,WALLET,%' OR ','||otd.condition_list||',' like '%,TOKEN,%'       then 'W'
                         when ','||otd.condition_list||',' like '%,CONTACTLESS,%' AND ','||otd.condition_list||',' like '%,CARD,%'  then 'C'
                         when ','||otd.condition_list||',' like '%,ENET,%' then 'E' else 'O' end as txn_type
               from dwd_trans_conditions otd
              where otd.record_state = 'A'
               ),
        vdot as (select /*+ materialize */
                      *
                 from v_dwr_operation_type
                where class_code = 'ENBD_REPORTS' 
                  and type_code  = 'TURNOVERS'  
                )
                
            
select * from 
(
select /*+ no_merge*/
org                           as ORG,      
record_number                 ||         
substr(account_number,1,6)    ||
       attr_value             ||
       trans_date             ||  
       trans_time             ||
       atpt_mt_merch_id       ||
       atpt_mt_category_code  ||
       merchant_name          ||
       merchant_city          ||
       merchant_country_code  ||
       terminal_id            ||
       transation_sign        ||
       transaction_id         ||
       transaction_amount     ||
       source_amount          ||
       source_currency        ||
       deal_code              ||
       txn_code               ||
       TRANSACTION_TYPE       ||
       prdcode                ||
       '  '                   ||
       employee_loyalty_id    ||
       filler_1               ||
       filler_2               ||
       filler_3               as Details
  from ( 
  
        select  /*+ ordered */
        i.org,
        to_char(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'),'DDMMYY')||lpad(rownum,8,'0') AS record_number,
        lpad(nvl(ltrim(corp.account_number,0),' '),6,' ') as account_number,
        lpad(nvl(cl.attr_value,' '),11,' ') as attr_value,
        /*lpad(nvl(to_char(odt.trans_date,'ddmmyy'),' '),6,' ') as trans_date,
        lpad(nvl(to_char(odt.trans_date, 'hh24miss'),' '),8,' ') as trans_time,*/
        to_char(nvl(to_date(substr((substr(odt.add_info_1, instr(odt.add_info_1, 'NI_AUTH_DATE=')+13,
        (instr(odt.add_info_1, ';', instr(odt.add_info_1, 'NI_AUTH_DATE='))-instr(odt.add_info_1, 'NI_AUTH_DATE=')-13))),1,14),'YYYYMMDDHH24MISS'), odt.trans_date), 'YYMMDD') as trans_date,
        rpad(nvl(to_char(nvl(to_date(substr((substr(odt.add_info_1, instr(odt.add_info_1, 'NI_AUTH_DATE=')+13,
        (instr(odt.add_info_1, ';', instr(odt.add_info_1, 'NI_AUTH_DATE='))-instr(odt.add_info_1, 'NI_AUTH_DATE=')-13))),1,14),'YYYYMMDDHH24MISS'), odt.trans_date), 'hh24miss'), '000000'), 8, '0')as trans_time,
        lpad(nvl(odt.merchant, '0'), 15, ' ') as atpt_mt_merch_id,
        lpad(nvl(substr(odt.trans_mcc, 1, 4), '0'), 4, '0') as atpt_mt_category_code,
        lpad(substr(nvl(odt.trans_details, odt.txn_description), 1, 23),23,' ') as merchant_name,
        lpad(nvl(substr(TRIM(odt.trans_city), 1, 14),' '),14,' ') as merchant_city,
        lpad(nvl(substr(odt.trans_country_code, 1, 3),' '),3,' ') as merchant_country_code,
        lpad(nvl(substr(odt.source_number, 1, 16), '0'), 16, '0') as terminal_id, 
        case when odt.amount > 0 then 'C' else 'D' end as transation_sign,
        lpad(nvl(substr(coalesce(odt.trans_rrn, odt.trans_arn, odt.trans_srn), 1, 23), '0'), 23, '0') as transaction_id,
        lpad(substr(abs(odt.amount), 1, 18),18,' ')   as transaction_amount,
        -- [*] [begin] 20220729.1 : EIB-9189 : Shalini  - Mapping changes for source_currency and source_amount
        /*
        case when odt.trans_currency<>odt.SETTL_CURRENCY then lpad(substr(odt.trans_amount, 1, 18),18,' ') else lpad(' ',18,' ') end as source_amount,
        case when odt.trans_currency<>odt.SETTL_CURRENCY then lpad(substr(odt.trans_currency, 1, 3),3,' ') else lpad(' ',3,' ') end as source_currency,
        */
        lpad(nvl(substr(odt.trans_amount, 1, 18),' '),18,' ')  as source_amount,
        lpad(nvl(substr(odt.trans_currency, 1, 3),' '),3,' ') as source_currency,
        -- [*] [end]   20220729.1 : EIB-9189 : Shalini  - Mapping changes for source_currency and source_amount
        case when odt.scheme_option_name is not null then lpad(substr(odt.scheme_option_name, - 5),5,'0')
             when vdot.code = 'CASH'     then '00002'
             when vdot.code = 'RETAIL'   then '00001'
             when vdot.code like '%FEE%' then '00201' 
             else '00000' end as deal_code,
        nvl(txn_type,'O')  as transaction_type,
        lpad(odt.txn_code, 4, '0') as txn_code,
        lpad(cl.prdcode,3,'0') as prdcode,
        lpad(oda.attr_value,11,' ') as employee_loyalty_id,
        lpad(' ',23,' ')                             AS filler_1,
        lpad(' ',40,' ')                             AS filler_2,
        lpad(' ',40,' ')                             AS filler_3
    from opt_dm_contract_info odc 
    JOIN inst i on i.id=odc.institution_id
    join corp_icc_logo cl on cl.prdcode=odc.logo
    join corp on corp.contract_idt=odc.parent_contract_idt
    join corp_lty cl on cl.contract_idt = corp.contract_idt
    join odt on odt.contract_idt = odc.contract_idt 
           
    join opt_dm_td_auth_scheme oda
           on odc.contract_idt = oda.contract_idt
          and oda.org          = :ORG
          and oda.code         = :LTY_CODE
          and oda.banking_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy') 

    
    left join otd
             on odt.trans_conditions_id=otd.id  
    
    left join vdot 
            on vdot.operation_type_id = odt.operation_type_id   
             
    left join dwd_card cd 
           on cd.record_idt        = odt.target_card_idt
          and cd.record_state     <> 'C'
          and cd.record_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
          and cd.record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
                 
        where odc.org          = :ORG
          and odc.banking_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy')
          
          )

 )