__version__ = "230814.1"
__job_name__ = "PyTL_IS_SimpleReports_ENBDGR_MONTHLY_JARIR_INSTLMNT_REPORT"
__bat_files__ = []
