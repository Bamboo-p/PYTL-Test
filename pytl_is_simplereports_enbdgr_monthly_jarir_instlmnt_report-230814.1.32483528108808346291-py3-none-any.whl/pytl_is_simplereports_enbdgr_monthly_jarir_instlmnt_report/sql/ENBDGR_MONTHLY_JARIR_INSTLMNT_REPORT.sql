/*
* CODE FOR MONTHLY JARIR INSTALLMENT REPORT
* Parameters:
*           :ORG                  = '016'
*           :P_REPORT_DATE        = 'DD-MM-YYYY'
*           :P_LOGO_LIST          = '009,015'
*           :P_TXN_FILTER         = 'LTY_GRP_1'
*
* Version history:
* 230728.1 = Santosh = EK-3480:Initial Version
* 230811.1 = Santosh = EK-3480: Date and join correction for contract_info
* 230811.2 = RakeshG = EK-3480: Date and join correction on top of santosh changes as suggested in the PR
* 230814.1 = RakeshG = EK-3548: Fixed duplicate issue and trans codition join issue, added missed field.
*/

WITH logos AS (
    SELECT /*+ no_merge materialize*/
        TRIM(regexp_substr(:P_LOGO_LIST, '[^,]+', 1, level)) logo
    FROM
        dual
    CONNECT BY
        regexp_substr(:P_LOGO_LIST, '[^,]+', 1, level) IS NOT NULL
)
,m_dates as (
    select /*+no_merge materialize*/
           trunc(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),'mm') as min_date, --[+] 230811.2 = RakeshG = EK-3480: Date 
           last_day(to_date(:P_REPORT_DATE,'DD-MM-YYYY'))   as max_date  --[+] 230811.2 = RakeshG = EK-3480: Date 
      from dual
    )
, contract AS (
        SELECT /*+ no_merge materialize*/
               info.*
          FROM opt_dm_contract_info info
          JOIN logos l ON l.logo = info.logo
         WHERE info.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
           AND info.org = :ORG
)
, installments AS (
        SELECT /*+ no_merge materialize*/
    c.contract_idt,
    i.doc_idt, --[*] 230811.1 = Santosh = EK-3480: Date correction for contract_info
    i.tenor,
    i.principal,
    i.total - i.principal as interest,
    i.total,
    substr(regexp_replace(nvl(substr(i.add_info,1,instr(i.add_info, ':', 1)-1),i.add_info), '[^[:digit:]]', ''),1,7) as PLAN_NUMBER,
	i.CREATION_DATE
FROM
      dwd_instalment i
 JOIN dwd_institution inst ON inst.record_idt = i.institution_id AND inst.record_state = 'A'
 JOIN contract c ON c.contract_idt = i.contract_idt
 JOIN m_dates d ON i.creation_date BETWEEN d.min_date AND d.max_date
 JOIN dwd_instl_status st ON i.status_id = st.id
  AND st.code not in ('Z','CLOSED','REVISED')
WHERE i.RECORD_STATE   = 'A'
  AND c.org            = :ORG   
)
  SELECT /*+ ordered */
          cc.org                                                             AS ORG,
		  c.pan                                                              AS MASKED_CARD_NUMBER,
          cc.contract_number                                                 AS ACCOUNT_NUMBER,
          to_char(t.trans_date,'DDMMYYYY')                                   AS TRANSACTION_DATE,
          to_char(t.banking_date,'DDMMYYYY')                                 AS SETTLEMENT_DATE,
          to_char(t.trans_amount, 'FM999999999.00')                          AS TRANS_AMOUNT,
          t.merchant                                                         AS MERCHANT_ID,
          CASE WHEN instr(tc.condition_list,'ENET')>0 then 'E-com'
               WHEN instr(tc.condition_list,'ATM')>0  then 'ATM'
               WHEN instr(tc.condition_list,'POS')>0  then 'POS'
               WHEN instr(tc.condition_list,'KEY_ENTRY')>0 then 'MANUAL' END AS TRANSACTION_TYPE,
          'Y'                                                                AS IPP_CONVERTED,      
          'N'                                                                AS REVERSED_TRANS,
		  to_char(di.CREATION_DATE,'DDMMYYYY')                               AS IPP_CONVERTION_DATE,  --[+] 230814.1 = RakeshG = EK-3548:Added missed column
          di.plan_number                                                     AS IPP_NUMBER,
          di.tenor                                                           AS TENOR,
          di.principal                                                       AS IPP_TOTAL_PRINCIPAL,
          di.interest                                                        AS IPP_TOTAL_INTEREST,
          di.total                                                           AS IPP_TOTAL_AMOUNT
     FROM contract cc
     JOIN opt_dm_transaction t ON cc.contract_idt = t.contract_idt
     JOIN m_dates d ON t.banking_date between d.min_date and d.max_date
      AND t.org = :ORG
      AND instr(t.add_info,:P_TXN_FILTER) > 0 
     JOIN dwd_card c ON c.record_idt = t.card_idt
      AND c.record_date_from <= t.banking_date
      AND c.record_date_to >= t.banking_date
     JOIN installments di ON  cc.contract_idt = di.contract_idt
     AND  di.doc_idt = t.doc_idt --[*] 230811.2 = RakeshG = EK-3480: Date and join correction for contract_info
     AND t.is_fee = 1            --[+] 230814.1 = RakeshG = EK-3548: Fixed duplicate issue
LEFT JOIN dwd_trans_conditions tc ON tc.id = t.trans_conditions_id  --[*] 230814.1 = RakeshG = EK-3548: used id instead of record_idt
      AND tc.record_state = 'A'