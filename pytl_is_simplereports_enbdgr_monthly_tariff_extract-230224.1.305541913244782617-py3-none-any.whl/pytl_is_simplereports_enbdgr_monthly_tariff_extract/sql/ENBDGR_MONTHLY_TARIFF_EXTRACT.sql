/*
* ENBD_MONTHLY_TARIFF_EXTRACT 
*
* Version history:
* 06012023.1 = Akshay = ENBD-24287 : Initial Version
* 230224.1 = Shalini = ENBD-24287 : Refactoring of query as per standard practice
*/SELECT
    :ORG                  as ORG
    ,tdo.amnd_date        as AMND_DATE
    ,tdo.name             as NAME        
    ,tdo.code             as CODE 
    ,t.tariff_role        as TARIFF_ROLE
    ,t.name               as TARIFF_NAME
    ,t.table_code_from    as TABLE_CODE_FROM
    ,tda.date_from        as TARIFF_VALUE_DATE_FROM
    ,tda.due_period       as DUE_PERIOD
    ,tda.due_period_grace as DUE_PERIOD_GRACE
    ,tda.max_amount       as MAX_AMOUNT
    ,tda.min_amount       as MIN_AMOUNT
    ,tda.min_rq_amount    as MIN_RQ_AMOUNT
    ,tda.single_amount    as SINGLE_AMOUNT
    ,tda.fx_rate_type     as FX_RATE_TYPE
    ,tda.rate_pcnt        as RATE_PCNT
    ,tda.fee_rate_pcnt    as FEE_RATE_PCNT
    ,tda.gl_number        as GL_NUMBER
    ,tda.min_count        as MIN_COUNT
    ,tda.max_count        as MAX_COUNT
FROM
    ows.tariff_domain tdo
    LEFT JOIN ows.tariff        t ON t.tariff_domain__oid = tdo.id
    LEFT JOIN ows.tariff_data   tda ON tda.tariff__oid = t.id
WHERE
        tdo.amnd_state = 'A'
    AND t.amnd_state = 'A'
    AND tda.amnd_state = 'A'
--and (tdo.code = '033_MAIN' or tdo.code like '033_AED_%')
    AND ( tdo.code = :ORG || '_MAIN'
          OR tdo.code LIKE :ORG || '_AED_%' )
    AND tdo.code != :ORG || '_BT_FLAT_PLAN'
ORDER BY
    tdo.code,
    t.tariff_role,
    t.table_code_from,
    tda.date_from