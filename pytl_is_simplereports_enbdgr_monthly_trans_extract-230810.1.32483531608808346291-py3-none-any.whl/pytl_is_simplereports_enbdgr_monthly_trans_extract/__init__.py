__version__ = "230810.1"
__job_name__ = "PyTL_IS_SimpleReports_ENBDGR_MONTHLY_TRANS_EXTRACT"
__bat_files__ = []
