/*
* CODE FOR ENBDGR MONTHLY TRANS EXTRACT
* PyTL_IS_SimpleReports_ENBDGR_MONTHLY_TRANS_EXTRACT=ENBDGR_MONTHLY_TRANS_EXTRACT.sql
* Parameters:
*           :ORG                  = '016'
*           :P_BANK_DATE          = 'DD-MM-YYYY'
*           :P_LOGO_LIST          = '045,046'
*           :P_TXN_FILTER         = 'LTY_GRP_1' This filter has been added in case the filter criteria is different for different orgs
*
* Version history:
* 230727.1 = RakeshG = EK-3479:Initial Version
* 230728.1 = RakeshG = EK-3479:Changed the job name, added a parameter P_TXN_FILTER.
* 230810.1 = RakeshG = EK-3540:Resolved duplicate issue,Mapping changes for TRANS_AMOUNT/REVERSED_TRANS
*/

WITH logos AS (
    SELECT /*+ no_merge materialize*/
        TRIM(regexp_substr(:P_LOGO_LIST, '[^,]+', 1, level)) logo
    FROM
        dual
    CONNECT BY
        regexp_substr(:P_LOGO_LIST, '[^,]+', 1, level) IS NOT NULL
)
, contract AS (
        SELECT /*+ no_merge materialize*/
               info.*
          FROM opt_dm_contract_info info
          JOIN logos l ON l.logo = info.logo
         WHERE info.banking_date = to_date(:P_BANK_DATE, 'DD-MM-YYYY')
           AND info.org = :ORG
)
  SELECT /*+ ordered */
          cc.org                                                             AS ORG,
          c.pan                                                              AS MASKED_CARD_NUMBER,
          cc.contract_number                                                 AS ACCOUNT_NUMBER,
          to_char(t.trans_date,'DDMMYYYY')                                   AS TRANSACTION_DATE,
          to_char(t.banking_date,'DDMMYYYY')                                 AS SETTLEMENT_DATE,
          to_char(t.SETTL_AMOUNT, 'FM999999999.00')                          AS TRANS_AMOUNT,         --[*]  230810.1 = RakeshG = EK-3540:trans amount mapping changes
          t.merchant                                                         AS MERCHANT_ID,
          CASE WHEN instr(tc.condition_list,'ENET')>0 then 'E-com'
               WHEN instr(tc.condition_list,'ATM')>0  then 'ATM'
               WHEN instr(tc.condition_list,'POS')>0  then 'POS'
               WHEN instr(tc.condition_list,'KEY_ENTRY')>0 then 'MANUAL' END AS TRANSACTION_TYPE,
          decode(t.direction,-1,'N','Y')                                     AS REVERSED_TRANS        --[*]  230810.1 = RakeshG = EK-3540:trans amount mapping changes
     FROM contract cc
     JOIN opt_dm_transaction t ON cc.contract_idt = t.contract_idt
      AND t.banking_date BETWEEN trunc(to_date(:P_BANK_DATE, 'DD-MM-YYYY'), 'MM') AND to_date(:P_BANK_DATE,'DD-MM-YYYY')
      AND t.org = :ORG
      AND instr(t.add_info,:P_TXN_FILTER) > 0                  --[*]  230728.1 = RakeshG = EK-3479 Added a new parameter for trans filter
      AND t.is_fee = 1                                         --[+]  230810.1 = RakeshG = EK-3540:Resolved duplicate issue
	 JOIN dwd_card c ON c.record_idt = t.card_idt
      AND c.record_date_from <= t.banking_date
      AND c.record_date_to >= t.banking_date
      AND c.record_state <> 'C'
LEFT JOIN dwd_trans_conditions tc ON tc.id = t.trans_conditions_id     --[*]  230810.1 = RakeshG = EK-3540:trans condition join
      AND tc.record_state = 'A'