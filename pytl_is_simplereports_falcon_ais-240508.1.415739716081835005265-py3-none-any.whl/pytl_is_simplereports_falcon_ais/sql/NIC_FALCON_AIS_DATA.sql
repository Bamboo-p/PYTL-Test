/*
07-03-2022 - OPKSAIC-3174 - Bharath - Falcon AIS report initial version
14-04-2022 - OPKSAIC-3174 - Bharath - Changed query to positional file requirements
31-05-2022 - OPKSAIC-3174 - Bharath - Changed query to update the lengths
14-09-2022 - OPKSAIC-4850 - Santosh - NVL condition added for customer_xid
230217.5 = deniska = NICORE-143: replace TABs with SPACEs. Trim trailing spaces.
230414.1 = santosh = ETSLT-363 : Added new param RETURN_RBS. Default value will be N
230508.1 = Santosh = ETSLT-363 : Changed to sqp file to mitigate regression impact
230711.1 = Santosh = ETSLT-363 : alias name corection
230828.1 = Santosh = ETSLT-363 : Removing RETURN_RBS: Reverting sqp and logic change to use product
230901.1 = Santosh = NICORE-788 : Change to populate client number
230904.1 = Santosh = NICORE-788 : condition update
230904.1 = Shalini = OPKSAIC-5547 : Added ability to change offset value as per P_TZ parameter
230904.2 = Shalini = OPKSAIC-5547 : Conflicts resolution
230908.1 = Shalini = IB-547: Logic changes to get common report for all clients under particular Tenant
231108.1 = Shalini = PRD-25567: Logic changes to correct milliseconds issue
240216.1 = KhaledO = AJM-5055 : Changed the join between client list and falcon table to be on branch code 
240308.1 = Santosh = CRKSA-496 : Changed conversion logic to support multicurrency
*/
with client_list as (
    select /*+ no_merge materialize */
          v.code as client_xid,
          v.name,
          v.add_info as tenant_name,
          inst.id,
          inst.branch_code,
		  inst.add_info --[+] 230901.1 = Santosh = NICORE-788 : Change to populate client number
     from sy_conf_group g
     join sy_conf_group_val v
       on v.amnd_state = 'A'
      and g.id = v.sy_conf_group__oid
     join sy_conf_group_rec r
       on r.amnd_state = 'A'
      and r.value_id = v.id
     join dwd_institution inst
       on inst.id = r.table_rec_id
    where g.code = 'CLIENT_BANK_ID'
      and g.group_code = 'FALCON_BATCH_FEED'
      and inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                 from dual
                           connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
    ),
inst as (
    select /*+ no_merge materialize */
          id,
          branch_code,
          name inst_name,
          local_currency
     from (select dwd_institution.branch_code,
                  dwd_institution.posting_institution_id,
                  dwd_institution.id,
                  dwd_institution.local_currency,
                  dwd_institution2.branch_code branch_code_posting,
                  dwd_institution.name
             from dwd_institution
             join dwd_institution dwd_institution2
               on dwd_institution.posting_institution_id = dwd_institution2.id
            where dwd_institution.record_state = 'A'
           ) inst
       start with inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                         from dual
                                   connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
                                      )
                            connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
    ),
conversion_rates as (
    select /*+no_merge materialize*/
          i.id as institution_id, --[+] 230908.1 = IB-547
          f.base_currency as settl_currency,
          f.rate_value
     from dwf_fx_rate f
     join inst i
       on f.institution_id = i.id
     join dwd_fx_rate_type d
       on d.id = f.fx_rate_type_id
      and d.record_state   = 'A'
    where f.banking_Date   = to_date(:P_BANKING_DATE,'DD-MM-YYYY')
      and d.fx_type_code   = 'D'
      and d.rate_type_code = 'M'
      --and base_currency    = i.local_currency --[-] 240308.1 = Santosh = CRKSA-496 : Changed conversion logic to support multicurrency
      and quote_currency   = (select min(code) from dwd_currency where name = 'USD' and record_state ='A')
    )

select i.branch_Code as ORG,
       'D'
     ||rpad(ais.workflow_xcd,16,' ')
     ||rpad('AIS20',8,' ')
     ||rpad('2.0',5,' ')
     ||rpad(ais.client_xid,16,' ')
--[*] begin 230904.1 = OPKSAIC-5547
--     ||rpad(to_char(sysdate,'yyyymmdd'),8,'0')
--     ||rpad(to_char(sysdate,'HHMMSS'),6,'0')
--     ||rpad(to_char(sysdate,'SS')*1000,3,'0')
--     ||'+04.00'
--[*] begin 231108.1 = PRD-25567
       ||TO_CHAR(
         FROM_TZ(
           TO_TIMESTAMP(SUBSTR(TO_CHAR(SYSTIMESTAMP, 'YYYYMMDDHH24MISSFFtzh:tzm'),1,17), 'YYYYMMDDHH24MISSFFtzh:tzm'),
           substr(TO_CHAR(SYSTIMESTAMP, 'tzh:tzm'),1,7)
         ) AT TIME ZONE NVL(:P_TZ, substr(TO_CHAR(SYSTIMESTAMP, 'tzh:tzm'),1,7)), 
         'YYYYMMDDHH24MISSFF3tzh.tzm'
       )
--[*] end 231108.1 = PRD-25567
--[*] end 230904.1 = OPKSAIC-5547
	 ||rpad(nvl(decode(sy_convert.get_tag_value(i.add_info,'CAF_EXPORT_CLIENT_ID'),'Y',ais.customer_xid,cl.CLIENT_NUMBER),' '),20,' ')--[*] 230901.1 = Santosh = NICORE-788 : Change to populate client number
	 ||rpad(nvl(decode(p.group_code,'ISSDEB',dc.contract_number,ais.account_reference_xid),' ') , 40, ' ') --[*]230828.1 = Santosh = ETSLT-363 : Reverting sqp and logic change to use product
     ||'WY4AIS'||lpad(opt_ais_file_seq.nextval,26,'0')
     ||rpad(nvl(ais.account_type_xcd,' ') ,2,' ')
     ||rpad(ais.account_owner_type_xcd,2,' ')
     ||rpad(ais.account_designation_xcd,2,' ')
     ||rpad(ais.joint_customer_xid,20,' ')
     ||rpad(ais.vip_xflg,1,' ')
     ||rpad(ais.routing_xid, 20, ' ')
     ||rpad(ais.bank_xid, 20, ' ')
     ||rpad(ais.branch_xid, 20, ' ')
     ||rpad(ais.branch_country_xcd, 3, ' ')
     ||rpad(ais.branch_country_region_xcd, 3, ' ')
     ||rpad(ais.branch_city_name, 40, ' ')
     ||rpad(ais.branch_postal_xcd, 10, ' ')
     ||rpad(ais.application_reference_xid, 32, ' ')
     ||rpad(ais.payment_id_cnt , 5, ' ')
     ||rpad(ais.authorized_account_users_cnt , 5, ' ')
     ||rpad(ais.account_open_dt , 8, ' ')
     ||rpad(ais.account_state_xcd , 2, ' ')
     ||rpad(nvl(ais.current_status_effective_dt,' ') , 8, ' ')
     ||rpad(ais.authentication_code_length , 2, ' ')
     ||rpad(ais.authentication_code_set_dt , 8, ' ')
     ||rpad(ais.authentication_type_xcd , 1, ' ')
     ||rpad(ais.currency_xcd , 3, ' ')
     ||rpad(nvl(to_char(c.rate_value),' '),13,' ') --[*] 230908.1 = IB-547
     ||rpad(ais.credit_limit_amt , 16, ' ')
     ||rpad(ais.overdraft_limit_amt , 16, ' ')
     ||rpad(ais.pos_daily_limit_amt , 16, ' ')
     ||rpad(ais.cash_daily_limit_amt , 16, ' ')
     ||rpad(ais.total_daily_limit_amt , 16, ' ')
     ||rpad(ais.daily_limit_type_xcd , 1, ' ')
     ||rpad(ais.direct_deposit_xflg , 1, ' ')
     ||rpad(ais.mobile_payment_xflg , 1, ' ')
     ||rpad(ais.online_payment_xflg , 1, ' ')
     ||rpad(ais.portfolio_name , 14, ' ')
     ||rpad(ais.account_service_type_xcd , 4, ' ')
     ||rpad(ais.statement_addressee , 60, ' ')
     ||rpad(ais.statement_address_line_1_strg , 40, ' ')
     ||rpad(ais.statement_address_line_2_strg , 40, ' ')
     ||rpad(ais.statement_address_line_3_strg , 40, ' ')
     ||rpad(ais.statement_address_line_4_strg , 40, ' ')
     ||rpad(ais.statement_city_name , 40, ' ')
     ||rpad(ais.statement_country_region_xcd , 3, ' ')
     ||rpad(ais.statement_postal_xcd , 10, ' ')
     ||rpad(ais.statement_country_xcd , 3, ' ')
     ||rpad(ais.statement_cycle_period_days , 3, ' ')
     ||rpad(ais.statement_day_of_month , 2, ' ')
     ||rpad(ais.account_interest_rate , 8, ' ')
     ||rpad(ais.interest_rate_category_xcd , 10, ' ')
     ||rpad(ais.account_inactive_cyc , 3, ' ')
     ||rpad(ais.payment_delinquent_cyc , 2, ' ')
     ||rpad(ais.trans_total_delinquent_amt , 19, ' ')
     ||rpad(ais.overlimit_xflg , 1, ' ')
     ||rpad(ais.behavior_1_scr , 4, ' ')
     ||rpad(ais.behavior_2_scr , 4, ' ')
     ||rpad(ais.segment1_xid , 6, ' ')
     ||rpad(ais.segment2_xid , 6, ' ')
     ||rpad(ais.segment3_xid , 6, ' ')
     ||rpad(ais.segment4_xid , 6, ' ')
     ||rpad(ais.user_indicator_1_xcd , 1, ' ')
     ||rpad(ais.user_indicator_2_xcd , 1, ' ')
     ||rpad(ais.user_indicator_3_xcd , 1, ' ')
     ||rpad(ais.user_indicator_4_xcd , 1, ' ')
     ||rpad(ais.user_indicator_5_xcd , 1, ' ')
     ||rpad(ais.user1_xcd , 3, ' ')
     ||rpad(ais.user2_xcd , 3, ' ')
     ||rpad(ais.user3_xcd , 3, ' ')
     ||rpad(ais.user4_xcd , 3, ' ')
     ||rpad(ais.user5_xcd , 3, ' ')
     ||rpad(ais.user_data_1_strg , 6, ' ')
     ||rpad(ais.user_data_2_strg , 6, ' ')
     ||rpad(ais.user_data_3_strg , 6, ' ')
     ||rpad(ais.user_data_4_strg , 8, ' ')
     ||rpad(ais.user_data_5_strg , 8, ' ')
     ||rpad(ais.user_data_6_num , 8, ' ')
     ||rpad(ais.user_data_7_strg , 10, ' ')
     ||rpad(ais.user_data_8_strg , 10, ' ')
     ||rpad(ais.user_data_9_strg , 15, ' ')
     ||rpad(ais.user_data_10_strg , 15, ' ')
     ||rpad(nvl(decode(p.group_code,'ISSDEB',ais.account_reference_xid,ais.user_data_11_strg),' ') , 20, ' ') --[*]230828.1 = Santosh = ETSLT-363 : Reverting sqp and logic change to use product
     ||rpad(ais.user_data_12_strg , 20, ' ')
     ||rpad(ais.user_data_13_strg, 40, ' ')
     ||rpad(ais.user_data_14_strg, 40, ' ')
     ||rpad(ais.user_data_15_strg, 60, ' ')
     ||rpad(ais.reserved_01, 30, ' ') as data

  from opt_v_falcon_ais ais
  join client_list i
	on trim(ais.client_xid) = trim(i.client_xid)
    and trim(ais.bank_xid) = trim(i.branch_code) --240216.1
left join conversion_rates c
    on c.settl_currency = ais.currency_xcd
and i.id=c.institution_id --[+] 230908.1 = IB-547
--[+] BEGIN 230904.1 = Santosh = NICORE-788 : condition update	
--[*]BEGIN 230828.1 = Santosh = ETSLT-363 : Reverting sqp and logic change to use product    
 left join dwd_contract dc
        on dc.personal_account = trim(ais.account_reference_xid)
		and dc.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
        and dc.record_date_to   >= to_date(:P_BANKING_DATE,'DD-MM-YYYY') 
left join dwd_client cl on cl.record_idt =  to_number(trim(ais.customer_xid)) --[+] 230901.1 = Santosh = NICORE-788 : Change to populate client number		
		and cl.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
        and cl.record_date_to   >= to_date(:P_BANKING_DATE,'DD-MM-YYYY') 
--[+] END 230904.1 = Santosh = NICORE-788 : condition update
  join dwd_product p on p.id = dc.product_id        
--[*]END 230828.1 = Santosh = ETSLT-363 : Reverting sqp and logic change to use product  