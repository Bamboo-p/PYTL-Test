/*
07-03-2022 - OPKSAIC-3174 - Bharath - Falcon AIS report initial version
14-04-2022 - OPKSAIC-3174 - Bharath - Changed query to positional file requirements
31-05-2022 - OPKSAIC-3174 - Bharath - Changed query to update the lengths
230217.5 = deniska = NICORE-143: replace TABs with SPACEs. Trim trailing spaces.
230908.1 = Shalini = IB-547: Logic changes to get common report for all clients under particular Tenant
*/

--[-] begin 230908.1 = IB-547
--with client_list as (
--    select /*+ no_merge materialize */
--          v.code as client_xid,
--          v.name,
--          v.add_info as tenant_name,
--          inst.id,
--          inst.branch_code
--     from sy_conf_group g
--     join sy_conf_group_val v
--       on v.amnd_state = 'A'
--      and g.id = v.sy_conf_group__oid
--     join sy_conf_group_rec r
--       on r.amnd_state = 'A'
--      and r.value_id = v.id
--     join dwd_institution inst
--       on inst.id = r.table_rec_id
--    where g.code = 'CLIENT_BANK_ID'
--      and g.group_code = 'FALCON_BATCH_FEED'
--      and inst.branch_code in (select trim(regexp_substr(ORGLIST, '[^,]+', 1, level)) org
--                                 from dual
--                           connect by regexp_substr(ORGLIST, '[^,]+', 1, level) is not null)
--    )
--[-] end  230908.1 = IB-547

select --i.branch_Code as ORG, --[-] 230908.1 = IB-547
       'B'
     ||'000000000'
     ||lpad(' ',1136,' ')
     ||'1.0'
     ||'AIS20   '
     ||'PMAX  '
     ||'00000000' as data
  from dual --[*] 230908.1 = IB-547
