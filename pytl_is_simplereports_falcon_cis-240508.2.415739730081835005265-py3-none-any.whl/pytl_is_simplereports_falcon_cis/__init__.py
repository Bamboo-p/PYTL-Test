__version__ = "240508.2"
__job_name__ = "PyTL_IS_SimpleReports_FALCON_CIS"
__bat_files__ = ["NIC_IS_Ou_FalconReports.bat"]
