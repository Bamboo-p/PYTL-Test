/*
07-03-2022 - OPKSAIC-3174 - Bharath - Falcon CIS report initial version
14-04-2022 - OPKSAIC-3174 - Bharath - Changed query to positional file requirements
31-05-2022 - OPKSAIC-3174 - Bharath - Changed query to update the lengths
14-02-2023 - ETSLT-247 - Santosh - Changes to replace non ascii chars
230217.6 = deniska = NICORE-143: replace TABs with SPACEs. Trim trailing spaces.
230901.1 = Santosh = NICORE-788 : Change to populate client number
230904.1 = Santosh = NICORE-788 : condition update
230904.1 = Shalini = OPKSAIC-5547 : Added ability to change offset value as per P_TZ parameter
230904.2 = Shalini = OPKSAIC-5547 : Conflicts resolution
230908.1 = Shalini = IB-547: Logic changes to get common report for all clients under particular Tenant
231108.1 = Shalini = PRD-25567: Logic changes to correct milliseconds issue
240216.1 = KhaledO = AJM-5055 : Changed the join between client list and client table to be inner and to use client.institution_id
*/
with client_list as (
    select /*+ no_merge materialize */
          v.code as client_xid,
          v.name,
          v.add_info as tenant_name,
          inst.id,
          inst.branch_code,
		  inst.add_info --[+] 230901.1 = Santosh = NICORE-788 : Change to populate client number
     from sy_conf_group g
     join sy_conf_group_val v
       on v.amnd_state = 'A'
      and g.id = v.sy_conf_group__oid
     join sy_conf_group_rec r
       on r.amnd_state = 'A'
      and r.value_id = v.id
     join dwd_institution inst
       on inst.id = r.table_rec_id
    where g.code = 'CLIENT_BANK_ID'
      and g.group_code = 'FALCON_BATCH_FEED'
      and inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                 from dual
                           connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
    ),
inst as (
    select /*+ no_merge materialize */
          id,
          branch_code,
          name inst_name,
          local_currency
     from (select dwd_institution.branch_code,
                  dwd_institution.posting_institution_id,
                  dwd_institution.id,
                  dwd_institution.local_currency,
                  dwd_institution2.branch_code branch_code_posting,
                  dwd_institution.name
             from dwd_institution
             join dwd_institution dwd_institution2
               on dwd_institution.posting_institution_id = dwd_institution2.id
            where dwd_institution.record_state = 'A'
           ) inst
       start with inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                         from dual
                                   connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
                                      )
                            connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
    ),
conversion_rates as (
    select /*+no_merge materialize*/
          i.id as institution_id, --[+] 230908.1 = IB-547
          f.base_currency as settl_currency,
          f.rate_value
     from dwf_fx_rate f
     join inst i
       on f.institution_id = i.id
     join dwd_fx_rate_type d
       on d.id = f.fx_rate_type_id
      and d.record_state   = 'A'
    where f.banking_Date   = to_date(:P_BANKING_DATE,'DD-MM-YYYY')
      and d.fx_type_code   = 'D'
      and d.rate_type_code = 'M'
      and base_currency    = i.local_currency
      and quote_currency   = (select min(code) from dwd_currency where name = 'USD' and record_state ='A')
    )

    select i.branch_Code as org,
           'D'
         ||rpad(cis.workflow_xcd,16,' ')
         ||rpad('CIS20',8,' ')
         ||rpad('2.0',5,' ')
         ||rpad(cis.client_xid,16,' ')
--[*] begin 230904.1 = OPKSAIC-5547
--         ||rpad(to_char(sysdate,'HHMMSS'),6,'0')
--         ||rpad(to_char(sysdate,'SS')*1000,3,'0')
--         ||rpad(to_char(sysdate,'yyyymmdd'),8,'0')
--         ||'+04.00'
--[*] begin 231108.1 = PRD-25567
         ||TO_CHAR(
         FROM_TZ(
           TO_TIMESTAMP(SUBSTR(TO_CHAR(SYSTIMESTAMP, 'YYYYMMDDHH24MISSFFtzh:tzm'),1,17), 'YYYYMMDDHH24MISSFFtzh:tzm'),
           substr(TO_CHAR(SYSTIMESTAMP, 'tzh:tzm'),1,7)
         ) AT TIME ZONE NVL(:P_TZ, substr(TO_CHAR(SYSTIMESTAMP, 'tzh:tzm'),1,7)), 
         'YYYYMMDDHH24MISSFF3tzh.tzm'
         )
--[*] end 231108.1 = PRD-25567
--[*] end 230904.1 = OPKSAIC-5547
         ||rpad(nvl(decode(sy_convert.get_tag_value(i.add_info,'CAF_EXPORT_CLIENT_ID'),'Y',cis.customer_xid,cl.CLIENT_NUMBER),' '),20,' ')--[*] 230901.1 = Santosh = NICORE-788 : Change to populate client number
         ||rpad(cis.account_reference_xid,40,' ')
         ||'WY4CIS'||lpad(opt_cis_file_seq.nextval,26,'0')
         ||rpad(nvl(cis.customer_type_xcd,' ') ,1,' ')
         ||rpad(cis.vip_xflg,1,' ')
         ||rpad(nvl(cis.relation_start_dt,' '),8,' ')
         ||rpad(cis.accounts_cnt,5,' ')
         ||rpad(cis.first_name,30,' ')
         ||rpad(cis.middle_name,30,' ')
         ||rpad(cis.last_name,60,' ')
         ||rpad(cis.prefix_name,10,' ')
         ||rpad(cis.suffix_name,10,' ')
         ||rpad(cis.preferred_greeting,60,' ')
         ||rpad(cis.preferred_language,3,' ')
         ||rpad(cis.mothers_maiden_name,60,' ')
         ||rpad(cis.household_name,60,' ')
         -- [+] begin 20230214 - ETSLT-247 - Santosh - Changes to replace non ascii chars
         --||rpad(cis.address_line_1_strg,40,' ')
         --||rpad(cis.address_line_2_strg,40,' ')
         --||rpad(cis.address_line_3_strg,40,' ')
         --||rpad(cis.address_line_4_strg,40,' ')
         ||rpad(REGEXP_REPLACE (cis.address_line_1_strg,'[^ -~|[:space:]]', '*'),40,' ')
         ||rpad(REGEXP_REPLACE (cis.address_line_2_strg,'[^ -~|[:space:]]', '*'),40,' ')
         ||rpad(REGEXP_REPLACE (cis.address_line_3_strg,'[^ -~|[:space:]]', '*'),40,' ')
         ||rpad(REGEXP_REPLACE (cis.address_line_4_strg,'[^ -~|[:space:]]', '*'),40,' ')
         -- [+] end 20230214 - ETSLT-247 - Santosh - Changes to replace non ascii chars
         ||rpad(cis.city_name,40,' ')
         ||rpad(cis.country_region_xcd,3,' ')
         ||rpad(cis.postal_xcd,10,' ')
         ||rpad(cis.country_xcd,3,' ')
         ||rpad(nvl(cis.residence_status_xcd,' '),1,' ')
         ||rpad(cis.address_effective_from_dt,8,' ')
         ||rpad(cis.address2_type_xcd,1,' ')
         -- [+] begin 20230214 - ETSLT-247 - Santosh - Changes to replace non ascii chars
         --||rpad(cis.address2_line_1_strg,40,' ')
         --||rpad(cis.address2_line_2_strg,40,' ')
         --||rpad(cis.address2_line_3_strg,40,' ')
         --||rpad(cis.address2_line_4_strg,40,' ')
         ||rpad(REGEXP_REPLACE (cis.address2_line_1_strg,'[^ -~|[:space:]]', '*'),40,' ')
         ||rpad(REGEXP_REPLACE (cis.address2_line_2_strg,'[^ -~|[:space:]]', '*'),40,' ')
         ||rpad(REGEXP_REPLACE (cis.address2_line_3_strg,'[^ -~|[:space:]]', '*'),40,' ')
         ||rpad(REGEXP_REPLACE (cis.address2_line_4_strg,'[^ -~|[:space:]]', '*'),40,' ')
         -- [+] end 20230214 - ETSLT-247 - Santosh - Changes to replace non ascii chars
         ||rpad(cis.city2_name,40,' ')
         ||rpad(cis.country_region2_xcd,3,' ')
         ||rpad(cis.postal2_xcd,10,' ')
         ||rpad(cis.country2_xcd,3,' ')
         ||rpad(cis.business_name,60,' ')
         -- [+] begin 20230214 - ETSLT-247 - Santosh - Changes to replace non ascii chars
         --||rpad(cis.work_address_line_1_strg,40,' ')
         --||rpad(cis.work_address_line_2_strg,40,' ')
         --||rpad(cis.work_address_line_3_strg,40,' ')
         --||rpad(cis.work_address_line_4_strg,40,' ')         
         ||rpad(REGEXP_REPLACE (cis.work_address_line_1_strg,'[^ -~|[:space:]]', '*'),40,' ')
         ||rpad(REGEXP_REPLACE (cis.work_address_line_2_strg,'[^ -~|[:space:]]', '*'),40,' ')
         ||rpad(REGEXP_REPLACE (cis.work_address_line_3_strg,'[^ -~|[:space:]]', '*'),40,' ')
         ||rpad(REGEXP_REPLACE (cis.work_address_line_4_strg,'[^ -~|[:space:]]', '*'),40,' ')
         -- [+] end 20230214 - ETSLT-247 - Santosh - Changes to replace non ascii chars
         ||rpad(cis.work_city_name,40,' ')
         ||rpad(cis.work_country_region_xcd,3,' ')
         ||rpad(cis.work_postal_xcd,10,' ')
         ||rpad(cis.work_country_xcd,3,' ')
         ||rpad(nvl(cis.employment_status_xcd,' '),3,' ')
         ||rpad(cis.employment_status_dt,8,' ')
         ||rpad(cis.employer_merchant_cat_xcd,4,' ')
         ||rpad(cis.occupation_xcd,4,' ')
         ||rpad(cis.income_amt,16,' ')
         ||rpad(cis.currency_xcd,3,' ')
         ||rpad(nvl(to_char(c.rate_value),' '),13,' ')
         ||rpad(cis.home_phone_num,24,' ')
         ||rpad(cis.phone2_num,24,' ')
         ||rpad(cis.work_phone_num,24,' ')
         ||rpad(cis.cell_phone_num,24,' ')
         ||rpad(cis.preferred_phone_xcd,1,' ')
         ||rpad(cis.email_address,40,' ')
         ||rpad(cis.educational_status_xcd,1,' ')
         ||rpad(cis.customer_birth_dt,8,' ')
         ||rpad(cis.birth_country_xcd,3,' ')
         ||rpad(cis.citizenship_country_xcd,3,' ')
         ||rpad(cis.national_xid,16,' ')
         ||rpad(cis.national_country_xcd,3,' ')
         ||rpad(cis.passport_xid,16,' ')
         ||rpad(cis.passport_country_xcd,3,' ')
         ||rpad(cis.passport_expiration_dt,8,' ')
         ||rpad(cis.drivers_license_xid,16,' ')
         ||rpad(cis.driver_license_country_xcd,3,' ')
         ||rpad(cis.tax_xid,16,' ')
         ||rpad(cis.tax_country_xcd,3,' ')
         ||rpad(cis.customer_gender_xcd,1,' ')
         ||rpad(cis.person_marital_status_xcd,1,' ')
         ||rpad(cis.dependents_cnt,2,' ')
         ||rpad(cis.credit_scr,4,' ')
         ||rpad(cis.credit_score_dt,8,' ')
         ||rpad(cis.credit_score_source,20,' ')
         ||rpad(cis.credit_scr_request_reason_xcd,1,' ')
         ||rpad(cis.credit_rating,4,' ')
         ||exposed_foregin_person_xflg
         ||foreign_assets_control_xflg
         ||behavior_1_scr
         ||behavior_2_scr
         ||segment1_xid
         ||segment2_xid
         ||segment3_xid
         ||segment4_xid
         ||user_indicator_1_xcd
         ||user_indicator_2_xcd
         ||user_indicator_3_xcd
         ||user_indicator_4_xcd
         ||user_indicator_5_xcd
         ||user1_xcd
         ||user2_xcd
         ||user3_xcd
         ||user4_xcd
         ||user5_xcd
         ||user_data_1_strg
         ||user_data_2_strg
         ||user_data_3_strg
         ||user_data_4_strg
         ||user_data_5_strg
         ||user_data_6_num
         ||user_data_7_strg
         ||user_data_8_strg
         ||user_data_9_strg
         ||user_data_10_strg
         ||user_data_11_strg
         ||user_data_12_strg
         ||user_data_13_strg
         ||user_data_14_strg
         ||user_data_15_strg
         ||reserved_01 as data

      from opt_v_falcon_cis cis
      join client_list i
        on trim(cis.client_xid) = trim(i.client_xid)
		
	 join dwd_client cl on cl.record_idt =  to_number(trim(cis.customer_xid))
		  and cl.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
		  and cl.record_date_to   >= to_date(:P_BANKING_DATE,'DD-MM-YYYY') 
		  and cl.institution_id = i.id  --240216.1 KhaledO : Removed the left join on the client and made it inner 
 left join conversion_rates c
        on c.settl_currency = cis.currency_xcd

and i.id=c.institution_id --[+] 230908.1 = IB-547
--[*]BEGIN 230904.1 = Santosh = NICORE-788 : condition update
--[+] BEGIN 230901.1 = Santosh = NICORE-788 : Change to populate client number		
