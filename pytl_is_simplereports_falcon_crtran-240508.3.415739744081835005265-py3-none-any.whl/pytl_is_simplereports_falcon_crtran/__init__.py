__version__ = "240508.3"
__job_name__ = "PyTL_IS_SimpleReports_FALCON_CRTRAN"
__bat_files__ = ["NIC_IS_Ou_FalconReports.bat"]

