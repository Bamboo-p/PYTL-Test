/*
18-04-2022 - OPKSAIC-3209 - Santosh - Falcon CRTRAN report initial version
230217.7 = deniska = NICORE-143: replace TABs with SPACEs. Trim trailing spaces.
230901.1 = Santosh = NICORE-788 : Change to populate client number
230904.1 = Santosh = NICORE-788 : condition update
230908.1 = Shalini = IB-547: Logic changes to get common report for all clients under particular Tenant
230926.1 = BharathG = D2C-339: Typo correction
240221.1 = KhaledO : AJM-5055 : Modified the client join
240305.1 = KhaledO :AJM-5053  Added P_TZ Praram instead of fixed TZ
*/
with client_list as (
    select /*+ no_merge materialize */
          v.code as client_xid,
          v.name,
          v.add_info as tenant_name,
          inst.id,
          inst.branch_code,
		  inst.add_info --[+] 230901.1 = Santosh = NICORE-788 : Change to populate client number
     from sy_conf_group g
     join sy_conf_group_val v
       on v.amnd_state = 'A'
      and g.id = v.sy_conf_group__oid
     join sy_conf_group_rec r
       on r.amnd_state = 'A'
      and r.value_id = v.id
     join dwd_institution inst
       on inst.id = r.table_rec_id
    where g.code = 'CLIENT_BANK_ID'
      and g.group_code = 'FALCON_BATCH_FEED'
      and inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                 from dual
                           connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
    ),
inst as (
    select /*+ no_merge materialize */
          id,
          branch_code,
          name inst_name,
          local_currency
     from (select dwd_institution.branch_code,
                  dwd_institution.posting_institution_id,
                  dwd_institution.id,
                  dwd_institution.local_currency,
                  dwd_institution2.branch_code branch_code_posting,
                  dwd_institution.name
             from dwd_institution
             join dwd_institution dwd_institution2
               on dwd_institution.posting_institution_id = dwd_institution2.id
            where dwd_institution.record_state = 'A'
           ) inst
       start with inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                         from dual
                                   connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
                                      )
                            connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
    ),
conversion_rates as (
    select /*+no_merge materialize*/
          i.id as institution_id, --[+] 230908.1 = IB-547
          f.base_currency as settl_currency,
          f.rate_value
     from dwf_fx_rate f
     join inst i
       on f.institution_id = i.id
     join dwd_fx_rate_type d
       on d.id = f.fx_rate_type_id
      and d.record_state   = 'A'
    where f.banking_Date   = to_date(:P_BANKING_DATE,'DD-MM-YYYY')
      and d.fx_type_code   = 'D'
      and d.rate_type_code = 'M'
      and base_currency    = i.local_currency
      and quote_currency   = (select min(code) from dwd_currency where name = 'USD' and record_state ='A')
    )

select i.branch_Code as ORG,
       'D'
     ||rpad(crtran.workflow_xcd,16,' ')
     ||rpad('CRTRAN25',8,' ')
     ||rpad('2.5',5,' ')
     ||rpad(crtran.client_xid,16,' ')
--     ||rpad(to_char(sysdate,'yyyymmdd'),8,'0')
--     ||rpad(to_char(sysdate,'HHMMSS'),6,'0')
--     ||rpad(to_char(sysdate,'SS')*1000,3,'0')
--     ||rpad('4',6,' ')
		--AJM-5053 : KhaledO : Added P_TZ Praram instead of fixed TZ
     ||TO_CHAR(
         FROM_TZ(
           TO_TIMESTAMP(SUBSTR(TO_CHAR(SYSTIMESTAMP, 'YYYYMMDDHH24MISSFFtzh:tzm'),1,17), 'YYYYMMDDHH24MISSFFtzh:tzm'),
           substr(TO_CHAR(SYSTIMESTAMP, 'tzh:tzm'),1,7)
         ) AT TIME ZONE NVL(:P_TZ, substr(TO_CHAR(SYSTIMESTAMP, 'tzh:tzm'),1,7)), 
         'YYYYMMDDHH24MISSFF3tzh.tzm'
       )
     ||rpad(nvl(decode(sy_convert.get_tag_value(i.add_info,'CAF_EXPORT_CLIENT_ID'),'Y',crtran.customer_xid,cl.CLIENT_NUMBER),' '),20,' ')--[*] 230901.1 = Santosh = NICORE-788 : Change to populate client number
     ||rpad(nvl(crtran.account_reference_xid,' '),40,' ')
     ||'WY4CRT'||lpad(opt_crtran_file_seq.nextval,26,'0')
     ||rpad(crtran.score_customer_account_xid,19,'0')
     ||rpad(crtran.authorization_posting_xcd,1,' ')
     ||rpad(crtran.CARD_POSTAL_XCD,9,' ')
     ||rpad(crtran.CARD_COUNTRY_XCD,3,' ')
     ||rpad(crtran.CARD_OPEN_DT,8,' ')
     ||rpad(crtran.CARD_ISSUE_DT,8,' ')
     ||rpad(crtran.CARD_ISSUE_TYPE_XCD,1,' ')
     ||rpad(crtran.ACCOUNT_EXPIRATION_DT,8,' ')
     ||rpad(nvl(crtran.card_expiration_dt, '        '),8,' ')
     ||rpad(crtran.PRIOR_CREDIT_LIMIT_AMT,10,' ')
     ||rpad(crtran.CARD_CREDIT_LIMIT_AMT,10,' ')
     ||rpad(crtran.customer_gender_xcd,1,' ')
     ||rpad(crtran.CUSTOMER_BIRTH_DT,8,' ')
     ||rpad(crtran.CUSTOMER_CARD_CNT,3,' ')
     ||rpad(crtran.INCOME_AMT,10,' ')
     ||rpad(crtran.CARD_TYPE_XCD,1,' ')
     ||rpad(crtran.PRIMARY_CARD_USE_XCD,1,' ')
     ||rpad(crtran.TRANSACTION_DTM,8,' ')
     ||rpad(crtran.TRANSACTION_TTM,6,' ')
     ||rpad(crtran.transaction_amt,13,' ')
     ||rpad(crtran.transaction_iso_currency_xcd,3,' ')
     ||rpad(c.rate_value, 13, ' ')
     ||rpad(crtran.decision_xcd, 1, ' ')
     ||rpad(crtran.transaction_type_xcd, 1, ' ')
     ||rpad(crtran.merchant_category_xcd, 4, ' ')
     ||rpad(crtran.MERCHANT_POSTAL_XCD, 9, ' ')
     ||rpad(crtran.merchant_country_xcd, 3, ' ')
     ||rpad(crtran.transaction_pin_verify_xcd, 1, ' ')
     ||rpad(crtran.CVV_VERIFY_XCD, 1, ' ')
     ||rpad(crtran.transaction_posting_entry_xflg, 1, ' ')
     ||rpad(crtran.transaction_posting_dt, 8, ' ')
     ||rpad(crtran.authorization_posting_mis_xcd, 1, ' ')
     ||rpad(crtran.TRANS_POSTING_MISMATCH_XFLG, 1, ' ')
     ||rpad(crtran.CREATE_CASE_XFLG, 1, ' ')
     ||rpad(crtran.USER_INDICATOR_1_XCD, 1, ' ')
     ||rpad(crtran.USER_INDICATOR_2_XCD, 1, ' ')
     ||rpad(crtran.USER_DATA_1_STRG, 10, ' ')
     ||rpad(crtran.USER_DATA_2_STRG, 10, ' ')
     ||rpad(crtran.MERCHANT_XID_DEPRICATED, 10, ' ')
     ||rpad(crtran.MERCHANT_DATA_XFLG, 1, ' ')
     ||rpad(crtran.CARD_DATA_AVAILABLE_XFLG, 1, ' ')
     ||rpad(crtran.EXTERNAL_1_SCR, 4, ' ')
     ||rpad(crtran.EXTERNAL_2_SCR, 4, ' ')
     ||rpad(crtran.EXTERNAL_3_SCR, 4, ' ')
     ||rpad(crtran.cardholder_present_xflg, 1, ' ')
     ||rpad(crtran.cat_type_xflg, 1, ' ')
     ||rpad(crtran.TESTING_RANDOM_DIGITS_STRG, 2, ' ')
     ||rpad(crtran.portfolio_name, 14, ' ')
     ||rpad(crtran.client_2_xid, 14, ' ')
     ||rpad(crtran.INTERBANK_CARD_ASSOCIATION_NUM, 6, ' ')
     ||rpad(crtran.merchant_name, 40, ' ')
     ||rpad(crtran.merchant_city_name, 30, ' ')
     ||rpad(crtran.merchant_state_xcd, 3, ' ')
     ||rpad(crtran.SUPPRES_CASE_XFLG, 1, ' ')
     ||rpad(crtran.USER_INDICATOR_3_XCD, 5, ' ')
     ||rpad(crtran.USER_INDICATOR_4_XCD, 5, ' ')
     ||rpad(crtran.USER_DATA_3_STRG, 15, ' ')
     ||rpad(crtran.USER_DATA_4_STRG, 20, ' ')
     ||rpad(crtran.USER_DATA_5_STRG, 40, ' ')
     ||rpad(crtran.REAL_TIME_REQUEST_XFLG, 1, ' ')
     ||rpad(crtran.PRIOR_ACTION_DATABASE_XCD, 1, ' ')
     ||rpad(crtran.PRIOR_ACTION_DB_EXPIRATION_DT, 8, ' ')
     ||rpad(crtran.master_account_number_xid, 19, ' ')
     ||rpad(crtran.CARD_OFFLN_STATIC_AUTHCTN_XFLG, 1, ' ')
     ||rpad(crtran.CARD_DYNAMIC_AUTHCTN_XCD, 1, ' ')
     ||rpad(crtran.RESERVED_02, 1, ' ')
     ||rpad(crtran.CARD_AIP_VERIFICATION_XFLG, 1, ' ')
     ||rpad(crtran.CARD_AIP_RISK_XFLG, 1, ' ')
     ||rpad(crtran.CARD_ISSUER_AUTH_SUPPORT_XFLG, 1, ' ')
     ||rpad(crtran.CARD_COMBINED_AUTHCTN_XFLG, 1, ' ')
     ||rpad(crtran.TRANSACTION_DELINQUENT_CYC, 1, ' ')
     ||rpad(crtran.TRANS_TOTAL_DELINQUENT_AMT, 13, ' ')
     ||rpad(crtran.CRD_STATEMENT_CASH_BALANCE_AMT, 13, ' ')
     ||rpad(crtran.MERCHANT_BALANCE_AMT, 13, ' ')
     ||rpad(crtran.CARD_PAYMENT_HISTORY_XCD, 12, ' ')
     ||rpad(crtran.CARD_MEDIA_TYPE_XCD, 1, ' ')
     ||rpad(crtran.CVV2_PRESENT_XFLG, 1, ' ')
     ||rpad(crtran.CVV2_RESPONSE_XFLG, 1, ' ')
     ||rpad(crtran.AVS_RESPONSE_XCD, 1, ' ')
     ||rpad(crtran.transaction_category_xcd, 1, ' ')
     ||rpad(crtran.acquirer_xid, 12, ' ')
     ||rpad(crtran.acquirer_country_xcd, 3, ' ')
     ||rpad(crtran.terminal_xid, 16, ' ')
     ||rpad(crtran.terminal_type_xcd, 1, ' ')
     ||rpad(crtran.terminal_entry_capability_xcd, 1, ' ')
     ||rpad(crtran.TRANSACTION_POS_CONDITION_XCD, 2, ' ')
     ||rpad(crtran.atm_network_xid, 1, ' ')
     ||rpad(crtran.RESERVED_01, 1, ' ')
     ||rpad(crtran.CHECK_NUM, 6, ' ')
     ||rpad(crtran.terml_verification_results_xcd, 10, ' ')
     ||rpad(crtran.card_verification_results_xcd, 10, ' ')
     ||rpad(crtran.AUTHZN_RQST_CRYPTO_VALID_XFLG, 1, ' ')
     ||rpad(crtran.ATC_CARD_CNT, 5, ' ')
     ||rpad(crtran.ATC_HOST_CNT, 5, ' ')
     ||rpad(crtran.RESERVED_03, 2, ' ')
     ||rpad(crtran.TERML_TO_CRD_OFFLINE_LIMIT_XCD, 2, ' ')
     ||rpad(crtran.TERMINAL_OFFLINE_LIMIT_MAX_XCD, 2, ' ')
     ||rpad(crtran.RECURRING_AUTHORIZATION_XCD, 2, ' ')
     ||rpad(crtran.RECURRING_AUTHZN_EXPIRATION_DT, 8, ' ')
     ||rpad(crtran.CARD_ASSOCIATION_XFLG, 1, ' ')
     ||rpad(crtran.CARD_INCENTIVE_XCD, 1, ' ')
     ||rpad(crtran.CARD_STATUS_XCD, 2, ' ')
     ||rpad(crtran.CARD_STATUS_DT, 8, ' ')
     ||rpad(crtran.PROCESSOR_REASON_XCD, 5, ' ')
     ||rpad(crtran.TRANSACTION_ADVICE_XCD, 1, ' ')
     ||rpad(crtran.merchant_xid, 16, ' ')
     ||rpad(crtran.CARD_ORDER_TYPE_XCD, 1, ' ')
     ||rpad(crtran.TRANSACTION_CASHBACK_AMT, 13, ' ')
     ||rpad(crtran.USER_DATA_6_NUM, 13, ' ')
     ||rpad(crtran.USER_DATA_7_STRG, 40, ' ')
     ||rpad(crtran.payment_instrument_xid, 30, ' ')
     ||rpad(crtran.AVS_REQUEST_XCD, 1, ' ')
     ||rpad(crtran.CVR_OFFLINEPIN_VERIFYPERF_XFLG, 1, ' ')
     ||rpad(crtran.CVR_OFFLINEPIN_VERIFYSTAT_XFLG, 1, ' ')
     ||rpad(crtran.CVR_PIN_TRYLIMIT_EXCEED_XFLG, 1, ' ')
     ||rpad(crtran.pos_terminal_attend_xflg, 1, ' ')
     ||rpad(crtran.pos_off_premises_xflg, 1, ' ')
     ||rpad(crtran.pos_card_capture_xflg, 1, ' ')
     ||rpad(crtran.POS_SECURITY_XFLG, 1, ' ')
     ||rpad(nvl(crtran.authorization_xid,'      '), 6, ' ')
     ||rpad(crtran.USER_DATA_8_STRG, 10, ' ')
     ||rpad(crtran.USER_DATA_9_STRG, 10, ' ')
     ||rpad(crtran.USER_INDICATOR_5_XCD, 1, ' ')
     ||rpad(crtran.USER_INDICATOR_6_XCD, 1, ' ')
     ||rpad(crtran.USER_INDICATOR_7_XCD, 5, ' ')
     ||rpad(crtran.USER_INDICATOR_8_XCD, 5, ' ')
     ||rpad(crtran.MODEL_CONTROL_1_XCD, 1, ' ')
     ||rpad(crtran.MODEL_CONTROL_2_XCD, 1, ' ')
     ||rpad(crtran.MODEL_CONTROL_3_XCD, 1, ' ')
     ||rpad(crtran.MODEL_CONTROL_4_XCD, 1, ' ')
     ||rpad(crtran.AUTHORIZATION_EXPIRE_DT_XFLG, 1, ' ')
     ||rpad(crtran.AUTH_SECONDARY_VERIFY_XCD, 1, ' ')
     ||rpad(crtran.authorization_response_xcd, 1, ' ')
     ||rpad(crtran.SEGMENT1_XID, 6, ' ')
     ||rpad(crtran.SEGMENT2_XID, 6, ' ')
     ||rpad(crtran.SEGMENT3_XID, 6, ' ')
     ||rpad(crtran.SEGMENT4_XID, 6, ' ')
      as data

  from opt_v_falcon_crtran crtran
  join client_list i
    on trim(crtran.client_xid) = trim(i.client_xid)
left join conversion_rates c
    on c.settl_currency = crtran.transaction_iso_currency_xcd
and i.id=c.institution_id --[+] 230908.1 = IB-547
--[*]BEGIN 230904.1 = Santosh = NICORE-788 : condition update	
--[+] BEGIN 230901.1 = Santosh = NICORE-788 : Change to populate client number		
 join dwd_client cl on cl.record_idt =  to_number(trim(crtran.customer_xid))
      and cl.institution_id = i.id 
	  and cl.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
        and cl.record_date_to   >= to_date(:P_BANKING_DATE,'DD-MM-YYYY') 
--[+] END 230901.1 = Santosh = NICORE-788 : Change to populate client number	
--[*]END 230904.1 = Santosh = NICORE-788 : condition update;