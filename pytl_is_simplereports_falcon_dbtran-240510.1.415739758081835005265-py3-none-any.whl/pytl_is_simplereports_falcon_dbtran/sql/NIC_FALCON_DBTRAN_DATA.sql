/*
20240328 - NICORE-1305 - Santosh - Falcon DBTRAN report initial version
20240510.1 - NICORE-1305 - Santosh - Fields correction
*/
with client_list as (
    select /*+ no_merge materialize */
          v.code as client_xid,
          v.name,
          v.add_info as tenant_name,
          inst.id,
          inst.branch_code,
		  inst.add_info 
     from sy_conf_group g
     join sy_conf_group_val v
       on v.amnd_state = 'A'
      and g.id = v.sy_conf_group__oid
     join sy_conf_group_rec r
       on r.amnd_state = 'A'
      and r.value_id = v.id
     join dwd_institution inst
       on inst.id = r.table_rec_id
    where g.code = 'CLIENT_BANK_ID'
      and g.group_code = 'FALCON_BATCH_FEED'
      and inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                 from dual
                           connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
    ),
inst as (
    select /*+ no_merge materialize */
          id,
          branch_code,
          name inst_name,
          local_currency
     from (select dwd_institution.branch_code,
                  dwd_institution.posting_institution_id,
                  dwd_institution.id,
                  dwd_institution.local_currency,
                  dwd_institution2.branch_code branch_code_posting,
                  dwd_institution.name
             from dwd_institution
             join dwd_institution dwd_institution2
               on dwd_institution.posting_institution_id = dwd_institution2.id
            where dwd_institution.record_state = 'A'
           ) inst
       start with inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                         from dual
                                   connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
                                      )
                            connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
    ),
conversion_rates as (
    select /*+no_merge materialize*/
          i.id as institution_id, 
          f.base_currency as settl_currency,
          f.rate_value
     from dwf_fx_rate f
     join inst i
       on f.institution_id = i.id
     join dwd_fx_rate_type d
       on d.id = f.fx_rate_type_id
      and d.record_state   = 'A'
    where f.banking_Date   = to_date(:P_BANKING_DATE,'DD-MM-YYYY')
      and d.fx_type_code   = 'D'
      and d.rate_type_code = 'M'
      and base_currency    = i.local_currency
      and quote_currency   = (select min(code) from dwd_currency where name = 'USD' and record_state ='A')
    )

select i.branch_Code as ORG,
       'D'
     ||rpad(dbtran.workflow_xcd,16,' ')
     ||rpad('DBTRAN25',8,' ')
     ||rpad('2.5',5,' ')
     ||rpad(dbtran.client_xid,16,' ')
     ||TO_CHAR(
         FROM_TZ(
           TO_TIMESTAMP(SUBSTR(TO_CHAR(SYSTIMESTAMP, 'YYYYMMDDHH24MISSFFtzh:tzm'),1,17), 'YYYYMMDDHH24MISSFFtzh:tzm'),
           substr(TO_CHAR(SYSTIMESTAMP, 'tzh:tzm'),1,7)
         ) AT TIME ZONE NVL(:P_TZ, substr(TO_CHAR(SYSTIMESTAMP, 'tzh:tzm'),1,7)), 
         'YYYYMMDDHH24MISSFF3tzh.tzm'
       )
     ||rpad(nvl(decode(sy_convert.get_tag_value(i.add_info,'CAF_EXPORT_CLIENT_ID'),'Y',dbtran.customer_xid,cl.CLIENT_NUMBER),' '),20,' ')
     ||rpad(nvl(dbtran.account_reference_xid,' '),40,' ')
     ||'WY4DBT'||lpad(opt_dbtran_file_seq.nextval,26,'0')
     ||rpad(dbtran.score_customer_account_xid,19,'0')
     ||rpad(dbtran.authorization_posting_xcd,1,' ')
     ||rpad(dbtran.CARD_POSTAL_XCD,9,' ')
     ||rpad(dbtran.CARDSEQNUM,3,' ')
     ||rpad(dbtran.CARD_OPEN_DT,8,' ')
     ||rpad(dbtran.CARD_ISSUE_DT,8,' ')
     ||rpad(dbtran.CARD_ISSUE_TYPE_XCD,1,' ')
     ||rpad(dbtran.ACCOUNT_EXPIRATION_DT,8,' ')
     ||rpad(nvl(dbtran.CARD_EXPIRATION_DT, '        '),8,' ')
     ||rpad(dbtran.EXPANDEDBIN,10,' ')
     ||rpad(dbtran.DAILY_CASH_LIMIT,10,' ')
     ||rpad(dbtran.customer_gender_xcd,1,' ')
     ||rpad(dbtran.TOKEN_EXPIRATION_DATE,8,' ')
     ||rpad(dbtran.CONSUMER_AUTHENTICATION_SCORE,3,' ')
     ||rpad(dbtran.INCOME_AMT,10,' ')
     ||rpad(dbtran.CAVV,1,' ')
     ||rpad(dbtran.PEERGROUPING,1,' ')
     ||rpad(dbtran.TRANSACTION_DTM,8,' ')
     ||rpad(dbtran.TRANSACTION_TTM,6,' ')
     ||rpad(dbtran.transaction_amt,13,' ')
     ||rpad(dbtran.transaction_iso_currency_xcd,3,' ')
     ||rpad(c.rate_value, 13, ' ')
     ||rpad(dbtran.decision_xcd, 1, ' ')
     ||rpad(dbtran.transaction_type_xcd, 1, ' ')
     ||rpad(dbtran.merchant_category_xcd, 4, ' ')
     ||rpad(dbtran.MERCHANT_POSTAL_XCD, 9, ' ')
     ||rpad(dbtran.merchant_country_xcd, 3, ' ')
     ||rpad(dbtran.transaction_pin_verify_xcd, 1, ' ')
     ||rpad(dbtran.CVV_VERIFY_XCD, 1, ' ')
     ||rpad(dbtran.transaction_posting_entry_xflg, 1, ' ')
     ||rpad(dbtran.transaction_posting_dt, 8, ' ')
     ||rpad(dbtran.authorization_posting_mis_xcd, 1, ' ')
     ||rpad(dbtran.TRANS_POSTING_MISMATCH_XFLG, 1, ' ')
     ||rpad(dbtran.CREATE_CASE_XFLG, 1, ' ')
     ||rpad(dbtran.USER_INDICATOR_1_XCD, 1, ' ')
     ||rpad(dbtran.USER_INDICATOR_2_XCD, 1, ' ')
     ||rpad(dbtran.USER_DATA_1_STRG, 10, ' ')
     ||rpad(dbtran.USER_DATA_2_STRG, 10, ' ')
     ||rpad(dbtran.MERCHANT_XID_DEPRICATED, 10, ' ')
     ||rpad(dbtran.MERCHANT_DATA_XFLG, 1, ' ')
     ||rpad(dbtran.ID_METHOD, 1, ' ')
     ||rpad(dbtran.EXTERNAL_1_SCR, 4, ' ')
     ||rpad(dbtran.EXTERNAL_2_SCR, 4, ' ')
     ||rpad(dbtran.EXTERNAL_3_SCR, 4, ' ')
     ||rpad(dbtran.cardholder_present_xflg, 1, ' ')
     ||rpad(dbtran.cat_type_xflg, 1, ' ')
     ||rpad(dbtran.TESTING_RANDOM_DIGITS_STRG, 2, ' ')
     ||rpad(dbtran.portfolio_name, 14, ' ')
     ||rpad(dbtran.client_2_xid, 14, ' ')
     ||rpad(dbtran.INTERBANK_CARD_ASSOCIATION_NUM, 6, ' ')
     ||rpad(dbtran.merchant_name, 40, ' ')
     ||rpad(dbtran.merchant_city_name, 30, ' ')
     ||rpad(dbtran.merchant_state_xcd, 3, ' ')
     ||rpad(dbtran.SUPPRES_CASE_XFLG, 1, ' ')
     ||rpad(dbtran.USER_INDICATOR_3_XCD, 5, ' ')
     ||rpad(dbtran.USER_INDICATOR_4_XCD, 5, ' ')
     ||rpad(dbtran.USER_DATA_3_STRG, 15, ' ')
     ||rpad(dbtran.USER_DATA_4_STRG, 20, ' ')
     ||rpad(dbtran.USER_DATA_5_STRG, 40, ' ')
     ||rpad(dbtran.REAL_TIME_REQUEST_XFLG, 1, ' ')
     ||rpad(dbtran.PAD_RESPONSE, 1, ' ')
     ||rpad(dbtran.PAD_ACTION_EXPIRE_DATE, 8, ' ')
     ||rpad(dbtran.master_account_number_xid, 19, ' ')
     ||rpad(dbtran.CARD_OFFLN_STATIC_AUTHCTN_XFLG, 1, ' ')
     ||rpad(dbtran.CARD_DYNAMIC_AUTHCTN_XCD, 1, ' ')
     ||rpad(dbtran.RESERVED_01, 1, ' ')
     ||rpad(dbtran.AUTHEXPIREDATEVERIFY, 1, ' ')
     ||rpad(dbtran.AUTHSECONDARYVERIFY, 1, ' ')
     ||rpad(dbtran.AUTHBENEFICIARY, 1, ' ')
     ||rpad(dbtran.authorization_response_xcd, 1, ' ')
     ||rpad(dbtran.AUTH_INDICATOR, 1, ' ')
     ||rpad(dbtran.AUTHCARDISSUER, 13, ' ')
     ||rpad(dbtran.CRD_STATEMENT_CASH_BALANCE_AMT, 13, ' ')
     ||rpad(dbtran.MERCHANT_BALANCE_AMT, 13, ' ')
     ||rpad(dbtran.CARD_PAYMENT_HISTORY_XCD, 12, ' ')
     ||rpad(dbtran.CARD_MEDIA_TYPE_XCD, 1, ' ')
     ||rpad(dbtran.CVV2_PRESENT_XFLG, 1, ' ')
     ||rpad(dbtran.CVV2_RESPONSE_XFLG, 1, ' ')
     ||rpad(dbtran.AVS_RESPONSE_XCD, 1, ' ')
     ||rpad(dbtran.transaction_category_xcd, 1, ' ')
     ||rpad(dbtran.acquirer_xid, 12, ' ')
     ||rpad(dbtran.acquirer_country_xcd, 3, ' ')
     ||rpad(dbtran.terminal_xid, 16, ' ')
     ||rpad(dbtran.terminal_type_xcd, 1, ' ')
     ||rpad(dbtran.terminal_entry_capability_xcd, 1, ' ')
     ||rpad(dbtran.TRANSACTION_POS_CONDITION_XCD, 2, ' ')
     ||rpad(dbtran.atm_network_xid, 1, ' ')
     ||rpad(dbtran.RESERVED_02, 1, ' ')
     ||rpad(dbtran.CHECK_NUM, 3, ' ')
	 ||rpad(dbtran.authorization_response_xcd, 1, ' ')
	 ||rpad(dbtran.AUTH_REVERSAL_REASON, 1, ' ')
	 ||rpad(dbtran.AUTH_CARD_ISSUER, 1, ' ')
     ||rpad(dbtran.terml_verification_results_xcd, 10, ' ')
     ||rpad(dbtran.card_verification_results_xcd, 10, ' ')
     ||rpad(dbtran.AUTHZN_RQST_CRYPTO_VALID_XFLG, 1, ' ')
     ||rpad(dbtran.ATC_CARD_CNT, 5, ' ')
     ||rpad(dbtran.ATC_HOST_CNT, 5, ' ')
     ||rpad(dbtran.RESERVED_03, 2, ' ')
     ||rpad(dbtran.TERML_TO_CRD_OFFLINE_LIMIT_XCD, 2, ' ')
     ||rpad(dbtran.SECOND_FACTOR_AUTHCODE, 2, ' ')
     ||rpad(dbtran.CAVV_KEY_INDICATOR, 2, ' ')
     ||rpad(dbtran.RECURRING_AUTHZN_EXPIRATION_DT, 8, ' ')
     ||rpad(dbtran.CARD_ASSOCIATION_XFLG, 1, ' ')
     ||rpad(dbtran.CARD_INCENTIVE_XCD, 1, ' ')
     ||rpad(dbtran.ECI_INDICATOR, 2, ' ')
     ||rpad(dbtran.CARD_STATUS_DT, 8, ' ')
     ||rpad(dbtran.PROCESSOR_REASON_XCD, 5, ' ')
     ||rpad(dbtran.TRANSACTION_ADVICE_XCD, 1, ' ')
     ||rpad(dbtran.merchant_xid, 16, ' ')
     ||rpad(dbtran.CARD_ORDER_TYPE_XCD, 1, ' ')
     ||rpad(dbtran.TRANSACTION_CASHBACK_AMT, 13, ' ')
     ||rpad(dbtran.USER_DATA_6_NUM, 13, ' ')
     ||rpad(dbtran.USER_DATA_7_STRG, 40, ' ')
     ||rpad(dbtran.payment_instrument_xid, 30, ' ')
     ||rpad(dbtran.AVS_REQUEST_XCD, 1, ' ')
     ||rpad(dbtran.CVR_OFFLINEPIN_VERIFYPERF_XFLG, 1, ' ')
     ||rpad(dbtran.CVR_OFFLINEPIN_VERIFYSTAT_XFLG, 1, ' ')
     ||rpad(dbtran.CVR_PIN_TRYLIMIT_EXCEED_XFLG, 1, ' ')
     ||rpad(dbtran.pos_terminal_attend_xflg, 1, ' ')
     ||rpad(dbtran.pos_off_premises_xflg, 1, ' ')
     ||rpad(dbtran.pos_card_capture_xflg, 1, ' ')
     ||rpad(dbtran.POS_SECURITY_XFLG, 1, ' ')
     ||rpad(nvl(dbtran.authorization_xid,'      '), 6, ' ')
     ||rpad(dbtran.USER_DATA_8_STRG, 10, ' ')
     ||rpad(dbtran.USER_DATA_9_STRG, 10, ' ')
     ||rpad(dbtran.USER_INDICATOR_5_XCD, 1, ' ')
     ||rpad(dbtran.USER_INDICATOR_6_XCD, 1, ' ')
     ||rpad(dbtran.USER_INDICATOR_7_XCD, 5, ' ')
     ||rpad(dbtran.USER_INDICATOR_8_XCD, 5, ' ')
     ||rpad(dbtran.MODEL_CONTROL_1_XCD, 1, ' ')
     ||rpad(dbtran.MODEL_CONTROL_2_XCD, 1, ' ')
     ||rpad(dbtran.MODEL_CONTROL_3_XCD, 1, ' ')
     ||rpad(dbtran.MODEL_CONTROL_4_XCD, 1, ' ')
     ||rpad(dbtran.RESERVED_04, 3, ' ')
     ||rpad(dbtran.SEGMENT1_XID, 6, ' ')
     ||rpad(dbtran.SEGMENT2_XID, 6, ' ')
     ||rpad(dbtran.SEGMENT3_XID, 6, ' ')
     ||rpad(dbtran.SEGMENT4_XID, 6, ' ')
      as data

  from opt_v_falcon_dbtran dbtran
  join client_list i
    on trim(dbtran.client_xid) = trim(i.client_xid)
left join conversion_rates c
    on c.settl_currency = dbtran.transaction_iso_currency_xcd
and i.id=c.institution_id 
 join dwd_client cl on cl.record_idt =  to_number(trim(dbtran.customer_xid))
      and cl.institution_id = i.id 
	  and cl.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
        and cl.record_date_to   >= to_date(:P_BANKING_DATE,'DD-MM-YYYY') 