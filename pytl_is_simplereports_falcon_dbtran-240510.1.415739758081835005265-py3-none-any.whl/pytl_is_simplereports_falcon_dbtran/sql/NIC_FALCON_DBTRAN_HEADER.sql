/*
240328 - NICORE-1305 - Santosh - Falcon DBTRAN report initial version
*/

select 
       'B'
     ||'000000000'
     ||lpad(' ',944,' ')
     ||'1.0'
     ||'DBTRAN25'
     ||'PMAX  '
     ||'00000000' as data
  from dual
