__version__ = "240508.4"
__job_name__ = "PyTL_IS_SimpleReports_FALCON_NMON"
__bat_files__ = ["NIC_IS_Ou_FalconReports.bat"]

