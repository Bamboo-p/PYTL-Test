/*
15-04-2022 - OPKSAIC-3208 - Santosh - Falcon NMON report initial version
230217.8 = deniska = NICORE-143: replace TABs with SPACEs. Trim trailing spaces.
230825.1 = Santosh = ETSLT-363 : Removing RETURN_RBS: Reverting sqp and logic change to use product
230901.1 = Santosh = NICORE-788 : Change to populate client number
230904.1 = Santosh = NICORE-788 : condition update
230904.1 = Shalini = OPKSAIC-5570 : Added ability to change offset value as per P_TZ parameter
230904.2 = Shalini = OPKSAIC-5570 : Conflicts resolution
230908.1 = Shalini = IB-547: Logic changes to get common report for all clients under particular Tenant
231026.1 = BharathG = NICORE-923 : sql changes to populate event 1300 into file
231108.1 = Shalini = PRD-25567: Logic changes to correct milliseconds issue
240202.1 = BharathG = NICORE-937 : SQL tuning 
240221.1 = KhaledO : AJM-5055 : Modified the client join
*/
with client_list as (
    select /*+ no_merge materialize */
          v.code as client_xid,
          v.name,
          v.add_info as tenant_name,
          inst.id,
          inst.branch_code,
		  inst.add_info --[+] 230901.1 = Santosh = NICORE-788 : Change to populate client number
     from sy_conf_group g
     join sy_conf_group_val v
       on v.amnd_state = 'A'
      and g.id = v.sy_conf_group__oid
     join sy_conf_group_rec r
       on r.amnd_state = 'A'
      and r.value_id = v.id
     join dwd_institution inst
       on inst.id = r.table_rec_id
    where g.code = 'CLIENT_BANK_ID'
      and g.group_code = 'FALCON_BATCH_FEED'
      and inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                 from dual
                           connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
    ),
inst as (
    select /*+ no_merge materialize */
          id,
          branch_code,
          name inst_name,
          local_currency
     from (select dwd_institution.branch_code,
                  dwd_institution.posting_institution_id,
                  dwd_institution.id,
                  dwd_institution.local_currency,
                  dwd_institution2.branch_code branch_code_posting,
                  dwd_institution.name
             from dwd_institution
             join dwd_institution dwd_institution2
               on dwd_institution.posting_institution_id = dwd_institution2.id
            where dwd_institution.record_state = 'A'
           ) inst
       start with inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                         from dual
                                   connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
                                      )
                            connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
    ),
conversion_rates as (
    select /*+no_merge materialize*/
          i.id as institution_id, --[+] 230908.1 = IB-547
          f.base_currency as settl_currency,
          f.rate_value
     from dwf_fx_rate f
     join inst i
       on f.institution_id = i.id
     join dwd_fx_rate_type d
       on d.id = f.fx_rate_type_id
      and d.record_state   = 'A'
    where f.banking_Date   = to_date(:P_BANKING_DATE,'DD-MM-YYYY')
      and d.fx_type_code   = 'D'
      and d.rate_type_code = 'M'
      and base_currency    = i.local_currency
      and quote_currency   = (select min(code) from dwd_currency where name = 'USD' and record_state ='A')
    ),
cntr_data as (
    select  /*+parallel(8) materialize use_hash(dc) use_hash(i) swap_join_inputs(i) use_hash(p) swap_join_inputs(p) */ 
          dc.personal_Account,
          dc.contract_number,
          p.group_code
     from client_list i 
     join dwd_contract dc
       on dc.institution_id = i.id
      and dc.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
      and dc.record_date_to   >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')  
	 join dwd_product p on p.id = dc.product_id
     ) 

select /*+ leading(i) use_hash(i) use_hash(nmon) use_hash(dc) ordered */
     i.branch_Code as ORG,
       'D'
     ||rpad(nmon.workflow_xcd,16,' ')
     ||rpad('NMON20',8,' ')
     ||rpad('2.0',5,' ')
     ||rpad(nmon.client_xid,16,' ')
--[*] begin 230904.1 = OPKSAIC-5570
--     ||rpad(to_char(sysdate,'yyyymmdd'),8,'0')
--     ||rpad(to_char(sysdate,'HHMMSS'),6,'0')
--     ||rpad(to_char(sysdate,'SS')*1000,3,'0')
--     ||rpad('4',6,' ')
--[*] begin 231108.1 = PRD-25567
       ||TO_CHAR(
         FROM_TZ(
           TO_TIMESTAMP(SUBSTR(TO_CHAR(SYSTIMESTAMP, 'YYYYMMDDHH24MISSFFtzh:tzm'),1,17), 'YYYYMMDDHH24MISSFFtzh:tzm'),
           substr(TO_CHAR(SYSTIMESTAMP, 'tzh:tzm'),1,7)
         ) AT TIME ZONE NVL(:P_TZ, substr(TO_CHAR(SYSTIMESTAMP, 'tzh:tzm'),1,7)), 
         'YYYYMMDDHH24MISSFF3tzh.tzm'
       )
--[*] end 231108.1 = PRD-25567
--[*] end 230904.1 = OPKSAIC-5570
     ||rpad(nvl(decode(sy_convert.get_tag_value(i.add_info,'CAF_EXPORT_CLIENT_ID'),'Y',nmon.customer_xid,cl.CLIENT_NUMBER),' '),20,' ')--[*] 230901.1 = Santosh = NICORE-788 : Change to populate client number
     ||rpad(nvl(decode(dc.group_code,'ISSDEB',dc.contract_number,nmon.account_reference_xid),' ') , 40, ' ') --[*]230828.1 = Santosh = ETSLT-363 : Reverting sqp and logic change to use product
     ||'WY4NMN'||lpad(opt_nmon_file_seq.nextval,26,'0')
     ||rpad(nmon.transaction_dtm,8,'0')
     ||rpad(nmon.transaction_ttm,6,'0')
     ||rpad(nmon.nonmon_event_xcd,4,' ')
     ||rpad(nmon.NONMON_CODE_INITIATOR_XCD,1,' ')
     ||rpad(nmon.DECISION_XCD,1,' ')
     ||rpad(nmon.CONTACT_METHOD_XCD,1,' ')
     ||rpad(nmon.CONTACT_METHOD_XID,40,' ')
     ||rpad(nmon.SERVICE_REPRESENTATIVE_XID,20,' ')
     ||rpad(nvl(nmon.score_customer_account_xid,' '),19,' ')
     ||rpad(nmon.PAYMENT_INSTRUMENT_XID,30,' ')
     ||rpad(nvl(nmon.new_customer_xid,' '),20,' ')
     ||rpad(nvl(nmon.new_customer_account_xid,' '),40,' ')
     ||rpad(nvl(nmon.new_primary_account_xid,' '),19,' ')
     ||rpad(nmon.NEW_PAYMENT_INSTRUMENT_XID,30,' ')
     ||rpad(nvl(nmon.action_xcd,' '),2,' ')
     ||rpad(nmon.NEW_FIRST_NAME,30,' ')
     ||rpad(nmon.PREVIOUS_FIRST_NAME,30,' ')
     ||rpad(nmon.NEW_MIDDLE_NAME,30,' ')
     ||rpad(nmon.PREVIOUS_MIDDLE_NAME,30,' ')
     ||rpad(nmon.NEW_LAST_NAME,60,' ')
     ||rpad(nmon.PREVIOUS_LAST_NAME,60,' ')
     ||rpad(nmon.NEW_SUFFIX_NAME,10,' ')
     ||rpad(nmon.PREVIOUS_SUFFIX_NAME,10,' ')
     ||rpad(nmon.NEW_ENTITY_NAME,60,' ')
     ||rpad(nmon.PREVIOUS_ENTITY_NAME,60,' ')
     ||rpad(nmon.NEW_ADDRESS_LINE_1_STRG,40,' ')
     ||rpad(nmon.PREVIOUS_ADDRESS_LINE_1_STRG,40,' ')
     ||rpad(nmon.NEW_ADDRESS_LINE_2_STRG,40,' ')
     ||rpad(nmon.PREVIOUS_ADDRESS_LINE_2_STRG,40,' ')
     ||rpad(nmon.NEW_ADDRESS_LINE_3_STRG,40,' ')
     ||rpad(nmon.PREVIOUS_ADDRESS_LINE_3_STRG,40,' ')
     ||rpad(nmon.NEW_ADDRESS_LINE_4_STRG,40,' ')
     ||rpad(nmon.PREVIOUS_ADDRESS_LINE_4_STRG,40,' ')
     ||rpad(nmon.NEW_CITY_NAME,40,' ')
     ||rpad(nmon.PREVIOUS_CITY_NAME,40,' ')
     ||rpad(nmon.NEW_COUNTRY_REGION_XCD,3,' ')
     ||rpad(nmon.PREVIOUS_COUNTRY_REGION_XCD,3,' ')
     ||rpad(nmon.NEW_POSTAL_XCD,10,' ')
     ||rpad(nmon.PREVIOUS_POSTAL_XCD,10,' ')
     ||rpad(nmon.NEW_COUNTRY_XCD,3,' ')
     ||rpad(nmon.PREVIOUS_COUNTRY_XCD,3,' ')
     ||rpad(nmon.NEW_PHONE_NUM,24,' ')
     ||rpad(nmon.PREVIOUS_PHONE_NUM,24,' ')
     ||rpad(nmon.NEW_PHONE_2_NUM,24,' ')
     ||rpad(nmon.PREVIOUS_PHONE_2_NUM,24,' ')
     ||rpad(nmon.NEW_EMAIL_ADDR,40,' ')
     ||rpad(nmon.PREVIOUS_EMAIL_ADDR,40,' ')
     ||rpad(nvl(nmon.new_dt,' '),8,' ')
     ||rpad(nvl(nmon.previous_dt,' '),8,' ')
     ||rpad(nvl(nmon.new_2_dt,' '),8,' ')
     ||rpad(nvl(nmon.previous_2_dt,' '),8,' ')
     ||rpad(nmon.NEW_CUST_REFERENCE_XID,20,' ')
     ||rpad(nmon.PREVIOUS_CUST_REFERENCE_XID,20,' ')
     ||rpad(nmon.NEW_CUST_REFERENCE_2_XID,20,' ')
     ||rpad(nmon.PREVIOUS_CUST_REFERENCE_2_XID,20,' ')
     ||rpad(nmon.new_transaction_type_xcd,3,' ')
     ||rpad(nmon.old_transaction_type_xcd,3,' ')
     ||rpad(nmon.new_transaction_type_2_xcd,3,' ')
     ||rpad(nmon.old_transaction_type_2_xcd,3,' ')
     ||rpad(nmon.NEW_TRANSACTION_TYPE_3_XCD,3,' ')
     ||rpad(nmon.OLD_TRANSACTION_TYPE_3_XCD,3,' ')
     ||rpad(nmon.new_indicator_1_xcd,1,' ')
     ||rpad(nmon.old_indicator_1_xcd,1,' ')
     ||rpad(nmon.new_indicator_2_xcd,1,' ')
     ||rpad(nmon.old_indicator_2_xcd,1,' ')
     ||rpad(nmon.new_indicator_3_xcd,1,' ')
     ||rpad(nmon.old_indicator_3_xcd,1,' ')
     ||rpad(nmon.new_indicator_4_xcd,1,' ')
     ||rpad(nmon.old_indicator_4_xcd,1,' ')
     ||rpad(nmon.new_monetary_value_amt,19,' ')
     ||rpad(nmon.previous_monetary_value_amt,19,' ')
     ||rpad(nmon.currency_xcd , 3, ' ')
     ||rpad(nvl(c.rate_value,'0'), 13, ' ')
     ||rpad(nmon.new_num, 10, ' ')
     ||rpad(nmon.previous_num, 10, ' ')
     ||rpad(nmon.new_2_num, 10, ' ')
     ||rpad(nmon.previous_2_num, 10, ' ')
     ||rpad(nmon.NEW_CHARACTER_VALUE_XCD, 10, ' ')
     ||rpad(nmon.PREVIOUS_CHARACTER_VALUE_XCD, 10, ' ')
     ||rpad(nmon.new_credentials_strg, 60, ' ')
     ||rpad(nmon.previous_credentials_strg, 60, ' ')
     ||rpad(nmon.COMMENT_STRG, 50, ' ')
     ||rpad(nmon.USER_INDICATOR_1_XCD, 1, ' ')
     ||rpad(nmon.USER_INDICATOR_2_XCD, 1, ' ')
     ||rpad(nmon.USER_INDICATOR_3_XCD, 1, ' ')
     ||rpad(nmon.USER_INDICATOR_4_XCD, 1, ' ')
     ||rpad(nmon.USER_INDICATOR_5_XCD, 1, ' ')
     ||rpad(nmon.USER1_XCD, 3, ' ')
     ||rpad(nmon.USER2_XCD, 3, ' ')
     ||rpad(nmon.USER3_XCD, 3, ' ')
     ||rpad(nmon.USER4_XCD, 3, ' ')
     ||rpad(nmon.USER5_XCD, 3, ' ')
     ||rpad(nmon.USER_DATA_1_STRG, 6, ' ')
     ||rpad(nmon.USER_DATA_2_STRG, 6, ' ')
     ||rpad(nmon.USER_DATA_2_STRG, 6, ' ')
     ||rpad(nmon.USER_DATA_4_STRG, 8, ' ')
     ||rpad(nmon.USER_DATA_5_STRG, 8, ' ')
     ||rpad(nmon.USER_DATA_6_STRG, 8, ' ')
     ||rpad(nmon.USER_DATA_7_STRG, 10, ' ')
     ||rpad(nmon.USER_DATA_8_STRG, 10, ' ')
     ||rpad(nmon.USER_DATA_9_STRG, 15, ' ')
     ||rpad(nmon.USER_DATA_10_STRG, 15, ' ')
     ||rpad(nmon.USER_DATA_11_STRG, 20, ' ')
     ||rpad(nmon.USER_DATA_12_STRG, 20, ' ')
     ||rpad(nmon.USER_DATA_13_STRG, 40, ' ')
     ||rpad(nmon.USER_DATA_14_STRG, 40, ' ')
     ||rpad(nmon.USER_DATA_15_STRG, 60, ' ')
     ||rpad(nmon.RESERVED_01, 30, ' ')
      as data

  from client_list i
  join opt_v_falcon_nmon nmon
    on trim(nmon.client_xid) = trim(i.client_xid)
	and nmon.tenant_name = i.tenant_name 
left join conversion_rates c
    on c.settl_currency = nmon.currency_xcd
   and i.id=c.institution_id --[+] 230908.1 = IB-547
 left join cntr_data dc
       on dc.personal_account = trim(nmon.account_reference_xid)
    --[+] BEGIN 230901.1 = Santosh = NICORE-788 : Change to populate client number
	join dwd_client cl 
		on cl.record_idt =  to_number(trim(nmon.customer_xid))
		--[*]BEGIN 230904.1 = Santosh = NICORE-788 : condition update
		and cl.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
        and cl.record_date_to   >= to_date(:P_BANKING_DATE,'DD-MM-YYYY') 
		and cl.institution_id = i.id
		--[*]END 230904.1 = Santosh = NICORE-788 : condition update 