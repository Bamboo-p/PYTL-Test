/*
15042022.1 - OPKSAIC-3208 - Santosh - Falcon NMON report initial version
22072022.2 - OPKSAIC-3208 - Santosh - Removed data part from trailer
26092022.1 - OPKSAIC-4850 - Santosh - Default trailer in case of no data returned
230217.8 = deniska = NICORE-143: replace TABs with SPACEs. Trim trailing spaces.
230908.1 = Shalini = IB-547: Logic changes to get common report for all clients under particular Tenant
230913.1 = Shalini = OPKSAIC-5684: Count of records correction
231026.1 = BharathG = NICORE-923 : sql changes to populate event 1300 into file
240202.1 = BharathG = NICORE-937 : SQL tuning 
240328.1 = Bharath : NICORE-1303 : Trailer count issue correction
*/
with client_list as (
    select /*+ no_merge materialize */
          v.code as client_xid,
          v.name,
          v.add_info as tenant_name,
          inst.id,
          inst.branch_code
     from sy_conf_group g
     join sy_conf_group_val v
       on v.amnd_state = 'A'
      and g.id = v.sy_conf_group__oid
     join sy_conf_group_rec r
       on r.amnd_state = 'A'
      and r.value_id = v.id
     join dwd_institution inst
       on inst.id = r.table_rec_id
    where g.code = 'CLIENT_BANK_ID'
      and g.group_code = 'FALCON_BATCH_FEED'
      and inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                 from dual
                           connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
    ),
cntr_data as (
    select  /*+parallel(8) materialize use_hash(dc) use_hash(i) swap_join_inputs(i) */ 
          dc.personal_Account,
          dc.contract_number
     from client_list i 
     join dwd_contract dc
       on dc.institution_id = i.id
      and dc.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
      and dc.record_date_to   >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
     ) 
--[+]begin 26-09-2022 - OPKSAIC-4850 - Santosh - Default trailer in case of no data returned
,default_tr as(
select --i.branch_Code as ORG, -- [-] 230908.1 = IB-547
       'E'
     ||'999999999'
     ||lpad(' ',2099,' ')
     ||'1.0'
     ||'NMON20  '
     ||'PMAX  '
     ||lpad(0,8,'0') as data
  from dual --[*] 230908.1 = IB-547
),
trail as(
--[+]end 26-09-2022 - OPKSAIC-4850 - Santosh - Default trailer in case of no data returned
select /*+ leading(i) use_hash(i) use_hash(nmon) use_hash(dc) ordered */
     -- i.branch_Code as ORG, -- [-] 230908.1 = IB-547
       'E'
     ||'999999999'
     ||lpad(' ',2099,' ')
     ||'1.0'
     ||'NMON20  '
     ||'PMAX  '
     ||lpad(count(1),8,'0') as data

  from opt_v_falcon_nmon nmon
  join client_list i
    on trim(nmon.client_xid) = trim(i.client_xid)
	and nmon.tenant_name = i.tenant_name
	join dwd_client cl 
	on cl.institution_id = i.id
    and cl.record_idt =  to_number(trim(nmon.customer_xid))
	and cl.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
    and cl.record_date_to   >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')  
-- group by i.branch_Code -- [-]230908.1 = IB-547
--[+]begin 230913.1 = OPKSAIC-5684
 left join cntr_data dc
       on dc.personal_account = trim(nmon.account_reference_xid)
--[+]end 230913.1 = OPKSAIC-5684
)
--[+]begin 26-09-2022 - OPKSAIC-4850 - Santosh - Default trailer in case of no data returned
select -- coalesce(tr.org,dtr.org) as org, -- 230908.1 = IB-547
       coalesce(tr.data,dtr.data) as data
  from trail tr
  right outer join default_tr dtr on 1=1 -- [*] 230908.1 = IB-547
--[+]end 26-09-2022 - OPKSAIC-4850 - Santosh - Default trailer in case of no data returned
