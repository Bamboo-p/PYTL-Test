/*
07-03-2022 - OPKSAIC-3174 - Bharath - Falcon PIS report initial version
14-04-2022 - OPKSAIC-3174 - Bharath - Changed query to positional file requirements
08-11-2022 - ETSLT-8 - Santosh - enhancing existing standard report to add ETSLT requirements
                                    1. Added alternate number logic to enhance report to EXID in the report based on input parameter
                                    2. New input parameter RETURN_EXID_CARD introduced to fetch alternate id instead of PAN
                                       possible inputs : RETURN_EXID_CARD=Y - fetches alternate id instead of card number
                                                         RETURN_EXID_CARD=N - fetches card number
                                                         RETURN_EXID_CARD=null - fetches card number
21-12-2022 - ETSLT-8 - Santosh - Added trim in join condition
27-12-2022 - ETSLT-8 - Santosh - Modified where clause to fetch EXID
230217.9 = deniska = NICORE-143: replace TABs with SPACEs. Trim trailing spaces.
230414.1 = santosh = ETSLT-363 : Added new param RETURN_RBS. Default value will be N
230828.1 = Santosh = ETSLT-363 : Removing RETURN_RBS: Reverting sqp and logic change to use product
230901.1 = Santosh = NICORE-788 : Change to populate client number
230904.1 = Santosh = NICORE-788 : condition update
230904.1 = Shalini = OPKSAIC-5547 : Added ability to change offset value as per P_TZ parameter
230904.2 = Shalini = OPKSAIC-5547 : Conflicts resolution
230908.1 = Shalini = IB-547: Logic changes to get common report for all clients under particular Tenant
231108.1 = Shalini = PRD-25567: Logic changes to correct milliseconds issue
240308.1 = Santosh = CRKSA-496 : Changed conversion logic to support multicurrency
*/
with client_list as (
    select /*+ no_merge materialize */
          v.code as client_xid,
          v.name,
          v.add_info as tenant_name,
          inst.id,
          inst.branch_code,
		  inst.add_info --[+] 230901.1 = Santosh = NICORE-788 : Change to populate client number
     from sy_conf_group g
     join sy_conf_group_val v
       on v.amnd_state = 'A'
      and g.id = v.sy_conf_group__oid
     join sy_conf_group_rec r
       on r.amnd_state = 'A'
      and r.value_id = v.id
     join dwd_institution inst
       on inst.id = r.table_rec_id
    where g.code = 'CLIENT_BANK_ID'
      and g.group_code = 'FALCON_BATCH_FEED'
      and inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                 from dual
                           connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
    ),
inst as (
    select /*+ no_merge materialize */
          id,
          branch_code,
          name inst_name,
          local_currency
     from (select dwd_institution.branch_code,
                  dwd_institution.posting_institution_id,
                  dwd_institution.id,
                  dwd_institution.local_currency,
                  dwd_institution2.branch_code branch_code_posting,
                  dwd_institution.name
             from dwd_institution
             join dwd_institution dwd_institution2
               on dwd_institution.posting_institution_id = dwd_institution2.id
            where dwd_institution.record_state = 'A'
           ) inst
       start with inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                         from dual
                                   connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
                                      )
                            connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
    ),
conversion_rates as (
    select /*+no_merge materialize*/
          i.id as institution_id, --[+] 230908.1 = IB-547
          f.base_currency as settl_currency,
          f.rate_value
     from dwf_fx_rate f
     join inst i
       on f.institution_id = i.id
     join dwd_fx_rate_type d
       on d.id = f.fx_rate_type_id
      and d.record_state   = 'A'
    where f.banking_Date   = to_date(:P_BANKING_DATE,'DD-MM-YYYY')
      and d.fx_type_code   = 'D'
      and d.rate_type_code = 'M'
      --and base_currency    = i.local_currency --[-] 240308.1 = Santosh = CRKSA-496 : Changed conversion logic to support multicurrency
      and quote_currency   = (select min(code) from dwd_currency where name = 'USD' and record_state ='A')
    )
-- [+][begin] 221108.1 = ETSLT-8 - Santosh - enhancing existing standard report to add ETSLT requirements
,ext_nums as (
    select /*+no_merge materialize */
           dca.card_idt,
           dca.attr_value exid,
           c.pan
      from dwa_card_attribute dca
      join dwd_attribute da
        on dca.attr_id = da.id
      join dwd_card c
        on c.record_idt = dca.card_idt
     where dca.attr_date_from <= TO_DATE(:P_BANKING_DATE,'DD-MM-YYYY')
       and dca.attr_date_to   >= TO_DATE(:P_BANKING_DATE,'DD-MM-YYYY')
-- [+][begin] 221227 - ETSLT-8 - Santosh - Modified where clause to fetch EXID
       and c.record_date_from <= TO_DATE(:P_BANKING_DATE,'DD-MM-YYYY')
       and c.record_date_to   >= TO_DATE(:P_BANKING_DATE,'DD-MM-YYYY')
-- [+][end] 221227 - ETSLT-8 - Santosh - Modified where clause to fetch EXID
       and da.dimension_code   = 'DWD_CARD'
       and da.record_source    = 'W4TD_DOMAIN'
       and da.code             = 'EXID'
    )
-- [+][end] 221108.1 = ETSLT-8 - Santosh - enhancing existing standard report to add ETSLT requirements
    select i.branch_Code as org,
           'D'
         ||rpad(pis.workflow_xcd,16,' ')
         ||rpad('PIS12',8,' ')
         ||rpad('1.2',5,' ')
         ||rpad(pis.client_xid,16,' ')
--[*] begin 230904.1 = OPKSAIC-5547
--         ||rpad(to_char(sysdate,'yyyymmdd'),8,'0')
--         ||rpad(to_char(sysdate,'HHMMSS'),6,'0')
--         ||rpad(to_char(sysdate,'SS')*1000,3,'0')
--         ||'+04.00'
--[*] begin 231108.1 = PRD-25567
         ||TO_CHAR(
         FROM_TZ(
           TO_TIMESTAMP(SUBSTR(TO_CHAR(SYSTIMESTAMP, 'YYYYMMDDHH24MISSFFtzh:tzm'),1,17), 'YYYYMMDDHH24MISSFFtzh:tzm'),
           substr(TO_CHAR(SYSTIMESTAMP, 'tzh:tzm'),1,7)
         ) AT TIME ZONE NVL(:P_TZ, substr(TO_CHAR(SYSTIMESTAMP, 'tzh:tzm'),1,7)), 
         'YYYYMMDDHH24MISSFF3tzh.tzm'
         )
--[*] end 231108.1 = PRD-25567
--[*] end 230904.1 = OPKSAIC-5547
         ||rpad(nvl(decode(sy_convert.get_tag_value(i.add_info,'CAF_EXPORT_CLIENT_ID'),'Y',pis.customer_xid,cl.CLIENT_NUMBER),' '),20,' ')--[*] 230901.1 = Santosh = NICORE-788 : Change to populate client number
         ||rpad(nvl(decode(p.group_code,'ISSDEB',dc.contract_number,pis.account_reference_xid),' ') , 40, ' ') --[*]230828.1 = Santosh = ETSLT-363 : Reverting sqp and logic change to use product
         ||'WY4PIS'||lpad(opt_pis_file_seq.nextval,26,'0')
         ||rpad(pis.score_customer_account_xid,19,' ')
         ||rpad(pis.card_type_xcd,1,' ')
         ||rpad(pis.card_sub_type_xcd,2,' ')
         ||rpad(pis.card_category_xcd,1,' ')
         ||rpad(pis.card_issuer_xcd,1,' ')
         ||rpad(pis.card_open_dt,8,' ')
         ||rpad(pis.member_since_dt,8,' ')
         ||rpad(pis.issuing_country_xcd,3,' ')
         ||rpad(pis.city_name,40,' ')
         ||rpad(pis.country_region_xcd,5,' ')
         ||rpad(pis.postal_xcd,10,' ')
         ||rpad(pis.country_xcd,3,' ')
         ||rpad(pis.payment_id_cnt,3,' ')
         ||rpad(pis.payment_instrument_xid,30,' ')
         ||rpad(pis.current_card_status_xcd,2,' ')
         ||rpad(pis.current_status_effective_dt,8,' ')
         ||rpad(pis.pin_length,2,' ')
         ||rpad(pis.pin_set_dt,8,' ')
         ||rpad(pis.pin_type_xcd,1,' ')
         ||rpad(pis.payment_active_indicator_xflg,1,' ')
         ||rpad(pis.payment_instrument_name,40,' ')
         ||rpad(pis.payment_instrument_expertn_dt,8,' ')
         ||rpad(pis.last_issue_dt,8,' ')
         ||rpad(pis.card_issue_type_xcd,1,' ')
         ||rpad(pis.incentive_xcd,1,' ')
         ||rpad(pis.currency_xcd,3,' ')
         ||rpad(nvl(to_char(c.rate_value),' '),13,' ')
         ||rpad(pis.credit_limit_amt,10,' ')
         ||rpad(pis.overdraft_limit_amt,10,' ')
         ||rpad(pis.pos_daily_limit_amt,10,' ')
         ||rpad(pis.cash_daily_limit_amt,10,' ')
         ||rpad(pis.daily_limit_type_xcd,1,' ')
         ||rpad(pis.media_type_xcd,1,' ')
         ||rpad(pis.aip_static_xflg,1,' ')
         ||rpad(pis.aip_dynamic_xflg,1,' ')
         ||rpad(pis.aip_verify_xflg,1,' ')
         ||rpad(pis.aip_risk_xflg,1,' ')
         ||rpad(pis.aip_issuer_authentication_xflg,1,' ')
         ||rpad(pis.aip_combined_xflg,1,' ')
         ||rpad(pis.chip_spec_xcd,1,' ')
         ||pis.chip_spec_version_xcd
         ||pis.offline_lower_limit
         ||pis.offline_upper_limit
         ||pis.user_indicator_1_xcd
         ||pis.user_indicator_2_xcd
         ||pis.user1_xcd
         ||pis.user2_xcd
         ||pis.user_data_1_strg
         ||pis.user_data_2_strg
         ||pis.user_data_3_strg
         ||pis.user_data_4_strg
         ||pis.user_data_5_strg
         ||decode(upper(substr(nvl(og.NAME,'N'),1,1)), 'Y',rpad(nvl(e.exid,' '),20,' '), pis.user_data_6_num) -- [+] 221108.1 = ETSLT-8 - Santosh - enhancing existing standard report to add ETSLT requirements  --[*] 230908.1 = IB-547
         ||rpad(nvl(decode(p.group_code,'ISSDEB',pis.account_reference_xid,pis.user_data_7_strg),' ') , 40, ' ') as data --[*]230828.1 = Santosh = ETSLT-363 : Reverting sqp and logic change to use product
      from opt_v_falcon_pis pis
      join client_list i
        on trim(pis.client_xid) = trim(i.client_xid)
 left join conversion_rates c
        on c.settl_currency = pis.currency_xcd
 --[+] begin 230908.1 = IB-547
and i.id=c.institution_id
left join opt_v_suppl_group og on og.code = i.branch_code
       and og.type_code = 'FALCON_EXID_ENABLED'
 --[+] end 230908.1 = IB-5472
-- [+][begin] 221108.1 = ETSLT-8 - Santosh - enhancing existing standard report to add ETSLT requirements
 left join ext_nums e
        on trim(pis.score_customer_account_xid) = e.pan  -- [+] 221221.1 = ETSLT-8 - Santosh - Added trim in join condition
-- [+][end] 221108.1 = ETSLT-8 - Santosh - enhancing existing standard report to add ETSLT requirements
    left join dwd_contract dc
        on dc.personal_account = trim(pis.account_reference_xid) 
	--[*] BEGIN 230901.1 = Santosh = NICORE-788 : Change to populate client number	
	left join dwd_client cl 
		on cl.record_idt =  to_number(trim(pis.customer_xid))
		--[*]BEGIN 230904.1 = Santosh = NICORE-788 : condition update
		and cl.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
		and cl.record_date_to   >= to_date(:P_BANKING_DATE,'DD-MM-YYYY') 
		--[*]BEGIN 230904.1 = Santosh = NICORE-788 : condition update
	join dwd_product p on p.id = dc.product_id        
    where dc.institution_id = i.id
        and dc.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
        and dc.record_date_to   >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
    --[*] BEGIN 230901.1 = Santosh = NICORE-788 : Change to populate client number			