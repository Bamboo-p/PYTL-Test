/*
07-03-2022 - OPKSAIC-3174 - Bharath - Falcon PIS report initial version
14-04-2022 - OPKSAIC-3174 - Bharath - Changed query to positional file requirements
31-05-2022 - OPKSAIC-3174 - Bharath - Changed query to update the lengths
26-09-2022 - OPKSAIC-4850 - Santosh - Default trailer in case of no data returned
230217.9 = deniska = NICORE-143: replace TABs with SPACEs. Trim trailing spaces.
230908.1 = Shalini = IB-547: Logic changes to get common report for all clients under particular Tenant
230913.1 = Shalini = OPKSAIC-5684: Count of records correction
*/
with client_list as (
    select /*+ no_merge materialize */
          v.code as client_xid,
          v.name,
          v.add_info as tenant_name,
          inst.id,
          inst.branch_code
     from sy_conf_group g
     join sy_conf_group_val v
       on v.amnd_state = 'A'
      and g.id = v.sy_conf_group__oid
     join sy_conf_group_rec r
       on r.amnd_state = 'A'
      and r.value_id = v.id
     join dwd_institution inst
       on inst.id = r.table_rec_id
    where g.code = 'CLIENT_BANK_ID'
      and g.group_code = 'FALCON_BATCH_FEED'
      and inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                 from dual
                           connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
    )
--[+]begin 26-09-2022 - OPKSAIC-4850 - Santosh - Default trailer in case of no data returned
,default_tr as(
select --i.branch_Code as ORG, --[-] 230908.1 = IB-547
           'E'
         ||'999999999'
         ||lpad(' ',527,' ')
         ||'1.2'
         ||'PIS12   '
         ||'PMAX  '
         ||lpad(0,8,'0') as data
  from dual --[-] 230908.1 = IB-547
),
trail as(
--[+]end 26-09-2022 - OPKSAIC-4850 - Santosh - Default trailer in case of no data returned
    select --i.branch_Code as ORG, --[-] 230908.1 = IB-547
           'E'
         ||'999999999'
         ||lpad(' ',527,' ')
         ||'1.2'
         ||'PIS12   '
         ||'PMAX  '
         ||lpad(count(1),8,'0') as data

      from opt_v_falcon_pis pis
      join client_list i
        on trim(pis.client_xid) = trim(i.client_xid)
--  group by i.branch_Code --[-] 230908.1 = IB-547
--[+]begin 230913.1 = OPKSAIC-5684
left join dwd_contract dc
        on dc.personal_account = trim(pis.account_reference_xid) 
        where dc.institution_id = i.id
        and dc.record_date_from <= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
        and dc.record_date_to   >= to_date(:P_BANKING_DATE,'DD-MM-YYYY')
--[+]end 230913.1 = OPKSAIC-5684
)
select --coalesce(tr.org,dtr.org) as org, --[-] 230908.1 = IB-547
       coalesce(tr.data,dtr.data) as data
  from trail tr
  right outer join default_tr dtr on 1=1 --[*] 230908.1 = IB-547
--[+]end 26-09-2022 - OPKSAIC-4850 - Santosh - Default trailer in case of no data returned