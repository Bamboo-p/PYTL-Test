__version__ = "240102.1"
__job_name__ = "PyTL_IS_SimpleReports_FIXED_CURRENCY_FLAG_REPORT"
__bat_files__ = []
