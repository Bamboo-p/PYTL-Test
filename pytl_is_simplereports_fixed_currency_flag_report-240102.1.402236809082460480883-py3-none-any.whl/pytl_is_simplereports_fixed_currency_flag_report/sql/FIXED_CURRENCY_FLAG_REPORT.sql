/*
Purpose: Report to provide the accounts for which the fixed rate classifier is enabled

Incoming parameters:
    :ORGLIST
    :P_REPORT_DATE as dd-MM-yyyy
231116.1 = AlexanderK = ENBD-25331: Initial development
231130.1 = AlexanderK = ENBD-25331: Changed code to MC_FIX_RATE_FLAG
231213.1 = AlexanderK = ENBD-25331: Changed code to FIX_RATE_FLAG
240102.1 = RakeshG = ENBD-25825: Primary CardNumber population logic change
*/

WITH
fi as (
    SELECT /*+ no_merge materialize */
        id,
        branch_code code,
        name
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code branch_code_posting,
                dwd_institution.name
            FROM
                dwd_institution
            JOIN
                dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY decode(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
),

atr as 
(Select
        dca.contract_idt
        ,max(case when da.type_code = 'PCT_TARIFF'            then da.code            else null end) as pctt
        ,max(case when da.type_code = 'FIX_RATE_FLAG'         then da.code            else null end) as fixed_currency_flag
        from dwa_contract_attribute dca
        join dwd_attribute da
             on da.id = dca.attr_id
             and da.type_code in ('PCT_TARIFF', 'FIX_RATE_FLAG')
             and dca.attr_date_from <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
             and dca.attr_date_to   >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
             group by dca.contract_idt
),
cntr as
(
select
        odci.bank_code                  as ORG
        ,odci.logo                      as LOGO
        ,odci.contract_number           as ACCOUNT_NUMBER
        ,atr.fixed_currency_flag        as FIXED_CURRENCY_FLAG
        ,atr.pctt                       as PCT
        ,odci.contract_idt
from opt_dm_contract_info odci
join atr on odci.contract_idt = atr.contract_idt
join fi on odci.bank_code = fi.code
where atr.fixed_currency_flag = 'Y'
),
-- [+] [Begin] 240102.1 = RakeshG = ENBD-25825: Primary CardNumber population logic change
primary_card as 
(
SELECT
        main_contract_idt as contracT_idt,
        org,
        card_number,
        plastic_status,
        trans_status,
        ROW_NUMBER() OVER(PARTITION BY main_contract_idt ORDER BY DECODE(plastic_status||trans_status,'AA',1,'CA',2,'LA',3,'CC',4,5) asc
		                                                         ,nvl(effective_date, to_date('01.01.1990', 'dd.mm.yyyy')) desc
																 ,card_idt desc) AS rn
    FROM
        (SELECT
                main_contract_idt,
                org,
                c.record_idt as card_idt,
                c.pan as card_number,
                effective_date,
                plastic_status,
                nvl(substr(regexp_substr(c.add_info, 'TRANS_STATUS[^;]+'),14), 'A') AS trans_status
           from cntr cc
           join dwd_card c on c.main_contracT_idt = cc.contract_idt
            and c.record_date_from <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
            and c.record_date_to >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
            and c.main_card_flag = 'Y'
            )c
)
-- [+] [End] 240102.1 = RakeshG = ENBD-25825: Primary CardNumber population logic change
select
       cntr.ORG
       ,cntr.LOGO
       ,pc.card_number as LATEST_PRIMARY_CARD
       ,cntr.ACCOUNT_NUMBER
       ,cntr.FIXED_CURRENCY_FLAG
       ,cntr.PCT
  from cntr
  join primary_card pc on pc.contract_idt = cntr.contracT_idt and pc.rn = 1