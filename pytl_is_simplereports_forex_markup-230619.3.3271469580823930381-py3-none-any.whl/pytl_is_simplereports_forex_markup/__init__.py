__version__ = "230619.3"
__job_name__ = "PyTL_IS_SimpleReports_FOREX_MARKUP"
__bat_files__ = []

