/*
* Code to get transactions for forex markup report
*
* Version history:
* 20210916-001 - Santosh - Added field "MARK UP PERC"
* 20210916-001 - Santosh - Created summary section
* 20210916-001 - Santosh - Removed TRANSACTION AMOUNT from summary
* 20220216.1   = ShaliniU = ALMB-567: Removed record_state filter to get back dated data
* 20230111.1   = ShaliniU = ANFE-171: Bin mapping changes
* 20230428.1   = Santosh = NICORE-420 : code enhancement for D2C
* 20230516.1   = Santosh = NICORE-420 : payment_scheme logic correction
* 20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added
*/
with
institutions as
    (
select /*+ no_merge materialize */ id institution_id,branch_code org,name
                      from (select dwd_institution.branch_code,
                                   dwd_institution.posting_institution_id,
                                   dwd_institution.id,
                                   dwd_institution2.branch_code branch_code_posting,
                                   dwd_institution.name
                            from dwd_institution
                                 join dwd_institution dwd_institution2 on dwd_institution.posting_institution_id = dwd_institution2.id
                            where dwd_institution.record_state = 'A'
                            ) inst
                      start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                                      from dual
                                                      connect by regexp_substr(:ORG , '[^,]+', 1, level) is not null
                                                      )
                      connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
    ),
    --[+]BEGIN 20230428.1   = Santosh = NICORE-420 : code enhancement for D2C
/*products as
    (
        select 
            *
        from
            v_dwr_product
        where
            class_code = 'BASE_REPORTS'
            and type_code  = 'LOGO'
    ),*/
  --[+]END 20230428.1   = Santosh = NICORE-420 : code enhancement for D2C
markup_entries as
    (
        select  /*+ no_merge */
            contract_idt,
            primary_doc_idt,
            operation_type_id,
            sum(case when entry_role = 'B' and service_class = 'T' then credit - debit else 0 end) as base_amount,
            sum(case when entry_role = 'M' and fee_code = 'MARKUP' then credit - debit else 0 end) as markup_amount,
            max(case when entry_role = 'M' and fee_code = 'MARKUP' then fee_rate_value else 0 end) as fee_rate_value,
            case when service_class = 'T'  and (entry_role in ('B','M') or (entry_role = 'F' and fee_code = 'MC_MARKUP')
            or (entry_role = 'A' and fee_code = '%VAT%')) then 1
                 else 2 end as is_fee
        from
            dwf_account_entry e
        join institutions inst
            on e.institution_id = inst.institution_id
        where
            e.banking_date = to_date(:P_REPORT_DATE,'dd-MM-yyyy')
        group by contract_idt, primary_doc_idt, operation_type_id,service_class,entry_role,fee_code

    ) 

,card_ext_nums as (
	select /*+no_merge materialize */
	       dca.card_idt,
		   dca.attr_value card_exid
	  from dwa_card_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CARD'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	)

,contract_ext_nums as (
	select /*+no_merge materialize */
	       dca.contract_idt,
		   dca.attr_value contract_exid
	  from dwa_contract_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CONTRACT'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	)

,markup_trans as (
select  /*+ no_merge materialize */
    inst.org "ORG",
    c.personal_account,
     --[+]BEGIN  20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added 
    decode(upper(substr(nvl(:RETURN_EXID_CONTRACT,'N'),1,1)),'Y',main_con.contract_exid, c.personal_account) as "ACCOUNT NUMBER",
    decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)),'Y',exn.card_exid, cd.pan) as "CARD NUMBER",
     --[+]END  20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added 
    curr.name CURR,
    base_curr.name B_CURR,
    abs(tr.trans_amount) "TRANSACTION AMOUNT",
    case when  tr.trans_currency ='840'
            then tr.trans_amount else round(tr.settl_amount / fxr.rate_value, 2)
    end "SETTLEMENT AMOUNT",
    tr.local_amount  "C/H BILLING AMOUNT",
    (((local_amount )* m.fee_rate_value  )/100) "MARK UP",
    (local_amount + (((local_amount )* m.fee_rate_value  )/100)) "MARKED UP AMOUNT",
    (local_amount + (((local_amount )* m.fee_rate_value  )/100)) "BILLING AMOUNT",
    ((local_amount * m.fee_rate_value )/tr.local_amount) "MARK UP PERC"
     ,dcp.bin as BIN --[+] 230111.1 = ANFE-171
     --[+]BEGIN 20230428.1   = Santosh = NICORE-420 : code enhancement for D2C
     ,c.base_currency "CONTRACT CURRENCY"
     ,pc.personal_account "PARENT ACCOUNT"
     --[+]END 20230428.1   = Santosh = NICORE-420 : code enhancement for D2C
     --[+]BEGIN  20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added 
     ,c.contract_number "RBS NUMBER"
     --[+]END 20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added
from
    dwd_contract c
--[+]BEGIN  20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added     
left join contract_ext_nums main_con
	       ON c.record_idt = main_con.contract_idt 
--[+]END  20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added            
join  markup_entries m
    on c.record_idt = m.contract_idt
join dwf_transaction tr
    on  m.primary_doc_idt=tr.doc_idt
    and tr.target_contract_idt = m.contract_idt
    --[+]BEGIN 20230428.1   = Santosh = NICORE-420 : code enhancement for D2C
left join dwd_contract pc
        on c.parent_contract_idt  = pc.record_idt
       and pc.record_date_from   <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
       and pc.record_date_to     >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')    
/*join products p
    on p.product_id=c.product_id */    
    --[+]END 20230428.1   = Santosh = NICORE-420 : code enhancement for D2C
join dwd_card cd
    on cd.record_idt=tr.target_card_idt
    and cd.record_date_from <=to_date(:P_REPORT_DATE,'dd-MM-yyyy')
    and cd.record_date_to >= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
    /*and cd.record_state='A'*/
    and c.record_date_from <=to_date(:P_REPORT_DATE,'dd-MM-yyyy')
    and c.record_date_to >= to_date(:P_REPORT_DATE,'dd-MM-yyyy')
   /*and c.record_state='A'*/
 --[+]BEGIN  20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added   
left join card_ext_nums exn
    on exn.card_idt = cd.record_idt
--[+]END  20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added     
join institutions inst
    on inst.institution_id=tr.institution_id
join dwd_currency curr
    on curr.code = tr.trans_currency
    and curr.record_state = 'A'
join dwd_currency base_curr
    on base_curr.code = c.base_currency
    and base_curr.record_state = 'A'
join dwf_fx_rate fxr
    on fxr.quote_currency = tr.settl_currency
    and fxr.institution_id=inst.institution_id
    and fxr.base_currency = :P_BASE_CURR
join dwd_product p
    on c.product_id = p.id
join dwd_fx_rate_type fxt
    on fxt.id = fxr.fx_rate_type_id
    and fxt.fx_type_code = 'D'
    and fxt.rate_type_code = 'M'
--[+] 230111.1 = ANFE-171
join dwd_card_product  dcp 
    on dcp.id = cd.card_product_id
    and dcp.record_state = 'A'
--[+] 230111.1 = ANFE-171
where 1=1
    and m.markup_amount <> 0
    and m.fee_rate_value <> 0
    and m.is_fee='1'
    and tr.banking_date = to_date(:P_REPORT_DATE,'dd-MM-yyyy')
--    and UPPER(p.payment_scheme) like  UPPER(:P_PAYMENT_SCHEMA)
    and instr(UPPER(p.payment_scheme),UPPER(:P_PAYMENT_SCHEMA)) > 0
    and fxr.banking_date = to_date(:P_REPORT_DATE,'dd-MM-yyyy')
 )


select  "ORG" ,"ACCOUNT NUMBER","CARD NUMBER",
to_char("TRANSACTION AMOUNT", 'FM999999990.00') || ' ' || curr "TRANSACTION AMOUNT",
to_char("SETTLEMENT AMOUNT" , 'FM999999990.00')  || ' USD' "SETTLEMENT AMOUNT",
to_char("C/H BILLING AMOUNT", 'FM999999990.00') || ' ' || b_curr "C/H BILLING AMOUNT",
to_char("MARK UP", 'FM9999999990.00') || ' ' || b_curr "MARK UP",
to_char("MARKED UP AMOUNT" , 'FM999999990.00') || ' ' || b_curr "MARKED UP AMOUNT",
to_char("BILLING AMOUNT" , 'FM999999990.00') || ' ' || b_curr "BILLING AMOUNT",
to_char("MARK UP PERC" , 'FM999999990.00') "MARK UP PERC"
--[+]BEGIN 20230428.1   = Santosh = NICORE-420 : code enhancement for D2C
,"CONTRACT CURRENCY" 
,"PARENT ACCOUNT"
--[+]END 20230428.1   = Santosh = NICORE-420 : code enhancement for D2C
--[+]BEGIN  20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added 
,"RBS NUMBER"
--[+]END 20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added
from markup_trans tr

union all
select :ORG AS "ORG", 'PRODUCT SUMMARY' AS COL1, NULL AS COL2, NULL AS COL3, NULL AS COL4, NULL AS COL5, NULL AS COL6,
NULL AS COL7, NULL AS COL8, NULL AS COL9, NULL, NULL, NULL
from dual

union all
select :ORG AS "ORG", 'PRODUCT' AS COL1, 'TRANS_COUNT' AS COL2, NULL AS COL3, 'SETTLEMENT AMOUNT' AS COL4,
'C/H BILLING AMOUNT' AS COL5, 'MARK UP' AS COL6,
'MARKED UP AMOUNT' AS COL7, 'BILLING AMOUNT' AS COL8, NULL AS COL9, NULL, NULL, NULL
from dual

union all
SELECT "ORG",
"BIN",
to_char("RECORD COUNT") "RECORD COUNT",
--to_char("TRANSACTION AMOUNT", 'FM999999990.00') || ' ' || curr "TRANSACTION AMOUNT",
NULL AS "TRANSACTION AMOUNT",
to_char("SETTLEMENT AMOUNT", 'FM999999990.00') || ' USD' "SETTLEMENT AMOUNT",
to_char("C/H BILLING AMOUNT" , 'FM999999990.00')|| ' ' || B_CURR "C/H BILLING AMOUNT",
to_char("MARK UP", 'FM999999990.00') || ' ' || B_CURR "MARK UP",
to_char("MARKED UP AMOUNT", 'FM999999990.00') || ' ' || B_CURR "MARKED UP AMOUNT",
to_char("BILLING AMOUNT", 'FM999999990.00') || ' ' || B_CURR "BILLING AMOUNT"
,NULL AS COL1
--[+]BEGIN 20230428.1   = Santosh = NICORE-420 : code enhancement for D2C
,NULL
,NULL
--[+]END 20230428.1   = Santosh = NICORE-420 : code enhancement for D2C
--[+]BEGIN  20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added 
,NULL
--[+]END 20230619.3   = GaukharA = NICORE-119 : EXID and RBS number added
FROM
(SELECT "ORG",
    --CURR,
    B_CURR,
--[*] 230111.1 = ANFE-171
    /*substr("CARD NUMBER",1,6) "BIN",*/
	BIN as "BIN",
--[*] 230111.1 = ANFE-171
    COUNT(substr("CARD NUMBER",1,6)) "RECORD COUNT",
    sum("TRANSACTION AMOUNT") "TRANSACTION AMOUNT",
    sum("SETTLEMENT AMOUNT") "SETTLEMENT AMOUNT",
    sum("C/H BILLING AMOUNT") "C/H BILLING AMOUNT",
   sum("MARK UP")  "MARK UP",
   sum("MARKED UP AMOUNT") "MARKED UP AMOUNT",
   sum("BILLING AMOUNT")  "BILLING AMOUNT"
   from markup_trans tr
--[*] 230111.1 = ANFE-171
/*group by org,substr("CARD NUMBER",1,6),B_CURR)*/
group by org,BIN,B_CURR)
--[*] 230111.1 = ANFE-171