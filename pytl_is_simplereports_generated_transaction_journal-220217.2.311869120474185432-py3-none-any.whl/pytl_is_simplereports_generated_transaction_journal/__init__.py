__version__ = "220217.2"
__job_name__ = "PyTL_IS_SimpleReports_GENERATED_TRANSACTION_JOURNAL"
__bat_files__ = []

