/*
* GENERATED TRANSACTION JOURNAL REPORT
*
* Version history:
* 220519.1 = RakeshG = ALMB-796: Added a condition to exclude few transaction codes
*/
with para as 
      (
      select /*+ no_merge materialize */ id institution_id,branch_code code,name
					  from (select dwd_institution.branch_code,
								   dwd_institution.posting_institution_id,
								   dwd_institution.id,
								   dwd_institution2.branch_code branch_code_posting,
                                   dwd_institution.name
							from dwd_institution
								 join dwd_institution dwd_institution2 on dwd_institution.posting_institution_id = dwd_institution2.id
							where dwd_institution.record_state = 'A'
							) inst
					  start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
													  from dual 
													  connect by regexp_substr(:ORG , '[^,]+', 1, level) is not null
													  )
					  connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2      
      )
select /*+ use_hash(td co) use_hash(co dcl) */
    para.code "ORG",
    co.personal_account "ACCOUNT NUMBER", 
    to_char(nvl(trunc(td.trans_date),trunc(td.banking_date)),'DD-MM-YYYY') "TRANSACTION DATE",
    td.txn_code                                      as "TRANSACTION MSG TYPE",
    td.amount                                        as "TRANSACTION AMOUNT",
	coalesce(td.trans_rrn, td.trans_arn, td.trans_srn, to_char(td.primary_doc_idt), to_char(td.primary_operation_idt)) as "TRANS REFERENCE NUMBER",
    td.source_channel                                as "SOURCE_CODE",
    nvl(td.posting_status,'P')                       as "POSTING_STATUS",
    co.block_code_1                                  as "BLOCK_CODE_1",
    co.block_code_2                                  as "BLOCK_CODE_2"
from opt_dm_nice_contract_info co
    join para
        on para.code = co.org
    join opt_dm_nice_transaction_info td
        on td.contract_idt  = co.record_idt
where 
    co.banking_date   = to_date(:P_REPORT_DATE, 'dd-MM-yyyy')
    and td.banking_date  = to_date(:P_REPORT_DATE, 'dd-MM-yyyy')   
and td.oper_type_add_info like '%GEN=Y;%'
and nvl(instr(td.oper_type_add_info,'TDUMP_EXCLUDE_GROUP=Y;'),0) = 0  --[+]220519.1 = RakeshG = ALMB-796