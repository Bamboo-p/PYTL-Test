__version__ = "230823.1"
__job_name__ = "PyTL_IS_SimpleReports_INSTANT_CARD_ISSUANCE"
__bat_files__ = []

