/*
* INSTANT_CARD_ISSUANCE
*
* Version history:
* 21112022.1 = Akshay = ECCBAU-6074 : Initial Version
* 221123.1 = Akshay = ECCBAU-6156: modifications in mapping for src channel & txn_flag fields
* 230110.1 = RakeshG = ECCBAU-6210:Instant issuance phase 2, updated Mapping for TEMPORARY_LIMIT,DIGITAL_CARD and PHYSICAL_CARD
* 230719.1 = RakeshG = ECCBAU-6490:Added subqueries,removed commented joins and mapping changes for the FULL CRedit limit and Temporary limit
* 230823.1 = RakeshG = EIB-9947:Added production event for instant issuance card
*/

with /*INSTANT_CARD_ISSUANCE*/
attr as (
select dca.contract_idt
          from dwa_contract_attribute dca
          join dwd_attribute da
            on da.id = dca.attr_id
           and da.record_source = 'W4CUSTOM'
           and da.code          = 'BANK_DATE_OPEN'
           and da.type_code     = 'DWD_ATTRIBUTE_CONTRACT_APPL_INFO'
         where dca.attr_date_from = to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
           and dca.attr_date_to   >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
)
--[+] begin 230719.1 = RakeshG = ECCBAU-6490:Added subqueries Mapping changes for the FULL CRedit limit and Temporary limit
,inst as (
        SELECT /*+ no_merge */
               inst.id,
               inst.branch_code,
               inst.branch_code_posting,
               inst.HeadInstitutionName,
               inst.posting_institution_id
          FROM (SELECT dwd_institution.branch_code,
                       dwd_institution.posting_institution_id,
                       dwd_institution.id,
                       dwd_institution2.branch_code branch_code_posting,
                       dwd_institution2.name HeadInstitutionName
                  FROM dwd_institution
                  JOIN dwd_institution dwd_institution2
                    ON dwd_institution.posting_institution_id = dwd_institution2.id
                 WHERE dwd_institution.record_state = 'A'
                ) inst
                START WITH inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                                from dual
                                                connect by regexp_substr(:ORG , '[^,]+', 1, level) is not null)
                CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = prior inst.id
              AND level <= 2
)
, cards as (
select dc.*
  from dwd_Card dc
  join inst on inst.id = dc.institution_id
  join dwd_production_service serv
    on serv.id = dc.production_service_id
   and serv.record_state    = 'A'
   and serv.code in ('NVC','RDPC')    --[*] 230823.1 = RakeshG = EIB-9947:Added production event
 where dc.opening_date = to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
   and dc.record_date_from <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
   and dc.record_date_to >= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
)
, cr_limit as (
select /*+ no_merge ordered use_nl(l)*/
       cs.record_idt as card_idt,
       l.contract_idt,
       l.full_amount as cr_limit,
       decode(l.prev_full_amount,0,null,l.prev_full_amount) as full_cr_limit,
       row_number() over(partition by cs.record_idt,l.contract_idt order by l.creation_date desc,l.cr_history_idt desc) as rn
from cards cs
join dwf_credit_limit l on cs.main_contract_idt = l.contract_idt
 and l.action_type = 'FIN_LIMIT'
 and l.banking_Date = cs.opening_date
)
--[+] end 230719.1 = RakeshG = ECCBAU-6490:Added subqueries Mapping changes for the FULL CRedit limit and Temporary limit
select
dc.pan as card_number
,odci.contract_number as account_number
,odci.client_number as customer_number
,trim(dc.embossed_first_name || ' ' || dc.embossed_last_name) as embossing_name
,NVL(DECODE(card_attr.virtual_card,'Y',cr.full_cr_limit,'F',cr.full_cr_limit),odci.credit_limit) as full_credit_limit -- [*] 230719.1 = RakeshG = ECCBAU-6490:Mapping changes for the FULL CR
,Case when card_attr.virtual_card in ('Y','F') and cr.full_cr_limit is not null
               then odci.credit_limit
          else 0 end  as temporary_credit_limit                                           --[*] 230719.1 = RakeshG = ECCBAU-6490:Mapping changes for Temp CR
,odci.client_reg_number AS cif
,DECODE(dc.main_card_flag, 'Y', 'Primary','Supplementary') as card_type /* Primary/Supplementary*/
,auth.attr_value as reference_number
,odci.product_name as product_type
,sy_convert.get_tag_value(dc.add_info, 'SRC_CHANNEL') as source_channel --[+] 221123.1 = ECCBAU-6156 Akshay
,DECODE(card_attr.virtual_card,'Y','Y','F','Y','N') as digital_card_issued --[*] 230110.1 = ECCBAU-6210 RakeshG
,DECODE(card_attr.virtual_card,'Y','N','F','N','Y') as physical_card_issued --[*] 230110.1 = ECCBAU-6210 RakeshG
,nvl(card_attr.TOKEN_TXN,'N') as tokenized_txn_flag --[+] 221123.1 = ECCBAU-6156 Akshay
,nvl(card_attr.ECOM_TXN,'N') as ecom_txn_flag   --[+] 221123.1 = ECCBAU-6156 Akshay
,nvl(card_attr.POS_TXN,'N') as pos_txn_flag --[+] 221123.1 = ECCBAU-6156 Akshay
,nvl(card_attr.ATM_TXN,'N') as atm_txn_flag --[+] 221123.1 = ECCBAU-6156 Akshay
from cards dc                                                                  --[*] 230719.1 = RakeshG = ECCBAU-6490: Added subqueries
join OPT_DM_CONTRACT_INFO odci on dc.MAIN_CONTRACT_IDT = odci.CONTRACT_IDT
    and odci.banking_date = to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
    and odci.org = :ORG
left join attr on attr.contract_idt = dc.record_idt
left join OPT_DM_TD_AUTH_SCHEME auth on auth.contract_idt=attr.contract_idt
    and auth.code='REF_NUMBER'
    and auth.banking_date=to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
    and auth.org = :ORG
LEFT JOIN (select t.card_idt,
       max(case when t.type_code = 'TF_ATM' then t.code else null end) as ATM_TXN,
       max(case when t.type_code = 'TF_POS' then t.code else null end) as POS_TXN,
       max(case when t.type_code = 'TF_ECOM' then t.code else null end) as ECOM_TXN,
       max(case when t.type_code = 'TF_TOKEN' then t.code else null end) as TOKEN_TXN,
       max(case when t.type_code = 'VIRTUAL_CARD' then t.code else null end) as VIRTUAL_CARD --[+] 230110.1 = ECCBAU-6210 RakeshG
from (select /*+ no_merge */
             a.id attr_id,
             a.code,
             a.type_code,
             da.card_idt,
             attr_date_from,
             attr_date_to,
             da.details
        from dwa_card_attribute da
        join dwd_attribute a on da.attr_id = a.id
         and (to_date(:P_REPORT_DATE,'DD-MM-YYYY') between da.attr_date_from and da.attr_date_to)
         and da.active_state != 'C'
         and a.type_code in ('TF_ATM','TF_POS','TF_ECOM','TF_TOKEN','VIRTUAL_CARD')) t  --[*] 230110.1 = ECCBAU-6210 RakeshG
         group by t.card_idt) card_attr
         ON card_attr.card_idt = dc.record_idt
  left join cr_limit cr on cr.card_idt = dc.record_idt and cr.rn = 1  --[+] 230719.1 = RakeshG = ECCBAU-6490:Mapping changes