/*
* CODE FOR AJMAN MONTHLY REPORT ON REWARDS ADJUSTED REPORTS
* PyTL_IS_SimpleReports_MONTHLY_AJM_MC_MANUAL_ADJ_PNTS_RPT=MONTHLY_AJM_MC_MANUAL_ADJ_PNTS.SQL
* Parameters:
    ORGLIST            = '031' or '021,022,023'
    P_BANK_DATE        = 'DD-MM-YYYY' = SYSDATE
* VERSION HISTORY:
* 230812.1 = KOKILA J = AJM-4617 : AJMAN MONTHLY REPORT ON REWARDS ADJUSTED REPORTS
* 231116.1 = KOKILA J = AJM-4617 : Adding sign to the amount column
*/WITH inst AS ( /* AJM_MC_MANUAL_ADJ_PNTS_RPT */
    SELECT
        ins.name,
        ins.code   AS org,
        ins.institution_id
    FROM
        v_dwr_institution ins
    WHERE
        code = :ORGLIST
        AND type_code = 'BANK_DESC'
), ot AS (
    SELECT /*+ no_merge materialize */
        *
    FROM
        v_dwr_operation_type op
    WHERE
        type_code = 'TXN_CODE'
        AND class_code = :ORGLIST || '_TXN_CODE'
        AND nvl(instr(upper(op.add_info), 'MANUALADJ_REP=Y;'), 0) > 0
), entries AS (
    SELECT /*+ no_merge ordered index(e DWF_ACCOUNT_ENTRY_INST_IDX) no_index(e DWF_ACCOUNT_ENTRY_OP_IDX) */
        e.banking_date,
        e.contract_idt,
        e.primary_doc_idt,
        e.operation_type_id,
        ot.code,
        SUM(e.credit - e.debit) AS amount,
        ot.name   AS txn_description
    FROM
        dwf_account_entry e
        JOIN inst ON inst.institution_id = e.institution_id
        JOIN ot ON ot.operation_type_id = e.operation_type_id
    WHERE
        e.banking_date BETWEEN trunc(TO_DATE(:P_BANK_DATE, 'dd-MM-yyyy') - 1, 'MM') AND last_day(TO_DATE(:P_BANK_DATE, 'dd-MM-yyyy'
        ) - 1)
    GROUP BY
        e.banking_date,
        e.contract_idt,
        e.primary_doc_idt,
        e.operation_type_id,
        ot.code,
        ot.name
)
SELECT /*+ index(trans DWF_TRANSACTION_DOCID_IDX) */
    :ORGLIST as org,
    regexp_substr(c.add_info, '(LTY_ID_2+)=([^;]+);', 1, 1, '', 2) AS LOYALTY_ID,
    replace(TO_CHAR(trans.trans_date, 'YYYY-DD-MM HH24/MI/SS'),'/',':') AS TRANSACTION_TIME,
    nvl(entries.amount, 0) AS POINTS_ADJUSTED,
    DECODE(trans.direction, 1, 'CR', - 1, 'DR') AS TRAN_SIGN,
    c.personal_account   AS ACCOUNT_NUMBER
FROM
    entries
    JOIN dwd_contract c ON c.record_idt = entries.contract_idt
    JOIN dwd_product p ON p.id = c.product_id
                          AND p.record_state = 'A'
    JOIN dwd_card_brand cb ON cb.id = p.card_brand_id
                              AND cb.record_state = 'A'
                              AND payment_scheme_code = 'E'
    JOIN dwf_transaction trans ON entries.primary_doc_idt = trans.doc_idt
                                  AND trans.institution_id = (
        SELECT
            institution_id
        FROM
            inst
    )
                                  AND trans.banking_date = entries.banking_date
WHERE
    c.record_date_from <= TO_DATE(:P_BANK_DATE, 'dd-MM-yyyy')
    AND c.record_date_to >= TO_DATE(:P_BANK_DATE, 'dd-MM-yyyy')