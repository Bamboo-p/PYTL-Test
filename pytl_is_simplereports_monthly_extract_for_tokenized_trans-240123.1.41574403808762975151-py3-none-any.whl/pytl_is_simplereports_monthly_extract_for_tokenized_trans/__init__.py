__version__ = "240123.1"
__job_name__ = "PyTL_IS_SimpleReports_MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS"
__bat_files__ = []

