/*
ENG-3666: Konstantin Akulshin 02 Jul 2021: Monthly Extract for Tokenized Transactions https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/197c66dfcd386080a45502bacc7f4072afbfa24b#pytl_jobs/NIC/PyTL_IS_SimpleReports_MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS/sql/MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS.sql
ENG-3666: Konstantin Akulshin 07 Jul 2021: SQL fixed as join conditions changed https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/5876f4b39a4e6b44f131e81a0c581ae1d79dbb06#pytl_jobs/NIC/PyTL_IS_SimpleReports_MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS/sql/MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS.sql
ENG-3666: Konstantin Akulshin 08 Jul 2021: fix for duplicates https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/bd0d57d47e71670963a45cb27e30456de22ba479#pytl_jobs/NIC/PyTL_IS_SimpleReports_MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS/sql/MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS.sql
ENG-3818: Santosh Kumar Singh 01 Sep 2021: chnages done to pull token name https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/aff431fee8946998f494cbfb2ca482cf4d4d24be#pytl_jobs/NIC/PyTL_IS_SimpleReports_MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS/sql/MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS.sql
OPKSAIC-1693: deniska 13 Dec 2021: renaming directory with job NIC_IS_Ou_SimpleReports into PyTL_IS_SimpleReports/PyTL_IS_SimpleReports.* https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/4dc1d4ef281ba3437ea2cbe543a7b6bbf42b6eb5#pytl_jobs/NIC/PyTL_IS_SimpleReports/sql/MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS.sql
ALMB-474: deniska 17 Feb 2022: PyTL_IS_SimpleReports_MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/2dc5e3302b5ff8f4f3da35d4cc000bab08592e44
ALMB-474: deniska 05 Apr 2022: Fixed DB_SOURCE in *.bat files, added MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS(GET_TEST_DATA).sql
ALMB-852: Shalini 24 Jun 2022: Changes for NET TRANSACTION AMOUNT,NET POS TRANSACTION AMOUNT,NET IN-APP-TRANSACTION AMOUNT
NICORE-973: GaukharA 27 Nov 2023: adding EXID
IB-761 : 240123.1 : KhaledO : Modified the amountS to handle minus values
*/
with ORG_LIST /*SimpleReports with MONTHLY_EXTRACT_FOR_TOKENIZED_TRANS.sql*/
as
(
  select inst.branch_code
       , inst.id
    from (select inst1.branch_code
               , inst1.id
               , inst1.posting_institution_id
            from dwh.dwd_institution inst1 join dwh.dwd_institution inst2 on (inst1.posting_institution_id = inst2.id)
               where inst1.record_state = 'A'
                 and inst2.record_state = 'A'
          ) inst
      start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                         from dual
                                           connect by regexp_substr(:ORG , '[^,]+', 1, level) is not null
                                     )
      connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id
             and level <= 2
)
, sy_handbook
  as
  (
    SELECT /*+ materialize*/
           coalesce(org_conf.filter2, default_conf.filter2) as token_req_id,
           --coalesce(org_conf.filter5, default_conf.filter5) as token_req_ind
		   coalesce(org_conf.name, default_conf.name) as wallet_name
      FROM (select filter2
				 , code
				 --, filter5
				 , name
			   from DWH.c$sy_handbook t join ORG_LIST on (t.filter = ORG_LIST.branch_code)
				 where t.amnd_state = 'A'
				   and t.group_code = 'TOKEN_REQUESTOR'
			) org_conf
			FULL OUTER JOIN (select *
							   from DWH.c$sy_handbook tt
								where tt.filter = '000'
								   and tt.group_code = 'TOKEN_REQUESTOR'
								   and tt.amnd_state = 'A'
							) default_conf
			ON (org_conf.filter2 = default_conf.filter2)
  )
--[*] begin : 231127.1 = GaukharA = NICORE-698 : Alternate Id (EXID) logic field added
,exid as (
	select /*+no_merge materialize */
	       dca.card_idt,
		   dca.attr_value card_exid
	  from dwa_card_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CARD'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	)
--[*] end : 231127.1 = GaukharA = NICORE-698 : Alternate Id (EXID) logic field added

  
  
select /*+ PARALLEL(odt, 4) */
       org_list.branch_code                                                                                                                            as ORG
     , rpad(dwh.sy_convert.get_tag_value(odt.trans_info,'D_TKN'), 16, ' ')                                                                             as "TOKEN NUMBER (KEY)"
     , decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)),'Y',exid.card_exid, rpad(pan, 16, ' '))                                                    as "CARD NUMBER"
     , sy_hand.wallet_name                                                                                                             				   as "WALLET TYPE"
     , lpad(count(1), 7, '0')                                                                                                                          as "TOTAL TRANSACTION COUNT"
     , CASE
        WHEN sum(settl_amount * direction) < 0 THEN
            '-' || LPAD(REPLACE(TO_CHAR(abs(sum(settl_amount * direction)), 'fm99999999.00'), '.', ''), 11, '0')
        ELSE
            LPAD(REPLACE(TO_CHAR(sum(settl_amount * direction), 'fm99999999.00'), '.', ''), 11, '0')
        END as "NET TRANSACTION AMOUNT" --[*] 220624 = ALMB-852  --[*] 240123.1 : KhaledO : Modified the amount to handle minus values                                                                 
     , lpad(sum(case when instr(dtc.condition_list,',ENET,') > 0 then 0 else 1 end), 7, '0')                                                           as "POS TRANSACTION COUNT"
     , CASE
        WHEN sum(case when instr(dtc.condition_list,',ENET,') > 0 then 0 else settl_amount * direction end) < 0 THEN
            '-' || lpad(replace(to_char(abs(sum(case when instr(dtc.condition_list,',ENET,') > 0 then 0 else settl_amount * direction end)),'fm99999999.00'), '.', ''),11,'0')
        ELSE
            lpad(replace(to_char(sum(case when instr(dtc.condition_list,',ENET,') > 0 then 0 else settl_amount * direction end),'fm99999999.00'), '.', ''),11,'0')
        END as "NET POS TRANSACTION AMOUNT" --[*] 240123.1 : KhaledO : Modified the amount to handle minus values   
     , lpad(sum(case when instr(dtc.condition_list,',ENET,') > 0 then 1 else 0 end), 7, '0')        as "IN-APP TRANSACTION COUNT"
     , CASE
        WHEN sum(case when instr(dtc.condition_list,',ENET,') > 0 then settl_amount * direction else 0 end) < 0 THEN
            '-' || lpad(replace(to_char(abs(sum(case when instr(dtc.condition_list,',ENET,') > 0 then settl_amount * direction else 0 end)),'fm99999999.00'), '.', ''),11,'0')
        ELSE
            lpad(replace(to_char(sum(case when instr(dtc.condition_list,',ENET,') > 0 then settl_amount * direction else 0 end),'fm99999999.00'), '.', ''),11,'0')
        END as  "NET IN-APP-TRANSACTION AMOUNT" --[*] 220624 = ALMB-852  --[*] 240123.1 : KhaledO : Modified the amount to handle minus values   
     , lpad(min(dwh.sy_convert.get_tag_value(odt.trans_info,'WSP_REQ_ID')),11,'0')                                                                     as "TOKEN REQUESTOR ID"
  from dwh.opt_dm_nice_transaction_info odt join dwh.DWD_TRANS_CONDITIONS dtc on (odt.TRANS_CONDITIONS_ID = dtc.id
                                                                                   and dtc.condition_list like '%,TOKEN,%'
                                                                                  )
                                        join dwh.dwd_card dc on (odt.card_idt = dc.record_idt
                                                                 and dc.record_state = 'A'
                                                                )
                                        join sy_handbook sy_hand on (DWH.sy_convert.get_tag_value(odt.trans_info,'WSP_REQ_ID') = sy_hand.token_req_id)
                                        join ORG_LIST on (odt.org = org_list.branch_code)
                                        left join exid 
    on exid.card_idt = odt.card_idt  
    where odt.banking_date between add_months(trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy') ,'MM'),-1) and last_day(add_months(trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy') ,'MM'),-1))
      and odt.is_fee = '1'
    group by org_list.branch_code
           , rpad(dwh.sy_convert.get_tag_value(odt.trans_info,'D_TKN'), 16, ' ')
           , decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)),'Y',exid.card_exid, rpad(pan, 16, ' ')) 
           , sy_hand.wallet_name
           