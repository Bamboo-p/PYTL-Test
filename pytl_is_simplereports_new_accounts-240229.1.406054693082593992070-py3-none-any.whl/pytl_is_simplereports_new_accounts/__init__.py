__version__ = "240229.1"
__job_name__ = "PyTL_IS_SimpleReports_NEW_ACCOUNTS"
__bat_files__ = []
