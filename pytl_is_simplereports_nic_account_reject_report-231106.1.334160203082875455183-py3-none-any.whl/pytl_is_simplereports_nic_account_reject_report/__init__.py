__version__ = "231106.1"
__job_name__ = "PyTL_IS_SimpleReports_NIC_Account_Reject_Report"
__bat_files__ = []

