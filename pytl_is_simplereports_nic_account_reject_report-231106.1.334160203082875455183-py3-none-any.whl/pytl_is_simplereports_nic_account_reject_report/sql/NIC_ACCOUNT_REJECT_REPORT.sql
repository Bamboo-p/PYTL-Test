/*
* 231106.1 = GaukharA = NICORE-929 : INITIAL REPORT
*/
with ins as (
select /*+ materialize */ id p_f_i,bank_code,name
                      from (select fi.bank_code,
                                   fi.posting_in,
                                   fi.id,
                                   fi2.bank_code bank_code_posting,
                                   fi.name
                            from ows.f_i fi
                                 join ows.f_i fi2 on fi.posting_in = fi2.id
                            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
                            ) inst
                      start with inst.bank_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                                      from dual 
                                                      connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
                                                      )
                      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
), 

ddate as (
select /*+ materialize */
       min(calendar_date) as from_Date,
       max(calendar_date) as rep_Date
  from ows.mp_consist_point
  where local_date in (to_date(:P_REPORT_DATE,'DD-MM-YYYY'),to_date(:P_REPORT_DATE,'DD-MM-YYYY')-1)
    and mp_consist_type__oid = (select min(id) from ows.mp_consist_type where code = 'END_DAY')
    )
        
select /*+ parallel(8) index(d doc_date) use_hash(d) pq_distribute(d broadcast none) use_hash(rc) use_hash(settl) use_hash(cur)*/
    :ORG                                           "ORG",
    :P_REPORT_DATE                              as "DATE OF REPORT",
    AC.CONTRACT_NAME                            AS "CUSTOMER NAME" ,                                
    cl.CLIENT_NUMBER                            as "CLIENT NUMBER",
    D.TARGET_NUMBER                             as "IBAN",
    to_char(D.POSTING_DATE, 'dd-mm-yyyy')       AS "DATE OF DEPOSIT",
    to_char(d.trans_amount, '99999999990.90')   as "TRANSACTION AMOUNT",
    cur.name                                    as "TRANSACTION CURRENCY",
    d.ret_ref_number 						    as "RRN",
    rc.resp_text                                as "REJECT REASON"
from
    ows.doc d
    join ddate on 1 = 1
    join ows.currency cur on cur.code = d.trans_curr
                             and cur.amnd_state = 'A'
    join ows.currency settl on settl.code = d.settl_curr
                               and settl.amnd_state = 'A'
    join ows.resp_code rc on rc.resp_code = d.return_code
                             and rc.amnd_state = 'A'
    left join ows.trans_type tr on d.trans_type = tr.id
    left join ows.acnt_contract ac on d.target_number = ac.contract_number
                                     and ac.amnd_state = 'A'
                                     and ac.f_i in (select p_f_i from ins)
                                     and ac.acnt_contract__oid is null 
    join ows.client cl on ac.client__id=cl.id and cl.amnd_state='A'                                 
    left join ows.appl_product ap on ap.id = ac.main_product  
    
  where
    d.amnd_date between from_date and rep_Date
     and d.amnd_state = 'A'
     and d.posting_status in ('D', 'J', 'E')
     and d.is_authorization = 'N'
     and d.trans_curr != '000'
     and (ac.pcat != 'B' or ac.pcat is null or return_code='14')