__version__ = "240723.1"
__job_name__ = "PyTL_IS_SimpleReports_NIC_ACTIVITY_RECAP"
__bat_files__ = ["NIC_IS_Ou_ActivityRecap.bat"]

