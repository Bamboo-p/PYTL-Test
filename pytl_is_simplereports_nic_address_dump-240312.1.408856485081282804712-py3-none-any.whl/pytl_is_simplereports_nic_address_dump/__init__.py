__version__ = "240312.1"
__job_name__ = "PyTL_IS_SimpleReports_NIC_ADDRESS_DUMP"
__bat_files__ = []

