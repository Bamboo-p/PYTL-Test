/*
27-12-2021 : OPKSAIC-2793 : enhancing existing standard report to add KSA requirements
                            1. Added alternate number logic to enhance report to EXID in the report based on input parameter
					        2. New input parameter RETURN_EXID introduced to fetch alternate id instead of PAN
							   possible inputs : RETURN_EXID=Y - fetches alternate id instead of card number
												 RETURN_EXID=N - fetches card number
												 RETURN_EXID=null - fetches card number
16-01-2022 : OPKSAIC-3246 : RETURN_EXID is spitted into RETURN_EXID_CARD / RETURN_EXID_CONTRACT
                            For Tiqmo RETURN_EXID_CONTRACT is not applicable , but default value is NO
220420.1 = Shalini = ALMB-766: Mapping changes for phone_mobile field for client
240312.1 = Santosh = NICORE-1245 : Mapping changes for phone_mobile field for card/contract
*/
WITH fi AS (
    SELECT
        id            institution_id,
        branch_code   code,
        name,
        add_info
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code   branch_code_posting,
                dwd_institution.name,
                dwd_institution.add_info
            FROM
                dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
),
ext_id_card as (
	select /*+no_merge materialize */
	       dca.card_idt,
		   dca.attr_value exid
	  from dwa_card_attribute dca
	  join dwd_attribute da
	    on dca.attr_id = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CARD'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	),
ext_id_contract as (
	select /*+no_merge materialize */
	       dca.contract_idt,
		   dca.attr_value exid
	  from dwa_contract_attribute dca
	  join dwd_attribute da
	    on dca.attr_id = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CONTRACT'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	)
SELECT
    fi.code              AS org,
    fi.code              AS institution_branch_code,
    fi.name              AS institution_name,
    'CLIENT' AS source,
    cl.client_number,
    cl.short_name,
    cl.title,
    cl.last_name,
    cl.first_name,
    cl.middle_name,
    cl.ident_number,
    NULL AS contract_number,
    dat.code as address_type_code,
    dat.name as address_type_name,
    da.language,
    da.country,
    da.region_code,
    da.state,
    da.city as city,
    da.address_line_1 as address_line_1,
    da.address_line_2 as address_line_2,
    da.address_line_3 as address_line_3,
    da.address_line_4 as address_line_4,
    da.e_mail as e_mail,
    da.phone as phone,
    da.phone_home as phone_home,
    decode(dat.code,'ADD_SMS_1',da.address_zip,da.phone_mobile) as phone_mobile,--[*] 220420.1 = ALMB-766
    da.fax as  fax,
    da.fax_home as fax_home,
    da.url as url,
    da.location as location,
    da.title as address_title,
    da.title_suffix as address_title_suffix,
    da.first_name as address_first_name,
    da.last_name as address_last_name,
    bank_officer.name AS bank_officer_name,
    bank_officer.login AS bank_officer_login
FROM
    dwd_address da
    JOIN fi ON fi.institution_id = da.institution_id
    JOIN dwd_address_type dat ON da.address_type_id = dat.id
    JOIN dwd_client cl ON da.client_idt = cl.record_idt
                          AND cl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                          AND cl.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    LEFT JOIN dwd_bank_officer bank_officer ON bank_officer.id = da.bank_officer_id
WHERE
    ( :P_MODE = 'INCREMENTAL'
      AND da.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
      AND da.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
    OR ( :P_MODE = 'FULL'
         AND da.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
         AND da.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
UNION ALL
SELECT
    fi.code              AS org,
    fi.code              AS institution_branch_code,
    fi.name              AS institution_name,
    CASE
        WHEN cnt.record_idt IS NOT NULL THEN 'CONTRACT'
        WHEN card.record_idt IS NOT NULL THEN 'CARD'
        ELSE 'NA'
    END AS source,
    NULL AS client_number,
    NULL AS short_name,
    NULL AS title,
    NULL AS last_name,
    NULL AS first_name,
    NULL AS middle_name,
    NULL AS ident_number,
    CASE WHEN cnt.record_idt IS NOT NULL THEN decode( upper(substr(nvl(:RETURN_EXID_CONTRACT,'N'),1,1)), 'Y',eico.exid, cnt.personal_account )
         WHEN card.record_idt IS NOT NULL THEN decode( upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',eica.exid, card.pan ) 
    ELSE NULL END AS contract_number,
    dat.code as address_type_code,
    dat.name as address_type_name,
    da.language,
    da.country,
    da.region_code,
    da.state,
    da.city as city,
    da.address_line_1 as address_line_1,
    da.address_line_2 as address_line_2,
    da.address_line_3 as address_line_3,
    da.address_line_4 as address_line_4,
    da.e_mail as e_mail,
    da.phone as phone,
    da.phone_home as phone_home,
	decode(dat.code,'ADD_SMS_1',da.address_zip,da.phone_mobile) as phone_mobile,--[*] 240312.1 = NICORE-1245
    da.fax as  fax,
    da.fax_home as fax_home,
    da.url as url,
    da.location as location,
    da.title as address_title,
    da.title_suffix as address_title_suffix,
    da.first_name as address_first_name,
    da.last_name as address_last_name,
    bank_officer.name AS bank_officer_name,
    bank_officer.login AS bank_officer_login
FROM dwd_contract_address da
    JOIN fi ON fi.institution_id = da.institution_id
    JOIN dwd_address_type dat ON da.address_type_id = dat.id
    LEFT JOIN dwd_card card ON da.contract_idt = card.record_idt
                               AND card.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                               AND card.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    LEFT JOIN dwd_contract cnt ON da.contract_idt = cnt.record_idt
                                  AND cnt.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                                  AND cnt.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    LEFT JOIN dwd_bank_officer bank_officer ON bank_officer.id = da.bank_officer_id
	LEFT JOIN ext_id_card eica ON eica.card_idt = card.record_idt
	LEFT JOIN ext_id_contract eico ON eico.contract_idt = cnt.record_idt
WHERE
    ( :P_MODE = 'INCREMENTAL'
      AND da.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
      AND da.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
    OR ( :P_MODE = 'FULL'
         AND da.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
         AND da.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )