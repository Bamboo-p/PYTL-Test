/*
* AECB EXTRACT = NIC_AECB_Extract.sql
*
* Version history:
* 20220407.1 = Shalini = ALMB-470 :  Initial development
* 20220421.1 = Shalini = ALMB-769 :  Mapping changes for IslamicContractFlag,SecuredContractFlag
* 20220531.1 = Shalini = ALMB-838 :  Query optimization
* 20220808.1 = RakeshG = ALMB-873 :  Added record date condition to fix Duplicate issue
* 20221004.1 = Santosh = ENG-4715 :  Changes done to include additional fields
* 20221012.1 = Santosh = ENG-4715 :  mapping correction for occupation
* 20221013.1 = Santosh = ENG-4715 :  field name change
* 20230705.1 = Shalini = ANFE-228 :  Logic changes to exclude purged contracts from the next day of purged date
* 20230710.1 = Shalini = ANFE-228 : Comments updated
* 20231127.1 = GaukharA = NICORE-976: Adding EXID
* 20231228.1 : Santosh - NICORE-1033 : Enable txn code and txn name override
* 20240118.1 : KhaledO - ANFE-285 : Changed the EmiratesId value from IDENT_DETAILS to IDENT_NUMBER
*/
with
inst AS (
    SELECT /*+ NO_MERGE MATERIALIZE */
        id          as institution_id,
        branch_code as org_code,
        name,
        add_info
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code   branch_code_posting,
                dwd_institution.name,
                dwd_institution.add_info
            FROM
                dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    start with inst.branch_code in (
        select trim(regexp_substr(:ORG, '[^,]+', 1, level))
        from dual
        connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
    )        
    CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
),

product as (
SELECT /*+ no_merge materialize */
    p.product_id,
    substr(p.code, 1, 3) AS logo,
    p.code,
    p.name
FROM
    v_dwr_product p
    JOIN inst ON inst.org_code = nvl(substr(p.code, 5, 3), '0')
WHERE
    p.class_code = 'BASE_REPORTS'
    AND p.type_code = 'LOGO'
    ),

contracts as (
SELECT /*+ no_merge materialize use_index(DWD_CONTRACT_INST_IDX dc) */
    DECODE(p.logo, NULL, dc.parent_contract_idt, dc.record_idt) AS main_contract_idt,
    dc.personal_account,
    dc.record_idt,
    dc.client_idt,
    DECODE(dc.base_currency, curr.code, curr.name) AS base_currency,
    dc.date_open,
    dc.date_close,
    dc.add_info,
    p.name,
    p.logo,
    dc.record_date_from,
    status_id,
    i.org_code,
    sy_convert.get_tag_value(dip.add_info,'IS_ISLAMIC') as islamic_flag,
    dc.institution_id

FROM
    dwd_contract dc
    JOIN inst i ON dc.institution_id = i.institution_id
    LEFT JOIN product p ON p.product_id = dc.product_id
    LEFT JOIN dwd_currency curr ON dc.base_currency = curr.code
    LEFT JOIN DWD_INT_PRODUCT dip
    on p.product_id=dip.product_id
    and dip.record_state='A'
WHERE
    dc.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND dc.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
      and dc.client_category='P'
      ),
bal as(
SELECT /*+ no_merge materialize */
    ag.account_group_id,
    ag.type_code
FROM
    v_dwr_account_group ag
WHERE
    ag.class_code = 'BALANCE_TYPE'
    AND ag.type_code  in ('TOTAL_BALANCE','PAST_DUE','TOTAL_DUE')
     ),
balances as (
SELECT /*+ no_merge use_index(DWF_ACC_BALANCE_INST_IDX b) ordered full(b) hash(b c) use_hash(b ag) */
    c.record_idt,
    SUM(CASE WHEN ag.type_code = 'TOTAL_BALANCE' THEN b.balance ELSE 0 END) AS total_balance,
    SUM(CASE WHEN ag.type_code = 'PAST_DUE' THEN b.balance ELSE 0 END) AS past_due,
    SUM(CASE WHEN ag.type_code = 'TOTAL_DUE' THEN b.balance ELSE 0 END) AS total_due
FROM
    dwf_account_balance b
    JOIN inst ON inst.institution_id=b.institution_id
    JOIN contracts c ON c.record_idt = b.contract_idt
    JOIN bal ag ON ag.account_group_id = b.account_group_id
WHERE
    b.banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    AND b.institution_id = inst.institution_id
GROUP BY
    c.record_idt
     ),
last_operations AS
  (SELECT /*+ no_merge materialize */
            operation_type_id,
            type_code,
            code
  FROM v_dwr_operation_type
  WHERE class_code = 'LAST_ACTIVITY_MARTS'
  AND type_code   IN ('LAST_OPER_LTD','TRANS_DT')
  AND code        IN ('TRANS_DT','RETAIL','PAYMENT')
  ),

last_payment as (SELECT /*+ ordered use_hash(entry l) */
                contract_idt,
                MAX(CASE WHEN value_code = 'PAYMENT'   THEN operation_date END) AS last_payment_date,
                MAX(CASE WHEN value_code = 'PAYMENT'   THEN amount END) AS last_payment_amount,
                MAX(CASE WHEN value_code = 'TRANS_DT'  THEN amount END) AS last_debit_amount
             FROM (SELECT NVL(entry.contract_idt, l.contract_idt)       AS contract_idt,
                          NVL(entry.type_code, l.type_code)             AS type_code,
                          NVL(entry.code, l.value_code)                 AS value_code,
                          NVL(entry.operation_date, l.operation_date)   AS operation_date,
                          NVL(entry.amount, l.amount)                   AS amount
                   FROM (SELECT /*+ no_merge index(l dwm_last_oper_inst_idx) */
                             l.contract_idt,
                             l.type_code,
                             l.value_code,
                             l.operation_date,
                             l.amount
                          FROM dwm_last_operation l
                          JOIN inst i
                            ON i.institution_id  = l.institution_id
                         WHERE l.banking_date    = add_months(last_day(to_date(:P_REPORT_DATE,'dd-mm-yyyy')),-1)
                           AND l.type_code IN ('TURNOVERS','TRANS_DT')
                           AND l.value_code IN ('TRANS_DT','RETAIL','PAYMENT')
                         ) l
        FULL OUTER JOIN (SELECT /*+ no_merge use_index(DWF_ACCOUNT_ENTRY_INST_IDX e) */
                                 e.contract_idt,
                                 MAX(e.credit-e.debit) keep (dense_rank FIRST ORDER BY banking_date DESC, primary_entry_idt DESC) AS amount,
                                 MAX(e.banking_date) AS operation_date,
                                 op.type_code,
                                 op.code
                             FROM dwf_account_entry e
                             JOIN inst i
                               ON i.institution_id = e.institution_id
                             JOIN last_operations op
                               ON op.operation_type_id = e.operation_type_id
                            WHERE e.banking_date      > add_months(last_day(to_date(:P_REPORT_DATE,'dd-mm-yyyy')),-1)
                              AND e.banking_date      <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
                          GROUP BY e.contract_idt,
                                 op.type_code,
                                 op.code
                           ) entry
                         ON entry.contract_idt = l.contract_idt
                        AND entry.type_code     = l.type_code
                        AND entry.code          = l.value_code
                        )
                   GROUP BY contract_idt)
,Attr_code as (
SELECT /*+ use_index(dca DWA_CNTR_ATTR_DATE_TO_IDX)*/
    dca.contract_idt,
    max(case when da.type_code = 'DLQ_LEVEL'                 then da.code else null end) AS dlq_level,
    max(case when da.type_code = 'DIRECT_DEBIT' then dca.attr_date_from else null end) as direct_debit_date,
    max(case when da.type_Code = 'BFA_ACCOUNT_STATUS' then
                  case when da.code in ('9')
                  then 'C' else 'A' end
                  else null end) as account_status,
    max(case when da.type_code = 'BFA_ACCOUNT_STATUS' and da.code ='9'
             then dca.attr_date_from
             else null
             end) as close_date,
    max(case when da.type_code = 'AECB_STATUS_TYPE'                 then da.code else null end) AS aecb_status,
    max(case when da.type_code = 'AECB_STATUS_TYPE' then dca.attr_date_from else null end) as aecb_status_date
FROM
    dwa_contract_attribute dca
    JOIN dwd_attribute da ON da.id = dca.attr_id
    AND da.type_code IN ('DLQ_LEVEL','DIRECT_DEBIT','BFA_ACCOUNT_STATUS','AECB_STATUS_TYPE')
    JOIN contracts c ON c.record_idt = dca.contract_idt
WHERE
    dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND dca.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
GROUP BY
    dca.contract_idt
),

crlimit as (
SELECT /*+ no_merge use_index(dwf_limit_inst_idx lim) */
    contract_idt,
    amount   AS credit_limit
FROM
    dwf_contract_limit lim
    JOIN inst i ON i.institution_id = lim.institution_id
WHERE
    lim.banking_date = TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND lim.type_code = 'FIN_LIMIT'
),

tarr as (
SELECT
    repayment_percent,
    substr(dt.domain, 1, 3) AS orgcd
FROM
    dwd_ageing_tariff dat
    JOIN dwd_tariff dt ON dat.record_idt = dt.record_idt
    JOIN inst ON org_code=substr(dt.domain, 1, 3)
WHERE
    dat.record_state = 'A'
    AND dt.record_state = 'A'
    AND dt.type_code = 'MTP_TARIFF'
    AND substr(dt.domain, 1, 3) = org_code
),
--[*]BEGIN 20231228.1 : Santosh - NICORE-1033 : Enable txn code and txn name override
--ot as(/*+ no_merge */
--select ot.* from
-- v_dwr_operation_type ot 
--where ot.class_code = 'NIC_TXN_DESC'
--AND ot.type_code = 'NIC_TXN_DESC'
--),
ot as (
SELECT /*+ materialize*/
           default_conf.org_code,
           default_conf.operation_type_code,
           default_conf.operation_type_id,
           default_conf.direction,
           default_conf.add_info,
           coalesce(org_conf.code, default_conf.code) as txn_code,
		   coalesce(org_conf.name, default_conf.name) as txn_name
           
      FROM (select op.operation_type_code, op.code, op.name , op.add_info , op.operation_type_id, op.direction, inst.org_code
              from v_dwr_operation_type op
			  join inst on op.type_code = inst.org_code || '_TXN_DESC'
              where class_code = 'NIC_TXN_DESC'
			) org_conf
			FULL OUTER JOIN (select op.operation_type_code, op.code, op.name, op.add_info , op.operation_type_id, op.direction , inst.org_code
                               from v_dwr_operation_type op
                               join inst on 1=1
                              where class_code = 'NIC_TXN_DESC'
                                and type_code = 'NIC_TXN_DESC'
							) default_conf
			ON (org_conf.operation_type_code = default_conf.operation_type_code)
            and (org_conf.org_code = default_conf.org_code)
),
--[*]END 20231228.1 : Santosh - NICORE-1033 : Enable txn code and txn name override
amnt_month as
(
SELECT /*+no_merge use_index(DWF_ACCOUNT_ENTRY_INST_IDX ae)*/
    SUM(ae.debit) as amt_spent,
    ae.contract_idt
FROM
    dwf_account_entry ae
    JOIN inst i ON i.institution_id = ae.institution_id
    JOIN  ot ON ot.operation_type_id = ae.operation_type_id
	and ot.org_code = i.org_code
	AND nvl(instr(ot.add_info,'CTD=Y;'),0)>0
WHERE ae.banking_date > add_months(last_day(to_date(:P_REPORT_DATE,'dd-mm-yyyy')),-1)
AND ae.banking_date      <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
group by ae.contract_idt
),

  billing as(
select /*+ no_merge materialize */
                     contract_idt,
                     max(due_date) due_date,
                     max(case when rn=1 then period_start_date end) period_start_date,
                     max(case when rn=1 then billing_date end) billing_date,
                     max(case when rn=2 and due_date <= to_date(:P_REPORT_DATE,'dd-mm-yyyy') then due_date
                              when rn=3 then due_date end) prev_due_date
                from (

                select /*+ use_index (DWF_CNTR_BILL_INST_IDX dcb)*/
                             contract_idt,
                             due_date,
                             period_start_date,
                             billing_date,
                             dcb.add_info,
                             row_number() over(partition by contract_idt order by billing_date desc) rn
                        from dwf_contract_billing dcb
                        join inst on inst.institution_id = dcb.institution_id
                        join contracts cp on cp.record_idt = dcb.contract_idt
                       where dcb.billing_date >= add_months(to_date(:P_REPORT_DATE,'dd-mm-yyyy'), -2)
                         and dcb.period_start_date <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')

                         )
               where rn in (1,2,3)
               group by contract_idt
),
ctd as
(
SELECT /*+no_merge use_index(DWF_ACCOUNT_ENTRY_INST_IDX ae)*/
    SUM(ae.debit) as ctd_amt,
    ae.contract_idt

FROM
    dwf_account_entry ae
    JOIN inst i ON i.institution_id = ae.institution_id
     JOIN ot ON ot.operation_type_id = ae.operation_type_id
	 and ot.org_code = i.org_code
    join billing on ae.contract_idt=billing.contract_idt
    AND nvl(instr(ot.add_info,'CTD=Y;'),0)>0
WHERE ae.BILLING_DATE >= billing.period_start_date
AND ae.banking_date      <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
group by ae.contract_idt
),

entries as (
SELECT /*+ no_merge use_index(ae DWF_ACCOUNT_ENTRY_INST_IDX) use_hash(ae op) */
    ae.*
FROM
    dwf_account_entry ae
    JOIN inst i on i.institution_id=ae.institution_id
    JOIN billing ON billing.contract_idt = ae.contract_idt
WHERE
    ae.banking_date >= billing.period_start_date
    AND ae.banking_date <= billing.billing_date
               ),
ent_1 as(
Select count(1) as counter,
ae.contract_idt
from entries ae
JOIN inst i on i.institution_id=ae.institution_id
join ot on ot.operation_type_id = ae.operation_type_id
and ot.org_code = i.org_code
and ot.direction=-1
GROUP BY ae.contract_idt
)
,DPD_levels as (select delq_bill.contract_idt,
                    (case  WHEN attr.dlq_level IN ('0','1') THEN '0'
                           else
                           nvl(to_char((to_date(:P_REPORT_DATE,'dd-mm-yyyy') - delq_bill.prev_due_date) + ((to_number(attr.dlq_level) - 2)*30 )),'0')
                    end) DPD
              from
                    attr_code attr
                    join billing delq_bill on delq_bill.contract_idt = attr.contract_idt

  ),
events as (
    SELECT
    contract_idt,
    case when decision_result = 'F' then '1' else '0' end as fraud_flag,
    nvl(decision_date, bk_decision_date) as fraud_flag_date
FROM
    (
        SELECT /*no_merge use_index(DWF_CNTR_EVENT_INST_IDX dce) */
            dce.contract_idt    AS contract_idt,
            et.group_code       AS decision_code,
            et.code             AS decision_result,
            et.name             AS decision_result_name,
            dce.record_date     AS decision_date,
            dce.activate_date   AS bk_decision_date,
            ROW_NUMBER() OVER(PARTITION BY dce.contract_idt, et.group_code ORDER BY nvl(dce.record_date, activate_date) DESC) AS rn
        FROM
            dwf_contract_event dce
            JOIN inst i ON i.institution_id = dce.institution_id
            JOIN dwd_event_type et ON et.id = dce.event_type_id
                                      AND et.group_code = 'BLOCK_CODE_ACC1'
                                      AND code = 'F'
            
    )
    WHERE
    rn = 1
    ),
addr as  (select /*+ no_merge use_index(DWD_ADDRESS_INST_IDX da*/
			     da.client_idt,
                 max(case when dat.code = 'ADD_SMS_1' then da.address_zip    else null end) as mobile,
			     max(case when dat.code = 'STMT_ADDR' then da.address_line_1 else null end) as stmt_addr_line_1,
			     max(case when dat.code = 'STMT_ADDR' then da.address_line_2 else null end) as stmt_addr_line_2,
                 max(case when dat.code = 'PRESENT' then da.city else null end) as city -- [+] 20221004.1 = Santosh = ENG-4715 :  Changes done to include additional fields 
		    from dwd_address da
		    join inst i
		      on i.institution_id     = da.institution_id
		    join dwd_address_type dat
		      on dat.id               = da.address_type_id
		     and dat.code in ('STMT_ADDR','ADD_SMS_1','PRESENT') -- [+] 20221004.1 = Santosh = ENG-4715 :  Changes done to include additional fields 
		   where da.record_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
		     and da.record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
	         group by da.client_idt
	     ),
-- [+] begin 20221004.1 = Santosh = ENG-4715 :  Changes done to include additional fields 
city_m as (select /*+ no_merge materialize */
                filter as code ,
                name 
           from sy_handbook 
           where group_code = 'AECB_EXTRACT' 
           and code = 'CITY'
),  
occ_m as (select /*+ no_merge materialize */
                lpad(filter,2,0) as code ,
                name 
           from sy_handbook 
           where group_code = 'AECB_EXTRACT' 
           and code = 'OCCUPATION'
),
-- [+] end 20221004.1 = Santosh = ENG-4715 :  Changes done to include additional fields
--[*] begin : 20231127.1 = GaukharA = NICORE-976 : Alternate Id (EXID) logic field added
ext_id_contract as (
	select /*+no_merge materialize */
	       dca.contract_idt,
		   dca.attr_value exid
	  from dwa_contract_attribute dca
	  join dwd_attribute da
	    on dca.attr_id = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CONTRACT'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	),
exid as (
	select /*+no_merge materialize */
	       dca.card_idt,
		   dca.attr_value card_exid
	  from dwa_card_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CARD'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	),
--[*] end : 20231127.1 = GaukharA = NICORE-976 : Alternate Id (EXID) logic field added

main_data as(
     SELECT /*+ no_merge use_index(DWD_CARD_INST_IDX dc) use_hash(c dcl)*/
    decode( upper(substr(nvl(:RETURN_EXID_CONTRACT,'N'),1,1)), 'Y',con.exid, c.personal_account) personal_account,
    C.org_code AS ORG,
    decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)),'Y',exid.card_exid, cd.pan) ProviderContractNo,
    c.base_currency          AS OriginalCurrency,
    to_char(to_date(:P_REPORT_DATE, 'dd-mm-yyyy'),'mmyyyy') AS ReferenceDate,
    'CREDIT CARD' AS ContractType,
    nvl(attr.account_status,'A')      AS ActiveFlag,
    to_char(cd.opening_date, 'ddmmyyyy') AS OpenDate,
    to_char(close_date, 'ddmmyyyy') AS ClosedDate,
    attr.aecb_status AS ContractStatus,
    to_char(attr.aecb_status_date,'ddmmyyyy') AS ContractStatusDate,
    'CAS' AS methodofpayment,
    'M' AS paymentfrequency,
    abs(crlim.credit_limit) AS creditlimit,
    tarr.repayment_percent   AS MinimumPaymentPercentage,
    trim(nvl((ba.total_balance*-1),0)) AS Balance,
    nvl(abs(ba.past_due),0) AS OverdueAmount,
    case when ent_1.counter > 0 then '1' else '0' end  as CardUsedFlag,
    LPAD(TO_CHAR(NVL(am.amt_spent,0),'FM9999999990'),12,' ') as AmountSpentInMonth,
    case when nvl(ba.total_due,0)>=nvl(lp.last_payment_amount,0)
    then '1' else '0' end as MinimumPaymentFlag,
    (case when dl.DPD between 0 and 5 then 0
                when dl.DPD between 6 and 29 then 1
                when dl.DPD between 30 and 59 then 2
                when dl.DPD between 60 and 89 then 3
                when dl.DPD between 90 and 119 then 4
                when dl.DPD between 120 and 149 then 5
                when dl.DPD between 150 and 179 then 6
                when dl.DPD > 180 then 7
           end) as DaysPaymentDelay
           ,decode(c.islamic_flag,'Y','1','0') AS IslamicContractFlag --[*] 220421 = ALMB-769
           ,case when nvl(sy_convert.get_tag_value(appl_info.ADD_INFO_02,'SEC_CH_IND'),'0') in ('C','F')
           THEN '1' else '0' end as SecuredContractFlag --[*] 220421 = ALMB-769
           ,sy_convert.get_tag_value(appl_info.ADD_INFO_02,'SCORE_APPL_NR') as ProviderApplicationNo
           ,'' as SecurityType
           , nvl(e.fraud_flag,0)  as FraudFlag
           , to_char(e.fraud_flag_date,'DDMMYYYY')   as FraudFlagDate
           ,'' AS SecurityTypeRemoveFlag
           ,to_char(billing.due_date,'DDMMYYYY') as PaymentDueDate
           ,LPAD(TO_CHAR(NVL((ba.total_due*-1),0),'FM999999990.90'),12,' ') as StatementDueAmount
           ,LPAD(TO_CHAR(NVL(abs(lp.last_payment_amount),0),'FM999999990.90'),12,' ') as ActualPaymentAmount
           ,cd.embossed_first_name||' '||cd.embossed_last_name as Name
           ,cl.gender as Gender
           ,addr.stmt_addr_line_1 as Address_line1
           ,addr.stmt_addr_line_2 as Address_line2
           ,addr.mobile as Mobile_number
           ,to_char(cl.birth_date,'DDMMYYYY') as Date_of_Birth
           ,cl.CITIZENSHIP as Nationality
           ,sy_convert.get_tag_value(cl.ADD_INFO,'INCOME') as Income
           ,cl.IDENT_NUMBER as Emirates_Id
           ,to_char(to_date(sy_convert.get_tag_value(cl.ADD_INFO,'CL_PASS_EXP'),'YYYY-MM-DD'),'DDMMYYYY') as Emirates_Id_ExpDate
--           ,sy_convert.get_tag_value(c.ADD_INFO,'DD_DAY') as DD_DAY
           ,to_char(attr.direct_debit_date,'DDMMYYYY') as DD_DATE
           ,sy_convert.get_tag_value(c.ADD_INFO,'DD_NUM') as DD_ACNT_NBR
           ,LPAD(TO_CHAR(NVL(abs(ctd.ctd_amt),0),'FM999999990.90'),12,' ') as ctd_spent_amount
           ,LPAD(TO_CHAR(NVL(abs(lp.last_payment_amount),0),'FM999999990.90'),12,' ') as Last_Payment_Amount
           ,rpad(nvl(cl.client_number,'0'),16,' ') as ProviderSubjectNo
           ,rpad(nvl(attr.account_status,'A'),2,' ') as Role
-- [+] begin 20221004.1 = Santosh = ENG-4715 :  Changes done to include additional fields           
           ,cm.code as emirate
           ,om.code as occupation
           ,sy_convert.get_tag_value(cl.ADD_INFO,'EMP_SALARY') as salary -- [+] begin 20221012.1 = Santosh = ENG-4715 :  mapping correction
-- [+] end 20221004.1 = Santosh = ENG-4715 :  Changes done to include additional fields           
FROM
    contracts c
    LEFT JOIN ext_id_contract con ON con.contract_idt=c.record_idt
    JOIN dwd_card cd ON c.record_idt = cd.main_contract_idt
                        AND nvl(cd.main_card_flag, 'N') = 'Y'
    LEFT JOIN exid 
    on exid.card_idt = cd.record_idt                     
    JOIN inst i ON i.institution_id=cd.institution_id
    left join balances ba ON ba.record_idt = c.record_idt
    left join last_payment lp on lp.contract_idt = c.record_idt
    LEFT JOIN attr_code attr ON ( attr.contract_idt = c.record_idt )
    LEFT JOIN crlimit crlim ON crlim.contract_idt = c.record_idt
    JOIN tarr ON c.org_code = tarr.orgcd
     left join amnt_month am on am.contract_idt=c.record_idt
     LEFT JOIN billing ON billing.contract_idt = c.record_idt
     left join ctd on ctd.contract_idt=c.record_idt
    LEFT JOIN ent_1 on ent_1.contract_idt = c.record_idt
    LEFT JOIN DPD_levels dl ON dl.contract_idt = c.record_idt
    LEFT JOIN events e on e.contract_idt = C.record_idt
    JOIN dwd_client cl
    ON cl.record_idt       = c.client_idt
    AND cl.institution_id=i.institution_id
    left join addr
    on addr.client_idt = c.client_idt
    LEFT JOIN opt_dwd_appl_info  appl_info ON appl_info.client_idt = cl.record_idt
    AND appl_info.add_info_type in ('CLIENT_DET_1')
-- [+][begin] 220808.1 = RakeshG = ALMB-873 :  Added record date condition to fix Duplicate issue	
	AND appl_info.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND appl_info.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
-- [+][end] 220808.1 = RakeshG = ALMB-873 :  Added record date condition to fix Duplicate issue
-- [+] begin 20221004.1 = Santosh = ENG-4715 :  Changes done to include additional fields    
    LEFT JOIN city_m cm on upper(addr.city) = cm.name
    LEFT JOIN occ_m om on upper(sy_convert.get_tag_value(cl.ADD_INFO,'EMP_POSITION')) = om.name -- [+] begin 20221012.1 = Santosh = ENG-4715 :  mapping correction
-- [+] end 20221004.1 = Santosh = ENG-4715 :  Changes done to include additional fields   

WHERE
    cd.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND cd.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    and cl.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND cl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND (close_date is null OR close_date>=TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')) --[+] 20230705.1 : ANFE-228
)
Select
      ORG
      ,rpad(nvl(ProviderContractNo,'0'),35,' ') as ProviderContractNo
      ,rpad(nvl(OriginalCurrency,' '),3,' ') as OriginalCurrency
      ,rpad(ReferenceDate,6,' ') as ReferenceDate
      ,rpad(decode(ContractType,'CREDIT CARD','02'),03,' ') as ContractType
      ,rpad(nvl(ActiveFlag,' '),1,' ') as ActiveFlag
      ,rpad(OpenDate,8,' ') as OpenDate
      ,rpad(nvl(ClosedDate,' '),8,' ') as ClosedDate
      ,rpad(nvl(ContractStatus,' '),1,' ') as ContractStatus
      ,rpad(nvl(ContractStatusDate,' '),8,' ') as ContractStatusDate
      ,MethodOfPayment
      ,PaymentFrequency
      ,lpad(CreditLimit,12,'0') as CreditLimit
      ,rpad(MinimumPaymentPercentage,2,' ') as MinimumPaymentPercentage
      ,lpad(abs(Balance),12,'0') as Balance
      ,lpad(OverdueAmount,12,'0') as OverdueAmount
      ,CardUsedFlag
      ,lpad(AmountSpentInMonth,12,'0') as AmountSpentInMonth
      ,rpad(nvl(MinimumPaymentFlag,' '),1,' ') as MinimumPaymentFlag
      ,nvl(DaysPaymentDelay,'0') as DaysPaymentDelay
      ,IslamicContractFlag
      ,SecuredContractFlag
      ,rpad(nvl(ProviderApplicationNo,' '),35,' ') as ProviderApplicationNo
      ,rpad(nvl(SecurityType,' '),4,' ') as SecurityType
      ,rpad(nvl(FraudFlag,' '),1,' ') as FraudFlag
      ,rpad(nvl(FraudFlagDate,' '),8,' ') as FraudFlagDate
      ,rpad(nvl(SecurityTypeRemoveFlag,' '),1,' ') as SecurityTypeRemoveFlag
      ,rpad(nvl(PaymentDueDate,' '),8,' ') as PaymentDueDate
      ,StatementDueAmount
      ,ActualPaymentAmount
      ,rpad(nvl(Name,' '),64,' ') as Name
      ,rpad(nvl(Gender,' '),1,' ') as Gender
      ,rpad(nvl(Address_line1,' '),255,' ') as Address_line1
      ,rpad(nvl(Address_line2,' '),255,' ') as Address_line2
      ,rpad(nvl(Mobile_number,' '),20,' ') as Mobile_number
      ,rpad(nvl(Date_of_Birth,' '),8,' ') as Date_of_Birth
      ,rpad(nvl(Nationality,' '),3,' ') as Nationality
      ,rpad(nvl(Income,' '),24,' ') as Income
      ,rpad(nvl(Emirates_Id,' '),18,' ') as EmiratesId
      ,rpad(nvl(Emirates_Id_ExpDate,' '),8,' ') as EmiratesIdExpDate
      ,rpad(nvl(DD_DATE,' '),8,' ') as DirectDebitDate
      ,rpad(nvl(DD_ACNT_NBR,' '),23,' ') as DirectDebitAccountnumber
      ,lpad(ctd_spent_amount,12,'0') as CTDSpentAmount
      ,lpad(Last_Payment_Amount,12,'0') as LastPaymentAmount
      ,ProviderSubjectNo
      ,Role
      -- [+] begin 20221004.1 = Santosh = ENG-4715 :  Changes done to include additional fields
      ,rpad(nvl(emirate,' '),1,' ') as emirate
      -- [+] begin 20221013.1 = Santosh = ENG-4715 :  field name change
      ,lpad(nvl(occupation,'10'),2,'0') as sourceofincome
      ,rpad(nvl(salary,' '),12,' ') as grossannualamount -- [+] begin 20221012.1 = Santosh = ENG-4715 :  mapping correction
      -- [+] end 20221013.1 = Santosh = ENG-4715 :  field name change
      -- [+] end 20221004.1 = Santosh = ENG-4715 :  Changes done to include additional fields
from main_data