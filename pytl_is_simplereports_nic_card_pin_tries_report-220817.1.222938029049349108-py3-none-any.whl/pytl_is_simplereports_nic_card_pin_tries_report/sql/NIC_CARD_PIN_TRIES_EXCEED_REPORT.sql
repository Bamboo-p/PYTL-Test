/*
* Code for NIC_CARD_PIN_TRIES_EXCEED_REPORT
* PyTL_IS_SimpleReports_NIC_CARD_PIN_TRIES_EXCEED_REPORT = NIC_CARD_PIN_TRIES_EXCEED_REPORT.sql
* Version history:
* 20220817.1 : WRB-3293 : Shalini  : Initial development
*/
WITH
inst AS (
     SELECT /*+ materialize */
         id,
         branch_code
     FROM
         dwh.dwd_institution
     WHERE
         branch_code = :ORG
         AND record_state = 'A'
 )
, attr AS (
     SELECT
         dca.card_idt,
         MAX(da.code) AS code
     FROM
         dwh.dwd_attribute da
         JOIN dwh.dwa_card_attribute dca ON da.id = dca.attr_id
     WHERE
         da.type_code = 'BFC_PIN_TRIES_EXC'
         AND da.dimension_code = 'DWD_CARD'
         AND da.record_source = 'W4CS_STATUS_TYPE'
         AND dca.attr_date_from <= TO_DATE(:P_PIN_UPDATED_DATE,'DD-MM-YYYY')
         AND dca.attr_date_to >= TO_DATE(:P_PIN_UPDATED_DATE,'DD-MM-YYYY')
     GROUP BY
         dca.card_idt
)
SELECT
     inst.branch_code         AS ORG,
     cd.pan                   AS CARD_NUMBER,
     cd.embossed_first_name
     || ' '
     || cd.embossed_last_name AS CARDHOLDER_NAME,
     c.personal_account       AS ACCOUNT_NUMBER,
     cl.client_number         AS CLIENT_NUMBER
 FROM
     dwh.dwd_contract c
     JOIN inst ON inst.id = c.institution_id
     JOIN dwh.dwd_card cd ON c.record_idt = cd.main_contract_idt
     JOIN dwh.dwd_client cl ON c.client_idt = cl.record_idt
     JOIN attr ON attr.card_idt = cd.record_idt
 WHERE
     attr.code = 'Y'
     AND c.record_date_from <= TO_DATE(:P_PIN_UPDATED_DATE,'DD-MM-YYYY')
     AND c.record_date_to >= TO_DATE(:P_PIN_UPDATED_DATE,'DD-MM-YYYY')
     AND inst.id = cd.institution_id
     AND cd.record_date_from <= TO_DATE(:P_PIN_UPDATED_DATE,'DD-MM-YYYY')
     AND cd.record_date_to >= TO_DATE(:P_PIN_UPDATED_DATE,'DD-MM-YYYY')
     AND inst.id = cl.institution_id
     AND cl.record_date_from <= TO_DATE(:P_PIN_UPDATED_DATE,'DD-MM-YYYY')
     AND cl.record_date_to >= TO_DATE(:P_PIN_UPDATED_DATE,'DD-MM-YYYY')