/*
* STANDARD CLIENT DUMP REPORT
*
* Version history:
* 210930.1 = Santosh Kumar Singh = ENG-3705: Added field CLIENT_DET_1 & CLIENT_DET_1
* 220119.1 = Bharath = OPKSAIC-3089: enhanced to use for KSA , changed ORG to ORGLIST
* 220330.1 = Shalini = ALMB-717: Mapping changes for sms_addr_phone_mobile field
* 240308.1 = Santosh = NICORE-1231: Added P_DATE_FORMAT parameter
*/
WITH fi AS (
    SELECT
        id            institution_id,
        branch_code   code,
        name,
        add_info
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code   branch_code_posting,
                dwd_institution.name,
                dwd_institution.add_info
            FROM
                dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
)
SELECT
    fi.code       AS org,
    fi.code       AS institution_branch_code,
    fi.name       AS institution_name,
    cl.client_category,
	to_char(cl.creation_date,:P_DATE_FORMAT) as creation_date,
    cl.residence,
    cl.country_code,
    cl.region_code,
    cl.client_number,
    cl.short_name,
    cl.title,
    cl.last_name,
    cl.first_name,
    cl.middle_name,
    cl.ind_tax_number,
    cl.ident_number AS ident_number,
    cl.ident_type,
    cl.ident_details AS ident_details,
	to_char(cl.birth_date,:P_DATE_FORMAT) as birth_date,
    cl.birth_place,
    cl.gender,
    cl.marital_status,
    cl.company_name AS company_name,
    cl.position AS position,
    cl.tax_position,
    cl.company_department,
    cl.trade_name,
    cl.alternate_idn,
    cl.citizenship,
    cl.decease_date,
    cl.language,
    cl.add_info AS add_info,
    cl.security_name AS security_name,
    cl.title_suffix,
    cl.social_number,
    cl.embossing_title,
    cl.embossing_first_name,
    cl.embossing_last_name,
    addr.permanent_addr_language,
    addr.permanent_addr_country,
    addr.permanent_addr_region_code,
    addr.permanent_addr_state,
    addr.permanent_addr_city AS permanent_addr_city,
    addr.permanent_addr_address_line_1 AS permanent_addr_address_line_1,
    addr.permanent_addr_address_line_2 AS permanent_addr_address_line_2,
    addr.permanent_addr_address_line_3 AS permanent_addr_address_line_3,
    addr.permanent_addr_address_line_4 AS permanent_addr_address_line_4,
    addr.permanent_addr_email AS permanent_addr_email,
    addr.permanent_addr_phone AS permanent_addr_phone,
    addr.permanent_addr_phone_home AS permanent_addr_phone_home,
    addr.permanent_addr_phone_mobile AS permanent_addr_phone_mobile,
    addr.permanent_addr_fax AS permanent_addr_fax,
    addr.permanent_addr_fax_home AS permanent_addr_fax_home,
    addr.permanent_addr_url AS permanent_addr_url,
    addr.permanent_addr_location AS permanent_addr_location,
    addr.permanent_addr_title AS permanent_addr_title,
    addr.permanent_addr_title_suffix AS permanent_addr_title_suffix,
    addr.permanent_addr_first_name AS permanent_addr_first_name,
    addr.permanent_addr_last_name AS permanent_addr_last_name,
    addr.present_addr_language,
    addr.present_addr_country,
    addr.present_addr_region_code,
    addr.present_addr_state,
    addr.present_addr_city AS present_addr_city,
    addr.present_addr_address_line_1 AS present_addr_address_line_1,
    addr.present_addr_address_line_2 AS present_addr_address_line_2,
    addr.present_addr_address_line_3 AS present_addr_address_line_3,
    addr.present_addr_address_line_4 AS present_addr_address_line_4,
    addr.present_addr_email AS present_addr_email,
    addr.present_addr_phone AS present_addr_phone,
    addr.present_addr_phone_home AS present_addr_phone_home,
    addr.present_addr_phone_mobile AS present_addr_phone_mobile,
    addr.present_addr_fax AS present_addr_fax,
    addr.present_addr_fax_home AS present_addr_fax_home,
    addr.present_addr_url AS present_addr_url,
    addr.present_addr_location AS present_addr_location,
    addr.present_addr_title AS present_addr_title,
    addr.present_addr_title_suffix AS present_addr_title_suffix,
    addr.present_addr_first_name AS present_addr_first_name,
    addr.present_addr_last_name AS present_addr_last_name,
    addr.sms_addr_language,
    addr.sms_addr_country,
    addr.sms_addr_region_code,
    addr.sms_addr_state,
    addr.sms_addr_city AS sms_addr_city,
    addr.sms_addr_address_line_1 AS sms_addr_address_line_1,
    addr.sms_addr_address_line_2 AS sms_addr_address_line_2,
    addr.sms_addr_address_line_3 AS sms_addr_address_line_3,
    addr.sms_addr_address_line_4 AS sms_addr_address_line_4,
    addr.sms_addr_email AS sms_addr_email,
    addr.sms_addr_phone AS sms_addr_phone,
    addr.sms_addr_phone_home AS sms_addr_phone_home,
    addr.sms_addr_phone_mobile AS sms_addr_phone_mobile,
    addr.sms_addr_fax AS sms_addr_fax,
    addr.sms_addr_fax_home AS sms_addr_fax_home,
    addr.sms_addr_url AS sms_addr_url,
    addr.sms_addr_location AS sms_addr_location,
    addr.sms_addr_title AS sms_addr_title,
    addr.sms_addr_title_suffix AS sms_addr_title_suffix,
    addr.sms_addr_first_name AS sms_addr_first_name,
    addr.sms_addr_last_name AS sms_addr_last_name,
    addr.stmt_addr_copy_to_address,
    bank_officer.name AS bank_officer_name,
    bank_officer.login AS bank_officer_login,
    br.name       AS branch_name,
    br.code       AS branch_code,
    clt.name      AS client_type_name,
    clt.code      AS client_type_code
    --[+]begin 210930.1 = Santosh Kumar Singh = ENG-3705
    ,case when appl_info.add_info_type = 'CLIENT_DET_1' then appl_info.ADD_INFO_02 end CLIENT_DET_1
    ,case when appl_info.add_info_type = 'CLIENT_DET_2' then appl_info.ADD_INFO_02 end CLIENT_DET_2
    --[+]end 210930.1 = Santosh Kumar Singh = ENG-3705
FROM
    dwd_client cl
    JOIN fi ON cl.institution_id = fi.institution_id
    LEFT JOIN (
        SELECT
            MAX(da.record_date_from) AS record_date_from,
            da.client_idt,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN language
                ELSE NULL
            END) AS permanent_addr_language,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN country
                ELSE NULL
            END) AS permanent_addr_country,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN region_code
                ELSE NULL
            END) AS permanent_addr_region_code,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN state
                ELSE NULL
            END) AS permanent_addr_state,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN city
                ELSE NULL
            END) AS permanent_addr_city,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN address_line_1
                ELSE NULL
            END) AS permanent_addr_address_line_1,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN address_line_2
                ELSE NULL
            END) AS permanent_addr_address_line_2,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN address_line_3
                ELSE NULL
            END) AS permanent_addr_address_line_3,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN address_line_4
                ELSE NULL
            END) AS permanent_addr_address_line_4,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN e_mail
                ELSE NULL
            END) AS permanent_addr_email,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN phone
                ELSE NULL
            END) AS permanent_addr_phone,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN phone_home
                ELSE NULL
            END) AS permanent_addr_phone_home,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN phone_mobile
                ELSE NULL
            END) AS permanent_addr_phone_mobile,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN fax
                ELSE NULL
            END) AS permanent_addr_fax,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN fax_home
                ELSE NULL
            END) AS permanent_addr_fax_home,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN url
                ELSE NULL
            END) AS permanent_addr_url,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN location
                ELSE NULL
            END) AS permanent_addr_location,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN title
                ELSE NULL
            END) AS permanent_addr_title,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN title_suffix
                ELSE NULL
            END) AS permanent_addr_title_suffix,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN first_name
                ELSE NULL
            END) AS permanent_addr_first_name,
            MAX(CASE
                WHEN dat.code = 'PERMANENT' THEN last_name
                ELSE NULL
            END) AS permanent_addr_last_name,
            MAX(CASE
                WHEN dat.code = 'STMT_ADDR' THEN sy_convert.get_tag_value(da.add_info, 'COPY_TO_ADDRESS')
                ELSE NULL
            END) AS stmt_addr_copy_to_address,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN language
                ELSE NULL
            END) AS present_addr_language,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN country
                ELSE NULL
            END) AS present_addr_country,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN region_code
                ELSE NULL
            END) AS present_addr_region_code,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN state
                ELSE NULL
            END) AS present_addr_state,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN city
                ELSE NULL
            END) AS present_addr_city,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN address_line_1
                ELSE NULL
            END) AS present_addr_address_line_1,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN address_line_2
                ELSE NULL
            END) AS present_addr_address_line_2,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN address_line_3
                ELSE NULL
            END) AS present_addr_address_line_3,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN address_line_4
                ELSE NULL
            END) AS present_addr_address_line_4,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN e_mail
                ELSE NULL
            END) AS present_addr_email,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN phone
                ELSE NULL
            END) AS present_addr_phone,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN phone_home
                ELSE NULL
            END) AS present_addr_phone_home,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN phone_mobile
                ELSE NULL
            END) AS present_addr_phone_mobile,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN fax
                ELSE NULL
            END) AS present_addr_fax,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN fax_home
                ELSE NULL
            END) AS present_addr_fax_home,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN url
                ELSE NULL
            END) AS present_addr_url,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN location
                ELSE NULL
            END) AS present_addr_location,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN title
                ELSE NULL
            END) AS present_addr_title,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN title_suffix
                ELSE NULL
            END) AS present_addr_title_suffix,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN first_name
                ELSE NULL
            END) AS present_addr_first_name,
            MAX(CASE
                WHEN dat.code = 'PRESENT' THEN last_name
                ELSE NULL
            END) AS present_addr_last_name,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN language
                ELSE NULL
            END) AS sms_addr_language,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN country
                ELSE NULL
            END) AS sms_addr_country,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN region_code
                ELSE NULL
            END) AS sms_addr_region_code,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN state
                ELSE NULL
            END) AS sms_addr_state,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN city
                ELSE NULL
            END) AS sms_addr_city,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN address_line_1
                ELSE NULL
            END) AS sms_addr_address_line_1,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN address_line_2
                ELSE NULL
            END) AS sms_addr_address_line_2,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN address_line_3
                ELSE NULL
            END) AS sms_addr_address_line_3,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN address_line_4
                ELSE NULL
            END) AS sms_addr_address_line_4,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN e_mail
                ELSE NULL
            END) AS sms_addr_email,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN phone
                ELSE NULL
            END) AS sms_addr_phone,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN phone_home
                ELSE NULL
            END) AS sms_addr_phone_home,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN address_zip --[*]220330.1 = ALMB-717
                ELSE NULL
            END) AS sms_addr_phone_mobile,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN fax
                ELSE NULL
            END) AS sms_addr_fax,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN fax_home
                ELSE NULL
            END) AS sms_addr_fax_home,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN url
                ELSE NULL
            END) AS sms_addr_url,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN location
                ELSE NULL
            END) AS sms_addr_location,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN title
                ELSE NULL
            END) AS sms_addr_title,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN title_suffix
                ELSE NULL
            END) AS sms_addr_title_suffix,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN first_name
                ELSE NULL
            END) AS sms_addr_first_name,
            MAX(CASE
                WHEN dat.code = 'ADD_SMS_1' THEN last_name
                ELSE NULL
            END) AS sms_addr_last_name
        FROM
            dwd_address da
            JOIN fi ON fi.institution_id = da.institution_id
            JOIN dwd_address_type dat ON da.address_type_id = dat.id
        WHERE
            dat.code IN (
                'STMT_ADDR',
                'ADD_SMS_1',
                'PERMANENT',
                'PRESENT'
            )
            AND da.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
            AND da.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        GROUP BY
            da.client_idt
    ) addr ON addr.client_idt = cl.record_idt
    LEFT JOIN dwd_client_type clt ON cl.client_type_id = clt.id
    LEFT JOIN dwd_branch br ON cl.branch_id = br.id
    LEFT JOIN dwd_bank_officer bank_officer ON cl.bank_officer_id = bank_officer.id
    --[+]begin 210930.1 = Santosh Kumar Singh = ENG-3705
    LEFT JOIN opt_dwd_appl_info  appl_info ON appl_info.client_idt = cl.record_idt
          AND appl_info.add_info_type in ('CLIENT_DET_1','CLIENT_DET_2')
    --[+]end 210930.1 = Santosh Kumar Singh = ENG-3705
WHERE
    ( :P_MODE = 'INCREMENTAL'
      AND cl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
      AND ( cl.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
            OR addr.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') ) )
    OR ( :P_MODE = 'FULL'
         AND cl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
         AND cl.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )