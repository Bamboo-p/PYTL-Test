__version__ = "230301.1"
__job_name__ = "PyTL_IS_SimpleReports_NIC_COMM_DUMP"
__bat_files__ = []

