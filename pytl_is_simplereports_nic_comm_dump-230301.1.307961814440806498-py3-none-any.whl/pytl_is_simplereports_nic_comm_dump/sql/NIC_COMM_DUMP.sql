/*
NIC_COMM_DUMP.sql
230127.1 : NIINT-2983 : Santosh : Initial version : Added logic for product_type
230130.1 : NIINT-2983 : Santosh : Added inst
230222.1 : NIINT-2983 : Santosh : changed join condition
010323.1 : NIINT-3059 : Santosh : Changed complete query to run on way4
*/
--[+]begin 010323.1 : NIINT-3059 : Santosh : Changed complete query to run on way4
with inst as (
select bank_code ,
       name,
       id
from ows.f_i 
where bank_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                      from dual
                                connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
  and amnd_state ='A'                                
)                                
select /*+ no_merge */ distinct
    inst.bank_code as org,
    inst.name as inst_name,
    ap.name as product_name,
    cs.prefix as bin,
    cs.prefix||cs.min_number as start_bin_range,
    cs.prefix||cs.max_number as end_bin_range,
    decode(parent_ap.contract_role,'CORP','Commercial','Consumer') as Product_type
from ows.appl_product ap
join inst 
on inst.id = ap.f_i
and ap.amnd_state ='A'
and ap.con_cat = 'C'
join ows.appl_product parent_ap
on parent_ap.id = ap.main_product
join ows.contr_subtype cs
on cs.id = ap.contr_subtype
and cs.amnd_state ='A'
--[+]begin 010323.1 : NIINT-3059 : Santosh : Changed complete query to run on way4
