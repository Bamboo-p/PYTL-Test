/*
NIC_CONTRACT_ATTRIBUTES_DUMP_INC.sql
* 220712.1 = Bharath = OPKSAIC-4608: Alternate Id (EXID) logic added
* 221031.1 = DenisKa = OPKSAIC-4883: Fix issue with empty response
* 240308.1 = Santosh = NICORE-1231: Added P_DATE_FORMAT parameter
*/
WITH inst AS (
    SELECT /*+ no_merge materialize */
        inst.id,
        inst.branch_code,
        inst.name,
        inst.branch_code_posting,
		inst.use_fi_settings
    FROM
        (
            SELECT
                /*no_query_transformation*/  -- [+] 221028.1 = DenisKa = OPKSAIC-4883: Fix issue with empty response 
                /*+no_merge*/  -- [+] 221031.1 = DenisKa = OPKSAIC-4883: Fix issue with empty response 
                dwd_institution.branch_code,
                dwd_institution.id,
                dwd_institution.posting_institution_id,
                dwd_institution2.branch_code   branch_code_posting,
                dwd_institution.name,
                nvl2(g.code, 'Y', 'N') as use_fi_settings
            FROM
                dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
                LEFT JOIN sy_conf_group g ON g.amnd_state = 'A' and g.code = dwd_institution.branch_code || '_CONTRACT_ATTR_DUMP'
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORG, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORG, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
),
-- [+][begin] 220120.1 = Bharath : OPKSAIC-1772 : Alternate ID logic added
contract_ext_nums as (
	select /*+no_merge materialize */
	       dca.contract_idt,
		   dca.attr_value contract_exid
	  from dwa_contract_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CONTRACT'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	),
card_ext_nums as (
	select /*+no_merge materialize */
	       dca.card_idt,
		   dca.attr_value card_exid
	  from dwa_card_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CARD'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	),
-- [+][end] 220120.1 = Bharath : OPKSAIC-1772 : Alternate ID logic added
attr_list_fi as (
		select regexp_replace(v.code, '<FI>', inst.branch_code) as attr_type, inst.branch_code from
		sy_conf_group g
		join sy_conf_group_group gg
		on g.sy_conf_group_group__oid = gg.id
		join sy_conf_group_val v on v.sy_conf_group__oid = g.id
		join inst on inst.use_fi_settings = 'Y' and g.code = inst.branch_code || '_CONTRACT_ATTR_DUMP'
		where g.amnd_state = 'A'
		and g.table_code = 'DUMMY'
		and gg.amnd_state = 'A'
		and gg.code = 'NIC_CONTRACT_ATTR_DUMP'
		and v.amnd_state = 'A'
),
attr_list_glob as (
		select regexp_replace(v.code, '<FI>', inst.branch_code) as attr_type, inst.branch_code from
		sy_conf_group g
		join sy_conf_group_group gg
		on g.sy_conf_group_group__oid = gg.id
		join sy_conf_group_val v on v.sy_conf_group__oid = g.id
		join inst on inst.use_fi_settings = 'N' and g.code = '000_CONTRACT_ATTR_DUMP'
		where g.amnd_state = 'A'
		and g.table_code = 'DUMMY'
		and gg.amnd_state = 'A'
		and gg.code = 'NIC_CONTRACT_ATTR_DUMP'
		and v.amnd_state = 'A'
),
attr_list as (
        select * 
		from attr_list_fi
		union all
		select * 
		from attr_list_glob
),
default_acnt_attributes AS (
    SELECT
        da.record_source,
        da.dimension_code,
        c.institution_branch_code,
        c.institution_name,
        c.record_idt         AS contract_idt,
        c.personal_account   AS contract_number,
        da.type_code,
        da.type_name,
        da.code,
        da.name,
        da.type_idt,
        c.record_date_from,
        c.new_acc_flag
    FROM
        (
            SELECT /*+ PARALLEL(c 8) PARALLEL(prev_c 8) */
                c.record_idt,
                inst.branch_code   AS institution_branch_code,
                inst.name          AS institution_name,
                c.personal_account,
                c.record_date_from,
                case when prev_c.personal_account is null then 'Y' else 'N' end as new_acc_flag
            FROM
                dwd_contract c
                LEFT JOIN dwd_contract prev_c ON prev_c.record_idt = c.record_idt
                AND prev_c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') - 1
                AND prev_c.record_date_to = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') - 1
                JOIN inst ON inst.id = c.institution_id
            WHERE
                c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                AND c.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        ) c
        JOIN attr_list ON c.institution_branch_code = attr_list.branch_code
		JOIN dwd_attribute da ON da.type_code = attr_list.attr_type
    WHERE
        da.used_as_default = 'Y'
        AND da.record_state = 'A'
        AND da.dimension_code = 'DWD_CONTRACT'
), default_card_attributes AS (
    SELECT
        da.record_source,
        da.dimension_code,
        c.institution_branch_code,
        c.institution_name,
        c.record_idt   AS card_idt,
        c.pan          AS contract_number,
        da.type_code,
        da.type_name,
        da.code,
        da.name,
        da.type_idt,
        c.record_date_from,
        c.new_acc_flag
    FROM
        (
            SELECT /*+ PARALLEL(c 8) PARALLEL(prev_c 8) */
                c.record_idt,
                inst.branch_code   AS institution_branch_code,
                inst.name          AS institution_name,
                c.pan,
                c.record_date_from,
                case when prev_c.pan is null then 'Y' else 'N' end as new_acc_flag
            FROM
                dwd_card c
                LEFT JOIN dwd_card prev_c ON prev_c.record_idt = c.record_idt
                AND prev_c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') - 1
                AND prev_c.record_date_to = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') - 1
                JOIN inst ON inst.id = c.institution_id
            WHERE
                c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                AND c.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        ) c
        JOIN attr_list ON c.institution_branch_code = attr_list.branch_code
		JOIN dwd_attribute da ON da.type_code = attr_list.attr_type
    WHERE
        da.used_as_default = 'Y'
        AND da.record_state = 'A'
        AND da.dimension_code = 'DWD_CARD'
)
SELECT
    attr.institution_branch_code   AS org,
    attr.record_source,
    attr.dimension_code,
    attr.institution_branch_code,
    attr.institution_name,
	-- [+][begin] 220712.2 = Bharath : OPKSAIC-4608 : Alternate ID logic added
    decode(upper(substr(nvl(:RETURN_EXID_CONTRACT,'N'),1,1)), 'Y',main_coen.contract_exid, attr.contract_number) AS contract_number,
    -- [+][end] 220712.2 = Bharath : OPKSAIC-4608 : Alternate ID logic added
    attr.type_code,
    attr.type_name,
    nvl(da.code, attr.code) AS attr_code,
    nvl(da.name, attr.name) AS attr_name,
    to_char(nvl(da.attr_date_from, TO_DATE('01.01.2000', 'dd.mm.yyyy')),:P_DATE_FORMAT) AS attr_date,
    da.details
FROM
    default_acnt_attributes attr
    LEFT JOIN (
        SELECT /*+ PARALLEL(da 8) */
            a.id   attr_id,
            a.code,
            a.name,
            a.type_idt,
            da.contract_idt,
            attr_date_from,
            attr_date_to,
            da.details,
            inst.branch_code
        FROM
            dwa_contract_attribute da
            JOIN inst ON 1=1
            JOIN dwd_attribute a ON da.attr_id = a.id and a.dimension_code = 'DWD_CONTRACT'
		    JOIN attr_list   ON inst.branch_code = attr_list.branch_code
							AND a.type_code = attr_list.attr_type
							AND (da.attr_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') AND da.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'))
							AND da.active_state != 'C'
    ) da ON attr.contract_idt = da.contract_idt
            AND attr.type_idt = da.type_idt
            AND attr.institution_branch_code = da.branch_code
    -- [+][begin] 220120.1 = Bharath : OPKSAIC-1772 : Alternate ID logic added
    LEFT JOIN contract_ext_nums main_coen
	       ON attr.contract_idt = main_coen.contract_idt    
    -- [+][end] 220120.1 = Bharath : OPKSAIC-1772 : Alternate ID logic added
WHERE (da.code is null AND attr.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') AND attr.new_acc_flag = 'Y')
      OR (da.code is not null)
UNION ALL
SELECT
    attr.institution_branch_code   AS org,
    attr.record_source,
    attr.dimension_code,
    attr.institution_branch_code,
    attr.institution_name,
	-- [+][begin] 220712.2 = Bharath : OPKSAIC-4608 : Alternate ID logic added
    decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',main_caen.card_exid, attr.contract_number) AS contract_number,
    -- [+][end] 220712.2 = Bharath : OPKSAIC-4608 : Alternate ID logic added
    attr.type_code,
    attr.type_name,
    nvl(da.code, attr.code) AS attr_code,
    nvl(da.name, attr.name) AS attr_name,
    to_char(nvl(da.attr_date_from, TO_DATE('01.01.2000', 'dd.mm.yyyy')),:P_DATE_FORMAT) AS attr_date,
    da.details
FROM
    default_card_attributes attr
    LEFT JOIN (
        SELECT /*+ PARALLEL(da 8) */
            a.id   attr_id,
            a.code,
            a.name,
            a.type_idt,
            da.card_idt,
            attr_date_from,
            attr_date_to,
            da.details,
            inst.branch_code
        FROM
            dwa_card_attribute da
            JOIN inst ON 1=1
            JOIN dwd_attribute a ON da.attr_id = a.id and a.dimension_code = 'DWD_CARD'
            JOIN attr_list ON inst.branch_code = attr_list.branch_code
		                   AND a.type_code = attr_list.attr_type
                           AND (da.attr_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') AND da.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'))
                           AND da.active_state != 'C'
    ) da ON attr.card_idt = da.card_idt
            AND attr.type_idt = da.type_idt
            AND attr.institution_branch_code = da.branch_code
    -- [+][begin] 220120.1 = Bharath : OPKSAIC-1772 : Alternate ID logic added
    LEFT JOIN card_ext_nums main_caen
	       ON attr.card_idt = main_caen.card_idt    
    -- [+][end] 220120.1 = Bharath : OPKSAIC-1772 : Alternate ID logic added
WHERE (da.code is null AND attr.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') AND attr.new_acc_flag = 'Y')
      OR (da.code is not null)