__version__ = "240327.1"
__job_name__ = "PyTL_IS_SimpleReports_NIC_CONTRACT_DUMP"
__bat_files__ = []

