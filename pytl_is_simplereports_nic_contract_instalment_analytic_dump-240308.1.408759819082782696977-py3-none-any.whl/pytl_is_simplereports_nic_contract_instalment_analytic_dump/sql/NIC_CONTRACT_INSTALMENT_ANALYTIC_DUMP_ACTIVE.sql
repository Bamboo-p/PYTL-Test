/*
STANDARD CONTRACT ACTIVE INSTALMENT ANALYTIC DUMP = NIC_CONTRACT_INSTALMENT_ANALYTIC_DUMP_ACTIVE.sql

Attention:
    In case of changing of NIC_CONTRACT_INSTALMENT_ANALYTIC_DUMP_ACTIVE.sql/NIC_CONTRACT_INSTALMENT_ANALYTIC_DUMP_CLOSED.sql
    NIC_CONTRACT_INSTALMENT_ANALYTIC_DUMP_HEADER.sql must be validated/updated!

Version history:
----------------
211012.1 = Tatiana Ovseannikova  = https://jira.network.ae/confluence/display/NICE/Contract+Instalment+Analytic+Dump  ,Initial development
211015.2 = Shalini = ALMAS-80: Grooming and removed masking. Initial commit
211107.3 = Santosh = ALMAS-530: Added filter to installment portion status
211115.1 - TatianaO = ENG-4180: renamed to differentiate active and closed instalment analytic dumps, moved closed instalment filter to instalment level
211116.1 = TatianaO = ENG-4180: peformance tuning, re-written joins
240308.1 = Santosh = NICORE-1231: Added P_DATE_FORMAT parameter
*/
WITH fi AS (
    SELECT /*+ no_merge materialize */
        id            institution_id,
        branch_code   code,
        name,
        add_info
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code   branch_code_posting,
                dwd_institution.name,
                dwd_institution.add_info
            FROM
                dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORG, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORG, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
)
SELECT /*+ ordered parallel(4) full(instl_total) full(portion) full(instl) use_hash(instl_total contr) */
    fi.code                        AS ORG,
    fi.code                        AS "INSTITUTION_BRANCH_CODE",
    fi.name                        AS "INSTITUTION_NAME",
--  fi.add_info                    AS institution_add_info,
    p.group_code                   AS "PRODUCT_GROUP_CODE",
    p.code                         AS "PRODUCT_CODE",
    p.name                         AS "PRODUCT_NAME",
--  int_p.add_info                 AS int_product_add_info,
    portion.portion_number         AS "PORTION_NUMBER",
    to_char(portion.open_date,:P_DATE_FORMAT)      AS "OPEN_DATE",
    to_char(portion.due_date,:P_DATE_FORMAT)       AS "DUE_DATE",
    to_char(portion.delinquency_date,:P_DATE_FORMAT)  AS "DELINQUENCY_DATE",
    portion.portion_amount         AS "PORTION_AMOUNT",
    portion.details                AS "DETAILS",
    portion.fee_capitalization     AS "FEE_CAPITALIZATION",
    portion_st.code                AS "PORTION_STATUS_CODE",
    portion_st.name                AS "PORTION_STATUS_NAME",
--  regexp_replace(contr.personal_account, '(^\d{9})(.*)(\d{4}$)', '\1******\3') AS contract_personal_account,
    personal_account               AS "CONTRACT_NUMBER",
    to_char(instl_total.effective_date,:P_DATE_FORMAT)     AS "AMOUNT_EFFECTIVE_DATE",
    to_char(instl_total.delinquency_date,:P_DATE_FORMAT)   AS "AMOUNT_DELINQUENCY_DATE",
    instl_total.status             AS "AMOUNT_STATUS",
    instl_total.amount_type        AS "AMOUNT_TYPE",
    instl_total.amount             AS "AMOUNT",
    instl_total.storno_reversed    AS "AMOUNT_STORNO_REVERSED",
    instl.scheme_code              AS "INSTALMENT_SCHEME_CODE",
    instl.scheme_name              AS "INSTALMENT_SCHEME_NAME",
    to_char(instl.creation_date,:P_DATE_FORMAT)            AS "INSTALMENT_CREATION_DATE",
    instl.total                    AS "INSTALMENT_TOTAL",
    instl.add_info                 AS "INSTALMENT_ADD_INFO",
    instl.scheme_option_code       AS "INSTALMENT_SCHEME_OPTION_CODE",
    instl.scheme_option_name       AS "INSTALMENT_SCHEME_OPTION_NAME",
    instl.record_idt               AS "INSTALMENT_IDT",
    null                           AS "CLOSE_DATE"
FROM
    dwf_instl_total instl_total
    JOIN fi ON instl_total.institution_id = fi.institution_id
    JOIN dwd_instl_portion portion ON instl_total.inst_portion_idt = portion.record_idt
    JOIN dwd_instl_status portion_st ON portion.status_id = portion_st.id
    JOIN dwd_instalment instl ON instl_total.instalment_idt = instl.record_idt
                                 AND instl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                                 AND instl.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    JOIN dwd_instl_status inst_st ON instl.status_id = inst_st.id
               AND inst_st.code NOT IN ('CLOSED','Z')  -- [+] 211107.3 = Santosh = ALMAS-530; 211115.1 = TatianaO = ENG-4180: moved filter to instalment level
    JOIN dwd_contract contr ON contr.record_idt = instl_total.contract_idt
                               AND contr.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                               AND contr.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    JOIN dwd_product p ON p.id = contr.product_id
WHERE
    ( :P_MODE = 'INCREMENTAL'
      AND portion.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
      AND portion.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
    OR ( :P_MODE = 'FULL'
         AND portion.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
         AND portion.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )