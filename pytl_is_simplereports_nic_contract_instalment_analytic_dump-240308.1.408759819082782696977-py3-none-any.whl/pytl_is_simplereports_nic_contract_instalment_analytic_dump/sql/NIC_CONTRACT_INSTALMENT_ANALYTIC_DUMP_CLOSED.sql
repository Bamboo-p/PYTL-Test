/*
STANDARD CONTRACT CLOSED INSTALMENT ANALYTIC DUMP = NIC_CONTRACT_INSTALMENT_ANALYTIC_DUMP_CLOSED.sql

Attention:
    In case of changing of NIC_CONTRACT_INSTALMENT_ANALYTIC_DUMP_ACTIVE.sql/NIC_CONTRACT_INSTALMENT_ANALYTIC_DUMP_CLOSED.sql
    NIC_CONTRACT_INSTALMENT_ANALYTIC_DUMP_HEADER.sql must be validated/updated!

Version history:
----------------
211115.1 = Tatiana Ovseannikova = ENG-4180 ,Initial development
211116.1 = Tatiana Ovseannikova = ENG-4180: performance tuning
230626.1 = BharathG             = PRD-23461 : Alias name issue correction and performance tuning
240308.1 = Santosh = NICORE-1231: Added P_DATE_FORMAT parameter
*/
WITH fi AS (
    SELECT /*+ materialize */
          id          institution_id,
          branch_code code,
          name,
          add_info
    FROM (SELECT /*+no_merge*/
                d.branch_code,
                d.posting_institution_id,
                d.id,
                d2.branch_code branch_code_posting,
                d.name,
                d.add_info
           FROM dwd_institution d
           JOIN dwd_institution d2 
             ON d.posting_institution_id = d2.id
          WHERE d.record_state = 'A'
          ) inst
    START WITH inst.branch_code IN (
            SELECT TRIM(regexp_substr(:ORG, '[^,]+', 1, level)) org
             FROM dual
       CONNECT BY regexp_substr(:ORG, '[^,]+', 1, level) IS NOT NULL )
       CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
              AND level <= 2
    )
   SELECT /*+ ordered leading(inst_st instl fi instl_total portion) index(instl_total dwf_inst_total_plan_idx) index(portion dwd_inst_portion_idt_idx) */
         fi.code                        AS ORG,
         fi.code                        AS "INSTITUTION_BRANCH_CODE",
         fi.name                        AS "INSTITUTION_NAME",
         p.group_code                   AS "PRODUCT_GROUP_CODE",
         p.code                         AS "PRODUCT_CODE",
         p.name                         AS "PRODUCT_NAME",
         portion.portion_number         AS "PORTION_NUMBER",
         to_char(portion.open_date,:P_DATE_FORMAT)              AS "OPEN_DATE",
         to_char(portion.due_date,:P_DATE_FORMAT)               AS "DUE_DATE",
         to_char(portion.delinquency_date,:P_DATE_FORMAT)       AS "DELINQUENCY_DATE",
         portion.portion_amount         AS "PORTION_AMOUNT",
         portion.details                AS "DETAILS",
         portion.fee_capitalization     AS "FEE_CAPITALIZATION",
         portion_st.code                AS "PORTION_STATUS_CODE",
         portion_st.name                AS "PORTION_STATUS_NAME",
         personal_account               AS "CONTRACT_NUMBER",
         to_char(instl_total.effective_date,:P_DATE_FORMAT)     AS "AMOUNT_EFFECTIVE_DATE",
         to_char(instl_total.delinquency_date,:P_DATE_FORMAT)   AS "AMOUNT_DELINQUENCY_DATE",
         instl_total.status             AS "AMOUNT_STATUS",
         instl_total.amount_type        AS "AMOUNT_TYPE",
         instl_total.amount             AS "AMOUNT",
         instl_total.storno_reversed    AS "AMOUNT_STORNO_REVERSED",
         instl.scheme_code              AS "INSTALMENT_SCHEME_CODE",
         instl.scheme_name              AS "INSTALMENT_SCHEME_NAME",
         to_char(instl.creation_date,:P_DATE_FORMAT)            AS "INSTALMENT_CREATION_DATE",
         instl.total                    AS "INSTALMENT_TOTAL",
         instl.add_info                 AS "INSTALMENT_ADD_INFO",
         instl.scheme_option_code       AS "INSTALMENT_SCHEME_OPTION_CODE",
         instl.scheme_option_name       AS "INSTALMENT_SCHEME_OPTION_NAME",
         instl.record_idt               AS "INSTALMENT_IDT",
         to_char(instl.record_date_from,:P_DATE_FORMAT)         AS "CLOSE_DATE"
        
    FROM dwd_instl_status inst_st
    
    JOIN dwd_instalment instl
      ON instl.status_id = inst_st.id
     AND inst_st.code IN ('CLOSED') 
     AND instl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
     AND instl.record_date_from BETWEEN TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') - :P_NUMBER_OF_DAYS_CLOSED AND TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
     
    JOIN fi 
      ON instl.institution_id = fi.institution_id

    JOIN dwf_instl_total instl_total
      ON instl_total.instalment_idt = instl.record_idt
      
    JOIN dwd_instl_portion portion 
      ON instl_total.inst_portion_idt = portion.record_idt
      
    JOIN dwd_instl_status portion_st 
      ON portion.status_id = portion_st.id
    
    JOIN dwd_contract contr 
      ON contr.record_idt = instl_total.contract_idt
     AND contr.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
     AND contr.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
     
    JOIN dwd_product p 
      ON p.id = contr.product_id

   WHERE (:P_MODE = 'INCREMENTAL'
     AND portion.record_date_to  >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
     AND portion.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
      OR (:P_MODE = 'FULL'
     AND portion.record_date_to   >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
     AND portion.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
