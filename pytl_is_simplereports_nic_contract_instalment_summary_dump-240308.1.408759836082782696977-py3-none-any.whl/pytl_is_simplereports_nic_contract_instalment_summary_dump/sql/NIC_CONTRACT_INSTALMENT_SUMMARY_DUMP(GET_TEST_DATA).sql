with s1 as (
select
    dwd_institution.branch_code,
    dwd_instalment.institution_id,
    dwd_instalment.record_date_from,
    dwd_instalment.record_date_to,
    dwd_instl_status.code
from
    dwd_instalment
    join dwd_instl_status on dwd_instl_status.id = dwd_instalment.status_id
    join dwd_institution on dwd_institution.id = dwd_instalment.institution_id
where
    dwd_institution.branch_code in (
        select
            trim(regexp_substr(:ORGLIST, '[^,]+', 1, level))
        from
            dual
        connect by
            regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
    )
)
select branch_code as org, branch_code, institution_id, code, min(record_date_from), max(record_date_to) from s1 
where code in ('CLOSED')
group by branch_code, institution_id, code 
union
select branch_code as org, branch_code, institution_id, code, min(record_date_from), max(record_date_to) from s1 
where code in ('Z')
group by branch_code, institution_id, code 
union
select branch_code as org, branch_code, institution_id, 'not CLOSED, Z' as code, min(record_date_from), max(record_date_to) from s1 
where code not in ('CLOSED', 'Z')
group by branch_code, institution_id, code 
