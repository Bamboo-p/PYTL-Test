/*
Dump.Contract Active Instalment - Standard Private Credit product build = NIC_CONTRACT_INSTALMENT_SUMMARY_DUMP_ACTIVE.sql

Attention:
    In case of changing of NIC_CONTRACT_INSTALMENT_SUMMARY_DUMP_ACTIVE.sql/NIC_CONTRACT_INSTALMENT_SUMMARY_DUMP_CLOSED.sql
    NIC_CONTRACT_INSTALMENT_SUMMARY_DUMP_HEADER.sql must be validated/updated!

Version history:
----------------
210705.1 = NikitaF  = ENG-3314: adding new query for instalment summary dump
                      https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/commits/b5e9990a95a7c13c90f37acd642acf1026deaf9c#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/sql/NIC_CONTRACT_INSTALMENT_SUMMARY_DUMP.sql
211018.1 = TatianaO = ALMAS-489: added filter by instalment status to decrease file size
                      https://devops.network.ae/stash/projects/INT/repos/pytl_jobs/pull-requests/171/commits/be51c7eefe2ec1ced052ee6b731573fbf14ff913#pytl_jobs/NIC/NIC_IS_Ou_SimpleReports/sql/NIC_CONTRACT_INSTALMENT_SUMMARY_DUMP.sql
211020.1 = DenisKa  = ALMAS-489: comments were added into the sql code
211115.1 = TatianaO = ENG-4179: renamed the report to differentiate active and closed instalment summary dumps
211122.1 = TatianaO = ENG-4179: synch up of layout between active and closed instalment summary dump
220324.1 = Shalini  = ALMB-710: Logic changes to fetch remaining_principal,remaining_fee
230510.1 = TatianaO = BBY-2891: fetching of PB_DOC_ID tag instead of document ID linked to the instalment for the cases when transaction conversion is done via balance conversion
231121.1 = GaukharA = NICORE-977: Adding EXID
240308.1 = Santosh = NICORE-1231: Added P_DATE_FORMAT parameter
*/
WITH fi AS (
    SELECT /*+ no_merge materialize */
        id            institution_id,
        branch_code   code,
        name,
        add_info
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code   branch_code_posting,
                dwd_institution.name,
                dwd_institution.add_info
            FROM
                dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORG, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORG, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
)
--[*] begin : 231121.1 = GaukharA = NICORE-977 : Alternate Id (EXID) logic field added
,exid as (
	select /*+no_merge materialize */
	       dca.card_idt,
		   dca.attr_value card_exid
	  from dwa_card_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CARD'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	)
,exid_contract as (
	select /*+no_merge materialize */
	       dca.contract_idt,
		   dca.attr_value exid
	  from dwa_contract_attribute dca
	  join dwd_attribute da
	    on dca.attr_id = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CONTRACT'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	)	
--[*] end : 231121.1 = GaukharA = NICORE-977 : Alternate Id (EXID) logic field added

SELECT /*+ ORDERED PARALLEL(instl 8) PARALLEL(contr 8) */
    fi.code            AS ORG,
    fi.code            AS institution_branch_code,
    fi.name            AS institution_name,
    p.group_code       AS product_group_code,
    p.code             AS product_code,
    p.name             AS product_name,
    decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)),'Y',con_exid.exid, contr.personal_account)  AS contract_number,
    decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)),'Y',exid.card_exid, card.pan) AS card_pan,
    instl.balance_type_code,
    instl.scheme_code,
    instl.scheme_name,
    instl.currency,
    instl.tenor,
    instl.free_period,
    instl.payment_holidays,
    to_char(instl.creation_date,:P_DATE_FORMAT) as creation_date,
    to_char(instl.start_date,:P_DATE_FORMAT) as start_date,
    to_char(instl.end_date,:P_DATE_FORMAT) as end_date,
    instl.principal,
    instl.rate,
    instl.total,
    instl_st.code      AS instl_status_code,
    instl_st.name      AS instl_status_name,
    instl.add_info,
    instl.fee_capitalization,
    instl.scheme_option_code,
    instl.scheme_option_name,
    instl.record_idt   AS instalment_idt,
    -- [*] begin 230510.1 = TatianaO = BBY-2891: fetching of PB_DOC_ID tag instead of document ID linked to the instalment for the cases when transaction conversion is done via balance conversion
    nvl(sy_convert.get_tag_value(instl.add_info, 'PB_DOC_ID'), instl.doc_idt)   AS doc_idt,
    -- [*] end 230510.1 = TatianaO = BBY-2891: fetching of PB_DOC_ID tag instead of document ID linked to the instalment for the cases when transaction conversion is done via balance conversion
    amnt.remaining_principal as remaining_principal_to_pay,
    amnt.remaining_fee as remaining_fee_to_pay,
    -- [*] 211122.1 = TatianaO = ENG-4179: synch up of layout between active and closed instalment summary dump
    null as close_date
FROM
    dwd_instalment instl
    JOIN fi ON instl.institution_id = fi.institution_id
    JOIN (
        SELECT /*+ PARALLEL(portion 8) */
            SUM(CASE
                WHEN amount_type = 'FEE'
                     AND status IN(
                    'Open', 'Waiting'
                ) THEN amount
                ELSE 0
            END) AS remaining_fee,
            SUM(CASE
                WHEN amount_type = 'PRINCIPAL'
                     AND status IN(
                    'Open', 'Waiting'
                ) THEN amount
                ELSE 0
            END) AS remaining_principal,
            portion.instalment_idt
        FROM
            dwf_instl_total portion
            JOIN fi ON fi.institution_id = portion.institution_id
--[+] begin 220324.1 = Shalini  = ALMB-710: Logic changes to fetch remaining_principal,remaining_fee			
			JOIN dwd_instl_portion ip ON ip.record_idt = portion.inst_portion_idt
			and portion.instalment_idt = ip.instalment_idt
			and ip.record_state = 'A'
            and ip.institution_id =  fi.institution_id
			JOIN dwd_instl_status st on st.id = ip.status_id
			and st.code = 'WAITING'

        GROUP BY 
            portion.instalment_idt
--[+] end 220324.1 = Shalini  = ALMB-710: Logic changes to fetch remaining_principal,remaining_fee
    ) amnt ON amnt.instalment_idt = instl.record_idt
    JOIN dwd_instl_status instl_st ON instl.status_id = instl_st.id
                                  AND instl_st.code not in ('CLOSED', 'Z')  -- [*] 211018.1 = TatianaO = ALMAS-489: added filter by instalment status to decrease file size
    JOIN dwd_product p ON p.id = instl.product_id
    JOIN dwd_contract contr ON contr.record_idt = instl.contract_idt
                               AND contr.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                               AND contr.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
	LEFT JOIN exid_contract con_exid	ON con_exid.contract_idt=contr.record_idt				   
    JOIN dwd_int_product int_p ON contr.int_product_idt = int_p.record_idt
                                  AND int_p.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                                  AND int_p.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    LEFT JOIN dwd_card card ON card.record_idt = instl.card_idt
                               AND card.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                               AND card.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    LEFT JOIN exid 
    on exid.card_idt = card.record_idt                            
WHERE
    ( :P_MODE = 'INCREMENTAL'
      AND instl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
      AND instl.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
    OR ( :P_MODE = 'FULL'
         AND instl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
         AND instl.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )