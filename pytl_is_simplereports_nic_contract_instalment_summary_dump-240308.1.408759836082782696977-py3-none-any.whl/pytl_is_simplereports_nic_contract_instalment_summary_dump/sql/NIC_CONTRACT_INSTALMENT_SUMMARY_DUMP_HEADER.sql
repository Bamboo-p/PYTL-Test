/*
Dump.Contract Header Instalment - Standard Private Credit product build = NIC_CONTRACT_INSTALMENT_SUMMARY_DUMP_HEADER.sql

Attention:
    In case of changing of NIC_CONTRACT_INSTALMENT_SUMMARY_DUMP_ACTIVE.sql/NIC_CONTRACT_INSTALMENT_SUMMARY_DUMP_CLOSED.sql
    NIC_CONTRACT_INSTALMENT_SUMMARY_DUMP_HEADER.sql must be validated/updated!

Version history:
----------------
211125.2 = DenisKa              = ENG-4180: external header
*/
select
    :ORG                            as ORG,
    'INSTITUTION_BRANCH_CODE'       as INSTITUTION_BRANCH_CODE,
    'INSTITUTION_NAME'              as INSTITUTION_NAME,
    'PRODUCT_GROUP_CODE'            as PRODUCT_GROUP_CODE,
    'PRODUCT_CODE'                  as PRODUCT_CODE,
    'PRODUCT_NAME'                  as PRODUCT_NAME,
    'CONTRACT_NUMBER'               as CONTRACT_NUMBER,
    'CARD_PAN'                      as CARD_PAN,
    'BALANCE_TYPE_CODE'             as BALANCE_TYPE_CODE,
    'SCHEME_CODE'                   as SCHEME_CODE,
    'SCHEME_NAME'                   as SCHEME_NAME,
    'CURRENCY'                      as CURRENCY,
    'TENOR'                         as TENOR,
    'FREE_PERIOD'                   as FREE_PERIOD,
    'PAYMENT_HOLIDAYS'              as PAYMENT_HOLIDAYS,
    'CREATION_DATE'                 as CREATION_DATE,
    'START_DATE'                    as START_DATE,
    'END_DATE'                      as END_DATE,
    'PRINCIPAL'                     as PRINCIPAL,
    'RATE'                          as RATE,
    'TOTAL'                         as TOTAL,
    'INSTL_STATUS_CODE'             as INSTL_STATUS_CODE,
    'INSTL_STATUS_NAME'             as INSTL_STATUS_NAME,
    'ADD_INFO'                      as ADD_INFO,
    'FEE_CAPITALIZATION'            as FEE_CAPITALIZATION,
    'SCHEME_OPTION_CODE'            as SCHEME_OPTION_CODE,
    'SCHEME_OPTION_NAME'            as SCHEME_OPTION_NAME,
    'INSTALMENT_IDT'                as INSTALMENT_IDT,
    'DOC_IDT'                       as DOC_IDT,
    'REMAINING_PRINCIPAL_TO_PAY'    as REMAINING_PRINCIPAL_TO_PAY,
    'REMAINING_FEE_TO_PAY'          as REMAINING_FEE_TO_PAY,
    'CLOSE_DATE'                    as CLOSE_DATE
from
    dual
