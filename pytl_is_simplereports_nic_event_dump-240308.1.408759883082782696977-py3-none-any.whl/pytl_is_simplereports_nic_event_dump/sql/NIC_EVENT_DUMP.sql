/*
NIC_EVENT_DUMP.sql
230714.1 = Santosh Singh = NICORE-692: RETURN_EXID_CARD/RETURN_EXID_CONTRACT - external id filter , pass YES to populate exid else NO
240308.1 = Santosh = NICORE-1231: Added P_DATE_FORMAT parameter
*/
WITH fi AS (
    SELECT
        id            institution_id,
        branch_code   code,
        name,
        add_info
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code   branch_code_posting,
                dwd_institution.name,
                dwd_institution.add_info
            FROM
                dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORG, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORG, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
)
--[+] BEGIN 230714.1 = Santosh Singh = NICORE-692: RETURN_EXID_CARD/RETURN_EXID_CONTRACT
,card_ext_nums as (
	select /*+no_merge materialize */
	       dca.card_idt,
		   dca.attr_value card_exid
	  from dwa_card_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CARD'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
),
contract_ext_nums as (
	select /*+no_merge materialize */
	       dca.contract_idt,
		   dca.attr_value contract_exid
	  from dwa_contract_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CONTRACT'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	)
--[+] END 230714.1 = Santosh Singh = NICORE-692: RETURN_EXID_CARD/RETURN_EXID_CONTRACT
SELECT
    fi.code       AS org,
    fi.code       AS institution_branch_code,
    fi.name       AS institution_name,
    'CARD' AS source,
    --[*] BEGIN 230714.1 = Santosh Singh = NICORE-692: RETURN_EXID_CARD/RETURN_EXID_CONTRACT
    --card.pan AS contract_number,
    decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)),'Y',card_exid.card_exid, card.pan) AS contract_number,
    --[*] BEGIN 230714.1 = Santosh Singh = NICORE-692: RETURN_EXID_CARD/RETURN_EXID_CONTRACT
    to_date(card_event.activate_date,:P_DATE_FORMAT) as activate_date,
    card_event.details,
    et.name,
    et.code
FROM
    dwf_card_event card_event
    JOIN fi ON fi.institution_id = card_event.institution_id
    JOIN dwd_event_type et ON et.id = card_event.event_type_id
                              AND record_source = 'W4EVENT_TYPE'
    JOIN dwd_card card ON card_event.card_idt = card.record_idt
                          AND card.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                          AND card.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    left join card_ext_nums card_exid on card.record_idt = card_exid.card_idt --[+] 230714.1 = Santosh Singh = NICORE-692: RETURN_EXID_CARD/RETURN_EXID_CONTRACT
WHERE
    card_event.activate_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
UNION ALL
SELECT
    fi.code       AS org,
    fi.code       AS institution_branch_code,
    fi.name       AS institution_name,
    'CONTRACT' AS source,
    --[*] BEGIN 230714.1 = Santosh Singh = NICORE-692: RETURN_EXID_CARD/RETURN_EXID_CONTRACT
    --cnt.personal_account AS contract_number,
    decode(upper(substr(nvl(:RETURN_EXID_CONTRACT,'N'),1,1)), 'Y',cen.contract_exid, cnt.personal_account) AS contract_number,
    --[*] END 230714.1 = Santosh Singh = NICORE-692: RETURN_EXID_CARD/RETURN_EXID_CONTRACT
    to_date(cnt_event.activate_date,:P_DATE_FORMAT) as activate_date,
    cnt_event.details,
    et.name,
    et.code
FROM
    dwf_contract_event cnt_event
    JOIN fi ON fi.institution_id = cnt_event.institution_id
    JOIN dwd_event_type et ON et.id = cnt_event.event_type_id
                              AND record_source = 'W4EVENT_TYPE'
    JOIN dwd_contract cnt ON cnt_event.contract_idt = cnt.record_idt
                             AND cnt.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                             AND cnt.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    left join contract_ext_nums cen on cnt.record_idt = cen.contract_idt  --[+] 230714.1 = Santosh Singh = NICORE-692: RETURN_EXID_CARD/RETURN_EXID_CONTRACT                           
WHERE
    cnt_event.activate_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')