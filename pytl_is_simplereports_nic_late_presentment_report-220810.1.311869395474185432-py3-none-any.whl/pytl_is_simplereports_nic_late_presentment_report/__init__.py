__version__ = "220810.1"
__job_name__ = "PyTL_IS_SimpleReports_NIC_LATE_PRESENTMENT_REPORT"
__bat_files__ = []

