/*
NIC_LATE_PRESENTMENT_REPORT.sql
25-05-2022 - OPKSAIC-3303 - Bharath - Initial version - NIC late presentment report
             Input params - ORG - bank code needs to be passed , ex -982
			                P_REPORT_DATE - report date with DD-MM-YYYY format
							P_DAY_RETAIL - this is the no of days in diff between transaction date and settlement date from scheme for retail , for NIC its 30
							P_DAY_CASH - this is the no of days in diff between transaction date and settlement date from scheme for cash , for NIC its 10
							RETURN_EXID_CARD - external id filter , pass YES to populate exid else NO
*/
with inst as
	(select /*+ no_merge materialize */ 
          id,
		  branch_code,
		  name inst_name
     from (select d.branch_code,
				  d.posting_institution_id,
				  d.id,
				  d2.branch_code branch_code_posting,
                  d.name
			 from dwd_institution d
			 join dwd_institution d2 
			   on d.posting_institution_id = d2.id
		    where d.record_state = 'A'
		   ) inst
	   start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
										 from dual 
								   connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
									  )
      connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
	), 
trans_types as
	(select /*+ no_merge materialize */
           transaction_type_id, 
		   code
      from v_dwr_transaction_type 
	 where class_code = 'NIC_REPORTS' 
	   and type_code  = 'TRANS_TYPE_CODE'
	),
card_ext_nums as (
	select /*+no_merge materialize */
	       dca.card_idt,
		   dca.attr_value card_exid
	  from dwa_card_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CARD'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	),
products as
	(select /*+ no_merge materialize */
           product_id, 
		   code, 
		   name,
           product_Code
      from v_dwr_product 
     where class_code = 'BASE_REPORTS' 
	   and type_code  = 'LOGO'
	)
	
select /*+ leading(trans) use_hash (trans contracts) */
       contracts.org                        as "ORG",
       decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)),'Y',card_exid.card_exid, cd.pan) as "CARD NUMBER",
       trans.trans_date                     as "TRANS DATE",
       trans.banking_date                   as "SETTL DATE",
       trans.effective_date                 as "POST DATE",
       trans.currency_name                  as "TRANS CURRENCY",
       abs(trans.trans_amount)              as "TRANS AMOUNT",
       abs(trans.local_amount)              as "BILLING AMOUNT",
       substr(trans.trans_details,1,22)     as "MERCHANT NAME",
       trans.trans_city                     as "MERCHANT CITY",
       trans.trans_country_code             as "MERCHANT COUNTRY",
       trans.trans_mcc                      as "MCC",
       trans.auth_code					    as "AUTH CODE",
       trans.pos						    as "POS ENTRY",
       trans.moto						    as "MOTO IND",
       NVL(trans.trans_arn,trans.trans_rrn) as "ARN RRN",
	   ''                                   as "ACQUIRER ID",
       contracts.product_Code               as "PRODUCT CODE",
	   trans.days_gap                       as "NO OF DAYS DIFFERENCE"
	   
  from (select /*+ no_merge use_hash(tr inst) leading(tr inst tt) */
               tr.banking_date,
               tr.target_contract_idt,
               tr.target_card_idt,
               tr.trans_date,
		       tr.effective_date,
               curr.name as currency_name,
               tr.trans_amount,
               tr.local_amount,
               tr.trans_details,
               tr.trans_city,
               tr.trans_country_code,
               tr.trans_mcc,
               tr.auth_code,
               tr.trans_response_code,
               case when dtc.condition_list like '%CONTACTLESS%' and dtc.condition_list like '%READ_CHIP%' then '07'
                    when dtc.condition_list like '%CONTACTLESS%' and dtc.condition_list like '%READ_TRACK%' then '91'
                    when dtc.condition_list like '%READ_TRACK%' then '05' else null end pos,
               case when dtc.condition_list like '%ENET%' and dtc.condition_list like '%SECURE_CODE%' then '5'
                when dtc.condition_list like '%ENET%' and dtc.condition_list like '%SECURE_ATTEMPT%' then '6'
                when dtc.condition_list like '%ENET%' and dtc.condition_list like '%NO_SECURE%' and dtc.condition_list like '%LINE_SECURE%' then '7'
                when dtc.condition_list like '%ENET%' then '8' else null end moto,
               tr.trans_arn,
               tr.trans_rrn,
               tr.doc_idt,
	           tr.effective_date - tr.trans_date days_gap
          from dwf_transaction tr
          join inst inst
            on inst.id                = tr.institution_id
          join trans_types tt
            on tt.transaction_type_id = tr.transaction_type_id
     left join dwd_currency curr
            on curr.code              = tr.trans_currency
           and curr.record_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
           and curr.record_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
          left join dwd_trans_conditions dtc
            on tr.trans_conditions_id = dtc.id
         where tr.banking_date        = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
           and tr.effective_date - tr.trans_date > decode (tt.code, 'RETAIL', :P_DAY_RETAIL, 'CASH',:P_DAY_CASH)
		 ) trans
  join (select /*+ leading(c) no_merge  */
               c.record_idt,
			   p.product_Code,
               p.name as product_name,
			   inst.branch_code as org
          from dwd_contract c
          join inst inst
            on inst.id             = c.institution_id
          join products p
            on p.product_id        = c.product_id
         where c.record_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
           and c.record_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
		) contracts
       on contracts.record_idt = trans.target_contract_idt
	
      join dwd_card cd
		on cd.record_idt        = trans.target_card_idt
	   and cd.record_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and cd.record_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
   
 left join card_ext_nums card_exid
	    on cd.record_idt = card_exid.card_idt

   