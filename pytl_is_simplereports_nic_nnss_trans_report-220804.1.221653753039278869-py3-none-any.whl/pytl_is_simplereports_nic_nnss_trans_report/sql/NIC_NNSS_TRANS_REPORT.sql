/*
* Code for NIC_NNSS_TRANS_REPORT
* PyTL_IS_SimpleReports_NIC_NNSS_TRANS_REPORT = NIC_NNSS_TRANS_REPORT.sql
* Version history:
* 20220802.1 : AJM-3996 : AsserM  : Initial development of query
* 20220803.1 : AJM-3996 : Shalini : Initial commit in PyTL_IS_SimpleReports
* 20220804.1 : AJM-3996 : Shalini : Added ORG , TRANS_DATE and TRANSACTION_POSTING_DATE format updated as a parameter
*/
WITH inst AS (
    SELECT /*+ materialize */
        id,
        branch_code
    FROM
        dwh.dwd_institution
    WHERE
            branch_code = :ORG
        AND record_state = 'A'
), trans_type AS (
    SELECT
        id   tt_id,
        name tt_name
    FROM
        dwh.dwd_transaction_type tt
    WHERE
        record_state = 'A'
), cards AS (
    SELECT
        record_idt card_idt,
        pan
    FROM
        dwh.dwd_card
    WHERE
            institution_id = (
                SELECT
                    id
                FROM
                    inst
            )
        AND record_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
        AND record_date_to >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
)
SELECT
    :ORG                                            AS ORG,
    rpad(nvl(c.pan, ' '), 19, ' ')                  AS CARD_NUMBER,
    tt.tt_name                                      AS TRANSACTION_TYPE,
    to_char(abs(e.amount), '0999999999.99')         AS TRANSACTION_AMOUNT,
    to_char(t.trans_date, :P_REPORT_DATE_FORMAT)    AS TRANS_DATE,/*--(DD/MM/YY)*/
    t.trans_details                                 AS TRANSACTION_DESCRIPTION,
    t.trans_city                                    AS TRANSACTION_CITY,
    t.trans_country_code                            AS TRANSACTION_COUNTRY,
    nvl(t.trans_rrn, t.trans_srn)                   AS TRANSACTION_REFERENCE_NUMBER,
    to_char(t.trans_amount, '0999999999.99')        AS SOURCE_AMOUNT,
    cur.name                                        AS SOURCE_CURRENCY,
    t.auth_code                                     AS AUTHORIZATION_CODE,
    to_char(t.banking_date, :P_REPORT_DATE_FORMAT)  AS TRANSACTION_POSTING_DATE
FROM
         dwf_transaction t
    JOIN (
        SELECT
            contract_idt,
            primary_doc_idt,
            credit - debit AS amount,
            (
                CASE
                    WHEN service_class = 'T'
                         AND ( entry_role IN ( 'B', 'M' )
                               OR ( entry_role = 'F'
                                    AND fee_code = 'MC_MARKUP' )
                               OR
                                ( entry_role = 'A'
                                    AND fee_code = 'VAT' ) ) THEN
                        1
                    ELSE
                        2
                END
            )              AS rn
        FROM
                 dwf_account_entry ae
            JOIN inst i ON i.id = ae.institution_id
        WHERE
            banking_date = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
    ) e ON primary_doc_idt = t.doc_idt
        AND rn = '1'
    JOIN cards            c ON nvl(t.target_card_idt, t.source_card_idt) = c.card_idt
    JOIN trans_type       tt ON tt.tt_id = t.transaction_type_id
    JOIN dwh.dwd_currency cur ON t.trans_currency = cur.code
WHERE
        t.banking_date = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
    AND t.institution_id = (
        SELECT
            id
        FROM
            dwd_institution
        WHERE
            branch_code = :ORG
    )
    AND instr(t.add_info, 'SFLG=8') <> 0
    AND cur.record_state = 'A'