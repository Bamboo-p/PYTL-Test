/*
* Code to get all over limit user accounts for each logo
*
* Version history:
* 210920.1 = Shalini = ALMAS-125: adding to NIC_IS_Ou_SimpleReports. Initial development
* 211019.2 = Shalini = ALMAS-125: Removed corporate product category code and added CORP_PROD tag filter condition(ALMAS-133)
*/
with inst as
  (select /*+ no_merge materialize */
         vdi.id as institution_id, 
		 vdi.branch_code as org_code
    from dwd_institution vdi
   where vdi.record_state = 'A'
     and vdi.branch_code  = :ORG
	 ),
products as
 (select /*+ no_merge materialize */
         vdp.product_id, 
		 substr(vdp.code, 1, 3) as logo,
		 ltrim(vdp.product_name, '0') as logo_name,
		 vdp.add_info --[+]211019.2 = shalini = ALMAS-133
    from v_dwr_product vdp
    join inst
      on inst.org_code  = substr(vdp.code, 5, 3)
   where vdp.type_code  = 'LOGO'
     and vdp.class_code = 'BASE_REPORTS'
	 ),
part_1 as 
 (select /*+ no_merge materialize ordered*/
        c.record_idt,
		da.code
    from dwd_contract c
    join inst i
	  on i.institution_id = c.institution_id
    join products p
      on c.product_id = p.product_id
	and nvl(sy_convert.get_tag_value(p.add_info,'CORP_PROD'),'N')='Y' --[+]211019.3 = shalini = ALMAS-133
	/* --[-]begin 211019.2 = shalini = ALMAS-133
    join opt_v_suppl_group ag
      on nvl(instr(ag.name,p.logo),0) > 0
     and ag.type_code = 'NIC_CORP_PRODUCT_CAT'
	--[-]end 211019.2 = shalini = ALMAS-133 */
	join dwa_contract_attribute dca 
      on c.record_idt = dca.contract_idt
    join dwd_attribute da
      on dca.attr_id  = da.id 
     and da.type_code = 'NIC_USER_ACC_LEVEL'
	 and da.record_state = 'A'
   where dca.attr_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
     and dca.attr_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
     and c.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
     and c.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
	 ),
part_2 as
(select /*+ no_merge materialize */
       user_acct
   from (select c.record_idt,
			    case when b.code = 1 then c.record_idt 
				else lead(c.record_idt,(b.code-1)) over (order by '') end as user_acct,
				level as rn
		   From dwd_contract c
		   join inst i
			 on i.institution_id = c.institution_id
	  left join part_1 b
			 on c.record_idt = b.record_idt
		    and c.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
		    and c.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
	 start with c.record_idt = b.record_idt
	 connect by c.parent_contract_idt = prior c.record_idt)
		  where rn = 1
	 ),
contracts as 
 (select /*+ no_merge materialize ordered use_nl(i) index(c dwd_contract_inst_idx)*/
        c.record_idt, 
		c.personal_account,
		c.product_id,
		c.date_open,
        c.client_short_name,
		c.client_idt,
		i.org_code
   from dwd_contract c
   join inst i
     on i.institution_id = c.institution_id
   join products p
     on p.product_id = c.product_id
	and nvl(sy_convert.get_tag_value(p.add_info,'CORP_PROD'),'N')='N' --[+]211019.2 = shalini = ALMAS-133
	/* --[-]begin 211019.2 = shalini = ALMAS-133
   join opt_v_suppl_group ag
     on nvl(instr(ag.name,p.logo),0) = 0
    and ag.type_code = 'NIC_CORP_PRODUCT_CAT'
	--[-]end 211019.2 = shalini = ALMAS-133 */
  where c.record_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
    and c.record_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
union
   select /*+ no_merge materialize ordered use_nl(i) index(c dwd_contract_inst_idx)*/
         c.record_idt, 
		 c.personal_account,
		 c.product_id,
		 c.date_open,
         c.client_short_name,
		 c.client_idt,
		 i.org_code
    from dwd_contract c
    join inst i
	  on i.institution_id = c.institution_id
    join part_2 cc
	  on cc.user_acct = c.record_idt
   where c.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
     and c.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
	  ),	 
bal as
(select /*+ no_merge materialize */
         ag.account_group_id, 
		 ag.type_code
    from v_dwr_account_group ag
   where ag.class_code = 'BALANCE_TYPE'
     and ag.type_code  = 'TOTAL_BALANCE'
	 ),
balances as (
    select /*+ no_merge ordered full(b) use_hash(b i) use_hash(b ag) */
           i.record_idt,
           sum(b.balance) as total_balance
      from dwf_account_balance b
      join contracts i
        on i.record_idt        = b.contract_idt
      join bal ag
        on ag.account_group_id = b.account_group_id
     where b.banking_date      = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and b.institution_id    = (select institution_id from inst)
     group by i.record_idt
	 ),	
atr as
(select /*+ no_merge materialize */
	   max(case when da.type_code = 'DLQ_LEVEL'            then da.code else null end) as dl,
	   max(case when da.type_code = 'BFA_ACCOUNT_STATUS'   then da.code else null end) as ac,
	   max(case when da.type_code like 'BLOCK_CODE_ACC1_'||:ORG then da.code else null end) as bc1,
	   max(case when da.type_code like 'BLOCK_CODE_ACC2_'||:ORG then da.code else null end) as bc2
  from dwd_attribute da
 where record_state    = 'A' 
   and used_as_default = 'Y'
   and type_code in ('BLOCK_CODE_ACC1_'||:ORG, 'BLOCK_CODE_ACC2_'||:ORG,'DLQ_LEVEL','BFA_ACCOUNT_STATUS')
    ),
last_operations as
 (select /*+ no_merge materialize */
        operation_type_id,
        type_code,
        code
   from v_dwr_operation_type
  where class_code   = 'LAST_ACTIVITY_MARTS'
    and type_code    = 'TRANS_DT' 
    and code         = 'TRANS_DT'
	)
  
    select /*+ use_hash(dc dcl) use_hash(dc lim) use_hash(dc ba) use_hash(dc b) use_hash(dc dcb) use_hash(dc t) index(dcl dwd_client_idt_idx)*/
          /*p.logo                                                      		as logo,
		  p.logo_name                                                		as logo_name,*/
		  dc.org_code                                                       as "ORG",
		  dc.personal_account                                         		as "ACCOUNT NUMBER ",
		  dc.client_short_name                                        		as "SHORT NAME",
		  nvl(b.ac,a.ac)                                               		as "STATUS",
		  'AED'                                                             as "ACCOUNT CURRENCY",
		  nvl(to_char(dcb.billing_date,'dd'),' ')                      		as "BILLING CYCLE DAY",
		  nvl(b.dl,a.dl)                                               		as "DLQ LEVEL",
          decode(nvl(b.bc1,a.bc1),'_',' ',nvl(b.bc1,a.bc1))            		as "BLOCK CODE 1",
          decode(nvl(b.bc2,a.bc2),'_',' ',nvl(b.bc2,a.bc2))            		as "BLOCK CODE 2",
		  to_char(dc.date_open,'DD-MM-YYYY')                             	as "OPENED",
		  to_char(t.operation_date,'DD-MM-YYYY')                         	as "LAST DEBIT",
		  trim(to_char(nvl((ba.total_balance*-1),0),'99999999990.90'))      as "CURRENT BALANCE",
		  trim(to_char(nvl(lim.amount,0) ,'99999999990.90'))                as "CREDIT LIMIT",
		  trim(to_char(nvl((ba.total_balance + lim.amount)*-1,0),'99999999990.90')) as "OVERLIMIT AMOUNT",
		  round((((ba.total_balance + lim.amount)/lim.amount)*100)*-1,3)             as "OVERLIMIT %"
		  
     from contracts dc
	 
	 join products p
	   on p.product_id = dc.product_id
	   
     join dwd_client dcl
       on dcl.record_idt        = dc.client_idt 
      and dcl.record_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
      and dcl.record_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	    	     
     join dwf_contract_limit lim 
       on lim.contract_idt      = dc.record_idt
      and lim.banking_date      = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
      and lim.type_code         = 'FIN_LIMIT'
      and lim.amount!=0
	  
	 join atr a
	   on 1                     = 1

left join balances ba
       on ba.record_idt         = dc.record_idt	 
       
left join (select /*+ no_merge use_hash(dca da)*/
			     dca.contract_idt,
			     max(case when da.type_code like 'BLOCK_CODE_ACC1_'||:ORG then da.code else null end) as bc1,
			     max(case when da.type_code like 'BLOCK_CODE_ACC2_'||:ORG then da.code else null end) as bc2,
			     max(case when da.type_code = 'BFA_ACCOUNT_STATUS'   then da.code else null end) as ac,
			     max(case when da.type_code = 'DLQ_LEVEL' then case when da.code <= 9 then da.code else '9' end end) as dl
		    from dwa_contract_attribute dca
		    join dwd_attribute da
			  on da.id               = dca.attr_id
		     and da.type_code       in ('BLOCK_CODE_ACC1_'||:ORG, 'BLOCK_CODE_ACC2_'||:ORG,'DLQ_LEVEL','BFA_ACCOUNT_STATUS')
		   where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') 
		     and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') 
		group by dca.contract_idt 
			) b 
	  on b.contract_idt = dc.record_idt
 
left join (select /*+ use_hash(dcb inst) */
			     contract_idt,
			     max(billing_date) as billing_date
		    from dwf_contract_billing dcb
		    join inst
			  on inst.institution_id    = dcb.institution_id
		   where dcb.billing_date      >= add_months(TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY'), -2)
		     and dcb.period_start_date <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') 
        group by contract_idt
	      ) dcb
	   on dcb.contract_idt = dc.record_idt
                      
left join (select /*+ no_merge */
				 contract_idt,
				 max(operation_date) as operation_date,
				 max(amount)         as txn_amount
		   from (select nvl(entry.contract_idt, l.contract_idt)     as contract_idt,
						nvl(entry.type_code, l.type_code)           as type_code,
						nvl(entry.code, l.value_code)               as value_code,
						nvl(entry.operation_date, l.operation_date) as operation_date,
						nvl(entry.amount, l.amount)                 as amount
				  from (select /*+ no_merge index(l dwm_last_oper_inst_idx) */
							   l.contract_idt,
							   l.type_code,
							   l.value_code,
							   l.operation_date,
							   l.amount
						  from dwm_last_operation l
						  join inst i 
							on i.institution_id = l.institution_id                                                                                          
						 where l.banking_date   = add_months(last_day(TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')),-1)
						   and l.type_code      = 'TRANS_DT'
						   and l.value_code     = 'TRANS_DT'
						   ) l
				  full outer join
					   (select /*+ no_merge index(e dwf_account_entry_inst_idx) use_hash(e op) */
							   e.contract_idt,
							   max(e.credit-e.debit) keep (dense_rank first order by banking_date desc, primary_entry_idt desc) as amount,
							   max(e.banking_date) as operation_date,
							   op.type_code,
							   op.code
						  from dwf_account_entry e
						  join last_operations op
							on op.operation_type_id  = e.operation_type_id
						 where e.banking_date       >  add_months(last_day(TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')),-1)
						   and e.banking_date       <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
                           and e.institution_id      = (select institution_id from inst)
					  group by e.contract_idt, 
							   op.type_code, 
							   op.code
					    ) entry
					on entry.contract_idt = l.contract_idt
				   and entry.type_code    = l.type_code
				   and entry.code         = l.value_code
				   )
		   group by contract_idt
		   ) t
	 on dc.record_idt = t.contract_idt      
		 
where (ba.total_balance + lim.amount) < 0 
  and p.logo is not null
order by  1