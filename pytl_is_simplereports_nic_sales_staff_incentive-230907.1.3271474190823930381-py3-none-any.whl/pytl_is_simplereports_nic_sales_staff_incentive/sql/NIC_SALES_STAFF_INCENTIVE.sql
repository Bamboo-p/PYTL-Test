/*
* Version history:
* 230804.1 : GaukharA: D2C-7: Sales Staff Incentive report
* 230907.1 : GaukhaA: D2C-301: quarter was added
*/
with INSTITUTION as
      (
      select /*+ no_merge materialize */
        id,
        branch_code code,
        name
                      from (select dwd_institution.branch_code,
                                   dwd_institution.posting_institution_id,
                                   dwd_institution.id,
                                   dwd_institution2.branch_code branch_code_posting,
                                   dwd_institution.name
                            from dwd_institution
                                 join dwd_institution dwd_institution2 on dwd_institution.posting_institution_id = dwd_institution2.id
                            where dwd_institution.record_state = 'A'
                            ) inst
                      start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                                      from dual
                                                      connect by regexp_substr(:ORG , '[^,]+', 1, level) is not null
                                                      )
                      connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
      )

, quart_dates AS (
select /*+no_merge materialize*/
           'Q'||to_char(to_date(:P_REPORT_DATE,'DD-MM-YYYY'), 'Q')||' '||to_char(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),'yyyy') as quarter,---* 230907.1 : GaukhaA: D2C-301: quarter was added
           trunc(to_date(:P_REPORT_DATE,'DD-MM-YYYY'), 'Q') as min_date, 
		   last_day(add_months(trunc(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),'Q'),2)) as max_date
	  from (select add_months(trunc(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),'y'), level - 1) dt 
			  from dual
        connect by level <= 1 )
        )
        
, attr  AS (
select /*+no_merge materialize */
	       dca.contract_idt,
		   dca.attr_value 
	  from dwa_contract_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CONTRACT'
	   and da.record_source    = 'W4CUSTOM'
	   and da.code             = 'STAFF_ID'
       )
     
   
SELECT 
    ins.code                                                     AS "ORG"
    ,d.quarter                                                   AS "QUARTER"--* 230907.1 : GaukhaA: D2C-301: quarter was added
    ,attr.attr_value                                             AS "SALES STAFF ID"
    ,cl.short_name                                               AS "CUSTOMER NAME"
    ,to_char(card.opening_date, 'DD-MM-YYYY')                     AS "DATE CUSTOMER ONBOARDED"
    ,COUNT(card.ID)                                              AS "NUMBERS OF CARD ONBOARDED"
    ,upper(prd.name)                                             AS "PRODUCT NAME"
    
    
FROM
    dwd_card card
    JOIN institution ins ON card.institution_id = ins.id
    JOIN dwd_contract con ON card.main_contract_idt=con.record_idt
    JOIN attr on attr.contract_idt=con.record_idt
    JOIN dwd_card_product prd ON card.card_product_id = prd.id
    JOIN dwd_client cl ON card.client_idt = cl.record_idt
    
    JOIN quart_dates d
	   on trunc(card.opening_date) between d.min_date and d.max_date  
          
WHERE
    con.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
    AND con.record_date_to >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
    AND cl.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
    AND cl.record_date_to >= to_date(:P_REPORT_DATE,'DD-MM-YYYY') 
	AND card.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
	AND card.record_date_to >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
    AND prd.record_state='A'
    AND cl.institution_id = ins.id
    AND con.record_state <> 'C'
    AND cl.record_state <> 'C'
    AND cl.client_category = 'P'
  
group by   ins.code     
    ,attr.attr_value
    ,cl.short_name     
    ,card.opening_date
    ,prd.name   
    ,d.quarter 