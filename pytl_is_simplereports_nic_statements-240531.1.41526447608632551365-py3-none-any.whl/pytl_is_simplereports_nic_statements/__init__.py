__version__ = "240531.1"
__job_name__ = "PyTL_IS_SimpleReports_NIC_STATEMENTS"
__bat_files__ = ["NIC_IS_Ou_Statements.bat"]

