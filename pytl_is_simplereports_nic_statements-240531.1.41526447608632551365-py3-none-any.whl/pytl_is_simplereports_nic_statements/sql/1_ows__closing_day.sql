SELECT f_i.bank_code,
  csv.code billing_day,
  COUNT(1) accounts
FROM ows.acnt_contract ac
INNER JOIN ows.f_i
ON f_i.id=ac.f_i
INNER JOIN OWS.cs_status_log csl
ON csl.acnt_contract__oid = ac.id
INNER JOIN OWS.cs_status_type cst
ON cst.id         =csl.status_type
AND cst.amnd_state='A'
AND cst.code     IN ('BILLING_DAY')
INNER JOIN OWS.cs_status_value csv
ON csv.id           = csl.status_value
AND csv.amnd_state  = 'A'
WHERE csl.Is_active = 'Y'
and ac.con_cat = 'A'
AND ac.amnd_state   = 'A'
AND ac.is_ready     = 'Y'
AND f_i.amnd_state  = 'A'
-- AND f_i.bank_code   = '020'
GROUP BY f_i.bank_code,
  csv.code
ORDER BY 1,2 ;
