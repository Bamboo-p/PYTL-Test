select max(banking_date) from dwh.dwd_banking_date;
