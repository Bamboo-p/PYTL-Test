/*
begin
    opt_nice_statement.load_nice_statement_tables(
                to_char(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'),'DD-FMMON-YYYY'), -- report_date_formatted.strftime("%d-%b-%Y"), 15-JAN-2022 ??? 2022-01-15 ???
                :P_ORG
    );
end;
/
*/
with inst as
       (select  /*+ no_merge materialize */
                inst.id,
                inst.branch_code,
                inst.name,
                inst.branch_code_posting
        from (select dwd_institution.branch_code,
                     dwd_institution.posting_institution_id,
                     dwd_institution.id,
                     dwd_institution.name,
                     dwd_institution2.branch_code branch_code_posting
			  from dwd_institution
			  join dwd_institution dwd_institution2
			    on dwd_institution.posting_institution_id = dwd_institution2.id
			 where dwd_institution.record_state                        = 'A') inst
/*             
          start with inst.branch_code in (select trim(regexp_substr(:p_org_list, '[^,]+', 1, level)) org
                                          from dual
                                          connect by regexp_substr(:p_org_list , '[^,]+', 1, level) is not null)
          connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id
                 and level                                                                           <= 2
*/                 
                 ) ,
	products as (
    select /*+ no_merge materialize */
            *
       from v_dwr_product
      where class_code = 'BASE_REPORTS' and type_code = 'LOGO'),
    account_groups as (
    select /*+ no_merge materialize */
           *
      from v_dwr_account_group
     where class_code = 'BALANCE_TYPE'
       and type_code in ('TOTAL_BALANCE', 'PAST_DUE', 'DUE', 'TOTAL_DUE', 'OVD_01', 'OVD_02', 'OVD_03', 'OVD_04', 'OVD_05', 'OVD_06', 'OVD_07', 'OVD_08', 'CASH_PLAN', 'STMT_BALANCE','DIRECT_DEBIT','LTY_BAL_TOT','FULL_PAYMENT')),
    contracts as (
    select /*+ no_merge ordered use_hash(c i) use_hash(c p) */
           decode(p.code, null, c.parent_contract_idt, c.record_idt) as main_contract_idt,
           substr(p.code, 1, 3)                                      as logo,
           p.name                                                    as logo_name,
           i.name                                                    as institution_name,
		       i.branch_code                                             as org,
           c.*,
           pc.personal_account parent_contract_number
      from dwd_contract c
      join inst i
        on i.id          = c.institution_id
      left join products p
        on p.product_id = c.product_id
      left join dwd_contract pc
        on c.parent_contract_idt  = pc.record_idt
/*        
       and pc.record_date_from   <= :p_report_date
       and pc.record_date_to     >= :p_report_date
     where c.record_date_from    <= :p_report_date
       and c.record_date_to      >= :p_report_date
*/       
       ),
    balances as (
    select /*+ no_merge ordered full(b) use_hash(b i) use_hash(b ag) */
           i.main_contract_idt,
           sum(case when ag.type_code = 'TOTAL_BALANCE' then b.balance else 0 end) as total_balance,
           sum(case when ag.type_code = 'CASH_PLAN'     then b.balance else 0 end) as cash,
           sum(case when ag.type_code = 'STMT_BALANCE'  then b.balance else 0 end) as stmt_balance,
           sum(case when ag.type_code = 'PAST_DUE'      then b.balance else 0 end) as past_due,
           sum(case when ag.type_code = 'TOTAL_DUE'     then b.balance else 0 end) as total_due,
           sum(case when ag.type_code = 'DUE'           then b.balance else 0 end) as due,
           sum(case when ag.type_code = 'DIRECT_DEBIT'  then b.balance else 0 end) as direct_debit,
           sum(case when ag.type_code = 'LTY_BAL_TOT'   then b.balance else 0 end) as loyalty_balance, --might be changed
           sum(case when ag.type_code = 'OVD_01'        then b.balance else 0 end) as ovd_01,
           sum(case when ag.type_code = 'OVD_02'        then b.balance else 0 end) as ovd_02,
           sum(case when ag.type_code = 'OVD_03'        then b.balance else 0 end) as ovd_03,
           sum(case when ag.type_code = 'OVD_04'        then b.balance else 0 end) as ovd_04,
           sum(case when ag.type_code = 'OVD_05'        then b.balance else 0 end) as ovd_05,
           sum(case when ag.type_code = 'OVD_06'        then b.balance else 0 end) as ovd_06,
           sum(case when ag.type_code = 'OVD_07'        then b.balance else 0 end) as ovd_07,
           sum(case when ag.type_code = 'OVD_08'        then b.balance else 0 end) as ovd_08,
           sum(case when ag.type_code = 'FULL_PAYMENT'  then b.balance else 0 end) as full_payment

      from dwf_account_balance b
      join contracts i
        on i.record_idt = b.contract_idt
      join account_groups ag
        on ag.account_group_id = b.account_group_id
/*        
     where b.banking_date = p_report_date
*/     
     group by i.main_contract_idt),
    default_attributes as
    (
    select /*+ no_merge materialize */
           max(case when da.type_code = 'DLQ_LEVEL'               then da.code else null end) as dlq_level,
           max(case when da.type_code = 'BFA_ACCOUNT_STATUS'      then da.code else null end) as activity_status,
           max(case when da.type_code = 'NIC_DIRECT_DEBIT'      then da.code else null end) as direct_debit,
           max(case when da.type_code = 'PCT_TARIFF'              then da.code else null end) as pct_tariff,
           max(case when da.type_code = 'PETRA_AMF_WAIVE'         then da.code else null end) as amf_waiver,
           max(case when da.type_code like 'BLOCK_CODE_ACC1%'     then da.code else null end) as block_code_1,
           max(case when da.type_code like 'BLOCK_CODE_ACC2%'     then da.code else null end) as block_code_2,
           max(case when da.type_code = 'PETRA_INS_ENROLLMENT_01' then da.code else null end) as insurance_enrollment_01,
           max(case when da.type_code = 'PETRA_INS_ENROLLMENT_02' then da.code else null end) as insurance_enrollment_02,
           max(case when da.type_code = 'PETRA_INS_ENROLLMENT_03' then da.code else null end) as insurance_enrollment_03,
           max(case when da.type_code = 'PETRA_INS_ENROLLMENT_04' then da.code else null end) as insurance_enrollment_04,
           max(case when da.type_code = 'PETRA_INS_ENROLLMENT_05' then da.code else null end) as insurance_enrollment_05,
           max(case when da.type_code = 'PETRA_INS_ENROLLMENT_06' then da.code else null end) as insurance_enrollment_06,
           max(case when da.type_code = 'PETRA_INS_ENROLLMENT_07' then da.code else null end) as insurance_enrollment_07,
           --
           max(case when da.type_code = 'PETRA_INS_ENROLLMENT_08' then da.code else null end) as insurance_enrollment_08,
           max(case when da.type_code = 'PETRA_INS_ENROLLMENT_09' then da.code else null end) as insurance_enrollment_09,
           max(case when da.type_code = 'PETRA_INS_ENROLLMENT_10' then da.code else null end) as insurance_enrollment_10,
           max(case when da.type_code = 'PETRA_INS_ENROLLMENT_11' then da.code else null end) as insurance_enrollment_11,
           max(case when da.type_code = 'PETRA_INS_ENROLLMENT_12' then da.code else null end) as insurance_enrollment_12,
           --
           max(case when da.type_code = 'NIC_BILLING_LEVEL'      then da.code else null end) as bil_level,
           max(case when da.type_code = 'NIC_USER_ACC_LEVEL'     then da.code else null end) as usr_acc_level,
           max(case when da.type_code = 'PETRA_SCF_FLAG'         then da.code else null end) as scf_flag,
           max(case when da.type_code = 'PETRA_PORTAL_FLAG_PE'   then da.code else null end) as ssp_flag,
           --
           max(case when da.type_code = 'PETRA_BCFEAT-INS-01'      then da.code else null end) as insurance_status_01,
           max(case when da.type_code = 'PETRA_BCFEAT-INS-02'      then da.code else null end) as insurance_status_02,
           max(case when da.type_code = 'PETRA_BCFEAT-INS-03'      then da.code else null end) as insurance_status_03,
           max(case when da.type_code = 'PETRA_BCFEAT-INS-04'      then da.code else null end) as insurance_status_04,
           max(case when da.type_code = 'PETRA_BCFEAT-INS-05'      then da.code else null end) as insurance_status_05,
           max(case when da.type_code = 'PETRA_BCFEAT-INS-06'      then da.code else null end) as insurance_status_06,
           max(case when da.type_code = 'PETRA_BCFEAT-INS-07'      then da.code else null end) as insurance_status_07,
           max(case when da.type_code = 'PETRA_BCFEAT-INS-08'      then da.code else null end) as insurance_status_08,
           max(case when da.type_code = 'PETRA_BCFEAT-INS-09'      then da.code else null end) as insurance_status_09,
           max(case when da.type_code = 'PETRA_BCFEAT-INS-10'      then da.code else null end) as insurance_status_10,
           max(case when da.type_code = 'PETRA_BCFEAT-INS-11'      then da.code else null end) as insurance_status_11,
           max(case when da.type_code = 'PETRA_BCFEAT-INS-12'      then da.code else null end) as insurance_status_12,         
           --
           max(case when da.type_code = 'PETRA_LPF_WAIVE_PE'      then da.code else null end) as lpf_waiver,
           max(case when da.type_code = 'PETRA_INTEREST_WAIVE_PE' then da.code else null end) as int_waiver,
           max(case when da.type_code = 'OVERLIMIT_FEE_WAIVER'    then da.code else null end) as ovl_waiver,
           max(case when da.type_code = 'NIC_STMT_FLAG'         then da.code else null end) as stmt_flag,
		   max(case when da.type_code = 'PETRA_LTY_ENROLLMENT'    then da.code else null end) as lty_flag   --might be changed
      from dwd_attribute da
     where record_state = 'A' and used_as_default = 'Y'
       and type_code in ('DLQ_LEVEL', 'BFA_ACCOUNT_STATUS', 'NIC_DIRECT_DEBIT','PETRA_LTY_ENROLLMENT',
                        'PCT_TARIFF', 'PETRA_AMF_WAIVE', 'BLOCK_CODE_ACC1_020', 'BLOCK_CODE_ACC2_020', 
                        'BLOCK_CODE_ACC1_030', 'BLOCK_CODE_ACC2_030',
                         'PETRA_INS_ENROLLMENT_01', 'PETRA_INS_ENROLLMENT_02', 
                         'PETRA_INS_ENROLLMENT_03', 'PETRA_INS_ENROLLMENT_04',
                          'PETRA_INS_ENROLLMENT_05','PETRA_INS_ENROLLMENT_06',
                          'PETRA_INS_ENROLLMENT_07','PETRA_INS_ENROLLMENT_08',
                          'PETRA_INS_ENROLLMENT_09','PETRA_INS_ENROLLMENT_10',
                          'PETRA_INS_ENROLLMENT_11','PETRA_INS_ENROLLMENT_12',
                          'NIC_BILLING_LEVEL','NIC_USER_ACC_LEVEL',
                          'PETRA_SCF_FLAG','PETRA_PORTAL_FLAG_PE',
                            'PETRA_BCFEAT-INS-01',
                            'PETRA_BCFEAT-INS-02',
                            'PETRA_BCFEAT-INS-03',
                            'PETRA_BCFEAT-INS-04',
                            'PETRA_BCFEAT-INS-05',
                            'PETRA_BCFEAT-INS-06',
                            'PETRA_BCFEAT-INS-07',
                            'PETRA_BCFEAT-INS-08',
                            'PETRA_BCFEAT-INS-09',
                            'PETRA_BCFEAT-INS-10',
                            'PETRA_BCFEAT-INS-11',
                            'PETRA_BCFEAT-INS-12',                         
                         'PETRA_LPF_WAIVE_PE','PETRA_INTEREST_WAIVE_PE',
                         'OVERLIMIT_FEE_WAIVER','NIC_STMT_FLAG'						
                         )
    )
,main_query as (    
    select /*+ parallel(8) ordered use_hash(c l) use_hash(c balances) use_hash(c billing) use_hash(c attr) */
/*    
           p_report_date                                                        as banking_date,
*/           
           c.org                                                                as org,
           c.institution_name                                                   as institution_name,
           c.record_idt                                                         as record_idt,
           c.record_date_from                                                   as record_date_from,
           c.main_contract_idt                                                  as main_contract_idt,
           c.branch_id                                                          as branch_id,
           c.bank_officer_id                                                    as bank_officer_id,
           c.status_id                                                          as status_id,
           c.status_name                                                        as status_name,
           c.name                                                               as contract_name,
           c.product_id                                                         as product_id,
           c.logo                                                               as logo,
           c.logo_name                                                          as logo_name,
           c.client_idt                                                         as client_idt,
           c.client_category                                                    as client_category,
           c.country_code                                                       as country_code,
           c.region_code                                                        as region_code,
           c.personal_account                                                   as personal_account,
           c.base_currency                                                      as base_currency,
           c.date_open                                                          as date_open,
           c.date_close                                                         as date_close,
           c.parent_contract_idt                                                as parent_contract_idt,
           c.parent_contract_number                                             as parent_contract_number,
           c.add_info                                                           as contract_info,
           c.int_product_idt                                                    as int_product_idt,
           card.record_idt                                                      as primary_card_idt,
           card.embossed_first_name                                             as primary_first_name,
           card.embossed_last_name                                              as primary_last_name,
           card.embossed_company                                                as primary_company_name,
           card.opening_date                                                    as primary_opening_date,
           card.effective_date                                                  as primary_effective_date,
           card.expiry_date                                                     as primary_expiry_date,
           card.pan                                                             as primary_card_number,
           card.sequence_number                                                 as primary_seq_number,
           b.total_balance                                                      as total_balance,
           b.cash                                                               as cash_balance,
           b.stmt_balance                                                       as stmt_balance,
           b.loyalty_balance                                                    as loyalty_balance,
           b.direct_debit                                                       as direct_debit_balance,
           b.past_due                                                           as past_due,
           b.total_due                                                          as total_due,
           b.due                                                                as due,
           b.ovd_01                                                             as ovd_01,
           b.ovd_02                                                             as ovd_02,
           b.ovd_03                                                             as ovd_03,
           b.ovd_04                                                             as ovd_04,
           b.ovd_05                                                             as ovd_05,
           b.ovd_06                                                             as ovd_06,
           b.ovd_07                                                             as ovd_07,
           b.ovd_08                                                             as ovd_08,
		   b.full_payment														as full_payment,
           l.credit_limit                                                       as credit_limit,
           l.amount_available                                                   as amount_available,
           billing.period_start_date                                            as billing_start_date,
           billing.billing_date                                                 as billing_date,
           billing.due_date                                                     as due_date,
           billing.billing_info                                                 as billing_info,
           billing.prev_billing_date                                            as prev_billing_date,
           billing.prev_billing_start_date                                      as prev_billing_start_date,
           billing.prev_due_date                                                as prev_due_date,
           billing.prev_billing_info                                            as prev_billing_info,
           nvl(attr.dlq_level, dflt.dlq_level)                                  as dlq_level,
           nvl(attr.activity_status,dflt.activity_status)                       as activity_status,
           attr.activity_status_date                                            as activity_status_date,
           nvl(attr.direct_debit, dflt.direct_debit)                            as direct_debit,
           nvl(attr.pct_tariff, dflt.pct_tariff)                                as pct_tariff,
           nvl(attr.amf_waiver, dflt.amf_waiver)                                as amf_waiver,
           nvl(attr.block_code_1, dflt.block_code_1)                            as block_code_1,
           attr.block_code_1_date                                               as block_code_1_date,
           nvl(attr.block_code_2, dflt.block_code_2)                            as block_code_2,
           attr.block_code_2_date                                               as block_code_2_date,
           nvl(attr.insurance_enrollment_01, dflt.insurance_enrollment_01)      as insurance_01,
           nvl(attr.insurance_enrollment_02, dflt.insurance_enrollment_02)      as insurance_02,
           nvl(attr.insurance_enrollment_03, dflt.insurance_enrollment_03)      as insurance_03,
           nvl(attr.insurance_enrollment_04, dflt.insurance_enrollment_04)      as insurance_04,
           nvl(attr.insurance_enrollment_05, dflt.insurance_enrollment_05)      as insurance_05,
           nvl(attr.insurance_enrollment_06, dflt.insurance_enrollment_06)      as insurance_06,
           nvl(attr.insurance_enrollment_07, dflt.insurance_enrollment_07)      as insurance_07,
           --
           nvl(attr.insurance_enrollment_08, dflt.insurance_enrollment_03)      as insurance_08,
           nvl(attr.insurance_enrollment_09, dflt.insurance_enrollment_04)      as insurance_09,
           nvl(attr.insurance_enrollment_10, dflt.insurance_enrollment_05)      as insurance_10,
           nvl(attr.insurance_enrollment_11, dflt.insurance_enrollment_06)      as insurance_11,
           nvl(attr.insurance_enrollment_12, dflt.insurance_enrollment_07)      as insurance_12,

            nvl(attr.insurance_status_01, dflt.insurance_status_01)      as insurance_st_01,
            nvl(attr.insurance_status_02, dflt.insurance_status_02)      as insurance_st_02,
            nvl(attr.insurance_status_03, dflt.insurance_status_03)      as insurance_st_03,
            nvl(attr.insurance_status_04, dflt.insurance_status_04)      as insurance_st_04,
            nvl(attr.insurance_status_01, dflt.insurance_status_05)      as insurance_st_05,
            nvl(attr.insurance_status_06, dflt.insurance_status_06)      as insurance_st_06,
            nvl(attr.insurance_status_07, dflt.insurance_status_07)      as insurance_st_07,
            nvl(attr.insurance_status_08, dflt.insurance_status_08)      as insurance_st_08,
            nvl(attr.insurance_status_09, dflt.insurance_status_09)      as insurance_st_09,
            nvl(attr.insurance_status_10, dflt.insurance_status_10)      as insurance_st_10,
            nvl(attr.insurance_status_11, dflt.insurance_status_11)      as insurance_st_11,
            nvl(attr.insurance_status_12, dflt.insurance_status_12)      as insurance_st_12,            

           nvl(attr.bil_level, dflt.bil_level)              as bil_level,
           nvl(attr.usr_acc_level, dflt.usr_acc_level)      as usr_acc_level,
           nvl(attr.scf_flag, dflt.scf_flag)                as scf_flag,
           nvl(attr.ssp_flag, dflt.ssp_flag)                as ssp_flag,

           --
           nvl(attr.lpf_waiver, dflt.lpf_waiver)                                as late_payment_waiver,
           nvl(attr.int_waiver, dflt.int_waiver)                                as interest_waiver,
           nvl(attr.ovl_waiver, dflt.ovl_waiver)                                as overlimit_waiver,
           nvl(attr.stmt_flag, dflt.stmt_flag)                                  as stmt_flag,
           nvl(attr.lty_flag, dflt.lty_flag)                                    as lty_flag           -- might be changed
      from contracts c
      left join (select /*+ no_merge use_hash(cd i) use_hash(cd cs) ordered */
                        row_number() over (partition by cd.main_contract_idt order by decode(cs.category, 'V', 1, 'D', 2, 3), cd.opening_date desc, cd.effective_date desc , cd.record_idt desc) as rn,
                        cd.record_idt,
                        cd.main_contract_idt,
                        cd.embossed_first_name,
                        cd.embossed_last_name,
                        cd.embossed_company,
                        cd.expiry_date,
                        cd.opening_date,
                        cd.effective_date,
                        cd.pan,
                        cd.sequence_number,
                        i.branch_code as bank_code
                   from dwd_card cd
                   join inst i
                     on i.id = cd.institution_id
                   join dwd_contract_status cs
                     on cs.id = cd.status_id
                   left join (select /*+ use_hash(dca da) no_merge */
                                     dca.card_idt, da.code
                                from dwa_card_attribute dca
                                join dwd_attribute da
                                  on da.id = dca.card_idt
                                 and da.type_code like 'BLOCK_CODE_CARD_%'
/*                                 
                               where dca.attr_date_from <= :p_report_date
                                 and dca.attr_date_to   >= :p_report_date
*/                                 
                                 ) attr
                     on attr.card_idt = cd.record_idt
/*                     
                  where cd.record_date_from <= :p_report_date
                    and cd.record_date_to   >= :p_report_date
*/                    
                    /*and cd.main_card_flag = 'Y'*/
					) card
        on card.main_contract_idt = c.record_idt
       and card.rn = 1
      join (select /*+ no_merge use_hash(lim i) */
                   contract_idt,
                   sum(case when lim.type_code = 'FIN_LIMIT' then amount else 0 end) as credit_limit,
                   sum(case when lim.type_code = 'AVAILABLE' then amount else 0 end) as amount_available
              from dwf_contract_limit lim
              join inst i
                on i.id          = lim.institution_id
             where /*lim.banking_date = :p_report_date
               and */lim.type_code in ('FIN_LIMIT','AVAILABLE')
          group by contract_idt) l
        on l.contract_idt = c.record_idt
      left join balances b
        on b.main_contract_idt = c.record_idt
      left join (select /*+ no_merge */
                        contract_idt,
                        max(due_date) due_date,
                        max(case when rn=1 then period_start_date end)                    as period_start_date,
                        max(case when rn=1 then billing_date end)                         as billing_date,
                        max(case when rn=1 then add_info end)                             as billing_info,
                        max(case when rn=2 then billing_date end)                         as prev_billing_date,
                        max(case when rn=2 then period_start_date end)                    as prev_billing_start_date,
                        max(case when rn=2 then add_info end)                             as prev_billing_info,
/*                        
                        max(case when rn=2 and due_date <= p_report_date then due_date
                                 when rn=3 then due_date end)                             as prev_due_date
*/                                 
                        max(due_date)                                                     as prev_due_date
                  from (select /*+ use_hash (dcb inst) */
                               contract_idt,
                               due_date,
                               period_start_date,
                               billing_date,
                               dcb.add_info,
                               row_number() over(partition by contract_idt order by billing_date desc) rn
                          from dwf_contract_billing dcb
						  join inst
						    on inst.id = dcb.institution_id
/*                            
                         where dcb.billing_date >= add_months(p_report_date, -2)
                           and dcb.period_start_date <= p_report_date
*/                           
                        )
                 where rn in (1,2,3)
              group by contract_idt) billing
        on billing.contract_idt = c.record_idt
      left join (select /*+ no_merge use_hash(dca da) */
                        dca.contract_idt,
                        max(case when da.type_code = 'DLQ_LEVEL'               then da.code            else null end) as dlq_level,
                        max(case when da.type_code = 'BFA_ACCOUNT_STATUS'      then da.code            else null end) as activity_status,
                        max(case when da.type_code = 'BFA_ACCOUNT_STATUS'      then dca.attr_date_from else null end) as activity_status_date,
                        max(case when da.type_code = 'NIC_DIRECT_DEBIT'      then da.code            else null end) as direct_debit,
                        max(case when da.type_code = 'PCT_TARIFF'              then da.code            else null end) as pct_tariff,
                        max(case when da.type_code = 'PETRA_AMF_WAIVE'         then da.code            else null end) as amf_waiver,
                        max(case when da.type_code like 'BLOCK_CODE_ACC1%'     then da.code            else null end) as block_code_1,
                        max(case when da.type_code like 'BLOCK_CODE_ACC1%'     then dca.attr_date_from else null end) as block_code_1_date,
                        max(case when da.type_code like 'BLOCK_CODE_ACC2%'     then da.code            else null end) as block_code_2,
                        max(case when da.type_code like 'BLOCK_CODE_ACC2%'     then dca.attr_date_from else null end) as block_code_2_date,
                        max(case when da.type_code = 'PETRA_INS_ENROLLMENT_01' then da.code            else null end) as insurance_enrollment_01,
                        max(case when da.type_code = 'PETRA_INS_ENROLLMENT_02' then da.code            else null end) as insurance_enrollment_02,
                        max(case when da.type_code = 'PETRA_INS_ENROLLMENT_03' then da.code            else null end) as insurance_enrollment_03,
                        max(case when da.type_code = 'PETRA_INS_ENROLLMENT_04' then da.code            else null end) as insurance_enrollment_04,
                        max(case when da.type_code = 'PETRA_INS_ENROLLMENT_05' then da.code            else null end) as insurance_enrollment_05,
                        max(case when da.type_code = 'PETRA_INS_ENROLLMENT_06' then da.code            else null end) as insurance_enrollment_06,
                        max(case when da.type_code = 'PETRA_INS_ENROLLMENT_07' then da.code            else null end) as insurance_enrollment_07,
                        max(case when da.type_code = 'PETRA_INS_ENROLLMENT_08' then da.code else null end) as insurance_enrollment_08,
                        max(case when da.type_code = 'PETRA_INS_ENROLLMENT_09' then da.code else null end) as insurance_enrollment_09,
                        max(case when da.type_code = 'PETRA_INS_ENROLLMENT_10' then da.code else null end) as insurance_enrollment_10,
                        max(case when da.type_code = 'PETRA_INS_ENROLLMENT_11' then da.code else null end) as insurance_enrollment_11,
                        max(case when da.type_code = 'PETRA_INS_ENROLLMENT_12' then da.code else null end) as insurance_enrollment_12,
                       --
                        max(case when da.type_code = 'NIC_BILLING_LEVEL'      then da.code else null end) as bil_level,
                        max(case when da.type_code = 'NIC_USER_ACC_LEVEL'     then da.code else null end) as usr_acc_level,
                        max(case when da.type_code = 'PETRA_SCF_FLAG'         then da.code else null end) as scf_flag,
                        max(case when da.type_code = 'PETRA_PORTAL_FLAG_PE'   then da.code else null end) as ssp_flag,
                       --
                        max(case when da.type_code = 'PETRA_BCFEAT-INS-01'      then da.code else null end) as insurance_status_01,
                        max(case when da.type_code = 'PETRA_BCFEAT-INS-02'      then da.code else null end) as insurance_status_02,
                        max(case when da.type_code = 'PETRA_BCFEAT-INS-03'      then da.code else null end) as insurance_status_03,
                        max(case when da.type_code = 'PETRA_BCFEAT-INS-04'      then da.code else null end) as insurance_status_04,
                        max(case when da.type_code = 'PETRA_BCFEAT-INS-05'      then da.code else null end) as insurance_status_05,
                        max(case when da.type_code = 'PETRA_BCFEAT-INS-06'      then da.code else null end) as insurance_status_06,
                        max(case when da.type_code = 'PETRA_BCFEAT-INS-07'      then da.code else null end) as insurance_status_07,
                        max(case when da.type_code = 'PETRA_BCFEAT-INS-08'      then da.code else null end) as insurance_status_08,
                        max(case when da.type_code = 'PETRA_BCFEAT-INS-09'      then da.code else null end) as insurance_status_09,
                        max(case when da.type_code = 'PETRA_BCFEAT-INS-10'      then da.code else null end) as insurance_status_10,
                        max(case when da.type_code = 'PETRA_BCFEAT-INS-11'      then da.code else null end) as insurance_status_11,
                        max(case when da.type_code = 'PETRA_BCFEAT-INS-12'      then da.code else null end) as insurance_status_12,
                        max(case when da.type_code = 'PETRA_LPF_WAIVE_PE'      then da.code            else null end) as lpf_waiver,
                        max(case when da.type_code = 'PETRA_INTEREST_WAIVE_PE' then da.code            else null end) as int_waiver,
                        max(case when da.type_code = 'OVERLIMIT_FEE_WAIVER'    then da.code            else null end) as ovl_waiver,
                        max(case when da.type_code = 'NIC_STMT_FLAG'         then da.code            else null end) as stmt_flag,
						max(case when da.type_code = 'PETRA_LTY_ENROLLMENT'    then da.code            else null end) as lty_flag
                   from dwa_contract_attribute dca
                   join dwd_attribute da
                     on da.id = dca.attr_id
                    and da.type_code in ('DLQ_LEVEL', 'BFA_ACCOUNT_STATUS', 'NIC_DIRECT_DEBIT','PETRA_LTY_ENROLLMENT',
                        'PCT_TARIFF', 'PETRA_AMF_WAIVE', 'BLOCK_CODE_ACC1_020', 'BLOCK_CODE_ACC2_020', 
                        'BLOCK_CODE_ACC1_030', 'BLOCK_CODE_ACC2_030',
                         'PETRA_INS_ENROLLMENT_01', 'PETRA_INS_ENROLLMENT_02', 
                         'PETRA_INS_ENROLLMENT_03', 'PETRA_INS_ENROLLMENT_04',
                          'PETRA_INS_ENROLLMENT_05','PETRA_INS_ENROLLMENT_06',
                          'PETRA_INS_ENROLLMENT_07','PETRA_INS_ENROLLMENT_08',
                          'PETRA_INS_ENROLLMENT_09','PETRA_INS_ENROLLMENT_10',
                          'PETRA_INS_ENROLLMENT_11','PETRA_INS_ENROLLMENT_12',
                          'NIC_BILLING_LEVEL','NIC_USER_ACC_LEVEL',
                          'PETRA_SCF_FLAG','PETRA_PORTAL_FLAG_PE',
                            'PETRA_BCFEAT-INS-01',
                            'PETRA_BCFEAT-INS-02',
                            'PETRA_BCFEAT-INS-03',
                            'PETRA_BCFEAT-INS-04',
                            'PETRA_BCFEAT-INS-05',
                            'PETRA_BCFEAT-INS-06',
                            'PETRA_BCFEAT-INS-07',
                            'PETRA_BCFEAT-INS-08',
                            'PETRA_BCFEAT-INS-09',
                            'PETRA_BCFEAT-INS-10',
                            'PETRA_BCFEAT-INS-11',
                            'PETRA_BCFEAT-INS-12',                         
                         'PETRA_LPF_WAIVE_PE','PETRA_INTEREST_WAIVE_PE',
                         'OVERLIMIT_FEE_WAIVER','NIC_STMT_FLAG')
/*                         
                  where dca.attr_date_from <= p_report_date
                    and dca.attr_date_to   >= p_report_date
*/                    
               group by dca.contract_idt) attr
        on attr.contract_idt = c.record_idt
      left join default_attributes dflt
        on 1 = 1
)        
select ORG, RECORD_DATE_FROM
from main_query
group by ORG, RECORD_DATE_FROM
order by ORG, RECORD_DATE_FROM
