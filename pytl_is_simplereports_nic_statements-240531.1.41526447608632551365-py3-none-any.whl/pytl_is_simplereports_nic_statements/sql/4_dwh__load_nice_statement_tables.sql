begin
    dwh.opt_nice_statement.load_nice_statement_tables(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'), :ORG);
end;
/
