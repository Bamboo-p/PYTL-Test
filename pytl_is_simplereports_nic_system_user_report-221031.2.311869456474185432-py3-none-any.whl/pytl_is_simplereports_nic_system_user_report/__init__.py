__version__ = "221031.2"
__job_name__ = "PyTL_IS_SimpleReports_NIC_SYSTEM_USER_REPORT"
__bat_files__ = []

