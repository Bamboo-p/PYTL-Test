__version__ = "240325.1"
__job_name__ = "PyTL_IS_SimpleReports_NIC_TRANSACTION_DUMP"
__bat_files__ = []
