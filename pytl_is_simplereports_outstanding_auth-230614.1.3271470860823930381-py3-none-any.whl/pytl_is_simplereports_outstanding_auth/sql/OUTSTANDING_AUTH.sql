/*
    --DM Outstanding Authorizations = OUTSTANDING_AUTH.sql
	20161121.001 Commented SRN filter since it was not returing all auth records
	20161122.002 trunc added for date filters since it was not returing all auth records
	20161122.003 AUTH_CODE not null check removed
	20170926.004 AHOCC-954
    20190724.005 PRD-8471 Performance Fix
    20191029.006 PRD-8084 OUTSTANDING AUTHORIZATIONS report showing as duplicated SR500 , but the customer has only one SR500 TXN , kindly fix the report and advice.
	20210324.7 = NikitaF   = ENG-3193:  007 - Initial commit to PYTL repository
	20211012.8 = SantoshKS = ALMAS-494: 008 - Removed Join for dwd_client_type
	20211020.9 = TatianaO  = ALMAS-494: 009 - Fixed AUTH AMOUNT,AUTH CURRENCY fields.Added TRANSACTION AMOUNT and TRANSACTION CURRENCY fields
    20220627.10 = SantoshKS = OPKSAIC-1450 : 010 - Added MCC and AUTH HOLD DAYS fields
    230614.1 = ErnestH = NICORE-120 : Alternate Id (EXID) logic and rbs number field added
*/
with ins as 
(
select /*+ no_merge materialize */ id,branch_code code,name
					  from (select dwd_institution.branch_code,
								   dwd_institution.posting_institution_id,
								   dwd_institution.id,
								   dwd_institution2.branch_code branch_code_posting,
                                   dwd_institution.name
							from dwd_institution
								 join dwd_institution dwd_institution2 on dwd_institution.posting_institution_id = dwd_institution2.id
							where dwd_institution.record_state = 'A'
							) inst
					  start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
													  from dual 
													  connect by regexp_substr(:ORG , '[^,]+', 1, level) is not null
													  )
					  connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
),
msg_ch as
 (
     select /*+ no_merge  materialize */  * 
     from dwh.v_c$mess_channel where amnd_state = 'A'
)
--[+] begin 230614.1 = ErnestH = NICORE-120 : Alternate Id (EXID) logic and rbs number field added
,card_ext_nums as (
    select /*+no_merge materialize */
           dca.card_idt,
           dca.attr_value card_exid
      from dwa_card_attribute dca
      join dwd_attribute da
        on dca.attr_id = da.id
     where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
       AND dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
       AND da.dimension_code   = 'DWD_CARD'
       AND da.record_source    = 'W4TD_DOMAIN'
       AND da.code             = 'EXID'
    )
--[+] end 230614.1 = ErnestH = NICORE-120 : Alternate Id (EXID) logic and rbs number field added
,auth_A as
(
select  /*+ index( op DWF_ISS_OPER_STARTDT ) */ 
     ins.code,
     decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',main_caen.card_exid,dc.pan) card_number, -- [*] 230614.1 = ErnestH = NICORE-120 : Alternate Id (EXID) logic and rbs number field added
     op.trans_date trans_date,
     dtt.name trans_type,
     msg_ch.name channel_name,
     op.auth_code auth_code,
     op.auth_status auth_status,
     op.amount auth_amount,--[*] 211020.9 = TatianaO = ALMAS-494
     acur.name auth_curr, --[*] 211020.9 = TatianaO = ALMAS-494
	 op.trans_amount trans_amount, --[+] 211020.9 = TatianaO = ALMAS-494
     tcur.name trans_curr, --[+] 211020.9 = TatianaO = ALMAS-494
     op.settl_amount,
     scur.name settl_curr,
     op.TRANS_DETAILS,
     --[+] begin 20220627.10 = SantoshKS = OPKSAIC-1450
     op.trans_mcc,
     round(to_date(:P_REPORT_DATE, 'DD-MM-YYYY') - op.STARTING_DATE) hold_days
     --[+] end 20220627.10 = SantoshKS = OPKSAIC-1450
     ,cnt.contract_number rbs_number --[+] 230614.1 = ErnestH = NICORE-120 : Alternate Id (EXID) logic and rbs number field added
from dwf_iss_operation op 
join ins on ins.id= op.institution_id
join dwd_contract cnt on  cnt.record_idt = op.contract_idt  
                                and cnt.institution_id  = ins.id 
                                and cnt.record_state='A'

join dwd_transaction_type dtt on dtt.record_state='A'
                                and dtt.id =op.transaction_type_id
join dwd_card dc on  dc.main_contract_idt    = op.contract_idt
                                and dc.record_idt        = op.card_idt
                                and dc.record_state    ='A'
--[+] begin 230614.1 = ErnestH = NICORE-120 : Alternate Id (EXID) logic and rbs number field added
left join card_ext_nums main_caen
       on dc.record_idt = main_caen.card_idt
--[+] end 230614.1 = ErnestH = NICORE-120 : Alternate Id (EXID) logic and rbs number field added
join dwd_client dcl on     dcl.record_idt = cnt.client_idt
                                and dcl.record_state='A'
--[-]begin 211012.8 = SantoshKS = ALMAS-494								
--join dwd_client_type dct on dct.id = dcl.client_type_id
--                                and dct.record_state='A'
--                                and dct.code in ('PR','CS','CR','PC') 
--[-]end 211012.8 = SantoshKS = ALMAS-494									
join msg_ch on  msg_ch.code =  op.contra_channel
left join dwd_currency tcur on tcur.code            = op.trans_currency
                                and tcur.record_state ='A'
left join dwd_currency scur on scur.code            = op.settl_currency --[*] 211020.9 = TatianaO = ALMAS-494
                                and scur.record_state ='A'
--[+] begin 211020.9 = TatianaO = ALMAS-494								
left join dwd_currency acur on acur.code            = op.currency
                                and acur.record_state ='A'
--[+] end 211020.9 = TatianaO = ALMAS-494								
where 1=1
and op.starting_date   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY') - :P_DAYS
and op.starting_date   <  to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
and op.contra_channel <>'T'
and op.auth_type        = 'P'
and op.auth_status      ='A'   /* Auth is A */
)
,dwf_iss_operation_auth_m
as 
(
    select  /*+ no_merge  materialize index( op DWF_ISS_OPER_STARTDT ) */  
            op.* 
    from dwf_iss_operation op 
    join ins on ins.id= op.institution_id
    where 1=1
    and op.starting_date   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY') - :P_DAYS
    and op.starting_date   <  to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    and op.contra_channel <> 'T'
    and op.auth_type         = 'P'
    and op.auth_status       = 'M'  /* Auth is M */
)
,
auth_M as
(
select  /*+  no_merge materialize ) */ 
     ins.code,
     decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',main_caen.card_exid,dc.pan) card_number, -- [*] 230614.1 = ErnestH = NICORE-120 : Alternate Id (EXID) logic and rbs number field added
     op_m.trans_date trans_date,
     dtt.name trans_type,
     msg_ch.name channel_name,
     op_m.auth_code auth_code,
     op_m.auth_status auth_status,
     op_m.amount auth_amount,
     acur.name auth_curr, --[*] 211020.9 = TatianaO = ALMAS-494
	 op_m.trans_amount trans_amount, --[*] 211020.9 = TatianaO = ALMAS-494
     tcur.name trans_curr, --[+] 211020.9 = TatianaO = ALMAS-494
     op_m.settl_amount, --[+] 211020.9 = TatianaO = ALMAS-494
     scur.name settl_curr,
     op_m.TRANS_DETAILS,
     --[+] begin 20220627.10 = SantoshKS = OPKSAIC-1450
     op_m.trans_mcc,
     round(to_date(:P_REPORT_DATE, 'DD-MM-YYYY') - op_m.STARTING_DATE) hold_days
     --[+] end 20220627.10 = SantoshKS = OPKSAIC-1450
     ,cnt.contract_number rbs_number --[+] 230614.1 = ErnestH = NICORE-120 : Alternate Id (EXID) logic and rbs number field added
from dwf_iss_operation_auth_m op_m 
join ins on ins.id= op_m.institution_id
join dwd_contract cnt on  cnt.record_idt = op_m.contract_idt  
                                and cnt.record_state='A'

join dwd_transaction_type dtt on dtt.record_state='A'
                                and dtt.id =op_m.transaction_type_id
join dwd_card dc on  dc.main_contract_idt    = op_m.contract_idt
                                and dc.record_idt        = op_m.card_idt
                                and dc.record_state    ='A'
--[+] begin 230614.1 = ErnestH = NICORE-120 : Alternate Id (EXID) logic and rbs number field added
left join card_ext_nums main_caen
       on dc.record_idt = main_caen.card_idt
--[+] end 230614.1 = ErnestH = NICORE-120 : Alternate Id (EXID) logic and rbs number field added
join dwd_client dcl on     dcl.record_idt = cnt.client_idt
                                and dcl.record_state='A'
--[-] begin 211012.8 = SantoshKS = ALMAS-494	
--join dwd_client_type dct on dct.id = dcl.client_type_id
--                                and dct.record_state='A'
--                                and dct.code in ('PR','CS','CR','PC')
--[-]end 211012.8 = SantoshKS = ALMAS-494	
join msg_ch on  msg_ch.code =  op_m.contra_channel
left join dwd_currency tcur on tcur.code            = op_m.trans_currency
                                and tcur.record_state ='A'
left join dwd_currency scur on scur.code            = op_m.settl_currency --[*] 211020.9 = TatianaO = ALMAS-494
                                and scur.record_state ='A'
--[+] begin 211020.9 = TatianaO = ALMAS-494								
left join dwd_currency acur on acur.code            = op_m.currency
                                and acur.record_state ='A'
--[+] end 211020.9 = TatianaO = ALMAS-494						
where 1=1
and op_m.closing_date   >=  to_date(:P_REPORT_DATE, 'DD-MM-YYYY') - 1
and op_m.closing_date   <   to_date(:P_REPORT_DATE, 'DD-MM-YYYY') 
),
top_sql as 
(
    select  * from auth_A
    union all
    select * from auth_M   
)
select 
  code "ORG",
  CARD_NUMBER "CARD NUMBER",
  to_char(TRANS_DATE, 'dd-mm-yyyy') "TRANSACTION DATE",
  TRANS_TYPE "TRANSACTION TYPE",
  CHANNEL_NAME "CHANNEL",
  AUTH_CODE "AUTH CODE",
  AUTH_STATUS "AUTH STATUS",
  trim(to_char(AUTH_AMOUNT,  '99999999990.00')) "AUTH AMOUNT",
  AUTH_CURR "AUTH CURRENCY",
  --[+] begin 211020.9 = TatianaO = ALMAS-494
  trim(to_char(TRANS_AMOUNT,  '99999999990.00')) "TRANSACTION AMOUNT",
  TRANS_CURR "TRANSACTION CURRENCY",
  --[+] end 211020.9 = TatianaO = ALMAS-494
  trim(to_char(SETTL_AMOUNT, '99999999990.00')) "SETTLEMENT AMOUNT",
  SETTL_CURR "SETTLEMENT CURRENCY",
  TRANS_DETAILS "TRANSACTION DESCRIPTION",
  --[+] begin 20220627.10 = SantoshKS = OPKSAIC-1450
  TRANS_MCC "MCC",
  HOLD_DAYS "AUTH HOLD DAYS"
  --[+] end 20220627.10 = SantoshKS = OPKSAIC-1450
  ,RBS_NUMBER "RBS NUMBER" --[+] 230614.1 = ErnestH = NICORE-120 : Alternate Id (EXID) logic and rbs number field added

from top_sql
order by trans_date