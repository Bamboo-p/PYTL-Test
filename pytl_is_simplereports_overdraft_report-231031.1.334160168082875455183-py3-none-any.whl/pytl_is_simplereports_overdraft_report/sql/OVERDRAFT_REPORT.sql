/*
220829.1 : Santosh : OPKSAIC-4771: Initial version : Overdraft report for Tiqmo
220906.1 : Santosh : OPKSAIC-4771: corrected param orglist
220920.1 : Santosh : OPKSAIC-4771: product code corrected
220920.2 : Santosh : OPKSAIC-4771: added comments in changed code
230315.1 : Santosh : NICORE-476: Added new fields
230515.1 : ErnestH : NICORE-614: Added new fields
230517.1 : ErnestH : NICORE-614: Field change for top contract: record_idt -> contract_number
230529.1 : ErnestH : NICORE-614: Typo fix
230601.1 = Santosh = NICORE-637 - Change for Available balance for multi currency
230602.1 = Santosh = NICORE-637 - Refactoring of query and removal of views
230926.1 = GaukharA = D2C-314 - Refactoring of query and removal of duplicates
231031.1 = Santosh = D2C-314 - Join table change
*/
with inst as
(select  /*+ no_merge materialize */
       inst.id,
       inst.branch_code,
       inst.name,
       inst.branch_code_posting
  from (select i.branch_code,
               i.posting_institution_id,
               i.id,
               i.name,
               i2.branch_code branch_code_posting
          from dwd_institution i
          join dwd_institution i2
            on i.posting_institution_id = i2.id
         where i.record_state                        = 'A') inst
    start with inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                      from dual
                                connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
    connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id
           AND level <= 2),
card_ext_nums as (
    select /*+no_merge materialize */
           dca.card_idt,
           dca.attr_value card_exid
      from dwa_card_attribute dca
      join dwd_attribute da
        on dca.attr_id = da.id
     where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
       AND dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
       AND da.dimension_code   = 'DWD_CARD'
       AND da.record_source    = 'W4TD_DOMAIN'
       AND da.code             = 'EXID'
    )
    --[+] Begin 230602.1 = Santosh = NICORE-637 - Refactoring of query and removal of views
,Attr_code as (
SELECT /*+ no_merge use_index(dca DWA_CNTR_ATTR_DATE_TO_IDX)*/
    dca.contract_idt,
    max(case when da.type_Code = 'BFA_ACCOUNT_STATUS' then da.name  else null end) as acnt_status_name,
    max(case when da.type_code = 'BLOCK_CODE_ACC1_'||inst.branch_code  then da.code else null end) AS bc1,
    max(case when da.type_code = 'BLOCK_CODE_ACC2_'||inst.branch_code  then da.code else null end) AS bc2
FROM
    dwa_contract_attribute dca    
    JOIN dwd_attribute da ON da.id = dca.attr_id
    JOIN inst on 1=1
    AND da.type_code in (select 'BLOCK_CODE_ACC'||t.lvl||'_'||i.branch_code from inst i join (select level as lvl from dual connect by level <=2) t on 1=1)
WHERE
    dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
    AND dca.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
GROUP BY
    dca.contract_idt
) 
,dflt_status as (
SELECT /*+ no_merge */
    da.name as dflt_acnt_status_name
FROM dwd_attribute da    
WHERE
    type_Code = 'BFA_ACCOUNT_STATUS'
    and used_as_default = 'Y'
    and record_state = 'A' 
)   
--[+] Begin 230602.1 = Santosh = NICORE-637 - Refactoring of query and removal of views
SELECT inst.branch_code                                                                              AS ORG,
       c.personal_account                                                                            AS ACCOUNT_NUMBER,
       decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',main_caen.card_exid, ca.pan)        AS CARD_NUMBER,
       cl.client_number                                                                              AS CUSTOMER_ID,
       p.code                                                                                        AS PRODUCT_CODE,  -- [*] OPKSAIC-4771 : Santosh : p.product_code -> p.code
       l.amount_available                                                                            AS OVERDRAFT_AMOUNT
       --[+]begin 20230315.1 : NICORE-476 : Santosh : Added new fields
      ,c.client_short_name                                                                           AS CONTRACT_NAME
      ,addr.add_sms_email                                                                            AS EMAIL
      --[+]end 20230315.1 : NICORE-476 : Santosh : Added new fields
      --[+]begin 20230515.1 : NICORE-614 : ErnestH : Added new fields
      ,con.ROOT_PERSONAL_ACCOUNT                                                                     AS TOP_CONTRACT  -- 230517.1 : ErnestH : NICORE-614 : Field change for top contract: record_idt -> contract_number
      --[*] Begin 230602.1 = Santosh = NICORE-637 - Refactoring of query and removal of views
      --,decode(b.bc1, '_', null, b.bc1)                                                               AS BLOCK_CODE_1
      --,decode(b.bc2, '_', null, b.bc2)                                                               AS BLOCK_CODE_2
      --,nvl(da.code, a.name)                                                                          AS STATUS
      ,decode(blk.bc1, '_', null, blk.bc1)                                                            AS BLOCK_CODE_1
      ,decode(blk.bc2, '_', null, blk.bc2)                                                            AS BLOCK_CODE_2
      ,nvl(blk.acnt_status_name,df.dflt_acnt_status_name)                                             AS STATUS
      --[*] End 230602.1 = Santosh = NICORE-637 - Refactoring of query and removal of views
      --[+]end 20230515.1 : NICORE-614 : ErnestH : Added new fields
FROM dwd_contract c
--[+]begin 20230515.1 : NICORE-614 : ErnestH : Added new fields
JOIN dwd_client cl
on cl.record_idt=c.client_idt
AND cl.record_date_from    <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
AND cl.record_date_to      >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')

LEFT JOIN opt_dm_nice_contract_hierarchy con on con.contract_idt = c.record_idt
--LEFT JOIN dwd_contract con ON con.record_idt=c.parent_contract_idt -- 20230529.1 : NICORE-614 : ErnestH : Typo fix
--[+] Begin 230602.1 = Santosh = NICORE-637 - Refactoring of query and removal of views
LEFT JOIN attr_code blk on c.record_idt=blk.contract_idt
LEFT JOIN dflt_status df on 1=1
--[+] END 230602.1 = Santosh = NICORE-637 - Refactoring of query and removal of views
JOIN inst ON inst.id = c.institution_id
AND c.record_date_from    <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
AND c.record_date_to      >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
JOIN dwd_card ca ON c.record_idt = ca.main_contract_idt
AND ca.record_date_from    <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
AND ca.record_date_to      >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
JOIN (select /*+ no_merge use_hash(lim i) */
                   contract_idt,
                   sum(case when lim.type_code in ('AVAILABLE','LINKED_ACC_AVAILABLE') then amount else 0 end) as amount_available --[*]230601.1 = Santosh = NICORE-637 - Change for Available balance for multi currency
              from dwf_contract_limit lim
              join inst i
                on i.id          = lim.institution_id
             where lim.banking_date = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
               AND lim.type_code in ('AVAILABLE','LINKED_ACC_AVAILABLE') --[*]230601.1 = Santosh = NICORE-637 - Change for Available balance for multi currency
          group by contract_idt) l
        ON l.contract_idt = con.root_contract_idt
LEFT JOIN dwd_product p ON p.id = c.product_id  -- [*] OPKSAIC-4771 : Santosh :dwd_card_product -> dwd_product
AND p.record_state = 'A'
LEFT JOIN card_ext_nums main_caen
       ON ca.record_idt = main_caen.card_idt
--[+]begin 20230315.1 : NICORE-476 : Santosh : Added new fields
left join (select /*+ no_merge ordered use_hash(da i) use_hash(da dat) */
                   da.client_idt,
                   max(case when dat.code = 'ADD_SMS_1' then da.e_mail    else null end) as add_sms_email
              from dwd_address da
              join inst i
                on i.id = da.institution_id
              join dwd_address_type dat
                on dat.id = da.address_type_id
               AND dat.code  = 'ADD_SMS_1'
               AND dat.record_state='A'
             where da.record_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
               AND da.record_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
          group by da.client_idt) addr
                on addr.client_idt     = c.client_idt
--[+]end 20230315.1 : NICORE-476 : Santosh : Added new fields
WHERE UPPER(p.card_category_code) = 'PREPAID'
AND ca.main_card_flag = 'Y'
AND l.amount_available < 0
AND con.BANKING_DATE = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
ORDER BY  p.code -- [*] OPKSAIC-4771 : Santosh : p.product_code -> p.code