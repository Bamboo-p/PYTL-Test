__version__ = "231212.1"
__job_name__ = "PyTL_IS_SimpleReports_STATEMENT_CHANGES_REPORT"
__bat_files__ = []
