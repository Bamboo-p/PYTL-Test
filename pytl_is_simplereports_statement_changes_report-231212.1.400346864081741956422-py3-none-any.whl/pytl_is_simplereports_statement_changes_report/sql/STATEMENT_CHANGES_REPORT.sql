/*
Purpose: Report to provide the client number and mobile number in case of mistaces in the number

Incoming parameters:
    :ORGLIST
    :P_REPORT_DATE as dd-MM-yyyy
231109.1 = AlexanderK = AUBI-3937: Initial development
231211.1 = AlexanderK = AUBI-3937: Added is null condition
231212.1 = AlexanderK = AUBI-3937: Changed report name
*/
WITH
fi as (
    SELECT /*+ no_merge materialize */
        id,
        branch_code code,
        name
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code branch_code_posting,
                dwd_institution.name
            FROM
                dwd_institution
            JOIN
                dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY decode(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
),

addr_stmt as (SELECT /*+ materialize use_nl_with_index(da,DWD_ADDRESS_INST_IDX)*/
                        MAX(fi.code) ficode
                        ,DA.CLIENT_IDT clidt
                        ,MAX(CASE
                              WHEN DAT.CODE = 'ADD_SMS_1'
                              THEN DA.ADDRESS_ZIP
                            END) mobile
                        FROM fi
                            JOIN DWD_ADDRESS DA ON (DA.institution_id = fi.id
                                                AND DA.RECORD_STATE <> 'C'
                                                AND TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy') BETWEEN DA.record_date_from AND DA.record_date_to
                                                    )
                            JOIN DWD_ADDRESS_TYPE DAT ON (DA.ADDRESS_TYPE_ID = DAT.ID
                                                      AND DAT.CODE IN( 'STMT_ADDR','ADD_SMS_1')
                                                            )
                 GROUP BY DA.CLIENT_IDT
                 )


select
    dwaddr.ficode                                                                  as ORG
    ,dwclient.client_number                                                        as CLIENT_NUMBER
    ,dwaddr.mobile                                                                 as CLIENT_LEVEL_MOBILE_NBR
    
from
    addr_stmt dwaddr
left join dwd_client dwclient
    on dwaddr.clidt = dwclient.record_idt
    and TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy') BETWEEN dwclient.record_date_from and dwclient.record_date_to
where
    dwaddr.mobile is null
    or dwaddr.mobile like '+%'
    or dwaddr.mobile like '% %'
    or Length(dwaddr.mobile) < 11
    or Substr(dwaddr.mobile,4,1) not in (9, 5, 6, 4)
