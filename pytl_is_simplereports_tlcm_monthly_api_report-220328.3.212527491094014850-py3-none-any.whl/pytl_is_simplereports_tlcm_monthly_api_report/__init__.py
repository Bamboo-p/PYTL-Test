__version__ = "220328.3"
__job_name__ = "PyTL_IS_SimpleReports_TLCM_MONTHLY_API_REPORT"
__bat_files__ = []

