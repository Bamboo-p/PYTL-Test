/*
* Python: SimpleRep with monthly TLCM_NOTIF_API_REPORT.sql
*
* Version history:
* 210926.1 = Santosh = ADCB-9742: adding NIC_IS_Ou_SimpleReports. Initial development.
*/
with ORG_LIST
as
(
    select id
         , bank_code
         , name
      from (select fi.bank_code,
                   fi.posting_in,
                   fi.id,
                   fi2.bank_code as bank_code_posting,
                   fi.name
            from ows.f_i fi
                 join ows.f_i fi2 on fi.posting_in = fi2.id
            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
            ) inst
      start with inst.bank_code in (select trim(regexp_substr( :ORG, '[^,]+', 1, level)) org
                                      from dual
                                      connect by regexp_substr( :ORG, '[^,]+', 1, level) is not null
                                   )
      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
)
select org_list.bank_code                       as "ORG",
       to_char(posting_date, 'DD-MON-YY')       as "REPORT DATE",
       card_number                              as "OLD CARD NUMBER",
       card_number_r                            as "NEW CARD NUMBER",
       to_char(posting_date, 'DD-MON-YY HH24:MI:SS') as "DATE OF REQUEST",
       req_group.name || ' ' ||req_code.name    as "API REQUEST TYPE",
       decode(req.outward_status, 'N', 'To be Sent', 'Y', 'Success', 'J', 'Rejected', 'S', 'Suspended', 'Undefined') as "RESPONSE FROM IPS",
       ows.sy_convert.get_tag_value(req.response_text, 'RESP_CODE') as "ERROR CODE"
  from OWS.REMOTE_FILE_REQ req  left outer join OWS.SY_STD_HANDBOOK req_group on (req_group.code = req.request_group
                                                                                    and req_group.group_code = 'REMOTE_FILE_REQUEST__REQ_GROUP'
                                                                                    and req_group.filter1 = req.channel
                                                                                  )
                                left outer join OWS.SY_STD_HANDBOOK req_code on (req_code.code = req.request_code
                                                                       and req_code.group_code = 'REMOTE_FILE_REQUEST__REQ_CODE'
                                                                       and req_code.filter1 = req.request_group
                                                                     )
                                join OWS.ACNT_CONTRACT acnt on (acnt.contract_number = req.card_number
                                                                    and acnt.amnd_state = 'A'
                                                                )
                                join ORG_LIST on (acnt.f_i = org_list.id)
    where req.file_code in ('MCC106','PAN', 'TK', 'CS') and req.amnd_state = 'A'
      and req.outward_status in ('J', 'Y', 'S')
     -- and trunc(req.posting_date) = to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
      and trunc(req.posting_date) BETWEEN add_months(to_date(:P_REPORT_DATE,'dd-MM-yyyy'),-1)+1 AND to_date(:P_REPORT_DATE,'dd-MM-yyyy')