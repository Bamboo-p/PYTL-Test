__version__ = "230310.1"
__job_name__ = "PyTL_IS_SimpleReports_TLCM_NOTIF_API_REPORT"
__bat_files__ = []

