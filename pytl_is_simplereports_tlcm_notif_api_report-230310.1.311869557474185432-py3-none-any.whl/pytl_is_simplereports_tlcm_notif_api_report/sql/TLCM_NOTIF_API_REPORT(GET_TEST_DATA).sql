select distinct fi.bank_code as "ORG", fi.bank_code, acnt.f_i,
       to_char(posting_date, 'DD-MON-YY')       as "REPORT DATE"
  from OWS.REMOTE_FILE_REQ req  left outer join OWS.SY_STD_HANDBOOK req_group on (req_group.code = req.request_group
                                                                                    and req_group.group_code = 'REMOTE_FILE_REQUEST__REQ_GROUP'
                                                                                    and req_group.filter1 = req.channel
                                                                                  )
                                left outer join OWS.SY_STD_HANDBOOK req_code on (req_code.code = req.request_code
                                                                       and req_code.group_code = 'REMOTE_FILE_REQUEST__REQ_CODE'
                                                                       and req_code.filter1 = req.request_group
                                                                     )
                                join OWS.ACNT_CONTRACT acnt on (acnt.contract_number = req.card_number
                                                                    and acnt.amnd_state = 'A'
                                                                )
                                join ows.f_i fi on (acnt.f_i = fi.id)
    where req.file_code in ('MCC106','PAN', 'TK', 'CS') and req.amnd_state = 'A'
      and req.outward_status in ('J', 'Y', 'S')
order by ORG asc, "REPORT DATE" desc