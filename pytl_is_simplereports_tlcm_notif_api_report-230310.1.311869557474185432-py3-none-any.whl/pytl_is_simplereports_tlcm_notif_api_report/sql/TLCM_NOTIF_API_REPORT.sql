/*
09-12-2021 : OPKSAIC-1710 : enhancing existing standard report to add KSA requirements
                            1. Added alternate number logic to enhance report to EXID in the report based on input parameter
                            2. New input parameter RETURN_EXID introduced to fetch alternate id instead of PAN
                               possible inputs : RETURN_EXID=YES - fetches alternate id instead of card number
                                                 RETURN_EXID=NO - fetches card number
                                                 RETURN_EXID=null - fetches card number
* 220215.6 = DenisKa = OPKSAIC-3226: fixed the issue with running under users different from OWS.
16-01-2022 : OPKSAIC-3246 : RETURN_EXID is spitted into RETURN_EXID_CARD / RETURN_EXID_CONTRACT
                            For Tiqmo RETURN_EXID_CONTRACT is not applicable , but default value is NO
*  220302.1 = ShaliniU = ALMB-640 : Query changes committed as per the latest changes provided by Bharath to fetch data for other orgs as well
*  220524.1 = Bharath  = OPKSAIC-1711 : External id logic corrected for NEW CARD NUMBER field
*  230310.1 = Santosh = AJM-4445 : Removed duplicate join
*/
with org_list as (
    select /*+no_merge materialize*/
          id,
          bank_code,
          name
      from (select fi.bank_code,
                   fi.posting_in,
                   fi.id,
                   fi2.bank_code as bank_code_posting,
                   fi.name
             from ows.f_i fi
             join ows.f_i fi2
               on fi.posting_in = fi2.id
            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
            ) inst
      start with inst.bank_code in (select trim(regexp_substr( :ORGLIST, '[^,]+', 1, level)) org
                                      from dual
                                connect by regexp_substr( :ORGLIST, '[^,]+', 1, level) is not null
                                   )
      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
    ),
auth_type as (
    select /*+no_merge materialize*/
          id
     From ows.td_auth_type
    where code        = 'EXID'
      and amnd_state  = 'A'
    ),
auth_schemes as (
    select /*+no_merge materialize*/
	      s.auth_idt,
		  s.acnt_contract__id
	 from ows.td_auth_sch s 
	 join auth_type at2
       on s.auth_type  = at2.id
      and s.amnd_state = 'A'
      and s.is_ready   = 'Y'		  
	)
    select org_list.bank_code                       as "ORG",
           to_char(posting_date, 'DD-MON-YY')       as "REPORT DATE",
		   case when acnt.con_cat = 'C' then 
           decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',ca_nu.auth_idt, req.card_number) else
		   decode(upper(substr(nvl(:RETURN_EXID_CONTRACT,'N'),1,1)), 'Y',ca_nu.auth_idt, req.card_number) end as "OLD CARD NUMBER",
		   case when acnt_r.con_cat = 'C' then -- [*] 220524.1 = Bharath = OPKSAIC-1711: External id logic corrected for NEW CARD NUMBER field
           decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',ca_nu_r.auth_idt, req.card_number_r) else 
           decode(upper(substr(nvl(:RETURN_EXID_CONTRACT,'N'),1,1)), 'Y',ca_nu_r.auth_idt, req.card_number_r) end as "NEW CARD NUMBER",
           to_char(posting_date, 'DD-MON-YY HH24:MI:SS') as "DATE OF REQUEST",
           req_group.name || ' ' ||req_code.name         as "API REQUEST TYPE",
           decode(req.outward_status, 'N', 'To be Sent', 'Y', 'Success', 'J', 'Rejected', 'S', 'Suspended', 'Undefined') as "RESPONSE FROM IPS",
           ows.sy_convert.get_tag_value(req.response_text, 'RESP_CODE') as "ERROR CODE"

      from ows.remote_file_req req
 left join ows.sy_std_handbook req_group
        on req_group.code       = req.request_group
       and req_group.group_code = 'REMOTE_FILE_REQUEST__REQ_GROUP'
       and req_group.filter1    = req.channel
 left join ows.sy_std_handbook req_code
        on req_code.code       = req.request_code
       and req_code.group_code = 'REMOTE_FILE_REQUEST__REQ_CODE'
       and req_code.filter1    = req.request_group
      join ows.acnt_contract acnt
        on acnt.contract_number = req.card_number
       and acnt.amnd_state      = 'A'
      join org_list
        on acnt.f_i = org_list.id
-- [+] begin 220524.1 = Bharath = OPKSAIC-1711: External id logic corrected for NEW CARD NUMBER field 
-- [-] begin 230310.1 = Santosh = AJM-4445 : Removed duplicate join
/*      
 left join ows.acnt_contract acnt_r
        on acnt_r.contract_number = req.card_number_r
       and acnt_r.amnd_state      = 'A'
*/       
-- [-] begin 230310.1 = Santosh = AJM-4445 : Removed duplicate join
-- [+] end   220524.1 = Bharath = OPKSAIC-1711: External id logic corrected for NEW CARD NUMBER field        
 left join auth_schemes ca_nu
        on ca_nu.acnt_contract__id = acnt.id
		
 left join ows.acnt_contract acnt_r
        on acnt_r.contract_number = req.card_number_r
       and acnt_r.amnd_state      = 'A'
       and acnt_r.f_i             = org_list.id

 left join auth_schemes ca_nu_r
        on ca_nu_r.acnt_contract__id = acnt_r.id -- [*] 220524.1 = Bharath = OPKSAIC-1711: External id logic corrected for NEW CARD NUMBER field

     where req.file_code in ('MCC106','PAN', 'TK', 'CS')
       and req.amnd_state = 'A'
       and req.outward_status in ('J', 'Y', 'S', 'N')
       and trunc(req.posting_date) = to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
