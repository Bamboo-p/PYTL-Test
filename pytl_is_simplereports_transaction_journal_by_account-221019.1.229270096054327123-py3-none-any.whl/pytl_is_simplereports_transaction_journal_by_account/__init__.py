__version__ = "221019.1"
__job_name__ = "PyTL_IS_SimpleReports_TRANSACTION_JOURNAL_BY_ACCOUNT"
__bat_files__ = []

