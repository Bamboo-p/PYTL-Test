__version__ = "230523.1"
__job_name__ = "PyTL_IS_SimpleReports_TRIAL_BALANCE_BY_ACCOUNT"
__bat_files__ = []

