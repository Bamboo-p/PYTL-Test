/*
* Trial Balance by Account Report = TRIAL_BALANCE_BY_ACCOUNT.sql
*
* Version history:
* 20210324.1 = NikitaF = ENG-3193:  001 - Initial development
* 20211011.1 = Shalini = ALMAS-133: 002 - Changes for corporate product category code
* 20211019.1 = Shalini = ALMAS-133: 003 - Removed corporate product category code and added CORP_PROD tag filter condition
* 20211020.1 = DenisKa = ALMAS-522: 004 - ALMAS-133 was splitted into ALMAS-133 (Way4 changes), ALMAS-522 (PyTL changes)
* 20230425.1 = Santosh = NICORE-429:005 - Added base_currency and parent_contract_number 
* 20230512.1 = Santosh = NICORE-429:006 - Added default account status
* 20230517.1 = Santosh = NICORE-429:007 - change to pull expiry date for all multicurrency contracts
* 20230523.1 = Santosh = NICORE-429:008 - Change for Available balance for multi currency
*/
with institutions as
(select /*+ no_merge materialize */ id institution_id,branch_code code,name
                      from (select dwd_institution.branch_code,
                                   dwd_institution.posting_institution_id,
                                   dwd_institution.id,
                                   dwd_institution2.branch_code branch_code_posting,
                                   dwd_institution.name
                            from dwd_institution
                                 join dwd_institution dwd_institution2 on dwd_institution.posting_institution_id = dwd_institution2.id
                            where dwd_institution.record_state = 'A'
                            ) inst
                      start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                                      from dual
                                                      connect by regexp_substr(:ORG , '[^,]+', 1, level) is not null
                                                      )
                      connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id and level <= 2
   ),
oper_types as
(select /*+ no_merge materialize */
       operation_type_id
   from v_dwr_operation_type
  where class_code = 'BASE_REPORTS'
    and type_code  = 'TURNOVERS'
    and code       = 'INTEREST'
   ),
ytd1 as (select /*+ no_merge materialize index(l dws_contract_oper_inst_idx) */
                   l.contract_idt,
                   sum(l.amount * (-1)) as interest_amount
             from dws_contract_operation l
             join institutions inst on l.institution_id = inst.institution_id
            where l.banking_date in (select /*+ no_merge materialize */
                                            distinct last_day(banking_date) as report_date
                                       from dwd_banking_date d
                                      where d.banking_date < TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
                                        and d.banking_date >= trunc(TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY'),'yy'))
              and l.type_code      = 'YTD_TURNOVERS'
              and l.value_code     = 'INTEREST'
         group by l.contract_idt
   ),
ytd2 as (select /*+ no_merge materialize use_hash(t op) index(e dwf_account_entry_inst_idx) */
                t.contract_idt,
                sum(debit) as interest_amount
           from dwf_account_entry t
            join institutions inst on t.institution_id = inst.institution_id
           join oper_types op
             on op.operation_type_id = t.operation_type_id
            and t.banking_date      >= trunc(TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY'),'mm')
            and last_day(TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')) <> TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
       group by t.contract_idt
   ),
products as
(select /*+ no_merge materialize */
        p.product_id,
        p.code,
        p.name,
        p.product_name,
        p.add_info --[+]211019.3 = shalini = ALMAS-133
   from v_dwr_product p
   join institutions i
     on i.code       = substr(p.code,5,3)
  where p.class_code = 'BASE_REPORTS'
    and p.type_code  = 'LOGO'
   ),
part_1 as
(select /*+ no_merge materialize ordered*/
        c.record_idt,
        da.code
    from dwd_contract c
    join institutions i
      on i.institution_id = c.institution_id
    join products p
      on c.product_id     = p.product_id
     and nvl(sy_convert.get_tag_value(p.add_info,'CORP_PROD'),'N')='Y' --[+]211019.3 = shalini = ALMAS-133
    --[-]begin 211019.3 = shalini = ALMAS-133
    /*join opt_v_suppl_group ag
      on nvl(instr(ag.name,substr(p.code,1,3)),0) > 0
     and ag.type_code     = i.code||'_CORP_PRODUCT_CAT' /* 20211011 - ALMAS-133 - 002*/
     --[-]end 211019.3 = shalini = ALMAS-133
    join dwa_contract_attribute dca
      on c.record_idt     = dca.contract_idt
    join dwd_attribute da
      on dca.attr_id      = da.id
     and da.type_code     = 'NIC_USER_ACC_LEVEL'
     and da.record_state  = 'A'
   where dca.attr_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
     and dca.attr_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
     and c.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
     and c.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')),
part_2 as
(select roots.record_idt as user_acct from
   (select distinct c.record_idt,
                    level as rn,
                    connect_by_root(c.record_idt) as root_record
           From dwd_contract c
           join institutions i
             on i.institution_id    = c.institution_id
      left join part_1 b
             on c.record_idt        = b.record_idt
            and c.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
            and c.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
     start with c.record_idt          = b.record_idt
     connect by c.parent_contract_idt = prior c.record_idt) roots
     join part_1 childs
       on roots.root_record = childs.record_idt
      and roots.rn          = childs.code),
contracts as
 (select /*+ no_merge materialize ordered use_nl(i) index(c dwd_contract_inst_idx)*/
        c.record_idt,
        c.personal_account,
        c.product_id,
        i.code as org_code,
        upper(i.name) as org_name,
        c.add_info,
        c.client_idt
        --[+]begin 20230425.1 = Santosh = NICORE-429:005 - Added base_currency and parent_contract_number
       ,c.base_currency
       ,c.parent_contract_idt
       --[+]end 20230425.1 = Santosh = NICORE-429:005 - Added base_currency and parent_contract_number
   from dwd_contract c
   join institutions i
     on i.institution_id = c.institution_id
   join products p
     on p.product_id     = c.product_id
    and nvl(sy_convert.get_tag_value(p.add_info,'CORP_PROD'),'N')='N' --[+]211019.3 = shalini = ALMAS-133
   --[-]begin 211019.3 = shalini = ALMAS-133
   /*join opt_v_suppl_group ag
     on nvl(instr(ag.name,substr(p.code,1,3)),0) = 0
    and ag.type_code        = i.code||'_CORP_PRODUCT_CAT' /* 20211011 - ALMAS-133 - 002*/
    --[-]end 211019.3 = shalini = ALMAS-133
  where c.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
    and c.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
union
   select /*+ no_merge materialize ordered use_nl(i) index(c dwd_contract_inst_idx)*/
         c.record_idt,
         c.personal_account,
         c.product_id,
         i.code as org_code,
         upper(i.name) as org_name,
         c.add_info,
         c.client_idt
         --[+]begin 20230425.1 = Santosh = NICORE-429:005 - Added base_currency and parent_contract_number
        ,c.base_currency
        ,c.parent_contract_idt
        --[+]end 20230425.1 = Santosh = NICORE-429:005 - Added base_currency and parent_contract_number
    from dwd_contract c
    join institutions i
      on i.institution_id    = c.institution_id
    join part_2 cc
      on cc.user_acct        = c.record_idt
   where c.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
     and c.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')),
account_groups as
(select /*+ no_merge materialize */
       account_group_id,
       type_code,
       ledger_category
  from v_dwr_account_group
 where class_code = 'BALANCE_TYPE'
   and type_code in ('TOTAL_BALANCE','TOTAL_DUE')
   ),
balances as (
select /*+ no_merge ordered full(ab) use_hash(ab c) use_hash(ab dwr) */
       sum(case when dwr.type_code = 'TOTAL_BALANCE' then ab.balance * dwr.ledger_category end) as total_balance,
       sum(case when dwr.type_code = 'TOTAL_DUE'     then ab.balance * dwr.ledger_category end) as total_due,
       c.record_idt
  from dwf_account_balance ab
  join contracts c
    on c.record_idt        = ab.contract_idt
  join account_groups dwr
    on ab.account_group_id = dwr.account_group_id
 join institutions inst on ab.institution_id = inst.institution_id
 where banking_date        = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
group by c.record_idt
   ),
limits as
   (select  /*+ no_merge materialize index(l dwf_limit_inst_idx) */
        l.contract_idt,
        sum(case when l.type_code in ('AVAILABLE','LINKED_ACC_AVAILABLE') then l.amount  end ) as open_to_buy, --[*]20230523.1 = Santosh = NICORE-429:008 - Change for Available balance for multi currency
        max(case when l.type_code = 'FIN_LIMIT' then l.amount  end ) as credit_limit
   from dwf_contract_limit l
    join institutions inst on l.institution_id = inst.institution_id
  where l.type_code      in ('AVAILABLE','FIN_LIMIT','LINKED_ACC_AVAILABLE')--[*]20230523.1 = Santosh = NICORE-429:008 - Change for Available balance for multi currency
    and l.banking_date    = to_date(:P_REPORT_DATE,'DD-MM-YYYY')
  group by l.contract_idt
  ),
billing as
  (select /*+ no_merge materialize*/
         contract_idt,
         max(due_date) due_date,
         max(case when rn=1 then billing_date end) as billing_date
    from
    (select /*+ use_nl(inst) index(dcb dwf_cntr_bill_inst_idx) */
          dcb.contract_idt,
          dcb.due_date,
          dcb.billing_date,
          row_number() over(partition by contract_idt order by due_date desc) rn
     from dwf_contract_billing dcb
     join institutions inst
       on inst.institution_id    = dcb.institution_id
    where dcb.billing_date      >= add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'), -2)
      and dcb.period_start_date <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
    )
  where rn = 1
  group by contract_idt
  )
--[+]begin 20230512.1 = Santosh = NICORE-429:006 - Added default account status  
 ,dflt_attr as 
 (select /*+ no_merge */
                 max(da.code) as def_st
            from dwd_attribute  da
            left join dwa_contract_attribute dca
              on da.id               = dca.attr_id
           where da.type_code       ='BFA_ACCOUNT_STATUS'
             and da.used_as_default = 'Y'
             and da.record_state = 'A'
 )
 --[+]end 20230512.1 = Santosh = NICORE-429:006 - Added default account status  
 --[+]begin 20230517.1 = Santosh = NICORE-429:007 - change to pull expiry date for all multicurrency contracts
 ,cards as (select /*+ no_merge index(cd dwd_card_inst_idx) use_nl(i) */
                    max(card.expiry_date) as expiry_date,
                    card.main_contract_idt
               from dwd_card card
               join institutions i
                 on i.institution_id       = card.institution_id
              where card.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
                and card.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
           group by card.main_contract_idt
           union all
           select /*+ no_merge index(cd dwd_card_inst_idx) use_nl(i) */
                    max(card.expiry_date) as expiry_date,
                    cr.contract_idt as main_contract_idt
               from dwd_card card
               join institutions i
                 on i.institution_id       = card.institution_id
               join dwa_card_relation cr on cr.card_idt = card.record_idt 
               and cr.active_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
                and cr.active_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
              where card.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
                and card.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
           group by cr.contract_idt
              )
--[+]end 20230517.1 = Santosh = NICORE-429:007 - change to pull expiry date for all multicurrency contracts
    select
          org_code "ORG",
          account_number "ACCOUNT NUMBER",
          short_name "SHORT NAME",
          to_char(expr, 'yymm') "EXPIRY DATE",
          to_char(cy, 'dd') "BILLING DATE",
          st "ACCOUNT STATUS",
          cd "DELINQUENCY LEVEL",
          decode(b1,'_',null,b1 ) "BLOCK CODE 1",
          decode(b2,'_',null,b2 ) "BLOCK CODE 2",
          nvl(curr_balance,0)*-1 "CURRENT BALANCE",
          nvl(credit_limit,0) "CREDIT LIMIT",
          nvl(open_to_buy ,0) "OPEN TO BUY",
          nvl(ytd_interest,0) "YTD INTEREST",
          nvl(tot_amt_due,0)*-1 "TOTAL AMOUNT DUE",
          to_char(due_date,'dd/mm/yy') "DUE DATE",
          to_char(txn_date,'dd/mm/yy') "LAST ACTIVITY DATE"
         --[+]begin 20230425.1 = Santosh = NICORE-429:005 - Added base_currency and parent_contract_number 
         ,base_currency as "ACCOUNT CURRENCY"
         ,parent_contract_number as "MAIN CONTRACT"
         --[+]end 20230425.1 = Santosh = NICORE-429:005 - Added base_currency and parent_contract_number
from
( select /*+ use_hash(con clt) use_hash(con cards) use_hash(con limits) use_hash(con attr) use_hash(con balances) use_hash(con bill) use_hash(con ytd2) use_hash(con ytd1) index(clt dwd_client_inst_idx)*/
        con.org_code,
        con.org_name,
        p.code as logo_code,
        p.name logo_name,
        con.personal_account as account_number,
        replace(clt.short_name,chr(49825),'') as short_name,
        bill.billing_date cy,
        bill.due_date,
        nvl(attr.st,df.def_st) as st, --[*]begin 20230512.1 = Santosh = NICORE-429:006 - Added default account status  
        attr.cd,
        '' as rc,
        null as store_id,
        limits.credit_limit,
        limits.open_to_buy,
        nvl(ytd1.interest_amount,0) + nvl(ytd2.interest_amount,0) as ytd_interest,
        cards.expiry_date as expr,
        '' as i_c,
        '' as cc ,
        attr.b1,
        attr.b2,
        balances.total_balance as curr_balance,
        balances.total_due as tot_amt_due,
        to_date(sy_convert.get_tag_value (con.add_info,'ACTIVITY_DATE'),'YYYY-MM-DD') txn_date
       --[+]begin 20230425.1 = Santosh = NICORE-429:005 - Added base_currency and parent_contract_number
       ,con.base_currency
       ,pc.personal_account as parent_contract_number
       --[+]end 20230425.1 = Santosh = NICORE-429:005 - Added base_currency and parent_contract_number
  from contracts con

  join products p
    on p.product_id = con.product_id

  --[+]begin 20230425.1 = Santosh = NICORE-429:005 - Added base_currency and parent_contract_number
    left join dwd_contract pc
        on con.parent_contract_idt  = pc.record_idt
       and pc.record_date_from   <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
       and pc.record_date_to     >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    --[+]end 20230425.1 = Santosh = NICORE-429:005 - Added base_currency and parent_contract_number
           
  left join dwd_client clt
    on clt.record_idt        = con.client_idt
   and clt.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
   and clt.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')

  left join dwa_card_relation cr on cr.contract_idt = con.record_idt
  left join  cards on cards.main_contract_idt = con.record_idt --[*]begin 20230517.1 = Santosh = NICORE-429:007 - change to pull expiry date for all multicurrency contracts
  left join limits on limits.contract_idt = con.record_idt

  left join balances
  on balances.record_idt = con.record_idt

  left join (select /*+ no_merge use_hash(dca da)*/
                 dca.contract_idt,
                 max(case when da.type_code like 'BLOCK_CODE_ACC1_%'    then da.code else null end) as b1,
                 max(case when da.type_code like 'BLOCK_CODE_ACC2_%'    then da.code else null end) as b2,
                 max(case when da.type_code = 'BFA_ACCOUNT_STATUS'      then da.code else null end) as st,
                 max(case when da.type_code = 'DLQ_LEVEL'               then da.code else null end) as cd
            from dwa_contract_attribute dca
            join institutions inst on 1=1
            join dwd_attribute da
              on da.id               = dca.attr_id
             and da.type_code       in ('BLOCK_CODE_ACC1_'||inst.code, 'BLOCK_CODE_ACC2_'||inst.code,'DLQ_LEVEL','BFA_ACCOUNT_STATUS')
           where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')
             and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')
        group by dca.contract_idt
            ) attr
      on attr.contract_idt = con.record_idt

  left join dflt_attr df on 1=1 --[+]begin 20230512.1 = Santosh = NICORE-429:006 - Added default account status  
  
  left join billing bill
    on bill.contract_idt = con.record_idt

  left join ytd1
    on ytd1.contract_idt = con.record_idt

  left join ytd2
    on ytd2.contract_idt = con.record_idt

  where p.code is not null

) order by logo_code