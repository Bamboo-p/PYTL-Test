''' NIC

The pytl job validates/converts JSON source file with UAE DDS customer info inside to WAY4 XML format

Requirements
------------
    pytl-core>=0.1.2

Parameters
----------
ENV
    Specifies path to settings file with database connection and in/out/etc dirs paths.
    Can be an absolute or relative path, or a file name without extension.

ORG
    Parameter that is used in several XML tags like Sender as Financial institution.
    ORG _MUST_ be 3 characters length
    Sample: 982

Optional parameters
-------------------
OUTPUT_FN_SEPARATOR
    By default '_'
OUTPUT_FN_PREFIX
    File name prefix of the output WAY4 XML files: {OUTPUT_FN_PREFIX}{ORG>06}{OUTPUT_FN_SEPARATOR}{seq>05}.{jjj}
    Sample: "nicapp_" from "nicapp_000320_00169.271"
    By default: "nicapp_"
OUTPUT_FN2_PREFIX
    File name prefix of the output reject files: {OUTPUT_FN2_PREFIX}DDMMYYYYHHMMSS{OUTPUT_FN2_EXTENSION}{OUTPUT_FN_SEPARATOR}{seq>03}{OUTPUT_FN2_EXTENSION}
    Sample: "NIC_UAE_DDS_FILE_" from "NIC_UAE_DDS_FILE_28092021090845_172.txt"
    By default: "NIC_UAE_DDS_FILE"
OUTPUT_FN2_EXTENSION
    Sample: ".txt" from "NIC_UAE_DDS_FILE_28092021090845_172.txt"
    By default: ".txt"
INPUT_FN_PREFIX
    File name prefix of the input JSON files
    By default "CCB"
INPUT_FN_EXTENSION
    File extenstion of the input JSON files
    By default: ".json"
    
References
----------
    ENG-3253

Changes
-------
    210928.1 = deniska = ENG-3253: Rewritten for unification, according to discussion with TatianaO/MaximS 20/09/2021, PavelP 22/09/2021, TatianaO 28/09/2021:
                         Fixed according to Tatiana Ovseannikova added a comment - 16/Sep/21 12:10 PM: 
                         * Sender should be filler as '000' || ORG
                            Output WAY4 XML file //ApplicationFile/FileHeader/Sender = '000' + ORG
                         * file name of output XML file for boarding should start with apboard (e.g. apboard000982_00320.300) and for UAEDDS - uaedds_ (e.g. uaedds_000982_00320.300)
                            Output WAY4 XML filename = {OUTPUT_FN_PREFIX}{ORG left padded with '0' for 6 characters}{OUTPUT_FN_SEPARATOR}{sequence left padded with '0' for 5 characters}.{jjj}
                         * Provide ability to change file prefixes from bat file
                             Optional parameter INPUT_FN renamed into INPUT_FN_PREFIX.      Default value: "CCB"
                             Optional parameter OUTPUT_FN renamed into OUTPUT_FN_PREFIX.    Default value: "nicapp_"
                             Optional parameter OUTPUT_FN2 renamed into OUTPUT_FN2_PREFIX.  Default value: "NIC_UAE_DDS_FILE"
                             
                         Fixed issues - crash with exception raising if:
                         * incorrect format of incoming JSON file: impossible to parse
                         * incorrect incoming JSON file: node //Customers was not found
                         * incorrect incoming JSON file: node //Customers/Customer was not found
    220512.3 = deniska = PRD-20670: the names of used tables are renamed from old Talend naming convention into new PyTL.
'''
# [+][begin] 210928.1 = deniska = ENG-3253
__params__ = {
## Mandatory
        "ENV":                      lambda: config["ENV"],              # D:\PYTL\NIC\JOBNAME\W4UAT25.PARM
# f"{config['ORG'].rjust(6, '0')}_" \
        "ORG":                      lambda: config["ORG"],              # XXX
## Optional
        "OUTPUT_FN_SEPARATOR":      lambda: "_" if not (__OUTPUT_FN_SEPARATOR := config.get("OUTPUT_FN_SEPARATOR")) else (__OUTPUT_FN_SEPARATOR if __OUTPUT_FN_SEPARATOR != '.' else ""),
# way4_file_name = f"{config.get('OUTPUT_FN', 'nicapp_')}" \
        "OUTPUT_FN_PREFIX":         lambda: "nicapp_" if not (__OUTPUT_FN_PREFIX := config.get("OUTPUT_FN_PREFIX")) else (__OUTPUT_FN_PREFIX if __OUTPUT_FN_PREFIX != '.' else ""),
# reject_file_name = f"{config.get('OUTPUT_FN2', 'NIC_UAE_DDS_FILE')}_" \
        "OUTPUT_FN2_PREFIX":        lambda: "NIC_UAE_DDS_FILE" if not (__OUTPUT_FN2_PREFIX := config.get("OUTPUT_FN2_PREFIX")) else (__OUTPUT_FN2_PREFIX if __OUTPUT_FN2_PREFIX != '.' else ""),
        "OUTPUT_FN2_EXTENSION":     lambda: ".txt" if not (__OUTPUT_FN2_EXTENSION := config.get("OUTPUT_FN2_EXTENSION")) else (__OUTPUT_FN2_EXTENSION if __OUTPUT_FN2_EXTENSION != '.' else ""),
# input_file_mask = config.get('INPUT_FN', 'CCB') + '*.json'
        "INPUT_FN_PREFIX":          lambda: "CCB" if not (__INPUT_FN_PREFIX := config.get("INPUT_FN_PREFIX")) else (__INPUT_FN_PREFIX if __INPUT_FN_PREFIX != '.' else ""),
        "INPUT_FN_EXTENSION":       lambda: ".json" if not (__INPUT_FN_EXTENSION := config.get("INPUT_FN_EXTENSION")) else (__INPUT_FN_EXTENSION if __INPUT_FN_EXTENSION != '.' else ""),
## Parameters from file config["ENV"]
# connection_string = config['DB_STG_SRC_WLTURL']  # must be available in PARM file
        "DB_STG_SRC_WLTURL":        lambda: config["DB_STG_SRC_WLTURL"],
## Precalculated values
# template = upload_jinja2_template(Path(config['TEMPLATES_DIR']) / 'APP.txt')
        "TEMPLATES_DIR":            lambda: config["TEMPLATES_DIR"],
# inputs = list(Path(config['SRC_DIR']).glob(input_file_mask))
        "SRC_DIR":                  lambda: config["SRC_DIR"],
# reject_file_path = Path(config['DST_DIR']) / reject_file_name
        "DST_DIR":                  lambda: config["DST_DIR"],
# way4_file_path = Path(config['W4C_IN_DIR']) / way4_file_name
        "W4C_IN_DIR":               lambda: config["W4C_IN_DIR"],
# # config['OUTPUT_FILES'].update({'way4_file' : way4_file_path})
# # config.setdefault('DST_FILES', []).append(reject_report)  # not used any more
}

try:
    # Could be imported ONLY if it's run as module
    from . import __job_name__
except:
    # Could be imported ONLY if it's run as normal py
    from __init__ import __job_name__

import os
# from pytl_core import *
from pytl_core.config import Config
import logging
from pathlib import Path
from jinja2 import Template
from pytl_core.oracle_db import OracleDB
import json
import csv
from pytl_core import utils
# [+][end]   210928.1 = deniska = ENG-3253
'''
# [-][begin] 210928.1 = deniska = ENG-3253
from pytl_core.job_launcher import *
job_launcher(config)  # reassign control
# [-][end]   210928.1 = deniska = ENG-3253
'''

# Declare job specific function
def upload_jinja2_template(file):
    """
    Upload Jinja2 template from the local file

    :param str file: filepath of Jinja2 template
    :return: Jinja2 template
    :rtype: jinja2.environment.Template
    """
    try:
        with open(file, 'r') as temp_file:
            temp = Template(temp_file.read())
        logging.debug(f"Jinja2 template has been uploaded from {file}")
        return temp
    except Exception as e:
        raise e


# [+][begin] 210928.1 = deniska = ENG-3253
from pytl_core.timestamp import Timestamp as timestamp
# [+][end]   210928.1 = deniska = ENG-3253

def generate_regnumber(prefix='NICE', time=timestamp('%Y%m%d'), seq=''):
    """
    Generate unique id for the every RegNumber tag in WAY4 XML file

    :param str prefix: prefix for regnumber value
    :param str datetime: timestamp
    :param str seq: processed input JSON file identifier
    :return: new unique regnumber
    :rtype: str
    """
    return f"{prefix}" \
           f"{time}" \
           f"{seq.rjust(5, '0')}_" \
           f"{utils.Sequence.get_next_seq_number('reg', 1, 1)}"


def validation(contract_number, dds_number, dd_flag, dd_num, dd_day):
    """
    Validation procedure for all records in the input Json file

    :param str contract_number: contract_number value
    :param str dds_number: dds_number value
    :param str dd_flag: dd_flag value
    :param str dd_num: dd_num value
    :param str dd_day: dd_day value
    :return: string message contains errors if they present else empty
    :rtype: str
    """
    is_contract = True if utils.string_not_empty(contract_number) \
                          and contract_number.isdigit() else False
                          # and re.match('^[a-zA-Z0-9]+$', contract_number) else False
    is_dds_num = True if utils.string_not_empty(dds_number) and dds_number.isdigit() else False
    is_flag = True if utils.string_not_empty(dd_flag) and dd_flag.upper() in ['C', 'R'] else False
    is_dd_num = True if not utils.string_not_empty(dd_flag) or dd_flag.upper() != 'R' or \
                        (utils.string_not_empty(dd_num) and dd_num.isdigit()) else False
    is_dd_day = True if not utils.string_not_empty(dd_flag) or dd_flag.upper() != 'R' or \
                        (utils.string_not_empty(dd_day) and dd_day.isdigit() and int(dd_day) >= 1 and
                         int(dd_day) <= 31) else False
    result = ("" if is_contract else "CONTRACT NUMBER IS NOT ALPHANUMERIC;") \
             + ("" if is_dds_num else "DDS NUMBER IS NOT NUMERIC;") \
             + ("" if is_flag else "INVALID R/C FLAG;") \
             + ("" if is_dd_num else "DD ACCOUNT NUMBER IS NOT NUMERIC;") \
             + ("" if is_dd_day else "INVALID DD DAY;")
    return result


def create_xml_file(file_name, structure):
    """
    WAY4 XML file creation using Jinja2 template

    :param str file_name: filepath for WAY4 XML file
    :param str structure: render jinja template
    """
    try:
        Path(file_name).parent.mkdir(parents=True, exist_ok=True)
        with open(file_name, 'w') as doc:
            doc.write(structure)
            # doc.write(et.tostring(structure, encoding='ISO-8859-15', xml_declaration=True, pretty_print=True))
            logging.info(f"WAY4 XML file is created {file_name}")
    except Exception as e:
        raise e


def create_report(file_name, records, delimiter='|'):
    """
    Create UAE DDS job specific report for full reject only

    :param str file_name: filepath for delimited report
    :param list of dict records: dataset
    :param str delimiter: delimiter
    """

    report = []
    action = {'R': 'REGISTRATION', 'C': 'CANCELLATION'}  # full names instead of R/C
    summary = {'SUCCESS': 0, 'REJECT': 0}  # summary dict

    # Need to redefine dict since not all fields are required in the report
    # Moreover we can change the order compared to how records is in XML, DB
    for record in records:
        new_dict = {k: (action.get(v, v)
                        if k == 'dd_flag' else v)
                    for k, v in record.items()
                    if k in ['dd_flag', 'contract_number', 'dd_num', 'dds_number', 'dd_day']}
        status = "SUCCESS" if record.get('error_type') != "REJECT" else "REJECT"
        summary[status] = summary.get(status) + 1
        new_dict['status'] = status
        err_msg = record.get('error_msg')

        # Every reject reason should be displayed on a separate line: error1;error2;error3
        if ';' in err_msg:
            for msg in list(filter(None, err_msg.split(';'))):
                temp = new_dict.copy()
                temp['reason'] = msg
                report.append(temp)
        else:
            new_dict['reason'] = err_msg
            report.append(new_dict)  # only one error message
    eol = '\r\n'  # windows End Of File
    summary_part = f"{eol * 2}" \
                   f"TOTAL NUMBER OF RECORDS UPLOADED  : {summary['SUCCESS']}{eol}" \
                   f"TOTAL NUMBER OF RECORDS REJECTED  : {summary['REJECT']}{eol}" \
                   f"TOTAL NUMBER OF RECORDS PROCESSED : {summary['SUCCESS'] + summary['REJECT']}{eol}"
    # Create delimited report
    try:
        Path(file_name).parent.mkdir(parents=True, exist_ok=True)
        header = ['ACTION', 'CONTRACT NUMBER', 'DD ACCOUNT NUMBER', 'UAE DDS NUMBER', 'DD DAY', 'STATUS', 'REASON']
        # Header may the differ from the key names, contains more than one line
        with open(file_name, 'w+', newline='') as report_file:
            report_file.write(delimiter.join(header))
            report_file.write(eol)
            writer = csv.DictWriter(report_file, fieldnames=report[0].keys(), delimiter=delimiter)
            writer.writerows(report)
            report_file.write(summary_part)
            logging.info(f"Append {len(report)} records to {file_name}")
    except Exception as e:
        raise e

# [+][begin] 210928.1 = deniska = ENG-3253
def main_in(_config):
    global config
    config = _config

# [+][end]   210928.1 = deniska = ENG-3253

    # Declare common variables, upload jinja2 template, open DB connection for STG_ETL schema
    input_file_mask = __params__['INPUT_FN_PREFIX']() + "*" + __params__['INPUT_FN_EXTENSION']()
    # current_timestamp = timestamp()
    template = upload_jinja2_template(Path(__params__['TEMPLATES_DIR']()) / 'APP.txt')
    template.globals['generate_regnumber'] = generate_regnumber
    template.globals['timestamp'] = timestamp
    # sql_new_sequence = f"select PyTL_JOB_SUPPORT.getSequenceValue('{__params__['JOB_NAME']()}', 'file_name') SEQUENCE_NUMBER from dual"
    # Re using Talend jobs name convention
    sql_new_sequence = f"select PyTL_JOB_SUPPORT.getSequenceValue('{__job_name__}', 'file_name') SEQUENCE_NUMBER from dual"
    connection_string = __params__['DB_STG_SRC_WLTURL']()  # must be available in PARM file
    stg_connection = OracleDB(connection_string)

    # Fetch corresponding output job names, multiple out jobs possible
    sql_out_job_name = f"select OUT_JOB_ID as value " \
                       f"from PyTL_JOB_RELATIONS " \
                       f"where IN_JOB_ID = '{__job_name__}'"
    out_job_names = [d['VALUE'] for d in stg_connection.select(statement=sql_out_job_name)]

    # Iterate by source Json files in the job_name/Input/
    inputs = list(Path(__params__['SRC_DIR']()).glob(input_file_mask))
    if len(inputs) == 0: logging.info(f"No input files found for mask {input_file_mask}")
    for path in inputs:
        # Get sequence number, the unique input file identifier
        # Declare service variables: output file names (XML, reject text report)
        logging.info(120 * '=')
        rows_generator = stg_connection.select(sql_new_sequence)
        seq_number = [d['SEQUENCE_NUMBER'] for d in rows_generator][0]
        # [*][begin] 210928.1 = deniska = ENG-3253
        way4_file_name = f"{__params__['OUTPUT_FN_PREFIX']()}" \
                         f"{__params__['ORG']().rjust(6, '0')}_" \
                         f"{seq_number.rjust(5, '0')}." \
                         f"{timestamp('%j').rjust(3, '0')}" \
                         
                         # + "=" + os.path.split(path)[1]
        # [*][end]   210928.1 = deniska = ENG-3253
        way4_file_path = Path(__params__['W4C_IN_DIR']()) / way4_file_name
        reject_file_name = f"{__params__['OUTPUT_FN2_PREFIX']()}_" \
                           f"{timestamp('%d%m%Y%H%M%S')}_" \
                           f"{seq_number}" \
                           f"{__params__['OUTPUT_FN2_EXTENSION']()}" \
                           
                           # + "=" + way4_file_name + "=" + os.path.split(path)[1]
        reject_file_path = Path(__params__['DST_DIR']()) / reject_file_name
        # __params__['OUTPUT_FILES']().update({'way4_file' : way4_file_path})
        # __params__['OUTPUT_FILES']().update({'reject_file': reject_file_path})

        # [+][begin] 210928.1 = deniska = ENG-3253
        try:
            customers = utils.read_json(path)['customers']
        except json.decoder.JSONDecodeError as ex:
            logging.warning(f"Incorrect JSON format of '{path}'. Processing of the file is skipped.")
            continue
        except KeyError as ex:
            logging.warning(f"No '//Customers' node found in '{path}'. Processing of the file is skipped.")
            continue
        # [+][end]   210928.1 = deniska = ENG-3253

        # Parsing Json file, apply the validation procedure to each record
        records = []
        # [*][begin] 210928.1 = deniska = ENG-3253
        for customer in customers:
        # [*][begin] 210928.1 = deniska = ENG-3253
            temp_dict = {}
            dd_parms = customer.get('directdebitparameters', {})
            temp_dict["dd_flag"] = dd_parms.get('dd_flag', '')
            temp_dict["contract_number"] = customer.get('contractnumber', '')
            temp_dict["dd_num"] = dd_parms.get('dd_num', '')
            temp_dict["dds_number"] = customer.get('ddsnumber', '')
            temp_dict["dd_day"] = dd_parms.get('dd_day', '')
            temp_dict["error_msg"] = validation(temp_dict['contract_number'],
                                                temp_dict['dds_number'],
                                                temp_dict['dd_flag'],
                                                temp_dict['dd_num'],
                                                temp_dict['dd_day'])
            temp_dict["error_type"] = "REJECT" if len(temp_dict["error_msg"]) > 0 else ""
            temp_dict["app_number"] = seq_number
            temp_dict["reg_number"] = generate_regnumber(seq=seq_number)
            records.append(temp_dict)

        # [+][begin] 210928.1 = deniska = ENG-3253
        if not records:
            logging.warning(f"No one 'customer' record found in {path}. Processing of the file is skipped.")
            continue
        # [+][end]   210928.1 = deniska = ENG-3253

        # Save records into the STG, filter only valid
        stg_connection.execute_insert_batch(table_name='PyTL_IS_UAE_DDS_File', data=records, commit=True)
        valid_records = list(filter(lambda d: d['error_type'] != "REJECT", records))

        # Create WAY4 XML file if valid records are available in the processed Json file
        if len(valid_records) > 0:
            logging.info(f"{len(valid_records)} records will be extracted into XML file")
            # Define service fields for building XML structure or reject report
            valid_records_upd = [dict(d, **{'is_registration':
                                                (utils.string_not_empty(d["dd_flag"])
                                                 and (d["dd_flag"].upper() == 'R'))
                                            })
                                 for d in valid_records]
            create_xml_file(way4_file_path,
                            template.render(org=__params__['ORG'](),
                                            seq_number=seq_number,
                                            records=valid_records_upd))
        else:
            logging.info(f"All records have been rejected by Python for {path}")
            create_report(file_name=reject_file_path, records=records)
            # close processed sequence number due to full reject
            for out_job_name in out_job_names:
                stg_connection.execute_stored_procedure('PyTL_JOB_SUPPORT.setSeqValueUsed',
                                                        bind_vars={'p_job_id': out_job_name,
                                                                   'p_seq_value': seq_number,
                                                                   'p_mode': 'mark'})
                # config.setdefault('DST_FILES', []).append(reject_report)  # not used any more

        utils.delete_file(path)

    stg_connection.close()

