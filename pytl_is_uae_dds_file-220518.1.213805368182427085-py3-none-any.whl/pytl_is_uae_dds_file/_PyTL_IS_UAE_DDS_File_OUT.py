""" NIC

The pytl job converts WAY4 XML response file to delimited text report

Requirements
------------
    pytl-core>=0.1.2

Parameters
----------
ENV : string
    Specifies path to settings file with database connection and in/out/etc dirs paths.
    Can be an absolute or relative path, or a file name without extension.

ORG : string
    Parameter that is used in several XML tags like Sender as Financial institution.
    ORG _MUST_ be 3 characters length
    Sample: 982

Optional parameters
-------------------
INPUT_FN_PREFIX
    File name prefix of the output WAY4 files: {INTPUT_FN_PREFIX}{ORG>03}_{seq>05}.{jjj}
    Sample: "RXADVAPL000" from "RXADVAPL000320_00087.300"
    By default: "RXADVAPLDDR"

INPUT_FN_EXTENSION
    Sample: ".300" from "RXADVAPL000320_00087.300"
    By default: ".*"

OUTPUT_FN_PREFIX
    File name prefix of the output files: {OUTPUT_FN_PREFIX}_DDMMYYYYHHMMSS_{seq}.{jjj}
    Sample: "NIC_UAE_DDS_FILE" from "NIC_UAE_DDS_FILE_31102021002407_87.txt"
    By default: "NIC_UAE_DDS_FILE"

OUTPUT_FN_EXTENSION
    Sample: ".txt" from "NIC_UAE_DDS_FILE_31102021002407_87.txt"
    By default: ".txt"

Legacy parameters
-----------------
INPUT_FN
    Same as INPUT_FN_PREFIX
OUTPUT_FN
    Same as OUTPUT_FN_PREFIX

References
----------
    ENG-3253

Changes
-------
    211028.1 = sergeimi = ALMAS-107: Rewritten for unification
    220512.3 = deniska = PRD-20670: the names of used tables are renamed from old Talend naming convention into new PyTL.
    220512.4 = deniska = PRD-20670: added ability to:
                                        process files with correct names, but incorrect content
                                        process already processed files = added optional parameter APPLICATIONS
"""
# [+][begin]    211028.1 = sergeimi = ALMAS-107
__params__ = {
## Mandatory
        "ENV":                      lambda: config["ENV"],              # Example: D:\PYTL\NIC\JOBNAME\W4UAT32.PARM
# config.get("ORG", "982") + \
        "ORG":                      lambda: config["ORG"],              # XXX
# connection_string = config['DB_STG_SRC_WLTURL']  # must be available in PARM file
        "DB_STG_SRC_WLTURL":        lambda: config["DB_STG_SRC_WLTURL"],

#input_file_mask = config.get("INPUT_FN", "RXADVAPLDDR") + \
        "INPUT_FN_PREFIX":          lambda: "RXADVAPLDDR" if not (__INPUT_FN_PREFIX := config.get("INPUT_FN_PREFIX")) and not (__INPUT_FN := config.get("INPUT_FN")) else (__INPUT_FN_PREFIX if not (__INPUT_FN := config.get("INPUT_FN")) else __INPUT_FN),
        "INPUT_FN_EXTENSION":       lambda: ".*" if not (__INPUT_FN_EXTENSION := config.get("INPUT_FN_EXTENSION")) else __INPUT_FN_EXTENSION,

# inputs = list(Path(config['W4C_OUT_DIR']).glob(input_file_mask))
        "W4C_OUT_DIR":               lambda: config["W4C_OUT_DIR"],

# report_file_name = f"{config.get('OUTPUT_FN', 'NIC_UAE_DDS_FILE')}_" \
        "OUTPUT_FN_PREFIX":         lambda: "NIC_UAE_DDS_FILE" if not (__OUTPUT_FN_PREFIX := config.get("OUTPUT_FN_PREFIX")) and not (__OUTPUT_FN := config.get("OUTPUT_FN")) else (__OUTPUT_FN_PREFIX if not (__OUTPUT_FN := config.get("OUTPUT_FN")) else __OUTPUT_FN),
        "OUTPUT_FN_EXTENSION":      lambda: ".txt" if not (__OUTPUT_FN_EXTENSION := config.get("OUTPUT_FN_EXTENSION")) else __OUTPUT_FN_EXTENSION,

        "APPLICATIONS":             lambda:  config.get("APPLICATIONS", None),  # [+] 220512.4 = deniska = PRD-20670: added possibility to process already processed APPLICATIONS

    # report_file_path = Path(config['DST_DIR']) / report_file_name
        "DST_DIR":                  lambda: config["DST_DIR"]
}
# [+][end] 211028.1 = sergeimi = ALMAS-107

try:
    # Could be imported ONLY if it's run as module
    from . import __job_name__
except:
    # Could be imported ONLY if it's run as normal py
    from __init__ import __job_name__

from pytl_core import timestamp, utils
from pytl_core.config import Config
from pytl_core.oracle_db import OracleDB
import logging
from pathlib import Path
from lxml import etree as et
import csv


#from pytl_core import *
#job_launcher(config)  # reassign control


# Declare job specific function

def read_xml(file):
    """
    Upload XML file into the memory

    :param str file: filepath of XML
    :return: lxml ElementTree object with uploaded file
    :rtype: lxml.etree._Element
    """
    try:
        with open(file, 'rb') as doc:
            data = doc.read()
        logging.info(f"Reading WAY4 XML response file {file}")
        return et.fromstring(data)
    except Exception as e:
        logging.error(e)
        raise e


def create_report(file_name, records, delimiter='|'):
    """
    Create UAE DDS interface specific report

    :param str file_name: filepath for delimited report
    :param list of dict records: dataset
    :param str delimiter: delimiter
    """

    report = []
    action = {'R': 'REGISTRATION', 'C': 'CANCELLATION'}  # full names instead of R/C
    summary = {'SUCCESS': 0, 'REJECT': 0}  # summary dict

    # Need to redefine dict since not all fields are required in the report
    # Moreover we can change the order compared to how records is in XML, DB
    for record in records:
        new_dict = {k: (action.get(v, v)
                        if k == 'DD_FLAG' else v)
                    for k, v in record.items()
                    if k in ['DD_FLAG', 'CONTRACT_NUMBER', 'DD_NUM', 'DDS_NUMBER', 'DD_DAY']}
        err_msg = record.get('ERROR_MSG')
        status = "REJECT" if (err_msg and len(err_msg) > 0) else "SUCCESS"
        summary[status] = summary.get(status) + 1
        new_dict['status'] = status

        # Every reject reason should be displayed on a separate line: error1;error2;error3
        if ';' in err_msg:
            for msg in list(filter(None, err_msg.split(';'))):
                temp = new_dict.copy()
                temp['reason'] = msg
                report.append(temp)
        else:
            new_dict['reason'] = err_msg
            report.append(new_dict)  # only one error message
    eol = '\r\n'  # windows End Of File
    summary_part = f"{eol * 2}" \
                   f"TOTAL NUMBER OF RECORDS UPLOADED  : {summary['SUCCESS']}{eol}" \
                   f"TOTAL NUMBER OF RECORDS REJECTED  : {summary['REJECT']}{eol}" \
                   f"TOTAL NUMBER OF RECORDS PROCESSED : {summary['SUCCESS'] + summary['REJECT']}{eol}"
    # Create delimited report
    try:
        Path(file_name).parent.mkdir(parents=True, exist_ok=True)
        header = ['ACTION', 'CONTRACT NUMBER', 'DD ACCOUNT NUMBER', 'UAE DDS NUMBER', 'DD DAY', 'STATUS', 'REASON']
        # Header may the differ from the key names, contains more than one line
        with open(file_name, 'w+', newline='') as report_file:
            report_file.write(delimiter.join(header))
            report_file.write(eol)
            writer = csv.DictWriter(report_file, fieldnames=report[0].keys(), delimiter=delimiter)
            writer.writerows(report)
            report_file.write(summary_part)
            logging.info(f"Append {len(report)} records to {file_name}")
    except Exception as e:
        raise e


# [+][begin]    211028.1 = sergeimi = ALMAS-107
def main_out(_config):
    global config
    config = _config

# [+][end] 211028.1 = sergeimi = ALMAS-107
    # Declare common variables, open DB connection for STG_ETL schema
    connection_string = __params__['DB_STG_SRC_WLTURL']()  # must be available in PARM file
    stg_connection = OracleDB(connection_string)

    if __params__['APPLICATIONS']():
        logging.info(f"*** DEBUG MODE for {__params__['APPLICATIONS']()=}")
        # Extract numbers of open/closed application {__params__['APPLICATIONS']()} from STG_ETL schema, assosiated with {__job_name__}
        select = f"select CURRENT_SEQUENCE_VALUE as VALUE from PyTL_JOBS_CURRENT_VALUES where OUT_JOB_ID = '{__job_name__}' " \
                 f"and CURRENT_SEQUENCE_VALUE in ({__params__['APPLICATIONS']()})"
    else:
        logging.info(f"*** NORMAL MODE")
        # Extract numbers of open applications from STG_ETL schema, assosiated with {__params__['JOB_NAME']()}
        select = f"select CURRENT_SEQUENCE_VALUE as VALUE from PyTL_TMP_ACTIVE_SEQUENCES_VW where OUT_JOB_ID = '{__job_name__}' " \
                 f"order by CURRENT_SEQUENCE_VALUE"

    open_sequences = [d['VALUE'] for d in stg_connection.select(statement=select)]
    # logging.debug(open_sequences)

    # Iterate by WAY4 response files in the job_name/W4C-Output/ only for open sequence numbers
    for seq_number in open_sequences:
        input_file_mask = __params__['INPUT_FN_PREFIX']() + \
                          __params__['ORG']() + \
                          f"_{seq_number.rjust(5, '0')}" + \
                          __params__['INPUT_FN_EXTENSION']()
        inputs = list(Path(__params__['W4C_OUT_DIR']()).glob(input_file_mask))
        if len(inputs) == 0: logging.info(f"No input files found for mask {input_file_mask}")
        for path in inputs:
            # Declare service variables: output file names (result text report) for the every input
            logging.info(120 * '=')
            report_file_name = f"{__params__['OUTPUT_FN_PREFIX']()}_" \
                               f"{timestamp('%d%m%Y%H%M%S')}_" \
                               f"{seq_number}" + \
                               __params__['OUTPUT_FN_EXTENSION']()
            report_file_path = Path(__params__['DST_DIR']()) / report_file_name
            # config['OUTPUT_FILES'].update({'report_file': report_file_path})

            # Parsing response WAY4 XML file using Xpath
            root = read_xml(path)
            xml_records = []
            for doc in root.xpath('/ApplicationResponseFile/NotificationsList/Notification'):
                temp_dict = {}
                temp_dict["REG_NUMBER"] = doc.xpath('RegNumber/text()')[0]
                resp_code = doc.xpath('Application/Status/RespCode/text()')[0]
                resp_text = doc.xpath('Application/Status/RespText/text()')[0]
                result = (resp_code == '0')
                # temp_dict['ERROR_TYPE'] = "SUCCESS" if result else "REJECT"
                temp_dict['ERROR_MSG'] = "" if result else resp_text
                # logging.debug(temp_dict)
                xml_records.append(temp_dict)
            logging.info(f"{len(xml_records)} records have been extracted from WAY4 XML response file")

            # Extract metadata and records rejected by Python for this sequence/original input file from STG_ETL
            select = f"select DD_FLAG, CONTRACT_NUMBER, DD_NUM, DDS_NUMBER, DD_DAY, ERROR_MSG, REG_NUMBER " \
                     f"from PyTL_IS_UAE_DDS_File where ltrim(APP_NUMBER, '0') = :app_number"
            db_records = [d for d in stg_connection.select(statement=select,
                                                           bind_vars={'app_number': seq_number})]

            # Added metadata for records from WAY4 XML file
            # using unique REG_NUMBER as a link between table in STG_ETL and an input file
            records = []

            for xml_record in xml_records:
                for db_record in db_records:
                    if xml_record.get('REG_NUMBER') == db_record.get('REG_NUMBER') \
                            and not utils.string_not_empty(db_record.get('ERROR_MSG')):
                        temp = {}
                        temp['DD_FLAG'] = db_record.get('DD_FLAG', '')
                        temp['CONTRACT_NUMBER'] = db_record.get('CONTRACT_NUMBER', '')
                        temp['DD_NUM'] = db_record.get('DD_NUM', '')
                        temp['DDS_NUMBER'] = db_record.get('DDS_NUMBER', '')
                        temp['DD_DAY'] = db_record.get('DD_DAY', '')
                        # If WAY4 rejected record need to share this info in the report
                        temp['ERROR_MSG'] = xml_record.get('ERROR_MSG')
                        records.append(temp)
                        continue  # the first match is enough

            # Added to the final report records were rejected by the inbound Python job
            rejected_records = list(filter(lambda d: utils.string_not_empty(d.get('ERROR_MSG')), db_records))
            records.extend(rejected_records)

            if records:
                create_report(file_name=report_file_path, records=records)
                # close processed sequence number using old Talend jobs name convention
                stg_connection.execute_stored_procedure('PyTL_JOB_SUPPORT.setSeqValueUsed',
                                                        bind_vars={'p_job_id': __job_name__,
                                                                   'p_seq_value': seq_number,
                                                                   'p_mode': 'mark'})
                utils.delete_file(path)
            else:
                logging.error(f"File {path} contains correct name, but the content of the file ({[xml_record.get('REG_NUMBER') for xml_record in xml_records]}) is not matched with processed records ({[db_record.get('REG_NUMBER') for db_record in db_records]})")

    stg_connection.close()

