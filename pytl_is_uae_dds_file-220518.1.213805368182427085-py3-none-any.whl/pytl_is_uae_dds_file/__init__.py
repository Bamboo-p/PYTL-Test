__version__ = "220518.1"
__job_name__ = "PyTL_IS_UAE_DDS_File"
__bat_files__ = ["NIC_IS_In_UAE_DDS_File.bat", "NIC_IS_Ou_UAE_DDS_File.bat"]

print(f"{__version__=}")
print(f"{__job_name__=}")
print(f"{__bat_files__=}")