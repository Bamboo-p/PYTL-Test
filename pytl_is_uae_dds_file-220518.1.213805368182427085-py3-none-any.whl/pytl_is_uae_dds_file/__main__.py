from pathlib import Path

try:
    # Could be imported ONLY if it's run as module
    from ._PyTL_IS_UAE_DDS_File_IN  import main_in
    from ._PyTL_IS_UAE_DDS_File_OUT import main_out
    from . import __job_name__
    from importlib_metadata import version as importlib_metadata_version
    __version__ = importlib_metadata_version(__job_name__)
except:
    # Could be imported ONLY if it's run as normal py
    from _PyTL_IS_UAE_DDS_File_IN  import main_in
    from _PyTL_IS_UAE_DDS_File_OUT import main_out
    from __init__ import __version__
    from __init__ import __job_name__

import pytl_core
import logging
 
print("*"*30 + " " + __job_name__)
if __name__ == "__main__":
    print("*"*15 + " " + __file__)
    
    global cfg, config
    cfg = config = pytl_core.Config.configure_pytl_core({'JOB_FILE': __file__, 'JOB_NAME': __job_name__})
    logging.debug(f"Config: initialization finished, 'config' and 'cfg' variables were created.")
    logging.info(f"Starting {Path(__file__).stem} python job")
    if config.get('DIRECTION') == "OUT":
        main_out(config)
    else:
        main_in(config)
    logging.info(f"{Path(__file__).stem} python job is FINISHED!")
    