''' PyTL_IS_XlsReports

Changes
-------
    220621.3 = deniska = EK-3122: added ability to include into SQL files placeholders with complex logic based on config variable (together with pytl_core v2.7)
    220623.3 = deniska = EK-3122: looking SQL files with extension *.SQ?
    220831.1 = deniska = OPKSAIC-3086: Fixing defect: calculated_column_width = columns_width[idx] * 1.2 = IndexError: list index out of range
                                       It happends if no data returns back in query response.
                                       Fixing defect: showing ORG column in case of no data returns back in query response.
'''
__version__ = "220831.1"
__job_name__ = "PyTL_IS_XlsReports"
__bat_files__ = ["NIC_IS_Ou_XlsReports.bat"]
import datetime
import decimal
import pytl_core
import logging
from pathlib import Path
import glob
import n0struct
import os
import re
import openpyxl
import cx_Oracle
import yaml
from typing import Tuple, List
from openpyxl.cell import Cell
from openpyxl.styles import Border, Alignment, Font
from openpyxl.utils import get_column_letter
def raiser(ex): raise ex


__params__ = pytl_core.Params({
# Mandatory parameters
        "ENV":                      lambda: config['ENV'],                          # D:\PYTL\NIC\JOBNAME\W4UAT25.PARM
        "XLS_SHEETS":               lambda: check_and_prepare_xls_sheets_config(__XLS_SHEETS__()),
# Optional parameters
        "STYLE_FILES":              lambda: set() if not (__STYLE_FILES := config.get('STYLE_FILES', "")
                                                                      or config.get('STYLEFILES', "")
                                            )
                                    else {
                                        __STRIPPED_STYLE_FILE for __SKIP_COLUMN in __STYLE_FILES.upper().split(',')
                                        if ( __STRIPPED_STYLE_FILE:=__SKIP_COLUMN.strip() )
                                    } | set(),
        "SKIP_COLUMNS":             lambda: (
                                                set() if not ((__SKIP_COLUMNS := config.get('SKIPCOLUMNS', "")) or config.get('SKIP_COLUMNS', ""))
                                                else {
                                                    __STRIPPED_SKIP_COLUMN for __SKIP_COLUMN in __SKIP_COLUMNS.upper().split(';')
                                                    if ( __STRIPPED_SKIP_COLUMN:=__SKIP_COLUMN.strip() )
                                                }
                                            ) | {"ORG"}  # [*] 220831.1 = deniska = OPKSAIC-3086: Fixing defect: showing ORG column in case of no data returns back in query response.
                                    ,
        "ONLY_COLUMNS":             lambda: [] if not (__ONLY_COLUMNS := config.get('ONLY_COLUMNS', ""))
                                            else {
                                                __STRIPPED_ONLY_COLUMN for __ONLY_COLUMN in __ONLY_COLUMNS.upper().split(';')
                                                if ( __STRIPPED_ONLY_COLUMN:=__ONLY_COLUMN.strip() )
                                            }
                                    ,
        "AUTO_CONVERTED":           lambda: True if not (__AUTO_CONVERTED := config.get('AUTO_CONVERTED', ""))
                                            else (
                                                True if __AUTO_CONVERTED.upper() in ("TRUE", "YES", "1")
                                                else False
                                            ),
        "WRITE_HEADER":            lambda: True if not (__WRITE_HEADER := config.get('WRITE_HEADER', ""))
                                            else (
                                                True if __WRITE_HEADER.upper() in ("TRUE", "YES", "1")
                                                else False
                                            ),
        "ORG_LIST":                 lambda: config.get('ORG_LIST', "")
                                            or __params__['ORG'],
        "ORG":                      lambda: config.get('ORG', "")
                                            or config['ORGLIST'],                   # "982" || "982,320"
        "DB_SOURCE":                lambda: config.get('DB_SOURCE', "OWS").upper()
                                            or "OWS",                               # "DWH" || "OWS" default
        "INPUT_DATE_FORMAT":        lambda: config.get('INPUT_DATE_FORMAT', "")
                                            or "%d-%m-%Y",

        "OUTPUT_DATE_FORMAT":       lambda: config.get('OUTPUT_DATE_FORMAT', "")
                                            or "%Y%m%d",
        "P_REPORT_DATE":            lambda: config.get('P_REPORT_DATE', "")
                                            or datetime.datetime.now().strftime(__params__['INPUT_DATE_FORMAT']),
        "OUTPUT_FN_PREFIX":         lambda: os.path.splitext(os.path.basename(list(__params__['DATA_SOURCES'].values())[0][1]))[0]
                                            if not (__OUTPUT_FN_PREFIX := config.get('OUTPUT_FN_PREFIX', "").strip())
                                            else (
                                                __OUTPUT_FN_PREFIX
                                                if __OUTPUT_FN_PREFIX != '.'
                                                else ""
                                            ),
        "OUTPUT_FN_SEPARATOR":      lambda: "_"
                                            if not (__OUTPUT_FN_SEPARATOR := config.get('OUTPUT_FN_SEPARATOR', ""))
                                            else (
                                                __OUTPUT_FN_SEPARATOR if __OUTPUT_FN_SEPARATOR != '.'
                                                else ""
                                            ),
        "OUTPUT_FN_SUFIX":          lambda: datetime.datetime.strptime(
                                                                __params__['P_REPORT_DATE'],
                                                                __params__['INPUT_DATE_FORMAT']
                                            ).strftime(__params__['OUTPUT_DATE_FORMAT'])
                                            if not (__OUTPUT_FN_SUFIX := config.get('OUTPUT_FN_SUFIX', ""))
                                            else (
                                                __OUTPUT_FN_SUFIX if __OUTPUT_FN_SUFIX != '.'
                                                else ""
                                            ),
        "OUTPUT_FN_EXTENSION":      lambda: ".xlsx" if not (__OUTPUT_FN_EXTENSION := config.get('EXTENSION', "")
                                                                                    or config.get('OUTPUT_FN_EXTENSION', "")
                                            )
                                            else (
                                                "" if __OUTPUT_FN_EXTENSION == '.'
                                                else (
                                                    "."+__OUTPUT_FN_EXTENSION if not __OUTPUT_FN_EXTENSION.startswith('.')
                                                    else __OUTPUT_FN_EXTENSION
                                                )
                                            ),
        "OUTPUT_FN_RELATED":        lambda: config.get('OUTPUT_FN_RELATED', "")
                                            or (
                                                  __params__['OUTPUT_FN_PREFIX']
                                                + __params__['OUTPUT_FN_SEPARATOR']
                                                + __params__['OUTPUT_FN_SUFIX']
                                                + __params__['OUTPUT_FN_EXTENSION']
                                            ),
# Parameters from file config['ENV']
        "DB_W4C_SRC_WLTURL":        lambda: config['DB_W4C_SRC_WLTURL'],
        "DB_DM_SRC_WLTURL":         lambda: config['DB_DM_SRC_WLTURL'],
# Precalculated values
        "JOB_NAME":                 lambda: config['JOB_NAME'],
        "SQL_DIR":                  lambda: config['SQL_DIR'],
        "DST_DIR":                  lambda: config.get('TGT_FILEPATH', "") or config['DST_DIR'],
})


__XLS_SHEETS__ = lambda: {} if not config.get("XLS_SHEETS", "") else {
                    (__SPLITTED_XLS_SHEET := n0struct.split_pair(__STRIPPED_FULL_XLS_SHEET, '=', default_element=1))[0]
                    :
                        [
                            [
                                [
                                    (__SPLITTED_SHEET_SETTING_NAME := n0struct.split_pair(__SPLITTED_SHEET_SETTING_PAIR, '=',
                                                                                 default_element=1))[0]
                                    ,
                                    __SPLITTED_SHEET_SETTING_NAME[1]


                                ] for __SPLITTED_SHEET_SETTING_PAIR in __SPLITTED_SHEET_SETTINGS.split(':')
                            ]
                            for __SPLITTED_SHEET_SETTINGS in __SPLITTED_XLS_SHEET[1].split('~')
                        ]

                    for __FULL_XLS_SHEET in config.get('XLS_SHEETS', "").split(';')
                    if (__STRIPPED_FULL_XLS_SHEET := __FULL_XLS_SHEET.strip())
}

##################################################################################################
# All of our data comes from the cursor as a strings.
# Below is the mapping of the default converting from a string to another type,
# according to what values are stored in the database.
# We use Decimal to prevent bugs with inaccurate decimal places that can occur when using float.
##################################################################################################

def convert_oracle_date_to_datetime(time_value):
    if isinstance(time_value, str):
        if re.search("[\d]{1,2}-[ADFJMNOS]\w*-[\d]{2}", time_value):
            time_value = datetime.datetime.strptime(time_value, '%d-%b-%y')
    return time_value


ORACLE_DATA_TYPE_MAPPING = {
    cx_Oracle.DB_TYPE_NUMBER: decimal.Decimal,
    cx_Oracle.DB_TYPE_BINARY_DOUBLE: decimal.Decimal,
    cx_Oracle.DB_TYPE_BINARY_FLOAT: decimal.Decimal,
    cx_Oracle.DB_TYPE_DATE: convert_oracle_date_to_datetime,  # PoC
}


DATA_TYPE_MAPPING = {
    "float": float,
    "string": str,
    "datetime": datetime.datetime,
}


STYLES_WRAP_MAPPING = {
    "font": Font,
    "alignment": Alignment,
    "border": Border
}


def style_file_parser(value):
    """
    prepare yaml file name
    """
    return __stripped_x if (
        __stripped_x := value.strip()).lower().endswith(".yaml") \
        else __stripped_x + ".yaml"


def array_parser(value):
    """
    split by comma separator
    """
    return {val.strip() for val in value.strip().split(',')}


def default_parser(value):
    """
    return defaul values
    """
    return value.strip()


def boolean_parser(value):
    """
    parse boolean
    """
    if value.strip().lower() in ['1', 'yes', 'true']:
        return True
    return False

local_spreadsheet_setting_mapping = {
    'style_file': style_file_parser,
    'style_alias': default_parser,
    'dbsource': default_parser,
    'write_header': boolean_parser,
    'skip_columns': array_parser,
}


def check_and_prepare_xls_sheets_config(xls_sheet_config_param):
    """
    Parse and prepare dict object based on XLS_SHEETS config param
    """
    prepared_params = {}
    for spread_sheet_name, spread_sheet_params in xls_sheet_config_param.items():
        prepared_params[spread_sheet_name] = []
        for specific_datasource_settings in spread_sheet_params:

            prepared_datasource_params = {}
            # last element always sql file
            sql_settings = specific_datasource_settings.pop()

            if not sql_settings[1]:
                raiser(Exception(f"Empty sql in '{spread_sheet_name}'"))

            prepared_datasource_params['sql_file'] = __stripped_x if (
                __stripped_x := sql_settings[1].strip()).lower().endswith(".sql")\
                else __stripped_x + ".sql"

            for __setting in specific_datasource_settings:
                __setting_name, __setting_value = __setting[0], __setting[1]
                # to prevent errors if user don't set setting name
                if __setting_name:
                    __setting_name = __setting_name.strip().lower()
                    if __setting_value and __setting_name in local_spreadsheet_setting_mapping:
                        prepared_datasource_params[__setting_name] = local_spreadsheet_setting_mapping[__setting_name](
                            __setting_value
                        )
            prepared_params[spread_sheet_name].append(prepared_datasource_params)
    return prepared_params


def prepare_openpyxl_styles(raw_params):
    prepared_params = {}
    for sheet_name, params_ in raw_params.items():
        prepared_params[sheet_name] = {
            "styles": {},
            "data_options": {},
            "column_dimensions": {}
        }
        for column_name, styles_params in params_.items():
            prepared_params[sheet_name][column_name] = {}
            for param_name, values in styles_params.items():
                param_name = param_name.lower()
                if param_name in STYLES_WRAP_MAPPING:
                    prepared_params[sheet_name]["styles"][column_name] = {
                        param_name: STYLES_WRAP_MAPPING[param_name](**values)
                    }
                    continue
                if param_name == "column_dimensions" or "data_options":
                    prepared_params[sheet_name][param_name][column_name] = values

    return prepared_params


def get_all_related_report_style_files() -> dict:
    """
    Find all *.yaml files related to PyTL_IS_XlsReports and generate dict for quick search
    """
    report_settings_files_in_all_directories = sorted(
        list(glob.iglob(
                os.path.abspath(f"{os.path.dirname(os.path.abspath(__file__))}/../{__job_name__}*/**/*.yaml"),
                recursive=True,
        )), \
        key=os.path.getmtime, reverse=True,
    )
    report_settings_files = {}
    for report_settings_file_fullpath in report_settings_files_in_all_directories:
        report_settings_key = os.path.splitext(os.path.basename(report_settings_file_fullpath.lower()))[0]
        if not report_settings_key in report_settings_files:
            # First found (the mordern one) will be used, other will be ignored
            report_settings_files.update({report_settings_key: report_settings_file_fullpath})
    return report_settings_files


def prepare_report_settings(report_settings_files:dict) -> dict:
    """
    Open *.yaml file related to PyTL_IS_XlsReports job and generate settings dict
    """
    spreadsheet_settings = {}  # by default we have empty spreadsheet settings
    # n0struct.n0print(report_settings_files)

    if __params__['STYLE_FILES']:
        for style_file in __params__['STYLE_FILES']:
            if not os.path.exists(settings_template_file := style_file):
                settings_template_key = os.path.splitext(os.path.basename(settings_template_file.lower()))[0]
                if not settings_template_key in settings_template_key:
                    raise Exception(f"STYLE_FILE '{settings_template_file}' is not found")
                settings_template_file = report_settings_files[settings_template_key]
            with open(settings_template_file) as in_filehandler:
                spreadsheet_settings = yaml.load(in_filehandler, Loader=yaml.FullLoader)
    return spreadsheet_settings


def get_all_related_sql_files() -> dict:
    """
    Find all *.sql files related to PyTL_IS_HtmlReports and generate dict for quick search
    """
    found_sql_query_files_in_all_directories = sorted(
        list(glob.iglob(
                os.path.abspath(f"{os.path.dirname(os.path.abspath(__file__))}/../{__job_name__}*/**/*.sq?"),
                recursive=True,
        )), \
        key=os.path.getmtime, reverse=True,
    )
    found_sql_query_files = {}  # for each found SQL-file just only 1 record will be generated,
                                # where key is lower case file name only WITHOUT extention
    for sql_query_file_fullpath in found_sql_query_files_in_all_directories:
        # key is lower case file name only WITHOUT extention
        sql_query_key = os.path.splitext(os.path.basename(sql_query_file_fullpath.lower()))[0]
        if not sql_query_key in found_sql_query_files:
            # First found (the mordern one) will be used, other will be ignored
            found_sql_query_files.update({sql_query_key: sql_query_file_fullpath})

    return found_sql_query_files


def prepare_datasources(sql_query_files: dict) -> dict:
    """
    Check if required sql exist and prepare data sources
    """
    if __params__['DB_SOURCE'] == "DWH":
        default_connection = __params__['DB_DM_SRC_WLTURL']
    else:
        default_connection = __params__['DB_W4C_SRC_WLTURL']

    spread_sheet_datasources = __params__['XLS_SHEETS']

    for spread_sheet_name, sheet_sources_list in spread_sheet_datasources.items():
        for sheet_source_object in sheet_sources_list:
            if not sheet_source_object.get('dbsource'):
                sheet_source_object['dbsource'] = default_connection
            elif sheet_source_object['dbsource'].upper() == "DWH":
                sheet_source_object['dbsource'] = __params__['DB_DM_SRC_WLTURL']
            else:
                sheet_source_object['dbsource'] = __params__['DB_W4C_SRC_WLTURL']

            if not os.path.exists(sql_query_file := sheet_source_object["sql_file"]):
                sql_query_key = os.path.splitext(os.path.basename(sql_query_file.lower()))[0]
                if not sql_query_key in sql_query_files:
                    raise Exception(f"SQL file '{sql_query_file}' is not found")
                sheet_source_object["sql_file"] = sql_query_files[sql_query_key]

    return spread_sheet_datasources


def prepare_db_connections(datasources) -> dict:
    """
    Execute each sql and prepare Connection objects with cursor.
    Also prepare connection-sheet name map objects.
    """

    db_connections = {}
    ## n0struct.n0debug("datasources")
    for spreadsheet_name in datasources:
        for datasource in datasources[spreadsheet_name]:
            if not (db_connection_name := datasource['dbsource']) in db_connections:
                ## n0struct.n0debug("db_connection_name")
                db_connections[db_connection_name] = pytl_core.Connection(db_connection_name)

    return db_connections


def main() -> None:
    report_styles_files = get_all_related_report_style_files()
    spreadsheet_settings = prepare_report_settings(report_styles_files)
    sql_query_files = get_all_related_sql_files()
    datasources = prepare_datasources(sql_query_files)
    db_connections = prepare_db_connections(datasources)

    ##########################################################################
    # Generate xlsx
    ##########################################################################
    prepared_params = prepare_openpyxl_styles(spreadsheet_settings)
    workbook = openpyxl.Workbook()

    for i, spreadsheet_name in enumerate(datasources):
        row_idx = 1
        if i == 0:
            ws = workbook.active
            ws.name = spreadsheet_name
            ws.title = spreadsheet_name
        else:
            ws = workbook.create_sheet(spreadsheet_name)

        for datasource in datasources[spreadsheet_name]:
            # ##########################################################################
            # Init variables per each SQL file
            # ##########################################################################
            headers = []
            columns_width = []
            header_data_types = {}
            worksheet_data_types_options = prepared_params.get(spreadsheet_name, {}).get("data_options", {})
            data_is_fetched = False
            skip_columns = datasource['skip_columns'] | {"ORG"} if datasource.get('skip_columns') else __params__['SKIP_COLUMNS']

            sql_query_text = pytl_core.utils.load_statement_from_file(datasource['sql_file'], config)  # 220621.3 = deniska = EK-3122: added ability to include into SQL files placeholders with complex logic based on config variable (together with pytl_core v2.7)
            sql_1_parm_dict = {}
            for key in config:
                if re.search(":" + key + "\W", sql_query_text):
                    sql_1_parm_dict[key] = config[key]

            db_connection = db_connections[datasource['dbsource']]

            # ##########################################################################
            # Fetch results per each SQL file
            # ##########################################################################
            logging.info(f"****** Start execution of SQL '{datasource['sql_file']}'...")
            for iteration, batch in enumerate(
                db_connection.execute_select_batch(statement=sql_query_text, bind_vars=sql_1_parm_dict, pd_mode=False)):
                data_is_fetched = True
                # ######################################################################
                #  Get <header: data type> mapping and write headers based on SQL cursor metadata during 1st iteration
                # ######################################################################
                if iteration == 0:
                    header_data_types = {
                        item[0]: item[1]
                        for item
                        in db_connection.current_cursor_metadata
                        if item[0] not in skip_columns
                    }
                    logging.info(f"****** Start writing to destination files...")
                    headers = list(header_data_types.keys())
                    columns_width = [len(header) for header in headers] # default values
                    ws.append(headers)

                # ######################################################################
                # Save fetched data into spreadsheet
                # ######################################################################
                for row in batch:
                    formatted_row = []
                    for column_index, column_name in enumerate(headers):
                        cell_value = row.get(column_name)
                        prev_cell_width_value = 0
                        current_cell_width_value= len(cell_value) if cell_value else 0

                        if column_index < len(columns_width):
                            prev_cell_width_value = columns_width[column_index]

                        columns_width[column_index] = max(current_cell_width_value, prev_cell_width_value)

                        cell = Cell(
                            worksheet=ws,
                            row=row_idx + 1,
                            column=column_index + 1,
                        )
                        column_type = header_data_types.get(column_name)
                        data_options = worksheet_data_types_options.get(column_name, {})

                        if cell_value and "data_type" in data_options:
                            python_mapped_type = DATA_TYPE_MAPPING.get(data_options["data_type"])
                            if python_mapped_type:
                                cell_value = python_mapped_type(cell_value)
                        elif all([
                            __params__['AUTO_CONVERTED'],
                            cell_value and column_type in ORACLE_DATA_TYPE_MAPPING
                        ]):
                            cell_value = ORACLE_DATA_TYPE_MAPPING[column_type](cell_value)

                        if "format" in data_options:
                            cell.number_format = data_options["format"]

                        cell.value = cell_value
                        cell_styles = prepared_params.get(spreadsheet_name, {}).get("styles", {}).get(headers[column_index],
                                                                                                      {})
                        for k, v in cell_styles.items():
                            setattr(cell, k, v)

                        formatted_row.append(cell)
                    ws.append(formatted_row)

            if not data_is_fetched:
                # ##########################################################################
                # Save only header in case of no data fetched  if CREATE_EMPTY_REPORT and WRITE_HEADER are True
                # ##########################################################################
                if datasource.get('write_header') or  __params__['WRITE_HEADER']:
                    # Create files with HEADER in case of no data fetched
                    sql_2 = "select t2.DUMMY_VALUE, t1.* from (" + sql_query_text + ") t1 full outer join (select null as DUMMY_VALUE from dual) t2 on t2.DUMMY_VALUE = t1.ORG"
                    db_connection.execute_select_batch(statement=sql_2, bind_vars=sql_1_parm_dict, pd_mode=False)
                    # Remove DUMMY_VALUE and columns mentioned in SKIP_COLUMNS (ORG and other)
                    headers = [
                        item[0] for item in db_connection.current_cursor_metadata
                        if item[0] not in (skip_columns | {"DUMMY_VALUE"})
                    ]
                    # [+] Begin 220831.1 = deniska = OPKSAIC-3086: Fixing defect: calculated_column_width = columns_width[idx] * 1.2 = IndexError: list index out of range
                    columns_width = [len(header) for header in headers] # default values
                    # [+] End   220831.1 = deniska = OPKSAIC-3086: Fixing defect: calculated_column_width = columns_width[idx] * 1.2 = IndexError: list index out of range
                    ws.append(headers)

            if headers and prepared_params.get(spreadsheet_name):
                for idx, header in enumerate(headers):
                    calculated_column_width = columns_width[idx] * 1.2
                    dimension_params = prepared_params.get(spreadsheet_name, {}).get("column_dimensions", {}).get(
                        header,
                        {'width': calculated_column_width}
                    )
                    for param_, value in dimension_params.items():
                        column_letter = get_column_letter(idx + 1)
                        setattr(ws.column_dimensions[column_letter], param_, value)
            elif headers and columns_width:
                for idx, header in enumerate(headers):
                    column_letter = get_column_letter(idx + 1)
                    calculated_column_width = columns_width[idx] * 1.2
                    setattr(ws.column_dimensions[column_letter], "width", calculated_column_width)


    report_path = Path(__params__['DST_DIR']) / (
                                                    datetime.datetime.strptime(
                                                                __params__['P_REPORT_DATE'],
                                                                __params__['INPUT_DATE_FORMAT']
                                                    ).strftime(__params__['OUTPUT_FN_RELATED'])
                                                  )
    report_path.parent.mkdir(parents=True, exist_ok=True)
    logging.info(f"Saving report into '{report_path}'")
    workbook.save(report_path)

    # ##########################################################################
    # Close db_connections
    # ##########################################################################
    for db_connection_name in db_connections:
        db_connections[db_connection_name].close()


def _main():
    global cfg, config
    cfg = config = pytl_core.Config.configure_pytl_core({'JOB_FILE': __file__, 'JOB_NAME': __job_name__})
    logging.debug(f"Config: initialization finished, 'config' and 'cfg' variables were created.")
    logging.info(f"Starting {Path(__file__).stem} python job")
    main()
    logging.info(f"{Path(__file__).stem} python job is FINISHED!")
