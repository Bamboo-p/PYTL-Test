__version__ = "240226.1"
__job_name__ = "PyTL_IS_XlsReports_AQ_BNPL_INST_SUMMARY_REPORT"
__bat_files__ = []

