/*
* Code for AQ_BNPL_INST_SUMMARY_REPORT
* PyTL_IS_XlsReports_AQ_BNPL_INST_SUMMARY_REPORT = AQ_BNPL_INST_SUMMARY_REPORT.sql
* Version history:
* 230711.1 : NIIN-324 : PrabirK : Initial development
* 231127.1 : PRD-25670: PrabirK : SQL Condition change for Contract and HINT addition
* 231129.1 : PRD-25670: PrabirK : Correction of bnpl_instl_fee_flag indicator addition
* 240226.1 : NIBOA-9502: HamzaHendi : adding visa installment and vat on visa installment fee
*/

with
institution as (
select /*+ no_merge materialize */ 
       id 
from dwh.dwd_institution 
where record_state = 'A' 
and code = :ORG
)
,operation as (
select /*+ no_merge materialize */
       id,
       code,
       name
from dwh.dwd_operation_type
where record_state = 'A'
and code in (
             'M_TRANS_DT_MC_BNPL_INST_FEE',
			 'M_TRANS_DT_MC_BNPL_INST_FEE_REV',
			 'M_TRANS_VAT_MC_BNPL_INST_FEE',
			 'M_TRANS_VAT_MC_BNPL_INST_FEE_REV',
             'M_TRANS_DT_VISA_INST_FEE',
             'M_TRANS_DT_VISA_INST_FEE_REV',
             'M_TRANS_VAT_VISA_INST_FEE',
             'M_TRANS_VAT_VISA_INST_FEE_REV'
             )
)
,contract as (
select /*+ no_merge leading(attr c) use_hash(attr c) */
       c.personal_account,
       c.record_idt,
       c.parent_contract_idt,
	   attr.cntr_role,
	   attr.bnpl_instl_fee_flag,
       attr.visa_instl_fee_flag
from dwh.dwd_contract c
join institution i
on i.id = c.institution_id
left join (select /*+ no_merge leading(da, dca) use_hash(da dca) no_push_pred */
                  dca.contract_idt,
                  max(case 
				       when da.type_code = 'ACQ_LVL' 
					    then da.code 
					   else null 
					   end) as cntr_role,
				  nvl(max(case 
				           when da.type_code = 'ACQ_MC_BNPL_INST_FEE_FLAG' 
						    then da.code 
					       else null 
					       end),'N') as bnpl_instl_fee_flag,
    			   nvl(max(case 
				           when da.type_code = 'ACQ_VISA_INST_FEE_FLAG' 
						    then da.code 
					       else null 
					       end),'N') as visa_instl_fee_flag                       
           from dwh.dwa_contract_attribute dca
		   join dwh.dwd_attribute da
		     on da.id = dca.attr_id
		    and da.type_code in ( 'ACQ_LVL','ACQ_MC_BNPL_INST_FEE_FLAG', 'ACQ_VISA_INST_FEE_FLAG')
		    and da.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
            and da.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
		   where dca.attr_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
           and dca.attr_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
           group by dca.contract_idt)attr
on attr.contract_idt = c.record_idt
where c.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
and c.record_date_to >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
and c.record_state != 'C'
)
,address as (
select /*+ no_merge use_hash(inst) swap_join_inputs(inst) pq_distribute(inst none broadcast)*/
                     dca.contract_idt,
                     max(decode(dat.code, 'STMT_ADDR', dca.address_line_1, null)) merchant_dba_name
from dwh.dwd_contract_address dca
join dwh.dwd_address_type dat
on dca.address_type_id = dat.id
and dat.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
and dat.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
join institution inst 
on dca.institution_id = inst.id
where dca.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
and dca.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
group by dca.contract_idt
)
,entry as (
select /*+ no_merge leading(opr) use_nl(opr) parallel(4) */
       ent.contract_idt,
       ent.credit - ent.debit as amnt,
       opr.code
from dwh.dwf_account_entry ent
join institution ins
on ins.id = ent.institution_id
join operation opr
on opr.id = ent.operation_type_id
where ent.banking_date >= trunc(add_months(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'),-1))
and ent.banking_date <= last_day(add_months(to_date(:P_REPORT_DATE, 'DD-MM-YYYY'),-1))
)

select :ORG as org,
       d.merchant_id,
       a.merchant_dba_name as merchant_name,
       to_char(add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1),'MONTH') as report_month,
       abs(d.bnpl_fee) as bnpl_fee,
       abs(d.vat_bnpl_fee) as vat_bnpl_fee,
       abs(d.visa_inst_fee) as visa_inst_fee,
       abs(d.vat_visa_inst_fee) as vat_visa_inst_fee
from (
select /*+ leading(dev ent mer) use_hash(dev ent) */
       mer.record_idt,
       mer.personal_account as merchant_id,
       sum(
           case 
            when ent.code in ('M_TRANS_DT_MC_BNPL_INST_FEE','M_TRANS_DT_MC_BNPL_INST_FEE_REV')
             then ent.amnt
            else 0
           end 
          )  as bnpl_fee,
       sum(
           case 
            when ent.code in ('M_TRANS_VAT_MC_BNPL_INST_FEE','M_TRANS_VAT_MC_BNPL_INST_FEE_REV')
             then ent.amnt
            else 0
           end 
          )  as vat_bnpl_fee,  
       sum(
           case 
            when ent.code in ('M_TRANS_DT_VISA_INST_FEE','M_TRANS_DT_VISA_INST_FEE_REV')
             then ent.amnt
            else 0
           end 
          )  as visa_inst_fee,
       sum(
           case 
            when ent.code in ('M_TRANS_VAT_VISA_INST_FEE','M_TRANS_VAT_VISA_INST_FEE_REV')
             then ent.amnt
            else 0
           end 
          )  as vat_visa_inst_fee
       
from entry ent
join contract dev
on dev.record_idt = ent.contract_idt
and dev.cntr_role = 'DEVICE'
join contract mer
on mer.record_idt = dev.parent_contract_idt
and mer.cntr_role = 'MERCHANT'
and (mer.bnpl_instl_fee_flag = 'Y' or mer.visa_instl_fee_flag = 'Y')
group by mer.record_idt,
         mer.personal_account
)d
left join address a
on a.contract_idt = d.record_idt