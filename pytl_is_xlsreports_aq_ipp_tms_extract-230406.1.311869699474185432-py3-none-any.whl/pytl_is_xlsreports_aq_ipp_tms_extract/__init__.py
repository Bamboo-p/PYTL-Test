__version__ = "230406.1"
__job_name__ = "PyTL_IS_XlsReports_AQ_IPP_TMS_EXTRACT"
__bat_files__ = []

