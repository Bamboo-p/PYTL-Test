/*
* Code for AQ_IPP_TMS_EXTRACT
* PyTL_IS_XlsReports_AQ_IPP_TMS_EXTRACT = AQ_IPP_TMS_EXTRACT.sql
* Version history:
* 230222.1 : NIBOA-8188 : PrabirK  : Initial development
* 230223.1 : NIBOA-8188 : PrabirK  : Updated the contract section and final select section
* 230224.1 : NIBOA-8188 : PrabirK  : Added Cash Desk ID check to fetch the terminal
* 230313.1 : NIBOA-8286 : PrabirK  : Remove CURR_INSTPP_FLAG filrer from final select statment
* 230406.1 : NIBOA-8363 : PrabirK  : Added Merchant City field to the extract
*/
WITH inst AS (
    SELECT
        id,
        code AS instcode
    FROM
        dwh.dwd_institution
    WHERE
            record_state = 'A'
        AND code = :ORG
-- [*][begin] 230223.1 = PrabirK = NIBOA-8188
), contract AS (
    SELECT
        cntr.record_idt,
        cntr.parent_contract_idt,
        cntr.personal_account,
        cntr.add_info         AS cntr_add_info,
        cntr.record_date_from AS cntr_record_date_from,
        CASE
            WHEN cntr.personal_account LIKE 'POS%' THEN
                'Y'
            ELSE
                'N'
        END                   AS is_dummy,
        clnt.add_info         AS clnt_add_info
    FROM
             dwh.dwd_contract cntr
        JOIN inst ON inst.id = cntr.institution_id
        JOIN dwh.dwd_client clnt ON clnt.record_idt = cntr.client_idt
                                    AND clnt.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                                    AND clnt.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    WHERE
            cntr.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND cntr.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
-- [*][end] 230223.1 = PrabirK = NIBOA-8188
), curr_cattr AS (
    SELECT
        dctr.contract_idt,
        datr.code AS curr_instpp_flag
    FROM
             dwh.dwa_contract_attribute dctr
        JOIN dwh.dwd_attribute datr ON datr.id = dctr.attr_id
                                       AND datr.type_code = 'ACQ_INSTPP_FLAG'
                                       AND datr.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                                       AND datr.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    WHERE
            dctr.attr_date_from = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND dctr.attr_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
),
-- [+][begin] 230406.1 = PrabirK = NIBOA-8363
addrs as (
select contract_idt,
       max(decode(address_type_code,'STMT_ADDR',city,null)) as city
from dwh.opt_v_address adr
join inst on inst.id = adr.institution_id
where adr.record_state = 'A'
and adr.address_type_code in ('STMT_ADDR','PAYM_ADDR')
group by contract_idt
)
-- [+][end]   230406.1 = PrabirK = NIBOA-8363

SELECT
    :ORG AS org,
    merchant,
    terminal,
    merchant_tag,
    bank_user_id,
    shop_id,
    cash_desk_id,
	merchant_city -- [+] 230406.1 = PrabirK = NIBOA-8363
FROM
    (
        SELECT
		    -- [*][begin] 230223.1 = PrabirK = NIBOA-8188
            dev.record_idt                                                         AS terminal_id,
            dev.personal_account                                                   AS terminal,
            merch.record_idt                                                       AS merchant_id,
            merch.personal_account                                                 AS merchant,
            dwh.sy_convert.get_tag_value(merch.clnt_add_info, 'INSTPP_MERCH_ID')   AS merchant_tag,
            dwh.sy_convert.get_tag_value(merch.clnt_add_info, 'INSTPP_BNKUSR_ID')  AS bank_user_id,
            dwh.sy_convert.get_tag_value(merch.clnt_add_info, 'INSTPP_SHOP_ID')    AS shop_id,
            dwh.sy_convert.get_tag_value(dev.cntr_add_info, 'INSTPP_CASH_DESK_ID') AS cash_desk_id,
            dev.cntr_record_date_from,
            curr_cattr.curr_instpp_flag,
			-- [*][end] 230223.1 = PrabirK = NIBOA-8188
			addrs.city															   AS merchant_city -- [+] 230406.1 = PrabirK = NIBOA-8363
        FROM
            contract merch
            LEFT JOIN contract dev ON dev.parent_contract_idt = merch.record_idt
                                      AND nvl(dev.is_dummy, 'N') = 'N'
                                      -- [+][begin] 230224.1 = PrabirK = NIBOA-8188
                                      AND instr(dev.cntr_add_info,'INSTPP_CASH_DESK_ID') > 0
                                      -- [-][begin] 230224.1 = PrabirK = NIBOA-8188
            LEFT JOIN curr_cattr ON curr_cattr.contract_idt = merch.record_idt
			-- [+][begin] 230406.1 = PrabirK = NIBOA-8363
			LEFT JOIN addrs ON addrs.contract_idt = merch.record_idt
			-- [+][end]   230406.1 = PrabirK = NIBOA-8363
    )
WHERE
    cntr_record_date_from = to_date(:P_REPORT_DATE, 'DD-MM-YYYY') -- [*] 230313.1 = PrabirK = NIBOA-8286
ORDER BY
    merchant