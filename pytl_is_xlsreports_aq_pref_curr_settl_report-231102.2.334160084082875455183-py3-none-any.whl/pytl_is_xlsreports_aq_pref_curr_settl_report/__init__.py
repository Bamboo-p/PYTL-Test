__version__ = "231102.2"
__job_name__ = "PyTL_IS_XlsReports_AQ_PREF_CURR_SETTL_REPORT"
__bat_files__ = []
