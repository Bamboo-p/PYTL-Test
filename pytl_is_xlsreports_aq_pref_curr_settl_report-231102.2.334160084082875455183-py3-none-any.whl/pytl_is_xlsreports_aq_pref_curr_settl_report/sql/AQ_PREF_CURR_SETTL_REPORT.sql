/*
* Version History - AQ_PREF_CURR_SETTL_REPORT.sql
231102.1 : MaksimSK : NIBOA-8233: Initial development for the Currency Settlement report
*/
with inst as (
select /*+ no_merge materialize */
  ID
from dwh.dwd_institution
where record_state = 'A'
  and code = :ORG
)
,chains as (
select /*+ no_merge materialize use_hash(dc) use_hash(inst) swap_join_inputs(inst) 
pq_distribute(inst none broadcast) use_hash(dft) swap_join_inputs(dft) 
pq_distribute(dft none broadcast) pq_distribute(dc hash hash)*/
  dach.contract_idt
  ,dc.ident_number
from dwh.dwd_affiliation dach
join dwh.dwd_affiliation_type dft on dach.affiliation_type_id = dft.id
  and dft.code in ('CHAINID_1')
  and dft.record_state != 'C'
  and to_date(:P_REPORT_DATE,'dd-mm-yyyy') between dft.record_date_from and dft.record_date_to
join dwh.dwd_client dc on dc.record_idt = dach.affiliated_client_idt
  and to_date(:P_REPORT_DATE,'dd-mm-yyyy') between dc.record_date_from and dc.record_date_to
  and dc.record_state != 'C'
join inst on inst.id = dc.institution_id
where to_date(:P_REPORT_DATE,'dd-mm-yyyy') between dach.record_date_from and dach.record_date_to
  and dach.record_state != 'C'
)
,addr as (
select /*+ no_merge */
  ova.contract_idt
  ,ova.address_line_1
from dwh.opt_v_address ova
join inst on inst.ID = ova.institution_id
where ova.address_type_code in ('STMT_ADDR')
  and to_date(:P_REPORT_DATE,'dd-mm-yyyy') between ova.record_date_from and ova.record_date_to
  and ova.record_state != 'C'
)
,currency as (
select /*+ no_merge materialize */
  code
  ,name
from dwh.dwd_currency
where record_state = 'A'
)
,cntr_attr as (
select /*+ no_merge materialize leading(attr dca) use_hash(attr dca) no_push_pred */
  dca.contract_idt
  ,attr.type_code
  ,attr.code
from 
dwh.dwa_contract_attribute dca
join dwh.dwd_attribute attr on attr.id = dca.attr_id
  and attr.record_state = 'A'
  and to_date(:P_REPORT_DATE, 'dd-mm-yyyy') between attr.record_date_from and attr.record_date_to
  and attr.type_code in (
    'ACQ_COMM_STTLM'
    ,'ACQ_LVL'
    ,'CURR_PREF_FLAG'
    )
where 
  to_date(:P_REPORT_DATE, 'dd-mm-yyyy') between dca.attr_date_from and dca.attr_date_to
  and dca.active_state = 'A'
)
,cntr_init as (
select /*+ no_merge leading(i cntr cntr_attr) use_hash(i cntr) use_hash(cntr cntr_attr) */
  cntr.personal_account
  ,cntr.record_idt
  ,decode(
    cntr_attr.code,'MERCHANT'
    ,cntr.record_idt
    ,cntr.parent_contract_idt
  )                                         as parent_contract_idt
  ,cntr.base_currency
  ,substr(
    cntr.add_info
    ,instr(cntr.add_info, 'CURR_PREF_VAL=')+14
    ,(instr(cntr.add_info, ';', instr(cntr.add_info, 'CURR_PREF_VAL=')) - instr(cntr.add_info, 'CURR_PREF_VAL=')-14)
  )                                         as prefer_currency
  ,cntr_attr.code
  ,substr(
    cntr.add_info
    ,instr(cntr.add_info, 'PAYM_MODE=')+10
    ,(instr(cntr.add_info, ';', instr(cntr.add_info, 'PAYM_MODE=')) - instr(cntr.add_info, 'PAYM_MODE=')-10)
  )                                         as pay_mode
  ,substr(
    cntr.add_info
    ,instr(cntr.add_info, 'CA_NUMBER=')+10
    ,(instr(cntr.add_info, ';', instr(cntr.add_info, 'CA_NUMBER=')) - instr(cntr.add_info, 'CA_NUMBER=')-10)
  )                                         as ca_number
from 
dwh.dwd_contract cntr
join inst i on i.id = cntr.institution_id
join cntr_attr on cntr.record_idt = cntr_attr.contract_idt
  and cntr_attr.type_code in ('ACQ_LVL')
  and cntr_attr.code in (
    'MERCHANT'
    ,'DEVICE'
    )
where 
  to_date(:P_REPORT_DATE,'dd-mm-yyyy') between cntr.record_date_from and cntr.record_date_to
  and cntr.record_state != 'C'
)
,cntr as (
select /*+ no_merge materialize leading(cn ccp dev ch) */
  ch.ident_number
  ,cn.personal_account
  ,cn.record_idt                            as contract_idt
  ,cn.pay_mode
  ,cn.ca_number
  ,addr.address_line_1                      as merchant_name
  ,basecur.name                             as base_currency
  ,prefcur.name                             as prefer_currency
  ,dev.record_idt
  ,decode(
    dev.code,'MERCHANT'
    ,dev.code
    ,NULL
  )                                         as code
  ,NVL(ccp.code, 'N')                       as curr_pref_flag
  ,ca.code                                  as comm_sttl
from cntr_attr ccp
join cntr_init cn on cn.record_idt = ccp.contract_idt
  and ccp.type_code = 'CURR_PREF_FLAG'
  and ccp.code = 'Y'
join cntr_init dev on cn.record_idt = dev.parent_contract_idt
  and cn.code = 'MERCHANT'
left join chains ch on ch.contract_idt = cn.record_idt
left join addr on addr.contract_idt = cn.record_idt
left join currency basecur on basecur.code = cn.base_currency
left join currency prefcur on prefcur.code = cn.prefer_currency
left join cntr_attr ca on ca.contract_idt = cn.record_idt
  and ca.type_code = 'ACQ_COMM_STTLM'
)
,oper as (
select /*+ no_merge materialize */
  op.operation_type_id
  ,op.name
  ,op.code
  ,op.purpose
  ,case
    when NVL(tot.type_total,'') = 'TOTAL_TRANSACTIONS'
      then 'TRAN'
    when op.code = 'VAT'
      then 'VAT'
    when instr(op.purpose, ',VAT_ON_FEE,') > 0
      then 'VAT'
    when instr(op.purpose, ',TRANS_FEE,') > 0
      then 'TRANS_FEE'
    when instr(op.purpose, ',COMM,') > 0
      then 'COMM'
    when instr(op.purpose, ',REBATE,') > 0
      then 'REBATE'
  end                                       as TYPE
from (
select /*+ inline no_merge materialize */
  op.operation_type_id                      as operation_type_id
  ,op.operation_type_code                   as operation_type_code
  ,op.code                                  as code
  ,','
  || listagg(op.type_code, ',') WITHIN GROUP (
  ORDER BY op.type_code)
  || ','                                    as purpose
  ,NVL(MIN(op.NAME), op.code)               as NAME
from (
select 
  op.operation_type_id
  ,op.operation_type_code
  ,op.NAME
  ,op.code
  ,op.sort_order
  ,op.type_code
from dwh.v_dwr_operation_type op
where op.class_code = 'ACQ_SETTLEMENT_REPORT'
) op
group by 
  op.operation_type_id
  ,op.operation_type_code
  ,op.code
) op
left join (
select /*+ no_merge materialize */
  operation_type_id
  ,code                                     as type_total
from dwh.v_dwr_operation_type
where 
  class_code = 'ACQ_REPORTS'
  and type_code = 'DA_TOTALS'
) tot
on tot.operation_type_id = op.operation_type_id
where 
  NVL(tot.type_total,'') = 'TOTAL_TRANSACTIONS'
  or instr(op.purpose, ',COMM_CODE,') > 0
)
,settlement as (
select /*+ no_merge materialize use_hash(i s) */
  s.merchant_idt
  ,s.doc_idt
from dwh.opt_dwf_settlement s
join inst on inst.id = s.institution_id
where s.settlement_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy')
group by 
  s.merchant_idt
  ,s.doc_idt
)
,entries as (
select /*+ no_merge materialize leading(i op e) full(e) parallel(4) */
  e.contract_idt
  ,e.banking_date
  ,e.primary_doc_idt
  ,op.operation_type_id
  ,op.type
  ,op.code
  ,e.credit - e.debit                       as amount
from 
dwh.dwf_account_entry e
join inst i on i.ID = e.institution_id
join oper op on op.operation_type_id = e.operation_type_id
where 
  e.banking_date >= add_months(to_date(:P_REPORT_DATE,'dd-mm-yyyy'),-1)
  and e.banking_date <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
)
,trans_entr as (
select /*+ no_merge leading(sttl e) materialize */
  e.contract_idt
  ,e.primary_doc_idt
  ,e.operation_type_id
  ,e.type
  ,e.code
  ,e.amount
from
settlement sttl
join entries e on e.primary_doc_idt = sttl.doc_idt
where e.type in (
    'TRAN'
    ,'COMM'
    ,'VAT'
    ,'TRANS_FEE'
    )

UNION ALL

select
  e.contract_idt
  ,e.primary_doc_idt
  ,e.operation_type_id
  ,e.type
  ,e.code
  ,e.amount
from entries e
where e.code in ('CRSTL_CNVRSN','CRSTL_MRKUP')
  and e.banking_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy')
)
,all_items as (
SELECT /*+ no_merge leading(cntr e) */
  cntr.contract_idt
  ,cntr.merchant_name
  ,cntr.pay_mode
  ,cntr.ca_number
  ,cntr.personal_account
  ,cntr.ident_number
  ,cntr.base_currency
  ,cntr.prefer_currency
  ,SUM(DECODE(e.TYPE,'TRAN',e.amount,0))         as trans_amount
  ,SUM(DECODE(e.TYPE,'COMM',e.amount,0))         as comm
  ,SUM(DECODE(e.TYPE,'TRANS_FEE',e.amount,0))    as trans_fee
  ,SUM(DECODE(e.code,'VAT',e.amount,0))          as vat
  ,SUM(DECODE(e.code,'VAT_ON_FEE',e.amount,0))   as vat_on_fee
  ,SUM(DECODE(e.code,'CRSTL_CNVRSN',e.amount,0)) as crstl_cnvrsn
  ,SUM(DECODE(e.code,'CRSTL_MRKUP',e.amount,0))  as crstl_mrkup
FROM
cntr
JOIN trans_entr e ON e.contract_idt = cntr.record_idt
group by
  cntr.contract_idt
  ,cntr.merchant_name
  ,cntr.pay_mode
  ,cntr.ca_number
  ,cntr.personal_account
  ,cntr.ident_number
  ,cntr.base_currency
  ,cntr.prefer_currency
)
select
  org                                       as "ORG"
  ,personal_account                         as "MERCHANT"
  ,merchant_name                            as "MERCHANT NAME"
  ,pay_mode                                 as "PMT MOD"
  ,ident_number                             as "CHAIN ID"
  ,ca_number                                as "MERCHANT ACCOUNT"
  ,base_currency                            as "MER BASE CURRENCY"
  ,prefer_currency                          as "PREFERRED SETTLEMENT CURRENCY"
  ,total_amount                             as "TOTAL AMOUNT IN MERCHANT BASE CY"
  ,mrkup_amount                             as "NI MARKUP IN MERCHANT BASE CURRENCY"
  ,net_amount                               as "NET AMOUNT IN MERCHANT BASE CURRENCY"
  ,net_amount_cnvrsn                        as "NET AMOUNT IN PREFERRED SETT CY"
from (
select 
  :ORG                                      as org
  ,personal_account
  ,merchant_name
  ,pay_mode
  ,ident_number
  ,ca_number
  ,base_currency
  ,prefer_currency
  ,(
      trans_amount
    + comm
    + trans_fee
    + vat
    + vat_on_fee
   )                                        as total_amount
  ,crstl_mrkup                              as mrkup_amount
  ,(
      trans_amount
    + comm
    + trans_fee
    + vat
    + vat_on_fee
    + crstl_mrkup
   )                                        as net_amount
  ,crstl_cnvrsn                             as net_amount_cnvrsn
from all_items
)
order by personal_account