__version__ = "231013.1"
__job_name__ = "PyTL_IS_XlsReports_AQ_SPLT_STL_PMNT_SUMM_RRT"
__bat_files__ = []

