__version__ = "230727.1"
__job_name__ = "PyTL_IS_XlsReports_AQ_UN_ENROLLMENT_BNPL"
__bat_files__ = []
