/*
* Version History - AQ_UN_ENROLLMENT_BNPL.sql
230719.1 : PadalaSK : NIIN-343: Initial development for the BNPL MC Installment un-enrollment extract
230727.1 : PadalaSK : NIIN-343: Updated logic for maid field to fetch it from contract add_info
*/
WITH inst AS (
    SELECT
        id,
        code AS instcode
    FROM
        dwh.dwd_institution
    WHERE
            record_state = 'A'
        AND code = :ORG
), merch AS (
    SELECT
        inst.instcode,
        cntr.record_idt,
        cntr.personal_account,
        cntr.parent_contract_idt,
        nvl(replace(replace(substr(cntr.add_info, instr(cntr.add_info, ';MC_ASSIGNED_ID=') + 16,(instr(cntr.add_info, ';', instr(cntr.
        add_info, ';MC_ASSIGNED_ID=') + 1) - instr(cntr.add_info, ';MC_ASSIGNED_ID=') - 16)), CHR(10)), CHR(13)), '424153') AS maid
    FROM
             dwh.dwd_contract cntr
        JOIN inst ON inst.id = cntr.institution_id
        JOIN dwh.dwd_client clnt ON clnt.record_idt = cntr.client_idt
                                    AND clnt.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                                    AND clnt.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    WHERE
            cntr.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND cntr.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
       -- AND cntr.parent_contract_idt IS NULL
), curr_cattr AS (
    SELECT
        dctr.contract_idt,
        datr.code AS curr_bnpl_inst_fee_flag
    FROM
             dwh.dwa_contract_attribute dctr
        JOIN dwh.dwd_attribute datr ON datr.id = dctr.attr_id
                                       AND datr.type_code = 'ACQ_MC_BNPL_INST_FEE_FLAG'
                                       AND datr.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                                       AND datr.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    WHERE
            dctr.attr_date_from = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND dctr.attr_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
), prev_cattr AS (
    SELECT
        dctr.contract_idt,
        datr.code AS prev_bnpl_inst_fee_flag
    FROM
             dwh.dwa_contract_attribute dctr
        JOIN dwh.dwd_attribute datr ON datr.id = dctr.attr_id
                                       AND datr.type_code = 'ACQ_MC_BNPL_INST_FEE_FLAG'
                                       AND datr.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                                       AND datr.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    WHERE
            dctr.attr_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY') - 1
        AND dctr.attr_date_to = to_date(:P_REPORT_DATE, 'DD-MM-YYYY') - 1
), merch_addrs AS (
    SELECT
        addrs.contract_idt,
        MAX(
            CASE
                WHEN addrs.address_type_code = 'STMT_ADDR' THEN
                    addrs.first_name
            END
        ) AS first_name,
        MAX(
            CASE
                WHEN addrs.address_type_code = 'STMT_ADDR' THEN
                    addrs.phone
            END
        ) AS phone,
        MAX(
            CASE
                WHEN addrs.address_type_code = 'STMT_ADDR' THEN
                    addrs.address_line_1
            END
        ) AS address_line_1,
        MAX(
            CASE
                WHEN addrs.address_type_code = 'STMT_ADDR' THEN
                    addrs.address_line_2
            END
        ) AS address_line_2,
        MAX(
            CASE
                WHEN addrs.address_type_code = 'STMT_ADDR' THEN
                    addrs.address_line_3
            END
        ) AS street,
        MAX(
            CASE
                WHEN addrs.address_type_code = 'STMT_ADDR' THEN
                    addrs.address_zip
            END
        ) AS postalcode,
        MAX(
            CASE
                WHEN addrs.address_type_code = 'STMT_ADDR' THEN
                    addrs.city
            END
        ) AS city,
        MAX(
            CASE
                WHEN addrs.address_type_code = 'STMT_ADDR' THEN
                    addrs.state
            END
        ) AS state,
        MAX(
            CASE
                WHEN addrs.address_type_code = 'STMT_ADDR' THEN
                    addrs.country
            END
        ) AS country
    FROM
        dwh.opt_v_address addrs
    WHERE
        addrs.address_type_code IN ( 'STMT_ADDR' )
        AND addrs.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND addrs.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    GROUP BY
        addrs.contract_idt
), full_q AS (
    SELECT
        nvl(merch.record_idt, '')                   AS merchant,
        nvl(merch.instcode, '')                     AS org_code,
        nvl(merch_addrs.first_name, '')             AS first_name,
        nvl(merch_addrs.phone, '')                  AS mobile,
        nvl(merch_addrs.address_line_1, '')         AS address_line_1,
        nvl(merch.personal_account, '')             AS mid,
        nvl(merch_addrs.address_line_2, '')         AS address_line_2,
        nvl(merch_addrs.street, '')                 AS street,
        nvl(merch_addrs.postalcode, '')             AS postal_code,
        nvl(merch_addrs.city, '')                   AS city,
        nvl(merch_addrs.state, '')                  AS state,
        nvl(merch_addrs.country, '')                AS country,
        nvl(merch.maid, '')                         AS maid,
        nvl(curr_cattr.curr_bnpl_inst_fee_flag, '') AS inst_fee_flag
    FROM
        merch
        LEFT JOIN merch dev ON merch.record_idt = dev.parent_contract_idt
                               AND dev.personal_account NOT LIKE 'POS%'
        LEFT OUTER JOIN curr_cattr ON curr_cattr.contract_idt = merch.record_idt
        LEFT OUTER JOIN prev_cattr ON prev_cattr.contract_idt = merch.record_idt
        JOIN merch_addrs ON merch_addrs.contract_idt = merch.record_idt
    WHERE
            curr_cattr.curr_bnpl_inst_fee_flag = 'N'
        AND prev_cattr.prev_bnpl_inst_fee_flag = 'Y'
)
SELECT
    first_name     AS legally_registered_merchant_name,
    address_line_1 AS address_line_1,
    address_line_1 AS address_line_2,
    city           AS city,
    state          AS state_province,
    postal_code    AS postal_code,
    ''             AS merchant_website_url,
    address_line_1 AS merchant_doing_business_as_dba_name,
    maid           AS mastercard_assigned_identifier_maid,
    ''             AS dun_bradstreet_d_u_n_s_number,
    ''             AS apple_pay_acceptance_flag,
    ''             AS apple_pay_merchant_id,
    ''             AS google_pay_acceptance_flag,
    ''             AS google_pay_merchant_id,
    ''             AS samsung_pay_acceptance_flag,
    ''             AS samsung_pay_merchant_id,
    '019537'       AS institution_ica,
    country        AS country
FROM
    full_q