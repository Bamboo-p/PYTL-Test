__version__ = "230426.1"
__job_name__ = "PyTL_IS_XlsReports_AQ_WECHAT_TMS_EXTRACT"
__bat_files__ = []

