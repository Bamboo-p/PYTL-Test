/*
* Code for AQ_WECHAT_TMS_EXTRACT
* PyTL_IS_XlsReports_AQ_WECHAT_TMS_EXTRACT = AQ_WECHAT_TMS_EXTRACT.sql
* Version history:
* 230317.1 : NIBOA-8243 : AngajalaK  : Initial development
* 230328.1 : NIBOA-8243 : PrabirK    : Four new fields (MCC, business_category_code, contact_phone, contact_email) added to report and changing field name from wechat_mid to sub_merchant_id
* 230426.1 : NIBOA-8434 : PrabirK    : Corrected the logic to fetch data for Business Category field
*/
WITH inst AS (
    SELECT
        id,
        code AS instcode
    FROM
        dwh.dwd_institution
    WHERE
            record_state = 'A'
        AND code = :ORG
), contract AS (
    SELECT
        cntr.record_idt,
        cntr.parent_contract_idt,
        cntr.personal_account,
        cntr.add_info         AS cntr_add_info,
        cntr.record_date_from AS cntr_record_date_from,
        CASE
            WHEN cntr.personal_account LIKE 'POS%' THEN
                'Y'
            ELSE
                'N'
        END                   AS is_dummy,
		-- [+][begin] 230328.1 = PrabirK = NIBOA-8243
		(
        SELECT
            MAX(dvc.mcc)
        FROM
            dwh.dwd_device dvc
        WHERE
                dvc.record_state = 'A'
            AND dvc.main_contract_idt = cntr.record_idt
        )                     AS mcc
		-- [+][end]   230328.1 = PrabirK = NIBOA-8243
    FROM
             dwh.dwd_contract cntr
        JOIN inst ON inst.id = cntr.institution_id
    WHERE
            cntr.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND cntr.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        -- AND cntr.record_idt = 415047880
), addrs AS (
    SELECT
        contract_idt,
        MAX(decode(address_type_code, 'STMT_ADDR', phone, NULL))          AS phone,
        MAX(decode(address_type_code, 'STMT_ADDR', e_mail, NULL))         AS e_mail
    FROM
             dwh.opt_v_address adr
        JOIN inst ON inst.id = adr.institution_id
    WHERE
            adr.record_state = 'A'
        AND adr.address_type_code IN ( 'STMT_ADDR', 'PAYM_ADDR' )
    GROUP BY
        contract_idt
)

SELECT
    :ORG AS org,
    merchant,
    terminal,
	-- [+][begin] 230328.1 = PrabirK = NIBOA-8243
	mcc,
	business_category_code,
	contact_phone,
	contact_email,
	-- [+][end]   230328.1 = PrabirK = NIBOA-8243
    sub_merchant_id -- [*]230328.1 = PrabirK = NIBOA-8243
FROM
    (
        SELECT
            dev.record_idt                                                  AS terminal_id,
            dev.personal_account                                            AS terminal,
            merch.record_idt                                                AS merchant_id,
            merch.personal_account                                          AS merchant,
            dwh.sy_convert.get_tag_value(merch.cntr_add_info, 'WECHAT_MID') AS sub_merchant_id, -- [*]230328.1 = PrabirK = NIBOA-8243
			dwh.sy_convert.get_tag_value(merch.cntr_add_info, 'BUSINESS_CAT') AS business_category_code, -- [*]230426.1 = PrabirK = NIBOA-8434
            merch.cntr_record_date_from,
			-- [+][begin] 230328.1 = PrabirK = NIBOA-8243
			merch.mcc                                                       AS mcc,
			addrs.phone                                                     AS contact_phone,
			addrs.e_mail                                                    AS contact_email
			-- [+][end]   230328.1 = PrabirK = NIBOA-8243
        FROM
            contract merch
            LEFT JOIN contract dev ON dev.parent_contract_idt = merch.record_idt
                                      AND nvl(dev.is_dummy, 'N') = 'N'
			LEFT JOIN addrs ON addrs.contract_idt = merch.record_idt
        WHERE
            instr(merch.cntr_add_info, 'WECHAT_MID') > 0
    )
WHERE
    cntr_record_date_from = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
ORDER BY
    merchant