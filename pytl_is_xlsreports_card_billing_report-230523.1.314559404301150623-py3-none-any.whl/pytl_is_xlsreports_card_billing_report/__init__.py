__version__ = "230523.1"
__job_name__ = "PyTL_IS_XlsReports_CARD_BILLING_REPORT"
__bat_files__ = []

