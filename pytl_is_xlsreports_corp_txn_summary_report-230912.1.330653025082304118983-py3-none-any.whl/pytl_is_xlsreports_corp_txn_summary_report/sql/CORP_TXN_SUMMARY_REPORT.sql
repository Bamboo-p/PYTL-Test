/*
230501.1 : BharathG : D2C-84 : Initial version : corporate wise transaction summary report
230530.2 : BharathG : D2C-84 : Updating the final report format
230610.1 : BharathG : D2C-84 : logic for direction updated for way4 calculation
230831.1 : GaukharA: D2C-283 : bin digits were changed from 6 to 8
230912.1 : GaukharA: D2C-283 : date range was change
*/
with inst as (
    select /*+ no_merge */
           inst.id,
           inst.branch_code,
           inst.name,
           inst.branch_code_posting
      from (select i.branch_code,
                   i.posting_institution_id,
                   i.id,
                   i.name,
                   i2.branch_code branch_code_posting
              from dwh.dwd_institution i
              join dwh.dwd_institution i2
                on i.posting_institution_id = i2.id
             where i.record_state           = 'A') inst
        start with inst.branch_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                          from dual
                                    connect by regexp_substr(:ORG , '[^,]+', 1, level) is not null)
        connect by decode(inst.posting_institution_id, inst.id, null, inst.posting_institution_id) = prior inst.id
               and level <= 2
    ),
mpoint as (
    select /*+no_merge*/
          mp.local_date, 
          mp.calendar_date, 
          lag(mp.calendar_date) over (order by mp.local_date asc) prev_calendar_date
     from dwh.etl_consist_point mp
     join dwh.etl_consist_type mt
       on mp.etl_consist_type__id = mt.id
      and mt.code       = 'END_DAY'
      and mt.amnd_state = 'A'
      and mp.amnd_state = 'A'
      and mp.local_date >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')-5--230912.1 : GaukharA: D2C-283 : date range was change
   ),
card as (
    select /*+no_merge full(cd) use_hash(i) swap_join_inputs(i) */
           cd.pan,
           cd.main_contract_idt,
           cd.record_idt,
           i.branch_Code as org
      from dwh.dwd_card cd
      join inst i
        on cd.institution_id = i.id
     where cd.record_state = 'A'
    ),
clearing_docs_w4 as (
    select /*+no_merge leading(mp) push_pred(d) index(d file_info_date)*/ 
           mp.local_date as banking_date,
           d.*
      From (select /*+no_merge*/ 
                  local_date, 
                  max(prev_calendar_date) as prev_calendar_date, 
                  max(calendar_date) as calendar_date 
             from mpoint 
            where local_date = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') group by local_date
            ) mp
      join dwh.v_c$opt_v_mp_file_info d
        on d.creation_date between mp.prev_calendar_date and mp.calendar_date            
       and d.file_type   = :P_FILE_TYPE    
    ),
w4_part_1 as (
    select /*+no_merge leading(d) use_hash(cd) use_hash(cds) use_hash(t) swap_join_inputs(d)*/
           d.file_id,
           d.banking_date,
           nvl(cd.main_contract_idt,cds.main_contract_idt) as contract_idt,
           substr(nvl(cd.pan,cds.pan),1,8) as bin,
           nvl(cd.org,cds.org) as org,
           d.settl_amount,
           d.settl_curr,
           d.trans_name,
           - nvl(t.direction,1) as direction /*D2C-84 : logic for direction updated for way4 calculation*/
      From clearing_docs_w4 d
--[+]begin : BharathG : D2C-84 : logic for direction updated for way4 calculation
 left join dwd_transaction_type t
        on d.request_category = t.request_category
       and d.trans_type = t.record_idt
       and t.record_state = 'A'
--[+]end : BharathG : D2C-84 : logic for direction updated for way4 calculation
 left join dwh.card cd
        on cd.pan = d.target_number
 left join dwh.card cds
        on cds.pan = d.source_number
     where nvl(cd.pan,cds.pan) is not null
    ),
w4_final_result as (
    select /*+no_merge leading(r)*/
           r.bin,
           hie.root_corporate_id as corporate_id,
           count(1) as incoming_file_count,
           sum(r.settl_amount * r.direction) as incomimg_file_volume,
           cur.name as incoming_file_currency
      from w4_part_1 r
      join dwh.opt_dm_nice_contract_hierarchy hie
        on hie.contract_idt = r.contract_idt
       and hie.org = r.org
      join dwh.dwd_currency cur
        on cur.code = r.settl_curr
       and cur.record_state = 'A'
  group by r.bin,
           hie.root_corporate_id,
           cur.name
    ),
clearing_docs_dm as (
    select /*+no_merge use_hash(mp) swap_join_inputs(mp) full(d)*/ 
           d.*
      From mpoint mp
      join dwh.dwf_clearing_message d
        on d.file_creation_date between mp.prev_calendar_date and mp.calendar_date
       and d.banking_date = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
       and d.type_code    = :P_FILE_TYPE        
     where mp.local_date  = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')      
    ),
dm_part_1 as (
    select /*+ no_merge full(t) use_hash(d) use_hash(cd) use_hash(i) swap_join_inputs(i) use_hash(tt) swap_join_inputs(tt) use_hash(cur) swap_join_inputs(cur)*/
           d.primary_file_idt file_id,
           substr(cd.pan,1,8) as bin,
           d.banking_date,
           t.root_corporate_id,
           t.settl_amount,
           cur.name as txn_dump_currency,
           tt.name as trans_name,
           - nvl(t.direction,1) as direction
      From dwh.opt_dm_nice_transaction_info t
      join inst i
        on t.org = i.branch_code
      join clearing_docs_dm d
        on t.primary_doc_idt = d.doc_idt
      join dwh.dwd_transaction_type tt
        on tt.id  = t.transaction_type_id
       and tt.record_state = 'A'
      join card cd
        on nvl(t.target_card_idt,t.source_card_idt) =  cd.record_idt
      join dwh.dwd_currency cur
        on cur.code = t.settl_currency
       and cur.record_state = 'A'
     where t.banking_date  = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
       and instr(t.oper_type_add_info,'STMT_TURNOVERS=FEE;') = 0
    ),
dm_final_result as (
    select /*+materialize*/
           bin,
           root_corporate_id as corporate_id,
           count(1) as txn_dump_count,
           sum(settl_amount * direction) as txn_dump_volume,
           txn_dump_currency
      From dm_part_1
  group by bin,
           root_corporate_id,
           txn_dump_currency
    )   
    select w4.bin,
           w4.corporate_id,
           w4.incoming_file_currency as currency,
           dm.txn_dump_count,
           dm.txn_dump_volume,
           w4.incoming_file_count,
           w4.incomimg_file_volume
      from w4_final_result w4
 left join dm_final_result dm
        on w4.bin          = dm.bin
       and w4.corporate_id = dm.corporate_id
       and w4.incoming_file_currency = dm.txn_dump_currency