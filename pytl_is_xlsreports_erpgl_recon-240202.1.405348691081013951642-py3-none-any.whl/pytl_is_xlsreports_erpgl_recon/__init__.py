__version__ = "240202.1"
__job_name__ = "PyTL_IS_XlsReports_ERPGL_RECON"
__bat_files__ = []

