/* MC_RECON_MATCHED.sql
220607.1 = Robby.Dasimo = OPKSAIC-3443
220802.1 = Robby.Dasimo = OPKSAIC-4666 use P_REPORT_DATE and added filter to show 1 day data only
220901.1 = DenisKa      = OPKSAIC-4823: code normilization, adding mandatory column ORG into responce
230306.1 = Robby.Dasimo = ETSLT-301: performance optimization & date parameter change
230525.1 = BharathG     = OPKSAIC-5312: adding merchant name and location details
230620.1 = BharathG     = OPKSAIC-5411: column alias name change
231122.1 = BharathG     = OPKSAIC-5654: trace_id column addition
240131.1 = ShaliniU     = AEDU-153 : Added P_FILE_TYPE to support both MC and VISAin data and renamed job
240201.1 = ShaliniU     = AEDU-153 : Logic changes for source_2 field
240201.1 = ShaliniU     = AEDU-153 : Logic changes to consider VISAIN files
*/
with memberid as (
    select '%'||bt.member_id||'%' member_id
    from ows.contr_subtype cs join ows.f_i fi
        on cs.f_i = fi.id
        and fi.bank_code = :ORG
    join ows.bin_table bt
        on bt.id = cs.bin_record
    where cs.con_cat = 'C'
        and cs.ccat <> 'A'
        and cs.amnd_state = 'A'
)
--[+] begin 240131.1 = AEDU-153
,file_type_list as (
         select   
           trim(regexp_substr(:P_FILE_TYPE, '[^,]+', 1, level)) FILE_TYPE
      from dual
connect by regexp_substr(:P_FILE_TYPE, '[^,]+', 1, level) is not null
)
--[+] end 240131.1 = AEDU-153
SELECT
    :ORG                                                                                "ORG"
    ,doc.target_number                                                                  "card_number"
    ,opt_erpgl.card_number                                                              "alternate_number"
    ,opt_erpgl.auth_code                                                                "auth_code"
    ,opt_erpgl.rrn                                                                      "rrn"
    ,doc.ps_ref_number                                                                  "trace_id"
    ,doc.trans_details||' '||doc.trans_city||' '||doc.trans_country                     "Merchant_name_and_location"
    ,opt_erpgl.trans_amount                                                             "trans_amount_1"
    ,opt_erpgl.trans_curr                                                               "trans_curr_1"
    ,opt_erpgl.settl_amount                                                             "settl_amount_1"
    ,opt_erpgl.settl_curr                                                               "settl_curr_1"
    ,opt_erpgl.trans_direction                                                          "trans_dir_1"
    ,doc.trans_amount                                                                   "trans_amount_2"
    ,doc.trans_curr                                                                     "trans_curr_2"
    ,doc.settl_amount                                                                   "settl_amont_2"
    ,doc.settl_curr                                                                     "settl_curr_2"
    ,DECODE(trans_type.dr_cr * DECODE(doc.request_category, 'R', -1, 1), -1, 'D', 'C')  "trans_dir_2"
    ,opt_erpgl.settl_amount - doc.settl_amount                                          "diff"
    ,doc.trans_date                                                                     "trans_date"
    ,opt_erpgl.account_number                                                           "account_number"
    ,opt_erpgl.posting_date                                                             "posting_date"
    ,opt_erpgl.entry_date                                                               "entry_date"
    ,'ERPGL'                                                                            "source_1"
    ,decode (:P_FILE_TYPE,'MIN','MC','VIN','VISA')                                      "source_2" --[*] 240201.1 = AEDU-153
    ,TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')                                              "recon_date"
FROM
    ows.opt_erpgl
    JOIN ows.doc ON doc.id = opt_erpgl.doc__id
    JOIN ows.trans_type ON doc.trans_type = trans_type.id
WHERE
    opt_erpgl.fi_code = :ORG
    AND opt_erpgl.entry_date >= trunc(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'))
                                - nvl(ows.opt_util.institution_parm(ows.opt_util.get_fi_id_by_branch(:ORG), 'ERPGL_RECON_DAYS'), 28)
    AND doc.settl_amount = opt_erpgl.settl_amount
    AND doc.id IN (
        SELECT
            doc__id
        FROM
            ows.original_doc
        WHERE
            file_info__id IN (
                SELECT
                    id
                FROM
                    ows.file_info join memberid
                    on file_info.file_id like memberid.member_id
                WHERE
                    file_info.file_type in (select FILE_TYPE from file_type_list) --[*] 240131.1 = AEDU-153
                    AND decode(file_info.file_type,'MIN',file_info.file_info__oid ,'VIN', file_info.id ) IS NOT NULL  --[*] 240202.1 = AEDU-153
                    AND file_info.creation_date between trunc(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                                                    and trunc(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') ) + 1
            )
    )
