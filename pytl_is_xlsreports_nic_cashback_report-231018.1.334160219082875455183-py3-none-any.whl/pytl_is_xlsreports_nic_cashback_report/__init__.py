__version__ = "231018.1"
__job_name__ = "PyTL_IS_XlsReports_NIC_CASHBACK_REPORT"
__bat_files__ = []

