__version__ = "220429.1"
__job_name__ = "PyTL_IS_XlsReports_NIC_MONTHLY_TOKEN_DETAIL"
__bat_files__ = []

