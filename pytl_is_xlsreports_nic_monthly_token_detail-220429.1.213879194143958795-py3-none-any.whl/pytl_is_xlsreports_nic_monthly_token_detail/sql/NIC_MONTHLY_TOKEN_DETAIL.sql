/*
NIC_MONTHLY_TOKEN_DETAIL.sql
08-04-2022 : ENG-4401 : Bharath : Total Active/new token Detail : initial requirement

             Query is applicable for total active token and total new token reports 
			 Below Input parameters needs to be passed
			 
			 ORG = Bank code
			 TOKEN_LIST = Wallet types , multiple wallets can be provided with comma separated 
			              ex : 'APPLE PAY,GOOGLE PAY,...'
			 RETURN_EXID_CARD = to display alternate card number pass 'YES', else Parameter can be ignored. Default Value is 'NO'
			 P_REPORT_DATE = Banking date , this report needs to be run on 20th of every month
			 REPORT_TYPE = to generate total active token report pass 'TOTAL_ACTIVE'
			               to generate total new token report pass 'TOTAL_NEW'
             MASK_CARD = to display masked card number pass 'YES' else 'NO' , For ALMB Masked card number needs to be displayed 
220505 : ALMB-788 : Shalini : Included trunc() for date_from
220510 : ALMB-806 : Shalini : Logic changes for report type
220511 : ALMB-807 : Shalini : added token_number field
220518 : ALMB-807 : Shalini : changes in masking logic of token_number field
*/
with inst as (
    select /*+no_merge materialize*/
          id,
          bank_code,
          name
      from (select fi.bank_code,
                   fi.posting_in,
                   fi.id,
                   fi2.bank_code as bank_code_posting,
                   fi.name
             from ows.f_i fi
             join ows.f_i fi2 
               on fi.posting_in = fi2.id
            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
            ) inst
      start with inst.bank_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                      from dual
                                connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
                                   )
      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
    ),
wallet_names as (
    select /*+no_merge materialize*/  
           trim(regexp_substr(:TOKEN_LIST, '[^,]+', 1, level)) token
      from dual
connect by regexp_substr(:TOKEN_LIST, '[^,]+', 1, level) is not null
    ),
token_meta as (
    select /*+no_merge materialize*/ 
          coalesce(org_conf.code, org_conf.filter2, default_conf.code, default_conf.filter2) as tkn_req_id
     from ( select *
              from ows.sy_handbook
             where amnd_state = 'A'
               and group_code like 'TOKEN_REQUESTOR%'
               and filter5 = :ORG
               and name in (select token from wallet_names)) org_conf
full join ( select *
              from ows.sy_handbook tt
             where tt.filter = '000'
               and tt.name in (select token from wallet_names)
               and tt.group_code like 'TOKEN_REQUESTOR%'
               and tt.amnd_state = 'A') default_conf
       on (org_conf.filter2 = default_conf.filter2) 
    ),
parm_id as (
    select /*+no_merge materialize*/ 
          parm.id 
     from ows.td_auth_parm parm
     join ows.td_auth_type t 
       on parm.td_auth_type__oid = t.id
      and (t.code   = :ORG || '-TOKEN-VTS'
       or t.code    = :ORG || '-TOKEN-MDES' )
    where parm.code = 'T_STATUS'
      and parm.amnd_state = 'A'
    ),
auth_type as (
    select /*+no_merge materialize*/
          id 
     From ows.td_auth_type
    where code        = 'EXID'
      and amnd_state  = 'A'
    ),
exid as (
    select /*+no_merge materialize*/
           e.acnt_contract__id,
           e.auth_idt
      from ows.td_auth_sch e
      join auth_type ty
        on e.auth_type         = ty.id
     where e.amnd_state        = 'A'
       and e.is_ready          = 'Y'
    )
    
    select /*+ leading(m) */ distinct 
          inst.bank_code     as ORG,		  
          inst.bank_code     as FI_CODE,
          prd.code           as PRODUCT_CODE,
          case when substr(upper(nvl(:MASK_CARD,'N')),1,1) = 'N' then 
               decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',e.auth_idt, c.contract_number) 
               when substr(upper(nvl(:MASK_CARD,'N')),1,1) = 'Y' then                
               decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)), 'Y',e.auth_idt, 
               substr(c.contract_number,1,4)||lpad('*',8,'*')||substr(c.contract_number,-4)) end as CARD_NUMBER,		  
          m.token_req_id     as TOKEN_REQUESTOR_ID,
		  m.effective_date   as CREATION_DATE,
		  m.token_status     as TOKEN_STATUS,          
          --regexp_replace(m.auth_idt, '(^\d{6})(.*)(\d{4}$)','\1******\3') as TOKEN_NUMBER --[+] 220511 : ALMB-807
		  rpad('*',length(m.auth_idt)-length(substr(m.auth_idt,-4)),'*')||substr(m.auth_idt,-4) as TOKEN_NUMBER --[+] 220518 : ALMB-807
     from (select /*+ no_merge full(t) */
                 t.id,
                 t.auth_idt,
                 t.acnt_contract__id,
                 to_char(t.amnd_date, 'yyyy-mm-dd')                      AS effective_date,
                 ows.opt_util.get_td_auth_parm_val(t.id, 'TOKEN_REQ_ID') AS token_req_id,
                 ows.opt_util.get_td_auth_parm_val(t.id, 'T_STATUS')     AS token_status
                 
            from ows.td_auth_sch t
            join ows.td_auth_type tat 
              on tat.id = t.auth_type
            join inst 
              on (tat.code = inst.bank_code ||'-TOKEN-MDES' 
              or tat.code  = inst.bank_code ||'-TOKEN-VTS')
			join ows.td_auth_val td_auth_val1 
              on t.id         = td_auth_val1.td_auth_sch__oid
             /* and td_auth_val1.parm_value = 'Active' */ --[-] 220510 : ALMB-806
             and td_auth_val1.amnd_state = 'A'
			join parm_id
			  on td_auth_val1.auth_parm  = parm_id.id
           where t.amnd_state = 'A'
             and t.is_ready   = 'Y'
			 and (('TOTAL_ACTIVE' = :REPORT_TYPE and td_auth_val1.parm_value = 'Active') --[*] 220510 : ALMB-806
			  or ('TOTAL_NEW'     = :REPORT_TYPE
             --[*] begin 220505 : ALMB-788
			 and trunc(t.date_from)  >= add_months(to_date(:P_REPORT_DATE, 'dd-mm-yyyy'),-1) + 1
             and trunc(t.date_from)  <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')))
			 --[*] end 220505 : ALMB-788
           ) m
           
       join ows.acnt_contract c 
         on m.acnt_contract__id = c.id
       join inst 
         on c.f_i = inst.id
	 
	   join ows.appl_product prd
	     on prd.internal_code = c.product
	    and prd.amnd_State    = 'A'
	  
	   join token_meta tkn
         on tkn.tkn_req_id = m.token_req_id
	   
 left join exid e
        on e.acnt_contract__id = c.id
		
