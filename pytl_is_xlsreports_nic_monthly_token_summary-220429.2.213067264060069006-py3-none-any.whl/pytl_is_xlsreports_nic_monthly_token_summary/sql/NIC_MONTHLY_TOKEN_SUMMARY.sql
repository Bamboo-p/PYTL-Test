/*
NIC_MONTHLY_TOKEN_SUMMARY.sql
11-04-2022 : ENG-4401 : Bharath : Total Active/new token summary : initial requirement

             Query is applicable for total active token and total new token summary reports 
			 Below Input parameters needs to be passed
			 
			 ORG = Bank code
			 TOKEN_LIST = Wallet types , multiple wallets can be provided with comma separated 
			              ex : 'APPLE PAY,GOOGLE PAY,...'
			 P_REPORT_DATE = Banking date , this report needs to be run on 20th of every month
			 REPORT_TYPE = to generate total active token report pass 'TOTAL_ACTIVE'
			               to generate total new token report pass 'TOTAL_NEW'
220505 : ALMB-788 : Shalini : Included trunc() for date_from
220510 : ALMB-806 : Shalini : Logic changes for report type
*/
with inst as (
    select /*+no_merge materialize*/
          id,
          bank_code,
          name
      from (select fi.bank_code,
                   fi.posting_in,
                   fi.id,
                   fi2.bank_code as bank_code_posting,
                   fi.name
             from ows.f_i fi
             join ows.f_i fi2 
               on fi.posting_in = fi2.id
            where fi.amnd_state = 'A' and fi2.amnd_state = 'A'
            ) inst
      start with inst.bank_code in (select trim(regexp_substr(:ORG, '[^,]+', 1, level)) org
                                      from dual
                                connect by regexp_substr(:ORG, '[^,]+', 1, level) is not null
                                   )
      connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
    ),
wallet_names as (
    select /*+no_merge materialize*/  
           trim(regexp_substr(:TOKEN_LIST, '[^,]+', 1, level)) token
      from dual
connect by regexp_substr(:TOKEN_LIST, '[^,]+', 1, level) is not null
    ),
token_meta as (
    select /*+no_merge materialize*/ 
          coalesce(org_conf.code, org_conf.filter2, default_conf.code, default_conf.filter2) as tkn_req_id
     from ( select *
              from ows.sy_handbook
             where amnd_state = 'A'
               and group_code like 'TOKEN_REQUESTOR%'
               and filter5 = :ORG
               and name in (select token from wallet_names)) org_conf
full join ( select *
              from ows.sy_handbook tt
             where tt.filter = '000'
               and tt.name in (select token from wallet_names)
               and tt.group_code like 'TOKEN_REQUESTOR%'
               and tt.amnd_state = 'A') default_conf
       on (org_conf.filter2 = default_conf.filter2) 
    ),
parm_id as (
    select /*+no_merge materialize*/ 
          parm.id 
     from ows.td_auth_parm parm
     join ows.td_auth_type t 
       on parm.td_auth_type__oid = t.id
      and (t.code   = :ORG || '-TOKEN-VTS'
       or t.code    = :ORG || '-TOKEN-MDES' )
    where parm.code = 'T_STATUS'
      and parm.amnd_state = 'A'
    )
    
    select /*+ leading(m) */
          inst.bank_code     as ORG,		  
          inst.bank_code     as FI_CODE,
          prd.code           as PRODUCT_CODE,
          m.token_req_id     as TOKEN_REQUESTOR_ID,
          count(1)           as TOTAL_COUNT_OF_ACTIVE_TOKENS
          
          
     from (select /*+ no_merge full(t) */
                 t.id,
                 t.auth_idt,
                 t.acnt_contract__id,
                 ows.opt_util.get_td_auth_parm_val(t.id, 'TOKEN_REQ_ID') AS token_req_id
                 
            from ows.td_auth_sch t
            join ows.td_auth_type tat 
              on tat.id = t.auth_type
            join inst 
              on (tat.code = inst.bank_code ||'-TOKEN-MDES' 
              or tat.code  = inst.bank_code ||'-TOKEN-VTS')
			join ows.td_auth_val td_auth_val1 
              on t.id         = td_auth_val1.td_auth_sch__oid
             /*and td_auth_val1.parm_value = 'Active'*/ --[-] 220510 : ALMB-806
             and td_auth_val1.amnd_state = 'A'
			join parm_id
			  on td_auth_val1.auth_parm  = parm_id.id
           where t.amnd_state = 'A'
             and t.is_ready   = 'Y'
			 and (('TOTAL_ACTIVE' = :REPORT_TYPE and td_auth_val1.parm_value = 'Active') --[*] 220510 : ALMB-806
			  or ('TOTAL_NEW'     = :REPORT_TYPE
			 --[*] begin 220505 : ALMB-788 
             and trunc(t.date_from)  >= add_months(to_date(:P_REPORT_DATE, 'dd-mm-yyyy'),-1) + 1
             and trunc(t.date_from)  <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')))
			 --[*] end 220505 : ALMB-788
           ) m
           
     join ows.acnt_contract c 
       on m.acnt_contract__id = c.id
     join inst 
       on c.f_i = inst.id
	 
	 join ows.appl_product prd
	   on prd.internal_code = c.product
	  and prd.amnd_State    = 'A'
	  
     join token_meta tkn
       on tkn.tkn_req_id = m.token_req_id

 group by inst.bank_code,prd.code,m.token_req_id
