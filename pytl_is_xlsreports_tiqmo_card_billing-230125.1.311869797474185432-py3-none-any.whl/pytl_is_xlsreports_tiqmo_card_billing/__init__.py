__version__ = "230125.1"
__job_name__ = "PyTL_IS_XlsReports_TIQMO_CARD_BILLING"
__bat_files__ = []

