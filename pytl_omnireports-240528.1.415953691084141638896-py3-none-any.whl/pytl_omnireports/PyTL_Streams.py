########################################################################################################################
########################################################################################################################
import typing
import openpyxl
import cx_Oracle
import decimal
import csv
from collections import defaultdict

import pytl_core
import pytl_core.pytl_globals as pytl_globals
from pathlib import Path
import zipfile
from n0struct import (
    n0debug,
    n0debug_calc,
    n0debug_object,
    n0info,
    n0print,
    generate_complex_csv_row,
    date_timestamp,
    n0dict,
    isnumber,
    to_date,
)

########################################################################################################################
########################################################################################################################
n0print(f"{'='*17} START: Importing in {__file__}")
try:
    # Could be imported ONLY if it's run as NORMAL py
    n0print(f"=-= NORMAL {'=-='*2} from _params import __params__")
    from _params import __params__
except Exception as ex:
    n0print(f"{'#'*17} not NORMAL")
    try:
        # Could be imported ONLY if it's run as MODULE
        n0print(f"=-= MODULE {'=-='*2} from ._params import __params__")
        from ._params import __params__
    except Exception as ex:
        n0print(f"{'#'*17} FATAL ERROR: Importing in {__file__} as MODULE: {ex}")

        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_type, exc_value, exc_traceback = sys.exc_info() # most recent (if any) by default
        traceback_details = {
                             'filename': exc_traceback.tb_frame.f_code.co_filename,
                             'lineno'  : exc_traceback.tb_lineno,
                             'name'    : exc_traceback.tb_frame.f_code.co_name,
                             'type'    : exc_type.__name__,
                             'message' : exc_value.message, # or see traceback._some_str()
                            }
        n0print(traceback.format_exc())
        n0print(traceback_details)

        exit(-999)

n0print(f"{'-'*17} END: Importing in {__file__}")

########################################################################################################################
########################################################################################################################
class PyTL_StreamBase(object):
    ############################################################################
    ############################################################################
    def __init__(self, query_index: int, sql_query_params: dict):
        n0print("PyTL_StreamBase.__init__: Start", level="DEBUG")
        # self.file_path = file_path

        self.sql_query_params = sql_query_params

        # Written rows total count (without title) from all queries into current file == sum(self.saved_rows_count_per_query.values())
        self.saved_rows_count = 0
        self.aggregate_count  = defaultdict(int)
        self.aggregate_sum    = defaultdict(float)

        # Written rows count (without header) from current query into current file
        self.last_query_index           = query_index
        self.saved_rows_count_per_query = {query_index: 0}
        self.aggregate_count_per_query  = {query_index: defaultdict(int)}
        self.aggregate_sum_per_query    = {query_index: defaultdict(float)}

        # Buffer for last row
        self.last_row = None

        ########################################################################
        ## Generate header during 1st iteration of each SQL file, based on dict keys
        __params__DB_CONNECTIONS_SOURCE_DB = __params__['DB_CONNECTIONS'][sql_query_params['SOURCE_DB']]
        self.columns_data_types = {
            item[0]: item[1:]
            for item in __params__DB_CONNECTIONS_SOURCE_DB.current_cursor_metadata
        }
        if sql_query_params['ONLY_COLUMNS']:
            self.header = sql_query_params['ONLY_COLUMNS']
        else:
            sql_query_params__SKIP_COLUMNS = sql_query_params['SKIP_COLUMNS']
            self.header = [
                column_name
                for column_name in self.columns_data_types
                if column_name not in sql_query_params__SKIP_COLUMNS
            ]


        if (sql_query_params__ADJUST_COLUMNS:=sql_query_params['ADJUST_COLUMNS']):
            columns_with_not_defined_width = [
                column_name for column_name in self.header if column_name not in sql_query_params__ADJUST_COLUMNS
            ]
            if columns_with_not_defined_width:
                raise SyntaxError(f"Column{'s' if len(columns_with_not_defined_width) > 1 else ''} "
                                  f"{','.join(columns_with_not_defined_width)} "
                                  f"{'have' if len(columns_with_not_defined_width) > 1 else 'has'} "
                                   "not defined width in parameter ADJUST_COLUMNS="
                                   "<column name1>=[align]<width1>[,<column nameN>=[align]<widthN>]"
                )

        n0print("PyTL_StreamBase.__init__: End", level="DEBUG")
    ############################################################################
    ############################################################################
    def write_header(self):
        sql_query_params__COLUMN_ALIASES = self.sql_query_params['COLUMN_ALIASES']
        self.last_row = [
            sql_query_params__COLUMN_ALIASES.get(column_name, column_name)
            for column_name in self.header
        ]
        self.mask_and_write_last_row(0) # title - no cut
    ############################################################################
    ############################################################################
    def mask_and_write_last_row(self, block_type:int = 1):
        n0print("PyTL_StreamBase.mask_and_write_last_row", level="DEBUG")
        """
        block_type:
            0   = title - no cut
            1   = header (1st row) or body (depends of ) columns in query#n
            2   = trailer (last row) columns in query#n
        """
        if self.last_row is None:
            # Skip first row -- it's not saved yet into self.last_row
            return

        if block_type:
            if self.saved_rows_count_per_query[self.last_query_index] == 0:
                block_type = 0 # header (1st row)
            max_columns = int(self.sql_query_params['COLUMNS_QUANTITY'][block_type])
        else:
            # title - no cut
            max_columns = 9999

        if self._mask_and_write_columns(self.last_row[0:max_columns], self.header[0:max_columns]) and max_columns != 9999:
            # Written rows count (without title) from current query
            self.saved_rows_count_per_query[self.last_query_index] += 1
            # Written rows total count (without title) from all queries into current file == sum(self.saved_rows_count_per_query.values())
            self.saved_rows_count += 1

        self.last_row = None

    ############################################################################
    ############################################################################
    def _mask_row(self, row: str) -> list:
        n0print("PyTL_StreamBase._mask_row", level="DEBUG")
        n0debug("row")
        for _pattern,_replace in self.sql_query_params['MASK_PATTERN'].items():
            n0debug("_pattern")
            n0debug("_replace")
            row = _pattern.sub(_replace, row)
        n0debug("row")
        return row
    ############################################################################
    ############################################################################
    def _mask_columns(self, column_values:list, column_names:list) -> list:
        n0print("PyTL_StreamBase._mask_columns", level="DEBUG")
        # NICORE-82: Fixed the issue when masking is enabled
        column_values = list(column_values) # To mitigate TypeError: 'generator' object is not subscriptable
        # if column_names is None, it means than it is header and must not be masked by column name
        if column_names:
            for column_i,column_name in enumerate(column_names):
                '''
                Incomming parameter:
                "MASK_COLUMNS=CARD_NO=([34569][0-9]{5})([0-9]{6})([0-9]{4})=\1xxxxxx\3,ACCNT_NO=0=o|1=i|2=Z|3=E|4=<|5=S|6=b|7=>|8=B|9=g"
                =>
                self.sql_query_params['MASK_COLUMNS'] == <dict  2> {
                    "CARD_NO": <dict  1> {<re.Pattern> re.compile('([34569][0-9]{5})([0-9]{6})([0-9]{4})'): "\1xxxxxx\3"},
                    "ACCNT_NO": <dict  10> {
                        <re.Pattern> re.compile('0'): "o",
                        <re.Pattern> re.compile('1'): "i",
                        <re.Pattern> re.compile('2'): "Z",
                        <re.Pattern> re.compile('3'): "E",
                        <re.Pattern> re.compile('4'): "<",
                        <re.Pattern> re.compile('5'): "S",
                        <re.Pattern> re.compile('6'): "b",
                        <re.Pattern> re.compile('7'): ">",
                        <re.Pattern> re.compile('8'): "B",
                        <re.Pattern> re.compile('9'): "g"
                    }
                }
                '''
                # n0debug_calc(self.sql_query_params['MASK_COLUMNS'].get(column_name, {}), f"sql_query_params['MASK_COLUMNS']['{column_name}']")
                # n0debug_calc(column_values[column_i], f"column_values[{column_i}]")
                for _pattern,_replace in self.sql_query_params['MASK_COLUMNS'].get(column_name, {}).items():
                    # n0debug("_pattern")
                    # n0debug("_replace")
                    # n0debug_calc(column_values[column_i], f"column_values[{column_i}]")
                    column_values[column_i] = _pattern.sub(_replace, column_values[column_i])
                    # n0debug_calc(column_values[column_i], f"column_values[{column_i}]")
                # n0debug_calc(column_values[column_i], f"column_values[{column_i}]")
            # n0debug("column_values")
        return column_values
    ############################################################################
    ############################################################################
########################################################################################################################
########################################################################################################################
class _PyTL_StreamTXTbase(PyTL_StreamBase):
    def __init__(self, query_index: int = None, sql_query_params: dict = None, file_path: str = None, opened_streams = None, previous_stream = None):
        n0print("_PyTL_StreamTXTbase.__init__: Start", level="DEBUG")
        if query_index is None:
            raise RuntimeError(f"Incorrect call of _PyTL_StreamTXTbase.__init__({query_index=}, {sql_query_params=}, {file_path=}, {previous_stream=})")

        # n0debug_object("self")
        super().__init__(query_index, sql_query_params)
        # n0debug_object("self")

        n0print("_PyTL_StreamTXTbase.__init__: Continue", level="DEBUG")

        if previous_stream:
            # Written rows total count (without title) from all queries into current file == sum(self.saved_rows_count_per_query.values())
            self.saved_rows_count = previous_stream.saved_rows_count
            self.aggregate_count  = previous_stream.aggregate_count
            self.aggregate_sum    = previous_stream.aggregate_sum
            # Written rows count (without header) from previous queries into current file
            self.saved_rows_count_per_query.update(previous_stream.saved_rows_count_per_query)
            self.aggregate_count_per_query.update(previous_stream.aggregate_count_per_query)
            self.aggregate_sum_per_query.update(previous_stream.aggregate_sum_per_query)

            self.file_path = previous_stream.file_path
            self.outfile   = previous_stream.outfile
            self.outstream = previous_stream.outstream
        else:
            self.file_path = Path(file_path)
            self.file_path.parent.mkdir(parents=True, exist_ok=True)
            if __params__['PACK']:
                self.outfile = zipfile.ZipFile(self.file_path.with_suffix(".zip"), mode="w", compression=__params__['PACK'], allowZip64=True, compresslevel=9)
                self.outstream = self.outfile.open(self.file_path.name, "w")
            else:
                if sql_query_params['CSV_GENERATOR'] == 'NATIVE':
                    # Native CSV module
                    self.outfile   = open(self.file_path, mode='wt', newline='', encoding='UTF-8')
                    self.outstream = csv.writer(self.outfile, delimiter=sql_query_params['DELIMITER'], lineterminator=sql_query_params['EOL'])
                else:
                    # Custom CSV/FWF generation
                    self.outfile = None
                    self.outstream = open(self.file_path, mode='wt', newline='', encoding='UTF-8')

        # n0debug_object("self")
        if self.sql_query_params['WRITE_HEADER']:
            self.write_header()

        n0print("_PyTL_StreamTXTbase.__init__: End", level="DEBUG")
    ############################################################################
    ############################################################################
    def __del__(self):
        n0print("PyTL_StreamTXTbase.__del__", level="DEBUG")
        ## if self.outstream:
        ##     raise BrokenPipeError(f"Stream for file '{self.file_path}' is not closed")
    ############################################################################
    ############################################################################
    def close(self):
        n0print("PyTL_StreamTXTbase.close", level="DEBUG")
        if self.outstream:
            pytl_core.logging.info(f"Saving report into '{self.file_path}'")
            if not self.outfile or __params__['PACK']:
                # Close in case of COMPLEX,SIMPLEX,PACK
                self.outstream.close()
                self.outstream = None
            if self.outfile:
                # Close in case of NATIVE or not PACK
                self.outfile.close()
                self.outfile = None
        else:
            raise BrokenPipeError(f"Impossible to close not opened file '{self.file_path}'")
########################################################################################################################
########################################################################################################################
class PyTL_StreamTXTbase(_PyTL_StreamTXTbase):
    # Used only by CSV-complex, CSV-simple, FWF-simple
    # CSV-native doesn't use _mask_and_write_row()->_write_row()
    def _write_row(self, row:str) -> str:
        n0print("PyTL_StreamTXTbase._write_row", level="DEBUG")
        self.outstream.write(row)
        return row
    # def __init__(self, query_index: int = None, sql_query_params: dict = None, file_path: str = None, opened_streams = None, previous_stream = None):
    #     n0print("PyTL_StreamTXTbase.__init__: Start", level="DEBUG")
    #     super().__init__(query_index, sql_query_params, file_path, opened_streams, previous_stream)
    #     n0print("PyTL_StreamTXTbase.__init__: End", level="DEBUG")
class PyTL_StreamTXTpack(_PyTL_StreamTXTbase):
    # Used only by CSV-complex, CSV-simple, FWF-simple + PACK
    def _write_row(self, row:str) -> str:
        n0print("PyTL_StreamTXTpack._write_row", level="DEBUG")
        self.outstream.write(row.encode('utf-8'))
        return row
    # def __init__(self, query_index: int = None, sql_query_params: dict = None, file_path: str = None, opened_streams = None, previous_stream = None):
    #     n0print("PyTL_StreamTXTpack.__init__: Start", level="DEBUG")
    #     super().__init__(query_index, sql_query_params, file_path, opened_streams, previous_stream)
    #     n0print("PyTL_StreamTXTpack.__init__: End", level="DEBUG")
########################################################################################################################
########################################################################################################################
class PyTL_StreamBaseNoMaskRows(PyTL_StreamBase):
    def _mask_and_write_row(self, row: str) -> typing.Union[str, list, None]:  # list for CSV-native/XLS, str for other
        n0print("PyTL_StreamBaseNoMaskRows._mask_and_write_row", level="DEBUG")
        return self._write_row(row)
########################################################################################################################
########################################################################################################################
class PyTL_StreamBaseMaskRows(PyTL_StreamBase):
    def _mask_and_write_row(self, row:str) -> typing.Union[str, list, None]:  # list for CSV-native/XLS, str for other
        n0print("PyTL_StreamBaseMaskRows._mask_and_write_row", level="DEBUG")
        return self._write_row(self._mask_row(row))
########################################################################################################################
########################################################################################################################
class PyTL_StreamBaseNoMaskColumnsNoEmpty(PyTL_StreamBase):
    def _mask_and_write_columns(self, column_values:list, column_names:list) -> typing.Union[str, list, None]:  # list for CSV-native/XLS, str for other
        n0print("PyTL_StreamBaseNoEmptyNoMaskColumns._mask_and_write_columns", level="DEBUG")
        if any(column_values[i] for i,column_name in enumerate(column_names) if column_name != 'ORG'):
            return self._write_columns(column_values, column_names)
        return None
########################################################################################################################
########################################################################################################################
class PyTL_StreamBaseMaskColumnsNoEmpty(PyTL_StreamBase):
    def _mask_and_write_columns(self, column_values:list, column_names:list) -> typing.Union[str, list, None]:  # list for CSV-native/XLS, str for other
        n0print("PyTL_StreamBaseNoEmptyMaskColumns._mask_and_write_columns", level="DEBUG")
        masked_columns = self._mask_columns(column_values, column_names)
        if any(masked_columns[i] for i,column_name in enumerate(column_names) if column_name != 'ORG'):
            return self._write_columns(masked_columns, column_names)
        return None
########################################################################################################################
########################################################################################################################
class PyTL_StreamBaseNoMaskColumns(PyTL_StreamBase):
    def _mask_and_write_columns(self, column_values:list, column_names:list) -> typing.Union[str, list, None]:  # list for CSV-native/XLS, str for other
        n0print("PyTL_StreamBaseNoMaskColumns._mask_and_write_columns", level="DEBUG")
        return self._write_columns(column_values, column_names)
########################################################################################################################
########################################################################################################################
class PyTL_StreamBaseMaskColumns(PyTL_StreamBase):
    def _mask_and_write_columns(self, column_values:list, column_names:list) -> typing.Union[str, list, None]:  # list for CSV-native/XLS, str for other
        n0print("PyTL_StreamBaseMaskColumns._mask_and_write_columns", level="DEBUG")
        return self._write_columns(self._mask_columns(column_values, column_names), column_names)
########################################################################################################################
########################################################################################################################
########################################################################################################################
########################################################################################################################
class _PyTL_StreamCSVcomplex(PyTL_StreamBase):
    def _write_columns(self, column_values:list, column_names:list) -> typing.Union[str, list, None]:  # list for CSV-native/XLS, str for other
        n0print("PyTL_StreamCSVcomplex._write_columns", level="DEBUG")
        return self._mask_and_write_row(
            generate_complex_csv_row(
                column_values,
                delimiter = self.sql_query_params['DELIMITER'],
                EOL = self.sql_query_params['EOL']
            )
        )
class PyTL_StreamCSVcomplex(_PyTL_StreamCSVcomplex, PyTL_StreamTXTbase):
    pass
class PyTL_StreamCSVpackComplex(_PyTL_StreamCSVcomplex, PyTL_StreamTXTpack):
    pass
########################################################################################################################
##********************************************************************************************************************##
########################################################################################################################
class PyTL_StreamCSV(PyTL_StreamCSVcomplex, PyTL_StreamBaseNoMaskColumns, PyTL_StreamBaseNoMaskRows):
    pass
class PyTL_StreamCSVpack(PyTL_StreamCSVpackComplex, PyTL_StreamBaseNoMaskColumns, PyTL_StreamBaseNoMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVmaskColumns(PyTL_StreamCSVcomplex, PyTL_StreamBaseMaskColumns, PyTL_StreamBaseNoMaskRows):
    pass
class PyTL_StreamCSVpackMaskColumns(PyTL_StreamCSVpackComplex, PyTL_StreamBaseMaskColumns, PyTL_StreamBaseNoMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVmaskRows(PyTL_StreamCSVcomplex, PyTL_StreamBaseNoMaskColumns, PyTL_StreamBaseMaskRows):
    pass
class PyTL_StreamCSVpackMaskRows(PyTL_StreamCSVpackComplex, PyTL_StreamBaseNoMaskColumns, PyTL_StreamBaseMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVmaskColumnsMaskRows(PyTL_StreamCSVcomplex, PyTL_StreamBaseMaskColumns, PyTL_StreamBaseMaskRows):
    pass
class PyTL_StreamCSVpackMaskColumnsMaskRows(PyTL_StreamCSVpackComplex, PyTL_StreamBaseMaskColumns, PyTL_StreamBaseMaskRows):
    pass
########################################################################################################################
##********************************************************************************************************************##
########################################################################################################################
class PyTL_StreamCSVnoEmpty(PyTL_StreamCSVcomplex, PyTL_StreamBaseNoMaskColumnsNoEmpty, PyTL_StreamBaseNoMaskRows):
    pass
class PyTL_StreamCSVpackNoEmpty(PyTL_StreamCSVpackComplex, PyTL_StreamBaseNoMaskColumnsNoEmpty, PyTL_StreamBaseNoMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVmaskColumnsNoEmpty(PyTL_StreamCSVcomplex, PyTL_StreamBaseMaskColumnsNoEmpty, PyTL_StreamBaseNoMaskRows):
    pass
class PyTL_StreamCSVpackMaskColumnsNoEmpty(PyTL_StreamCSVpackComplex, PyTL_StreamBaseMaskColumnsNoEmpty, PyTL_StreamBaseNoMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVmaskRowsNoEmpty(PyTL_StreamCSVcomplex, PyTL_StreamBaseNoMaskColumnsNoEmpty, PyTL_StreamBaseMaskRows):
    pass
class PyTL_StreamCSVpackMaskRowsNoEmpty(PyTL_StreamCSVpackComplex, PyTL_StreamBaseNoMaskColumnsNoEmpty, PyTL_StreamBaseMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVmaskColumnsMaskRowsNoEmpty(PyTL_StreamCSVcomplex, PyTL_StreamBaseMaskColumnsNoEmpty, PyTL_StreamBaseMaskRows):
    pass
class PyTL_StreamCSVpackMaskColumnsMaskRowsNoEmpty(PyTL_StreamCSVpackComplex, PyTL_StreamBaseMaskColumnsNoEmpty, PyTL_StreamBaseMaskRows):
    pass
########################################################################################################################
########################################################################################################################
########################################################################################################################
########################################################################################################################
class _PyTL_StreamCSVsimpleBase(PyTL_StreamBase):
    def _write_columns(self, column_values:list, column_names:list) -> typing.Union[str, list, None]:  # list for CSV-native/XLS, str for other
        n0print("PyTL_StreamCSVsimple._write_columns", level="DEBUG")
        return self._mask_and_write_row(f"{self.sql_query_params['DELIMITER'].join(column_values)}{self.sql_query_params['EOL']}")
class PyTL_StreamCSVsimpleBase(PyTL_StreamTXTbase, _PyTL_StreamCSVsimpleBase):
    pass
class PyTL_StreamCSVpackSimpleBase(PyTL_StreamTXTpack, _PyTL_StreamCSVsimpleBase):
    pass
########################################################################################################################
##********************************************************************************************************************##
########################################################################################################################
class PyTL_StreamCSVsimple(PyTL_StreamCSVsimpleBase, PyTL_StreamBaseNoMaskColumns, PyTL_StreamBaseNoMaskRows):
    pass
class PyTL_StreamCSVpackSimple(PyTL_StreamCSVpackSimpleBase, PyTL_StreamBaseNoMaskColumns, PyTL_StreamBaseNoMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVsimpleMaskColumns(PyTL_StreamCSVsimpleBase, PyTL_StreamBaseMaskColumns, PyTL_StreamBaseNoMaskRows):
    pass
class PyTL_StreamCSVpackSimpleMaskColumns(PyTL_StreamCSVpackSimpleBase, PyTL_StreamBaseMaskColumns, PyTL_StreamBaseNoMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVsimpleMaskRows(PyTL_StreamCSVsimpleBase, PyTL_StreamBaseNoMaskColumns, PyTL_StreamBaseMaskRows):
    pass
class PyTL_StreamCSVpackSimpleMaskRows(PyTL_StreamCSVpackSimpleBase, PyTL_StreamBaseNoMaskColumns, PyTL_StreamBaseMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVsimpleMaskColumnsMaskRows(PyTL_StreamCSVsimpleBase, PyTL_StreamBaseMaskColumns, PyTL_StreamBaseMaskRows):
    pass
class PyTL_StreamCSVpackSimpleMaskColumnsMaskRows(PyTL_StreamCSVpackSimpleBase, PyTL_StreamBaseMaskColumns, PyTL_StreamBaseMaskRows):
    pass
########################################################################################################################
##********************************************************************************************************************##
########################################################################################################################
class PyTL_StreamCSVsimpleNoEmpty(PyTL_StreamCSVsimpleBase, PyTL_StreamBaseNoMaskColumnsNoEmpty, PyTL_StreamBaseNoMaskRows):
    pass
class PyTL_StreamCSVpackSimpleNoEmpty(PyTL_StreamCSVpackSimpleBase, PyTL_StreamBaseNoMaskColumnsNoEmpty, PyTL_StreamBaseNoMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVsimpleMaskColumnsNoEmpty(PyTL_StreamCSVsimpleBase, PyTL_StreamBaseMaskColumnsNoEmpty, PyTL_StreamBaseNoMaskRows):
    pass
class PyTL_StreamCSVpackSimpleMaskColumnsNoEmpty(PyTL_StreamCSVpackSimpleBase, PyTL_StreamBaseMaskColumnsNoEmpty, PyTL_StreamBaseNoMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVsimpleMaskRowsNoEmpty(PyTL_StreamCSVsimpleBase, PyTL_StreamBaseNoMaskColumnsNoEmpty, PyTL_StreamBaseMaskRows):
    pass
class PyTL_StreamCSVpackSimpleMaskRowsNoEmpty(PyTL_StreamCSVpackSimpleBase, PyTL_StreamBaseNoMaskColumnsNoEmpty, PyTL_StreamBaseMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVsimpleMaskColumnsMaskRowsNoEmpty(PyTL_StreamCSVsimpleBase, PyTL_StreamBaseMaskColumnsNoEmpty, PyTL_StreamBaseMaskRows):
    pass
class PyTL_StreamCSVpackSimpleMaskColumnsMaskRowsNoEmpty(PyTL_StreamCSVpackSimpleBase, PyTL_StreamBaseMaskColumnsNoEmpty, PyTL_StreamBaseMaskRows):
    pass
########################################################################################################################
########################################################################################################################
########################################################################################################################
########################################################################################################################
class PyTL_StreamCSVnativeBase(PyTL_StreamTXTbase):
    def _write_columns(self, column_values:list, column_names:list) -> typing.Union[str, list, None]:  # list for CSV-native/XLS, str for other
        n0print("PyTL_StreamCSVnativeBase._write_columns", level="DEBUG")
        self.outstream.writerow(column_values)
        return column_values
########################################################################################################################
# PyTL_StreamBaseNoMaskRows is not required, because of self._mask_and_write_row is not used by _write_columns
########################################################################################################################
class PyTL_StreamCSVnative(PyTL_StreamCSVnativeBase, PyTL_StreamBaseNoMaskColumns):
    pass
class PyTL_StreamCSVnativeMaskColumns(PyTL_StreamCSVnativeBase, PyTL_StreamBaseMaskColumns):
    pass
########################################################################################################################
##********************************************************************************************************************##
########################################################################################################################
class PyTL_StreamCSVnativeNoEmpty(PyTL_StreamCSVnativeBase, PyTL_StreamBaseNoMaskColumnsNoEmpty):
    pass
class PyTL_StreamCSVnativeMaskColumnsNoEmpty(PyTL_StreamCSVnativeBase, PyTL_StreamBaseMaskColumnsNoEmpty):
    pass
########################################################################################################################
########################################################################################################################
########################################################################################################################
########################################################################################################################
class _PyTL_StreamFWFbase(PyTL_StreamBase):
    def _write_columns(self, column_values:list, column_names:list) -> typing.Union[str, list, None]:  # list for CSV-native/XLS, str for other
        n0print("PyTL_StreamFWFbase._write_columns", level="DEBUG")
        sql_query_params_ADJUST_COLUMNS = self.sql_query_params['ADJUST_COLUMNS']
        str_column_values = []
        for column_index,column_value in enumerate(column_values):
            str_column_value = column_value if isinstance(column_value, str) else str(column_value)
            adjust_params = sql_query_params_ADJUST_COLUMNS[column_names[column_index]]

            if len(str_column_value) > adjust_params[2]:
                if not adjust_params[3]:
                    if (sql_query_params_TOO_LONG_VALUE := self.sql_query_params['TOO_LONG_VALUE']) == 'CUT':
                        str_column_value = str_column_value[:adjust_params[2]]
                    elif sql_query_params_TOO_LONG_VALUE == 'STOP':
                        raise ValueError(f"Value '{str_column_value}' in column {column_names[column_index]} is longer that expected {adjust_params[2]}")
            else:
                if adjust_params[1] == '<':
                    str_column_value = str_column_value.ljust(adjust_params[2], adjust_params[0])
                elif adjust_params[1] == '^':
                    str_column_value = str_column_value.center(adjust_params[2], adjust_params[0])
                elif adjust_params[1] == '>':
                    str_column_value = str_column_value.rjust(adjust_params[2], adjust_params[0])
                else:
                    raise ValueError(f"Unknown adjustment '{adjust_params[1]}' for column {column_names[column_index]}")
            str_column_values.append(str_column_value)
        return self._mask_and_write_row(f"{self.sql_query_params['DELIMITER'].join(str_column_values)}{self.sql_query_params['EOL']}")
class PyTL_StreamFWFbase(PyTL_StreamTXTbase, _PyTL_StreamFWFbase):
    pass
class PyTL_StreamFWFpackBase(PyTL_StreamTXTpack, _PyTL_StreamFWFbase):
    pass
    # def __init__(self, query_index: int = None, sql_query_params: dict = None, file_path: str = None, opened_streams = None, previous_stream = None):
    #     n0print("PyTL_StreamFWFpackBase.__init__: Start", level="DEBUG")
    #     super().__init__(query_index, sql_query_params, file_path, opened_streams, previous_stream)
    #     n0print("PyTL_StreamFWFpackBase.__init__: End", level="DEBUG")
########################################################################################################################
########################################################################################################################
class PyTL_StreamFWF(PyTL_StreamFWFbase, PyTL_StreamBaseNoMaskColumns, PyTL_StreamBaseNoMaskRows):
    pass
class PyTL_StreamFWFpack(PyTL_StreamFWFpackBase, PyTL_StreamBaseNoMaskColumns, PyTL_StreamBaseNoMaskRows):
    pass
    # def __init__(self, query_index: int = None, sql_query_params: dict = None, file_path: str = None, opened_streams = None, previous_stream = None):
    #     n0print("PyTL_StreamFWFpack.__init__: Start", level="DEBUG")
    #     super().__init__(query_index, sql_query_params, file_path, opened_streams, previous_stream)
    #     n0print("PyTL_StreamFWFpack.__init__: End", level="DEBUG")
########################################################################################################################
########################################################################################################################
class PyTL_StreamFWFmaskColumns(PyTL_StreamFWFbase, PyTL_StreamBaseMaskColumns, PyTL_StreamBaseNoMaskRows):
    pass
class PyTL_StreamFWFpackMaskColumns(PyTL_StreamFWFpackBase, PyTL_StreamBaseMaskColumns, PyTL_StreamBaseNoMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamFWFmaskRows(PyTL_StreamFWFbase, PyTL_StreamBaseNoMaskColumns, PyTL_StreamBaseMaskRows):
    pass
class PyTL_StreamFWFpackMaskRows(PyTL_StreamFWFpackBase, PyTL_StreamBaseNoMaskColumns, PyTL_StreamBaseMaskRows):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamFWFmaskColumnsMaskRows(PyTL_StreamFWFbase, PyTL_StreamBaseMaskColumns, PyTL_StreamBaseMaskRows):
    pass
class PyTL_StreamFWFpackMaskColumnsMaskRows(PyTL_StreamFWFpackBase, PyTL_StreamBaseMaskColumns, PyTL_StreamBaseMaskRows):
    pass
########################################################################################################################
########################################################################################################################
ORACLE_DATA_TYPE_MAPPING = {
    cx_Oracle.DB_TYPE_NUMBER:           lambda v: decimal.Decimal(v) if isnumber(v) else v,
    cx_Oracle.DB_TYPE_BINARY_DOUBLE:    lambda v: decimal.Decimal(v) if isnumber(v) else v,
    cx_Oracle.DB_TYPE_BINARY_FLOAT:     lambda v: decimal.Decimal(v) if isnumber(v) else v,
    cx_Oracle.DB_TYPE_DATE:             lambda v: to_date(v),
}
class PyTL_StreamXLSbase(PyTL_StreamBase):
    def __init__(self, query_index: int = None, sql_query_params: dict = None, file_path: str = None, opened_streams = None, previous_stream = None):
        n0print("PyTL_StreamXLSbase.__init__: Start", level="DEBUG")
        if query_index is None:
            raise RuntimeError(f"Incorrect call of PyTL_StreamXLSbase.__init__({query_index=}, {sql_query_params=}, {file_path=}, {previous_stream=})")

        # n0debug_object("self")
        super().__init__(query_index, sql_query_params)
        # n0debug_object("self")

        n0print("PyTL_StreamXLSbase.__init__: Continue", level="DEBUG")

        if previous_stream:
            # Written rows total count (without title) from all queries into current worksheet == sum(self.saved_rows_count_per_query.values())
            self.saved_rows_count = previous_stream.saved_rows_count
            # Written rows count (without header) from previous queries into current worksheet
            self.saved_rows_count_per_query.update(previous_stream.saved_rows_count_per_query)
            self.file_path = previous_stream.file_path
            self.outfile   = previous_stream.outfile
            self.outstream = previous_stream.outstream

            self.worksheet_name = previous_stream.worksheet_name
            self.worksheet_data_options = previous_stream.worksheet_data_options
            self.excel_row_index = previous_stream.excel_row_index
        else:
            file_path_parts = file_path.split('::', 1)
            self.file_path = Path(file_path_parts[0])
            self.worksheet_name = file_path_parts[1] if len(file_path_parts) > 1 else "Default"

            self.worksheet_data_options = sql_query_params.get(
                                               'XLS_STYLES',
                                               __params__.get('XLS_STYLES', {}).get(self.worksheet_name, {})
            ).get("data_options", {})

            self.excel_row_index = 1
            # self.sql_query_params['CREATE_EMPTY_REPORT'] = False

            self.outfile = next(
                # Find first opened XLS file with the same file_path (without worksheet_name)
                (opened_stream.outfile for opened_stream in opened_streams.values() if self.file_path == opened_stream.file_path),
                # If no files were created, then create the new Workbook()
                None
            )   # workbook handler
            if not self.outfile:
                self.outfile = openpyxl.Workbook()
                self.outstream = self.outfile.active  # already the first worksheet will be created
            else:
                self.outstream = self.outfile.create_sheet(self.worksheet_name) # worksheet handler = workbook.active

            self.outstream.name  = self.worksheet_name
            self.outstream.title = self.worksheet_name

        if self.sql_query_params['WRITE_HEADER']:
            self.write_header()

        n0print("PyTL_StreamXLSbase.__init__: End", level="DEBUG")
    ############################################################################
    ############################################################################
    def __del__(self):
        n0print("PyTL_StreamXLSbase.__del__", level="DEBUG")
        if self.outstream:
            raise BrokenPipeError(f"Stream for worksheet '{self.file_path}::{self.worksheet_name}' is not closed")
    ############################################################################
    ############################################################################
    def close(self):
        n0print("PyTL_StreamXLSbase.close", level="DEBUG")
        if self.outstream:
            pytl_core.logging.info(f"Adjusting report in '{self.file_path}::{self.worksheet_name}'")
            # Adjust columns' widths
            worksheet = self.outstream
            for col in worksheet.columns:
                 max_length = 0
                 for cell in col:
                     try: # Necessary to avoid error on empty cells
                         if len(str(cell.value)) > max_length:
                             max_length = len(str(cell.value))
                     except:
                         pass
                 adjusted_width = (max_length + 2) * 1.2
                 column_name = col[0].column_letter # Get the column name
                 worksheet.column_dimensions[column_name].width = adjusted_width
            self.outstream = None
        else:
            raise BrokenPipeError(f"Impossible to close not opened file '{self.file_path}'")
    ############################################################################
    ############################################################################
    def _write_columns(self, column_values:list, column_names:list) -> typing.Union[str, list, None]:  # list for CSV-native/XLS, str for other
        n0print("PyTL_StreamXLSbase._write_columns", level="DEBUG")

        ############################################################################
        ## ???
        columns_width = [len(column_name) for column_name in column_names] # default values
        ## ???
        ############################################################################
        formatted_row = []
        for column_index, cell_value in enumerate(column_values):
            ########################################################################
            ## ???
            prev_cell_width_value = 0
            current_cell_width_value = len(cell_value) if cell_value else 0
            if column_index < len(columns_width):
                prev_cell_width_value = columns_width[column_index]
            columns_width[column_index] = max(current_cell_width_value, prev_cell_width_value)
            ## ???
            ########################################################################

            cell = openpyxl.cell.Cell(
                worksheet = self.outstream,
                row       = self.excel_row_index,
                column    = column_index + 1,
            )

            column_name = column_names[column_index]
            column_type = self.columns_data_types[column_name][0]
            data_options = self.worksheet_data_options.get(column_name, {})

            if cell_value:
                ################################################################
                # n0debug("cell_value")
                # n0debug_calc(__params__['AUTO_PRECISION'], "__params__['AUTO_PRECISION']")
                # n0debug_calc(column_type == cx_Oracle.DB_TYPE_VARCHAR, f"{column_type} == cx_Oracle.DB_TYPE_VARCHAR")
                # n0debug_calc(isnumber(cell_value), f"isnumber({cell_value})")
                # n0debug_calc(__params__['AUTO_CONVERT'], "__params__['AUTO_CONVERT']")
                # n0debug_calc(ORACLE_DATA_TYPE_MAPPING.get(column_type), f"ORACLE_DATA_TYPE_MAPPING.get({column_type})")
                ################################################################

                def auto_precision(cell_value: str):
                    if not isnumber(cell_value):
                        return ""
                    if not '.' in cell_value:
                        return "0"
                    fractional_part_len = len(cell_value.split('.', 1)[1])
                    return "0." +  "0"*fractional_part_len

                if __params__['AUTO_PRECISION'] \
                and column_type == cx_Oracle.DB_TYPE_VARCHAR \
                and isnumber(cell_value):
                    # Convert string into number in case of
                    #   AUTO_PRECISION=YES
                    #   string
                    #   looks like a number
                    cell.number_format = auto_precision(cell_value)
                    cell.value = decimal.Decimal(cell_value)
                    n0debug("cell_value")   #######
                elif __params__['AUTO_CONVERT'] and (convert_to_python_type:=ORACLE_DATA_TYPE_MAPPING.get(column_type)):
                    # cell_value = convert_to_python_type(cell_value)
                    # n0debug("cell_value") #######
                    # n0debug("convert_to_python_type")
                    cell.number_format = auto_precision(cell_value)
                    cell.value = (cell_value:=convert_to_python_type(cell_value))
                    # cell_value = decimal.Decimal(cell_value)
                    n0debug("cell_value")   #######
                elif convert_to_python_type:=ORACLE_DATA_TYPE_MAPPING.get(data_options.get("data_type")):
                    cell.number_format = auto_precision(cell_value)
                    cell.value = (cell_value:=convert_to_python_type(cell_value))
                    n0debug("cell_value")   #######
                else:
                    cell.value = cell_value
                    n0debug("cell_value")   #######

            if "format" in data_options:
                cell.number_format = data_options["format"]

            # cell_styles = prepared_params.get(spreadsheet_name, {}).get("styles", {}).get(headers[column_index], {})
            # for k, v in cell_styles.items():
                # setattr(cell, k, v)
            formatted_row.append(cell)
            ########################################################################

        n0debug("formatted_row")    #######
        self.outstream.append(formatted_row)
        self.excel_row_index += 1

        return formatted_row
########################################################################################################################
# PyTL_StreamBaseNoMaskRows is not required, because of self._mask_and_write_row is not used by _write_columns
########################################################################################################################
class PyTL_StreamXLS(PyTL_StreamXLSbase, PyTL_StreamBaseNoMaskColumns):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamXLSmaskColumns(PyTL_StreamXLSbase, PyTL_StreamBaseMaskColumns):
    pass
########################################################################################################################
##********************************************************************************************************************##
########################################################################################################################
class PyTL_StreamXLSnoEmpty(PyTL_StreamXLSbase, PyTL_StreamBaseNoMaskColumnsNoEmpty):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamXLSmaskColumnsNoEmpty(PyTL_StreamXLSbase, PyTL_StreamBaseMaskColumnsNoEmpty):
    pass
########################################################################################################################
########################################################################################################################
class PyTL_StreamDB(PyTL_StreamBase):
    def __init__(self, query_index: int, sql_query_params: dict):
        n0print("PyTL_StreamDB.__init__: Start", level="DEBUG")

        try:
            if (target_db_name:=sql_query_params['TARGET_DB']) not in __params__['DB_CONNECTIONS']:
                __params__['DB_CONNECTIONS'][target_db_name] = pytl_globals.config[target_db_name]

            if isinstance(__params__['DB_CONNECTIONS'][target_db_name], str):
                target_db_connection = __params__['DB_CONNECTIONS'][target_db_name] = pytl_core.Connection(
                    __params__['DB_CONNECTIONS'][target_db_name],
                    __params__['JOB_NAME'] + " " + date_timestamp()
                )
            else:
                target_db_connection = __params__['DB_CONNECTIONS'][target_db_name]
        except Exception as ex:
            pytl_core.logging.error(f"Error with connection {target_db_name} ({__params__['DB_CONNECTIONS'].get(target_db_name)}): {ex}")
            raise ex

        const_sql_values = {
           'UNIQUE_CALL_ID':    sql_query_params['UNIQUE_CALL_ID'],
           'QUERY_NAME':        sql_query_params['SQL_QUERY_NAME'],
           'QUERY_PARAMS':      n0dict(sql_query_params['BINDED_VARS']).to_json(compress=True),
        }

        recalculated_sql_values = {
           'ROW_ID':            lambda fetched_row_index,fetched_row: fetched_row_index,
           'SERIALIZED':        lambda fetched_row_index,fetched_row: n0dict(fetched_row).to_json(compress=True),
        }

        source_columns = sql_query_params['TARGET_COLUMNS'].values()
        insert_sql_statement = f"""
            insert into {sql_query_params['TARGET_TABLE']}(
                {', '.join(sql_query_params['TARGET_COLUMNS'].keys())}
            ) values (
                {', '.join(f":{v}" for v in source_columns)}
            )
        """

        self.fetched_rows_count = 0 # index at the begining and after the count of fetched rows FROM ALL BATCHES
        self.saved_rows_count = 0   # the count of saved rows FROM ALL BATCHES (ideally (for Oracle12+ client) should be equal to self.fetched_rows_count)
        try:
            target_cursor = target_db_connection.connection.cursor()

            # https://github.com/oracle/python-cx_Oracle/issues/200
            for rows_batch in sql_query_params['SQL_CURSOR']:
                n0debug("rows_batch")
                n0debug_calc(self.fetched_rows_count, "self.fetched_rows_count")
                target_rows = []
                for fetched_row in rows_batch:
                    n0debug("fetched_row")
                    target_row = {}
                    for column_name in source_columns:
                        fetched_field = {
                            column_name:    const_sql_values.get(
                                                column_name,
                                                fetched_row.get(
                                                    column_name,
                                                    recalculated_sql_values.get(
                                                        column_name,
                                                        lambda __fetched_rows_count, __fetched_row: None
                                                    )(self.fetched_rows_count, fetched_row)
                                                )
                                            )
                        }
                        n0debug("fetched_field")

                        if sql_query_params['MASK_COLUMNS'] and (_regexp_patterns:=sql_query_params['MASK_COLUMNS'].get(column_name, {})):
                            for _pattern,_replace in _regexp_patterns.items():
                                fetched_field[column_name] = _pattern.sub(_replace, fetched_field[column_name])

                        target_row.update(fetched_field)

                    n0debug("target_row")
                    target_rows.append(target_row)
                    self.fetched_rows_count += 1

                n0debug("target_rows")
                n0debug_calc(self.fetched_rows_count, "self.fetched_rows_count")

                if target_rows:
                    target_cursor.executemany(insert_sql_statement, target_rows, arraydmlrowcounts=True)

                    saved_rows_count = None
                    try:
                        if self.fetched_rows_count:
                            saved_rows_count = sum(target_cursor.getarraydmlrowcounts())
                    except cx_Oracle.DatabaseError as ex:
                        # DPI-1002: invalid dpiStmt handle"
                        # dpiStmt_getRowCounts: check main handle"
                        # code = 0
                        n0debug_object("ex")
                        oracle_error, = ex.args
                        n0debug_object("oracle_error")
                        pytl_core.logging.info(ex)
                        if oracle_error.code == 24349:
                            saved_rows_count = 0
                        elif oracle_error.code == 0 and "DPI-1050" in oracle_error.message:
                            saved_rows_count = None
                            pytl_core.logging.info("Impossible to determine count of written records -- Oracle client upgrade is required")
                        elif oracle_error.code == 0 and "DPI-1002" in oracle_error.message:
                            saved_rows_count = None
                            pytl_core.logging.info("Not clear message: DPI-1002: invalid dpiStmt handle")
                        else:
                            raise ex
                    if saved_rows_count is not None:
                        self.saved_rows_count += saved_rows_count

            if self.fetched_rows_count:
                target_db_connection.commit()
                if self.saved_rows_count:
                     pytl_core.logging.info(f"Saved {self.saved_rows_count} records")
                else:
                     pytl_core.logging.info(f"Impossible to determine count of written records -- fetched {self.fetched_rows_count} records")
            else:
                pytl_core.logging.info(f"No records saved")

        except Exception as e:
            n0debug_object("e")
            pytl_core.logging.error(f"Batch insert execution error: {e}")
            target_db_connection.connection.rollback()
            raise e
        finally:
            target_cursor.close()

        n0print("PyTL_StreamDB.__init__: End", level="DEBUG")
########################################################################################################################
########################################################################################################################
########################################################################################################################
