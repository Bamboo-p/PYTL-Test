'''
Changes
-------
    230227.1 = deniska = NICORE-133: Fixing failing if OUTPUT_FN_PREFIX= is not provided
    230228.1 = deniska = NICORE-133: Adoptation for complex structure of XLS_SHEETS parameter
    230301.1 = deniska = NICORE-133: Conversion from PyTL_IS_XlsReports into PyTL_OmniReports
    230311.1 = deniska = NICORE-133: Possibility to split results into several files depends of query result
    230312.1 = deniska = NICORE-133: resolving the issue with importing of modules at the server
    230312.2 = deniska = NICORE-133: resolving the issue with reusing header from the first query
    230315.1 = deniska = NICORE-133: resolving the issue with NameError: name 'logging' is not defined
    230428.1 = deniska = NICORE-595: migration to OOP approach
    230525.1 = deniska = AUBI-3627: fixed issue with complex import of modules
    230525.1 = deniska = AUBI-3627: fixed issue with complex import of modules
    230721.1 = deniska = NICORE-676: Added parameter COLUMN_ALIASES=
    230824.1 = deniska = NICORE-723: Unification of parsing of global and local parameters
    231004.1 = deniska = NICORE-860: XML/HTML generation added to PyTL_OmniReports
    231009.1 = deniska = NICORE-723: Saving results into DB
    240207.1 = deniska = NICORE-1170: to generate empty reports for all SQL queries,
                                      added support center for ADJUST_COLUMNS, nested COLUMNS_QUANTITY, ADJUST_COLUMNS, MASK_PATTERN, MASK_COLUMNS
    240207.2 = deniska = NICORE-1170: fixing issue with multiple output files
    240207.3 = deniska = NICORE-1170: fixing issue with multiple output files #2
    240208.1 = deniska = NICORE-1170: fixing issue with duplication of the last line
    240209.1 = deniska = NICORE-1170: MASK_ALL could be local parameter
    240212.1 = deniska = NICORE-1170: deep refactoring for unification of masking (without DB)
    240220.1 = deniska = NICORE-1170: deep refactoring for unification of masking with DB/XLSX
    240222.1 = deniska = NICORE-1170: fixing issue with FWF
    240222.2 = deniska = NICORE-1170: changing approach of importing
    240222.3 = deniska = NICORE-1170: duplication of charater '^' mitigation, EOL fix
    240222.4 = deniska = NICORE-1170: 'SYNONYMS': {"DB_SOURCE", "DBSOURCE"} for 'SOURCE_DB'
    240223.1 = deniska = NICORE-1170: New parameters AGGREGATE_COUNT, AGGREGATE_SUM, USE_AGGREGATE, OVERWRITE_OUTPUT, SQL_QUERY_ID (local only), 'unicode_escape' is supported in SQL_QUERIES=
    240224.1 = deniska = NICORE-1170: New parameters SQL_TYPE=QUERY|ANONYMOUS_BLOCK|AUTO, SAVE_INTO (local only)
    240224.2 = deniska = NICORE-1170: New parameter SAVE_INTO_TYPE=STR|DICT|LIST|AUTO (local only). Executing SQLs on demand with injection of pytl_globals.config variables
    240224.3 = deniska = NICORE-1170: OVERWRITE_OUTPUT=YES by default for back compatibility
    240319.1 = deniska = PRD-26867: Fixing err0r NotImplementedErr0r: "OUTPUT_ENGINE=XLS" with "CSV_GENERATOR=None" are not supported
    240320.1 = deniska = PRD-26867: Fixing err0r NameErr0r: name 'isnumber' is not defined
    240321.1 = deniska = PRD-26767: Fixing err0r TypeErr0r: execute_select_batch() got an unexpected keyword argument 'sql_file'
    240321.2 = deniska = PRD-26864: sql name in PyTL_Serialized_Data.QUERY_NAME will be file name only instead of file name+extension
    240327.1 = deniska = NICORE-1301: merge regression defect fixes (240319.1-240321.2) with experemental changes (240222.4-240224.3)
    240328.1 = deniska = NICORE-1301: fix d3f3ct with segregation output data into the different worksheets in case of XLS
    240328.2 = deniska = NICORE-1301: fix d3f3ct with recalculation of combined_config + adding ability to provide escaped strings into parameters OUTPUT_FN_PREFIX,OUTPUT_FN_SEPARATOR,OUTPUT_FN_SUFFIX,OUTPUT_FN_EXTENSION
    240328.3 = deniska = NICORE-1307: merged code of HamzaD from NICORE-1307: float width in case of ~ in ADJUST_COLUMNS=COL1=~5
    240429.1 = deniska = NICORE-1301: updated code for nested formats (XML/JSON/HTML), debugging messages disabled in the loops
    240506.1 = deniska = CRKSA-580/NICORE-1301: fix d3f3ct with NameError: name 'pytl_globals' is not defined in PyTL_StreamDB
    240506.2 = deniska = NICORE-1301: fix PACK=
'''

########################################################################################################################
########################################################################################################################
import typing
import sys
import os
import re
from pathlib import Path
import zipfile
import pytl_core
import jinja2
import pytl_core.pytl_globals as pytl_globals
import inspect
from collections import defaultdict

from n0struct import (
    deserialize_list,
    date_timestamp,
    validate_values,
    n0debug,
    n0debug_calc,
    n0print,
    n0error,
    n0pretty,
    to_date,
    merge_dict,
    load_file,
    save_file,
    unique_file_path,
    iterable,
    isiterable,
    date_today,
    date_dash_yyyymmdd,
    time_colon_hhmmss,
)

n0print(f"{'='*20} START: Importing in {__file__}")
try:
    # Could be imported ONLY if it's run as NORMAL py
    n0print(f"=-= NORMAL {'=-='*3} from __init__ import __job_name__, __version__")
    from __init__ import (
        __job_name__,
        __version__,
    )

    n0print(f"=-= NORMAL {'=-='*3} from _params import __params__, CONNECTION_SYNONYMS")
    from _params import (
        __params__,
        CONNECTION_SYNONYMS,
    )

    n0print(f"=-= NORMAL {'=-='*3} from _prepare_openpyxl_styles import *")
    from _prepare_openpyxl_styles import *

    n0print(f"=-= NORMAL {'=-='*3} from PyTL_Streams import *")
    from PyTL_Streams import *

# except Exception as ex:
except ModuleNotFoundError as ex:
    n0print(f"{'#'*20} not NORMAL")
    try:
        # Could be imported ONLY if it's run as MODULE
        n0print(f"=-= MODULE {'=-='*3} from . import __job_name__")
        from . import __job_name__

        from importlib_metadata import version as importlib_metadata_version
        __version__ = importlib_metadata_version(__job_name__)

        n0print(f"=-= MODULE {'=-='*3} from ._params import __params__, CONNECTION_SYNONYMS")
        from ._params import (
            __params__,
            CONNECTION_SYNONYMS,
        )

        n0print(f"=-= MODULE {'=-='*3} from ._prepare_openpyxl_styles import *")
        from ._prepare_openpyxl_styles import *

        n0print(f"=-= MODULE {'=-='*3} from .PyTL_Streams import *")
        from .PyTL_Streams import *

    except Exception as ex:
        n0print(f"{'#'*20} FATAL ERROR: Importing in {__file__} as MODULE: {ex}")

        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_type, exc_value, exc_traceback = sys.exc_info() # most recent (if any) by default
        traceback_details = {
                             'filename': exc_traceback.tb_frame.f_code.co_filename,
                             'lineno'  : exc_traceback.tb_lineno,
                             'name'    : exc_traceback.tb_frame.f_code.co_name,
                             'type'    : exc_type.__name__,
                             'message' : exc_value.message, # or see traceback._some_str()
                            }
        n0print(traceback.format_exc())
        n0print(traceback_details)

        exit(-999)

n0print(f"{'-'*20} END: Importing in {__file__}")
########################################################################################################################
########################################################################################################################

########################################################################################################################
########################################################################################################################
def get_related_file_path(all_related_files: dict, file_key: str) -> Path:
    file_path = Path(file_key.encode().decode('unicode_escape'))
    if not file_path.exists() or not file_path.is_file():
        file_path = Path(file_key)
        if not file_path.exists() or not file_path.is_file():
            try:
                file_path = all_related_files[file_path.stem.lower()]
            except KeyError:
                raise FileNotFoundError(f"Requested file '{file_key}' is not found!")
    return file_path.absolute()
########################################################################################################################
########################################################################################################################
opened_streams = {}
def open_or_get_stream(file_path: str, query_index: int, sql_query_params: dict) -> tuple:
    """
        file_path to destination file or file+spreed_sheet name
    """
    # File/CSV writer/ZIP archive/XLS sheet is already opened
    if file_path in opened_streams and query_index == opened_streams[file_path].last_query_index:
        return opened_streams[file_path]

    if file_path in opened_streams:
        previous_stream = opened_streams[file_path]
    else:
        previous_stream = None

    if __params__['OUTPUT_ENGINE'] == 'CSV':
        if sql_query_params['CSV_GENERATOR'] not in ('FWF', 'NATIVE', 'SIMPLE', 'COMPLEX'):
            raise NotImplementedError(f"Unexpected value in parameter \"CSV_GENERATOR={sql_query_params['CSV_GENERATOR']}\".\nExpected: FWF, NATIVE, SIMPLE, COMPLEX")
        if sql_query_params['CSV_GENERATOR'] == 'NATIVE' and len(sql_query_params['DELIMITER']) != 1:
            raise NotImplementedError(f"\"CSV_GENERATOR=NATIVE\" doesn't support not standard \"DELIMITER={sql_query_params['DELIMITER']}\"")
        if sql_query_params['ADJUST_COLUMNS']:
            sql_query_params['CSV_GENERATOR'] = 'FWF'
    else:
        sql_query_params['CSV_GENERATOR'] = None

        if not previous_stream and not __params__['OVERWRITE_OUTPUT']:
            backup_file_path = unique_file_path(file_path)
            if backup_file_path != Path(file_path):
                os.rename(file_path, backup_file_path)

    '''
        ('DB',  None,       False,  False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamDB(a1, a2),
        ('DB',  None,       False,  True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamDB(a1, a2),
        ('DB',  None,       True,   False,  True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=DB\" does not support MASK_ALL=True")),
        ('DB',  None,       True,   True,   True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=DB\" does not support MASK_ALL=True")),

        ('DB',  None,       False,  False,  False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=DB\" does not support WRITE_EMPTY_ROWS=False")),
        ('DB',  None,       False,  True,   False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=DB\" does not support WRITE_EMPTY_ROWS=False")),
        ('DB',  None,       True,   False,  False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=DB\" does not support MASK_ALL=True and WRITE_EMPTY_ROWS=False")),
        ('DB',  None,       True,   True,   False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=DB\" does not support MASK_ALL=True and WRITE_EMPTY_ROWS=False")),
    '''

    n0debug_calc(__params__['OUTPUT_ENGINE'],                                                       "__params__['OUTPUT_ENGINE']")
    n0debug_calc(False if __params__['PACK'] is None else True,                                     "__params__['PACK']")
    n0debug_calc(sql_query_params['CSV_GENERATOR'],                                                 "sql_query_params['CSV_GENERATOR']")
    n0debug_calc(sql_query_params['MASK_ALL'],                                                      "sql_query_params['MASK_ALL']")
    n0debug_calc(bool(sql_query_params['MASK_COLUMNS']) or bool(sql_query_params['USE_AGGREGATE']), "bool(sql_query_params['MASK_COLUMNS']) or bool(sql_query_params['USE_AGGREGATE'])")
    n0debug_calc(sql_query_params['WRITE_EMPTY_ROWS'],                                              "sql_query_params['WRITE_EMPTY_ROWS']")

    opened_stream = opened_streams[file_path] = {
        # Engine Pack    CSVgen     MaskRow MaskCol WrtEmpt
        ('CSV', False,  'NATIVE',   False,  False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVnative(a1, a2, a3, a4, a5),
        ('CSV', False,  'NATIVE',   False,  True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVnativeMaskColumns(a1, a2, a3, a4, a5),
        ('CSV', False,  'NATIVE',   True,   False,  True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"CSV_GENERATOR=NATIVE\" does not support MASK_ALL=True")),
        ('CSV', False,  'NATIVE',   True,   True,   True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"CSV_GENERATOR=NATIVE\" does not support MASK_ALL=True")),
                    
        ('CSV', False,  'NATIVE',   False,  False,  False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVnativeNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', False,  'NATIVE',   False,  True,   False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVnativeMaskColumnsNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', False,  'NATIVE',   True,   False,  False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"CSV_GENERATOR=NATIVE\" does not support MASK_ALL=True")),
        ('CSV', False,  'NATIVE',   True,   True,   False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"CSV_GENERATOR=NATIVE\" does not support MASK_ALL=True")),
                    
        ('CSV', False,  'SIMPLE',   False,  False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVsimple(a1, a2, a3, a4, a5),
        ('CSV', False,  'SIMPLE',   False,  True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVsimpleMaskColumns(a1, a2, a3, a4, a5),
        ('CSV', False,  'SIMPLE',   True,   False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVsimpleMaskRows(a1, a2, a3, a4, a5),
        ('CSV', False,  'SIMPLE',   True,   True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVsimpleMaskColumnsMaskRows(a1, a2, a3, a4, a5),
                    
        ('CSV', False,  'SIMPLE',   False,  False,  False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVsimpleNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', False,  'SIMPLE',   False,  True,   False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVsimpleMaskColumnsNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', False,  'SIMPLE',   True,   False,  False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVsimpleMaskRowsNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', False,  'SIMPLE',   True,   True,   False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVsimpleMaskColumnsMaskRowsNoEmpty(a1, a2, a3, a4, a5),
                    
        ('CSV', False,  'COMPLEX',  False,  False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSV(a1, a2, a3, a4, a5),
        ('CSV', False,  'COMPLEX',  False,  True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVmaskColumns(a1, a2, a3, a4, a5),
        ('CSV', False,  'COMPLEX',  True,   False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVmaskRows(a1, a2, a3, a4, a5),
        ('CSV', False,  'COMPLEX',  True,   True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVmaskColumnsMaskRows(a1, a2, a3, a4, a5),
                    
        ('CSV', False,  'COMPLEX',  False,  False,  False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVnoEmpty(a1, a2, a3, a4, a5),
        ('CSV', False,  'COMPLEX',  False,  True,   False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVmaskColumnsNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', False,  'COMPLEX',  True,   False,  False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVmaskRowsNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', False,  'COMPLEX',  True,   True,   False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVmaskColumnsMaskRowsNoEmpty(a1, a2, a3, a4, a5),
                    
        ('CSV', False,  'FWF',      False,  False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamFWF(a1, a2, a3, a4, a5),
        ('CSV', False,  'FWF',      False,  True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamFWFmaskColumns(a1, a2, a3, a4, a5),
        ('CSV', False,  'FWF',      True,   False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamFWFmaskRows(a1, a2, a3, a4, a5),
        ('CSV', False,  'FWF',      True,   True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamFWFmaskColumnsMaskRows(a1, a2, a3, a4, a5),
                    
        ('CSV', False,  'FWF',      False,  False,  False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"CSV_GENERATOR=FWF\" does not support WRITE_EMPTY_ROWS=False")),
        ('CSV', False,  'FWF',      False,  True,   False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"CSV_GENERATOR=FWF\" does not support WRITE_EMPTY_ROWS=False")),
        ('CSV', False,  'FWF',      True,   False,  False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"CSV_GENERATOR=FWF\" does not support WRITE_EMPTY_ROWS=False")),
        ('CSV', False,  'FWF',      True,   True,   False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"CSV_GENERATOR=FWF\" does not support WRITE_EMPTY_ROWS=False")),
                    
        ('XLS', False,  None,       False,  False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamXLS(a1, a2, a3, a4, a5),
        ('XLS', False,  None,       False,  True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamXLSmaskColumns(a1, a2, a3, a4, a5),
        ('XLS', False,  None,       True,   False,  True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=XLS\" does not support MASK_ALL=True")),
        ('XLS', False,  None,       True,   True,   True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=XLS\" does not support MASK_ALL=True")),
                    
        ('XLS', False,  None,       False,  False,  False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamXLSnoEmpty(a1, a2, a3, a4, a5),
        ('XLS', False,  None,       False,  True,   False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamXLSmaskColumnsNoEmpty(a1, a2, a3, a4, a5),
        ('XLS', False,  None,       True,   False,  False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=XLS\" does not support MASK_ALL=True")),
        ('XLS', False,  None,       True,   True,   False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=XLS\" does not support MASK_ALL=True")),


        # PACK=...

        ('CSV', True,   'NATIVE',   False,  False,  True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=NATIVE\" does not support PACK=")),
        ('CSV', True,   'NATIVE',   False,  True,   True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=NATIVE\" does not support PACK=")),
        ('CSV', True,   'NATIVE',   True,   False,  True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=NATIVE\" does not support PACK=")),
        ('CSV', True,   'NATIVE',   True,   True,   True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=NATIVE\" does not support PACK=")),
                    
        ('CSV', True,   'NATIVE',   False,  False,  False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=NATIVE\" does not support PACK=")),
        ('CSV', True,   'NATIVE',   False,  True,   False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=NATIVE\" does not support PACK=")),
        ('CSV', True,   'NATIVE',   True,   False,  False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=NATIVE\" does not support PACK=")),
        ('CSV', True,   'NATIVE',   True,   True,   False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=NATIVE\" does not support PACK=")),
                    
        ('CSV', True,   'SIMPLE',   False,  False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackSimple(a1, a2, a3, a4, a5),
        ('CSV', True,   'SIMPLE',   False,  True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackSimpleMaskColumns(a1, a2, a3, a4, a5),
        ('CSV', True,   'SIMPLE',   True,   False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackSimpleMaskRows(a1, a2, a3, a4, a5),
        ('CSV', True,   'SIMPLE',   True,   True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackSimpleMaskColumnsMaskRows(a1, a2, a3, a4, a5),
                    
        ('CSV', True,   'SIMPLE',   False,  False,  False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackSimpleNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', True,   'SIMPLE',   False,  True,   False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackSimpleMaskColumnsNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', True,   'SIMPLE',   True,   False,  False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackSimpleMaskRowsNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', True,   'SIMPLE',   True,   True,   False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackSimpleMaskColumnsMaskRowsNoEmpty(a1, a2, a3, a4, a5),
                    
        ('CSV', True,   'COMPLEX',  False,  False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpack(a1, a2, a3, a4, a5),
        ('CSV', True,   'COMPLEX',  False,  True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackMaskColumns(a1, a2, a3, a4, a5),
        ('CSV', True,   'COMPLEX',  True,   False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackMaskRows(a1, a2, a3, a4, a5),
        ('CSV', True,   'COMPLEX',  True,   True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackMaskColumnsMaskRows(a1, a2, a3, a4, a5),
                    
        ('CSV', True,   'COMPLEX',  False,  False,  False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', True,   'COMPLEX',  False,  True,   False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackMaskColumnsNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', True,   'COMPLEX',  True,   False,  False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackMaskRowsNoEmpty(a1, a2, a3, a4, a5),
        ('CSV', True,   'COMPLEX',  True,   True,   False,  ):      lambda a1, a2, a3, a4, a5: PyTL_StreamCSVpackMaskColumnsMaskRowsNoEmpty(a1, a2, a3, a4, a5),
                    
        ('CSV', True,   'FWF',      False,  False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamFWFpack(a1, a2, a3, a4, a5),
        ('CSV', True,   'FWF',      False,  True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamFWFpackMaskColumns(a1, a2, a3, a4, a5),
        ('CSV', True,   'FWF',      True,   False,  True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamFWFpackMaskRows(a1, a2, a3, a4, a5),
        ('CSV', True,   'FWF',      True,   True,   True,   ):      lambda a1, a2, a3, a4, a5: PyTL_StreamFWFpackMaskColumnsMaskRows(a1, a2, a3, a4, a5),
                    
        ('CSV', True,   'FWF',      False,  False,  False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"CSV_GENERATOR=FWF\" does not support WRITE_EMPTY_ROWS=False")),
        ('CSV', True,   'FWF',      False,  True,   False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"CSV_GENERATOR=FWF\" does not support WRITE_EMPTY_ROWS=False")),
        ('CSV', True,   'FWF',      True,   False,  False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"CSV_GENERATOR=FWF\" does not support WRITE_EMPTY_ROWS=False")),
        ('CSV', True,   'FWF',      True,   True,   False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"CSV_GENERATOR=FWF\" does not support WRITE_EMPTY_ROWS=False")),
                    
        ('XLS', True,   None,       False,  False,  True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=XLS\" does not support PACK=")),
        ('XLS', True,   None,       False,  True,   True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=XLS\" does not support PACK=")),
        ('XLS', True,   None,       True,   False,  True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=XLS\" does not support PACK=")),
        ('XLS', True,   None,       True,   True,   True,   ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=XLS\" does not support PACK=")),
                    
        ('XLS', True,   None,       False,  False,  False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=XLS\" does not support PACK=")),
        ('XLS', True,   None,       False,  True,   False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=XLS\" does not support PACK=")),
        ('XLS', True,   None,       True,   False,  False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=XLS\" does not support PACK=")),
        ('XLS', True,   None,       True,   True,   False,  ):      lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError("\"OUTPUT_ENGINE=XLS\" does not support PACK=")),

    }.get(
        (
            __params__['OUTPUT_ENGINE'],
            False if __params__['PACK'] is None else True,
            sql_query_params['CSV_GENERATOR'],
            sql_query_params['MASK_ALL'],
            bool(sql_query_params['MASK_COLUMNS']) or bool(sql_query_params['USE_AGGREGATE']),
            sql_query_params['WRITE_EMPTY_ROWS'],
        ),
        lambda a1, a2, a3, a4, a5: pytl_core.raiser(NotImplementedError(f"\"OUTPUT_ENGINE={__params__['OUTPUT_ENGINE']}\" with \"CSV_GENERATOR={__params__['CSV_GENERATOR']}\" are not supported"))
    )(query_index, sql_query_params, file_path, opened_streams, previous_stream)

#       "AGGREGATE_USE=COL1=SAVED_ROWS_COUNT|AGGREGATE_COUNT_COL1|AGGREGATE_SUM_COL2=04f,COL2=AGGREGATE_SUM[0]_COL2|AGGREGATE_SUM[1]_COL2=03f"
    if sql_query_params['USE_AGGREGATE']:
        n0debug_calc(sql_query_params['USE_AGGREGATE'],         "sql_query_params['USE_AGGREGATE']")
        n0debug_calc(opened_stream.saved_rows_count,            "opened_stream.saved_rows_count")
        n0debug_calc(opened_stream.aggregate_count,             "opened_stream.aggregate_count")
        n0debug_calc(opened_stream.aggregate_sum,               "opened_stream.aggregate_sum")
        n0debug_calc(opened_stream.saved_rows_count_per_query,  "opened_stream.saved_rows_count_per_query")
        n0debug_calc(opened_stream.aggregate_count_per_query,   "opened_stream.aggregate_count_per_query")
        n0debug_calc(opened_stream.aggregate_sum_per_query,     "opened_stream.aggregate_sum_per_query")

        for column_name_where_to_use,aggregate_vars in sql_query_params['USE_AGGREGATE'].items():
            if column_name_where_to_use in opened_stream.header:
                placeholders = {}
                for placeholder_name,aggregate_format in aggregate_vars.items():
                    aggregate_function    = placeholder_name
                    aggregate_query_index = None
                    aggregate_column_name = None
                    if '.' in aggregate_function:
                        aggregate_function,aggregate_column_name = aggregate_function.split('.', 1)
                    if '[' in aggregate_function:
                        aggregate_function,aggregate_query_index = aggregate_function.split('[', 1)
                        aggregate_query_index = aggregate_query_index.rstrip(']').strip()
                        try:
                            aggregate_query_index = int(aggregate_query_index)
                            if aggregate_query_index < 0:
                                aggregate_query_index += query_index
                        except ValueError as ex:
                            pass
                    n0debug("aggregate_function")
                    n0debug("aggregate_query_index")
                    n0debug("aggregate_column_name")
                    n0debug_calc(aggregate_query_index is not None, "bool(aggregate_query_index)")
                    n0debug_calc(aggregate_query_index is not None, "bool(aggregate_column_name)")

                    if aggregate_function not in ('SAVED_ROWS_COUNT', 'AGGREGATE_COUNT', 'AGGREGATE_SUM'):
                        raise NotImplementedError(f"\{aggregate_function} in {placeholder_name} is not supported")

                    '''
                    # Should work, but doesn't work
                    search_for = (
                        aggregate_function,
                        aggregate_query_index is not None,
                        aggregate_column_name is not None,
                    )
                    n0debug("search_for")
                    search_in = {
                        ('SAVED_ROWS_COUNT', False, False ): opened_stream.saved_rows_count,
                        ('SAVED_ROWS_COUNT', True,  False ): opened_stream.saved_rows_count_per_query.get(aggregate_query_index, None),
                        ('AGGREGATE_COUNT',  False, True  ): opened_stream.aggregate_count.get(aggregate_column_name, None),
                        ('AGGREGATE_COUNT',  True,  True  ): opened_stream.aggregate_count_per_query.get(aggregate_query_index, {}).get(aggregate_column_name, None),
                        ('AGGREGATE_SUM',    False, True  ): opened_stream.aggregate_sum.get(aggregate_column_name, None),
                        ('AGGREGATE_SUM',    True,  True  ): opened_stream.aggregate_sum_per_query.get(aggregate_query_index, {}).get(aggregate_column_name, None),
                    }
                    n0debug("search_in")
                    '''
                    search_for = f"{aggregate_function};{aggregate_query_index is not None};{aggregate_column_name is not None}"
                    n0debug("search_for")
                    search_in = {
                        'SAVED_ROWS_COUNT;False;False': opened_stream.saved_rows_count,
                        'SAVED_ROWS_COUNT;True;False':  opened_stream.saved_rows_count_per_query.get(aggregate_query_index, None),
                        'AGGREGATE_COUNT;False;True':   opened_stream.aggregate_count.get(aggregate_column_name, None),
                        'AGGREGATE_COUNT;True;True':    opened_stream.aggregate_count_per_query.get(aggregate_query_index, {}).get(aggregate_column_name, None),
                        'AGGREGATE_SUM;False;True':     opened_stream.aggregate_sum.get(aggregate_column_name, None),
                        'AGGREGATE_SUM;True;True':      opened_stream.aggregate_sum_per_query.get(aggregate_query_index, {}).get(aggregate_column_name, None),
                    }
                    n0debug("search_in")

                    placeholder_value = search_in.get(search_for)
                    n0debug("placeholder_value")

                    # placeholder_value = search_in.get(search_for,
                        ### exception will be raised in any cases
                        # # pytl_core.raiser(
                            # # NotImplementedError(
                                # # f"Unknown: {aggregate_function}"
                                # # f"{'['+aggregate_query_index+']' if aggregate_query_index is not None else ''}"
                                # # f"{'.'+aggregate_column_name if aggregate_column_name is not None else ''}"
                            # # )
                        # # )
                    # )
                    # n0debug("placeholder_value")
                    if placeholder_value is not None:
                        placeholder_name = placeholder_name.replace('[','\[').replace('.','\.')
                        placeholders.update({re.compile(f"%{placeholder_name}%"): f"{{:{aggregate_format}}}".format(placeholder_value)})

                if placeholders:
                    # n0debug_calc(sql_query_params['MASK_COLUMNS'], "sql_query_params['MASK_COLUMNS']")
                    if column_name_where_to_use not in opened_stream.sql_query_params['MASK_COLUMNS']:
                        opened_stream.sql_query_params['MASK_COLUMNS'][column_name_where_to_use] = dict()
                    opened_stream.sql_query_params['MASK_COLUMNS'][column_name_where_to_use].update(placeholders)
                    n0debug_calc(sql_query_params['MASK_COLUMNS'], "sql_query_params['MASK_COLUMNS']")

    return opened_streams[file_path]
########################################################################################################################
########################################################################################################################
def execute_sql(sql_query_params: dict):
    db_connection = __params__['DB_CONNECTIONS'][sql_query_params['SOURCE_DB']]

    combined_config = {**pytl_globals.config, **__params__}
    n0debug("combined_config")   #######

    sql_query_params['SQL_TEXT'] = \
    stripped_sql_text = \
    sql_text = \
        pytl_core.utils.load_statement_from_file(
            sql_full_path := sql_query_params['SQL_FULL_PATH'],
            combined_config
    )

    sql_query_params['BINDED_VARS'] = \
    binded_vars = {
        key: value
        for key, value in combined_config.items()
        if re.search(":" + key + "(\W|$)", sql_text)
    }

    is_ananymos_block = False
    if sql_query_params['SQL_TYPE'] == "AUTO":
        regexp_remove_patterns = (
            ( re.compile(r'/\*.*?\*/\s*($|\n)', flags=re.DOTALL),                   ''   ),
            ( re.compile(r'\s*--.*?($|\n)'),                                        '\n' ),
            ( re.compile(r'(^|\n)\s*SET\s*.*', flags=re.IGNORECASE),                ''   ),
            ( re.compile(r'(^|\n)\s*EXIT\s*;?', flags=re.IGNORECASE),               ''   ),
            ( re.compile(r'\s*($|\n)'),                                             '\n' ),
            ( re.compile(r'\s*/($|\n)'),                                            '\n' ),
            ( re.compile(r'\n\n'),                                                  '\n' ),
            ( re.compile(r'^\s*'),                                                  ''   ),
            ( re.compile(r'\s*$'),                                                  ''   ),
        )
        regexp_match_patterns = (
            re.compile(r'^(ALTER\s+SESSION.*?\n)*(DECLARE|BEGIN).*END\s*;?$',   flags=re.DOTALL|re.IGNORECASE),
            re.compile(r'^(ALTER\s+SESSION.*?\n?)+$',                           flags=re.IGNORECASE),
        )
        for regexp_remove_pattern in regexp_remove_patterns:
            stripped_sql_text = regexp_remove_pattern[0].sub(regexp_remove_pattern[1], stripped_sql_text)
        is_ananymos_block = any(regexp_match_pattern.match(stripped_sql_text) for regexp_match_pattern in regexp_match_patterns)
        n0debug("sql_text")   #######
        n0debug("stripped_sql_text")   #######
        n0debug("binded_vars")   #######
        n0debug_calc(f"{is_ananymos_block}\t{sql_full_path}")

    if is_ananymos_block:
        sql_query_params['SQL_TYPE'] = "ANONYMOUS_BLOCK"
        sql_query_params['SQL_CURSOR'] = None
        db_connection.execute_statement_or_anonym_block(
            statement = sql_text,
            bind_vars = binded_vars,
            sql_file  = sql_query_params['SQL_QUERY_NAME']
            # batch_size = __params__['BATCH_SIZE'],
        )
    else:
        sql_query_params['SQL_TYPE'] = "QUERY"
        if __params__['OUTPUT_ENGINE'] == 'DB':
            execute_sql_function = db_connection.execute_select_batch
        else:
            execute_sql_function = db_connection.execute_select_seamlessly
        sql_query_params['SQL_CURSOR'] = execute_sql_function(
            statement = sql_text,
            bind_vars = binded_vars,
            sql_file  = sql_query_params['SQL_QUERY_NAME'],
            batch_size = __params__['BATCH_SIZE'],
        )
    sql_query_params['CURSOR_METADATA'] = db_connection.current_cursor_metadata
    n0debug("sql_query_params")   #######
########################################################################################################################
########################################################################################################################
def main(_config: None) -> None:
########################################################################################################################
########################################################################################################################
########################################################################################################################
    combined_config = {**pytl_globals.config, **__params__}
    try:
        for key, value in combined_config.items():
            n0debug_calc(value, f"combined_config[{key}]")
    except KeyError as ex:
        if ex != key:
            n0error(f"Mandatory parameter {ex} during generation of {key} is not provided")
        else:
            n0error(f"Mandatory parameter {ex} is not provided")
        sys.exit(-999)

    ############################################################################
    ## Find all *.sql files related to PyTL_OmniReports
    ## (and other PyTL_IS_*Reports) and generate dict for quick search
    ############################################################################
    found_sql_files = pytl_core.get_all_related_files(
                                (
                                    "PyTL_OmniReports",
                                    # "PyTL_IS_SimpleReports",
                                    # "PyTL_IS_HtmlReports",
                                    # "PyTL_IS_XlsReports",
                                ),
                                "*.sq?",
                                Path(__file__).absolute().parent,
    )
    n0debug("found_sql_files")  #######

    ############################################################################
    ## Init variables once per run
    ############################################################################
    if os.path.dirname(__params__['OUTPUT_FN_RELATED']):
        destination_filename_template = __params__['OUTPUT_FN_RELATED']
    else:
        destination_filename_template = os.path.join(__params__['DST_DIR'], __params__['ROUTING_DIR'], __params__['OUTPUT_FN_RELATED'])
    pytl_core.logging.info(f"{destination_filename_template=}")

    ############################################################################
    # worksheet_or_datasource_name in case of:
    #   XLS:            worksheet name
    #   XML:            datasource name
    #   CSV(DSV,FWF):   name of first SQL file
    ############################################################################
    # Open DB connections and cursors for each SQL file
    # Open connection (if it was not opened)
    # and execute db_connection.execute_select_seamlessly(..) per each SQL file
    ############################################################################
    n0debug_calc(__params__['SOURCE_OF_DATA'] , "__params__['SOURCE_OF_DATA']")  #######
    # SOURCE_OF_DATA = { First SQL name (SQL_QUERIES) or Worksheet name (XLS_SHEETS) or Jinja source name (DATA_SOURCES): [{paramN: value}, {paramN: value}] }
    if __params__['OUTPUT_ENGINE'] != 'CSV':
        __params__['CSV_GENERATOR'] = None

    for worksheet_or_datasource_name in tuple(__params__['SOURCE_OF_DATA'].keys()):  # Mitigate RuntimeError: dictionary keys changed during iteration
        sql_queries = __params__['SOURCE_OF_DATA'][worksheet_or_datasource_name]
        n0debug_calc(sql_queries, f"__params__['SOURCE_OF_DATA'][{worksheet_or_datasource_name}]")   #######

        for sql_query_params in sql_queries:
            sql_query_params['SQL_FULL_PATH'] = \
            sql_full_path = get_related_file_path(found_sql_files, sql_query_params['SQL_QUERY_NAME'])

            sql_query_params['SQL_QUERY_NAME'] = \
            sql_query_name = str(sql_full_path.stem.upper())
            n0debug("sql_query_name")   #######

            source_db = sql_query_params['SOURCE_DB']
            if source_db not in __params__['DB_CONNECTIONS']:
                __params__['DB_CONNECTIONS'][source_db] = pytl_globals.config[source_db]
            if isinstance(__params__['DB_CONNECTIONS'][source_db], str):
                __params__['DB_CONNECTIONS'][source_db] = \
                    pytl_core.Connection(
                        __params__['DB_CONNECTIONS'][source_db],
                        (pytl_globals.config['INTERCHANGE_JOB_DIR'].lstrip(__params__['JOB_NAME']+"_") or __params__['JOB_NAME']) + " " + date_timestamp()[-6:]
                )
            db_connection = __params__['DB_CONNECTIONS'][sql_query_params['SOURCE_DB']]

            '''
            #*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
            #*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
            #*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*

            sql_query_params['SQL_TEXT'] = \
            sql_text = \
                pytl_core.utils.load_statement_from_file(
                    sql_full_path,
                    combined_config
            )

            sql_query_params['BINDED_VARS'] = \
            binded_vars = {
                key: value
                for key, value in combined_config.items()
                if re.search(":" + key + "(\W|$)", sql_text)
            }

            if __params__['OUTPUT_ENGINE'] == 'DB':
                # execute_select = db_connection.execute_select_batch
                sql_query_params['SQL_CURSOR'] = db_connection.execute_select_batch(
                    statement = sql_text,
                    bind_vars = binded_vars,
                    sql_file  = sql_query_name,  # will be supported in pytl_core 2.14+
                    batch_size = __params__['BATCH_SIZE'],
                )
            else:
                # execute_select = db_connection.execute_select_seamlessly
                sql_query_params['SQL_CURSOR'] = db_connection.execute_select_seamlessly(
                    statement = sql_text,
                    bind_vars = binded_vars,
                    sql_file  = sql_query_name,  # already supported in pytl_core 2.12+
                    batch_size = __params__['BATCH_SIZE'],
                )
            # sql_query_params['SQL_CURSOR'] = execute_select(

            n0debug("sql_query_params")   #######
            n0debug_calc(db_connection.current_cursor_metadata, "db_connection.current_cursor_metadata")    #######

            #*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
            #*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
            #*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
            '''

        if __params__['OUTPUT_ENGINE'] == 'XLS':
            # Exchange Worksheet name with full file path with Worksheet name for XLS
            __params__['SOURCE_OF_DATA'][destination_filename_template + "::" + worksheet_or_datasource_name] = \
                __params__['SOURCE_OF_DATA'].pop(worksheet_or_datasource_name)
        elif __params__['OUTPUT_ENGINE'] in ('CSV', 'DB'):
            # Single destination template for CSV/FWF
            __params__['SOURCE_OF_DATA'][destination_filename_template] = __params__['SOURCE_OF_DATA'].pop(worksheet_or_datasource_name)
        # elif __params__['OUTPUT_ENGINE'] in ('XML'):
            # Nothing to do, because of it's datasources for Jinja2

    n0debug_calc(__params__['SOURCE_OF_DATA'], "__params__['SOURCE_OF_DATA']")  #######

    ############################################################################
    # Execute 1 time per session before main loop per SQL queries ('XLS', 'CSV', 'DB', 'XML'):
    #   1) Load required files with additional configs
    #   2) Define common parameters, used during the session
    #   3) Call method(s) if it(they) should be called 1 time per session (for example: XML)
    ############################################################################
    if __params__['OUTPUT_ENGINE'] == 'XLS':
        ############################################################################
        ## Find all *.yaml files related to PyTL_OmniReports/PyTL_IS_XlsReports and generate dict for quick search
        ############################################################################
        if __params__['STYLE_FILES']:
            report_styles_files = pytl_core.get_all_related_files(
                                        (
                                            "PyTL_OmniReports",
                                            ## "PyTL_IS_XlsReports",
                                        ),
                                        (
                                            "*.yaml",
                                            "*.yml",
                                        ),
                                        Path(__file__).absolute().parent,
            )
            spreadsheet_settings = {}
            for style_file in __params__['STYLE_FILES']:
                spreadsheet_settings.update(yaml.load(load_file(get_related_file_path(report_styles_files, style_file)), Loader=yaml.FullLoader))
            __params__['XLS_STYLES'] = prepare_openpyxl_styles(spreadsheet_settings)
    elif __params__['OUTPUT_ENGINE'] == 'XML':
        ############################################################################
        ## Find all template files related to PyTL_OmniReports/PyTL_IS_HtmlReports and generate dict for quick search
        ############################################################################

        for worksheet_or_datasource_name in tuple(__params__['SOURCE_OF_DATA'].keys()):  # Mitigate RuntimeError: dictionary keys changed during iteration
            sql_queries = __params__['SOURCE_OF_DATA'][worksheet_or_datasource_name]
            n0debug_calc(sql_queries, f"__params__['SOURCE_OF_DATA'][{worksheet_or_datasource_name}]")   #######

            for sql_query_params in sql_queries:
                sql_query_params['SQL_FULL_PATH'] = \
                sql_full_path = get_related_file_path(found_sql_files, sql_query_params['SQL_QUERY_NAME'])

                sql_query_params['SQL_QUERY_NAME'] = \
                sql_query_name = str(sql_full_path.stem.upper())
                n0debug("sql_query_name")   #######

                source_db = sql_query_params['SOURCE_DB']
                if source_db not in __params__['DB_CONNECTIONS']:
                    __params__['DB_CONNECTIONS'][source_db] = pytl_globals.config[source_db]
                if isinstance(__params__['DB_CONNECTIONS'][source_db], str):
                    __params__['DB_CONNECTIONS'][source_db] = \
                        pytl_core.Connection(
                            __params__['DB_CONNECTIONS'][source_db],
                            (pytl_globals.config['INTERCHANGE_JOB_DIR'].lstrip(__params__['JOB_NAME']+"_") or __params__['JOB_NAME']) + " " + date_timestamp()[-6:]
                    )
                db_connection = __params__['DB_CONNECTIONS'][sql_query_params['SOURCE_DB']]

                #*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
                #*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
                #*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*

                sql_query_params['SQL_TEXT'] = \
                sql_text = \
                    pytl_core.utils.load_statement_from_file(
                        sql_full_path,
                        combined_config
                )

                sql_query_params['BINDED_VARS'] = \
                binded_vars = {
                    key: value
                    for key, value in combined_config.items()
                    if re.search(":" + key + "(\W|$)", sql_text)
                }

                if __params__['OUTPUT_ENGINE'] == 'DB':
                    # execute_select = db_connection.execute_select_batch
                    sql_query_params['SQL_CURSOR'] = db_connection.execute_select_batch(
                        statement = sql_text,
                        bind_vars = binded_vars,
                        sql_file  = sql_query_name,  # will be supported in pytl_core 2.14+
                        batch_size = __params__['BATCH_SIZE'],
                    )
                else:
                    # execute_select = db_connection.execute_select_seamlessly
                    sql_query_params['SQL_CURSOR'] = db_connection.execute_select_seamlessly(
                        statement = sql_text,
                        bind_vars = binded_vars,
                        sql_file  = sql_query_name,  # already supported in pytl_core 2.12+
                        batch_size = __params__['BATCH_SIZE'],
                    )
                # sql_query_params['SQL_CURSOR'] = execute_select(

                n0debug("sql_query_params")   #######
                n0debug_calc(db_connection.current_cursor_metadata, "db_connection.current_cursor_metadata")    #######

                #*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
                #*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*
                #*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*#*


        report_template_files = pytl_core.get_all_related_files(
                                    (
                                        "PyTL_OmniReports",
                                        ## "PyTL_IS_HtmlReports",
                                    ),
                                    (
                                        "*.htm*",
                                        "*.jinja*",
                                        "*.templ*",
                                    ),
                                    Path(__file__).absolute().parent,
        )
        ## Using of jinja2.Environment() is mandatory for definition of own filters
        jinja2_env = jinja2.Environment()
        jinja2_env.filters["to_date"] = to_date
        jinja2_env.filters["to_currency"] = lambda v, precision=2: round(float(v.replace(',', '')), precision)
        jinja2_env.filters["n0debug"] = n0pretty
        template_full_path = get_related_file_path(report_template_files, __params__['TEMPLATE'])
        ## jinja2_template = jinja2.Template(load_file(template_full_path))
        jinja2_template = jinja2_env.from_string(load_file(template_full_path))

        combined_config = {**pytl_globals.config, **__params__}
        destination_file_path = str(Path(
            destination_filename_template.format(**combined_config)
                .translate(
                    {
                        ord(c): ord('_')
                        for c in "\"'`^&|<>*? "
                    }
                )
        ))
        if not __params__['OVERWRITE_OUTPUT']:
            backup_file_path = unique_file_path(destination_file_path)
            if str(backup_file_path) != destination_file_path:
                os.rename(destination_file_path, backup_file_path)

        # data_sources = { **__params__['SOURCE_OF_DATA'],  'config': combined_config }
        data_sources = {}
        for data_source_name,data_source in __params__['SOURCE_OF_DATA'].items():
            data_sources[data_source_name] = data_source[0]['SQL_CURSOR'] \
                                             if len(data_source) == 1 else \
                                             [sql_query['SQL_CURSOR'] for sql_query in data_source]
        data_sources['config'] = combined_config
        pytl_core.logging.info(f"Saving report into '{destination_file_path}'")
        n0debug("data_sources")        #######

        sysdate = date_today()
        rendered_buffer = jinja2_template.render(
            **data_sources,
            timestamp               = date_timestamp(sysdate).replace('_', ''),
            sysdate_dash_yyyymmdd   = date_dash_yyyymmdd(sysdate),
            systime_colon_hhmmss    = time_colon_hhmmss(sysdate),
            ORG                     = __params__['ORG'],
        ).encode('UTF-8')  # Binary mode was done specially to support Posix new line at Windows

        if __params__['MASK_ALL']:
            for _pattern,_replace in __params__['MASK_PATTERN'].items():
                n0debug("_pattern")
                n0debug("_replace")
                rendered_buffer = _pattern.sub(_replace, rendered_buffer)

        save_file(destination_file_path, rendered_buffer)
    else:
        # CSV, DB
        pass

    ############################################################################
    # Execute so many times like SQL queries were defined ('XLS', 'CSV', 'DB')
    ############################################################################
    n0debug_calc(__params__['OUTPUT_ENGINE'], "__params__['OUTPUT_ENGINE']")    #######
    if __params__['OUTPUT_ENGINE'] in ('XLS', 'CSV', 'DB'): # Not Jinja2
        for destination_filename_template,sql_queries in __params__['SOURCE_OF_DATA'].items():
            n0debug("destination_filename_template")
            n0debug("sql_queries")
            pytl_globals.config['TOTAL_FETCHED_ROWS_COUNT'] = 0

            for query_index,sql_query_params in enumerate(sql_queries):
                n0debug("query_index")
                n0debug("sql_query_params")
                execute_sql(sql_query_params)
                if sql_query_params['SQL_TYPE'] == "ANONYMOUS_BLOCK":
                    continue

                if sql_query_params['SAVE_INTO']:
                    result = list(sql_query_params['SQL_CURSOR'])
                    n0debug("result")
                    if len(result) == 1 or sql_query_params['SAVE_INTO_TYPE'] in ("STR", "DICT"):
                        result = result[0]

                        if (sql_query_params__ONLY_COLUMNS:=sql_query_params['ONLY_COLUMNS']):
                            result = {
                                column_name: result.get(column_name)
                                for column_name in sql_query_params__ONLY_COLUMNS
                            }
                        elif (sql_query_params__SKIP_COLUMNS:=sql_query_params['SKIP_COLUMNS']):
                            result = {
                                column_name: column_value
                                for column_name,column_value in result.items()
                                if column_name not in sql_query_params__SKIP_COLUMNS
                            }

                        if len(result.keys()) == 1 or sql_query_params['SAVE_INTO_TYPE'] == "STR":
                            sql_query_params['SAVE_INTO_TYPE'] = "STR"
                            result = tuple(result.values())[0]
                        else:
                            sql_query_params['SAVE_INTO_TYPE'] = "DICT"
                    else:
                        # "AUTO" or "LIST"
                        sql_query_params['SAVE_INTO_TYPE'] = "LIST"
                    n0debug("result")
                    pytl_globals.config[sql_query_params['SAVE_INTO']] = result
                    continue

                if sql_query_params['SQL_QUERY_ID'] is not None:
                    query_index = sql_query_params['SQL_QUERY_ID']

                pytl_globals.config['FETCHED_ROWS_COUNT'] = 0

                n0debug("sql_query_params") #######
                opened_stream = None
                if __params__['OUTPUT_ENGINE'] in ('XLS', 'CSV'):

                    for fetched_row_index,fetched_row in enumerate(sql_query_params['SQL_CURSOR']):
                        pytl_globals.config['FETCHED_ROWS_COUNT'] += 1
                        pytl_globals.config['TOTAL_FETCHED_ROWS_COUNT'] += 1

                        n0debug("fetched_row")                      #######
                        n0debug("destination_filename_template")    #######
                        destination_file_path = str(Path(
                            destination_filename_template.format(**{**pytl_globals.config, **__params__ , **fetched_row})
                                .translate(
                                    {
                                        ord(c): ord('_')
                                        for c in "\"'`^&|<>*? "
                                    }
                                )
                        ))
                        n0debug("destination_file_path")            #######

                        opened_stream = open_or_get_stream(
                            file_path = destination_file_path,
                            sql_query_params = sql_query_params,
                            query_index = query_index,
                        )

                        # Writing happends with delay of one row -- just to understand if it's last row or not
                        # So writing previous row if exists (2nd and next loops)
                        opened_stream.mask_and_write_last_row()

                        # Save the row to write at the next round of the loop
                        opened_stream.last_row = [
                            field_value if (field_value:=fetched_row.get(column_name)) else ''
                            for column_name in opened_stream.header
                        ]


                        for column_name in sql_query_params['AGGREGATE_SUM']:
                            field_value = fetched_row[column_name]
                            n0debug("field_value")
                            try:
                                # field_value = float(fetched_row.get(column_name))
                                field_value = float(field_value)
                            except (ValueError, TypeError) as ex:
                                field_value = 0.
                            n0debug("field_value")
                            opened_stream.aggregate_sum[column_name] += field_value
                            opened_stream.aggregate_sum_per_query[query_index][column_name] += field_value
                        for column_name in sql_query_params['AGGREGATE_COUNT']:
                            # if fetched_row.get(column_name):
                            if fetched_row[column_name]:
                                opened_stream.aggregate_count[column_name] += 1
                                opened_stream.aggregate_count_per_query[query_index][column_name] += 1


                elif __params__['OUTPUT_ENGINE'] == 'DB':
                    streamdb = PyTL_StreamDB(query_index, sql_query_params)

                    pytl_globals.config['FETCHED_ROWS_COUNT'] = streamdb.fetched_rows_count
                    pytl_globals.config['TOTAL_FETCHED_ROWS_COUNT'] += streamdb.fetched_rows_count
                else:
                    raise NotImplementedError(
                        f"Unexpected value '{__params__['OUTPUT_ENGINE']}' in parameter 'OUTPUT_ENGINE'."
                        " Expected: XLS, CSV, DB"
                    )

                ############################################################################
                ## Save the last row (trailer) after each query for all files
                ############################################################################
                for opened_stream in opened_streams.values():
                    opened_stream.mask_and_write_last_row(block_type = 2)  # trailer (last row)

                ############################################################################
                ## Create empty report
                ############################################################################
                n0debug_calc(opened_streams, "opened_streams")    #######
                if sql_query_params['CREATE_EMPTY_REPORT'] and __params__['OUTPUT_ENGINE'] in ('XLS', 'CSV') \
                   and not any(query_index in opened_stream.saved_rows_count_per_query.keys() for opened_stream in opened_streams.values()):
                    combined_config = {**pytl_globals.config, **__params__}
                    n0debug("combined_config")      #######

                    filename_changers = re.findall(r"{(.*?)}", destination_filename_template)
                    n0debug("filename_changers")    #######

                    for filename_changer in filename_changers:
                        if filename_changer not in combined_config:
                            pytl_core.logging.info(f"Impossible to generate empty files '{destination_filename_template}', because of '{filename_changer}' must be returned from SQL selection.")
                            break
                    else:
                        if sql_query_params['WRITE_HEADER']:
                            sql_query_params['SQL_TEXT'] = \
                                f"select t2.DUMMY_COLUMN_ONLY_FOR_JOIN, t1.* from ({sql_query_params['SQL_TEXT']}) t1 " \
                                "full outer join (" \
                                "select null as DUMMY_COLUMN_ONLY_FOR_JOIN from dual" \
                                ") t2 on t2.DUMMY_COLUMN_ONLY_FOR_JOIN = t1.ORG"
                            sql_query_params['SQL_CURSOR'] = \
                                __params__['DB_CONNECTIONS'][sql_query_params['SOURCE_DB']].execute_select_seamlessly(
                                    statement = sql_query_params['SQL_TEXT'],
                                    bind_vars = sql_query_params['BINDED_VARS'],
                                    sql_file  = "DUMMY " + sql_query_params['SQL_QUERY_NAME']
                                )
                            if not sql_query_params['ONLY_COLUMNS']:
                                sql_query_params['SKIP_COLUMNS'] = sql_query_params['SKIP_COLUMNS'] | {"DUMMY_COLUMN_ONLY_FOR_JOIN"}
                        else:
                            __params__['DB_CONNECTIONS'][sql_query_params['SOURCE_DB']].current_cursor_metadata = []

                        for org in set(deserialize_list(__params__['ORG_LIST'], delimiter = ',')):
                            destination_file_path = destination_filename_template.format(**{**combined_config, **{'ORG': org}}) \
                                .translate(
                                    {
                                        ord(c): ord('_')
                                        for c in "\"'`^&|<>*? "
                                    }
                                )
                            n0debug("destination_file_path")        #######
                            opened_stream = open_or_get_stream(
                                file_path = destination_file_path,
                                sql_query_params = sql_query_params,
                                query_index = query_index,
                            )

    ############################################################################
    ## Close/save reports
    ############################################################################

    # Close streams
    saved_report_files = defaultdict(lambda: defaultdict(int))
    for opened_stream in opened_streams.values():
        saved_report_files[opened_stream.file_path]['saved_rows_count']    += opened_stream.saved_rows_count  # saved_rows_count in file or worksheet
        saved_report_files[opened_stream.file_path]['create_empty_report'] |= opened_stream.sql_query_params['CREATE_EMPTY_REPORT']
        saved_report_files[opened_stream.file_path]['minimum_rows']         = opened_stream.sql_query_params['MINIMUM_ROWS']
        if __params__['OUTPUT_ENGINE'] == 'CSV':
            pytl_core.logging.info(f"****** Closing destination file '{opened_stream.file_path}'...")
            pytl_core.logging.info(f"***** {opened_stream.saved_rows_count} (possible empty) rows were written{' (empty rows were skipped)' if not __params__['WRITE_EMPTY_ROWS'] else ''}.")
            if __params__['WRITE_EOF']:
                pytl_core.logging.info(f"***** EOF mark is written.")
                if opened_stream.sql_query_params['CSV_GENERATOR'] == 'NATIVE':
                    opened_stream.outfile.write('\x1A')
                else:
                    opened_stream._write_row('\x1A')
                
        opened_stream.close() # self.outstream.close() + self.outfile.close()

    # Save workbooks
    if __params__['OUTPUT_ENGINE'] == 'XLS':
        opened_workbooks = {
            opened_stream.file_path: opened_stream.outfile
            for opened_stream in opened_streams.values()
            if opened_stream.outfile
        }
        for file_path, opened_workbook in opened_workbooks.items():
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            pytl_core.logging.info(f"****** Saving destination file '{file_path}'...")
            pytl_core.logging.info(f"***** {saved_report_files[file_path]} (possible empty) rows into ALL WORKSHEETS were written{' (empty rows were skipped)' if not __params__['WRITE_EMPTY_ROWS'] else ''}.")

            if not __params__['OVERWRITE_OUTPUT']:
                backup_file_path = unique_file_path(file_path)
                if backup_file_path != Path(file_path):
                    os.rename(file_path, backup_file_path)

            opened_workbook.save(file_path)

    for file_path,saved_report_file_params in {**saved_report_files}.items():
        if not saved_report_file_params['create_empty_report'] and saved_report_file_params['saved_rows_count'] < saved_report_file_params['minimum_rows']:
            # Delete empty files if CREATE_EMPTY_REPORT is False
            Path(file_path).unlink(missing_ok=True)
            pytl_core.logging.info(f"****** Deleted '{file_path}' because of it contains {saved_report_file_params['saved_rows_count']} rows with minimum {saved_report_file_params['minimum_rows']}")
            del saved_report_files[file_path]

    if __params__['SAVE_REPORT_FILES']:
        destination_file_path = __params__['SAVE_REPORT_FILES'].format(**combined_config) \
                        .translate(
                            {
                                ord(c): ord('_')
                                for c in "\"'`^&|<>*? "
                            }
                        )
        save_file(destination_file_path, saved_report_files.keys())

    ############################################################################
    ## Close DB_CONNECTIONS
    ############################################################################
    n0debug_calc(__params__['DB_CONNECTIONS'], "__params__['DB_CONNECTIONS']")  #######
    for db_connection_name,db_connection in __params__['DB_CONNECTIONS'].items():
        if isinstance(db_connection, pytl_core.oracle_db.Connection):
            db_connection.close()
