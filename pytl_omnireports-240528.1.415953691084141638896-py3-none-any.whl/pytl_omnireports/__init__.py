print("="*60 + f" START: {__file__}")

__version__ = "240528.1"
__job_name__ = "PyTL_OmniReports"
__bat_files__ = ["PyTL_OmniReports.bat"]

print(f"{__version__=}")
print(f"{__job_name__=}")
print(f"{__bat_files__=}")

print("-"*60 + f" END: {__file__}")
