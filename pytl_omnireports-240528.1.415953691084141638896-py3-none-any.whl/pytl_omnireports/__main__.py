from pathlib import Path
import pytl_core
import pytl_core.pytl_globals as pytl_globals
from n0struct import *


########################################################################################################################
########################################################################################################################

n0print(f"{'='*23} START: Importing in {__file__}")
try:
    # Could be imported ONLY if it's run as NORMAL py
    n0print(f"=-= NORMAL {'=-='*4} from __init__ import __job_name__, __version__")
    from __init__ import (
        __job_name__,
        __version__,
    )
    
    n0print(f"=-= NORMAL {'=-='*4} from _PyTL_OmniReports import main")
    from _PyTL_OmniReports import main

except ModuleNotFoundError as ex:
    n0print(f"{'#'*23} not NORMAL")
    try:
        # Could be imported ONLY if it's run as MODULE
        n0print(f"=-= MODULE {'=-='*4} from . import __job_name__")
        from . import __job_name__
        
        from importlib_metadata import version as importlib_metadata_version
        __version__ = importlib_metadata_version(__job_name__)
        
        n0print(f"=-= MODULE {'=-='*4} from ._PyTL_OmniReports import main")
        from ._PyTL_OmniReports import main
        
    except Exception as ex:
        n0print(f"{'#'*23} FATAL ERROR: Importing in {__file__} as MODULE: {ex}")
        
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_type, exc_value, exc_traceback = sys.exc_info() # most recent (if any) by default
        traceback_details = {
                             'filename': exc_traceback.tb_frame.f_code.co_filename,
                             'lineno'  : exc_traceback.tb_lineno,
                             'name'    : exc_traceback.tb_frame.f_code.co_name,
                             'type'    : exc_type.__name__,
                             'message' : exc_value.message, # or see traceback._some_str()
                            }
        n0print(traceback.format_exc())
        n0print(traceback_details)
        
        exit(-999)
        
n0print(f"{'-'*23} END: Importing in {__file__}")
########################################################################################################################
n0print(f"{'*'*23} {__job_name__} v{__version__} ==  {__name__}")
if __name__ == "__main__":
    config = pytl_globals.config = pytl_core.Config.configure_pytl_core({'JOB_FILE': __file__, 'JOB_NAME': __job_name__})
    n0print("pytl_globals.config\n"+'\n'.join(["="*40]+[f"{key}={value}" for key, value in pytl_globals.config.items()]+["-"*40]))
    pytl_core.logging.debug(f"Config: initialization finished, variable 'pytl_globals.config' is created.")

    try:
        if config.get('LOCK_FILE'):
            config['LOCK_FILE'] = Path(config['LOCK_FILE'])
            config['LOCK_FILE'].parent.mkdir(parents=True, exist_ok=True)
            config['LOCK_FILE'].unlink(missing_ok=True)
            with open(config['LOCK_FILE'], 'wt') as fh:
                pytl_core.logging.debug(f"Lock file '{config['LOCK_FILE']}' is created.")
                fh.write(config['JOB_FILE'])
        pytl_core.logger.org_logging_info(f"******* {__file__}@{__job_name__} v{__version__} is STARTED")
        pytl_core.logging.info("*"*23 + f" execute main(config)")
        main(config)
        pytl_core.logger.org_logging_info(f"******* {__file__}@{__job_name__} v{__version__} is COMPLETED")
    except Exception as ex:
        # it doesn't catch BaseException or the system-exiting exceptions SystemExit, KeyboardInterrupt and GeneratorExit
        n0print(ex.message, ex.args)
    except:
        # it catches all other exceptions: BaseException or the system-exiting exceptions SystemExit, KeyboardInterrupt and GeneratorExit
        pass
    if config.get('LOCK_FILE'):
        pytl_core.logging.debug(f"Lock file '{config['LOCK_FILE']}' is deleted.")
        config['LOCK_FILE'].unlink(missing_ok=True)

n0print("-"*60 + f" END: Body of '{__file__}'")
