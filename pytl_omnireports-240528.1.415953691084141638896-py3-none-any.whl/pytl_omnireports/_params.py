# import os
from pathlib import Path
import re
import zipfile
import pytl_core
import pytl_core.pytl_globals as pytl_globals
from n0struct import (
    deserialize_list,
    deserialize_fixed_list,
    deserialize_dict,
    deserialize_key_value,
    validate_values,
    validate_bool,
    validate_path,
    # validate_str,
    isnumber,
    to_date,
    date_to_format,
    date_today,
    # date_timestamp,
    n0debug,
    # n0debug_calc,
    # n0print,
    # n0error,
    raise_in_lambda,
    split_pair,
)

__date_today = date_today()  # Initiated single time per call

__params__ = pytl_core.Params({
################################################################################
# Mandatory incoming parameters for each call
        'ENV':                  lambda: pytl_globals.config['ENV'],             # D:\PYTL\NIC\JOBNAME\W4UAT25.PARM

        'ORG':                  lambda: pytl_globals.config.get('ORG_LIST')
                                        or pytl_globals.config.get('ORGLIST')   # 'or' means that empty ORG_LIST is NOT acceptable
                                        or pytl_globals.config['ORG'],          # "982" || "982,320"
# Is used in few of PyTL_IS_SimpleReports/PyTL_IS_XlsReports
        'ORG_LIST':             lambda: __params__['ORG'],
# Is used in most of PyTL_IS_SimpleReports/PyTL_IS_XlsReports/PyTL_IS_EmbosserFiles
        'ORGLIST':              lambda: __params__['ORG'],
################################################################################
# Predefined mandatory values
        'JOB_NAME':             lambda: pytl_globals.config['JOB_NAME'],
        'SQL_DIR':              lambda: pytl_globals.config['SQL_DIR'],
        'UNIQUE_CALL_ID':       lambda: __inherited_params__['UNIQUE_CALL_ID']['PARSE_LOCAL'](
                                            pytl_globals.config.get('UNIQUE_CALL_ID', date_to_format(__date_today, "%Y%m%d%H%M%S%f"))
                                        ),
################################################################################
# Parameters of data sources -- one of them is mandatory
        'SQL_QUERIES':          lambda: parse_SQL_QUERIES(
                                            pytl_globals.config.get('SQL_QUERIES')
                                         or pytl_globals.config.get('SQL_QUERY')    # 'or' means that empty SQL_QUERIES is NOT acceptable
                                         or pytl_globals.config.get('SQLQUERY')
                                         or pytl_globals.config.get('OUTPUT_FN')
                                        ),
        'XLS_SHEETS':           lambda: parse_XLS_SHEETS(
                                            pytl_globals.config.get('XLS_SHEETS')
                                        ),
        'DATA_SOURCES':         lambda: parse_DATA_SOURCES(
                                            pytl_globals.config.get('DATA_SOURCE')
                                         or pytl_globals.config.get('DATA_SOURCES') # 'or' means that empty DATA_SOURCE is NOT acceptable
                                        ),
        "TEMPLATE":             lambda: pytl_globals.config['TEMPLATE']
                                        if __params__['OUTPUT_ENGINE'] == 'XML' else None
                                        ,
########################################
# Validation that data source parameter is provided
        'OUTPUT_ENGINE':        lambda: validate_values(
                                            (
                                                'XLS' if __params__['XLS_SHEETS'] else (
                                                    'XML' if __params__['DATA_SOURCES'] else (
                                                        'DB' if __params__['SQL_QUERIES'] and __params__['TARGET_DB'] else (
                                                            'CSV' if __params__['SQL_QUERIES'] else (
                                                                raise_in_lambda(
                                                                    ValueError(
                                                                        "No one of parameters XLS_SHEETS, DATA_SOURCES, SQL_QUERIES or SQL_QUERIES+TARGET_DB are defined"
                                                                    )
                                                                )
                                                            )
                                                        )
                                                    )
                                                )
                                                if not (__OUTPUT_ENGINE := pytl_globals.config.get('OUTPUT_ENGINE'))
                                                else __OUTPUT_ENGINE
                                            ),
                                            ("XLS", "XML", "CSV", "DB"),
                                            raise_if_not_found = NotImplementedError(
                                                                    "Unexpected value in parameter 'OUTPUT_ENGINE'. "
                                                                    "Expected: XLS, XML, CSV, DB"
                                                                 )
                                        ),
        'SOURCE_OF_DATA':       lambda: {
                                            **__params__['XLS_SHEETS'],
                                            **__params__['DATA_SOURCES'],
                                            **__params__['SQL_QUERIES']
                                        },
################################################################################
# Global parameters for source of data
        'SOURCE_DB':            lambda: __inherited_params__['SOURCE_DB']['PARSE_LOCAL'](
                                            pytl_globals.config.get(
                                                'SOURCE_DB',
                                                pytl_globals.config.get('DB_SOURCE', pytl_globals.config.get('DBSOURCE', "OWS"))
                                            )
                                        ),
        'TARGET_DB':            lambda: __inherited_params__['TARGET_DB']['PARSE_LOCAL'](
                                            pytl_globals.config.get('TARGET_DB')
                                        ),
        'TARGET_TABLE':         lambda: __inherited_params__['TARGET_TABLE']['PARSE_LOCAL'](
                                            pytl_globals.config.get('TARGET_TABLE', "PyTL_Serialized_Data")
                                        ),
        'TARGET_COLUMNS':       lambda: __inherited_params__['TARGET_COLUMNS']['PARSE_LOCAL'](
                                            pytl_globals.config.get('TARGET_COLUMNS')
                                        ),
# Parameters from file .parm file defined in pytl_globals.config['ENV']
        'DB_CONNECTIONS':       lambda: {
                                            pytl_db_source_name[0]: db_connection
                                            for pytl_db_source_name in CONNECTION_SYNONYMS
                                            if (db_connection:=pytl_globals.config.get(pytl_db_source_name[1]))
                                        },
        'BATCH_SIZE':           lambda: int(pytl_globals.config.get('BATCH_SIZE') or 50000),
################################################################################
# Date parameters
        'INPUT_DATE_FORMAT':    lambda: pytl_globals.config.get('INPUT_DATE_FORMAT')
                                        or "%d-%m-%Y",
        'OUTPUT_DATE_FORMAT':   lambda: pytl_globals.config.get('OUTPUT_DATE_FORMAT')
                                        or "%Y%m%d",
        'P_REPORT_DATE':        lambda: pytl_globals.config.get('P_REPORT_DATE')
                                        or date_to_format(date_today(), __params__['INPUT_DATE_FORMAT']),
################################################################################
        'FULL_JOB_NAME':        lambda: pytl_globals.config.get('FULL_JOB_NAME')
                                        or (__params__['JOB_NAME'] + '_' + __params__['FIRST_QUERY']),
################################################################################
# File name parameters
        'FIRST_QUERY':          lambda: Path(
                                            list(__params__['SOURCE_OF_DATA'].values())[0][0]['SQL_QUERY_NAME'].upper()
                                        ).stem,
        'OUTPUT_FN_PREFIX':     lambda: __params__['FIRST_QUERY']
                                        if (__OUTPUT_FN_PREFIX := pytl_globals.config.get('OUTPUT_FN_PREFIX')) is None  # Empty OUTPUT_FN_PREFIX is acceptable
                                        else validate_path(__OUTPUT_FN_PREFIX).encode().decode('unicode_escape'),
        'OUTPUT_FN_SEPARATOR':  lambda: '_'
                                        if (__OUTPUT_FN_SEPARATOR := pytl_globals.config.get('OUTPUT_FN_SEPARATOR')) is None  # Empty OUTPUT_FN_SEPARATOR is acceptable
                                        else validate_path(__OUTPUT_FN_SEPARATOR).encode().decode('unicode_escape'), # '.' => '' '\.' => '.'
        'OUTPUT_FN_SUFIX':      lambda: date_to_format(to_date(__params__['P_REPORT_DATE'], __params__['INPUT_DATE_FORMAT']), __params__['OUTPUT_DATE_FORMAT'])
                                        if (__OUTPUT_FN_SUFIX := pytl_globals.config.get('OUTPUT_FN_SUFIX')) is None  # Empty OUTPUT_FN_SUFIX is acceptable
                                        else validate_path(__OUTPUT_FN_SUFIX).encode().decode('unicode_escape'),
        'OUTPUT_FN_EXTENSION':  lambda: {
                                            'XLS': ".xlsx",
                                            'XML': ".html",
                                            'CSV': ".csv",
                                            'DB':  "$db$",
                                        }[__params__['OUTPUT_ENGINE']]
                                        if (
                                            __OUTPUT_FN_EXTENSION := pytl_globals.config.get(
                                                                        'OUTPUT_FN_EXTENSION',
                                                                        pytl_globals.config.get('EXTENSION')  # It means that empty OUTPUT_FN_EXTENSION is acceptable
                                                                     )
                                        ) is None   # Empty OUTPUT_FN_EXTENSION is acceptable
                                        else (
                                            '.' + __VALIDATED_OUTPUT_FN_EXTENSION
                                            if not (__VALIDATED_OUTPUT_FN_EXTENSION := validate_path(__OUTPUT_FN_EXTENSION)).startswith('.')
                                            else __VALIDATED_OUTPUT_FN_EXTENSION
                                        ),
        'OVERWRITE_OUTPUT':     lambda: validate_bool(pytl_globals.config.get('OVERWRITE_OUTPUT'), True),
        # __params__['DST_DIR'] / __params__['ROUTING_DIR'] / __params__['OUTPUT_FN_RELATED']
        'DST_DIR':              lambda: pytl_globals.config.get('TGT_FILEPATH') # TGT_FILEPATH could be as-is, but NOT empty
                                        or pytl_globals.config['DST_DIR'],
        'ROUTING_DIR':          lambda: validate_path(pytl_globals.config.get('ROUTING_DIR'), "{ORG}").encode().decode('unicode_escape'),
        'OUTPUT_FN_RELATED':    lambda: pytl_globals.config.get('OUTPUT_FN_RELATED') # OUTPUT_FN_RELATED could be as-is, but NOT empty
                                        or (
                                              __params__['OUTPUT_FN_PREFIX']
                                            + __params__['OUTPUT_FN_SEPARATOR']
                                            + __params__['OUTPUT_FN_SUFIX']
                                            + __params__['OUTPUT_FN_EXTENSION']
                                        ),
################################################################################
# Parameters for saving data: for all formats
        # Example in command line: "WRITE_HEADER=False"
        'WRITE_HEADER':         lambda: __inherited_params__['WRITE_HEADER']['PARSE_LOCAL'](
                                            pytl_globals.config.get('WRITE_HEADER')
                                        ),
        # Example in command line: "WRITE_EMPTY_ROWS=False"
        'WRITE_EMPTY_ROWS':     lambda: __inherited_params__['WRITE_EMPTY_ROWS']['PARSE_LOCAL'](
                                            pytl_globals.config.get('WRITE_EMPTY_ROWS')
                                        ),
        # Example in command line: "CREATE_EMPTY_REPORT=False"
        'CREATE_EMPTY_REPORT':  lambda: __inherited_params__['CREATE_EMPTY_REPORT']['PARSE_LOCAL'](
                                            pytl_globals.config.get('CREATE_EMPTY_REPORT')
                                        ),
        # Example in command line: "MINIMUM_ROWS=3"
        # If destionation report contains rows less that MINIMUM_ROWS, then it means that destionation report was not generated/is empty
        'MINIMUM_ROWS':         lambda: __inherited_params__['MINIMUM_ROWS']['PARSE_LOCAL'](
                                            pytl_globals.config.get('MINIMUM_ROWS')
                                        ),
        # Example in command line: "SAVE_REPORT_FILES=C:\\TMP\\File_where_paths_to_generated_reports_will_be_saved.txt"
        'SAVE_REPORT_FILES':    lambda: pytl_globals.config.get('SAVE_REPORT_FILES'),

        # NOT COMPARTIBLE with SimpleReport
        #   1) no nested lists
        #   2) COLUMNS_QUANTITY is global parameter, wich will be inheretended for each SQL if it's not redefined
        #   3) could be defined/redefined inside SOURCE_OF_DATA for each SQL separately
        # "COLUMNS_QUANTITY':     lambda: deserialize_fixed_list(
        #                                         pytl_globals.config.get('COLUMNS_QUANTITY'),
        #                                         fixed_list_len = 3,
        #                                         delimiter = ',',    # NOT COMPARTIBLE with SimpleReport: no nested lists
        #                                         default_item = 888,
        #                                         parse_item = lambda item, item_index, separated_items, previous_items:
        #                                             int(item)
        #                                             if isnumber(item)
        #                                             else (previous_items[-1] if len(previous_items) else 999)
        #                                         ,
        #                                         parse_empty = True,
        #                                 ),
        #   4) OPPOSITE to SimpleReport: empty element with ',' copies previous value
        #   5) OPPOSITE to SimpleReport: empty element WITHOUT ',' put default_item
        #   5) Not numbers will be ignored
        # Default values are 888,888,888
        # If the quantity of fetched columns is more that defined in COLUMNS_QUANTITY, then such columns will be truncated.
        # If the quantity of fetched columns is less that defined in COLUMNS_QUANTITY, then they will be provided as is.
        #       "COLUMNS_QUANTITY="         : [[777,777,777]]
        #       "COLUMNS_QUANTITY=,,"       : [[999,999,999]]
        #       "COLUMNS_QUANTITY=3,5,7"    : [[3,5,7]]
        #       "COLUMNS_QUANTITY=3,5,"     : [[3,5,5]]
        #       "COLUMNS_QUANTITY=3,5"      : [[3,5,888]]
        #       "COLUMNS_QUANTITY=3,"       : [[3,3,888]]
        #       "COLUMNS_QUANTITY=3"        : [[3,888,888]]
        #       "COLUMNS_QUANTITY=,5,"      : [[999,5,5]]
        #       "COLUMNS_QUANTITY=,5"       : [[999,5,888]]
        #       "COLUMNS_QUANTITY=,,7"      : [[999,999,7]]
        #       "COLUMNS_QUANTITY=NA,3,NA"  : [[999,3,3]]
        #       "COLUMNS_QUANTITY=NA,NA"    : [[999,999,888]]
        #       "COLUMNS_QUANTITY=;,,;3,5,7;3,5,;3,5;3,,;3;,5,;,5;,,7;NA,3,NA;" :   <list  12> [
        #                                                                               [999,888,888],
        #                                                                               [999,999,999],
        #                                                                               [3, 5, 7],
        #                                                                               [3,5,5],
        #                                                                               [3,5,888],
        #                                                                               [3,3,3],
        #                                                                               [3,888,888],
        #                                                                               [999,5,5],
        #                                                                               [999,5,888],
        #                                                                               [999,999,7],
        #                                                                               [999,3,3]
        #                                                                               [999,888,888],
        #                                                                           ]

        # Definition of global parameter COLUMNS_QUANTITY=A1,B1,C1;A2,B2,C2 is different from local parameter COLUMNS_QUANTITY=A,B,C
        'COLUMNS_QUANTITY':     lambda: deserialize_list(
                                            pytl_globals.config.get('COLUMNS_QUANTITY'),
                                            delimiter = ';',
                                            parse_item = lambda item,
                                                                item_index,
                                                                separated_items,
                                                                previous_items:
                                                         __inherited_params__['COLUMNS_QUANTITY']['PARSE_LOCAL'](item)
                                            ,
                                            parse_empty = True,
                                        ) or ((777,777,777),),
        'SKIP_COLUMNS':         lambda: __inherited_params__['SKIP_COLUMNS']['PARSE_LOCAL'](
                                            pytl_globals.config.get('SKIP_COLUMNS', pytl_globals.config.get('SKIPCOLUMNS'))
                                        ),
        'ONLY_COLUMNS':         lambda: __inherited_params__['ONLY_COLUMNS']['PARSE_LOCAL'](
                                            pytl_globals.config.get('ONLY_COLUMNS')
                                        ),
        'COLUMN_ALIASES':       lambda: __inherited_params__['COLUMN_ALIASES']['PARSE_LOCAL'](
                                            pytl_globals.config.get('COLUMN_ALIASES')
                                        ),
        'PADDING_CHAR':         lambda: __inherited_params__['PADDING_CHAR']['PARSE_LOCAL'](
                                            pytl_globals.config.get('PADDING_CHAR', '')
                                        ),
        'ADJUST_COLUMNS':       lambda: __inherited_params__['ADJUST_COLUMNS']['PARSE_LOCAL'](
                                            pytl_globals.config.get('ADJUST_COLUMNS')
                                        ),
        'TOO_LONG_VALUE':       lambda: __inherited_params__['TOO_LONG_VALUE']['PARSE_LOCAL'](
                                            (pytl_globals.config.get('TOO_LONG_VALUE') or "STOP").upper()
                                        ),
########################################
# Parameters for saving data: only for CSV (DSV,FWF)
        # Example in command line: "WRITE_EOF=True"
        'WRITE_EOF':            lambda: validate_bool(pytl_globals.config.get('WRITE_EOF'), False),
        # Example in command line: "EOL=\n"
        'EOL':                  lambda: __inherited_params__['EOL']['PARSE_LOCAL'](
                                            pytl_globals.config.get('EOL', "\r\n")
                                        ),
        # Example in command line: "PACK=LZMA"
        'PACK':                 lambda: {
                                          'BZIP2':      zipfile.ZIP_BZIP2,
                                          'LZMA':       zipfile.ZIP_LZMA,
                                          'DEFLATED':   zipfile.ZIP_DEFLATED,
                                          None:         None
                                        }[pytl_globals.config.get('PACK')],
        # Example in command line:
        #   Could NOT be used with PACK/MASK_ALL, the almost fast like SIMPLE.
        #   Could be used if there is no information about possible column values.
        #       "CSV_GENERATOR=NATIVE"
        #   Could be used with PACK/MASK_ALL, the slowest. Could be used if there is no information about possible column values.
        #       "CSV_GENERATOR=COMPLEX"
        #   Could be used with PACK/MASK_ALL, the fastest. Could be used ONLY if there are no delimiters inside column values.
        #       "CSV_GENERATOR=SIMPLE"
        'CSV_GENERATOR':        lambda: __inherited_params__['CSV_GENERATOR']['PARSE_LOCAL'](
                                                pytl_globals.config.get('CSV_GENERATOR', "COMPLEX")
                                        ),
        # DELIMITER could be empty string for FWF
        'DELIMITER':            lambda: __inherited_params__['DELIMITER']['PARSE_LOCAL'](
                                            pytl_globals.config.get('DELIMITER', "|")
                                        ),
########################################
        # Example in command line: "MASK_ALL=True"
        'MASK_ALL':             lambda: __inherited_params__['MASK_ALL']['PARSE_LOCAL'](
                                            pytl_globals.config.get('MASK_ALL')
                                        ),
        # Example in command line:
        # "MASK_PATTERN=([2-6,8-9][0-9]{5})([0-9]{4,9})([0-9]{4})=\1******\3,John=Jane"
        'MASK_PATTERN':         lambda: __inherited_params__['MASK_PATTERN']['PARSE_LOCAL'](
                                            pytl_globals.config.get('MASK_PATTERN')
                                        ),
        # Example in command line:
        #   Replace middle 6 numbers in all number sequences like PAN with 'xxxxxx' in the column CARD_NO.
        #   Replace number with similar character in the column ACCNT_NO
        #       "MASK_COLUMNS=CARD_NO=([34569][0-9]{5})([0-9]{6})([0-9]{4})=\1xxxxxx\3,ACCNT_NO=0=o|1=i|2=Z|3=E|4=<|5=S|6=b|7=>|8=B|9=g"
        'MASK_COLUMNS':         lambda: __inherited_params__['MASK_COLUMNS']['PARSE_LOCAL'](
                                            pytl_globals.config.get('MASK_COLUMNS')
                                        ),

################################################################################
        'AGGREGATE_COUNT':      lambda: __inherited_params__['AGGREGATE_COUNT']['PARSE_LOCAL'](
                                            pytl_globals.config.get('AGGREGATE_COUNT')
                                        ),
        'AGGREGATE_SUM':        lambda: __inherited_params__['AGGREGATE_SUM']['PARSE_LOCAL'](
                                            pytl_globals.config.get('AGGREGATE_SUM')
                                        ),
        'USE_AGGREGATE':        lambda: __inherited_params__['USE_AGGREGATE']['PARSE_LOCAL'](
                                            pytl_globals.config.get('USE_AGGREGATE', pytl_globals.config.get('AGGREGATE_USE'))
                                        ),
################################################################################
        'SQL_TYPE':             lambda: __inherited_params__['SQL_TYPE']['PARSE_LOCAL'](
                                            pytl_globals.config.get('SQL_TYPE', "AUTO")
                                        ),
################################################################################
# Optional parameters for XLS_SHEETS
        'STYLE_FILES':          lambda: set(deserialize_list(
                                            pytl_globals.config.get('STYLE_FILES')
                                            or pytl_globals.config.get('STYLEFILES')
                                            or pytl_globals.config.get('STYLEFILE')
                                            or pytl_globals.config.get('STYLE_FILE')
                                            ,delimiter = ','
                                        )),
        # In case of returned DB_TYPE_VARCHAR, and looks like number it will be converted to decimal with setting proper format (quantity of digits after comma)
        'AUTO_PRECISION':       lambda: validate_bool(
                                            pytl_globals.config.get('AUTO_PRECISION'),
                                            False
                                        ),
        # In case of returned DB_TYPE_NUMBER/DB_TYPE_BINARY_DOUBLE/DB_TYPE_BINARY_FLOAT, it will be converted to decimal without any format
        'AUTO_CONVERT':         lambda: validate_bool(
                                            pytl_globals.config.get('AUTO_CONVERT')
                                            or pytl_globals.config.get('AUTO_CONVERTED'),
                                            True
                                        ),
})

CONNECTION_SYNONYMS =(
    ('OWS', 'DB_W4C_TGT_WLTURL'),
    ('OWS', 'DB_W4C_SRC_WLTURL'),
    ('DWH', 'DB_DM_TGT_WLTURL'),
    ('DWH', 'DB_DM_SRC_WLTURL'),
    ('STG', 'DB_STG_TGT_WLTURL'),
    ('STG', 'DB_STG_SRC_WLTURL'),
)

__inherited_params__ = {
    'UNIQUE_CALL_ID':       {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   v,
    },
    'SOURCE_DB':            {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   validate_values(
                                                                v,
                                                                tuple(pytl_globals.config.keys() | dict(CONNECTION_SYNONYMS).keys()) + ('OWS',),
                                                                raise_if_not_found= NotImplementedError(
                                                                                        f"Unexpected value '{v}' in parameter 'SOURCE_DB'. "
                                                                                        "Expected: OWS, DWH, STG or other defined parameters with connectivity string"
                                                                                    )
                                                            ),
                                'SYNONYMS':     {"DB_SOURCE", "DBSOURCE"},
    },
    'TARGET_DB':            {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   validate_values(
                                                    v,
                                                    tuple(pytl_globals.config.keys() | dict(CONNECTION_SYNONYMS).keys()) + (None,),
                                                    raise_if_not_found = NotImplementedError(
                                                                            f"Unexpected value '{pytl_globals.config.get('TARGET_DB')}' in parameter 'TARGET_DB'. "
                                                                            "Expected: OWS, DWH, STG or other defined parameters with connectivity string"
                                                                        )
                                                ),
    },
    'TARGET_TABLE':         {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   v,
    },
    'TARGET_COLUMNS':       {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   deserialize_dict(
                                                                v,
                                                                delimiter = ',',    # Not compatible with W4 TAGS
                                                                default_value = lambda key_value, parsed_key: parsed_key,
                                                                # It will allow to provide list instead of serialized dict
                                                                # in case of source and target colum names are the same
                                                            )
                                                            or {
                                                                "UNIQUE_CALL_ID":   "UNIQUE_CALL_ID",
                                                                "QUERY_NAME":       "QUERY_NAME",
                                                                "QUERY_PARAMS":     "QUERY_PARAMS",
                                                                "ROW_ID":           "ROW_ID",
                                                                "SERIALIZED":       "SERIALIZED",
                                                            },
    },
    'WRITE_HEADER':         {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   validate_bool(v, True),
    },
    'WRITE_EMPTY_ROWS':     {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   validate_bool(v, True),
    },
    'CREATE_EMPTY_REPORT':  {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   validate_bool(v, True),
    },
    'MINIMUM_ROWS':         {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   int(v or 1),
    },
    'COLUMNS_QUANTITY':     {
                                'GET_GLOBAL':   lambda v,i: v[i] if i < len(v) else v[-1],
                                'PARSE_LOCAL':  lambda v:   deserialize_fixed_list(
                                                                ','.join(v) if isinstance(v, (list, tuple)) else v,
                                                                fixed_list_len = 3,
                                                                delimiter = ',',
                                                                default_item = 888,
                                                                parse_item = lambda item, item_index, separated_items, previous_items:
                                                                    int(item) if isnumber(item) else (previous_items[-1] if len(previous_items) else 666)
                                                                ,
                                                                parse_empty = True,
                                                            ) or (999,999,999)
    },
    'SKIP_COLUMNS':         {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   set(
                                                                deserialize_list(
                                                                    v,
                                                                    delimiter = ',',    # Not compartible with SimpleReport where it is ';'
                                                                )
                                                            ) | {"ORG"}, # ORG is technical mandatory field and will be excluded in any cases
    },
    'ONLY_COLUMNS':         {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   deserialize_list(
                                                                v,
                                                                delimiter = ',',    # Not compartible with SimpleReport where it is ';'
                                                            ),
    },
    'COLUMN_ALIASES':       {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   deserialize_dict(
                                                                v,
                                                                delimiter = ',',    # Not compatible with W4 TAGS
                                                            ),
    },
    'PADDING_CHAR':         {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   v.encode().decode('unicode_escape') or ' ',
    },
    'ADJUST_COLUMNS':       {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   deserialize_dict(
                                                                ','.join(v) if isinstance(v, (list, tuple)) else v,
                                                                delimiter = ',',
                                                                parse_value = lambda key_value, default_value:
                                                                                    (
                                                                                        (__adjust_params:=split_pair(
                                                                                            __value,
                                                                                            '>',
                                                                                            default_left = __params__['PADDING_CHAR'],
                                                                                            transform_left = lambda x: x if x else __params__['PADDING_CHAR'],
                                                                                            transform_right = lambda x: int(x.replace('~', '')),
                                                                                        ))[0],
                                                                                        '>',  # Adjust to the right
                                                                                        __adjust_params[1],
                                                                                        True if __value.startswith('~') else False
                                                                                    )
                                                                                    if '>' in (__value:=key_value[1]) else
                                                                                    (
                                                                                        (
                                                                                            (__adjust_params:=split_pair(
                                                                                                __value,
                                                                                                '^',
                                                                                                default_left = __params__['PADDING_CHAR'],
                                                                                                transform_left = lambda x: x if x else __params__['PADDING_CHAR'],
                                                                                                # In some cases '^^' could be provided instead of ^
                                                                                                transform_right = lambda x: int(x.replace('^', '').replace('~', '')),
                                                                                            ))[0],
                                                                                            '^',  # Adjust to the center
                                                                                            __adjust_params[1],
                                                                                            True if __value.startswith('~') else False
                                                                                        )
                                                                                        if '^' in (__value:=key_value[1]) else
                                                                                        (
                                                                                            (__adjust_params:=split_pair(
                                                                                                __value,
                                                                                                '<',
                                                                                                default_left = __params__['PADDING_CHAR'],
                                                                                                transform_left = lambda x: x if x else __params__['PADDING_CHAR'],
                                                                                                transform_right = lambda x: int(x.replace('~', '')),
                                                                                            ))[0],
                                                                                            '<',  # Adjust to the left by default
                                                                                            __adjust_params[1],
                                                                                            True if __value.startswith('~') else False
                                                                                        )
                                                                                    )
                                                            ),
    },
    'TOO_LONG_VALUE':       {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   validate_values(
                                                    v,
                                                    ("CUT", "ASIS", "STOP"),  # "STOP" is default value
                                                    raise_if_not_found = NotImplementedError(
                                                                            "Unexpected value in parameter 'TOO_LONG_VALUE'. "
                                                                            "Expected: CUT, ASIS, STOP"
                                                                         )
                                                ),
    },
    # Example in command line: "EOL=\n"
    'EOL':                  {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   v.encode().decode('unicode_escape'),
    },
    'CSV_GENERATOR':        {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   validate_values(
                                                    v,
                                                    ("FWF", "NATIVE", "SIMPLE", "COMPLEX"),
                                                    raise_if_not_found = ValueError(
                                                                        "Unexpected value in parameter 'CSV_GENERATOR'. "
                                                                        "Expected: FWF, NATIVE, SIMPLE, COMPLEX"
                                                                   )
                                                ),
    },
    'DELIMITER':            {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   v.encode().decode('unicode_escape'), # DELIMITER could be empty string for FWF
    },
    'MASK_ALL':             {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   validate_bool(v, False),
    },
    # Example in command line:
    # "MASK_PATTERN=([2-6,8-9][0-9]{5})([0-9]{4,9})([0-9]{4})=\1******\3,John=Jane"
    'MASK_PATTERN':         {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   deserialize_dict(
                                                                ','.join(v) if isinstance(v, (list, tuple)) else v,
                                                                delimiter = ',',
                                                                parse_key = lambda key_value, default_key: re.compile(key_value[0]),
                                                            ) or { re.compile("([2-6,8-9][0-9]{5})([0-9]{4,9})([0-9]{4})"): r"\1******\3" }
    },
    # Example in command line:
    #   Replace middle 6 numbers in all number sequences like PAN with 'xxxxxx' in the column CARD_NO.
    #   Replace number with similar character in the column ACCNT_NO
    #       "MASK_COLUMNS=CARD_NO=([34569][0-9]{5})([0-9]{6})([0-9]{4})=\1xxxxxx\3,ACCNT_NO=0=o|1=i|2=Z|3=E|4=<|5=S|6=b|7=>|8=B|9=g"
    'MASK_COLUMNS':         {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   deserialize_dict(
                                                                ','.join(v) if isinstance(v, (list, tuple)) else v,
                                                                delimiter = ',',
                                                                parse_value = lambda key_value, default_value:
                                                                                deserialize_dict(
                                                                                    key_value[1],
                                                                                    delimiter = '|',
                                                                                    parse_key = lambda key_value, default_key: re.compile(key_value[0]),
                                                                                )
                                                                ,
                                                                default_value = __params__['MASK_PATTERN'],
                                                            ),
    },
################################################################################
    'SQL_QUERY_ID':         {
###                                'GET_GLOBAL':   lambda v,i: v,  ## NOT POSSIBLE TO DEFINE AS GLOBAL PARAMETER
                                'PARSE_LOCAL':  lambda v:   v,
    },
    'AGGREGATE_COUNT':      {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   set(deserialize_list(
                                                                v,
                                                                delimiter = ',',
                                                            ))
    },
    'AGGREGATE_SUM':      {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   set(deserialize_list(
                                                                v,
                                                                delimiter = ',',
                                                            ))
    },
# "USE_AGGREGATE={Column name where aggregate variable(s) will be used}={The name of used variable}[={format}][|{The name of used variable}[={format}]],.."
#   {Column name where aggregate variable(s) will be used} == any from SQL result dataset
#   {The name of used variable}:
#       SAVED_ROWS_COUNT == rows from ALL previous SQLs saved into the CURRENT file (could be different from fetched rows in case of WRITE_EMPTY_ROWS=False)
#       SAVED_ROWS_COUNT[{index}] == rows from previous SQL {index} saved into the CURRENT file (could be different from fetched rows in case of WRITE_EMPTY_ROWS=False)
#       AGGREGATE_COUNT.{Column name} == count of not empty field values from column {Column name} from ALL previous SQLs saved into the CURRENT file
#       AGGREGATE_SUM.{Column name} == sum of numeric values in the column {Column name} from ALL previous SQLs saved into the CURRENT file
#       AGGREGATE_COUNT[{index}].{Column name} == count of not empty field values from column {Column name} from previous SQL {index} saved into the CURRENT file
#       AGGREGATE_SUM[{index}].{Column name} == sum of numeric values in the column {Column name} from previous SQL {index} saved into the CURRENT file
#
#       SAVED_ROWS_COUNT and SAVED_ROWS_COUNT[{index}] are calculated always
#       AGGREGATE_COUNT_{Column name} and AGGREGATE_COUNT[{index}]{Column name} are calculated only if "AGGREGATE_COUNT={Column name},..." is defined
#       AGGREGATE_SUM_{Column name} and AGGREGATE_SUM[{index}]{Column name} are calculated only if "AGGREGATE_SUM={Column name},..." is defined
#
# Parameters:
#       "SQL_QUERIES+=AGGREGATE_COUNT=COL1,COL2:AGGREGATE_SUM=COL2:BODY.sql;"
#       "SQL_QUERIES+=USE_AGGREGATE=COL1=SAVED_ROWS_COUNT|AGGREGATE_COUNT.COL1|AGGREGATE_SUM.COL2=04f,COL2=AGGREGATE_SUM[0].COL2|AGGREGATE_SUM[1].COL2=03f;FOOTER.sql"
# SQL Query:
#       select 'Total rows from all SQL: %SAVED_ROWS_COUNT%' as COL1, 'Sum from 1st query: %AGGREGATE_SUM[0]_COL2%' as COL2 from dual
# Result:
#               Total rows from all SQL: 5,Sum from 1st query: 222.22
# SQL Query:
#       select 'Not empty COL1: %AGGREGATE_COUNT_COL1% - Total sum of COL2: %AGGREGATE_SUM_COL2%' as COL1, 
#              'Sum from 2nd query: %AGGREGATE_SUM[1]_COL2%' as COL2 from dual
# Result:
#               Not empty COL1: 3 - Total sum of COL2: 555.5550,Sum from 2nd query: 333.333
    'USE_AGGREGATE':        {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   deserialize_dict(
                                                                ','.join(v) if isinstance(v, (list, tuple)) else v,
                                                                delimiter = ',',
                                                                parse_value = lambda key_value, default_value:
                                                                                deserialize_dict(
                                                                                    key_value[1],
                                                                                    delimiter = '|',
                                                                                    # parse_key = lambda key_value, default_key: re.compile(key_value[0]),
                                                                                    default_value = '',
                                                                                )
                                                                ,
                                                                default_value = __params__['MASK_PATTERN'], # ???
                                                            ),
                                'SYNONYMS':     {"AGGREGATE_USE"},
    },
################################################################################
    'SQL_TYPE':             {
                                'GET_GLOBAL':   lambda v,i: v,
                                'PARSE_LOCAL':  lambda v:   validate_values(
                                                    v or "AUTO",
                                                    ("QUERY", "ANONYMOUS_BLOCK", "AUTO"),  # "AUTO" is default value
                                                    raise_if_not_found = ValueError(
                                                                        "Unexpected value in parameter 'SQL_TYPE'. "
                                                                        "Expected: QUERY, ANONYMOUS_BLOCK, AUTO"
                                                                   )
                                                ),
    },
    'SAVE_INTO':            {
###                                'GET_GLOBAL':   lambda v,i: v,  ## NOT POSSIBLE TO DEFINE AS GLOBAL PARAMETER
                                'PARSE_LOCAL':  lambda v:   v,
    },
    'SAVE_INTO_TYPE':       {
###                                'GET_GLOBAL':   lambda v,i: v,  ## NOT POSSIBLE TO DEFINE AS GLOBAL PARAMETER
                                'PARSE_LOCAL':  lambda v:   validate_values(
                                                    v or "AUTO",
                                                    ("STR", "DICT", "LIST", "AUTO"),  # "AUTO" is default value
                                                    raise_if_not_found = ValueError(
                                                                        "Unexpected value in parameter 'SQL_TYPE'. "
                                                                        "Expected: STR, DICT, LIST, AUTO"
                                                                   )
                                                ),
    },
}

def inherite_global_params_and_split_queries(deserialized_list: list) -> list:
    # Inherit values from global __params__ for params, which was not defined localy, but mentioned in __inherited_params__
    need_to_split = []
    for i,sql_query in enumerate(deserialized_list):
        for param_name in __inherited_params__:
            if param_name in sql_query:
                validated_value = __inherited_params__[param_name]['PARSE_LOCAL'](sql_query[param_name])
            elif (param_name_synonyms:=__inherited_params__[param_name].get('SYNONYMS')) \
             and (param_name_synonym:=next((param_name_synonym for param_name_synonym in param_name_synonyms if param_name_synonym in sql_query), None)):
                validated_value = __inherited_params__[param_name]['PARSE_LOCAL'](sql_query[param_name_synonym])
            elif 'GET_GLOBAL' in __inherited_params__[param_name]:
                validated_value = __inherited_params__[param_name]['GET_GLOBAL'](__params__[param_name], i)
            else:
                validated_value = None
            sql_query[param_name] = validated_value
        if isinstance(sql_query['SQL_QUERY_NAME'], list):
            need_to_split.append((i, sql_query))

    # Split queries inside one record into separate records
    correction_after_previous_inserts = 0
    for src_index,sql_query in need_to_split:
        sql_query_names = sql_query['SQL_QUERY_NAME']
        sql_query['SQL_QUERY_NAME'] = sql_query_names[0]
        j = None
        for j,sql_query_name in enumerate(sql_query_names[1:]):
            new_sql_query = copy.deepcopy(sql_query)
            ### new_sql_query['SQL_QUERY_NAME'] = sql_query_name
            new_sql_query['SQL_QUERY_NAME'] = sql_query_name.encode().decode('unicode_escape')
            dst_index = src_index + 1 + correction_after_previous_inserts + j
            deserialized_list.insert(dst_index, new_sql_query)
        if j is not None:
            correction_after_previous_inserts += j+1
    return deserialized_list

def parse_SQL_QUERY(item: str, item_index: int, separated_items: list, previous_items: str) -> tuple:
    return deserialize_key_value(
        item,
        default_key = 'SQL_QUERY_NAME' if item_index == len(separated_items) -1 else 'SOURCE_DB',
        parse_value = lambda key_value, default_value:
            key_value[1]
            if ',' not in key_value[1] else
            deserialize_list(
                key_value[1], delimiter = ',',
            )
    )

def parse_SQL_QUERIES(in_str: str) -> dict:
    # n0debug("in_str")
    if not in_str:
        return {}
    deserialized_list = deserialize_list(
        in_str, delimiter = ';',
        parse_item = lambda item, item_index, separated_items, previous_items:
                            dict(deserialize_list(
                                item, delimiter = ':',
                                parse_item = parse_SQL_QUERY
                            ))
    )
    # recursive call: SQL_QUERIES -> OUTPUT_FN_RELATED -> OUTPUT_FN_PREFIX -> FIRST_QUERY -> SQL_QUERIES
    # deserialized_dict = {__params__['OUTPUT_FN_RELATED']: inherite_global_params_and_split_queries(deserialized_list)}
    deserialized_list = inherite_global_params_and_split_queries(deserialized_list)
    deserialized_dict = {deserialized_list[0]['SQL_QUERY_NAME'].upper(): deserialized_list}
    n0debug("deserialized_dict")
    return deserialized_dict
    # return {'SQL_QUERIES': inherite_global_params_and_split_queries(deserialized_list)}

def parse_XLS_SHEETS(in_str: str) -> dict:
    # n0debug("in_str")
    if not in_str:
        return {}
    deserialized_list = deserialize_list(
        in_str, delimiter = ';',
        parse_item = lambda item, item_index, separated_items, previous_items:
                        deserialize_key_value(
                            item,
                            parse_value = lambda key_value, default_value:
                                dict(deserialize_list(
                                    key_value[1], delimiter = ':',
                                    parse_item = parse_SQL_QUERY,
                                ))
                        ),
    )
    deserialized_dict = {}
    for key,value in deserialized_list:
       if key not in deserialized_dict:
           deserialized_dict[key] = []
       deserialized_dict[key].append(value)
    for key,value in deserialized_dict.items():
       deserialized_dict[key] = inherite_global_params_and_split_queries(value)
    n0debug("deserialized_dict")
    return deserialized_dict

def parse_DATA_SOURCES(in_str: str) -> dict:
    # n0debug("in_str")
    deserialized_dict = parse_XLS_SHEETS(in_str)
    for key,value in deserialized_dict.items():
        if not isinstance(value, list):
            raise ReferenceError(f"Unexpected type of sub item: {type(value)} {value}")
        if len(value) != 1:
            sql_query_names = [sql_query['SQL_QUERY_NAME'] for sql_query in value]
            raise SyntaxError(f"Impossible to define under single DATA_SOURCE '{key}' several queries '{sql_query_names}'")
    n0debug("deserialized_dict")
    return deserialized_dict
