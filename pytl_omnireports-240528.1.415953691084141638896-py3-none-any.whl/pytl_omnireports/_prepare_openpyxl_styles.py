import os
import cx_Oracle
import yaml
import openpyxl
from n0struct import (
    to_date,
    validate_bool,
    n0print,
)
########################################################################################################################
########################################################################################################################
n0print(f"{'='*14} START: Importing in {__file__}")
try:
    # Could be imported ONLY if it's run as NORMAL py
    n0print(f"=-= NORMAL {'=-='*1} from _params import __params__")
    from _params import __params__
except Exception as ex:
    n0print(f"{'#'*14} not NORMAL")
    try:
        # Could be imported ONLY if it's run as MODULE
        n0print(f"=-= MODULE {'=-='*1} from ._params import __params__")
        from ._params import __params__
    except Exception as ex:
        n0print(f"{'#'*14} FATAL ERROR: Importing in {__file__} as MODULE: {ex}")
        
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exc_type, exc_value, exc_traceback = sys.exc_info() # most recent (if any) by default
        traceback_details = {
                             'filename': exc_traceback.tb_frame.f_code.co_filename,
                             'lineno'  : exc_traceback.tb_lineno,
                             'name'    : exc_traceback.tb_frame.f_code.co_name,
                             'type'    : exc_type.__name__,
                             'message' : exc_value.message, # or see traceback._some_str()
                            }
        n0print(traceback.format_exc())
        n0print(traceback_details)
        
        exit(-999)

n0print(f"{'-'*14} END: Importing in {__file__}")
########################################################################################################################
########################################################################################################################


##################################################################################################
# All of our data comes from the cursor as a strings.
# Below is the mapping of the default converting from a string to another type,
# according to what values are stored in the database.
# We use Decimal to prevent bugs with inaccurate decimal places that can occur when using float.
##################################################################################################

local_spreadsheet_setting_mapping = {
    'STYLE_FILE': lambda item: stripped_item if (stripped_item:=item.strip()).lower().endswith(".yaml") else __stripped_x + ".yaml",
    'STYLE_ALIAS': lambda item: item.strip(),
    'SOURCE_DB': lambda item: item.strip(),
    'WRITE_HEADER': validate_bool,
    'SKIP_COLUMNS': lambda item: deserialize_list(item, separator_tag = ','),
}


########################################################################################################################
def prepare_openpyxl_styles(raw_params: dict):
    STYLES_WRAP_MAPPING = {
        "font": openpyxl.styles.Font,
        "alignment": openpyxl.styles.Alignment,
        "border": openpyxl.styles.Border
    }
    prepared_params = {}

    for sheet_name, params_ in raw_params.items():
        prepared_params[sheet_name] = {
            "styles": {},
            "data_options": {},
            "column_dimensions": {}
        }
        for column_name, styles_params in params_.items():
            prepared_params[sheet_name][column_name] = {}
            for param_name, values in styles_params.items():
                param_name = param_name.lower()
                if param_name in STYLES_WRAP_MAPPING:
                    prepared_params[sheet_name]["styles"][column_name] = {
                        param_name: STYLES_WRAP_MAPPING[param_name](**values)
                    }
                    continue
                if param_name in ("column_dimensions", "data_options"):
                    prepared_params[sheet_name][param_name][column_name] = values

    return prepared_params


########################################################################################################################
def prepare_report_settings(report_settings_files:dict) -> dict:
    """
    Open *.yaml file related to PyTL_IS_XlsReports job and generate settings dict
    """
    spreadsheet_settings = {}  # by default we have empty spreadsheet settings

    if __params__['STYLE_FILES']:
        for style_file in __params__['STYLE_FILES']:
            if not os.path.exists(settings_template_file := style_file):
                settings_template_key = os.path.splitext(os.path.basename(settings_template_file.lower()))[0]
                if not settings_template_key in settings_template_key:
                    raise Exception(f"STYLE_FILE '{settings_template_file}' is not found")
                settings_template_file = report_settings_files[settings_template_key]
            with open(settings_template_file) as in_filehandler:
                spreadsheet_settings = yaml.load(in_filehandler, Loader=yaml.FullLoader)
    return spreadsheet_settings

