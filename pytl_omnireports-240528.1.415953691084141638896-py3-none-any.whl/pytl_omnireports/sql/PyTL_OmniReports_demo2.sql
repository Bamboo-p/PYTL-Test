select :ORG as ORG, 'row1: PyTL_OmniReports demo = column1' as COL1, NULL as COL2, 'row1: PyTL_OmniReports demo = column3' as COL3, NULL as COL4, 'row1: PyTL_OmniReports demo = column5' as COL5 from dual
union
select :ORG as ORG, 'row2: PyTL_OmniReports demo = column1' as COL1, NULL as COL2, 'row2: PyTL_OmniReports demo = column3' as COL3, NULL as COL4, 'row2: PyTL_OmniReports demo = column5' as COL5 from dual
