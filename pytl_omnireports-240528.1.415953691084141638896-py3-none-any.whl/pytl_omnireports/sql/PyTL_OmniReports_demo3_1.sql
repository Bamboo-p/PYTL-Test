select :ORG as ORG, stg_etl.PyTL_PETRA_UNIQUE_FIGURE__SEQ.nextval as SEQ from dual
