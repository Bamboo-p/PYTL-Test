with t1 as (
    select '771' as ORG, 'ROW1_COL1' as COL1, 'ROW1_COL2' as COL2 from dual
    union all
    select :ORG  as ORG, 'ROW2_COL1' as COL1, 'ROW2_COL2' as COL2 from dual
    union all
    select '773' as ORG, 'ROW3_COL1' as COL1, 'ROW3_COL2' as COL2 from dual
    union all
    select :ORG  as ORG, 'ROW4_COL1' as COL1, 'ROW4_COL2' as COL2 from dual
)
select t1.ORG, stg_etl.PyTL_PETRA_UNIQUE_FIGURE__SEQ.currval as SEQ, t1.COL1, t1.COL2 from t1
