select :ORG as ORG, '----------' as COL1, '----------' as COL2, '----------' as COL3, '----------' as COL4, '----------' as COL5 from dual
