select :ORG as ORG, 'body_row1: PyTL_OmniReports demo = column1' as COL1, 0.111 as COL2, 'body_row1: PyTL_OmniReports demo = column3' as COL3, 3 as COL4, 'body_row1: PyTL_OmniReports demo = column5' as COL5 from dual
union
select :ORG as ORG, 'body_row2: PyTL_OmniReports demo = column1' as COL1, 0.222 as COL2, 'body_row2: PyTL_OmniReports demo = column3' as COL3, NULL as COL4, 'body_row2: PyTL_OmniReports demo = column5' as COL5 from dual
union
select :ORG as ORG, 'body_row3: PyTL_OmniReports demo = column1' as COL1, 0.333 as COL2, 'body_row3: PyTL_OmniReports demo = column3' as COL3, 7 as COL4, 'body_row3: PyTL_OmniReports demo = column5' as COL5 from dual
union
select :ORG as ORG, 'body_row4: PyTL_OmniReports demo = column1' as COL1, NULL as COL2, 'body_row4: PyTL_OmniReports demo = column3' as COL3, 9 as COL4, 'body_row4: PyTL_OmniReports demo = column5' as COL5 from dual
union
select :ORG as ORG, 'body_row5: PyTL_OmniReports demo = column1' as COL1, 0.555 as COL2, 'body_row5: PyTL_OmniReports demo = column3' as COL3, NULL as COL4, 'body_row5: PyTL_OmniReports demo = column5' as COL5 from dual
