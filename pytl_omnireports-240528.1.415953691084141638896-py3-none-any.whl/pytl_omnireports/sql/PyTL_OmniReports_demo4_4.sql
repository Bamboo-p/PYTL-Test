select
    :ORG as ORG
    ,'footer_row1: '
    || 'SAVED_ROWS_COUNT == "%SAVED_ROWS_COUNT%" '
    || 'SAVED_ROWS_COUNT[0] == "%SAVED_ROWS_COUNT[0]%" '
    || 'SAVED_ROWS_COUNT[MAIN_BODY] == "%SAVED_ROWS_COUNT[MAIN_BODY]%" '
    || 'SAVED_ROWS_COUNT[2] == "%SAVED_ROWS_COUNT[2]%" '
    || 'SAVED_ROWS_COUNT[-2] == "%SAVED_ROWS_COUNT[-2]%" '
    || 'AGGREGATE_COUNT.ORG == "%AGGREGATE_COUNT.ORG%" '
    || 'AGGREGATE_COUNT[0].ORG == "%AGGREGATE_COUNT[0].ORG%" '
    || 'AGGREGATE_COUNT.COL2 == "%AGGREGATE_COUNT.COL2%"' 
    as COL1
    ,'' as COL2
    ,'' as COL3
    ,'' as COL4
    ,'' as COL5
from dual
union
select
    :ORG as ORG
    ,'' as COL1
    ,'footer_row2:'
    || 'AGGREGATE_SUM.COL2 == "%AGGREGATE_SUM.COL2%" '
    || 'AGGREGATE_SUM[0].COL2 == "%AGGREGATE_SUM[0].COL2%" '
    || 'AGGREGATE_SUM[MAIN_BODY].COL2 == "%AGGREGATE_SUM[MAIN_BODY].COL2%"'
    as COL2
    ,'' as COL3
    ,'' as COL4
    ,'' as COL5
from dual
