select :ORG as ORG, 'body_row1: PyTL_OmniReports demo5_1 = column1' as COL1, SYSDATE as COL2,      'body_row1: PyTL_OmniReports demo5_1 = column3' as COL3, NULL as COL4, 'body_row1: PyTL_OmniReports demo5_1 = column5' as COL5 from dual
union
select :ORG as ORG, 'body_row2: PyTL_OmniReports demo5_1 = column1' as COL1, SYSTIMESTAMP as COL2, 'body_row2: PyTL_OmniReports demo5_1 = column3' as COL3, NULL as COL4, 'body_row2: PyTL_OmniReports demo5_1 = column5' as COL5 from dual
union
select :ORG as ORG, 'body_row3: PyTL_OmniReports demo5_1 = column1' as COL1, NULL as COL2,         'body_row3: PyTL_OmniReports demo5_1 = column3' as COL3, to_date('2024-03-04', 'YYYY-MM-DD') as COL4, 'body_row3: PyTL_OmniReports demo5_1 = column5' as COL5 from dual
