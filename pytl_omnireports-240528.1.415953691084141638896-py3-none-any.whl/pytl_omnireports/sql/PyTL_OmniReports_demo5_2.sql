alter session set NLS_DATE_FORMAT = '{{config.get('NLS_DATE_FORMAT', 'YYYY-MM-DD')}}'
