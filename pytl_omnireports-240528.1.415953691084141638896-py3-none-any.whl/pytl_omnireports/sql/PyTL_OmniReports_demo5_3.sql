declare
    V_TMP VARCHAR2(4000);
begin
    select '' into V_TMP from dual;
end;
