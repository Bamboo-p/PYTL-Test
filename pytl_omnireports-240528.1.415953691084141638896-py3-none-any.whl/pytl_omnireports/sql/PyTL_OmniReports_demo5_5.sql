select 'body_row1: PyTL_OmniReports demo5_5 = column1' as COL1 from dual
