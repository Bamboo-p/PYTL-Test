with sub_query1 as (
{{
"\n union all \n".join(
    "select '" + row['COL1'] + "' as COL6 from dual"
    for row in config['VAR_1_LIST']
)
}}
)
select
    :ORG as ORG
    ,'PyTL_OmniReports demo6 = column1'     as COL1
    ,'{{config['FILE_SEQUENCE_NUMBER']}}'   as COL2
    ,'PyTL_OmniReports demo6 = column3'     as COL3
    ,'{{config['VAR_2_DICT']['COL3']}}'     as COL4
    ,'PyTL_OmniReports demo6 = column5'     as COL5
    ,sq1.COL6                               as COL6
from
    dual
cross join sub_query1 sq1
