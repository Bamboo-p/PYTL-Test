/*
:ORGLIST == 982
*/
select * from (
	with inst as (
        select  /*+ no_merge materialize */
            inst.ID
            ,inst.BRANCH_CODE
            ,inst.NAME
            ,inst.BRANCH_CODE_POSTING
        from (
            select
                i.BRANCH_CODE
                ,i.POSTING_INSTITUTION_ID
                ,i.ID
                ,i.NAME
                ,i2.BRANCH_CODE                                                         as BRANCH_CODE_POSTING
            from dwh.dwd_institution i
            join dwh.dwd_institution i2 on i.POSTING_INSTITUTION_ID = i2.ID
            where i.RECORD_STATE = 'A'
        ) inst
        start with inst.BRANCH_CODE in (
            select
                trim(regexp_substr(:ORGLIST, '[^,]+', 1, level))                  as ORG 
            from
                DUAL
            connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
        )
        connect by decode(
                        inst.posting_institution_id, 
                        inst.id, null, 
                        inst.posting_institution_id
                   ) = prior inst.id
                   and level <= 2
    )
    select
        i.BRANCH_CODE                                                                   as ORG
        /*
        ,p.CLASS_CODE
        ,p.CLASS_NAME
        ,p.TYPE_CODE
        ,p.TYPE_NAME
        */
        ,p.NAME
        ,p.CODE
        ,p.PRODUCT_ID
        ,p.PRODUCT_NAME
        ,p.PRODUCT_CODE
    from dwh.v_dwr_product p
    join inst i on i.BRANCH_CODE = substr(p.CODE,5,3)
    where
        p.CLASS_CODE  = 'BASE_REPORTS'
        and p.TYPE_CODE   = 'LOGO'
)
where NAME like 'Visa%'
order by PRODUCT_CODE
