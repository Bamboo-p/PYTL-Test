select t.* from PyTL_Saved_Test_Data t
join (select max(QUERY_TIMESTAMP) QUERY_TIMESTAMP from PyTL_Saved_Test_Data) max_value on max_value.QUERY_TIMESTAMP = t.QUERY_TIMESTAMP
order by t.ROW_ID
