select * from PyTL_Serialized_Data t
join (select max(QUERY_TIMESTAMP) QUERY_TIMESTAMP from PyTL_Serialized_Data) max_value on max_value.QUERY_TIMESTAMP = t.QUERY_TIMESTAMP
order by t.ROW_ID
