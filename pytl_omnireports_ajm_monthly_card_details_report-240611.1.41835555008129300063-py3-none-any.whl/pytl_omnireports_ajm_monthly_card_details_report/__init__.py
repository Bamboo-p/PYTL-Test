__version__ = "240611.1"
__job_name__ = "PyTL_OmniReports_AJM_MONTHLY_CARD_DETAILS_REPORT"
__bat_files__ = []
