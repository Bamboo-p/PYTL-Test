/*
* CODE FOR AJM MONTHLY CARD DETAILS REPORT GENERATION
* AJM_MONTHLY_CARD_DETAILS_REPORT
* Parameters:
*           :ORG LIST              = '100'
*           :P_REPORT_DATE        = 'DD-MM-YYYY'
*
* Version history:
* 240507.1 = Kokila J = AJM-5227: Initial Development
* 240611.1 = Kokila J = AJM-5227: channel_id changes
*/WITH inst AS (
    SELECT /*+ no_merge materialize*/
        ins.code   AS bank_code,
        ins.institution_id
    FROM
        v_dwr_institution ins
    WHERE
        class_code = 'BASE_REPORTS'
        AND type_code = 'BANK_DESC'
        AND code = :ORG
), products AS (
    SELECT /*+ no_merge materialize */
        v.product_id,
        v.code,
        v.product_code,
        v.name
    FROM
        v_dwr_product v
        JOIN inst i ON substr(v.code, 5, 3) = i.bank_code
    WHERE
        v.class_code = 'BASE_REPORTS'
        AND v.type_code = 'LOGO'
), crlimit AS (
    SELECT /*+ use_hash(l inst) */
        contract_idt,
        SUM(CASE
            WHEN type_code = 'FIN_LIMIT' THEN amount
            ELSE 0
        END) AS credit_limit,
        SUM(CASE
            WHEN type_code = 'AVAILABLE' THEN amount
            ELSE 0
        END) AS amount_available
    FROM
        dwf_contract_limit l
        JOIN inst ON inst.institution_id = l.institution_id
    WHERE
        banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND type_code IN (
            'FIN_LIMIT',
            'AVAILABLE'
        )
    GROUP BY
        contract_idt
), cards AS (
    SELECT /*+ no_merge materialize */
        c.record_idt       AS card_id,
        c.pan              AS card_number,
        c.main_contract_idt,
        nvl(embossed_last_name, ' ') AS embossed_names,
        crl.credit_limit   AS card_credit_limit,
        c.opening_date     AS card_open_date,
        sy_convert.get_tag_value(c.add_info, 'SVC_DET_1') AS channel_id,
        client_idt
    FROM
        dwd_card c
        JOIN inst i ON i.institution_id = c.institution_id
        JOIN crlimit crl ON crl.contract_idt = c.record_idt
    WHERE
        c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND c.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
), cl_addr AS (
    SELECT /*+ ordered no_merge use_hash(DWD_ADDRESS DWD_ADDRESS_TYPE) use_hash(DWD_ADDRESS inst) full(DWD_ADDRESS) */
        dcl.record_idt     AS client_idt,
        dcl.client_number,
        dcl.gender,
        dcn.name           AS nationality,
        dcl.language,
        phone_mobile,
        e_mail,
        sy_convert.get_tag_value(dcl.add_info, 'PASS_NUM') AS passport_number,
        sy_convert.get_tag_value(dcl.add_info, 'PASS_EXP') AS passport_expiry,
        dcl.ident_number   AS eida,
        sy_convert.get_tag_value(dcl.add_info, 'CL_PASS_EXP') AS eida_expiry
    FROM
        dwd_client dcl
        JOIN inst ON inst.institution_id = dcl.institution_id
                     AND dcl.record_state = 'A'
        LEFT JOIN dwd_country dcn ON dcn.code = dcl.citizenship
                                     AND dcn.record_state = 'A'
        LEFT JOIN (
            SELECT
                client_idt,
                MAX(CASE
                    WHEN dwd_address_type.code = 'ADD_SMS_1' THEN address_zip
                END) AS phone_mobile,
                MAX(CASE
                    WHEN dwd_address_type.code = 'ADD_SMS_1' THEN e_mail
                END) AS e_mail
            FROM
                dwd_address
                JOIN dwd_address_type ON dwd_address.address_type_id = dwd_address_type.id
                                         AND dwd_address_type.code = 'ADD_SMS_1'
                                         AND dwd_address_type.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy')
                                         AND dwd_address_type.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy')
            WHERE
                dwd_address.record_state = 'A'
                AND dwd_address.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy')
                AND dwd_address.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy')
            GROUP BY
                dwd_address.client_idt
        ) addr ON ( addr.client_idt = dcl.record_idt )
), contracts AS (
    SELECT /*+ no_merge materialize index(c dwd_contract_inst_idx)*/
        c.personal_account,
        c.record_idt   AS contract_idt,
        substr(p.code, 1, 3) AS logo,
        p.name         AS logo_name,
        credit_limit   AS contract_credit_limit,
        c.client_idt,
        sy_convert.get_tag_value(c.add_info, 'DD_PCNT') AS ddf_pcnt,
        sy_convert.get_tag_value(c.add_info, 'LTY_P01') AS loyalty_program_01,
        sy_convert.get_tag_value(c.add_info, 'LTY_P02') AS loyalty_program_02,
        sy_convert.get_tag_value(c.add_info, 'LTY_P03') AS loyalty_program_03,
        sy_convert.get_tag_value(c.add_info, 'LTY_P04') AS loyalty_program_04,
        sy_convert.get_tag_value(c.add_info, 'LTY_P05') AS loyalty_program_05,
        billing_date   AS statement_date,
        due_date       AS payment_due_date,
        activity_status,
        pct_tariff,
        sy_convert.get_tag_value(c.add_info, 'EXT_ID_1') AS acp_id,
        sy_convert.get_tag_value(c.add_info, 'SALES_DET_1') AS staff_officer_code,
        sy_convert.get_tag_value(c.add_info, 'SALES_MG') AS staff_officer_name,
        sy_convert.get_tag_value(c.add_info, 'SALES_CAMPAIGN') AS promo_code,
        crl.amount_available
    FROM
        dwd_contract c
        JOIN inst i ON c.institution_id = i.institution_id
        JOIN products p ON c.product_id = p.product_id
        JOIN dwf_contract_billing dcb ON dcb.contract_idt = c.record_idt
                                         AND dcb.banking_date BETWEEN trunc(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY'), 'mm') AND TO_DATE
                                         (:P_REPORT_DATE, 'DD-MM-YYYY')
        JOIN crlimit crl ON crl.contract_idt = c.record_idt
                            AND c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                            AND c.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        LEFT JOIN (
            SELECT /*+ no_merge use_hash(dca da) */
                dca.contract_idt,
                MAX(CASE
                    WHEN da.type_code = 'BFA_ACCOUNT_STATUS' THEN da.name
                    ELSE NULL
                END) AS activity_status,
                MAX(CASE
                    WHEN da.type_code = 'PCT_TARIFF_EFF' THEN da.code
                    ELSE NULL
                END) AS pct_tariff
            FROM
                dwa_contract_attribute dca
                JOIN dwd_attribute da ON da.id = dca.attr_id
                                         AND da.type_code IN (
                    'BFA_ACCOUNT_STATUS',
                    'PCT_TARIFF_EFF'
                )
            WHERE
                dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                AND dca.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
            GROUP BY
                dca.contract_idt
        ) con_attr ON con_attr.contract_idt = c.record_idt
), crd_block_code AS (
    SELECT /*no_merge */
        dca.card_idt,
        MAX(nvl(CASE
            WHEN da.type_code = 'PRIM_SUPPLY_CLASS' THEN da.code
        END, 'P')) prim_supply_class,
        MAX(CASE
            WHEN da.type_code = 'PETRA_CARD_STATUS' THEN da.name
            ELSE NULL
        END) AS card_status,
        MAX(CASE
            WHEN da.type_code = 'VIRTUAL_CARD' THEN da.code
            ELSE NULL
        END) AS virtual_flag,
        MAX(CASE
            WHEN da.type_code = 'VIRTUAL_CARD' THEN dca.attr_date_from
            ELSE NULL
        END) AS virtual_date_conv
    FROM
        dwa_card_attribute dca
        JOIN dwd_attribute da ON da.id = dca.attr_id
                                 AND da.type_code IN (
            'PRIM_SUPPLY_CLASS',
            'PETRA_CARD_STATUS',
            'VIRTUAL_CARD'
        )
                                 AND da.dimension_code = 'DWD_CARD'
                                 AND dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                                 AND dca.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                                 AND da.record_state = 'A'
    GROUP BY
        dca.card_idt
), prev_attr_crd AS (
    SELECT /*+ no_merge materialize */
        bc.card_idt,
        MAX(CASE
            WHEN da.type_code = 'VIRTUAL_CARD' || :ORG THEN da.code
            ELSE NULL
        END) AS prev_virtual_flag
    FROM
        crd_block_code bc
        JOIN dwh.dwa_card_attribute dca ON bc.card_idt = dca.card_idt
        JOIN dwh.dwd_attribute da ON da.id = dca.attr_id
                                     AND da.type_code = 'VIRTUAL_CARD'
    WHERE
        dca.attr_date_to = virtual_date_conv - 1
    GROUP BY
        bc.card_idt
), token_wall AS (
    SELECT /*+ materialize*/
        coalesce(org_conf.code, default_conf.code) AS token_req_id,
        coalesce(org_conf.name, default_conf.name) AS wallet_name
    FROM
        (
            SELECT
                filter2,
                code,
                name
            FROM
                c$sy_handbook t
                JOIN inst ON ( t.filter = inst.bank_code )
            WHERE
                t.amnd_state = 'A'
                AND t.group_code = 'TOKEN_REQUESTOR'
        ) org_conf
        FULL OUTER JOIN (
            SELECT
                *
            FROM
                c$sy_handbook tt
            WHERE
                tt.filter = '000'
                AND tt.group_code = 'TOKEN_REQUESTOR'
                AND tt.amnd_state = 'A'
        ) default_conf ON ( org_conf.filter2 = default_conf.filter2 )
), token AS (
    SELECT
        card_idt,
        MAX(CASE
            WHEN wallet_name = 'APPLE PAY' THEN 'Y'
            ELSE NULL
        END) token_apple_pay,
        MAX(CASE
            WHEN wallet_name = 'GOOGLE PAY' THEN 'Y'
            ELSE NULL
        END) token_google_pay,
        MAX(CASE
            WHEN wallet_name = 'SAMSUNG PAY' THEN 'Y'
            ELSE NULL
        END) token_samsung_pay
    FROM
        (
            SELECT
                sy_convert.get_tag_value(td.parm_data, 'MC_WALLET_DATA') AS service_provider,
                td.acnt_contract__id   AS card_idt
            FROM
                c$td_auth_sch td
                JOIN c$td_auth_val tv ON td.id = tv.td_auth_sch__oid
                JOIN c$td_auth_parm tp ON tv.auth_parm = tp.id
                                          AND tp.code = 'T_STATUS'
            WHERE
                ( td.name = :ORG || '-TOKEN-VTS'
                  OR td.name = :ORG || '-TOKEN-MDES' )
                AND td.amnd_state = 'A'
                AND tv.amnd_state = 'A'
                AND tp.amnd_state = 'A'
                AND tv.parm_value IN (
                    'Suspended',
                    'Deactivated',
                    'Active'
                )
        ) tok_dim
        JOIN token_wall ON token_req_id = tok_dim.service_provider
    GROUP BY
        card_idt
), event AS (
    SELECT /*+ no_merge materialize index(e dwf_card_event_inst_idx) use_nl(i) */
        e.card_idt,
        MIN(e.activate_date) AS activation_date
    FROM
        dwf_card_event e
        JOIN inst i ON e.institution_id = i.institution_id
        JOIN dwd_event_type det ON det.code = 'UNLOCK_PLASTIC'
                                   AND e.event_type_id = det.id
                                   AND det.record_state = 'A'
    GROUP BY
        e.card_idt
),balance as ( SELECT
    b.contract_idt,
    abs(sum(b.balance)) AS account_balance
FROM
         dwf_account_balance b
    JOIN contracts           i ON i.contract_idt = b.contract_idt
    JOIN v_dwr_account_group ag ON ag.account_group_id = b.account_group_id
                                   AND class_code = 'BALANCE_TYPE'
                                   AND type_code = 'TOTAL_BALANCE'
WHERE
    b.banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
group by b.contract_idt )
SELECT
    acp_id,
    client_number             AS cif_id,
    c.logo_name               AS card_type,
    bc.prim_supply_class      AS prm_sup,
    c.contract_credit_limit   AS account_limit,
    c.personal_account        AS acct_nbr,
    c.activity_status         AS acct_status,
    cd.card_number            AS card_nbr,
    cd.card_credit_limit      AS card_limit,
    b.account_balance         AS os_balance,
    c.amount_available        AS available_limit,
    ddf_pcnt                  AS dd_pcnt,
    statement_date            AS statement_date,
    CASE
        WHEN ( ( bc.virtual_flag = 'Y'
                 OR bc.virtual_flag = 'F' )
               OR ( ( bc.virtual_flag = 'Y'
                      OR bc.virtual_flag = 'F' )
                    AND ( prev_virtual_flag = 'N'
                          OR prev_virtual_flag = 'F' ) ) ) THEN card_open_date
        ELSE NULL
    END AS virtual_card_activation_date,
    CASE
        WHEN virtual_flag = 'N' THEN activation_date
        ELSE NULL
    END AS physical_card_activation_date,
    payment_due_date          AS payment_due_date,
    c.logo                    AS logo,
    c.pct_tariff              AS pct,
    staff_officer_code        AS staff_officer_code,
    staff_officer_name,
    channel_id,
    promo_code,
    bc.card_status            AS card_status,
    cd.card_open_date         AS card_open_date,
    cd.embossed_names         AS cardholder_name,
    cl.nationality            AS nationality,
    cl.gender                 AS gender,
    cl.language               AS language,
    cl.e_mail                 AS email_id,
    eida,
    eida_expiry,
    cl.passport_number        AS passport_nbr,
    cl.passport_expiry        AS passport_expiry,
    cl.phone_mobile           AS sms_mobile_nbr,
    nvl(c.loyalty_program_01, 'N') AS loyalty_pgm_p1,
    nvl(c.loyalty_program_02, 'N') AS loyalty_pgm_p2,
    nvl(c.loyalty_program_03, 'N') AS loyalty_pgm_p3,
    nvl(c.loyalty_program_04, 'N') AS loyalty_pgm_p4,
    nvl(c.loyalty_program_05, 'N') AS loyalty_pgm_p5,
    DECODE(token.token_apple_pay, NULL, 'N', 'Y') AS token_applepay,
    DECODE(token.token_google_pay, NULL, 'N', 'Y') AS token_googlepay,
    DECODE(token.token_samsung_pay, NULL, 'N', 'Y') AS token_samsungpay
FROM
    cards cd
    JOIN contracts c ON cd.main_contract_idt = c.contract_idt
	JOIN balance b ON b.contract_idt=c.contract_idt
    LEFT JOIN crd_block_code bc ON bc.card_idt = cd.card_id
    JOIN cl_addr cl ON cl.client_idt = c.client_idt
    LEFT JOIN token ON cd.card_id = token.card_idt
    LEFT JOIN prev_attr_crd pcb ON pcb.card_idt = cd.card_id
    LEFT JOIN event e ON e.card_idt = cd.card_id