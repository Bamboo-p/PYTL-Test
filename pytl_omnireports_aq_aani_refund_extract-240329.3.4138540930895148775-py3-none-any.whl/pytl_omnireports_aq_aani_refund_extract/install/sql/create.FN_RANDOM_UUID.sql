/*
2400329.1: maksimsk: NIBOA-9700: initial development
*/
create or replace and compile
java source named "RandomUUID"
as
public class RandomUUID
{
  public static String create()
  {
    /*
      Static factory to retrieve a type 4 (pseudo randomly generated) UUID. 
      The UUID is generated using a cryptographically strong pseudo random number generator.
      https://docs.oracle.com/javase/8/docs/api/java/util/UUID.html
    */
    return java.util.UUID.randomUUID().toString();
  }
}
/


create or replace function fn_random_uuid
return varchar2
as
-------------------------------------------------------------------------------
-- Function is generated random UUIDv4 using Java UUID.randomUUID()
--
-- UUIDv4 has the following format:
--  [a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}
--    first 8 bytes and second 4 bytes should be chars from range a-f or 0-9
--    third 4 bytes must be first fixed "4" and next chars should be from range a-f or 0-9
--    fourth 4 bytes must be first char from (8,9,a,b) and next chars should from range a-f or 0-9
--    fifth 12 bytes  should be chars from range a-f or 0-9
--
--  For example:
--    select FN_RANDOM_UUID from dual;
--      return: f44913c2-0d2f-4d42-8687-141d27327dcc
-------------------------------------------------------------------------------
language java
NAME 'RandomUUID.create() return java.lang.String';
/
exit;
