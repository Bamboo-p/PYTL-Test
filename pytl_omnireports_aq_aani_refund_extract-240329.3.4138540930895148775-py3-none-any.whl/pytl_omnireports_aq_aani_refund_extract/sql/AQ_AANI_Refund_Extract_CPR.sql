/* 
240327.1: maksimsk: NIBOA-9700: Initial development
240327.2: maksimsk: NIBOA-9700: fixed HEAD_MSG_ID, ORIG_CB_UETR, LOCAL_DT
240328.1: maksimsk: NIBOA-9700: fixed INPUT_DATETIME
240329.1: maksimsk: NIBOA-9700: fixed INTR_BK_STTLM_DT is mapped from LocalDt
*/
with w4file as (
select 
   t_batches.ORG
  ,t_batches.INPUT_BATCH_UID
  ,t_records.IN_DATA."ORIG_CB_ETE"[0] as ORIG_CB_ETE
  ,t_records.IN_DATA."ORIG_CB_UETR"[0] as ORIG_CB_UETR
  ,t_records.IN_DATA."Transaction"."Amount" as AMOUNT
  ,t_records.IN_DATA."ORIG_CB_DBTRID"[0] as ORIG_CB_DBTRID
  ,t_records.IN_DATA."ORIG_CB_DBTRISSR"[0] as ORIG_CB_DBTRISSR
  ,t_records.IN_DATA."Originator"."ContractNumber" as DBTR_ACCT_IBAN
  ,t_records.IN_DATA."ORIG_CB_DBTRAGT"[0] as ORIG_CB_DBTRAGT
  ,t_records.IN_DATA."ORIG_CB_CDTRAGT"[0] as ORIG_CB_CDTRAGT
  ,t_records.IN_DATA."ORIG_CB_CLRYSREF"[0] as ORIG_CB_CLRYSREF
  ,t_records.IN_DATA."ORIG_DTL"[0] as CDTR_NM
  ,t_records.IN_DATA."Destination"."ContractNumber" as CDTR_ACCT_IBAN
  ,t_records.IN_DATA."CB_ORGNTXID"[0] as CB_ORGNTXID
  ,t_records.IN_DATA."ORIG_CB_TXID"[0] as ORIG_CB_TXID
  ,t_records.IN_DATA."LocalDt" as LOCAL_DT
from stg_etl.PYTL_INTERFACES_BATCHES t_batches
join stg_etl.PYTL_INTERFACES_RECORDS t_records on t_records.BATCH_ID = t_batches.UNIQUE_ID
where 1=1
  and t_batches.INPUT_BATCH_UID = :INPUT_BATCH_UID
  and t_batches.ORG = :ORG
  and t_batches.INTERFACE = :INTERFACE
)
,cpr_head as (
select
   'E410'||to_char(INPUT_DATETIME, 'YYMMDDHH24MISS')||'CPR'||'001' as MSG_ID
  ,to_char(INPUT_DATETIME, 'YYYY-MM-DD"T"HH24.MI.SS.FF3')||'Z' as CRE_DT_TM
  ,RECORD_COUNT
  ,TOTAL_AMOUNT
  ,CONST_EOD_CPR
  ,INSTGAGT_BICFI
  ,INSTDAGT_BICFI
from (
  select 
     w4file.ORG
    ,max(NVL(to_timestamp(:FILE_TIME_UID, 'YYMMDD_HH24MISS_FF3'), current_timestamp)) as INPUT_DATETIME
    ,COUNT(1) AS RECORD_COUNT
    ,SUM(to_number(w4file.AMOUNT)) AS TOTAL_AMOUNT
    ,'EOD CPR' as CONST_EOD_CPR
    ,'E410AEX0' as INSTGAGT_BICFI
    ,:INSTDAGT_BICFI as INSTDAGT_BICFI  /* AEPCAEA0 - for UAT, AEPCAEAA - for PROD */
  from w4file
  group by 
     w4file.ORG
  )
)
,cpr_body as (
select 
   w4file.ORG
  ,w4file.ORIG_CB_ETE
  ,to_char(to_date(w4file.LOCAL_DT, 'YYYY-MM-DD HH24:mi:ss'), 'YYYY-MM-DD"T"HH24.MI.SS')||'.000Z' as LOCAL_DT
  ,to_char(to_date(w4file.LOCAL_DT, 'YYYY-MM-DD HH24:mi:ss'), 'YYYY-MM-DD')||'Z' as INTR_BK_STTLM_DT
  ,w4file.ORIG_CB_TXID as ORIG_CB_TXID
  ,w4file.ORIG_CB_UETR
  ,w4file.AMOUNT
  ,w4file.CDTR_NM
  ,w4file.ORIG_CB_CLRYSREF
  ,case 
    when w4file.ORIG_CB_DBTRID not like '%-7777'
      then  w4file.ORIG_CB_DBTRID||'%-7777'
    else    w4file.ORIG_CB_DBTRID
   end ORIG_CB_DBTRID
  ,w4file.ORIG_CB_DBTRISSR
  ,w4file.DBTR_ACCT_IBAN
  ,w4file.ORIG_CB_DBTRAGT
  ,w4file.ORIG_CB_CDTRAGT
  ,w4file.CDTR_ACCT_IBAN
  ,'BOID' as CONST_BOID
  ,'OTHR' as CONST_OTHR
  ,'TEST' as CONST_TEST
from w4file
)
select 
   bd.ORG
  ,'CPR_'||to_char(rownum) as FILENAME
  ,bd.ORIG_CB_ETE
  ,bd.LOCAL_DT
  ,bd.INTR_BK_STTLM_DT
  ,bd.ORIG_CB_TXID
  ,bd.ORIG_CB_UETR
  ,bd.AMOUNT
  ,bd.CDTR_NM
  ,bd.ORIG_CB_CLRYSREF
  ,bd.ORIG_CB_DBTRID
  ,bd.ORIG_CB_DBTRISSR
  ,bd.DBTR_ACCT_IBAN
  ,bd.ORIG_CB_DBTRAGT
  ,bd.ORIG_CB_CDTRAGT
  ,bd.CDTR_ACCT_IBAN
  ,bd.CONST_BOID
  ,bd.CONST_OTHR
  ,bd.CONST_TEST
  ,hd.MSG_ID as HEAD_MSG_ID
  ,hd.CRE_DT_TM
  ,hd.CONST_EOD_CPR
  ,hd.RECORD_COUNT as HEAD_RECORD_COUNT
  ,hd.TOTAL_AMOUNT as HEAD_TOTAL_AMOUNT
  ,hd.INSTGAGT_BICFI as HEAD_INSTGAGT_BICFI
  ,hd.INSTDAGT_BICFI as HEAD_INSTDAGT_BICFI
from cpr_body bd
join cpr_head hd on 1=1
