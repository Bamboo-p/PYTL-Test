/* 
240327.1: maksimsk: NIBOA-9700: Initial development
240328.1: maksimsk: NIBOA-9700: fixed INPUT_DATETIME, added sequence number
240329.1: maksimsk: NIBOA-9700: added function fn_random_uuid for generating UUIDv4
*/
with w4file as (
select 
   t_batches.ORG
  ,t_records.IN_DATA."ORIG_CB_ETE"[0] as ORIG_CB_ETE
  ,t_records.IN_DATA."ARN"[0] as ARN
  ,t_records.IN_DATA."DOCID"[0] as DOCID
  ,t_records.IN_DATA."Transaction"."Amount" as AMOUNT
  ,t_records.IN_DATA."SourceDtls"."MerchantName" as DBTR_NM
  ,t_records.IN_DATA."ORIG_CB_DBTRID"[0] as ORIG_CB_DBTRID
  ,t_records.IN_DATA."ORIG_CB_DBTRISSR"[0] as ORIG_CB_DBTRISSR
  ,t_records.IN_DATA."Originator"."ContractNumber" as DBTR_ACCT_IBAN
  ,t_records.IN_DATA."ORIG_CB_DBTRAGT"[0] as ORIG_CB_DBTRAGT
  ,t_records.IN_DATA."ORIG_DTL"[0] as ORIG_DTL
  ,t_records.IN_DATA."Destination"."ContractNumber" as CDTR_ACCT_IBAN
  ,t_records.IN_DATA."CB_ORGNTXID"[0] as CB_ORGNTXID
from stg_etl.PYTL_INTERFACES_BATCHES t_batches
join stg_etl.PYTL_INTERFACES_RECORDS t_records on t_records.BATCH_ID = t_batches.UNIQUE_ID
where 1=1
  and t_batches.INPUT_BATCH_UID = :INPUT_BATCH_UID
  and t_batches.ORG = :ORG
  and t_batches.INTERFACE = :INTERFACE
)
, seq as (
select
count(1) as last_seq_num
from stg_etl.PYTL_INTERFACES_BATCHES t_batches
where 1=1
  and t_batches.ORG = :ORG
  and t_batches.INTERFACE = :INTERFACE
  and trunc(t_batches.INPUT_DATETIME) = trunc(sysdate)
)
,pacs008_head as (
select 
   ORG
  ,'RETURN'||lpad(NVL(seq.last_seq_num, 0)+1, 9, '0') as MSG_ID
  ,to_char(INPUT_DATETIME, 'YYYY-MM-DD"T"HH24.MI.SS.FF3')||'+04.00' as CRE_DT_TM
  ,to_char(INPUT_DATETIME, 'YYYY-MM-DD') as INTR_BK_STTLM_DT
  ,RECORD_COUNT
  ,TOTAL_AMOUNT
  ,STTLM_MTD
  ,PRTRY
  ,INSTGAGT_BICFI
  ,INSTDAGT_BICFI  /* AEPCAEA0 - for UAT, AEPCAEAA - for PROD */
from (
  select 
     w4file.ORG
    ,max(NVL(to_timestamp(:FILE_TIME_UID, 'YYMMDD_HH24MISS_FF3'), current_timestamp)) as INPUT_DATETIME
    ,COUNT(1) AS RECORD_COUNT
    ,SUM(to_number(w4file.AMOUNT)) AS TOTAL_AMOUNT
    ,'CLRG' as STTLM_MTD
    ,'UAEIPP Core Service' as PRTRY
    ,'E410AEX0' as INSTGAGT_BICFI
    ,:INSTDAGT_BICFI as INSTDAGT_BICFI  /* AEPCAEA0 - for UAT, AEPCAEAA - for PROD */
  from w4file
  group by 
     w4file.ORG
  ) 
  left join seq on 1=1
)
,pacs008_body as (
select 
   w4file.ORG
  ,w4file.ORIG_CB_ETE
  ,w4file.ARN
  ,'PACS008RETURN'||w4file.DOCID as TXID
  ,stg_etl.fn_random_uuid as UUIDV4
  ,'BATC' as LCL_INSTRM_PRTRY
  ,'IPR'  as CTGY_PURP_PRTRY
  ,w4file.AMOUNT
  ,'SLEV' as CHRGBR
  ,w4file.DBTR_NM
  ,case 
    when w4file.ORIG_CB_DBTRID not like '%-7777'
      then  w4file.ORIG_CB_DBTRID||'%-7777'
    else    w4file.ORIG_CB_DBTRID
   end ORIG_CB_DBTRID
  ,'BOID' as SCHMENM_CD
  ,w4file.ORIG_CB_DBTRISSR
  ,w4file.DBTR_ACCT_IBAN
  ,'E410AEX0' as DBTRAGT_BICFI
  ,w4file.ORIG_CB_DBTRAGT
  ,w4file.ORIG_DTL
  ,w4file.CDTR_ACCT_IBAN
  ,'OTHR' as CDTR_ACCT_TP_CD
  ,'NOWS' as PURP_CD
  ,'REFUND ON '||w4file.CB_ORGNTXID||' SALE' as RMT_INF_USTRD
from w4file
)
select 
   bd.ORG
  ,bd.ORIG_CB_ETE
  ,bd.ARN as END_TO_END_ID
  ,bd.TXID
  ,bd.UUIDV4
  ,bd.LCL_INSTRM_PRTRY
  ,bd.CTGY_PURP_PRTRY
  ,bd.AMOUNT
  ,bd.CHRGBR
  ,bd.DBTR_NM
  ,bd.ORIG_CB_DBTRID
  ,bd.SCHMENM_CD
  ,bd.ORIG_CB_DBTRISSR
  ,bd.DBTR_ACCT_IBAN
  ,bd.DBTRAGT_BICFI
  ,bd.ORIG_CB_DBTRAGT
  ,bd.ORIG_DTL
  ,bd.CDTR_ACCT_IBAN
  ,bd.CDTR_ACCT_TP_CD
  ,bd.PURP_CD
  ,bd.RMT_INF_USTRD
  ,hd.MSG_ID
  ,hd.CRE_DT_TM
  ,hd.INTR_BK_STTLM_DT
  ,hd.RECORD_COUNT
  ,hd.TOTAL_AMOUNT
  ,hd.STTLM_MTD
  ,hd.PRTRY
  ,hd.INSTGAGT_BICFI
  ,hd.INSTDAGT_BICFI
from pacs008_body bd
join pacs008_head hd on 1=1
