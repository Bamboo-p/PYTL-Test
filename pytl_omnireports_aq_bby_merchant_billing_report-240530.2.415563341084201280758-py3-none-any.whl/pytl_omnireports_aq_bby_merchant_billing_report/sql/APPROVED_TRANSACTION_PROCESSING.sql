/*
*
* Version history:
* 240516.1 = HamzaHendi = BBY-3394 : Initial Version
* 240522.1 = HamzaHendi = BBY-3394 : changing the query to DM
*/


WITH inst AS
(SELECT /*+ no_merge */
 code,
 id
 from dwh.dwd_institution
 where record_state = 'A'
 and code = :ORG
),
cntr as
(select /*+ no_merge */
 cntr.record_idt,
 cntr.personal_account,
 cntr.date_open
from dwh.dwd_contract cntr
join inst on inst.id = cntr.institution_id
where cntr.parent_contract_idt is null
and   cntr.record_state = 'A'
 ),
 trans_type as
(select /*+ no_merge */
  dtt.id
  from dwd_transaction_type dtt
  where dtt.record_state = 'A'
  and dtt.code in  ('R1-P','K1-P')                
),
trans as 
(select 
 case when t.target_channel in('e','E') then 'Mastercard'
      when t.target_channel in('v','V') then 'VISA' 
 end schemetype,
 case when t.target_channel in('e','E') then 'Auth'
      when  t.target_channel in('v','V') then 'Capture' 
 end TranType,
 'Approved' TranStatus
 from dwh.dwf_transaction t
 join inst i on i.id = t.institution_id
 join trans_type tt on tt.id = t.transaction_type_id
 join cntr on   cntr.personal_account = t.merchant
 where t.target_channel in ('v', 'V' , 'e' , 'E') 
 and   t.banking_date >= add_months(to_date(:P_REPORT_DATE,'dd-mm-yyyy') , -1)  
 and   t.banking_date < to_date(:P_REPORT_DATE,'dd-mm-yyyy') 
 )
 select 
 :ORG AS ORG,
 t.schemetype,
 t.TranType,
 t.TranStatus,
 count(1) Transaction_Count 
 from trans t
 group by t.schemetype,
          t.TranType,
          t.TranStatus
 union all
 select 
 :ORG AS ORG,
 null,
 null,
 'Total',
 count(1)
 from trans