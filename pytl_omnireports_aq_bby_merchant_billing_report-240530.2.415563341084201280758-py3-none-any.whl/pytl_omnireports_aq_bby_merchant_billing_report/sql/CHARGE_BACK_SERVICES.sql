/*
*
* Version history:
* 240516.1 = HamzaHendi = BBY-3394 : Initial Version
* 240522.1 = HamzaHendi = BBY-3394 : changing the query to DM
* 240530.1 = HamzaHendi = BBY-3437 : fixing chargeback codes query

*/

WITH inst AS
(SELECT /*+ no_merge */
 code,
 id
 from dwh.dwd_institution
 where record_state = 'A'
 and code = :ORG
),
cntr as
(select /*+ no_merge */
 cntr.record_idt,
 cntr.personal_account,
 cntr.date_open
from dwh.dwd_contract cntr
join inst on inst.id = cntr.institution_id
where cntr.parent_contract_idt is null
and   cntr.record_state = 'A'
 ),
 trans_type as
(select /*+ no_merge */
  dtt.id
  from dwd_transaction_type dtt
  where dtt.record_state = 'A'
  and dtt.code in  ('C2-P','C4-P','C6-P','R2-P','R4-P','R6-P','K2-P','K4-P','K6-P','U2-P','U4-P','U6-P')            
),
trans as 
(select 
 case when t.source_channel in('e','E') then 'Mastercard'
      when t.source_channel in('v','V') then 'VISA' 
 end schemetype
 from dwh.dwf_transaction t
 join inst i on i.id = t.institution_id
 join trans_type tt on tt.id = t.transaction_type_id
 join cntr on   cntr.personal_account = t.merchant
 where t.source_channel in ('v', 'V' , 'e' , 'E') 
 and   t.banking_date >= add_months(to_date(:P_REPORT_DATE,'dd-mm-yyyy') , -1)  
 and   t.banking_date < to_date(:P_REPORT_DATE,'dd-mm-yyyy') 
 )
 select :ORG AS ORG,
        t.schemetype,
        null TranType,
        count(1) Transaction_Count 
 from trans t
 group by t.schemetype
 union all
 select :ORG AS ORG,
        'Total Chargeback transactions',
        null,
        count(1)
 from trans