/*
*
* Version history:
* 240522.1 = HamzaHendi = BBY-3394 : Initial Version
* 240530.1 = HamzaHendi = BBY-3437 : fixing target channel
* 240530.2 = HamzaHendi = BBY-3437 : fixing target channel
*/

WITH institution as (
            select /*+ no_merge materialize */
                   id
              from ows.f_i
             where bank_code = :ORG
               and amnd_state = 'A'
        ),
contracts as 
(
select 
 ac.contract_number
 FROM ows.acnt_contract ac
 JOIN institution f  ON f.ID = ac.f_i        
 where ac.amnd_state = 'A'
 and   ac.pcat = 'M'
 and   ac.ccat = 'C'
 and   ac.con_cat = 'A' 
 ),   
 tr_typ as 
 (
select /*+ no_merge materialize */ 
 id
 from ows.trans_type
 where amnd_state = 'A'
 and   trans_code IN ('R1','K1')
 ),
trans as
(select ac.* 
from 
 (/*rejected transaction docs*/
select  /*+ ordered index(d DOC_DATE) */
    d.merchant_id,
    case when ows.sy_convert.get_tag_value(d.add_info ,'ACQ_TGT_CHNL') in('e','E') then 'Mastercard'
         when ows.sy_convert.get_tag_value(d.add_info ,'ACQ_TGT_CHNL') in('v','V') then 'VISA' 
    end schemetype,
    case when ows.sy_convert.get_tag_value(d.add_info ,'ACQ_TGT_CHNL') in('e','E') then 'Auth'
         when ows.sy_convert.get_tag_value(d.add_info ,'ACQ_TGT_CHNL') in('v','V') then 'Capture' 
    end TranType,
    'Declined' TranStatus
from ows.doc d 
JOIN tr_typ tt      ON tt.ID =  d.trans_type                             
WHERE  d.amnd_date >= add_months(to_date(:P_REPORT_DATE,'dd-mm-yyyy') , -1)  
AND d.amnd_date < to_date(:P_REPORT_DATE,'dd-mm-yyyy') 
AND d.amnd_state = 'A' 
AND ows.sy_convert.get_tag_value(d.add_info ,'ACQ_TGT_CHNL') in ('v', 'V' , 'e' , 'E') 
AND d.posting_status IN ('J', 'D', 'E')
 ) ac
 JOIN contracts on contracts.contract_number = ac.merchant_id
)
 select /*+ parallel(8) */
 :ORG AS ORG,
 t.schemetype,
 t.TranType,
 t.TranStatus,
 count(1) Transaction_Count 
 from trans t
 group by t.schemetype,
          t.TranType,
          t.TranStatus
 union all
 select :ORG AS ORG,
        null,
        null,
       'Total',
       count(1)
 from trans