/*
*
* Version history:
* 240516.1 = HamzaHendi = BBY-3394 : Initial Version
* 240522.1 = HamzaHendi = BBY-3394 : changing the query to DM 
*/


WITH inst AS
(SELECT /*+ no_merge */
 code,
 id
 from dwh.dwd_institution
 where record_state = 'A'
 and code = :ORG
),
cntr as
(select /*+ no_merge materialize */
 cntr.record_idt,
 cntr.personal_account,
 cntr.date_open
from dwh.dwd_contract cntr
join inst on inst.id = cntr.institution_id
where cntr.parent_contract_idt is null
 and  cntr.date_open >= add_months(to_date(:P_REPORT_DATE,'dd-mm-yyyy') , -1) 
 and  cntr.date_open < to_date(:P_REPORT_DATE,'dd-mm-yyyy') 
 and  cntr.record_state = 'A'
 )
select 
 :ORG AS ORG,
 to_char(cntr.date_open , 'dd-Mon-yyyy') as "DateOpen",
 cntr.personal_account as "MID"
 from  cntr
 union all
 select 
 :ORG AS ORG,
 'Total number of MID',
 to_char(count(1))
 from cntr