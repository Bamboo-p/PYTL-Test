__version__ = "240603.1"
__job_name__ = "PyTL_OmniReports_AQ_BBY_Payout_And_Settlement"
__bat_files__ = ["PyTL_AQ_BBY_MERCHANT.bat"]
