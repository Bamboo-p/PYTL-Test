/*
* Detailed Settlement Report BBY 
*
* Version history:
* 240508.1 = Khader = BBY-3393 : Initial Version
* 240522.1 = Khader = BBY-3143 : Table name update
* 240527.1 = HamzaHendi = BBY-3143 : fixing date and time
* 240530.1 = HamzaHendi = BBY-3427 : fixing date format
*/
select 
 :ORG as ORG,
 ' ' as "Tran Date",
 ' ' as "Tran Time",
 ' ' as "Merchant Code",
 ' ' as "Store Code",
 ' ' as "Terminal Code",
 ' ' as "Batch",
 ' ' as "RRN",
 'Detailed Settlement Statement' as "Card No",
 ' ' as "Tran Type",
 ' ' as "Approval Code",
 ' ' as "Tran Amt",
 ' ' as "Commission",
 ' ' as "Net Amt"
from dual

union all

select 
 :ORG as ORG,
 'Tran Date',
 'Tran Time',
 'Merchant Code',
 'Store Code',
 'Terminal Code',
 'Batch',
 'RRN',
 'Card No',
 'Tran Type',
 'Approval Code',
 'Tran Amt',
 'Commission',
 'Net Amt'
from dual

union all

select 
 :ORG as ORG,
 to_char(banking_date ,'DD-MON-YYYY')           as "Tran Date",
 to_char(banking_date , 'hh24miss')             as "Tran Time",
 to_char(personal_Account)                      as "Merchant Code",
 to_char(personal_Account)                      as "Store Code",
 to_char(dev_personal_acnt)                     as "Terminal Code",
 ' '                                            as "Batch",
 to_char(trans_rrn)                             as "RRN",
 to_char(target_number)                         as "Card No",
 to_char(txn_code_group)                        as "Tran Type",
 to_char(auth_code)                             as "Approval Code",
 to_char(tran)                                  as "Tran Amt",
 to_char(comission)                             as "Commission",
 to_char(net)                                   as "Net Amt"
  from OPT_ACQ_BBY_MERCHANT_DUMP
 
 union all

select  distinct
 :ORG as ORG,
 null,
 null,
 null,
 null,
 null,
 null,
 null,
 null,
 null,
 'Total :',
 sum_trn                                   as "Tran Amt",
 sum_comm                                  as "Commission",
 sum_net                                   as "Net Amt"
from OPT_ACQ_BBY_MERCHANT_DUMP