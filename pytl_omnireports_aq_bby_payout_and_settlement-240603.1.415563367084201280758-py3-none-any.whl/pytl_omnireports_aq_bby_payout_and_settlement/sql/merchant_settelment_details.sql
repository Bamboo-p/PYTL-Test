/*
* Merchant Settlement Report BBY 
*
* Version history:
* 240508.1 = Khader = BBY-3393 : Initial Version
* 240522.1 = Khader = BBY-3143 : Table name update & Column name change 
* 240527.1 = HamzaHendi = BBY-3143 : fixing table name
* 240530.1 = HamzaHendi = BBY-3427 : fixing time feild
* 240603.1 = PrabirK = BBY-3427 : Remove unnecessary hints from sql
*/
SELECT 
  :ORG as ORG,
  ' ' as "Merchant Aggregator ID",
  ' ' as "Merchant Type",
  ' ' as "MID",
  ' ' as "SID",
  ' ' as "TID",
  ' ' as "Settlement Date",
  ' ' as "Business Date",
  ' ' as "Transaction Type",
  ' ' as "Source Currency",
  ' ' as "Source Amount",
  ' ' as "Target a/c Type",
  ' ' as "Target a/c currency",
  ' ' as "Target a/c",
  ' ' as "Target a/c conversion rate table",
  ' ' as "Target a/c conversion rate",
  ' ' as "Target Converted Amount",
  ' ' as "Tax Type",
  ' ' as "% service tax",
  ' ' as "Service tax on converted amount",
  ' ' as "Net Settlement Amount",
  ' ' as "Remarks"
from dual

union all
 
SELECT 
  :ORG as ORG,'Merchant Settlement Report',null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null
from dual
 
union all
 
SELECT 
  :ORG as ORG,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null
from dual
 
union all
 
SELECT 
 distinct :ORG as ORG,'Financial Institution ID :'||  fi_name ,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null
from OPT_ACQ_BBY_MERCHANT_DUMP 
 
union all
 
SELECT 
  :ORG as ORG,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null
from dual
 
union all
 
SELECT 
  :ORG as ORG,'From Settlement Date:'||to_char(sysdate,'dd/mm/yyyy'),null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null
from dual
 
union all
 
SELECT 
  :ORG as ORG,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null
from dual
 
union all
SELECT 
  :ORG as ORG,'To Settlement Date:'||to_char(sysdate,'dd/mm/yyyy'),null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null
from dual
 
union all
 
SELECT 
  :ORG as ORG,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null
from dual
 
union all
 
SELECT 
  :ORG as ORG,'Run Date / Time :'||TO_CHAR(SYSDATE,'DD/MM/YYYY HH24:MI:SS') || ' Asia/Kuwait',null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null
from DUAL
 
union all
 
SELECT 
  :ORG as ORG,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null
from dual
 
union all

SELECT 
  :ORG as ORG,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null
from dual
 
UNION ALL

SELECT 
  :ORG as ORG,
  'Merchant Aggregator ID',
  'Merchant Type',
  'MID',
  'SID',
  'TID',
  'Settlement Date',
  'Business Date',
  'Transaction Type',
  'Source Currency',
  'Source Amount',
  'Target a/c Type',
  'Target a/c currency',
  'Target a/c',
  'Target a/c conversion rate table',
  'Target a/c conversion rate',
  'Target Converted Amount',
  'Tax Type',
  '% service tax',
  'Service tax on converted amount',
  'Net Settlement Amount',
  'Remarks'
from dual
 
union all
 
SELECT 
  :ORG as ORG,
  TO_CHAR(merch_name) as "Merchant Aggregator ID",
  TO_CHAR(Merchant_Type),
  TO_CHAR(personal_account) as "MID",
  TO_CHAR(personal_account) as "SID",
  TO_CHAR(dev_personal_acnt) as "TID",
  TO_CHAR(sysdate,'dd/mm/yyyy') as "Settlement Date",
  TO_CHAR(sysdate,'yyyy-mm-dd hh24:mi:ss') ||'.0' as "Business Date",
  TO_CHAR(txn_code_group) as "Transaction Type",
  TO_CHAR(TRANS_CURRENCY) as "Source Currency",
  TO_CHAR(TRANS_AMOUNT) as "Source Amount",
  '  ' as "Target a/c Type",
  TO_CHAR(TRANS_CURRENCY) as "Target a/c currency",
  TO_CHAR(Target_ac),
  '0' as "Target a/c conversion rate table",
  '0' as "Target a/c conversion rate",
  trans_amount  as "Target Converted Amount",
  '  ' as "Tax Type",
  '0' as "% service tax",
  '0.000' as "Service tax on converted amount",
  trans_amount as "Net Settlement Amount",
  'PGW'||' '||personal_account as "Remarks"
 
FROM OPT_ACQ_BBY_MERCHANT_DUMP

union all

SELECT 
  :ORG as ORG,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null
from dual
 
union all
 
SELECT 
  :ORG as ORG,
  'Total No of records : '||count(1) as "Merchant Aggregator ID",
  null as "Merchant Type",
  null as "MID",
  null as "SID",
  null as "TID",
  null as "Settlement Date",
  null as "Business Date",
  null as "Transaction Type",
  null as "Source Currency",
  null as "Source Amount",
  '*** END OF REPORT ***' as "Target a/c Type",
  null as "Target a/c currency",
  null as "Target a/c",
  null as "Target a/c conversion rate table",
  null as "Target a/c conversion rate",
  null as "Target Converted Amount",
  null as "Tax Type",
  null as "% service tax",
  null as "Service tax on converted amount",
  null as "Net Settlement Amount",
  null as "Remarks"
from OPT_ACQ_BBY_MERCHANT_DUMP