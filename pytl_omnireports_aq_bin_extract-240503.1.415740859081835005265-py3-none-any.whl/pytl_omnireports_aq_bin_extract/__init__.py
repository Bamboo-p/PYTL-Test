__version__ = "240503.1"
__job_name__ = "PyTL_OmniReports_AQ_BIN_EXTRACT"
__bat_files__ = []
