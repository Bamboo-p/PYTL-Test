/* 
240425.1: HamzaH: NIBOA-9983: Initial Version
240503.1: HamzaH: NIBOA-9983: changing Card type logic
*/
select
distinct
:ORG as org,
:P_BANK_NAME as bank_name,
:P_ACQ_INST_ID as acq_inst_id,
substr(start_bin,1,6) as bin,
substr(pan_length,1,2) as pan,
case when USAGE = 'C' then 'CR'
     when USAGE = 'D' then 'DR'
     when USAGE = 'P' then 'PR'
     end as card_type
from ows.bin_table
where country = :P_COUNTRY_CODE
and channel IN (:P_CHANNEL)
and instr(bin_details, 'TOKEN_BIN=Y;') = 0
and amnd_state = 'A'

