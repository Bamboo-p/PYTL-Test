/*
240216.1: maksimsk: NIBOA-9198: initial development
*/
create or replace function FN_TAG_MERGE (
  tags_list1       in varchar2,
  tags_list2       in varchar2
) return varchar2
is 
-------------------------------------------------------------------------------
-- Function for merging tag list 1 with tag list 2
--  @params:
--    tags_list1 - source tag list
--    tags_list2 - target tag list

--  If tag_list1.tag_code exists      in tag_list2  then update tag_list1.tag_code=tag_list2.tag_value
--  If tag_list1.tag_code not exists  in tag_list2  then add    tag_list1.tag_code=tag_list1.tag_value
--  If tag_list2.tag_code not exists  in tag_list1  then add    tag_list2.tag_code=tag_list2.tag_value
--  
--  For example:
--    tag_list1 = 'RESTRICT_PAYM=OG;FF_IND=N;CARD_PTI=1;COLL_BRAND=VISA;CBUAE;'
--    tag_list2 = 'RESTRICT_PAYM=DD;FF_IND=N;ESP=3;COLL_BRAND=MC;'
--  
--    FN_TAG_MERGE(tag_list1,tag_list2) = 'RESTRICT_PAYM=DD;FF_IND=N;COLL_BRAND=MC;CARD_PTI=1;CBUAE;ESP=3;'
-------------------------------------------------------------------------------
  tags_merged varchar2(4000 char);
begin
  if tags_list1 is null and tags_list2 is null then
    tags_merged := null;
  elsif tags_list1 is not null and tags_list2 is null then
    tags_merged := tags_list1;
  elsif tags_list1 is null and tags_list2 is not null then
    tags_merged := tags_list2;
  else
    for rec in (
      with tg1 as (
      select 
        tag_full, 
        NVL(substr(tag_full, 1, instr(tag_full, '=')-1),'__NA__') as tag_code,
        substr(tag_full, instr(tag_full, '=')+1) as tag_value,
        rownum as rn
      from (
        select trim(regexp_substr(tags_list1, '[^;]+', 1, level)) as tag_full
        from dual 
        connect by  regexp_substr(tags_list1, '[^;]+', 1, level) is not null
        )
      )
      ,tg2 as (
      select 
        tag_full, 
        NVL(substr(tag_full, 1, instr(tag_full, '=')-1),'__NA__') as tag_code,
        substr(tag_full, instr(tag_full, '=')+1) as tag_value,
        rownum as rn
      from (
        select trim(regexp_substr(tags_list2, '[^;]+', 1, level)) as tag_full
        from dual 
        connect by  regexp_substr(tags_list2, '[^;]+', 1, level) is not null
        )
      )
      --when tag_code from tg1 exsist in tg2
      select 
        1 as gr_rn,
        tg1.rn,
        tg1.tag_code,
        case when tg1.tag_value = tg2.tag_value then tg1.tag_value else tg2.tag_value end tag_value
      from tg1
      join tg2 on tg1.tag_code = tg2.tag_code
      --when tag_code from tg1 NOT exsist in tg2
      union all
      select 
        1 as gr_rn,
        tg1.rn,
        tg1.tag_code, 
        tg1.tag_value
      from tg1
      left join tg2 on tg1.tag_code = tg2.tag_code
      where tg2.tag_code is null
      --when tag_code from tg2 NOT exsist in tg1
      union all
      select 
        2 as gr_rn,
        tg2.rn,
        tg2.tag_code, 
        tg2.tag_value
      from tg2
      left join tg1 on tg1.tag_code = tg2.tag_code
      where tg1.tag_code is null
      order by gr_rn, rn
    ) 
    loop
      if rec.tag_code != '__NA__' then
        tags_merged := tags_merged || rec.tag_code ||'='|| rec.tag_value ||';';
      else
        tags_merged := tags_merged || rec.tag_value ||';';
      end if;
    end loop;
  end if;
  
  return tags_merged;
end;
/
exit;