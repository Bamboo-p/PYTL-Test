/* PyTL_OmniReports_AQ_BIN_Upload/AQ_BIN_Upload_BASE24.sql
240215.1: maksimsk: NIBOA-9198: Initial development
240221.1: maksimsk: NIBOA-9198: added logic for generating BIN records based on Low and High Range
240222.1: maksimsk: NIBOA-9198: input file is uploaded by PyTL_Interfaces into PYTL_INTERFACES_RECORDS, PYTL_INTERFACES_BATCHES
240222.2: maksimsk: NIBOA-9198: added filter "STATUS_CODE = 3" to get only valid records
240223.1: maksimsk: NIBOA-9198: migrated to OWS
240228.1: maksimsk: NIBOA-9198: using STG BD tables
*/
with bin_file as (
select 
   t_batches.ORG                           as ORG
  ,t_batches.input_filename                as INPUT_FILENAME
  ,t_batches.input_datetime                as INPUT_DATETIME
  ,t_batches.INPUT_BATCH_UID               as INPUT_BATCH_UID
  ,t_records.IN_DATA."Bank Name"           as BANK_NAME
  ,t_records.IN_DATA."Institution ID"      as INSTITUTION_ID
  ,t_records.IN_DATA."Low BIN Range"       as LOW_BIN_RANGE
  ,t_records.IN_DATA."High BIN Range"      as HIGH_BIN_RANGE
  ,t_records.IN_DATA."PAN Length"          as PAN_LENGTH
  ,t_records.IN_DATA."Product Type"        as PRODUCT_TYPE
  ,t_records.IN_DATA."Scheme"              as SCHEME
  ,t_records.IN_DATA."Scheme Product"      as SCHEME_PRODUCT
  ,t_records.IN_DATA."Card Type"           as CARD_TYPE
  ,t_records.IN_DATA."Services"            as SERVICES
  ,t_records.IN_DATA."Currency Code"       as CURRENCY_CODE
  ,t_records.IN_DATA."Country Code"        as COUNTRY_CODE
from stg_etl.PYTL_INTERFACES_BATCHES t_batches
join stg_etl.PYTL_INTERFACES_RECORDS t_records on t_records.BATCH_ID = t_batches.UNIQUE_ID
where 1=1
  and t_batches.INPUT_BATCH_UID = :INPUT_BATCH_UID
  and t_batches.ORG = :ORG
  and t_batches.INTERFACE = :INTERFACE
  and t_records.STATUS_CODE = 3  --only valid records
)
, all_items as (
select 
   fl.ORG
  ,fl.BANK_NAME
  ,fl.INSTITUTION_ID
  ,fl.LOW_BIN_RANGE
  ,fl.HIGH_BIN_RANGE
,to_number(case 
    when length(rtrim(fl.LOW_BIN_RANGE, '0')) < length(rtrim(fl.HIGH_BIN_RANGE, '9')) 
        then rpad(rtrim(fl.LOW_BIN_RANGE, '0'), length(rtrim(fl.HIGH_BIN_RANGE, '9')), '0')
    else rtrim(fl.LOW_BIN_RANGE, '0')
end) as start_range
,to_number(case 
    when length(rtrim(fl.LOW_BIN_RANGE, '0')) > length(rtrim(fl.HIGH_BIN_RANGE, '9')) 
        then rpad(rtrim(fl.HIGH_BIN_RANGE, '9'), length(rtrim(fl.LOW_BIN_RANGE, '0')), '9')
    else rtrim(fl.HIGH_BIN_RANGE, '9')
end) as end_range
  ,fl.PAN_LENGTH
from bin_file fl
)
select 
   a.ORG
  ,'Network International' as BANK_NAME
  ,'784111111'             as INSTITUTION_ID
  ,lvls.Column_value       as low_bin_range
  ,a.PAN_LENGTH
  ,'CB'                    as CONST_CB
from all_items a
,table(cast(multiset(
    select (a.start_range + level - 1) 
    from dual 
    connect by (a.start_range + level - 1) <= a.end_range and level <= a.end_range
) as sys.OdciNumberList)) lvls
