/* PyTL_OmniReports_AQ_BIN_Upload/AQ_BIN_Upload_ETL_MC.sql
240304.1: maksimsk: NIBOA-9198: extract first 16 digits of LOW_BIN_RANGE for Mastercard(M)
240319.1: maksimsk: PRD-26767: fixed to extarct first 6 digits of LOW_BIN_RANGE
*/
select 
  substr(t_records.IN_DATA."Low BIN Range",1,6)       as LOW_BIN_RANGE
from stg_etl.PYTL_INTERFACES_BATCHES t_batches
join stg_etl.PYTL_INTERFACES_RECORDS t_records on t_records.BATCH_ID = t_batches.UNIQUE_ID
where 1=1
  and t_batches.INPUT_BATCH_UID = :INPUT_BATCH_UID
  and t_batches.ORG = :ORG
  and t_batches.INTERFACE = :INTERFACE
  and t_records.STATUS_CODE = 3  --only valid records
  and upper(t_records.IN_DATA."Scheme") = 'M'
