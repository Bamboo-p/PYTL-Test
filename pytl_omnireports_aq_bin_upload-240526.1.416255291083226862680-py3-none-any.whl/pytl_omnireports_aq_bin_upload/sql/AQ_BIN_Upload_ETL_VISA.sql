/* PyTL_OmniReports_AQ_BIN_Upload/AQ_BIN_Upload_ETL_VISA.sql
240223.1: maksimsk: NIBOA-9198: Initial development
240228.1: maksimsk: NIBOA-9198: return only LOW_BIN_RANGE for ETL needs
240304.1: maksimsk: NIBOA-9198: extract first 6 characters of LOW_BIN_RANGE
240304.2: maksimsk: NIBOA-9198: extract first 9 digits of LOW_BIN_RANGE for VISA(V)
240319.1: maksimsk: PRD-26767: fixed to extarct first 6 digits of LOW_BIN_RANGE
*/
select 
  substr(t_records.IN_DATA."Low BIN Range",1,6)       as LOW_BIN_RANGE
from stg_etl.PYTL_INTERFACES_BATCHES t_batches
join stg_etl.PYTL_INTERFACES_RECORDS t_records on t_records.BATCH_ID = t_batches.UNIQUE_ID
where 1=1
  and t_batches.INPUT_BATCH_UID = :INPUT_BATCH_UID
  and t_batches.ORG = :ORG
  and t_batches.INTERFACE = :INTERFACE
  and t_records.STATUS_CODE = 3  --only valid records
  and upper(t_records.IN_DATA."Scheme") = 'V'
