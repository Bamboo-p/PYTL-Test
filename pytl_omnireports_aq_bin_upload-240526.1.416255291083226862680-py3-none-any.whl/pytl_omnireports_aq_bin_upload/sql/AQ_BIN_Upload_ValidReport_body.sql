/* PyTL_OmniReports_AQ_BIN_Upload/AQ_BIN_Upload_ValidReport_body.sql
240223.1: maksimsk: NIBOA-9198: Initial development
*/
with bin_file as (
select 
   t_batches.ORG                           as ORG
  ,t_batches.input_filename                as FLNM
  ,t_batches.input_datetime
  ,t_batches.INPUT_BATCH_UID
  ,t_records.STATUS_CODE
  ,t_records.input_recrd_uid
  ,t_records.IN_DATA."Low BIN Range"       as LOW_BIN_RANGE
  ,t_records.IN_DATA."High BIN Range"      as HIGH_BIN_RANGE
  ,regexp_substr(t_records.error_msg, '[^;]+', 1, 1) as error_msg
from stg_etl.PYTL_INTERFACES_BATCHES t_batches
join stg_etl.PYTL_INTERFACES_RECORDS t_records on t_records.BATCH_ID = t_batches.UNIQUE_ID
where 1=1
  and t_batches.INPUT_BATCH_UID = :INPUT_BATCH_UID
  and t_batches.ORG = :ORG
  and t_batches.INTERFACE = :INTERFACE
)
select
   b.ORG                                                    as ORG
  ,to_number(b.input_recrd_uid)                             as LINE
  ,nvl(b.LOW_BIN_RANGE ,' ')                                as LOW_BIN_RANGE
  ,nvl(b.HIGH_BIN_RANGE,' ')                                as HIGH_BIN_RANGE
  ,decode(b.STATUS_CODE,3,'Accepted',-1,'Rejected')         as STATUS
  ,nvl(decode(b.STATUS_CODE,3,'Success' ,-1,b.error_msg), ' ')        as RESPOND_MESSAGE
from bin_file b
order by 2