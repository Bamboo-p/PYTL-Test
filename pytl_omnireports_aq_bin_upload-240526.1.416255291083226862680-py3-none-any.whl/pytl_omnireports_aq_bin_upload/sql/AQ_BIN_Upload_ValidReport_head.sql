/* PyTL_OmniReports_AQ_BIN_Upload/AQ_BIN_Upload_ValidReport_head.sql
240223.1: maksimsk: NIBOA-9198: Initial development
*/
with bin_file as (
select
   t_batches.ORG                           as ORG
  ,t_batches.input_filename                as FLNM
  ,t_batches.input_datetime
from stg_etl.PYTL_INTERFACES_BATCHES t_batches
where 1=1
  and t_batches.INPUT_BATCH_UID = :INPUT_BATCH_UID
  and t_batches.ORG = :ORG
  and t_batches.INTERFACE = :INTERFACE
)
select :ORG as ORG, head 
from (
select rpad(lpad(' ', 54, ' ')||'Central Bank', 200, ' ')                 as head 
from dual
union all
select rpad(lpad(' ', 47, ' ')||'BIN Upload Validation Report', 200, ' ') as head 
from dual
union all
select rpad(' ', 200, ' ')                                                as head 
from dual
union all
select rpad(' FILE_PROCESSED: ' || FLNM, 200, ' ')                        as head 
from bin_file
union all
select rpad(' PROCESS_DATE  : ' || to_char(input_datetime,'dd-mm-yyyy'), 200, ' ') as head 
from bin_file
union all
select rpad(' ', 200, ' ')                                                as head 
from dual
union all
select rpad('-', 200, '-')                                                as head 
from dual
union all
select rpad('LINE   LOW_BIN_RANGE         HIGH_BIN_RANGE        STATUS    REASON_MESSAGE', 200, ' ') as head 
from dual
union all
select rpad('-', 200, '-')                                                as head 
from dual
)