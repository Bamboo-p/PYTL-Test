/* PyTL_OmniReports_AQ_BIN_Upload/AQ_BIN_Upload_WAY4_body.sql
240215.1: maksimsk: NIBOA-9198: Initial development
240215.2: maksimsk: NIBOA-9198: fixed mapping for BIN_DETAILS
240216.1: maksimsk: NIBOA-9198: added function FN_TAG_MERGE for merging tags
240219.1: maksimsk: NIBOA-9198: get matching LOW_BIN_RANGE and start_bin by first 9 chars
240222.1: maksimsk: NIBOA-9198: input file is uploaded by PyTL_Interfaces into PYTL_INTERFACES_RECORDS, PYTL_INTERFACES_BATCHES
240222.2: maksimsk: NIBOA-9198: added filter "STATUS_CODE = 3" to get only valid records
240222.3: maksimsk: NIBOA-9198: changed mapping for BIN_DETAILS and CHANNEL for new BIN
240223.1: maksimsk: NIBOA-9198: migrated to OWS
240223.2: maksimsk: NIBOA-9198: renamed CUST_ACQ_UTILS to OPT_ACQ_UTILS
240226.1: maksimsk: NIBOA-9198: added filter to exclude ATM BIN records
240228.1: maksimsk: NIBOA-9198: using STG DB tables
240303.1: maksimsk: NIBOA-9198: added tag 'CBUAE;' for updating BIN record
240304.1: maksimsk: NIBOA-9198: extract first 6 characters of LOW_BIN_RANGE
240304.2: maksimsk: NIBOA-9198: matching first 9 digits of LOW_BIN_RANGE for VISA(V), first 16 digits of LOW_BIN_RANGE for MC(M), and for PL(P) considered as new BIN
240319.1: maksimsk: PRD-26767: fixed to match first 6 digits of LOW_BIN_RANGE for both VISA and MC
240503.1: maksimsk: NIBOA-10016: incorporated JAYWAN BIN records and added variable P_BIN_GROUP
240510.1: maksimsk: NIBOA-10016: fixed populating of USAGE
240526.1: HamzaHendi: NIBOA-10208: mapping country column for new bins from file for ARE only
*/
with bin_file as (
select 
   t_batches.ORG                           as ORG
  ,t_batches.input_filename                as INPUT_FILENAME
  ,t_batches.input_datetime                as INPUT_DATETIME
  ,t_batches.INPUT_BATCH_UID               as INPUT_BATCH_UID
  ,t_records.IN_DATA."Bank Name"           as BANK_NAME
  ,t_records.IN_DATA."Institution ID"      as INSTITUTION_ID
  ,t_records.IN_DATA."Low BIN Range"       as LOW_BIN_RANGE
  ,t_records.IN_DATA."High BIN Range"      as HIGH_BIN_RANGE
  ,t_records.IN_DATA."PAN Length"          as PAN_LENGTH
  ,t_records.IN_DATA."Product Type"        as PRODUCT_TYPE
  ,t_records.IN_DATA."Scheme"              as SCHEME
  ,t_records.IN_DATA."Scheme Product"      as SCHEME_PRODUCT
  ,t_records.IN_DATA."Card Type"           as CARD_TYPE
  ,t_records.IN_DATA."Services"            as SERVICES
  ,t_records.IN_DATA."Currency Code"       as CURRENCY_CODE
  ,t_records.IN_DATA."Country Code"        as COUNTRY_CODE
  ,t_records.IN_DATA."Product Type"        as USAGE
from stg_etl.PYTL_INTERFACES_BATCHES t_batches
join stg_etl.PYTL_INTERFACES_RECORDS t_records on t_records.BATCH_ID = t_batches.UNIQUE_ID
where 1=1
  and t_batches.INPUT_BATCH_UID = :INPUT_BATCH_UID
  and t_batches.ORG = :ORG
  and t_batches.INTERFACE = :INTERFACE
  and t_records.STATUS_CODE = 3  --only valid records
)
, bin_way4 as (
select 
   b.ID
  ,b.MEMBER_ID
  ,b.START_BIN
  ,b.END_BIN
  ,b.START_BIN_4
  ,b.PAN_LENGTH
  ,b.BIN_CONDITION
  ,b.CARD_BRAND
  ,b.CARD_ORG
  ,b.CARD_TECHNOLOGY
  ,b.CDV_ALGORITHM
  ,b.CHANNEL
  ,b.COUNTRY
  ,b.DATA_SOURCE
  ,b.EC_ATM_TYPE
  ,b.FORWARDING_ID
  ,b.ICA_NUMBER
  ,b.PROCESSING_CLASS
  ,b.PRODUCT_ID
  ,b.LICENSED_PRODUCT_ID
  ,b.PRODUCT_CATEGORY
  ,b.REGION_FOR_ISSUER
  ,b.SERVICE_INDICATOR
  ,b.TERMINAL_CATEGORY
  ,b.USAGE
  ,b.USAGE_DOMAIN
  ,b.BIN_STATUS
  ,b.BIN_DETAILS
from stg_etl.PYTL_AQ_BIN_UPLOAD_DATA b
where 1=1
  and b.INPUT_BATCH_UID = :INPUT_BATCH_UID
  and b.ORG = :ORG
)
, all_items as (
--MASTERCARD BIN RECORDS (matching by first 6 bytes of LOW_BIN_RANGE)
select 
   fl.ORG
  ,'CBUAESW'                 as BIN_GROUP
  ,fl.BANK_NAME
  ,fl.INSTITUTION_ID
  ,fl.LOW_BIN_RANGE
  ,fl.HIGH_BIN_RANGE
  ,fl.PAN_LENGTH             as PAN_LEN
  ,fl.PRODUCT_TYPE
  ,fl.SCHEME
  ,fl.SCHEME_PRODUCT
  ,fl.CARD_TYPE
  ,fl.SERVICES
  ,fl.CURRENCY_CODE
  ,fl.COUNTRY_CODE
  ,bins.ID
  ,bins.MEMBER_ID
  ,bins.START_BIN
  ,bins.END_BIN
  ,bins.START_BIN_4
  ,bins.PAN_LENGTH
  ,bins.BIN_CONDITION
  ,bins.CARD_BRAND
  ,bins.CARD_ORG
  ,bins.CARD_TECHNOLOGY
  ,bins.CDV_ALGORITHM
  ,bins.CHANNEL
  ,bins.COUNTRY
  ,bins.DATA_SOURCE
  ,bins.EC_ATM_TYPE
  ,bins.FORWARDING_ID
  ,bins.ICA_NUMBER
  ,bins.PROCESSING_CLASS
  ,bins.PRODUCT_ID
  ,bins.LICENSED_PRODUCT_ID
  ,bins.PRODUCT_CATEGORY
  ,bins.REGION_FOR_ISSUER
  ,bins.SERVICE_INDICATOR
  ,bins.TERMINAL_CATEGORY
  ,NVL(fl.USAGE,bins.USAGE)  as USAGE
  ,bins.USAGE_DOMAIN
  ,bins.BIN_STATUS
  ,bins.BIN_DETAILS
from bin_file fl
left join bin_way4 bins 
on substr(bins.start_bin,1,6) = substr(fl.LOW_BIN_RANGE,1,6)
and upper(bins.CHANNEL) = 'E'
where upper(fl.SCHEME) = 'M'

UNION ALL
--VISA BIN RECORDS (matching by first 6 bytes of LOW_BIN_RANGE)
select 
   fl.ORG
  ,'CBUAESW'                 as BIN_GROUP
  ,fl.BANK_NAME
  ,fl.INSTITUTION_ID
  ,fl.LOW_BIN_RANGE
  ,fl.HIGH_BIN_RANGE
  ,fl.PAN_LENGTH             as PAN_LEN
  ,fl.PRODUCT_TYPE
  ,fl.SCHEME
  ,fl.SCHEME_PRODUCT
  ,fl.CARD_TYPE
  ,fl.SERVICES
  ,fl.CURRENCY_CODE
  ,fl.COUNTRY_CODE
  ,bins.ID
  ,bins.MEMBER_ID
  ,bins.START_BIN
  ,bins.END_BIN
  ,bins.START_BIN_4
  ,bins.PAN_LENGTH
  ,bins.BIN_CONDITION
  ,bins.CARD_BRAND
  ,bins.CARD_ORG
  ,bins.CARD_TECHNOLOGY
  ,bins.CDV_ALGORITHM
  ,bins.CHANNEL
  ,bins.COUNTRY
  ,bins.DATA_SOURCE
  ,bins.EC_ATM_TYPE
  ,bins.FORWARDING_ID
  ,bins.ICA_NUMBER
  ,bins.PROCESSING_CLASS
  ,bins.PRODUCT_ID
  ,bins.LICENSED_PRODUCT_ID
  ,bins.PRODUCT_CATEGORY
  ,bins.REGION_FOR_ISSUER
  ,bins.SERVICE_INDICATOR
  ,bins.TERMINAL_CATEGORY
  ,NVL(fl.USAGE,bins.USAGE)  as USAGE
  ,bins.USAGE_DOMAIN
  ,bins.BIN_STATUS
  ,bins.BIN_DETAILS
from bin_file fl
left join bin_way4 bins 
on substr(bins.start_bin, 1, 6) = substr(fl.LOW_BIN_RANGE, 1, 6)
and upper(bins.CHANNEL) = 'V'
where upper(fl.SCHEME) = 'V'

UNION ALL
--PRIVATE LABEL BIN RECORDS (always as new BIN)
select 
   fl.ORG
  ,'CBUAESW'                 as BIN_GROUP
  ,fl.BANK_NAME
  ,fl.INSTITUTION_ID
  ,fl.LOW_BIN_RANGE
  ,fl.HIGH_BIN_RANGE
  ,fl.PAN_LENGTH             as PAN_LEN
  ,fl.PRODUCT_TYPE
  ,fl.SCHEME
  ,fl.SCHEME_PRODUCT
  ,fl.CARD_TYPE
  ,fl.SERVICES
  ,fl.CURRENCY_CODE
  ,fl.COUNTRY_CODE
  ,NULL as ID
  ,NULL as MEMBER_ID
  ,NULL as START_BIN
  ,NULL as END_BIN
  ,NULL as START_BIN_4
  ,NULL as PAN_LENGTH
  ,NULL as BIN_CONDITION
  ,NULL as CARD_BRAND
  ,NULL as CARD_ORG
  ,NULL as CARD_TECHNOLOGY
  ,NULL as CDV_ALGORITHM
  ,NULL as CHANNEL
  ,NULL as COUNTRY
  ,NULL as DATA_SOURCE
  ,NULL as EC_ATM_TYPE
  ,NULL as FORWARDING_ID
  ,NULL as ICA_NUMBER
  ,NULL as PROCESSING_CLASS
  ,NULL as PRODUCT_ID
  ,NULL as LICENSED_PRODUCT_ID
  ,NULL as PRODUCT_CATEGORY
  ,NULL as REGION_FOR_ISSUER
  ,NULL as SERVICE_INDICATOR
  ,NULL as TERMINAL_CATEGORY
  ,fl.USAGE as USAGE
  ,NULL as USAGE_DOMAIN
  ,NULL as BIN_STATUS
  ,NULL as BIN_DETAILS
from bin_file fl
where fl.SCHEME = 'P'

UNION ALL
--JAYWAN BIN RECORDS (matching by first 6 bytes of LOW_BIN_RANGE)
select 
   fl.ORG
  ,'JAYWANC'                 as BIN_GROUP
  ,fl.BANK_NAME
  ,fl.INSTITUTION_ID
  ,fl.LOW_BIN_RANGE
  ,fl.HIGH_BIN_RANGE
  ,fl.PAN_LENGTH             as PAN_LEN
  ,fl.PRODUCT_TYPE
  ,fl.SCHEME
  ,fl.SCHEME_PRODUCT
  ,fl.CARD_TYPE
  ,fl.SERVICES
  ,fl.CURRENCY_CODE
  ,fl.COUNTRY_CODE
  ,bins.ID
  ,bins.MEMBER_ID
  ,bins.START_BIN
  ,bins.END_BIN
  ,bins.START_BIN_4
  ,bins.PAN_LENGTH
  ,bins.BIN_CONDITION
  ,bins.CARD_BRAND
  ,bins.CARD_ORG
  ,bins.CARD_TECHNOLOGY
  ,bins.CDV_ALGORITHM
  ,bins.CHANNEL
  ,bins.COUNTRY
  ,bins.DATA_SOURCE
  ,bins.EC_ATM_TYPE
  ,bins.FORWARDING_ID
  ,bins.ICA_NUMBER
  ,bins.PROCESSING_CLASS
  ,bins.PRODUCT_ID
  ,bins.LICENSED_PRODUCT_ID
  ,bins.PRODUCT_CATEGORY
  ,bins.REGION_FOR_ISSUER
  ,bins.SERVICE_INDICATOR
  ,bins.TERMINAL_CATEGORY
  ,NVL(fl.USAGE,bins.USAGE)  as USAGE
  ,bins.USAGE_DOMAIN
  ,bins.BIN_STATUS
  ,bins.BIN_DETAILS
from bin_file fl
left join bin_way4 bins 
on substr(bins.start_bin, 1, 6) = substr(fl.LOW_BIN_RANGE, 1, 6)
and upper(bins.CHANNEL) = 'JAYWAN'
where upper(fl.SCHEME) = 'J'
)
/* BIN exists */
select 
   ORG
  ,'EXISTS'                      as BIN_FLAG
  ,BANK_NAME
  ,MEMBER_ID
  ,START_BIN
  ,END_BIN
  ,START_BIN_4
  ,to_char(PAN_LENGTH)           as PAN_LENGTH
  ,BIN_CONDITION
  ,stg_etl.FN_TAG_MERGE(BIN_DETAILS, 
    decode(INSTITUTION_ID, NULL, '', 'ISS_INST_ID='||INSTITUTION_ID||';') ||
    decode(CHANNEL, 'V', 'COLL_BRAND=VISA;', 'E', 'COLL_BRAND=MC;', '') ||
    decode(SCHEME, NULL, '', 'SCHEME='||SCHEME||';') ||
    decode(CARD_TYPE, NULL, '', 'CARD_TYPE='||CARD_TYPE||';') ||
    decode(SERVICES, NULL, '', 'SERVICES='||SERVICES||';') ||
    decode(CURRENCY_CODE, NULL, '', 'CURRENCY_CODE='||CURRENCY_CODE||';') ||
    decode(COUNTRY_CODE, NULL, '', 'COUNTRY_CODE='||COUNTRY_CODE||';') ||
    'CBUAE;'
  )                              as BIN_DETAILS
  ,CARD_BRAND
  ,CARD_ORG
  ,CARD_TECHNOLOGY
  ,CDV_ALGORITHM
  ,CHANNEL
  ,COUNTRY
  ,'O'                           as DATA_SOURCE
  ,EC_ATM_TYPE
  ,FORWARDING_ID
  ,ICA_NUMBER
  ,PROCESSING_CLASS
  ,PRODUCT_ID
  ,LICENSED_PRODUCT_ID
  ,PRODUCT_CATEGORY
  ,REGION_FOR_ISSUER
  ,SERVICE_INDICATOR
  ,TERMINAL_CATEGORY
  ,USAGE
  ,USAGE_DOMAIN
  ,'A'                           as BIN_STATUS
from all_items
where ID is not null
  AND BIN_GROUP = :P_BIN_GROUP

UNION ALL

/* BIN new */
select 
   ORG
  ,'NEW'                         as BIN_FLAG
  ,BANK_NAME
  ,substr(LOW_BIN_RANGE, 1, 6)   as MEMBER_ID
  ,LOW_BIN_RANGE                 as START_BIN
  ,HIGH_BIN_RANGE                as END_BIN
  ,substr(LOW_BIN_RANGE, 1, 6)   as START_BIN_4
  ,PAN_LEN                       as PAN_LENGTH
  ,''                            as BIN_CONDITION
  ,(
    'COLL_BRAND=PL;' ||
    decode(INSTITUTION_ID, NULL, '', 'ISS_INST_ID='||INSTITUTION_ID||';') ||
    decode(SCHEME, NULL, '', 'SCHEME='||SCHEME||';') ||
    decode(CARD_TYPE, NULL, '', 'CARD_TYPE='||CARD_TYPE||';') ||
    decode(SERVICES, NULL, '', 'SERVICES='||SERVICES||';') ||
    decode(CURRENCY_CODE, NULL, '', 'CURRENCY_CODE='||CURRENCY_CODE||';') ||
    decode(COUNTRY_CODE, NULL, '', 'COUNTRY_CODE='||COUNTRY_CODE||';') ||
    'CBUAE;'
  )                              as BIN_DETAILS
  ,'PL'                          as CARD_BRAND
  ,''                            as CARD_ORG
  ,''                            as CARD_TECHNOLOGY
  ,''                            as CDV_ALGORITHM
  ,'O'                           as CHANNEL
  ,decode(COUNTRY_CODE,
          '784','ARE'
          ,'')                   as COUNTRY
  ,'O'                           as DATA_SOURCE
  ,''                            as EC_ATM_TYPE
  ,''                            as FORWARDING_ID
  ,''                            as ICA_NUMBER
  ,''                            as PROCESSING_CLASS
  ,'PRIVATE'                     as PRODUCT_ID
  ,''                            as LICENSED_PRODUCT_ID
  ,''                            as PRODUCT_CATEGORY
  ,''                            as REGION_FOR_ISSUER
  ,''                            as SERVICE_INDICATOR
  ,'P'                           as TERMINAL_CATEGORY
  ,USAGE                         as USAGE
  ,''                            as USAGE_DOMAIN
  ,'A'                           as BIN_STATUS
from all_items
where ID is null
  AND BIN_GROUP = :P_BIN_GROUP
