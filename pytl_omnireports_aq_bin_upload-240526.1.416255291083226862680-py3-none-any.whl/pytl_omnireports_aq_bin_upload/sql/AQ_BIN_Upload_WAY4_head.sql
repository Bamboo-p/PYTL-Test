/* PyTL_OmniReports_AQ_BIN_Upload/AQ_BIN_Upload_WAY4_head.sql
240215.1: maksimsk: NIBOA-9198: Initial development
240215.3: maksimsk: NIBOA-9198: fixed sequence number
240219.1: maksimsk: NIBOA-9198: set TYPE_IND to 'INCREMENTAL'
240503.1: maksimsk: NIBOA-10016: added variables P_SENDER and P_BIN_GROUP
*/
select 
   :ORG                          as ORG
  ,'BINTABLE'                    as FILE_LABEL
  ,'1.0'                         as FORMAT_VERSION
  ,:P_SENDER                     as SENDER
  ,to_char(sysdate,'yyyy-mm-dd') as CREATION_DATE
  ,to_char(sysdate,'hh24:mi:ss') as CREATION_TIME
  ,:P_SEQUENCE_NUMBER            as SEQUENCE_NUMBER
  ,'NI'                          as RECEIVER
  ,'INCREMENTAL'                 as TYPE_IND
  ,:P_BIN_GROUP                  as BIN_GROUP
from dual