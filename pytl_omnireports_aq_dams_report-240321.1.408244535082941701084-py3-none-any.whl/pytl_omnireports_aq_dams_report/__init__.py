__version__ = "240321.1"
__job_name__ = "PyTL_OmniReports_AQ_DAMS_REPORT"
__bat_files__ = ["PyTL_OmniReports_AQ_DAMS_REPORT.bat"]
