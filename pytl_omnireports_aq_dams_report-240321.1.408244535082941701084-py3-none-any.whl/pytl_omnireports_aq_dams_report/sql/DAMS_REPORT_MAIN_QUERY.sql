/* PyTL_OmniReports_AQ_DAMS_REPORT/DAMS_REPORT_MAIN_QUERY.sql
231208.1: maksimsk: SBA-1385: Initial development
240207.1: maksimsk: SBA-1443: fixed alignment "EMAIL" label for both files, fixed alignment delivery_type and "VAT ON COMM" for MS file
240207.2: maksimsk: SBA-1443: fixed PROC DATE to be filled with YYYY in MS header
*/
with all_items as (
select
  org
  ,settlement_date
  ,record_type
  ,report_id
  ,doc_idt
  ,fraud_flag
  ,merchant
  ,merchant_idt
  ,dtoftrn
  ,trns_time
  ,trmnl_id
  ,sequence_number
  ,card_number
  ,type
  ,acq_ref_num
  ,auth_code
  ,case 
    when code = 'CASHBACK'
      then
        trn_amnt - (tcashback_amount/100)
    when type = 'PWCB_CASHBACK'
      then 
        tcashback_amount/100
    else 
        trn_amnt 
  end                                       as trn_amnt
  ,disc_type
  ,uniqueid
  ,code
  ,code_ori
  ,operation_type_code
  ,debit
  ,credit
  ,sttl_type
  ,tcashback_amount
  ,comm_code
  ,payment_scheme_code
  ,trans_arn
  ,posting_status
  ,dept_code
  ,original_dept_code
  ,tde
  ,ident_number
  ,delivery_type
  ,phone
  ,fax
  ,address_line_1
  ,address_line_2
  ,address_line_3
  ,address_line_4
  ,location
  ,e_mail
  ,inst_name
  ,net_settl
  ,case 
    when code in (
      'RETAIL'
      ,'REFUND_REV'
      ,'DCC_RETAIL'
      ,'CASH'
      ,'CASHBACK'
      ,'M_CR_ADJ_DCC'
      ,'CR_CBK_ADJ_DCC'
    ) then 
        'SALES'
    when code in (
      'REFUND'
      ,'RETAIL_REV'
      ,'DCC_CREDIT'
      ,'CASH_REV'
      ,'M_DT_ADJ_DCC'
      ,'DB_CBK_ADJ_DCC'
    ) then 
        'REFUND'
    when code = 'PWCB_CASHBACK' 
      then 
        'CASH(PWCB)'
    when type = 'COMMISSION'
      then 
        'COMMISSION'
    when comm_code = 'TRAN FEE' 
      then 
        'TRANS_FEE'
    when code in (
      'STARTUP_FEE'
      ,'STATEMENT_FEE'
      ,'SETUP_FEE'
      ,'COF'
      ,'STATIONARY_FEE'
      ,'VAT_ON_FEE'
      ,'FEE_CR_ADJ'
      ,'FEE_DT_ADJ'
      ,'MISC_DT_ADJ'
      ,'MISC_CR_ADJ'
      ,'FRAUD_FEE'
      ,'BULK_RENT_FEE'
    ) then 
        'MISC AMT'
    else 
        code
  end                                       as type_group
from OWS.OPT_ACQ_DAMS_DATA
where 1=1
  and org = :ORG
  and settlement_date = to_date(:P_REPORT_DATE, 'dd-mm-yyyy')
  and report_id in ('BOTH')
  and record_type in (
     'TRANS'
    ,'PWCB'
    ,'FRAUD'
    ,'COMM'
  )
)
, headers as (
select *
from (
  select 
    org
    ,merchant
    ,upper(inst_name)                         as inst_name
    ,nvl(address_line_1,' ')                  as address_line_1
    ,nvl(address_line_2,' ')                  as address_line_2
    ,nvl(address_line_3,' ')                  as address_line_3
    ,rpad(address_line_4,20,' ')
     || rpad(location,20,' ')                 as address_line_4
    ,nvl(location,' ')                        as address_line_5
    ,nvl(e_mail,' ')                          as e_mail
    ,nvl(phone,' ')                           as phone
    ,nvl(fax,' ')                             as fax
    ,null                                     as agent_code
    ,delivery_type
    ,nvl(ident_number,'00000000')             as ident_number
    ,settlement_date
    ,row_number() over(partition by org, merchant 
       order by org, merchant
     )                                        as rn
  from all_items
  )
where rn = 1
)
, totals as (
select
  merchant
  ,org
  ,sum(
    case
      when code IN (
         'RETAIL'
        ,'RETAIL_REV'
        ,'REFUND'
        ,'REFUND_REV'
        ,'CASHBACK'
        ,'CASHBACK_REV'
        ,'CASH'
        ,'CASH_REV'
        ,'DCC_RETAIL'
        ,'DCC_CREDIT'
        ,'M_CR_ADJ_DCC'
        ,'M_DT_ADJ_DCC'
        ,'CR_CBK_ADJ_DCC'
        ,'DB_CBK_ADJ_DCC'
        ,'DCC_RETAIL_REV'
        ,'DCC_CREDIT_REV'
        )
        then trn_amnt
      else   0
    end
  )                                         as total_pos
  ,sum(
    case 
      when code IN (
        'RETAIL'
       ,'RETAIL_REV'
       ,'REFUND'
       ,'REFUND_REV'
       ,'CASHBACK'
       ,'CASHBACK_REV'
       ,'CASH'
       ,'CASH_REV'
       ,'DCC_RETAIL'
       ,'DCC_CREDIT'
       ,'M_CR_ADJ_DCC'
       ,'M_DT_ADJ_DCC'
       ,'CR_CBK_ADJ_DCC'
       ,'DB_CBK_ADJ_DCC'
       ,'DCC_RETAIL_REV'
       ,'DCC_CREDIT_REV'
       )
        then 1
      else   0
    end
  )                                         as total_num_pos
  ,sum(
    case 
      when type IN (
        'COMMISSION'
        ,'MIN COMM ADJ'
        ,'VAT COMM'
        ) 
        then trn_amnt
      else   0
    end
  )                                         as total_comm
  ,sum(
    case
      when code IN (
        'COF'
        ,'STATIONARY_FEE'
        ,'GPRS_SIM_FEE'
        ,'GPRS_U_FEE'
        ,'TERMINAL_RENT_FEE'
        ,'INS_FEE'
        ,'MMF'
        ,'DT_SUBV_ADJ'
        ,'CR_SUBV_ADJ'
        ,'COMMISSION'
        ,'COMMISSION_REV'
        ,'FEE_DT_ADJ'
        ,'FEE_CR_ADJ'
        ,'MISC_CR_ADJ'
        ,'MISC_DT_ADJ'
        ,'M_CR_ADJ'
        ,'M_DT_ADJ'
        ,'M_CR_ADJ'
        ,'M_DT_ADJ'
        ,'STARTUP_FEE'
        ,'STATEMENT_FEE'
        ,'CB_FEE'
        ,'BULK_RENT_FEE'
        ,'SETUP_FEE'
        ,'FRAUD_FEE'
        ,'VAT_ON_FEE'
        ) 
        or type in (
        'TRAN FEE'
        ,'VAT ON FEE'
        ) 
        then trn_amnt
      else   0
    end
  )                                         as total_fee
  ,sum(
    case
      when code IN (
        'DB_CBK_ADJ'
        ,'CR_CBK_ADJ'
        ) 
        then trn_amnt
      else   0 
    end
  )                                         as total_cbk
  ,sum(
    case 
      when code IN (
        'FRD_CR_ADJ'
        ,'FRD_DB_ADJ'
        )  
        then trn_amnt
      else   0
    end
  )                                         as total_fraud
  ,sum(
    case
      when type IN ('PWCB-CASHBACK')
        then to_number(tcashback_amount)/100
      else   0
    end
  )                                         as total_cash
  ,sum(
    case 
      when type IN ('REBATE FEE')
        then trn_amnt
      else   0
    end
  )                                         as total_rebate
  ,sum(
    case 
      when code IN ('FRD_DB_ADJ')
        then trn_amnt
      else   0
    end
  )                                         as susp_hold
  ,sum(
    case 
      when code IN ('FRD_CR_ADJ')
        then trn_amnt
      else   0
    end
  )                                         as susp_rel
  ,sum(
    case 
      when code IN ('CR_CBK_ADJ')
        then trn_amnt
      else   0
    end
  )                                         as chbk_cr
  ,sum(
    case 
      when code IN ('DB_CBK_ADJ')
        then trn_amnt
      else   0
    end
  )                                         as chbk_db
  ,sum(
    case 
      when code IN ('CB_FEE')
        then trn_amnt
      else   0
    end
  )                                         as cb_fee
  ,sum(
    case 
      when type_group IN ('TRANS_FEE')
        then trn_amnt
      else   0
    end
  )                                         as tran_fee
  ,sum(
    case 
      when code IN (
         'GPRS_SIM_FEE'
        ,'GPRS_U_FEE'
        )
        then trn_amnt
      else   0
    end
  )                                         as gprs
  ,sum(
    case 
      when code IN ('TRANINS_FEES_FEE')
        then trn_amnt
      else   0
    end
  )                                         as insur
  ,sum(
    case 
      when code IN ('TERMINAL_RENT_FEE')
        then trn_amnt
      else   0
    end
  )                                         as term
  ,sum(
    case 
      when code IN ('MMF')
        then trn_amnt
      else   0
    end
  )                                         as mmf
  ,sum(
    case 
      when code IN ('M_DT_ADJ')
        then trn_amnt
      else   0
    end
  )                                         as m_db
  ,sum(
    case 
      when code IN ('M_CR_ADJ')
        then trn_amnt
      else   0
    end
  )                                         as m_cr
  ,sum(
    case 
      when code IN (
         'STARTUP_FEE'
        ,'STATEMENT_FEE'
        ,'SETUP_FEE'
        ,'COF'
        ,'STATIONARY_FEE'
        ,'VAT_ON_FEE'
        ,'FEE_CR_ADJ'
        ,'FEE_DT_ADJ'
        ,'MISC_DT_ADJ'
        ,'MISC_CR_ADJ'
        ,'FRAUD_FEE'
        ,'BULK_RENT_FEE'
        )
        then trn_amnt
      else   0
    end
  )                                         as misc
  ,sum(
    case 
      when code IN ('MIN_COMM_ADJ')
        then trn_amnt
      else   0
    end
  )                                         as min_comm
  ,sum(
    case 
      when code IN ('REBATE_FEE')
        then trn_amnt
      else   0
    end
  )                                         as rebate
  ,sum(
    case 
      when type_group IN ('VAT')
        then trn_amnt
      else   0
    end
  )                                         as vat_comm
  ,sum(
    case 
      when type_group IN (
         'SALES'
        ,'REFUND'
        ,'CASH(PWCB)'
        ,'COMMISSION'
        )
          and payment_scheme_code = 'V'
        then trn_amnt
      else   0
    end
  )                                         as total_visa
  ,sum(
    case 
      when type_group IN (
         'SALES'
        ,'REFUND'
        ,'CASH(PWCB)'
        )
          and payment_scheme_code = 'V'
        then 1
      else   0
    end
  )                                         as total_visa_cnt
  ,sum(
    case 
      when type_group IN (
         'SALES'
        ,'REFUND'
        ,'CASH(PWCB)'
        ,'COMMISSION'
        )
          and payment_scheme_code in ('E','ME')
        then trn_amnt
      else   0
    end
  )                                         as total_mc
  ,sum(
    case 
      when type_group IN (
         'SALES'
        ,'REFUND'
        ,'CASH(PWCB)'
        )
          and payment_scheme_code in ('E','ME')
        then 1
      else   0
    end
  )                                         as total_mc_cnt
  ,sum(
    case 
      when type_group IN (
         'SALES'
        ,'REFUND'
        ,'CASH(PWCB)'
        ,'COMMISSION'
        )
          and payment_scheme_code = 'C'
        then trn_amnt
      else   0
    end
  )                                         as total_din
  ,sum(
    case 
      when type_group IN (
         'SALES'
        ,'REFUND'
        ,'CASH(PWCB)'
        )
          and payment_scheme_code = 'C'
        then 1
      else   0
    end
  )                                         as total_din_cnt
  ,sum(
    case 
      when type_group IN (
         'SALES'
        ,'REFUND'
        ,'CASH(PWCB)'
        ,'COMMISSION'
        )
          and payment_scheme_code = 'O'
        then trn_amnt
      else   0
    end
  )                                         as total_pl
  ,sum(
    case 
      when type_group IN (
         'SALES'
        ,'REFUND'
        ,'CASH(PWCB)'
        )
          and payment_scheme_code = 'O'
        then 1
      else   0
    end
  )                                         as total_pl_cnt
  ,sum(
    case 
      when type_group IN (
         'SALES'
        ,'REFUND'
        ,'CASH(PWCB)'
        ,'COMMISSION'
        )
          and payment_scheme_code = 'H'
        then trn_amnt
      else   0
    end
  )                                         as total_cup
  ,sum(
    case 
      when type_group IN (
         'SALES'
        ,'REFUND'
        ,'CASH(PWCB)'
        )
          and payment_scheme_code = 'H'
        then 1
      else   0
    end
  )                                         as total_cup_cnt
  ,sum(trn_amnt)                            as total_sum
  ,sum(
    case 
      when code IN (
         'RETAIL'
        ,'RETAIL_REV'
        ,'REFUND'
        ,'REFUND_REV'
        ,'CASHBACK'
        ,'CASHBACK_REV'
        ,'CASH'
        ,'CASH_REV'
        ,'DCC_RETAIL'
        ,'DCC_CREDIT'
        ,'M_CR_ADJ_DCC'
        ,'M_DT_ADJ_DCC'
        ,'CR_CBK_ADJ_DCC'
        ,'DB_CBK_ADJ_DCC'
        ,'DCC_RETAIL_REV'
        ,'DCC_CREDIT_REV'
        )
        then 1
      else 0 
    end
  )                                         as total_cnt
from all_items
group by 
   merchant
  ,org
)
, pay_sch_records as (
select 
   org
  ,merchant
  ,type_group
  ,sum(
    decode(payment_scheme_code,'V',trn_amnt,0)
   )                                        as visa_sum
  ,sum(
    decode(payment_scheme_code,'V', 1,0)
   )                                        as visa_cnt
  ,sum(
    decode(payment_scheme_code,'E',trn_amnt,'ME',trn_amnt,0)
   )                                        as mc_sum
  ,sum(
    decode(payment_scheme_code,'E', 1,'ME',1,0)
   )                                        as mc_cnt
  ,sum(
    decode(payment_scheme_code,'C',trn_amnt,0)
   )                                        as din_sum
  ,sum(
    decode(payment_scheme_code,'C', 1,0)
   )                                        as din_cnt
  ,sum(
    decode(payment_scheme_code,'O',trn_amnt,0)
   )                                        as pl_sum
  ,sum(
    decode(payment_scheme_code,'O', 1,0)
   )                                        as pl_cnt
  ,sum(
    decode(payment_scheme_code,'H',trn_amnt,0)
   )                                        as cup_sum
  ,sum(
    decode(payment_scheme_code,'H', 1,0)
   )                                        as cup_cnt
  ,sum(nvl(trn_amnt,0))                     as total_sum
  ,count(1)                                 as total_cnt
from all_items
where type_group in (
  'SALES'
  ,'REFUND'
  ,'CASH(PWCB)'
  ,'COMMISSION'
)
group by 
    org
   ,merchant
   ,type_group
)
-----------------------DAILY ACTIVITY-------------------------
, da_report as (
  ------------------------------------------------------------
  -- Report Header (10)
  ------------------------------------------------------------
  select * from (
    select
       hd.org
      ,hd.merchant
      ,substr(
       lpad(' ',round((132 - length(hd.inst_name)) / 2),' ') 
       || hd.inst_name|| lpad(' ', 132, ' ')
       ,1,132)                                  as record_data
      ,10                                       as record_id
      ,10                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,(lpad(' ',51,' ') || rpad('MERCHANT TRANSACTION ACTIVITY', 68, ' ') || 'PAGE'
       || lpad(row_number() over(partition by hd.org order by hd.merchant),9,' ')
       )                                        as record_data
      ,20                                       as record_id
      ,10                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,lpad('COMPUTERISED FAX/EMAIL     (', 83, ' ') || hd.delivery_type
       || ')            PROC DATE '
       || to_char(sysdate, 'DD/MM/YY') ||'    TIME '
       || to_char(systimestamp, 'HH.MI.SS')     as record_data
      ,30                                       as record_id
      ,10                                       as section_id
    from headers hd
  )
  
  UNION ALL 
  
  ------------------------------------------------------------
  -- Merchant Demographic Records (20)
  ------------------------------------------------------------
  select * from (
    select
       hd.org
      ,hd.merchant
      ,rpad(
        '  MERCHANT NO :  ' || rpad(merchant, 95, ' ')
        || 'AGENT CODE ' 
        || nvl(hd.agent_code,'00000')
        ,132,' ')                               as record_data
      ,10                                       as record_id
      ,20                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,rpad(
        '  ADDRESS     :  ' || rpad(coalesce(hd.address_line_1, 'NA'),92,' ')
        || 'PHONE '
        || nvl(hd.phone,'NA')
        ,132,' ')                               as record_data
      ,20                                       as record_id
      ,20                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,rpad(
        lpad(' ', 17, ' ') || rpad(coalesce(address_line_2, 'NA'),92,' ')
        || 'FAX   '
        || coalesce(hd.fax,'NA')
        ,132,' ')                               as record_data
      ,30                                       as record_id
      ,20                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,rpad(
        lpad(' ', 17, ' ') || coalesce(hd.address_line_3, 'NA')
       ,132,' ')                                as record_data
      ,40                                       as record_id
      ,20                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,rpad(
        lpad(' ', 17, ' ') || coalesce(hd.address_line_4, 'NA')
        ,132,' ')                               as record_data
      ,50                                       as record_id
      ,20                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,rpad(
        '  EMAIL :' || coalesce(hd.e_mail, 'NA')
        ,132,' ')                               as record_data
      ,60                                       as record_id
      ,20                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,rpad(
        '  CHAIN ID    :  ' || rpad(hd.ident_number,24,' ')
        || 'MERCHANT TRANSACTIONS SETTLED ON '
        || rpad(to_char(hd.settlement_date - 1,'DD/MM/YYYY'), 41, ' ')
        || rpad('MBU989_1', 9,' ')
        ,132,' ')                               as record_data
      ,70                                       as record_id
      ,20                                       as section_id
    from headers hd
  )
  
  UNION ALL
  
  ------------------------------------------------------------
  -- Transaction Header (30)
  ------------------------------------------------------------
  select  * from (
    select
       hd.org
      ,hd.merchant
      ,lpad('-',132,'-')                        as record_data
      ,10                                       as record_id
      ,30                                       as section_id
    from headers hd
    UNION ALL
    select
       hd.org
      ,hd.merchant
      ,'DTOF   TRAN    TRMNL    SEQUENCE     CARD NUMBER   TYPE             '
       || 'ACQ REF NBR            AUTH     TRAN       DISC  UNIQUE         '
       as record_data
      ,20                                       as record_id
      ,30                                       as section_id
    from headers hd
    UNION ALL
    select
       hd.org
      ,hd.merchant
      ,'TRN    TIME     ID       NUMBER                                                            '
       || 'CODE     AMT        TYPE   ID            ' as record_data
      ,30                                       as record_id
      ,30                                       as section_id
    from headers hd
    UNION ALL
    select
       hd.org
      ,hd.merchant
      ,lpad('-',132,'-')                        as record_data
      ,40                                       as record_id
      ,30                                       as section_id
    from headers hd
  )
  
  UNION ALL
  
  ------------------------------------------------------------
  -- Transaction Records (40)
  ------------------------------------------------------------
  select 
     bd.org
    ,bd.merchant
    ,rpad(
    rpad(nvl(to_char(bd.dtoftrn),' '),5,' ') || ' ' ||
    rpad(nvl(to_char(bd.trns_time),' '),8,' ') || ' ' ||
    rpad(nvl(bd.trmnl_id,' '),8,' ') || ' ' || 
    rpad(nvl(bd.sequence_number,' '),12,' ') || ' ' || 
    rpad(nvl(bd.card_number,' '),13,' ') || ' ' || 
    rpad(nvl(bd.type,' '),15,' ') || ' ' || 
    rpad(nvl(bd.acq_ref_num,' '),23,' ') || ' ' || 
    rpad(nvl(bd.auth_code,' '),6,' ') || ' ' || 
    lpad(trim(to_char(bd.trn_amnt, '999999999990.99')),12,' ') || ' ' || 
    rpad(nvl(bd.disc_type,' '),4,' ') || ' ' ||
    rpad(nvl(bd.uniqueid,' '),15,' ')
    ,132,' ')                                   as record_data
    ,row_number() over(partition by bd.org, bd.merchant
      order by 
        bd.order_id
       ,bd.dtoftrn
       ,bd.trns_time
       ,bd.trmnl_id
       ,bd.sequence_number
       ,bd.card_number
       ,bd.type
       ,bd.acq_ref_num
     )                                        as record_id
    ,40                                       as section_id
  from (
    select 
      org
     ,merchant
     ,type
     ,dtoftrn
     ,trns_time
     ,trmnl_id
     ,sequence_number
     ,card_number
     ,acq_ref_num
     ,auth_code
     ,trn_amnt
     ,disc_type
     ,uniqueid
     ,1                                       as order_id
    from all_items
    where record_type in (
       'TRANS'
      ,'PWCB'
      ,'FRAUD'
    )
    
    UNION ALL
    
    select 
     org
     ,merchant
     ,type
     ,dtoftrn
     ,trns_time
     ,trmnl_id
     ,sequence_number
     ,card_number
     ,acq_ref_num
     ,auth_code
     ,sum(trn_amnt)                           as trn_amnt
     ,disc_type
     ,uniqueid
     ,2                                       as order_id
     from (
      select 
        org
       ,merchant
       ,type
       ,to_char(to_date(:P_REPORT_DATE,'dd-mm-yyyy')-1
         ,'dd/mm')                               as dtoftrn
       ,'00:00:00'                               as trns_time
       ,null                                     as trmnl_id
       ,null                                     as sequence_number
       ,null                                     as card_number
       ,null                                     as acq_ref_num
       ,null                                     as auth_code
       ,trn_amnt
       ,null                                     as disc_type
       ,null                                     as uniqueid
      from all_items
      where record_type in (
         'COMM'
      )
    )
    group by 
      org
     ,merchant
     ,type
     ,dtoftrn
     ,trns_time
     ,trmnl_id
     ,sequence_number
     ,card_number
     ,acq_ref_num
     ,auth_code
     ,disc_type
     ,uniqueid
  ) bd
  
  UNION ALL
  
  ------------------------------------------------------------
  -- Grand Totals (50)
  ------------------------------------------------------------
  select * from (
    select
       tot.org
      ,tot.merchant
      ,lpad('-',132,'-')                        as record_data
      ,10                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  GRAND TOTAL OF POS TRANSACTIONS :',51,' ')
        || lpad(trim(lpad(nvl(tot.total_num_pos,0), 5, 0)),15,' ')
        ,132,' ')                               as record_data
      ,20                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  GRAND TOTAL VALUE OF POS TRANSACTIONS :',51,' ')
        || lpad(trim(to_char(nvl(tot.total_pos,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,30                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  MONTHLY VALUE OF COMMISSION + VAT :',51,' ')
        || lpad(trim(to_char(nvl(tot.total_comm,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,40                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  GRAND TOTAL VALUE OF FEE TRANSACTIONS :',51,' ')
        || lpad(trim(to_char(nvl(tot.total_fee,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,50                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  VALUE OF CHARGEBACK TRANSACTIONS :',51,' ')
        || lpad(trim(to_char(nvl(tot.total_cbk,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,60                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  VALUE OF SUSPENDED TRANSACTIONS :',51,' ')
        || lpad(trim(to_char(nvl(tot.total_fraud,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,70                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  GRAND TOTAL OF CASH (PWCB):',51,' ')
        || lpad(trim(to_char(nvl(tot.total_cash,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,80                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  GRAND TOTAL OF REBATE :',51,' ')
        || lpad(trim(to_char(nvl(tot.total_rebate,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,90                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,lpad('-',132,'-')                        as record_data
      ,100                                      as record_id
      ,50                                       as section_id
    from totals tot
  )
  
  UNION ALL
  
  ------------------------------------------------------------
  -- Report Footer (900)
  ------------------------------------------------------------
  select
     hd.org
    ,hd.merchant
    ,rpad(' END OF REPORT',132,' ')           as record_data
    ,10                                       as record_id
    ,900                                      as section_id
  from headers hd
)
-----------------------MONTHLY SUMARY-------------------------
, ms_report as (
  ------------------------------------------------------------
  -- Report Header (10)
  ------------------------------------------------------------
  select * from (
    select
       hd.org
      ,hd.merchant
      ,substr(
       lpad(' ',round((132 - length(hd.inst_name)) / 2),' ') 
       || hd.inst_name || lpad(' ', 132, ' ')
       ,1,132)                                  as record_data
      ,10                                       as record_id
      ,10                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,(lpad(' ',51,' ') || rpad('MERCHANT SETTLEMENT ADVICES', 68, ' ') || 'PAGE'
       || lpad(row_number() over(partition by hd.org order by hd.merchant),9,' ')
       )                                        as record_data
      ,20                                       as record_id
      ,10                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,lpad(' ',55,' ') || 'COMPUTERISED FAX/EMAIL    ('
       || hd.delivery_type
       || ')             PROC DATE '
       || to_char(sysdate, 'DD/MM/YYYY') ||'  TIME '
       || to_char(systimestamp, 'HH.MI.SS')     as record_data
      ,30                                       as record_id
      ,10                                       as section_id
    from headers hd
  )
  
  UNION ALL 
  
  ------------------------------------------------------------
  -- Merchant Demographic Records (20)
  ------------------------------------------------------------
  select * from (
    select
       hd.org
      ,hd.merchant
      ,rpad(
        '  MERCHANT NO :  ' || rpad(merchant, 92, ' ')
        || 'AGENT CODE ' 
        || nvl(hd.agent_code,'00000')
        ,132,' ')                               as record_data
      ,10                                       as record_id
      ,20                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,rpad(
        '  ADDRESS     :  ' || rpad(coalesce(hd.address_line_1, 'NA'),92,' ')
        || 'PHONE '
        || nvl(hd.phone,'NA')
        ,132,' ')                               as record_data
      ,20                                       as record_id
      ,20                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,rpad(
        lpad(' ', 17, ' ') || rpad(coalesce(address_line_2, 'NA'),92,' ')
        || 'FAX   '
        || coalesce(hd.fax,'NA')
        ,132,' ')                               as record_data
      ,30                                       as record_id
      ,20                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,rpad(
        lpad(' ', 17, ' ') || coalesce(hd.address_line_3, 'NA')
       ,132,' ')                                as record_data
      ,40                                       as record_id
      ,20                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,rpad(
        lpad(' ', 17, ' ') || coalesce(hd.address_line_4, 'NA')
        ,132,' ')                               as record_data
      ,50                                       as record_id
      ,20                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,rpad(
        '  EMAIL :' || coalesce(hd.e_mail, 'NA')
        ,132,' ')                               as record_data
      ,60                                       as record_id
      ,20                                       as section_id
    from headers hd
    UNION ALL 
    select
       hd.org
      ,hd.merchant
      ,rpad(
         lpad('MERCHANT SUMMARY ADVICE FROM ',70,' ')
         || to_char(hd.settlement_date-1,'DD/MM/YYYY')
         || ' TO '
         || to_char(hd.settlement_date-1,'DD/MM/YYYY')
         ,132,' ')                              as record_data
      ,70                                       as record_id
      ,20                                       as section_id
    from headers hd
  )
  
  UNION ALL
  
  ------------------------------------------------------------
  -- Payment Scheme Header (30)
  ------------------------------------------------------------
  select  * from (
    select
       hd.org
      ,hd.merchant
      ,lpad('-',132,'-')                        as record_data
      ,10                                       as record_id
      ,30                                       as section_id
    from headers hd
    UNION ALL
    select 
       hd.org
      ,hd.merchant
      ,rpad('BEING SETTLEMENT ADVICE FOR ALL ACTIVITY PERFORMED DURING PROCESSING DAY:',132,' '
       )                                        as record_data
      ,20                                       as record_id
      ,30                                       as section_id
    from headers hd
    UNION ALL
    select 
       hd.org
      ,hd.merchant
      ,rpad('ITEM               VISA             MASTERCARD      DINERS      P/LABEL           CUP          TOTAL'
       ,132,' ')                                as record_data
      ,30                                       as record_id
      ,30                                       as section_id
    from headers hd
    UNION ALL
    select
       hd.org
      ,hd.merchant
      ,lpad('-',132,'-')                        as record_data
      ,40                                       as record_id
      ,30                                       as section_id
    from headers hd
    UNION ALL
    select
       hd.org
      ,hd.merchant
      ,rpad('            |  NO|   AMT    |  NO|   AMT    |  NO|   AMT    |  NO|   AMT    |  NO|   AMT    |  NO|   AMOUNT'
       ,132,' ')                                as record_data
      ,50                                       as record_id
      ,30                                       as section_id
    from headers hd
    UNION ALL
    select
       hd.org
      ,hd.merchant
      ,lpad('-',132,'-')                        as record_data
      ,60                                       as record_id
      ,30                                       as section_id
    from headers hd
  )
  
  UNION ALL
  
  ------------------------------------------------------------
  --  Payment Scheme Records (40)
  ------------------------------------------------------------
  select
     tmp.org
    ,tmp.merchant
    ,rpad(
      rpad(tmp.type_group,12,' ')||'|'
      ||lpad(nvl(sch.visa_cnt,0),4,' ') ||'|'||lpad(trim(to_char(nvl(sch.visa_sum,0),'999999999990.99')),10,' ')||'|'
      ||lpad(nvl(sch.mc_cnt,0),4,' ')    ||'|'||lpad(trim(to_char(nvl(sch.mc_sum,0),'999999999990.99')),10,' ')||'|'
      ||lpad(nvl(sch.din_cnt,0),4,' ')  ||'|'||lpad(trim(to_char(nvl(sch.din_sum,0),'999999999990.99')),10,' ')||'|'
      ||lpad(nvl(sch.pl_cnt,0),4,' ')   ||'|'||lpad(trim(to_char(nvl(sch.pl_sum,0),'999999999990.99')),10,' ')||'|'
      ||lpad(nvl(sch.cup_cnt,0),4,' ')  ||'|'||lpad(trim(to_char(nvl(sch.cup_sum,0),'999999999990.99')),10,' ')||'|'
      ||lpad(nvl(sch.total_cnt,0),4,' ')||'|'||lpad(trim(to_char(nvl(sch.total_sum,0),'999999999990.99')),13,' ')
     ,132,' ')                                  as record_data
    ,tmp.record_id
    ,40                                         as section_id
  from (
    select org, merchant, 'SALES' as type_group,      1 as record_id from headers
    union all
    select org, merchant, 'CASH(PWCB)' as type_group, 2 as record_id from headers
    union all
    select org, merchant, 'REFUND' as type_group,     3 as record_id from headers
    union all
    select org, merchant, 'COMMISSION' as type_group, 4 as record_id from headers
  ) tmp 
  left join pay_sch_records sch on sch.merchant = tmp.merchant
    and sch.org = tmp.org
    and sch.type_group = tmp.type_group
  
  UNION ALL
  
  ------------------------------------------------------------
  -- Additional Fees (50)
  ------------------------------------------------------------
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('VAT ON COMM',98,' ')
        ||lpad(trim(to_char(tot.vat_comm,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,10                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,lpad('-',132,'-')                        as record_data
      ,20                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('SUSPENDED HOLD',98,' ')
        ||lpad(trim(to_char(tot.susp_hold,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,30                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('SUSPENDED RELEASE',98,' ')
        ||lpad(trim(to_char(tot.susp_rel,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,40                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('CHGBK CREDIT',98,' ')
        ||lpad(trim(to_char(tot.chbk_cr,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,50                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('CHGBK DEBIT',98,' ')
        ||lpad(trim(to_char(tot.chbk_db,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,60                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('CHGBK FEES',98,' ')
        ||lpad(trim(to_char(tot.cb_fee,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,70                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('TRAN FEES',98,' ')
        ||lpad(trim(to_char(tot.tran_fee,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,80                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('GPRS FEES',98,' ')
        ||lpad(trim(to_char(tot.gprs,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,90                                       as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('INSURANCE',98,' ')
        ||lpad(trim(to_char(tot.insur,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,100                                      as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('TID RENTAL',98,' ')
        ||lpad(trim(to_char(tot.term,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,110                                      as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('MEM FEES',98,' ')
        ||lpad(trim(to_char(tot.mmf,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,120                                      as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('DR ADJ AMT',98,' ')
        ||lpad(trim(to_char(tot.m_db,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,130                                      as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('CR ADJ AMT',98,' ')
        ||lpad(trim(to_char(tot.m_cr,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,140                                      as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('MISC AMT',98,' ')
        ||lpad(trim(to_char(tot.misc,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,150                                      as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('MIN COMM ADJ',98,' ')
        ||lpad(trim(to_char(tot.min_comm,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,160                                      as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('REBATE TOTAL',98,' ')
        ||lpad(trim(to_char(tot.rebate,'999999999990.99')),13,' ')
        ,132,' ')                               as record_data
      ,170                                      as record_id
      ,50                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,lpad('-',132,'-')                        as record_data
      ,300                                      as record_id
      ,50                                       as section_id
    from totals tot

    UNION ALL

  ------------------------------------------------------------
  -- Payment Scheme Totals (60)
  ------------------------------------------------------------
    select
     tot.org
    ,tot.merchant
    ,rpad(
      rpad(' TOTAL',12,' ')||'|'
      ||lpad(nvl(tot.total_visa_cnt,0),4,' ') ||'|'||lpad(trim(to_char(nvl(tot.total_visa,0),'999999999990.99')),10,' ')||'|'
      ||lpad(nvl(tot.total_mc_cnt,0),4,' ')   ||'|'||lpad(trim(to_char(nvl(tot.total_mc,0),'999999999990.99')),10,' ')||'|'
      ||lpad(nvl(tot.total_din_cnt,0),4,' ')  ||'|'||lpad(trim(to_char(nvl(tot.total_din,0),'999999999990.99')),10,' ')||'|'
      ||lpad(nvl(tot.total_pl_cnt,0),4,' ')   ||'|'||lpad(trim(to_char(nvl(tot.total_pl,0),'999999999990.99')),10,' ')||'|'
      ||lpad(nvl(tot.total_cup_cnt,0),4,' ')  ||'|'||lpad(trim(to_char(nvl(tot.total_cup,0),'999999999990.99')),10,' ')||'|'
      ||lpad(nvl(tot.total_cnt,0),4,' ')      ||'|'||lpad(trim(to_char(nvl(tot.total_sum,0),'999999999990.99')),13,' ')
     ,132,' ')                                  as record_data
    ,10                                         as record_id
    ,60                                         as section_id
  from totals tot
  
  UNION ALL
  
  ------------------------------------------------------------
  -- Grand Totals (70)
  ------------------------------------------------------------
  select * from (
    select
       tot.org
      ,tot.merchant
      ,lpad('-',132,'-')                        as record_data
      ,10                                       as record_id
      ,70                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  GRAND TOTAL OF POS TRANSACTIONS :',96,' ')
        || lpad(trim(lpad(nvl(tot.total_num_pos,0), 5, 0)),15,' ')
        ,132,' ')                               as record_data
      ,20                                       as record_id
      ,70                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  GRAND TOTAL VALUE OF POS TRANSACTIONS :',96,' ')
        || lpad(trim(to_char(nvl(tot.total_pos,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,30                                       as record_id
      ,70                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  MONTHLY VALUE OF COMMISSION + VAT :',96,' ')
        || lpad(trim(to_char(nvl(tot.total_comm,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,40                                       as record_id
      ,70                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  GRAND TOTAL VALUE OF FEE TRANSACTIONS :',96,' ')
        || lpad(trim(to_char(nvl(tot.total_fee,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,50                                       as record_id
      ,70                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  VALUE OF CHARGEBACK TRANSACTIONS :',96,' ')
        || lpad(trim(to_char(nvl(tot.total_cbk,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,60                                       as record_id
      ,70                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  VALUE OF SUSPENDED TRANSACTIONS :',96,' ')
        || lpad(trim(to_char(nvl(tot.total_fraud,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,70                                       as record_id
      ,70                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  GRAND TOTAL OF CASH (PWCB):',96,' ')
        || lpad(trim(to_char(nvl(tot.total_cash,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,80                                       as record_id
      ,70                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,rpad(
        rpad('  GRAND TOTAL OF REBATE :',96,' ')
        || lpad(trim(to_char(nvl(tot.total_rebate,0), '999999999990.99')),15,' ')
        ,132,' ')                               as record_data
      ,90                                       as record_id
      ,70                                       as section_id
    from totals tot
    UNION ALL
    select
       tot.org
      ,tot.merchant
      ,lpad('-',132,'-')                        as record_data
      ,100                                      as record_id
      ,70                                       as section_id
    from totals tot
  )
  
  UNION ALL
  
  ------------------------------------------------------------
  -- Bank Notice (80)
  ------------------------------------------------------------
  select
     hd.org
    ,hd.merchant
    ,rpad(ft.add_info_01,132,' ')             as record_data
    ,ft.record_id
    ,80                                       as section_id
  from headers hd
  left join (
    select 
       cl.org
      ,level*10                               as record_id
      ,regexp_substr(cl.add_info_01,'[^'||CHR(10)||CHR(13)||']+', 1, level
       )                                      as add_info_01
    from (
      select distinct
         fi.bank_code                         as org
        ,fi.name
        ,cl.add_info_01
      from ows.opt_v_acq_fi_match fi
      left join ows.client cl on cl.f_i = fi.id
        and cl.amnd_state = 'A'
        and cl.reg_number = :ORG||'-01'
      where fi.bank_code = :ORG
    ) cl
    connect by regexp_substr(cl.add_info_01, '[^'||CHR(10)||CHR(13)||']+', 1, level) is not null
  ) ft on ft.org = hd.org
  
  UNION ALL

  ------------------------------------------------------------
  -- Report Footer (900)
  ------------------------------------------------------------
  select
     hd.org
    ,hd.merchant
    ,rpad(' END OF REPORT',132,' ')           as record_data
    ,10                                       as record_id
    ,900                                      as section_id
  from headers hd
)
------------------------------------------------------------
select 
   org
  ,merchant
  ,record_data
  ,record_id
  ,section_id
  ,report_file
from (
  select 
     org
    ,merchant
    ,record_data
    ,record_id
    ,section_id
    ,:P_DA_FILE                                 as report_file
  from da_report
  where :P_DA_FILE is not null
  
  UNION ALL
  
  select 
     org
    ,merchant
    ,record_data
    ,record_id
    ,section_id
    ,:P_MS_FILE                                 as report_file
  from ms_report
  where :P_MS_FILE is not null
)
order by 
   org
  ,report_file
  ,merchant
  ,section_id
  ,record_id