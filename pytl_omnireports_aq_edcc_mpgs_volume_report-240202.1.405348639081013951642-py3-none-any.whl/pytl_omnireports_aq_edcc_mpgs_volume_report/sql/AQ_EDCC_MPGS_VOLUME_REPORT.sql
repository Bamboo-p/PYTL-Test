/*
* Code for AQ_EDCC_MPGS_VOLUME_REPORT
* PyTL_OmniReports_AQ_EDCC_MPGS_VOLUME_REPORT = AQ_EDCC_MPGS_VOLUME_REPORT.sql
* Version history:
* 240118.1 : NIINT-4374 : PrabirK : Initial version : Extract for DCC rates and amounts
* 240122.1 : NIINT-4374 : PrabirK : LPAD COUNT/RATE/AMOUNT Fields
* 240123.1 : NIINT-4374 : PrabirK : SQL Correction
* 240131.1 : NIINT-4557 : PrabirK : Remove opeartio and entry subquery, added cntr_trf subquery and fetching amounts from transaction add_info
* 240201.1 : NIINT-4573 : Prabirk : Correction for DCC_REV_AMOUNT Tag
* 240202.1 : NIINT-4573 : Prabirk : Added trans_type subquery and change in logic for amount calculation
*/
with 
institution as (
select /*+ no_merge */
       id
      ,name
      ,code
from dwh.dwd_institution
where record_state = 'A'
and code = :ORG
)
, currency as (
select /*+ no_merge */
       full_name
      ,code
      ,name
from dwh.dwd_currency
where record_state = 'A'
and name = 'AED'
)
, trans_type as (
select /*+ no_merge */ 
       id
      ,code
      ,name
      ,request_category
      ,case
        when code in ('R1-P','DCCR1-P','K1-R','DCCK1-R') then 'SALE'
        when code in ('K1-P','DCCK1-P','R1-R','DCCR1-R') then 'REFUND'
       end as type_group
from dwd_transaction_type
where record_state = 'A'
and service_class = 'T'
and request_category in ('R','P')
and code in ('R1-P','R1-R','K1-P','K1-R','DCCR1-P','DCCR1-R','DCCK1-P','DCCK1-R')
)
, transaction as (
select /*+ no_merge */
       t.merchant
      ,t.doc_idt
      ,tt.type_group
      ,cur.name as settl_curr_name
      ,t.settl_amount
      ,to_number(replace(replace(substr(t.add_info, instr(t.add_info, 'DCC_MRK_AMOUNT=')+15, (instr(t.add_info, ';', instr(t.add_info, 'DCC_MRK_AMOUNT='))-instr(t.add_info, 'DCC_MRK_AMOUNT=')-15)), chr(10)), chr(13))) as dcc_markup_amount
      ,to_number(replace(replace(substr(t.add_info, instr(t.add_info, 'DCC_NIR_AMOUNT=')+15, (instr(t.add_info, ';', instr(t.add_info, 'DCC_NIR_AMOUNT='))-instr(t.add_info, 'DCC_NIR_AMOUNT=')-15)), chr(10)), chr(13))) as dcc_ni_merchant_amount
      ,to_number(replace(replace(substr(t.add_info, instr(t.add_info, 'DCC_REV_AMOUNT=')+15, (instr(t.add_info, ';', instr(t.add_info, 'DCC_REV_AMOUNT='))-instr(t.add_info, 'DCC_REV_AMOUNT=')-15)), chr(10)), chr(13))) as merchant_revenue_amount
      ,1 as cnt
from dwh.dwf_transaction t
join currency cur
on cur.code = t.settl_currency
join trans_type tt 
on tt.id = t.transaction_type_id
where t.institution_id in (select /*+ no_merge */ id from institution)
and t.banking_date = to_date(:P_REPORT_DATE,'DD-MM-YYYY')
and instr(t.add_info,'DT_CRESPND=FEXCO;') > 0 
and instr(t.add_info,'MIGS=Y;') > 0 
and instr(t.add_info,'DT_STATUS=1;') > 0
) 
, cntr_trf as (
select /*+ no_merge */
       ct.contract_idt
      ,c.personal_account
      ,max(case when d.type_code = 'ACQ_DCC_MRK'  then s.fee_rate_value else null end) as dcc_markup_rate
      ,max(case when d.type_code = 'ACQ_DCC_NI'  then s.fee_rate_value else null end)  as dcc_ni_merchant_rate
      ,max(case when d.type_code = 'ACQ_DCC_REV'  then s.fee_rate_value else null end) as merchant_revenue_rate
from dwh.dwa_contract_tariff ct
join institution on institution.id = ct.institution_id
join dwh.dwd_tariff d on ct.tariff_idt = d.record_idt
and d.type_code in ('ACQ_DCC_MRK','ACQ_DCC_NI','ACQ_DCC_REV')
and d.record_state = 'A'
and d.role = 'SERVICE'
join dwh.dwd_service_tariff s on s.record_idt = d.record_idt
and s.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
and s.record_date_to >= to_date(:P_REPORT_DATE,'DD-MM-YYYY') 
join dwd_contract c
on c.record_idt = ct.contract_idt
and c.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
and c.record_date_to >= to_date(:P_REPORT_DATE,'DD-MM-YYYY') 
where ct.active_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
and ct.active_date_to >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
and ct.switched_on = 'Y'
group by ct.contract_idt,c.personal_account
)
, total_entry as (
select /*+ no_merge */
       e.merchant
      ,e.transaction_count
      ,e.transaction_amount
      ,e.dcc_markup_rate
      ,e.dcc_markup_amount
      ,e.dcc_ni_merchant_rate
      ,e.dcc_ni_merchant_amount
      ,e.merchant_revenue_rate
      ,e.merchant_revenue_amount
      ,(e.dcc_markup_rate - e.dcc_ni_merchant_rate - e.merchant_revenue_rate) as fexco_rate
      ,(e.dcc_markup_amount - e.dcc_ni_merchant_amount - e.merchant_revenue_amount) as fexco_amount     
from (
select /*+ no_merge */
       tr.merchant
      ,sum(tr.cnt)                                                                                                                  as transaction_count
      ,sum(decode(tr.type_group,'SALE',tr.settl_amount,0) - decode(tr.type_group,'REFUND',tr.settl_amount,0))                       as transaction_amount
      ,ct.dcc_markup_rate
      ,sum(decode(tr.type_group,'SALE',tr.dcc_markup_amount,0) - decode(tr.type_group,'REFUND',tr.dcc_markup_amount,0))             as dcc_markup_amount
      ,ct.dcc_ni_merchant_rate
      ,sum(decode(tr.type_group,'SALE',tr.dcc_ni_merchant_amount,0) - decode(tr.type_group,'REFUND',tr.dcc_ni_merchant_amount,0))   as dcc_ni_merchant_amount
      ,ct.merchant_revenue_rate
      ,sum(decode(tr.type_group,'SALE',tr.merchant_revenue_amount,0) - decode(tr.type_group,'REFUND',tr.merchant_revenue_amount,0)) as merchant_revenue_amount
from transaction tr
join cntr_trf ct
on tr.merchant = ct.personal_account
group by tr.merchant
        ,ct.dcc_markup_rate
        ,ct.dcc_ni_merchant_rate
        ,ct.merchant_revenue_rate
)e
)
, total as (
select /*+ no_merge */
       sum(te.transaction_count)       as transaction_count
      ,sum(te.transaction_amount)      as transaction_amount
      ,sum(te.dcc_markup_amount)       as dcc_markup_amount
      ,sum(te.dcc_ni_merchant_amount)  as dcc_ni_merchant_amount
      ,sum(te.merchant_revenue_amount) as merchant_revenue_amount
      ,sum(te.fexco_amount)            as fexco_amount
from total_entry te
)
, header as (
select lpad(' ',73,' ') || upper(name) || CHR(13)||CHR(10) ||
       lpad(' ',75,' ') || 'MERCHANT E-DCC VOLUME REPORT' || CHR(13)||CHR(10) ||
       lpad(' ',140,' ') || 'PROC DATE ' || to_char(sysdate, 'DD/MM/YYYY') ||'  TIME ' || to_char(systimestamp, 'HH.MI.SS') || CHR(13)||CHR(10) || 
       lpad('-',177,'-') || CHR(13)||CHR(10) ||
       'MERCHANT      TRANSACTION     TRANSACTION      DCC MARKUP      DCC MARKUP        NI SHARE        NI SHARE  MERCHANT REVENUE  MERCHANT REVENUE      FEXCO RATE    FEXCO AMOUNT' || CHR(13)||CHR(10) ||
       'ID            COUNT           AMOUNT           RATE            AMOUNT            RATE            AMOUNT    RATE              AMOUNT' || CHR(13)||CHR(10) ||
       lpad('-',177,'-') as datasumm
      ,1 as record_order
from institution
)
, body as (
select /*+ no_merge */
       rpad(tent.merchant,12,' ') || '  ' ||
       lpad(tent.transaction_count,11,' ') || '  ' ||
       lpad(to_char(tent.transaction_amount,'FM999999999990D00'),14,' ') || '  ' ||
       lpad(to_char(tent.dcc_markup_rate,'FM999999999990D00'),14,' ') || '  ' ||
       lpad(to_char(tent.dcc_markup_amount,'FM999999999990D00'),14,' ') || '  ' ||
       lpad(to_char(tent.dcc_ni_merchant_rate,'FM999999999990D00'),14,' ') || '  ' ||
       lpad(to_char(tent.dcc_ni_merchant_amount,'FM999999999990D00'),14,' ') || '  ' ||
       lpad(to_char(tent.merchant_revenue_rate,'FM999999999990D00'),16,' ') || '  ' ||
       lpad(to_char(tent.merchant_revenue_amount,'FM999999999990D00'),16,' ') || '  ' ||
       lpad(to_char(tent.fexco_rate,'FM999999999990D00'),14,' ') || '  ' ||
       lpad(to_char(tent.fexco_amount,'FM999999999990D00'),14,' ') as datasumm
      ,2 as record_order
from total_entry tent
), footer as (
select /*+ no_merge */ 
       lpad('-',177,'-') || CHR(13)||CHR(10) ||
       '  TOTAL COUNT OF OPTED IN TRANSACTIONS :' || lpad(nvl(tt.transaction_count,0),24,' ') || CHR(13)||CHR(10) ||
       '  TOTAL AMOUNT OF OPTED IN TRANSACTIOS :' || lpad(to_char(nvl(tt.transaction_amount,0),'FM999999999990D00'),24,' ') || CHR(13)||CHR(10) ||
       '  TOTAL DCC MARKUP AMOUNT :             ' || lpad(to_char(nvl(tt.dcc_markup_amount,0),'FM999999999990D00'),24,' ') || CHR(13)||CHR(10) ||
       '  TOTAL NI SHARE AMOUNT :               ' || lpad(to_char(nvl(tt.dcc_ni_merchant_amount,0),'FM999999999990D00'),24,' ') || CHR(13)||CHR(10) ||
       '  TOTAL MERCHANT SHARE AMOUNT :         ' || lpad(to_char(nvl(tt.merchant_revenue_amount,0),'FM999999999990D00'),24,' ') || CHR(13)||CHR(10) ||
       '  TOTAL FEXCO SHARE AMOUNT :            ' || lpad(to_char(nvl(tt.fexco_amount,0),'FM999999999990D00'),24,' ') || CHR(13)||CHR(10) || 
       lpad('-',68,'-') || CHR(13)||CHR(10) ||
       'END OF REPORT' as datasumm
      ,3 as record_order
from total tt
) 

select 
       :ORG as org
      ,datasumm
from (
select datasumm,record_order from header
union all
select datasumm,record_order from body
union all
select datasumm,record_order from footer
)
order by record_order