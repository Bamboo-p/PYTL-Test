__version__ = "240510.2"
__job_name__ = "PyTL_OmniReports_AQ_IPP_TMS_EXTRACT"
__bat_files__ = []
