/*
* Version history:
* 240510.1 : NIBOA-10062 : PadalaSK  : Initial development PyTL_IS_XlsReports_AQ_IPP_TMS_EXTRACT --> PyTL_OmniReports_AQ_IPP_TMS_EXTRACT
*/WITH inst AS (
    SELECT
        id,
        code AS instcode
    FROM
        dwh.dwd_institution
    WHERE
            record_state = 'A'
        AND code = :ORG
), contract AS (
    SELECT
        cntr.record_idt,
        cntr.parent_contract_idt,
        cntr.personal_account,
        cntr.add_info            AS cntr_add_info,
        cntr.record_date_from    AS cntr_record_date_from,
        CASE
            WHEN cntr.personal_account LIKE 'POS%' THEN
                'Y'
            ELSE
                'N'
        END AS is_dummy,
        clnt.add_info            AS clnt_add_info,
        (
            SELECT
                MAX(mcc)
            FROM
                dwh.dwd_device
            WHERE
                    main_contract_idt = cntr.record_idt
                AND record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                AND record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        ) AS mcc
    FROM
             dwh.dwd_contract cntr
        JOIN inst ON inst.id = cntr.institution_id
        JOIN dwh.dwd_client clnt ON clnt.record_idt = cntr.client_idt
                                    AND clnt.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                                    AND clnt.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    WHERE
            cntr.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND cntr.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
), curr_cattr AS (
    SELECT
        dctr.contract_idt,
        datr.code AS curr_instpp_flag
    FROM
             dwh.dwa_contract_attribute dctr
        JOIN dwh.dwd_attribute datr ON datr.id = dctr.attr_id
                                       AND datr.type_code = 'ACQ_INSTPP_FLAG'
                                       AND datr.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                                       AND datr.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    WHERE
            dctr.attr_date_from = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND dctr.attr_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
), addrs AS (
    SELECT
        contract_idt,
        MAX(decode(address_type_code, 'STMT_ADDR', city, NULL)) AS city
    FROM
             dwh.opt_v_address adr
        JOIN inst ON inst.id = adr.institution_id
    WHERE
            adr.record_state = 'A'
        AND adr.address_type_code IN (
            'STMT_ADDR',
            'PAYM_ADDR'
        )
    GROUP BY
        contract_idt
), final AS (
    SELECT
        dev.record_idt																					AS terminal_id,
        dev.personal_account																			AS terminal,
        merch.record_idt																				AS merchant_id,
        merch.personal_account																			AS merchant,
        regexp_substr(merch.clnt_add_info, '(INSTPP_MERCH_ID+)=([^;]+);', 1, 1, '', 2)					AS merchant_tag,
        regexp_substr(merch.clnt_add_info, '(INSTPP_BNKUSR_ID+)=([^;]+);', 1, 1, '', 2)					AS bank_user_id,
        regexp_substr(merch.clnt_add_info, '(INSTPP_SHOP_ID+)=([^;]+);', 1, 1, '', 2)					AS shop_id,
        regexp_substr(dev.cntr_add_info, '(INSTPP_CASH_DESK_ID+)=([^;]+);', 1, 1, '', 2)				AS cash_desk_id,
        dev.cntr_record_date_from,
        curr_cattr.curr_instpp_flag,
        addrs.city																						AS merchant_city,
        :GROUP_CODE																						AS group_code,
        :BANK_CODE																						AS bank_code,
        nvl(merch.mcc, '')																				AS mcc,
        substr('784d6610-s4ss-485s-as55-2024s6e372bf-926d2015-s4sse485s5as558357', 1, 64 - nvl(length(regexp_substr(merch.clnt_add_info,
        '(INSTPP_BNKUSR_ID+)=([^;]+);', 1, 1, '',
                                                                                                                    2)), 0))
        || regexp_substr(merch.clnt_add_info, '(INSTPP_BNKUSR_ID+)=([^;]+);', 1, 1, '',
                         2)                                        AS appid
    FROM
        contract  merch
        LEFT JOIN contract  dev ON dev.parent_contract_idt = merch.record_idt
                                  AND nvl(dev.is_dummy, 'N') = 'N'
                                  AND instr(dev.cntr_add_info, 'INSTPP_CASH_DESK_ID') > 0
        LEFT JOIN curr_cattr ON curr_cattr.contract_idt = merch.record_idt
        LEFT JOIN addrs ON addrs.contract_idt = merch.record_idt
), final_dump AS (
    SELECT
        merchant,
        terminal,
        merchant_tag,
        bank_user_id,
        shop_id,
        cash_desk_id,
        merchant_city,
        group_code,
        bank_code,
        mcc,
        appid
    FROM
        final
    WHERE
            cntr_record_date_from = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND :P_REPORT_TYPE = 'IPP_ENBD'
    UNION
    SELECT
        merchant,
        NULL  AS terminal,
        merchant_tag,
        bank_user_id,
        shop_id,
        NULL  AS cash_desk_id,
        NULL  AS merchant_city,
        group_code,
        bank_code,
        NULL  AS mcc,
        NULL  AS appid
    FROM
        final
    WHERE
            cntr_record_date_from = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND :P_REPORT_TYPE = 'MERCHANT'
    GROUP BY
        merchant,
        bank_user_id,
        shop_id,
        merchant_tag,
        group_code,
        bank_code
    UNION
    SELECT
        merchant,
        terminal,
        merchant_tag,
        bank_user_id,
        shop_id,
        cash_desk_id,
        merchant_city,
        group_code,
        bank_code,
        mcc,
        NULL AS appid
    FROM
        final
    WHERE
            cntr_record_date_from = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND :P_REPORT_TYPE = 'TERMINAL'
    GROUP BY
        merchant,
        terminal,
        merchant_tag,
        bank_user_id,
        shop_id,
        cash_desk_id,
        merchant_city,
        group_code,
        bank_code,
        mcc
)
SELECT
    :ORG AS org,
    merchant,
    terminal,
    merchant_tag,
    bank_user_id,
    shop_id,
    cash_desk_id,
    merchant_city,
    group_code,
    bank_code,
    mcc,
    appid
FROM
    final_dump