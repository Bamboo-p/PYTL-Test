/*
* 240506.1 : NIBOA-9981 : maksimsk : Initial version
* 240507.1 : NIBOA-9981 : maksimsk : fixed logic and improved performance
* 240507.2 : NIBOA-9981 : maksimsk : fixed ORIGIN_GROUP mapping
* 240507.3 : NIBOA-9981 : maksimsk : fixed numerating and sorting records
* 240510.1 : NIBOA-9981 : maksimsk : added filter by AFF_MERCH_TYPE to exclude Split Settl MIDs
* 240510.2 : NIBOA-9981 : maksimsk : fixed logic for TRAN_TYPE_IND
*/
WITH inst AS (
SELECT /*+ no_merge materialize */
   id
  ,code
FROM dwh.dwd_institution
WHERE record_state = 'A'
  AND code = :ORG
)
, oper AS (
SELECT 
  op.operation_type_id
  ,op.operation_type_code
  ,op.purpose
  ,op_new.code
  ,op_new.TYPE_NAME
  ,op_new.NAME                AS NARRATION
  ,op_new.TOTAL_GROUP         AS ORIGIN_GROUP
  ,op_new.ACCOUNTED
  ,op_new.UNIQUE_VAT
  ,op_new.CARD_FLAG
FROM (
  SELECT /*+ no_merge */
     op.operation_type_id
    ,op.operation_type_code
    ,op.class_code
    ,op.type_name
    ,op.type_code
    ,op.code
    ,op.name
    ,op.add_info
    ,regexp_substr(op.add_info,'(TOTAL_GROUP+)=([^;]+);', 1, 1, '', 2)        AS TOTAL_GROUP
    ,case when instr(op.add_info,';ACCOUNTED;') > 0 then 1 else 0 end         AS ACCOUNTED
    ,case when instr(op.add_info,';UNIQUE_VAT;') > 0 then 1 else 0 end        AS UNIQUE_VAT
    ,case when instr(op.add_info,';CARD_NUMBER;') > 0 then 1 else 0 end       AS CARD_FLAG
  FROM dwh.v_dwr_operation_type op
  WHERE op.class_code = 'ACQ_ALL_OPERATION_TYPES'
    AND instr(op.add_info,';RTA;') = 0
  ) op_new
LEFT JOIN (
  SELECT /*+ no_merge */
     operation_type_id
    ,operation_type_code
    ,code
    ,','
    || listagg(type_code, ',') WITHIN GROUP (
    ORDER BY type_code)
    || ','                    AS purpose
    ,MIN(NAME)                AS NAME
  FROM (
    SELECT
       operation_type_id
      ,operation_type_code
      ,class_code
      ,type_code
      ,code
      ,name
    FROM dwh.v_dwr_operation_type
    WHERE class_code = 'ACQ_SETTLEMENT_REPORT'
    )
  GROUP BY
     operation_type_id
    ,operation_type_code
    ,code
  ) op on op.operation_type_code = op_new.operation_type_code
)
, addr AS (
SELECT /*+ no_merge use_concat */
   COALESCE(merch_addr.address_line_2,'NA')                                                      AS LOCATION
  ,COALESCE(merch_addr.phone,merch_addr.phone_home,merch_addr.phone_mobile,'NA')                 AS telephone
  ,DECODE(merch_addr.address_type_code,'PST_ADDR',merch_addr.client_idt,merch_addr.contract_idt) AS contract_idt
  ,merch_addr.address_line_1                                                                     AS merch_name
  ,merch_addr.e_mail                                                                             AS email
  ,merch_addr.state
  ,merch_addr.address_type_code
FROM dwh.opt_v_address merch_addr
INNER JOIN inst ON inst.ID = merch_addr.institution_id
WHERE merch_addr.address_type_code IN ('STMT_ADDR','PST_ADDR')
  AND merch_addr.record_date_FROM <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  AND merch_addr.record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
)
, chains AS (
SELECT /*+ no_merge leading(dft dach dc inst) use_hash(dft dach) 
use_nl(dc dach) use_hash(dc inst) use_hash(dc addr) */
   dach.contract_idt
   ,dc.ident_number                                  AS chainid_1
  ,SUBSTR(dc.add_info
      ,instr(dc.add_info, 'CHAIN_GROUPS_CODE=')+18
      ,(instr(dc.add_info, ';', instr(dc.add_info, 'CHAIN_GROUPS_CODE='))
      -instr(dc.add_info, 'CHAIN_GROUPS_CODE=')-18)) AS chainid_1_gc
  ,addr.state                                        AS addr_state
FROM dwh.dwd_affiliation dach
INNER JOIN dwh.dwd_affiliation_type dft ON dach.affiliation_type_id = dft.ID
  AND dft.code IN ('CHAINID_1')
  AND dft.record_date_FROM <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  AND dft.record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  AND dach.record_date_FROM <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  AND dach.record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
INNER JOIN dwh.dwd_client dc
ON dc.record_idt = dach.affiliated_client_idt
  AND dc.record_date_FROM <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  AND dc.record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  AND instr(dc.add_info, 'CHAIN_GROUPS_CODE=EAM;') > 0
INNER JOIN inst ON inst.ID = dc.institution_id
LEFT JOIN addr ON addr.contract_idt = dc.record_idt
  AND addr.address_type_code = 'PST_ADDR'
)
, card_brand AS (
SELECT /*+ no_merge */
   'PREMIUM'                                           AS code
  ,cb.code                                             AS card_brand_code
  ,SUM(DECODE(v.type_code,'NI_DOM_IPS_CARD_TYPE',1,0)) AS ni_dom_ips_card_type
  ,SUM(DECODE(v.type_code,'NI_INT_IPS_CARD_TYPE',1,0)) AS ni_int_ips_card_type
  ,SUM(DECODE(v.type_code,'NI_SUP_IPS_CARD_TYPE',1,0)) AS ni_sup_ips_card_type
FROM dwh.v_dwr_lowest_level v
INNER JOIN dwh.dwd_card_brand cb ON cb.ID = v.dim_record_id
  AND cb.record_date_FROM <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  AND cb.record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
WHERE v.type_code IN (
  'NI_DOM_IPS_CARD_TYPE'
  ,'NI_INT_IPS_CARD_TYPE'
  ,'NI_SUP_IPS_CARD_TYPE'
  )
GROUP BY cb.code
)
, cattr AS (
SELECT /*+ no_merge leading(dft cattr) use_hash(dft cattr) */
   cattr.contract_idt
  ,attr.code
  ,attr.type_code
FROM dwh.dwa_contract_attribute cattr
INNER JOIN dwh.dwd_attribute attr ON attr.ID = cattr.attr_id
  AND attr.record_date_FROM <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  AND attr.record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
WHERE cattr.attr_date_FROM <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  AND cattr.attr_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  AND cattr.active_state = 'A'
  AND attr.type_code IN (
     'ACQ_LVL'
    ,'ACQ_MULTICUR'
    ,'ACQ_VATCOM_MERCH'
    ,'ACQ_COMM_STTLM'
    ,'ACQ_INT_RPRC'
    ,'ACQ_VATFEE_MERCH'
    ,'TRANS_FEE_STTLM'
  )
)
, cntr_tmp AS (
SELECT
   cn.inst_code
  ,cn.personal_account
  ,cn.record_idt
  ,cn.status_name
  ,cn.parent_contract_idt
  ,REPLACE(REPLACE(
    SUBSTR(
      cn.add_info,
       instr(cn.add_info, ';MERCH_TYPE=')+12,
      (instr(cn.add_info, ';', instr(cn.add_info, ';MERCH_TYPE=')+1)
      -instr(cn.add_info, ';MERCH_TYPE=')-12))
    , chr(10)), chr(13))                         AS store_type
  ,REPLACE(REPLACE(
    SUBSTR(
      cn.add_info,
       instr(cn.add_info, ';CREDITACCT=')+12,
      (instr(cn.add_info, ';', instr(cn.add_info, ';CREDITACCT=')+1)
      -instr(cn.add_info, ';CREDITACCT=')-12))
    , chr(10)), chr(13))                         AS bank_account
  ,cn.code
  ,cn.type_code
  ,SUBSTR(cn.add_info, 
     instr(cn.add_info, ';AFF_MERCH_TYPE=')+16, 
    (instr(cn.add_info, ';', instr(cn.add_info, ';AFF_MERCH_TYPE=')+1)
    -instr(cn.add_info, ';AFF_MERCH_TYPE=')-16)
  )                                              AS AFF_MERCH_TYPE
FROM (
  SELECT /*+ no_merge leading(dca c inst) use_nl(dca c) use_hash(c inst) */
     inst.code            AS inst_code
    ,c.personal_account
    ,c.record_idt
    ,c.status_name
    ,decode(dca.code, 'MERCHANT', c.record_idt, c.parent_contract_idt) AS parent_contract_idt
    ,';' || c.add_info    AS add_info
    ,dca.code
    ,dca.type_code
  FROM dwh.dwd_contract c
  JOIN inst ON inst.id = c.institution_id
  JOIN cattr dca ON c.record_idt = dca.contract_idt
    AND dca.type_code = 'ACQ_LVL'
    AND dca.code IN ('DEVICE','MERCHANT')
    AND c.record_date_FROM <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
    AND c.record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  ) cn
)
, cntr AS (
SELECT /*+ no_merge leading(ch mer dev) use_nl(ch mer) use_nl(mer dev) */
   mer.inst_code
  ,mer.record_idt          AS merchant_idt
  ,mer.personal_account
  ,dev.record_idt
  ,mer.store_type
  ,mer.bank_account
  ,dev.code
  ,mult.code               AS mult
  ,ch.chainid_1_gc         AS gc_chain1
  ,ch.chainid_1            AS master_chain1
  ,ch.addr_state
  ,merch_addr.merch_name   AS merchant_name
  ,merch_addr.LOCATION
  ,merch_addr.telephone
  ,merch_addr.email
  ,NVL(vatcomm.code,'Y')   AS vatcomm
  ,commfreq.code           AS commfreq
  ,transcomm.code          AS transcomm
  ,trnsfreq.code           AS trnsfreq
  ,NVL(rp.code,'Y')        AS rprc
FROM cntr_tmp dev
INNER JOIN cntr_tmp mer on mer.record_idt = dev.parent_contract_idt
  AND mer.code = 'MERCHANT'
  AND mer.status_name != 'Account Closed'
  AND upper(NVL(mer.AFF_MERCH_TYPE,'NA')) not in ('M', 'S')
INNER JOIN chains ch on ch.contract_idt = mer.record_idt
LEFT JOIN cattr mult ON mult.contract_idt = mer.record_idt
  AND mult.type_code = 'ACQ_MULTICUR'
LEFT JOIN cattr vatcomm ON vatcomm.contract_idt = mer.record_idt
  AND vatcomm.type_code = 'ACQ_VATCOM_MERCH'
LEFT JOIN cattr commfreq ON commfreq.contract_idt = mer.record_idt
  AND commfreq.type_code = 'ACQ_COMM_STTLM'
LEFT JOIN cattr rp ON rp.contract_idt = mer.record_idt
  AND rp.type_code = 'ACQ_INT_RPRC'
LEFT JOIN cattr transcomm ON transcomm.contract_idt = mer.record_idt
  AND transcomm.type_code = 'ACQ_VATFEE_MERCH'
LEFT JOIN cattr trnsfreq ON trnsfreq.contract_idt = mer.record_idt
  AND trnsfreq.type_code = 'TRANS_FEE_STTLM'
LEFT JOIN addr merch_addr ON merch_addr.contract_idt = mer.record_idt
)
, entries AS (
SELECT /*+ no_merge materialize use_hash(e) use_hash(i) swap_join_inputs(i) pq_distribute(i none broadcast)
use_hash(op) swap_join_inputs(op) pq_distribute(op none broadcast) use_nl(cntr e) pq_distribute(e hash hash) */
   e.primary_doc_idt          AS doc_idt
  ,e.banking_date
  ,e.fee_rate_value
  ,cntr.merchant_idt
  ,i.code                     AS inst_code
  ,e.contract_idt
  ,(e.credit - e.debit)       AS amnt
  ,e.fee_code
  ,e.tariff_idt
  ,e.operation_type_id
  ,op.operation_type_code
  ,op.origin_group
  ,op.narration
  ,op.accounted
  ,op.unique_vat
  ,op.code
  ,op.card_flag
  ,op.purpose
FROM cntr
INNER JOIN dwh.dwf_account_entry e ON e.contract_idt = cntr.record_idt
  AND e.banking_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy')
INNER JOIN inst i ON i.id = e.institution_id
INNER JOIN oper op ON op.operation_type_id = e.operation_type_id
)
, vat_comm_fee AS (
SELECT /*+ no_merge materialize */
   contract_idt
  ,doc_idt
  ,max(case when origin_group in ('COMM') then fee_rate_value else NULL end)  AS fee_rate_value
  ,sum(case when origin_group in ('TRANS_FEE') then amnt else 0 end)          AS trans_fee
  ,sum(case when origin_group in ('VAT_FEE') then amnt else 0 end)            AS vat_fee
  ,sum(case when origin_group in ('COMM') then amnt else 0 end)               AS comm
  ,sum(case when origin_group in ('VAT_COMM') then amnt else 0 end)           AS vat_comm
  ,sum(case when origin_group in ('ADD_FEE') then amnt else 0 end)            AS add_fee
  ,sum(case when origin_group in ('VAT_ADD_FEE') then amnt else 0 end)        AS vat_add_fee
FROM entries
WHERE origin_group in ('VAT_FEE','TRANS_FEE','VAT_COMM','COMM','ADD_FEE','VAT_ADD_FEE')
group by contract_idt, doc_idt
)
, doc_indicator AS (
SELECT /*+ no_merge */
   e.doc_idt
  ,e.contract_idt
  ,'SLAB_PRICED'             AS entry_flag
FROM entries e
INNER JOIN dwh.dwd_tariff t ON t.record_idt = e.tariff_idt
  AND t.record_date_FROM <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  AND t.record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
WHERE t.role = 'SERVICE'
  AND (t.code like '%ELCRDOMPR%'
    OR t.code like '%MLCRDOMPR%'
    OR t.code like '%ELDBDOMPR%'
    OR t.code like '%MLDBDOMPR%'
  )
)
, transactions AS (
SELECT
   tr.doc_idt
  ,tr.trans_currency
  ,tr.settl_currency
  ,tr.card_brand_id
  ,tr.trans_conditions_id
  ,tr.trans_rrn
  ,tr.trans_arn
  ,tr.trans_date
  ,tr.settl_amount
  ,tr.banking_date
  ,tr.direction
  ,tr.auth_code
  ,tr.source_number
  ,tr.target_channel
  ,tr.target_number
  ,tr.source_contract_idt
  ,tr.settlement_date
  ,CASE
    WHEN instr(tr.add_info, 'FROM_CYBERSOURCE') > 0
      THEN  'Y'
    ELSE    'N'
  END                                                       AS tc33
  ,CASE
    WHEN tr.source_message_code LIKE 'IATA%'
      THEN  'Y'
    ELSE    'N'
  END                                                       AS bsp
  ,CASE
    WHEN tr.source_message_code LIKE '%ARC%'
      THEN  'Y'
    ELSE    'N'
  END                                                       AS arc
  ,SUBSTR(tr.add_info
         ,instr(tr.add_info, 'TRADE_CODE=')+11
         ,(instr(tr.add_info, ';', instr(tr.add_info, 'TRADE_CODE='))
         -instr(tr.add_info, 'TRADE_CODE=')-11))            AS dept_code
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'GN_UNIQUE_ID=')+13
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'GN_UNIQUE_ID='))
        -instr(tr.add_info, 'GN_UNIQUE_ID=')-13))           AS gn_unique_id
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'CS_REQ_REC_ID=')+14
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'CS_REQ_REC_ID='))
        -instr(tr.add_info, 'CS_REQ_REC_ID=')-14))          AS cs_req_rec_id
  ,REPLACE(REPLACE(
    SUBSTR(tr.add_info
          ,instr(tr.add_info, 'RI_TIP_AMOUNT=')+14
          ,(instr(tr.add_info, ';', instr(tr.add_info, 'RI_TIP_AMOUNT='))
          -instr(tr.add_info, 'RI_TIP_AMOUNT=')-14))
    ,chr(10)),chr(13))                                      AS tip_amount
  ,REPLACE(REPLACE(
    SUBSTR(tr.add_info
          ,instr(tr.add_info, 'RI_TAG_ID=')+10
          ,(instr(tr.add_info, ';', instr(tr.add_info, 'RI_TAG_ID='))
          -instr(tr.add_info, 'RI_TAG_ID=')-10))
    ,chr(10)),chr(13))                                      AS tag_id
  ,REPLACE(REPLACE(
    SUBSTR(tr.add_info
          ,instr(tr.add_info, 'RI_DRIVER_ID=') +13
          ,(instr(tr.add_info, ';', instr(tr.add_info, 'RI_DRIVER_ID='))
          -instr(tr.add_info, 'RI_DRIVER_ID=')-13))
    ,chr(10)),chr(13))                                      AS driver_id
  ,REPLACE(REPLACE(
    SUBSTR(tr.add_info
          ,instr(tr.add_info, 'RI_CARD_ID=')+11
          ,(instr(tr.add_info, ';', instr(tr.add_info, 'RI_CARD_ID='))
          -instr(tr.add_info, 'RI_CARD_ID=')-11))
    ,chr(10)),chr(13))                                      AS card_id
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'ARC_TACN=')+9
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'ARC_TACN='))
        -instr(tr.add_info, 'ARC_TACN=')-9))                AS arc_tacn
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'AI_F270=')+8
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'AI_F270='))
        -instr(tr.add_info, 'AI_F270=')-8))                 AS ai_f270
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'AI_F268=')+8
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'AI_F268='))
        -instr(tr.add_info, 'AI_F268=')-8))                 AS ai_f268
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'PURCH_ID=')+9
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'PURCH_ID='))
        -instr(tr.add_info, 'PURCH_ID=')-9))                AS purch_id
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'GWAY_IDT=')+9
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'GWAY_IDT='))
        -instr(tr.add_info, 'GWAY_IDT=')-9))                AS gway_idt
  ,NVL(SUBSTR(tr.add_info
            ,instr(tr.add_info, 'MIGS=')+5
            ,(instr(tr.add_info, ';', instr(tr.add_info, 'MIGS='))
            -instr(tr.add_info, 'MIGS=')-5))
       ,'N')                                                AS migs
  ,NVL(SUBSTR(tr.add_info
          ,instr(tr.add_info, 'PTLF=')+5
          ,(instr(tr.add_info, ';', instr(tr.add_info, 'PTLF='))
          -instr(tr.add_info, 'PTLF=')-5))
       ,'N')                                                AS ptlf
  ,NVL(SUBSTR(tr.add_info
          ,instr(tr.add_info, 'DOMESTIC=')+9
          ,(instr(tr.add_info, ';', instr(tr.add_info, 'DOMESTIC='))
          -instr(tr.add_info, 'DOMESTIC=')-9))
       ,'N')                                                AS domestic
  ,rpad(REPLACE(REPLACE(
      SUBSTR(tr.add_info
            ,instr(tr.add_info, 'ACQ_PRD_1=')+10
            ,(instr(tr.add_info, ';', instr(tr.add_info, 'ACQ_PRD_1='))
            -instr(tr.add_info, 'ACQ_PRD_1=')-10))
      ,chr(10)),chr(13)),34,' ')
   || rpad(REPLACE(REPLACE(
      SUBSTR(tr.add_info
            ,instr(tr.add_info, 'ACQ_PRD_2=')+10
            ,(instr(tr.add_info, ';', instr(tr.add_info, 'ACQ_PRD_2='))
            -instr(tr.add_info, 'ACQ_PRD_2=')-10))
      ,chr(10)),chr(13)),15,' ')                            AS acquirer_data
  ,to_number(NVL(SUBSTR(tr.add_info
            ,instr(tr.add_info, 'TCASHBACK_AMOUNT=')+17
            ,(instr(tr.add_info, ';', instr(tr.add_info, 'TCASHBACK_AMOUNT='))
            -instr(tr.add_info, 'TCASHBACK_AMOUNT=')-17))
       ,'0'))/100                                           AS pwcb_cashback
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'MPGSOrderId=')+12
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'MPGSOrderId='))
        -instr(tr.add_info, 'MPGSOrderId=')-12))            AS MPGSOrderId
  ,NVL(SUBSTR(tr.add_info
            ,instr(tr.add_info, 'UPI_ECOMM=')+10
            ,(instr(tr.add_info, ';', instr(tr.add_info, 'UPI_ECOMM='))
            -instr(tr.add_info, 'UPI_ECOMM=')-10))
       ,'N')                                                AS UPI_ECOMM
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'ORDER_ID=')+9
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'ORDER_ID='))
        -instr(tr.add_info, 'ORDER_ID=')-9))                AS ORDER_ID
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'V1_TKN_RQ_ID=')+13
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'V1_TKN_RQ_ID='))
        -instr(tr.add_info, 'V1_TKN_RQ_ID=')-13))           AS v1_tkn_rq_id
  ,CASE
    WHEN instr(tr.add_info, 'QR_TRAN=Y;') > 0
      THEN  'Y'
    ELSE    'N'
  END AS QR_ENABLED
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'DOMESTIC=')+9
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'DOMESTIC='))
        -instr(tr.add_info, 'DOMESTIC=')-9))                AS DOMESTIC_2
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'CARD_AFS=')+9
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'CARD_AFS='))
        -instr(tr.add_info, 'CARD_AFS=')-9))                AS CARD_AFS
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'GNUSRFLD1=')+10
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'GNUSRFLD1='))
        -instr(tr.add_info, 'GNUSRFLD1=')-10))              AS GNUSRFLD1
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'SOURCE_FIID=')+12
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'SOURCE_FIID='))
        -instr(tr.add_info, 'SOURCE_FIID=')-12))            AS SOURCE_FIID
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'TC33_AUTH_DATE=')+15
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'TC33_AUTH_DATE='))
        -instr(tr.add_info, 'TC33_AUTH_DATE=')-15))         AS TC33_AUTH_DATE
  ,CASE
    WHEN instr(tr.add_info, 'PTLF=Y;') >  0
      THEN  'PTLF'
    WHEN instr(tr.add_info, 'MIGS=Y;') >0
      THEN  'MIGS'
    WHEN instr(tr.add_info, 'WE_CHAT=Y;') >  0
      THEN  'WECHAT'
    WHEN instr(tr.add_info, 'ALI_PAY=Y;') >0
      THEN  'ALIPAY+'
    WHEN instr(tr.add_info, 'FROM_CYBERSOURCE') > 0
      THEN  'CYBERSOURCE'
    WHEN instr(tr.add_info, 'DCC=FEXCO') > 0
      THEN  'FEXCO'
    WHEN instr(tr.add_info, 'DCC=PP;') > 0
      THEN  'PLANET PAYMENT'
    WHEN instr(tr.add_info, 'TDE=Y;') > 0
      THEN  'MANUAL ENTRY'
    WHEN instr(tr.add_info, 'UPI_ECOMM=Y;') >0
      THEN  'UPI_ECOMM'
    WHEN instr(tr.add_info, 'TERRAPAY=Y;') >0
      THEN  'TERRAPAY'
    WHEN tr.target_channel ='NPCI' THEN 'NPCI QR'
    ELSE null
  END                                                       AS CHANNEL
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'MIGSTransNumber=')+16
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'MIGSTransNumber='))
        -instr(tr.add_info, 'MIGSTransNumber=')-16))        AS MIGS_TRANS_NUMBER
  ,SUBSTR(tr.add_info
        ,instr(tr.add_info, 'Q3ORDER_ID=')+11
        ,(instr(tr.add_info, ';', instr(tr.add_info, 'Q3ORDER_ID='))
        -instr(tr.add_info, 'Q3ORDER_ID=')-11))             AS Q3ORDER_ID
FROM (
  SELECT /*+ no_merge leading(e tr) use_nl(e tr) index(tr DWF_TRANSACTION_DOCID_IDX) */
    tr.doc_idt
    ,tr.trans_currency
    ,tr.settl_currency
    ,tr.card_brand_id
    ,tr.trans_conditions_id
    ,tr.trans_rrn
    ,tr.trans_arn
    ,tr.trans_date
    ,tr.settl_amount
    ,tr.banking_date
    ,tr.direction
    ,tr.auth_code
    ,tr.source_number
    ,tr.target_number
    ,tr.source_contract_idt
    ,tr.target_channel
    ,tr.settlement_date
    ,tr.source_message_code
    ,';' || tr.add_info                   AS add_info
  FROM (select distinct doc_idt from entries where origin_group in ('TRANS','ADJ','ADD_FEE')) e
  INNER JOIN dwh.dwf_transaction tr ON tr.doc_idt = e.doc_idt
  INNER JOIN inst i ON i.ID = tr.institution_id
  WHERE tr.banking_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy')
    AND NVL(tr.target_channel,'NO') != 'X'
  ) tr
)
, currency AS (
SELECT /*+ no_merge materialize */
  code
  ,name
FROM dwh.dwd_currency
WHERE record_state = 'A'
)
,  all_items AS (
SELECT /*+ no_merge leading(cntr op tr) use_hash(op cntr) use_nl(tr op) 
use_hash(tr br) use_hash(tr trcond) use_hash(tr br) parallel(4) */
  cntr.personal_account
  ,cntr.merchant_idt
  ,cntr.merchant_name
  ,cntr.location
  ,cntr.telephone
  ,cntr.email
  ,DECODE(op.origin_group,'TRANS',1,'ADJ',2,'ADD_FEE',3,'TRANS_FEE',4,999) as GROUP_NO
  ,op.doc_idt
  ,DECODE(op.card_flag, 1, DECODE(op.contract_idt, tr.source_contract_idt, tr.source_number, tr.target_number),'') AS terminal_id
  ,tr.trans_rrn                                   AS txn_seq_no
  ,trans_curr.NAME                                AS trans_curr
  ,TO_CHAR(tr.trans_date,'dd/mm/yyyy')            AS txn_date
  ,TO_CHAR(tr.trans_date,'dd')                    AS txn_day
  ,TO_CHAR(tr.trans_date,'HH24:MI')               AS txn_hhmm
  ,TO_CHAR(tr.settlement_date,'dd/mm/yyyy')       AS settlement_date
  ,br.payment_scheme                              AS card_type
  ,DECODE(op.card_flag, 1, DECODE(op.contract_idt, tr.source_contract_idt, tr.target_number, tr.source_number),'') AS card_no
  ,LENGTH(trim(DECODE(op.contract_idt, tr.source_contract_idt, tr.target_number, tr.source_number)))               AS card_no_length
  ,tr.auth_code                                   AS auth_code
  ,op.trans_type
  ,NVL(op.amnt,0)                                 AS txn_amount
  ,NVL(op.comm,0)                                 AS commission
  ,NVL(op.vat,0)                                  AS vat
  ,(NVL(op.amnt,0) + NVL(op.comm,0) + NVL(op.vat,0)) AS net_amount
  ,tr.acquirer_data
  ,tr.trans_rrn                                   AS ret_ref_no
  ,cntr.store_type
  ,cntr.bank_account
  ,TO_CHAR(tr.trans_date, 'HH24:MI:SS')           AS TIME
  ,cntr.gc_chain1
  ,cntr.master_chain1
  ,tr.pwcb_cashback
  ,CASE
    WHEN crd.ni_sup_ips_card_type       != 0
    AND NVL(br.payment_scheme_code,'NA') = 'E'
      THEN 'M/TVL'
    WHEN crd.ni_sup_ips_card_type       != 0
    AND NVL(br.payment_scheme_code,'NA') = 'V'
      THEN 'V/TVL'
    WHEN crd.ni_int_ips_card_type != 0
    AND cntr.rprc = 'Y'
    AND tr.domestic               != 'Y'
      THEN 'PREMIUM'
    WHEN crd.ni_dom_ips_card_type != 0
      THEN 'PREMIUM'
    ELSE 'STANDARD'
  END AS trn_typ
  ,CASE
    WHEN crd.ni_sup_ips_card_type       != 0
    AND NVL(br.payment_scheme_code,'NA') = 'E'
      THEN 'MT'
    WHEN crd.ni_sup_ips_card_type       != 0
    AND NVL(br.payment_scheme_code,'NA') = 'V'
      THEN 'VT'
    WHEN crd.ni_int_ips_card_type != 0
    AND cntr.rprc = 'Y'
    AND tr.domestic               != 'Y'
      THEN 'P'
    WHEN crd.ni_dom_ips_card_type != 0
      THEN 'P'
    ELSE 'S'
  END AS pr_st
  ,DECODE(tr.direction, 1, 'C', 'D') AS tran_ind
  ,DECODE(tr.direction, 1, 'D', 'C') AS comm_ind
  ,CASE
    WHEN trcond.condition_list LIKE '%,KEY_ENTRY,%'
      THEN 'M'
    ELSE 'E'
  END AS man_elec
  ,tr.banking_date
  ,tr.settl_amount
  ,TO_CHAR(tr.trans_date,'ddmmyyyy') AS undel_date
  ,TO_CHAR(tr.trans_date,'HH24:MI')  AS short_time
  ,tr.trans_currency
  ,CASE
    WHEN NVL(br.payment_scheme_code,'NA') = 'E'
      THEN
        CASE
          WHEN crd.ni_sup_ips_card_type != 0
            THEN 'M/TVL'
          WHEN crd.ni_int_ips_card_type != 0
          AND cntr.rprc = 'Y'
          AND tr.domestic               != 'Y'
            THEN 'MC-PREM'
          WHEN crd.ni_dom_ips_card_type != 0
            THEN 'MC-PREM'
          ELSE 'MC-STND'
        END
    WHEN NVL(br.payment_scheme_code,'NA') = 'V'
      THEN
        CASE
          WHEN crd.ni_sup_ips_card_type != 0
            THEN 'V/TVL'
          WHEN crd.ni_int_ips_card_type != 0
          AND cntr.rprc = 'Y'
          AND tr.domestic               != 'Y'
            THEN 'VISA-PREM'
          WHEN crd.ni_dom_ips_card_type != 0
            THEN 'VISA-PREM'
          ELSE 'VISA-STND'
        END
    ELSE
      CASE
        WHEN br.payment_scheme_code = 'O'
          THEN 'PRIVATE LABEL'
        ELSE upper(SUBSTR(br.payment_scheme,1,DECODE(instr(br.payment_scheme,' ',1),0,LENGTH(br.payment_scheme),instr(br.payment_scheme,' ',1)-1)))
      END
  END AS crd_pr_st
  ,br.payment_scheme_code
  ,tr.trans_arn
  ,NVL(tr.dept_code,'N')              AS dept_code
  ,DECODE(tr.domestic,'Y','DOM','INT') AS dom_int
  ,tr.migs
  ,tr.ptlf
  ,tr.tc33
  ,tr.bsp
  ,tr.arc
  ,tr.arc_tacn
  ,tr.ai_f270
  ,tr.ai_f268
  ,tr.purch_id
  ,tr.gway_idt
  ,tr.trans_rrn
  ,tr.cs_req_rec_id
  ,tr.tip_amount
  ,tr.tag_id
  ,tr.driver_id
  ,tr.card_id
  ,cntr.mult
  ,tr.gn_unique_id
  ,cntr.addr_state
  ,tr.MPGSOrderId
  ,tr.ORDER_ID
  ,tr.UPI_ECOMM
  ,tr.v1_tkn_rq_id
  ,tr.QR_ENABLED
  ,tr.DOMESTIC_2
  ,tr.CARD_AFS
  ,tr.SOURCE_FIID
  ,tr.CHANNEL
  ,tr.GNUSRFLD1
  ,CASE
  WHEN tr.TC33_AUTH_DATE IS NOT NULL 
    AND ('1231' = to_char(to_date(tr.TC33_AUTH_DATE, 'mmdd'),'mmdd')
      OR '1230' = to_char(to_date(tr.TC33_AUTH_DATE, 'mmdd'), 'mmdd')
    ) AND '0101' = to_char(to_date(tr.trans_date,'dd/mm/yy'),'mmdd')
    THEN to_char(to_date(tr.TC33_AUTH_DATE, 'mmdd'), 'dd/mm')  || '/' || (TO_CHAR(tr.trans_date, 'yyyy')-1)
  WHEN tr.TC33_AUTH_DATE IS NOT NULL
    THEN to_char(to_date(tr.TC33_AUTH_DATE, 'mmdd'), 'dd/mm')  || '/' || TO_CHAR(tr.trans_date, 'yyyy')
    ELSE ''
  END                           AS auth_date
  ,doi.entry_flag
  ,CASE
    WHEN br.payment_scheme_code = 'V'
      THEN 'VISA-'
    WHEN br.payment_scheme_code = 'E'
      THEN 'MC-'
    ELSE    ' '
  END                           AS chnl
  ,tr.MIGS_TRANS_NUMBER
  ,tr.Q3ORDER_ID
FROM cntr
INNER JOIN (
  /*TRANS, ADJ*/
  SELECT
    e.merchant_idt
    ,e.contract_idt
    ,e.doc_idt
    ,e.amnt
    ,vcf.comm
    ,vcf.vat_comm     AS vat
    ,e.origin_group
    ,e.code
    ,e.narration      AS trans_type
    ,e.card_flag
  FROM entries e
  LEFT JOIN vat_comm_fee vcf on vcf.doc_idt = e.doc_idt
  WHERE e.accounted = 1
    AND e.origin_group in ('TRANS','ADJ')

  UNION ALL

  /*ADD_FEE*/
  SELECT
    e.merchant_idt
    ,e.contract_idt
    ,e.doc_idt
    ,e.amnt
    ,0                AS comm
    ,vcf.vat_fee      AS vat
    ,e.origin_group
    ,e.code
    ,e.narration      AS trans_type
    ,e.card_flag
  FROM entries e
  LEFT JOIN vat_comm_fee vcf on vcf.doc_idt = e.doc_idt
  WHERE e.accounted = 1
    AND e.origin_group in ('ADD_FEE')
    AND e.UNIQUE_VAT != 1

  UNION ALL

  /*ADD_FEE WITH UNIQUE VAT*/
  SELECT
    e.merchant_idt
    ,e.contract_idt
    ,e.doc_idt
    ,e.amnt
    ,0                AS comm
    ,vcf.vat_add_fee  AS vat
    ,e.origin_group
    ,e.code
    ,e.narration      AS trans_type
    ,e.card_flag
  FROM entries e
  LEFT JOIN vat_comm_fee vcf on vcf.doc_idt = e.doc_idt
  WHERE e.accounted = 1
    AND e.origin_group in ('ADD_FEE')
    AND e.UNIQUE_VAT = 1

  UNION ALL

  /*TRANS_FEE*/
  SELECT
    e.merchant_idt
    ,NULL             AS contract_idt
    ,0                AS doc_idt
    ,sum(e.amnt)      AS amnt
    ,0 AS comm
    ,sum(vcf.vat_fee) AS vat
    ,e.origin_group
    ,null             AS code
    ,'TRANS FEE'      AS trans_type
    ,0                AS card_flag
  FROM entries e
  LEFT JOIN vat_comm_fee vcf on vcf.doc_idt = e.doc_idt
  WHERE e.accounted != 1
    AND e.origin_group in ('TRANS_FEE')
  GROUP BY e.merchant_idt, e.origin_group
) op ON op.merchant_idt = cntr.merchant_idt
    AND cntr.code = 'MERCHANT'
LEFT JOIN transactions tr ON tr.doc_idt = op.doc_idt
LEFT JOIN currency trans_curr ON trans_curr.code = tr.trans_currency
LEFT JOIN dwh.dwd_card_brand br ON br.ID = tr.card_brand_id
LEFT JOIN card_brand crd ON br.code = crd.card_brand_code
LEFT JOIN dwh.dwd_trans_conditions trcond ON tr.trans_conditions_id = trcond.ID
  AND trcond.record_date_FROM <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
  AND trcond.record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
LEFT JOIN doc_indicator doi ON doi.doc_idt = op.doc_idt
)
, totals as (
SELECT
   personal_account                     AS merchant_id
  ,count(1)                             AS txn_count
  ,sum(txn_amount)                      AS txn_amount
  ,sum(commission)                      AS commission
  ,sum(vat)                             AS vat
  ,sum(net_amount)   AS net_amount
FROM all_items
GROUP BY personal_account
)
SELECT
  :ORG                                         as ORG
  ,case when SECTION_NO = 1 then rpad(SRL, 5, ' ') else lpad(SRL, 5, ' ') end as SRL
  ,rpad(MERCHANT_ID,11,' ')                    as MERCHANT_ID
  ,rpad(NVL(MASTER_CHAIN1,' '),9,' ')          as MASTER_CHAIN1
  ,rpad(NVL(MERCHANT_NAME,' '),40,' ')         as MERCHANT_NAME
  ,rpad(NVL(LOCATION,' '),40,' ')              as LOCATION
  ,rpad(NVL(TELEPHONE,' '),15,' ')             as TELEPHONE
  ,rpad(NVL(TERMINAL_ID,' '),12,' ')           as TERMINAL_ID
  ,rpad(NVL(SEQ_NO,' '),10,' ')                as SEQ_NO
  ,rpad(NVL(TRANS_CURR,' '),5,' ')             as TRANS_CURR
  ,rpad(NVL(TXN_DATE,' '),10,' ')              as TXN_DATE
  ,rpad(NVL(CARD_TYPE,' '),15,' ')             as CARD_TYPE
  ,rpad(NVL(CARD_NO,' '),19,' ')               as CARD_NO
  ,rpad(NVL(AUTH_CODE,' '),13,' ')             as AUTH_CODE
  ,rpad(NVL(TRANS_TYPE,' '),20,' ')            as TRANS_TYPE
  ,lpad(TXN_AMOUNT,12,' ')                     as TXN_AMOUNT
  ,lpad(COMMISSION,10,' ')                     as COMMISSION
  ,lpad(VAT,10,' ')                            as VAT
  ,lpad(NET_AMOUNT,12,' ')                     as NET_AMOUNT
  ,rpad(NVL(ACQUIRER_DATA,' '),49,' ')         as ACQUIRER_DATA
  ,rpad(NVL(RET_REF_NO,' '),12,' ')            as RET_REF_NO
  ,rpad(NVL(STORE_TYPE,' '),2,' ')             as STORE_TYPE
  ,rpad(NVL(BANK_ACCOUNT,' '),30,' ')          as BANK_ACCOUNT
  ,lpad(TRAN_TYPE_IND||lpad(' ',round((13-length(TRAN_TYPE_IND))/2,0),' '),13,' ') as TRAN_TYPE_IND
  ,NULL AS FILLER
FROM
(
--HEADER RECORD 1
SELECT
   merchant_id          as MID
  ,1                    as SECTION_NO
  ,1                    as RECORD_NO
  ,'SRL'                as SRL
  ,'MERCHANT ID'        as MERCHANT_ID
  ,'CHAIN-ID'           as MASTER_CHAIN1
  ,'MERCHANT NAME'      as MERCHANT_NAME
  ,'LOCATION'           as LOCATION
  ,'TELEPHONE'          as TELEPHONE
  ,'TERMINAL'           as TERMINAL_ID
  ,'SEQUENCE'           as SEQ_NO
  ,'TRAN'               as TRANS_CURR
  ,'TRAN'               as TXN_DATE
  ,'CARD'               as CARD_TYPE
  ,'CREDIT CARD'        as CARD_NO
  ,'AUTHORIZATION'      as AUTH_CODE
  ,'TRAN'               as TRANS_TYPE
  ,'SALES'              as TXN_AMOUNT
  ,'COMMISSION'         as COMMISSION
  ,'VAT'                as VAT
  ,'NET'                as NET_AMOUNT
  ,'ACQUIRER DATA'      as ACQUIRER_DATA
  ,'REFERENCE NO'       as RET_REF_NO
  ,'TY'                 as STORE_TYPE
  ,'BANK ACCOUNT'       as BANK_ACCOUNT
  ,'TRAN TYPE IND'      as TRAN_TYPE_IND
FROM totals

UNION ALL

--HEADER RECORD 2
SELECT
   merchant_id          as MID
  ,1                    as SECTION_NO
  ,2                    as RECORD_NO
  ,'NO.'                as SRL
  ,' '                  as MERCHANT_ID
  ,' '                  as MASTER_CHAIN1
  ,' '                  as MERCHANT_NAME
  ,' '                  as LOCATION
  ,' '                  as TELEPHONE
  ,'ID'                 as TERMINAL_ID
  ,'NUMBER'             as SEQ_NO
  ,'CURR.'              as TRANS_CURR
  ,'DATE'               as TXN_DATE
  ,'TYPE'               as CARD_TYPE
  ,'NUMBER'             as CARD_NO
  ,'CODE'               as AUTH_CODE
  ,'TYPE'               as TRANS_TYPE
  ,'AMOUNT'             as TXN_AMOUNT
  ,' '                  as COMMISSION
  ,'AMOUNT'             as VAT
  ,'AMOUNT'             as NET_AMOUNT
  ,' '                  as ACQUIRER_DATA
  ,' '                  as RET_REF_NO
  ,' '                  as STORE_TYPE
  ,' '                  as BANK_ACCOUNT
  ,' '                  as TRAN_TYPE_IND
FROM totals

UNION ALL

--BODY RECORDS
SELECT
   personal_account                 AS MID
  ,2                                AS SECTION_NO
  ,row_number() over(partition by personal_account order by personal_account, GROUP_NO, CARD_TYPE, TRANS_TYPE) as RECORD_NO
  ,to_char(row_number() over(partition by personal_account order by personal_account, GROUP_NO, CARD_TYPE, TRANS_TYPE)) as SRL
  ,SUBSTR(personal_account,-9)      AS MERCHANT_ID
  ,SUBSTR(master_chain1,-9)         AS MASTER_CHAIN1
  ,merchant_name
  ,location
  ,telephone
  ,trim(SUBSTR(terminal_id,1,12))   AS TERMINAL_ID
  ,SUBSTR(txn_seq_no,3,10)          AS SEQ_NO
  ,trans_curr
  ,txn_date
  ,CASE
    WHEN payment_scheme_code = 'V' AND QR_ENABLED = 'Y'
      THEN 'VISA QR'
    WHEN payment_scheme_code = 'E' AND QR_ENABLED = 'Y'
      THEN 'MC QR'
    WHEN payment_scheme_code = 'O'
      THEN 'PRIVATE LABEL'
    WHEN payment_scheme_code = 'H'
      THEN 'CHINA UNION PAY'
    WHEN CHANNEL = 'TERRAPAY'
      THEN 'TERRAPAY'
    WHEN CHANNEL = 'NPCI QR'
      THEN 'NPCI QR'
    ELSE upper(SUBSTR(card_type,1,DECODE(instr(card_type,' ',1),0,LENGTH(card_type),instr(card_type,' ',1)-1)))
  END                               AS CARD_TYPE
  ,SUBSTR(card_no,1,6) || lpad('X',DECODE(card_no_length,13,3,14,4,15,5,16,6,17,7,18,8,19,9,3),'X')
  || SUBSTR(card_no,-4)             AS CARD_NO
  ,AUTH_CODE
  ,TRANS_TYPE
  ,to_char(txn_amount)              AS TXN_AMOUNT
  ,to_char(commission)              AS COMMISSION
  ,to_char(vat)                     AS VAT
  ,to_char(net_amount)              AS NET_AMOUNT
  ,CASE
    WHEN arc = 'Y'
      THEN arc_tacn || ai_f270
    WHEN migs = 'Y'
      THEN
        CASE
          WHEN gc_chain1 = 'KSA'
            THEN SUBSTR(acquirer_data,1,34)
          WHEN acquirer_data IS NULL
            THEN rpad(SUBSTR(ai_f270,0,13),34,' ') || SUBSTR(ai_f268,0,6)
          WHEN gc_chain1 = 'SDG'
            THEN SUBSTR(acquirer_data,0,12)
          ELSE acquirer_data
        END
    WHEN bsp = 'Y'
      THEN SUBSTR(ai_f270,0,13)
    WHEN ptlf = 'Y'
      THEN
        CASE
          WHEN SOURCE_FIID = 'NGEN'
            THEN rpad(trans_rrn,12,' ')
          ELSE
            rpad(tip_amount,12,' ')
            || rpad(driver_id,10,' ')
            || rpad(tag_id,10,' ')
            || rpad(card_id,17,' ')
        END
    WHEN tc33 = 'Y'
      THEN
        CASE
          WHEN addr_state = 'A'
            THEN rpad(purch_id,25,' ') || rpad(trans_rrn,12,' ')
          WHEN addr_state = 'D'
            THEN rpad(cs_req_rec_id,26,' ')
          WHEN gway_idt = 'NO' 
            THEN
              CASE 
                WHEN trans_rrn IS NULL
                  THEN '$' || txn_day || txn_hhmm
                ELSE rpad(purch_id,25,' ') || rpad(trans_rrn,12,' ')
              END
          ELSE rpad(purch_id,25,' ')
        END
    ELSE acquirer_data
  END                               AS ACQUIRER_DATA
  ,RET_REF_NO
  ,lpad(store_type,2,'0')           AS STORE_TYPE
  ,trim(bank_account)               AS BANK_ACCOUNT
  ,(CASE
    WHEN entry_flag = 'SLAB_PRICED'
      THEN
        CASE
          WHEN DOMESTIC_2 = 'Y' AND CARD_AFS = 'C'
            THEN DECODE(man_elec,'M','MAN','E','ELC') || '/C'
          ELSE DECODE(man_elec,'M','MAN','E','ELC')
        END
    WHEN pr_st IN ('MT','VT')
      THEN pr_st
    ELSE man_elec || pr_st
  END) || 
  (CASE
    WHEN DOMESTIC_2 = 'Y' AND CARD_AFS = 'D'
    THEN '/D'
    ELSE ''
  END)                              AS TRAN_TYPE_IND
FROM all_items

UNION ALL

--TRAILER RECORD
SELECT
   merchant_id          as MID
  ,3                    as SECTION_NO
  ,1                    as RECORD_NO
  ,to_char(txn_count)   as SRL
  ,' '                  as MERCHANT_ID
  ,'000000000'          as MASTER_CHAIN1
  ,'MERCHANT TOTALS >>>' as MERCHANT_NAME
  ,' '                  as LOCATION
  ,' '                  as TELEPHONE
  ,' '                  as TERMINAL_ID
  ,' '                  as SEQ_NO
  ,' '                  as TRANS_CURR
  ,' '                  as TXN_DATE
  ,' '                  as CARD_TYPE
  ,' '                  as CARD_NO
  ,' '                  as AUTH_CODE
  ,' '                  as TRANS_TYPE
  ,to_char(txn_amount)  as TXN_AMOUNT
  ,to_char(commission)  as COMMISSION
  ,to_char(vat)         as VAT
  ,to_char(net_amount)  as NET_AMOUNT
  ,' '                  as ACQUIRER_DATA
  ,' '                  as RET_REF_NO
  ,' '                  as STORE_TYPE
  ,' '                  as BANK_ACCOUNT
  ,' '                  as TRAN_TYPE_IND
FROM totals
)
ORDER BY MID, SECTION_NO, RECORD_NO
