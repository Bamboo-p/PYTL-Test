/*
* AQ POS REFUND REPORT
*
* Version history:
* 240213.1 = HamzaHendi = NIBOA-9197 : Initial Version
* 240215.1 = HamzaHendi = NIBOA-9197 : adding the missing fields
* 240215.2 = HamzaHendi = NIBOA-9197 : fixing query bug
* 240226.1 = HamzaHendi = NIBOA-9630 : bug fixing (adding ORG and fix terminal_id)
* 240226.2 = HamzaHendi = NIBOA-9630 : bug fixing (change mcc retrieving logic)
* 240227.1 = HamzaHendi = NIBOA-9630 : bug fixing modify output aliases
* 240228.1 = HamzaHendi = NIBOA-9630 : adding file name column
* 240229.1 = HamzaHendi = NIBOA-9630 : bug fixing file name date format
* 240229.2 = HamzaHendi = NIBOA-9630 : bug fixing modify output aliases
* 240301.1 = HamzaHendi = NIBOA-9630 : refactoring the query
* 240301.2 = HamzaHendi = NIBOA-9630 : adding INST_ID
* 240304.1 = HamzaHendi = NIBOA-9630 : returning the header only if there is transactions 
* 240304.2 = HamzaHendi = NIBOA-9630 : bug fixing returning the header only if there is transactions 
* 240405.1 = PrabirK    = NIBOA-9891 : update schema name and logic change to get AUTH_CODE from original retail doc
* 240405.2 = PrabirK    = NIBOA-9891 : remove header and trans amount correction
* 240510.1 = HamzaHendi = NIBOA-9741 : including Jaywan target bin group
* 240529.1 = Khader     = NIBOA-10219,PRD-27693: Filter to check outwrd status
* 240604.1 = Khader     = NIBOA-10287,PRD-27693: outward status tag update 
* 240607.1 = PrabirK    = NIBOA-10287,PRD-27693: Change input parameter to P_TRACE_ID1
* 240617.1 = PrabirK    = NIBOA-10287,PRD-27693: Fetching Refund(Normal, Recovery) record from Way4
*/
with
inst as (
select  fi.id
       ,fi.bank_code
from ows.f_i fi
where fi.bank_code = :ORG
and fi.amnd_state = 'A'
)
, transtype as (
select 
       t.id
      ,t.name
from ows.trans_type t
where t.amnd_state = 'A'
and t.trans_code in ('K1','DCCK1')
)
, contract as (
select  inst.bank_code
       ,mer.id as merchant_idt
       ,mer.contract_number as merchant_number
       ,dev.id as device_idt
       ,dev.contract_number as device_number
from ows.acnt_contract mer
join inst
on inst.id = mer.f_i
join ows.acnt_contract dev
on dev.liab_contract = mer.id
and dev.amnd_state = 'A'
and dev.f_i in (select id from inst)
and dev.pcat = 'M'
and dev.con_cat = 'M'
and dev.ccat = 'C'
and instr(dev.contract_number,'POS') = 0
where mer.amnd_state = 'A'
and mer.pcat = 'M'
and mer.con_cat = 'A'
and mer.ccat = 'C'
) 
, address as (
select 
       cadr.acnt_contract__oid as contract_idt
      ,cadr.address_line_1 as merch_name
from ows.client_address cadr
join ows.address_type adtp
on adtp.id = cadr.address_type
and adtp.code = 'STMT_ADDR'
and adtp.amnd_state = 'A'
where cadr.amnd_state = 'A'
)
, trans as (
select 
       dc.source_contract
      ,dc.target_number
      ,dc.source_number
      ,dc.trans_date
      ,dc.trans_amount
      ,dc.trans_curr
      ,substr(bin.bin_details, instr(bin.bin_details, 'ISS_INST_ID=') 
       + length('ISS_INST_ID='),instr(bin.bin_details,';',instr(bin.bin_details, 'ISS_INST_ID=')) 
       - instr(bin.bin_details, 'ISS_INST_ID=') - LENGTH('ISS_INST_ID=')) as iss_inst_id
      ,dc.ret_ref_number
      ,dc.sic_code
      ,dc.auth_code
from ows.dm_collection dm
join ows.dm_record dr
on dr.dm_collection__oid = dm.id
join ows.doc dc
on dc.id = dr.marked_id
and dc.amnd_state = 'A'
and dc.posting_status = 'P'
and dc.outward_status = 'C'
and substr(dc.add_info,instr(dc.add_info,'TGT_BIN_GR=')
    + length('TGT_BIN_GR='),instr(dc.add_info,';',instr(dc.add_info,'TGT_BIN_GR='))
    - instr(dc.add_info,'TGT_BIN_GR=') - length('TGT_BIN_GR='))
    in (select trim(regexp_substr(:P_TGT_BIN_GR, '[^,]+', 1, level)) P_TGT_BIN_GR
         from dual
         connect by regexp_substr(:P_TGT_BIN_GR, '[^,]+', 1, level) is not null
        ) 
and substr(dc.add_info, instr( dc.add_info, 'DOC_ST=')
    + length('DOC_ST='), (instr(dc.add_info, ';', instr(dc.add_info, 'DOC_ST='))
	- instr(dc.add_info, 'DOC_ST=')- length('DOC_ST=')))  = 'C'
join transtype tt
on tt.id = dc.trans_type
left join ows.bin_table bin
on bin.id = dc.bin_record
and bin.amnd_state = 'A'
where dm.scope = 'HOLD_REFUND_CLEARING'
and dm.table_code = 'DOC'
and dm.path = 'RELEASED'
and dm.name = 'HOLD_REFUND_RELEASED_' || to_char(to_date(:P_REPORT_DATE,'DD-MM-YYYY') - :P_DAYS_AGO,'YYYYMMDD')
and dm.amnd_state = 'A'
)
, trans_full as (
select 
       decode(cnt.device_idt, trn.source_contract, trn.target_number, trn.source_number) as pan
      ,to_char(trn.trans_date, 'mmddyyyy') as local_date
      ,to_char(trn.trans_date , 'hhmmss') as local_time
      ,lpad(replace(to_char(trn.trans_amount,'FM999999990D00'), '.',''), 12 , 0) as trans_amount
      ,trn.trans_curr
      ,:P_ACQ_INST_ID as acq_inst_id
      ,trn.iss_inst_id as issuer_inst_id
      ,trn.ret_ref_number as rrn
      ,'UAP' as issuing_network
      ,trn.sic_code as mcc
      ,784 acq_country_code
      ,trn.auth_code
      ,trn.source_number as terminal_id
      ,adr.merch_name as card_acceptor_name
      ,cnt.merchant_number as card_acceptor_id_code
      ,cnt.merchant_number as retailer_id
      ,null  as user_fld_1
      ,null  as user_fld_2
      ,null  as user_fld_3
      ,trn.auth_code as orig_retail_doc
      ,cnt.bank_code
from contract cnt
join trans trn
on trn.source_contract = cnt.device_idt
left join address adr
on adr.contract_idt  = cnt.merchant_idt
)

select 
      :ORG as org
     ,to_char(pan) as PAN
     ,to_char(local_date) as LOCAL_DATE
     ,to_char(local_time) as LOCAL_TIMEs
     ,to_char(trans_amount) as TRAN_AMOUNT
     ,to_char(trans_curr) as TRAN_CURRENCY
     ,to_char(acq_inst_id) as ACQ_INST_ID
     ,to_char(issuer_inst_id) as ISSUER_INST_ID
     ,to_char(rrn) RRN
     ,to_char(row_number() over (partition by bank_code order by local_date) + to_number(:P_TRACE_ID)) as TRACE
     ,to_char(issuing_network) as ISSUING_NETWORK
     ,to_char(mcc) MCC
     ,to_char(acq_country_code) as ACQ_COUNTRY_CODE
     ,to_char(coalesce(orig_retail_doc,'000000')) AUTHCODE
     ,to_char(terminal_id) as TERMINAL_ID
     ,to_char(card_acceptor_name) as CARD_ACCEPTOR_NAME
     ,to_char(card_acceptor_id_code) as CARD_ACCEPTOR_ID
     ,to_char(retailer_id) as RETAILER_ID
     ,to_char(user_fld_1) as USER_FLD_1
     ,to_char(user_fld_2) as USER_FLD_2
     ,to_char(user_fld_3) as USER_FLD_3
     ,:P_FILE_PREFIX || :P_CLIENT || '_' || :P_INST_ID || '_' || TO_CHAR(SYSDATE,'YYYYMMDDHHMISS') FILE_NAME
FROM trans_full