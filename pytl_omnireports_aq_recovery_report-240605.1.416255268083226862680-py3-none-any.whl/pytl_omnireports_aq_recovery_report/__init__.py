__version__ = "240605.1"
__job_name__ = "PyTL_OmniReports_AQ_RECOVERY_REPORT"
__bat_files__ = []
