/*
* Code for AQ_RECOVERY_REPORT
* PyTL_OmniReports_AQ_RECOVERY_REPORT = AQ_RECOVERY_REPORT_HEADER.sql
* Version history:
* 231221.1 : NIBOA-9285,NIBOA-9286 : PrabirK : Initial development
*/

select 
       :ORG                                                           as org,
       '000'||code                                                    as sender,
       to_char(sysdate ,'YYYY-MM-DD')                                 as creationdate,
       to_char(sysdate ,'HH24.MI.SS')                                 as creationtime,
       code||to_char(sysdate ,'YYMMDD')||to_char(sysdate ,'HH24MISS') as fileseqnum,
       code                                                           as receiver,
	   to_date(:P_REPORT_DATE, 'DD-MM-YYYY')                          as reportdate,
	   :P_REPORT_TYPE                                                 as reporttype
from dwh.dwd_institution
where record_state = 'A'
and code = :ORG