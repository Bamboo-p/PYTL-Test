__version__ = "240603.1"
__job_name__ = "PyTL_OmniReports_AQ_TABBY_FEE_REPORT"
__bat_files__ = ["PyTL_AQ_TABBY_FEE_REPORT.bat"]
