/*
240529.1: PrabirK : NIBOA-10082 : initial version
240530.1: PrabirK : NIBOA-10250 : Correction in SQL
240602.1: PrabirK : NIBOA-10250 : GROSS_COUNT field addition
240603.1: PrabirK : NIBOA-10250 : Logic change in SLAB range
*/
with 
slabs as (
SELECT  t.code
       ,st.fee_min_amount
       ,DECODE(st.fee_max_amount,0,999999999999999999,st.fee_max_amount)    as fee_max_amount
       ,st.fee_rate_value
       ,case
         when t.code = 'ACQ_TABBY_SALE_TIER_1' then '< USD 2Mn (AED 7,300,000)'
         when t.code = 'ACQ_TABBY_SALE_TIER_2' then 'USD 2-3 Mn (AED 7,300,000 – 10,950,000)'
         when t.code = 'ACQ_TABBY_SALE_TIER_3' then 'USD 3-4 Mn (AED 10,950,000 – 14,600,000)'
         when t.code = 'ACQ_TABBY_SALE_TIER_4' then 'USD 4 Mn + (AED 14,600,000 above)'
        end as tier_slab_desc
FROM dwh.dwd_tariff t
INNER JOIN dwh.dwd_service_tariff st on st.record_idt = t.record_idt
  AND st.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
  AND st.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
WHERE t.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
  AND t.record_date_to   >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
  AND t.type_code = 'ACQ_TABBY_SALE'
  AND t.role = 'SERVICE'
  AND SUBSTR(t.domain, 0, instr(t.domain, '-')-1) = :ORG
)
, tabby_data as (
SELECT  s.org
       ,s.cnt
       ,s.trans_amnt
       ,s.pcnt_fee
       ,s.fxd_fee
       ,s.vat_rate
       ,s.cum_amnt
       ,s.trans_group
       ,(SELECT sl.code
           FROM slabs sl
           WHERE abs(s.cum_amnt) > sl.fee_min_amount 
             AND abs(s.cum_amnt) <= sl.fee_max_amount)                       as tier_slab 
       ,(SELECT sl.fee_rate_value
           FROM slabs sl
           WHERE abs(s.cum_amnt) > sl.fee_min_amount 
             AND abs(s.cum_amnt) <= sl.fee_max_amount)                       as tier_pcnt       
FROM (
SELECT  sa.org
       ,sa.doc_idt
       ,1                                                                   as cnt
       ,sa.trans_amnt                                                       as trans_amnt
       ,(sa.trans_amnt*sa.tabby_sal_rate)/100                               as pcnt_fee
       ,sa.tabby_sal_base                                                   as fxd_fee
       ,sa.vat_rate
       ,SUM(sa.trans_amnt) OVER (order by sa.doc_idt)                       as cum_amnt
       ,sa.trans_group
FROM OPT_ACQ_TABBY_FEE_DATA sa
WHERE sa.org = :ORG
  AND sa.trans_group = 'SALE'
UNION
SELECT  re.org
       ,re.doc_idt
       ,1                                                                   as cnt
       ,re.trans_amnt                                                       as trans_amnt
       ,(re.trans_amnt*re.tabby_ref_rate)/100                               as pcnt_fee
       ,re.tabby_ref_base                                                   as fxd_fee
       ,re.vat_rate
       ,SUM(re.trans_amnt) OVER (order by re.doc_idt)                       as cum_amnt
       ,re.trans_group
FROM OPT_ACQ_TABBY_FEE_DATA re
WHERE re.org = :ORG
  AND re.trans_group = 'REFUND'
) s
)
, tabby_aggr as (
SELECT  td.org
       ,td.tier_slab
       ,td.vat_rate
       ,td.tier_pcnt
       ,SUM(DECODE(td.trans_group,'SALE',cnt,0))                            as sale_count
       ,SUM(DECODE(td.trans_group,'SALE',TRANS_AMNT,0))                     as sale_amnt
       ,SUM(DECODE(td.trans_group,'SALE',PCNT_FEE,0))                       as sale_pcnt_fee
       ,SUM(DECODE(td.trans_group,'SALE',PCNT_FEE,0)*VAT_RATE)/100          as sale_pcnt_vat
       ,SUM(DECODE(td.trans_group,'SALE',FXD_FEE,0))                        as sale_fxd_fee
       ,SUM(DECODE(td.trans_group,'SALE',FXD_FEE,0)*VAT_RATE)/100           as sale_fxd_vat
       ,SUM(DECODE(td.trans_group,'REFUND',cnt,0))                          as ref_count
       ,SUM(DECODE(td.trans_group,'REFUND',TRANS_AMNT,0))                   as ref_amnt
       ,SUM(DECODE(td.trans_group,'REFUND',PCNT_FEE,0))                     as ref_pcnt_fee
       ,SUM(DECODE(td.trans_group,'REFUND',PCNT_FEE,0)*VAT_RATE)/100        as ref_pcnt_vat
       ,SUM(DECODE(td.trans_group,'REFUND',FXD_FEE,0))                      as ref_fxd_fee
       ,SUM(DECODE(td.trans_group,'REFUND',FXD_FEE,0)*VAT_RATE)/100         as ref_fxd_vat
       ,row_number() over(partition by td.ORG order by td.TIER_SLAB)        as ser_num
FROM tabby_data td
group by td.org
        ,td.tier_slab
        ,td.vat_rate
        ,td.tier_pcnt
)

select  ta.org
       ,to_char(to_date(:P_REPORT_DATE, 'DD-MM-YYYY')-1,'Mon-YY')                           as mon_yy
       ,ta.tier_pcnt                                                                        
       ,(select slb.tier_slab_desc from slabs slb where slb.code = ta.tier_slab)            as tier_slab
       ,ta.sale_count                                                                       
       ,ta.sale_amnt                                                                        
       ,ta.sale_pcnt_fee                                                                    
       ,ta.sale_pcnt_vat                                                                    
       ,ta.sale_fxd_fee                                                                     
       ,ta.sale_fxd_vat                                                                     
       ,ta.ref_count                                                                        
       ,abs(ta.ref_amnt)                                                                    as ref_amnt
       ,abs(ta.ref_pcnt_fee)                                                                as ref_pcnt_fee
       ,abs(ta.ref_pcnt_vat)                                                                as ref_pcnt_vat
       ,abs(ta.ref_fxd_fee)                                                                 as ref_fxd_fee                                
       ,abs(ta.ref_fxd_vat)                                                                 as ref_fxd_vat
	   ,(ta.sale_count - ta.ref_count)                                                      as gross_count
       ,(ta.sale_amnt - abs(ta.ref_amnt))                                                   as gross_sale
       ,((ta.sale_pcnt_fee + ta.sale_fxd_fee)-(abs(ta.ref_pcnt_fee)+ abs(ta.ref_fxd_fee)))  as total_fee
       ,((ta.sale_pcnt_vat + ta.sale_fxd_vat)-(abs(ta.ref_pcnt_vat) + abs(ta.ref_fxd_vat))) as total_vat
       ,(((ta.sale_amnt - abs(ta.ref_amnt))*ta.tier_pcnt)/100)                              as ni_rev_share
       ,(((((ta.sale_amnt - abs(ta.ref_amnt))*ta.tier_pcnt)/100)*ta.vat_rate)/100)          as ni_vat_share
from tabby_aggr ta
order by ta.ser_num