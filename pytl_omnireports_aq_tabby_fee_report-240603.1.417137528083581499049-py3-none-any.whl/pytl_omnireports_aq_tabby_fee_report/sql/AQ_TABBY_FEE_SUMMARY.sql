/*
240518: maksimsk : NIBOA-10081 : initial version
240530.1: PrabirK : NIBOA-10250 : Correction in SQL
*/
with tabby_data as (
select
 ORG
,to_char(to_date(:P_REPORT_DATE, 'DD-MM-YYYY')-1,'Mon-YY')         as MON_YY
,PERSONAL_ACCOUNT
,MERCHANT_NAME
,DECODE(TRANS_GROUP,'SALE',1,0)                                   as SALE_COUNT
,DECODE(TRANS_GROUP,'SALE',TRANS_AMNT,0)                          as SALE_AMOUNT
,DECODE(TRANS_GROUP,'SALE',(TRANS_AMNT*TABBY_SAL_RATE)/100,0)     as SALE_PCNT_FEE
,DECODE(TRANS_GROUP,'SALE',TABBY_SAL_BASE,0)                      as SALE_FXD_FEE
,DECODE(TRANS_GROUP,'REFUND',1,0)                                 as REF_COUNT
,DECODE(TRANS_GROUP,'REFUND',TRANS_AMNT,0)                        as REF_AMOUNT
,DECODE(TRANS_GROUP,'REFUND',(TRANS_AMNT*TABBY_REF_RATE)/100,0)   as REF_PCNT_FEE
,DECODE(TRANS_GROUP,'REFUND',TABBY_REF_BASE,0)                    as REF_FXD_FEE
,SUBSTR(CARD_NUMBER,1,6)
  || lpad('X',DECODE(CARD_NUMBER,13,3,14,4,15,5,16,6,17,7,18,8,19,9,3),'X')
  || SUBSTR(CARD_NUMBER,-4)                                       as CARD_NUMBER
,TABBY_SAL_RATE
,TABBY_SAL_BASE
,TABBY_REF_RATE
,TABBY_REF_BASE
,VAT_RATE
from OPT_ACQ_TABBY_FEE_DATA
WHERE ORG = :ORG
  AND REPORT_DATE = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
)
, tabby_aggr as (select
 ORG
,PERSONAL_ACCOUNT
,MERCHANT_NAME
,sum(SALE_COUNT)                            as SALE_COUNT
,sum(SALE_AMOUNT)                           as SALE_AMOUNT
,sum(SALE_PCNT_FEE)                         as SALE_PCNT_FEE
,(sum(SALE_PCNT_FEE)*VAT_RATE)/100          as SALE_PCNT_VAT
,sum(SALE_FXD_FEE)                          as SALE_FXD_FEE
,(sum(SALE_FXD_FEE)*VAT_RATE)/100           as SALE_FXD_VAT
,sum(REF_COUNT)                             as REF_COUNT
,sum(REF_AMOUNT)                            as REF_AMOUNT
,sum(REF_PCNT_FEE)                          as REF_PCNT_FEE
,(sum(REF_PCNT_FEE)*VAT_RATE)/100           as REF_PCNT_VAT
,sum(REF_FXD_FEE)                           as REF_FXD_FEE
,(sum(REF_FXD_FEE)*VAT_RATE)/100            as REF_FXD_VAT
,sum(SALE_AMOUNT) - sum(ABS(REF_AMOUNT))    as GROSS_SALE
,((sum(SALE_PCNT_FEE)
+sum(SALE_FXD_FEE))
-(sum(abs(REF_PCNT_FEE))
+sum(abs(REF_FXD_FEE))))                    as TOTAL_FEE
,(((sum(SALE_PCNT_FEE)*VAT_RATE)/100
+(sum(SALE_FXD_FEE)*VAT_RATE)/100)
-((sum(abs(REF_PCNT_FEE))*VAT_RATE)/100
+(sum(abs(REF_FXD_FEE))*VAT_RATE)/100))     as TOTAL_VAT
,MON_YY
from tabby_data
GROUP BY 
 ORG
,PERSONAL_ACCOUNT
,MERCHANT_NAME
,MON_YY
,VAT_RATE
)
select
 ORG
,row_number() over(partition by ORG order by PERSONAL_ACCOUNT) as SER_NUM
,PERSONAL_ACCOUNT
,MERCHANT_NAME
,SALE_COUNT
,SALE_AMOUNT
,SALE_PCNT_FEE
,SALE_PCNT_VAT
,SALE_FXD_FEE
,SALE_FXD_VAT
,REF_COUNT
,ABS(REF_AMOUNT)                                               as REF_AMOUNT
,ABS(REF_PCNT_FEE)                                             as REF_PCNT_FEE
,ABS(REF_PCNT_VAT)                                             as REF_PCNT_VAT
,ABS(REF_FXD_FEE)                                              as REF_FXD_FEE
,ABS(REF_FXD_VAT)                                              as REF_FXD_VAT
,GROSS_SALE                                                    as GROSS_SALE
,TOTAL_FEE                                                     as TOTAL_FEE
,TOTAL_VAT                                                     as TOTAL_VAT
,MON_YY
from tabby_aggr
order by 1,2