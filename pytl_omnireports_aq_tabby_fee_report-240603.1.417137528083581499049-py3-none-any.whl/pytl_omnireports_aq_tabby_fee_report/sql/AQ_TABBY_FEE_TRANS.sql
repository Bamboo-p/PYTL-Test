/*
240518: maksimsk : NIBOA-10081 : initial version
240530.1: PrabirK : NIBOA-10250 : Correction in SQL
*/
with tabby_data as (
select
 ORG
,PERSONAL_ACCOUNT
,MERCHANT_NAME
,TRANS_GROUP
,CARD_NUMBER
,TRANS_AMNT
,AUTH_CODE
,to_char(TRANS_DATE,'dd-mm-yyyy hh24:mi:ss')                     as TRANS_DATE
,DECODE(TRANS_GROUP,'SALE',TABBY_SAL_BASE,TABBY_REF_BASE)        as FXD_FEE
,DECODE(TRANS_GROUP,'SALE',(TRANS_AMNT*TABBY_SAL_RATE)/100,(TRANS_AMNT*TABBY_REF_RATE)/100)        as PCNT_FEE
,VAT_RATE
from OPT_ACQ_TABBY_FEE_DATA
WHERE ORG = :ORG
  AND REPORT_DATE = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
)

select
 :ORG                                                                as org
,RPAD('Merchant ID',12,' ')                                          as "Merchant ID" 
,RPAD('Merchant Name',25,' ')                                        as "Merchant Name"
,RPAD('Transaction type',16,' ')                                     as "Transaction type"
,RPAD('Masked PAN',16,' ')                                           as "Masked PAN"
,RPAD('Transaction Amount',18,' ')                                   as "Transaction Amount"
,RPAD('Auth code',10,' ')                                            as "Auth code"
,RPAD('Transaction date and time',25,' ')                            as "Transaction date and time"
,RPAD('Tabby Fixed Fee',18,' ')                                      as "Tabby Fixed Fee"
,RPAD('VAT on Tabby Fixed Fee',22,' ')                               as "VAT on Tabby Fixed Fee"
,RPAD('Tabby Percentage Fee',20,' ')                                 as "Tabby Percentage Fee"              
,RPAD('VAT on Tabby Percentage Fee',27,' ')                          as "VAT on Tabby Percentage Fee"
,RPAD('Total Tabby Fee',18,' ')                                      as "Total Tabby Fee"
,RPAD('Total VAT Tabby Fee',19,' ')                                  as "Total VAT Tabby Fee"
from dual
UNION ALL
select
 ORG                                                                 as org
,RPAD(PERSONAL_ACCOUNT,12,' ')                                       as "Merchant ID" 
,RPAD(NVL(MERCHANT_NAME,' '),25,' ')                                 as "Merchant Name"
,RPAD(initcap(TRANS_GROUP),16,' ')                                   as "Transaction type"
,RPAD(CARD_NUMBER,16,' ')                                            as "Masked PAN"
,LPAD(TRANS_AMNT,18,' ')                                             as "Transaction Amount"
,RPAD(NVL(AUTH_CODE,' '),10,' ')                                     as "Auth code"
,RPAD(TRANS_DATE,25,' ')                                             as "Transaction date and time"
,LPAD(FXD_FEE,18,' ')                                                as "Tabby Fixed Fee"
,LPAD((FXD_FEE * VAT_RATE)/100,22,' ')                               as "VAT on Tabby Fixed Fee"
,LPAD(PCNT_FEE,20,' ')                                               as "Tabby Percentage Fee"              
,LPAD((PCNT_FEE * VAT_RATE)/100 ,27,' ')                             as "VAT on Tabby Percentage Fee"
,LPAD(FXD_FEE + PCNT_FEE,18,' ')                                     as "Total Tabby Fee"
,LPAD((FXD_FEE * VAT_RATE)/100 + (PCNT_FEE * VAT_RATE)/100,19,' ')   as "Total VAT Tabby Fee"
from tabby_data