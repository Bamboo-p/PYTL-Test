/*
* AQ_TMS_EXTRACT
*
* Version history:
* 240327.1 = MohammadKH = NIBOA-9490 : Initial Version
* 240416.1 = MohammadKH = NIBOA-9924 : Added order by 
*/
SELECT * FROM   OPT_ACQ_TMS_EXTRACT_DUMP OPT
WHERE OPT.banking_date  = to_date(:P_REPORT_DATE,'dd-mm-yyyy')
AND OPT.ORG = :ORG
ORDER BY SNO
