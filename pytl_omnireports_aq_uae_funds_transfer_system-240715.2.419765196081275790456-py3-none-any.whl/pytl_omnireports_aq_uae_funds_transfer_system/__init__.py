__version__ = "240715.2"
__job_name__ = "PyTL_OmniReports_AQ_UAE_Funds_Transfer_System"
__bat_files__ = []
