/*
240607.1: PadalaSK: NIBOA-10248: Initial development of message creation report
240715.1: PadalaSK: NIBOA-10438: Updated code to have field details through CTM
240715.2: PadalaSK: NIBOA-10438: Updated code to have ordering institution field to pass via CTM
*/
WITH bank_dates as (
            select local_date,
              min(calendar_date) min_calendar_date,
              max(calendar_date) max_calendar_date
            from ows.mp_consist_point mcp
            join ows.mp_consist_type mct
            on mcp.mp_consist_type__oid = mct.id
              and mct.code = 'END_DAY'
            group by local_date),
    cp as (
            select max(local_date) local_date,
              'PREV_CP' cp
            from bank_dates
            where local_date <= (to_date(:P_REPORT_DATE, 'dd-mm-yyyy') - 1)
            union all
            select max(local_date) local_date,
              'CUR_CP' cp
            from bank_dates
            where local_date <= to_date(:P_REPORT_DATE, 'dd-mm-yyyy')),
    parms as (
            select /*+ materialize */
            max(case when cp.cp = 'PREV_CP' then max_calendar_date end) date_from,
            max(case when cp.cp = 'CUR_CP' then min_calendar_date end)  date_to
              from bank_dates bank_dates
              join cp on bank_dates.local_date = cp.local_date
              ),

    classifiers as (
            select  /*+ no_merge leading(st sl sv) use_nl(st sl) use_nl(sl sv) */
              sl.acnt_contract__oid,
              max(case when st.code = 'ACQ_MCS' then sv.code end) as mcs,
              max(case when st.code = 'UBP_ACCEPTANCE' then sv.code end) as ubp
            from ows.cs_status_log sl
            JOIN ows.cs_status_type st ON st.id = sl.status_type
              AND st.code IN ('UBP_ACCEPTANCE', 'ACQ_MCS')
              AND st.amnd_state = 'A'
            JOIN ows.cs_status_value sv on sv.id = sl.status_value
              AND sv.amnd_state = 'A'
            WHERE to_date(:P_REPORT_DATE, 'dd-mm-yyyy') between sl.START_LOCAL_DATE and sl.END_LOCAL_DATE
              and sl.is_active = 'Y'
            group by sl.acnt_contract__oid
        ),

    institution as (
            select /*+ no_merge materialize */
                   id
              from ows.f_i
             where bank_code = :ORG
               and amnd_state = 'A'
        ),

    contracts as (
            select /*+ ordered index(ac CONTRACT_CAT) */
                ac.contract_number,
                case when nvl(cl.ubp, 'N') = 'Y' and instr(ac.add_info_01,'PAY_MODE=NN;') > 0 then 'N' else 'Y' end isPopulate,
                NVL(cl.mcs, 'N') as isMult
              FROM ows.acnt_contract ac

              JOIN institution f
                ON f.ID = ac.f_i

              LEFT JOIN classifiers cl
                ON cl.acnt_contract__oid = ac.id

            where ac.amnd_state = 'A'
               AND ac.pcat = 'M'
               AND ac.ccat = 'C'
        ),
    bins as (
            select /*+ materialize */
              b.id, g.card_org, b.start_bin
            from ows.bin_table b
            join ows.bin_group g
            on g.id = b.bin_group__oid
            where g.card_org = 'RTANOL'
    AND g.amnd_state = 'A'
    AND b.amnd_state = 'A'
    ),
    cb_bins as (
            select /*+ materialize */
              b.id, g.card_org, b.start_bin
            from ows.bin_table b
            join ows.bin_group g
            on g.id = b.bin_group__oid
            where g.card_org = 'CBUAESW'
    AND g.amnd_state = 'A'
    AND b.amnd_state = 'A'
    ),

    tr_typ as (
            select /*+ no_merge materialize */
              id, name, trans_code, dr_cr
            from ows.trans_type
            where amnd_state = 'A'
              AND ID NOT IN (47453, 47461, 93977, 93900, 47460, 36280, 47458, 63640)),

    acc AS (select ac.* from (
            /*accepted transaction docs*/
            SELECT /*+ no_merge materialize leading(tr inst d tt) index(tr MACRO_STATUS) use_nl(tr d) */
            distinct
            d.id,
            d.merchant_id,
            CASE WHEN d.posting_status IN ('P', 'C', 'I') THEN 1
                 WHEN d.outward_status = 'S' THEN 3
            END AS ordr_curr,
            d.trans_curr trn_curr,
            tr.posting_date p_date,
            (CASE WHEN (tt.dr_cr = 1 AND d.request_category = 'P') OR (tt.dr_cr = -1 AND d.request_category IN ('R','J')) THEN 1 ELSE 0 END) dr_cnt,
            (CASE WHEN (tt.dr_cr = 1 AND d.request_category = 'P') OR (tt.dr_cr = -1 AND d.request_category IN ('R','J')) THEN d.trans_amount ELSE 0 END) dr_vol,
            (CASE WHEN (tt.dr_cr = 1 AND d.request_category IN ('R','J')) OR (tt.dr_cr = -1 AND d.request_category = 'P') THEN 1 ELSE 0 END) cr_cnt,
            (CASE WHEN (tt.dr_cr = 1 AND d.request_category IN ('R','J')) OR (tt.dr_cr = -1 AND d.request_category = 'P') THEN d.trans_amount ELSE 0 END) cr_vol

            from ows.m_transaction tr
            JOIN institution inst
              ON inst.id = tr.f_i

            JOIN ows.DOC d
              ON d.id = tr.doc__oid

            JOIN tr_typ tt
              ON tt.ID =  d.trans_type

            JOIN ows.mess_channel ch
              ON ch.code = d.target_channel
              AND ch.amnd_state = 'A'
              AND ch.name = 'AANI'

            WHERE tr.posting_date = trunc(to_date(:P_REPORT_DATE, 'dd-mm-yyyy'))
               AND d.posting_date = trunc(to_date(:P_REPORT_DATE, 'dd-mm-yyyy'))
               AND d.amnd_state = 'A'
               AND NVL(d.bin_record,-9999) not in (select id from bins)
               AND substr(d.add_info, instr(d.add_info, 'PTLF_SUM_DOC=')+13,(instr(d.add_info, ';', instr(d.add_info, 'PTLF_SUM_DOC='))-instr(d.add_info, 'PTLF_SUM_DOC=')-13)) IS NULL
               AND NVL(d.is_authorization, 'N') = 'N'
               AND ((d.target_channel = 'H' and instr(';'||d.add_info,';ORDER_ID=') != 0) or instr(';'||d.add_info,';ORDER_ID=') = 0)
               AND (d.posting_status IN ('P', 'C', 'I') OR d.outward_status = 'S')
               AND (CASE WHEN d.posting_status IN ('P', 'C', 'I') AND tt.dr_cr IS NOT NULL
                         AND d.trans_amount IS NOT NULL
                         AND d.target_channel IS NOT NULL
                        THEN 1
                    WHEN d.outward_status = 'S'
                         AND d.target_channel IS NOT NULL
                        THEN 1
               END) = 1
               AND ( d.source_channel = 'P' OR d.source_channel IS NULL )
               AND ((nvl(d.target_channel,'NA') != 'O' AND nvl(d.source_code,'NA') NOT LIKE 'XLS%') OR (d.target_channel='O' AND d.source_code IN ('XLS1','XLS3'))
                OR (d.target_channel IN ('O','7') AND tt.trans_code = 'R1' AND d.card_seqv_number IN ('999', '099')
                    AND instr(d.add_info, 'UBE_LTY=Y;') > 0)
                OR (d.target_channel IN ('O','7') AND tt.trans_code = 'R1' AND d.card_seqv_number IN ('999', '099')
                    AND substr(d.add_info, instr(d.add_info, 'REWARD_SEQV=')+12,(instr(d.add_info, ';', instr(d.add_info, 'REWARD_SEQV='))-instr(d.add_info, 'REWARD_SEQV=')-12)) IS NOT NULL)
                    )
       ) ac
        JOIN contracts on contracts.contract_number = ac.merchant_id
          AND contracts.isPopulate = 'Y' -- UTLTYMIGW4-163
          AND (CASE
             WHEN (NVL(:P_CURRENCY, 'ALL') = 'ALL') THEN 1
             WHEN :P_CURRENCY = 'MUL' and contracts.isMult = 'Y' THEN 1
             WHEN :P_CURRENCY = 'NON_MUL' and contracts.isMult = 'N' THEN 1
             WHEN :P_CURRENCY IS NOT NULL AND :P_CURRENCY = ac.trn_curr THEN 1
             ELSE 0
          END) = 1 -- ADCBA-965 P_MODE should be NON_MULT for ADCB, for other banks it should be ALL
      ),
final as(
SELECT
'CTD'                                                   AS  RECORD_TYPE,
'I103N'                                                 AS  MESSAGE_TYPE,
'000001'                                                AS  SEQUENCE_NUMBER,
:BEN_INST_IDENTIFIER                                    AS  BEN_INST_IDENTIFIER,
'FIS'                                                   AS  TRAN_TYPE_CODE,
TO_CHAR(SYSDATE, 'YYMMDD')                              AS  VALUE_DATE,
'AED'                                                   AS  CURRENCY_CODE,
TO_CHAR((sum(cr_vol)-sum(dr_vol)), 'fm999999999999D00') AS  SETTLED_AMOUNT,
TO_CHAR((sum(cr_vol)-sum(dr_vol)), 'fm999999999999D00') AS  INSTRUCTED_AMOUNT,
'0802/'                                                 AS  ORDERING_CUSTOMER_TYPE,
'AE744100001000331101001'                               AS  ORDERING_CUSTOMER_ACCOUNT,
'Network International - Al Barsha 2 Dubai United Arab Emirates'    AS  ORDERING_CUSTOMER_ADDRESS,
:BEN_INST_IDENTIFIER                                    AS  ORDERING_INSTITUTION,
'/'||'AE480260001011333911713'                          AS  BEN_ACCOUNT_PARTICIPANT,
'Emirates NBD - Diera Dubai United Arab Emirates'       AS  BEN_ACCOUNT_ADDRESS,
'/REF/Settlement'                                       AS  REMITTANCE_INFORMATION,
'SHA'                                                   AS  DETAILS_OF_CHARGES,
''                                                      AS  SENDERS_CHARGES,
''                                                      AS  INSTRUCTIONS_BEN_BANK,
'NI'||TO_CHAR(SYSDATE, 'YYMMDDHH24MiSS')                AS  SENDING_INST_REF_TRANS,
''                                                      AS  ACCOUNT_WITH_INSTITUTION,
''                                                      AS  INSTRUCTED_CURRENCY,
''                                                      AS  EXCHANGE_RATE,
''                                                      AS  SENDERS_CORRESPONDENT,
''                                                      AS  RECEIVERS_CORRESPONDENT,
''                                                      AS  INTERMEDIARY_INSTITUTION,
''                                                      AS  GPI_REFERENCE_NUMBER,
''                                                      AS  FUTURE_USE1,
''                                                      AS  FUTURE_USE2,
'UAEFTS'                                                AS  FUTURE_USE
FROM acc
group by ordr_curr, p_date, trn_curr

union all

select
'CTC'                                                   AS  RECORD_TYPE,
:SENDING_INST_IDENTIFIER                                AS  MESSAGE_TYPE,
'NI'||TO_CHAR(SYSDATE, 'YYMMDDHH24MiSS')                AS  SEQUENCE_NUMBER,
'UAEFTSRB'                                              AS  BEN_INST_IDENTIFIER,
TO_CHAR(SYSDATE, 'YYMMDD')                              AS  TRAN_TYPE_CODE,
'AED'                                                   AS  VALUE_DATE,
TO_CHAR((sum(cr_vol)-sum(dr_vol)), 'fm999999999999D00') AS  CURRENCY_CODE,
'NI'||TO_CHAR(SYSDATE, 'YYMMDDHH24MiSS')                AS  SETTLED_AMOUNT,
''                                                      AS  INSTRUCTED_AMOUNT,
''                                                      AS  ORDERING_CUSTOMER_TYPE,
''                                                      AS  ORDERING_CUSTOMER_ACCOUNT,
''                                                      AS  ORDERING_CUSTOMER_ADDRESS,
''                                                      AS  ORDERING_INSTITUTION,
''                                                      AS  BEN_ACCOUNT_PARTICIPANT,
''                                                      AS  BEN_ACCOUNT_ADDRESS,
''                                                      AS  REMITTANCE_INFORMATION,
''                                                      AS  DETAILS_OF_CHARGES,
''                                                      AS  SENDERS_CHARGES,
''                                                      AS  INSTRUCTIONS_BEN_BANK,
''                                                      AS  SENDING_INST_REF_TRANS,
''                                                      AS  ACCOUNT_WITH_INSTITUTION,
''                                                      AS  INSTRUCTED_CURRENCY,
''                                                      AS  EXCHANGE_RATE,
''                                                      AS  SENDERS_CORRESPONDENT,
''                                                      AS  RECEIVERS_CORRESPONDENT,
''                                                      AS  INTERMEDIARY_INSTITUTION,
''                                                      AS  GPI_REFERENCE_NUMBER,
''                                                      AS  FUTURE_USE1,
''                                                      AS  FUTURE_USE2,
'UAEFTS'                                                AS  FUTURE_USE
FROM acc
group by ordr_curr, p_date, trn_curr
)
select
RECORD_TYPE,
MESSAGE_TYPE,
SEQUENCE_NUMBER,
BEN_INST_IDENTIFIER,
TRAN_TYPE_CODE,
VALUE_DATE,
CURRENCY_CODE,
SETTLED_AMOUNT,
INSTRUCTED_AMOUNT,
ORDERING_CUSTOMER_TYPE,
ORDERING_CUSTOMER_ACCOUNT,
ORDERING_CUSTOMER_ADDRESS,
ORDERING_INSTITUTION,
BEN_ACCOUNT_PARTICIPANT,
BEN_ACCOUNT_ADDRESS,
REMITTANCE_INFORMATION,
DETAILS_OF_CHARGES,
SENDERS_CHARGES,
INSTRUCTIONS_BEN_BANK,
SENDING_INST_REF_TRANS,
ACCOUNT_WITH_INSTITUTION,
INSTRUCTED_CURRENCY,
EXCHANGE_RATE,
SENDERS_CORRESPONDENT,
RECEIVERS_CORRESPONDENT,
INTERMEDIARY_INSTITUTION,
GPI_REFERENCE_NUMBER,
FUTURE_USE1,
FUTURE_USE2,
FUTURE_USE,
TO_CHAR(SYSDATE, 'HH24MISS') || TO_CHAR(SYSDATE, 'YYMMDDHH24MISS')  AS REPORT_TIMESTAMP
from final