/*
* VISA_ONBOARDING_MERCHANT
*
* Version history:
* 240305.1 = HamzaHendi = NIBOA-9506 : Initial Version
* 240318.1 = HamzaHendi = NIBOA-9506 : updating pending points
* 240403.1 = PrabirK    = NIBOA-9506 : Adding schema name (dwh) and adding DWD_COUNTRY table to fetch country code (2-byte ISO code)
* 240415.1 = HamzaHendi = NIBOA-9936 : fixing attributes query
* 240416.1 = HamzaHendi = NIBOA-9936 : updating retrieving data logic and feilds length
*/
with inst as
(select
 /*+ no_merge */
 id,
 code
 from dwh.dwd_institution i
 where record_state = 'A'
 and code = :ORG
)
,cntr as
(select /*+ materialize use_hash(da) swap_join_inputs(da) use_nl(cntr) use_hash(inst) swap_join_inputs(inst) leading(dca da cntr)*/
 cntr.personal_account,
 cntr.record_idt contract_idt,
 da.code,
 da.type_code,
 dca.attr_date_from,
 dca.attr_date_to,
 dca.active_state,
 substr(clnt.add_info, instr(clnt.add_info, 'URL=') + length('URL='), 
 instr(clnt.add_info, 
 ';', 
 instr(clnt.add_info, 'URL=')
 ) 
 - 
 instr(clnt.add_info, 'URL=') - length('URL=')
 ) as primaryWebsiteURL
 from dwh.dwa_contract_attribute dca
 join 
(select /*+ no_merge full(attr)*/
 attr.id,
 attr.code,
 attr.type_code
 from dwh.dwd_attribute attr
 where to_date(:P_REPORT_DATE,'dd-mm-yyyy') between attr.record_date_from and attr.record_date_to
 and attr.type_code     =  'ACQ_LVL'
 and attr.code          =  'MERCHANT'
 and attr.record_state != 'C' 
 union all
 select /*+ no_merge full(attr)*/
 attr.id,
 attr.code,
 attr.type_code
 from dwh.dwd_attribute attr
 where attr.type_code     =  'ACQ_VISA_INST_FEE_FLAG'
 and attr.record_state != 'C'
) da
 on   da.id = dca.attr_id  
 join dwh.dwd_contract cntr
 on   cntr.record_idt = dca.contract_idt
 and  to_date(:P_REPORT_DATE,'dd-mm-yyyy') between cntr.record_date_from and cntr.record_date_to
 and  cntr.record_state != 'C'
 join inst
 on   inst.id = cntr.institution_id
 join dwh.dwd_client clnt
 on   cntr.client_idt = clnt.record_idt 
 and  clnt.record_state != 'C'
 and  to_date(:P_REPORT_DATE,'dd-mm-yyyy') between clnt.record_date_from and clnt.record_date_to

), 
cntr_merch as
(select  
 cntr.personal_account,
 cntr.contract_idt,
 cntr.primaryWebsiteURL
 from cntr 
 where  cntr.type_code = 'ACQ_LVL'
 and    cntr.code = 'MERCHANT'
 and    cntr.active_state = 'A'
 and    to_date(:P_REPORT_DATE,'dd-mm-yyyy') between cntr.attr_date_from   and cntr.attr_date_to
),
cntr_visa_clsfr as
(select 
 contract_idt,
 max(case when to_date(:P_REPORT_DATE,'dd-mm-yyyy')  between cntr.attr_date_from and cntr.attr_date_to 
          then code else 
          null end) today_value,
 nvl(max(case when to_date(:P_REPORT_DATE,'dd-mm-yyyy')-1 between cntr.attr_date_from and cntr.attr_date_to 
          then code else 
          null end),'N') yesterday_value
 from  cntr
 where cntr.type_code = 'ACQ_VISA_INST_FEE_FLAG'
 group by contract_idt
),
addr as
(select /*+ no_merge */
 merch_addr.contract_idt   AS contract_idt,
 merch_addr.address_type_code,
 merch_addr.city,
 merch_addr.address_line_1,
 merch_addr.address_line_2,
 merch_addr.address_line_3,
 merch_addr.address_zip zip,
 merch_addr.first_name,
 merch_addr.last_name,
 merch_addr.state,
 merch_addr.phone,
 merch_addr.country,
 merch_addr.e_mail email
 from dwh.opt_v_address merch_addr
 join inst
 on inst.id   = merch_addr.institution_id
 and merch_addr.address_type_code in ('STMT_ADDR' , 'PAYM_ADDR')
 and to_date(:P_REPORT_DATE,'dd-mm-yyyy') between merch_addr.record_date_from and merch_addr.record_date_to
)  
 select  /*+ materialize use_hash(cntr) */
 :ORG                          as ORG,
 substr(cntr_merch.personal_account,0,100)   as "partnerMerchantReferenceID",
 substr(stmt_addr.city,0,50)                as "city",
 substr(stmt_addr.address_line_3,0,140)      as "address2",
 substr(stmt_addr.address_line_2,0,140)      as "address1",
 substr(stmt_addr.zip,0,11)                 as "postalCode",
 substr(paym_addr.last_name,0,24)           as "primaryContactLastName",
 substr(paym_addr.first_name,0,24)          as "primaryContactFirstName",
 substr(stmt_addr.first_name,0,75)          as "primaryLegalName",
 substr(stmt_addr.state,0,100)               as "stateProvinceCode",
 substr(stmt_addr.phone,0,16)               as "phone",
 substr(cntry.code_2char,0,2)              as "countryCode",
 substr(cntr_merch.primaryWebsiteURL,0,100)  as "primaryWebsiteURL",
 substr(stmt_addr.address_line_1,0,75)      as "primaryTradeName",
 substr(stmt_addr.email,0,100)               as "primaryContactEmail",
 substr(cntr_merch.personal_account,0,15)   as "cardAcceptorId"
 from cntr_merch 
 left join addr stmt_addr  on cntr_merch.contract_idt = stmt_addr.contract_idt
                           and stmt_addr.address_type_code = 'STMT_ADDR'
 left join addr paym_addr  on cntr_merch.contract_idt = paym_addr.contract_idt
                           and paym_addr.address_type_code = 'PAYM_ADDR'
 left join cntr_visa_clsfr on  cntr_merch.contract_idt = cntr_visa_clsfr.contract_idt
 left join dwh.dwd_country cntry on cntry.code = stmt_addr.country
                                and to_date(:P_REPORT_DATE,'dd-mm-yyyy') between cntry.record_date_from and cntry.record_date_to
								and cntry.record_state != 'C'
 where today_value = 'Y' 
 and yesterday_value = 'N'