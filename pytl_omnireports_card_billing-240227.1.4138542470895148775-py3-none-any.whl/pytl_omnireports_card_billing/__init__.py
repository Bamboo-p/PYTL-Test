__version__ = "240227.1"
__job_name__ = "PyTL_OmniReports_CARD_BILLING"
__bat_files__ = []

