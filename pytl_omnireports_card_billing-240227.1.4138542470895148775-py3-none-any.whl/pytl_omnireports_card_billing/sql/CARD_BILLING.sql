/*
CARD_BILLING_REPORT.sql
28-03-2022 : OPKSAIC-3337 : Bharath : Initial version : Tiqmo Card Billing Report
04-07-2022 : OPKSAIC-3337 : Bharath : Extraction logic for Value_Code is modified using custom tag PR_GROUP_REP
230125.1 : NIINT-2984 : Santosh : Added logic for product_type
240227.1 : NICORE-1215 : Shalini : Renaming of job and sql
*/
with inst as(
    select /*+ no_merge materialize */
          id,
          bank_code code,
          name
    from (select fi.bank_code,
                 fi.posting_in,
                 fi.id,
                 fi2.bank_code bank_code_posting,
                 fi.name
            from ows.f_i fi
            join ows.f_i fi2
              on fi.posting_in = fi2.id
           where fi.amnd_state = 'A'
             and fi2.amnd_state = 'A'
         ) inst
  start with inst.bank_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                  from dual
                                  connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
                                  )
  connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
    ),
cards as (
    select /*+ no_merge materialize */
          c.id,
          c.contract_number,
          --[+] : OPKSAIC-3337 : Extraction logic for Value_Code is modified using custom tag PR_GROUP_REP
          decode(nvl(ows.sy_convert.get_tag_value(p.custom_data,'PR_GROUP_REP'),p.product_group),
          'ISSCREDIT','CREDIT','ISSDEB','DEBIT','ISSPREPAID','PREPAID','CREDIT') as value_Code,
          --[-] : OPKSAIC-3337 : Extraction logic for Value_Code is modified using custom tag PR_GROUP_REP
          i.code as institution,
          i.name as institution_name,
          s.name as status,
          p.contract_role -- [+] 230125.1 : NIINT-2984 : Santosh : Added logic for product_type
     from ows.acnt_contract c
     join inst i
       on i.id = c.f_i
     join ows.appl_product p
       on c.product    = p.internal_code
      and p.amnd_state = 'A'
     join ows.contr_status s
       on c.contr_status = s.id
      and s.amnd_state   = 'A'
    where c.amnd_state = 'A'
      and c.con_cat    = 'C'
    ),
transactions as (
    select /*+ no_merge materialize */
          count(*) as cnt,
          c.contract_number
     from ows.doc d
     join cards c
       on c.contract_number = nvl(d.target_number,d.source_number)
      and d.amnd_date >= trunc(add_months(to_date(:P_REPORT_DATE,'dd-MM-yyyy'),-1))
      and d.amnd_date <= trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy'))
 group by c.contract_number
    )

    select institution      as org,
           'WAY4'           as System,
           institution      as Institution,
           institution_name as Institution_Name,
           status           as Status,
           decode(contract_role,'CORP','Commercial','Consumer')  as Product_type,-- [+] 230125.1 : NIINT-2984 : Santosh : Added logic for product_type
           value_Code       as Type_of_Cards,
           'STANDARD'       as CardProduct,
           count(*)         as No_of_Cards,
           sum(case when nvl(cnt,0) > 0 then 1 else 0 end) as No_of_Active_Cards,
           sum(case when nvl(cnt,0) = 0 then 1 else 0 end) as No_of_Inactive_Cards
      from cards c
 left join transactions t
        on c.contract_number = t.contract_number
  group by institution,institution_name,status,contract_role,value_Code
  order by status

