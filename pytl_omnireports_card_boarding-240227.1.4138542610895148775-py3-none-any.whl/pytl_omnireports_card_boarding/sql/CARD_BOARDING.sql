/*
* Version history:
11-04-2022 : OPKSAIC-3344: Santosh Kumar Singh - Initial Version
09-05-2022 : OPKSAIC-3344: Santosh Kumar Singh - Logic correction to pull card_type
12-05-2022 : OPKSAIC-3344: Santosh Kumar Singh - Added schema reference
240227.1 : NICORE-1215 : Shalini : Renaming of job and sql
*/
with inst as(
    select /*+ no_merge materialize */
          id,
          bank_code code,
          name
    from (select fi.bank_code,
                 fi.posting_in,
                 fi.id,
                 fi2.bank_code bank_code_posting,
                 fi.name
            from ows.f_i fi
            join ows.f_i fi2
              on fi.posting_in = fi2.id
           where fi.amnd_state = 'A'
             and fi2.amnd_state = 'A'
         ) inst
  start with inst.bank_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                  from dual
                                  connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
                                  )
  connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
    )

 select /*+ no_merge materialize */
          i.code      as org,
          'WAY4'           as System,
          i.code as institution,
          i.name as institution_name,
          substr(c.contract_number ,1,6) as BIN,
--          pc.value_Code AS CARD_TYPE,
          decode(nvl(ows.sy_convert.get_tag_value(p.custom_data,'PR_GROUP_REP'),pc.value_code),
          'ISSCREDIT','CREDIT','ISSDEB','DEBIT','ISSPREPAID','PREPAID',
          nvl(ows.sy_convert.get_tag_value(p.custom_data,'PR_GROUP_REP'),pc.value_code)) as CARD_TYPE,
          COUNT(1) NUMBER_OF_CARDS
     from ows.acnt_contract c
     join inst i
       on i.id = c.f_i
     join ows.appl_product p
       on c.product    = p.internal_code
      and p.amnd_state = 'A'
     join ows.v_product_sy_conf pc
       on p.id  = pc.product_id
      and pc.classifier_code = 'DWD_CARD_CATEGORY'
      and pc.group_code      = 'DWH_CONF'
    where c.amnd_state = 'A'
      and c.con_cat    = 'C'
      and c.DATE_OPEN BETWEEN trunc(add_months(to_date(:P_REPORT_DATE,'dd-MM-yyyy'),-1)) and trunc(to_date(:P_REPORT_DATE,'dd-MM-yyyy'))
      group by  'WAY4',
          i.code ,
          i.name ,
          substr(c.contract_number ,1,6),
    decode(nvl(ows.sy_convert.get_tag_value(p.custom_data,'PR_GROUP_REP'),pc.value_code),
          'ISSCREDIT','CREDIT','ISSDEB','DEBIT','ISSPREPAID','PREPAID',
          nvl(ows.sy_convert.get_tag_value(p.custom_data,'PR_GROUP_REP'),pc.value_code))