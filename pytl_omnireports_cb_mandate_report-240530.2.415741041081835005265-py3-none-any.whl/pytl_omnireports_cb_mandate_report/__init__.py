__version__ = "240530.2"
__job_name__ = "PyTL_OmniReports_CB_MANDATE_REPORT"
__bat_files__ = []
