/*
PyTL_OmniReports_CB_MANDATE_REPORT = = CB_MANDATE_REPORT.sql
Incoming parameters:
    :ORG_LIST
    :P_REPORT_DATE as dd-MM-yyyy

240327.1 = ErnestH = ENBD-26313
240515.2 = AlexanderK = ENBD-26313: Turn off TXN_CODE_LIST filter
240517.3 = AlexanderK = ENBD-26313: Add field instalment_interest
240520.4 = AlexanderK = ENBD-26313: Remove field first_time_revolver
240522.5 = AlexanderK = ENBD-26313: Added filter by CALC_INT_RETAIL
240524.1 = RakeshG    = ENBD-27055,ENBD-27056,ENBD-27076,ENBD-27062,ENBD-27054 balances fixes
*/

with inst as(
     SELECT  /*+ no_merge materialize */
             inst.id as institution_id,
             inst.branch_code,
             inst.branch_code_posting
       FROM
            (SELECT dwd_institution.branch_code,
                    dwd_institution.posting_institution_id,
                    dwd_institution.id,
                    dwd_institution2.branch_code branch_code_posting
               FROM dwd_institution
               JOIN dwd_institution dwd_institution2
                 ON dwd_institution.posting_institution_id = dwd_institution2.id
              WHERE dwd_institution.record_state = 'A'
            ) inst
 START WITH inst.branch_code in (select trim(regexp_substr(:ORG_LIST, '[^,]+', 1, level)) org
                                   from dual
                             connect by regexp_substr(:ORG_LIST , '[^,]+', 1, level) is not null)
 CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = prior inst.id
        AND level <= 2),

     contracts as (
     select /*+ no_merge materialize*/
	        c.contract_idt,
            c.contract_number,
            c.product_name,
            c.client_first_name,
            c.client_last_name,
            c.due_date,
            c.prev_due_date,
            c.billing_date,
            c.prev_billing_date,
            c.client_reg_number,
            c.logo,
            inst.branch_code_posting,
            decode(instr(c.BILLING_INFO, 'STMT_BALANCE='), null, null, substr(regexp_substr(BILLING_INFO, 'STMT_BALANCE=[^;]+'), 14)) as STMT_BALANCE,
			decode(instr(c.BILLING_INFO, 'PAST_DUE='), null, null, substr(regexp_substr(BILLING_INFO, 'PAST_DUE=[^;]+'), 10)) as PAST_DUE,
			decode(instr(c.BILLING_INFO, 'RTL_INT_BILL='), null, null, substr(regexp_substr(BILLING_INFO, 'RTL_INT_BILL=[^;]+'), 14)) as RETAIL_INT,
            BANK_CODE
       from opt_dm_contract_info c
       join inst on inst.institution_id=c.institution_id
      where c.billing_date=to_date(:P_REPORT_DATE,'dd-MM-yyyy')
        and c.banking_date=to_date(:P_REPORT_DATE,'dd-MM-yyyy')
        ),

     operation_types as (
     select /*+ materialize*/
            *
       from v_dwr_operation_type
      where class_code = 'ENBD_REPORTS' and type_code ='STMT_TURNOVERS'),

     attributes as (
     select /*+ no_merge materialize*/
            da.contract_idt,
            nvl(a.code, '0') as attr_code,
            da.attr_date_from,
            da.attr_date_to,
            a.type_code,
            c.prev_billing_date,
            c.billing_date
       from dwa_contract_attribute da
       join dwd_attribute a on da.attr_id = a.id
        and da.active_state != 'C'
        and a.type_code = 'DLQ_LEVEL'
       join contracts c on c.contract_idt=da.contract_idt)
,bill_info as (SELECT
    contract_idt,
    billing_date,
    MAX(CASE WHEN rn = 1 THEN bill_date ELSE NULL END) AS prev_billing_date,
    MAX(CASE WHEN rn = 1 THEN due_date ELSE NULL END) AS prev_due_date,
    MAX(CASE WHEN rn = 2 THEN due_date ELSE NULL END) AS prev_due_date1,
    MAX(CASE WHEN rn = 1 THEN stmt_balance ELSE 0 END) AS prev_stmt_bal,
    MAX(CASE WHEN rn = 2 THEN stmt_balance ELSE 0 END) AS prev_stmt_bal1
FROM
    (
        SELECT
            c.contract_idt,
            c.billing_date,
            b.billing_date AS bill_date,
            b.due_date,
            ROW_NUMBER()
            OVER(PARTITION BY c.contract_idt
                 ORDER BY
                     b.billing_date DESC
            )              AS rn,
            TO_NUMBER(decode(instr(b.add_info, 'STMT_BALANCE='),
                             NULL,
                             NULL,
                             substr(regexp_substr(b.add_info, 'STMT_BALANCE=[^;]+'),
                                    14)) * - 1)  AS stmt_balance
        FROM
            contracts            c
            LEFT JOIN dwf_contract_billing b ON c.contract_idt = b.contract_idt
                                                AND b.billing_date >= add_months(c.billing_date, - 3)
                                                AND b.billing_date < c.billing_date
    )
GROUP BY
    contract_idt,
    billing_date
)
,FP_FLAG as (
    SELECT
        info.contract_idt,
        info.billing_date,
        info.prev_billing_date,
        MAX(
            CASE
                WHEN info.billing_date BETWEEN att.attr_date_from AND att.attr_date_to THEN
                    a.code
                ELSE
                    NULL
            END
        ) AS prev_status,
        MAX(
            CASE
                WHEN info.prev_billing_date BETWEEN att.attr_date_from AND att.attr_date_to THEN
                    a.code
                ELSE
                    NULL
            END
        ) AS prev_status1
    FROM
             bill_info info
        JOIN dwa_contract_attribute att ON att.contract_idt = info.contract_idt
                                           AND att.attr_date_from <= info.billing_date
        JOIN dwd_attribute          a ON a.id = att.attr_id
                                AND a.record_state = 'A'
                                    AND a.type_code = 'PETRA_FULL_PAYMENT'
    GROUP BY
        info.contract_idt,
        info.billing_date,
        info.prev_billing_date
),
contract_status as (SELECT
    c.contract_idt,
    fp.prev_status as abc,
    bill.prev_billing_date,
    bill.prev_stmt_bal,
    CASE
        WHEN nvl(fp.prev_status, ' ') = 'Y' OR bill.prev_billing_date is null THEN 'T'
        WHEN fp.prev_status = 'N' AND bill.prev_stmt_bal <= 0 THEN 'T'
        ELSE 'R'
    END AS prev_status,
    CASE
        WHEN nvl(fp.prev_status1, ' ') = 'Y'  OR bill.prev_billing_date is null THEN 'T'
        WHEN fp.prev_status1 = 'N' AND bill.prev_stmt_bal1 <= 0 THEN 'T'
        ELSE 'R'
    END AS prev_status1
FROM
    contracts c
    LEFT JOIN bill_info bill ON bill.contract_idt = c.contract_idt
    LEFT JOIN fp_flag fp ON fp.contract_idt = c.contract_idt
),  
     acc_group as (
     select /*+ materialize*/
            class_code,
            type_code,
            code,
            account_group_id
       from v_dwr_account_group
      where v_dwr_account_group.class_code = 'ENBD_REPORTS'
        and v_dwr_account_group.type_code = 'ENBD_BALANCE_TYPES'
        and v_dwr_account_group.code in ('IPP_BILLED_PRINCIPAL','IPP_BILLED_INT')),
     inst_bal as (
     select /*+ no_merge materialize*/
            c.contract_idt,
            sum(case when ag.code = 'IPP_BILLED_PRINCIPAL' then b.balance else 0 end) * -1 as ipp_billed_princ,
            sum(case when ag.code = 'IPP_BILLED_INT' then b.balance else 0 end) * -1 as ipp_billed_int
       from contracts c
       join dwf_account_balance b on b.contract_idt = c.contract_idt
        and b.banking_Date = c.prev_billing_date
       join acc_group ag on ag.account_group_id = b.account_group_id
   group by c.contract_idt
)
,transactions as (
     select /*+ no_merge materialize*/
            odt.contract_idt,
            sum(case when odt.banking_date between c.prev_billing_date + 1 and c.prev_due_date then odt.amount end) as before_pdd,
            sum(case when odt.banking_date between c.prev_due_date + 1 and c.billing_date then odt.amount end)      as before_statement
        from opt_dm_transaction odt
       join contracts c on c.contract_idt=odt.contract_idt
       join operation_types ot on ot.operation_type_id = odt.operation_type_id and ot.code = 'PAYMENT'
   group by odt.contract_idt)

select c.bank_code                                                                          as org,
       c.contract_number                                                                    as card_account_number,
       c.client_first_name || c.client_last_name                                            as cardholder_name,
       c.product_name                                                                       as product_type,
       to_date(to_date(:P_REPORT_DATE,'dd-MM-yyyy'))                                        as billing_date,
       to_char(c.due_date, 'YYYYMMDD ')                                                     as payment_due_date,
       case when ( - 1) * c.RETAIL_INT > 0 then 'Y' else 'N' end                            as interest_charged,
       case when attr.dlq_level > 2 then 'Y' else 'N' end                                   as delinquent,
       attr.dlq_level                                                                       as delinquency_level,
       nvl(rvl.PREV_STATUS1,'T')||'-'||nvl(rvl.PREV_STATUS,'T')                             as status,
       nvl(( - 1) * c.RETAIL_INT,'0')                                                       as interest_amount,
       ( - 1) * nvl(c.STMT_BALANCE,0)                                                       as statement_outstanding,
       nvl(t.before_pdd,'0')                                                                as payment_made_before_PDD,
       nvl(t.before_statement,'0')                                                          as payment_made_before_statement,
       nvl(i.ipp_billed_princ,'0')                                                          as installment_before_PDD,
       nvl(i.ipp_billed_int,'0')                                                            as instalment_interest,
       ( - 1) *(c.past_due)                                                                 as overdue_amount,
       c.client_reg_number                                                                  as CIF,
       c.logo                                                                               as Logo
  from contracts c
left join transactions t on t.contract_idt = c.contract_idt
left join opt_dm_contract_attribute attr on c.contract_idt=attr.contract_idt and attr.banking_date=to_date(:P_REPORT_DATE,'dd-MM-yyyy') and attr.org=c.branch_code_posting
left join contract_status rvl on c.contract_idt = rvl.contract_idt
left join inst_bal i on c.contract_idt = i.contract_idt