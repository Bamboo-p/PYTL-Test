/*
* CODE FOR DCC_NONDCC_FX_MTHLY GENERATION
* PyTL_OmniReports_DCC_NONDCC_FX_MTHLY
* Parameters:
*           :ORG                  = '100'
*           :P_REPORT_DATE        = 'DD-MM-YYYY'
*           :CR_NUMBER            = '436406'
*           :DR_NUMBER            = '436406'
*
* Version history:
* 240417.1 = AlexanderK = ENBD-26616:Initial Development
*/

select  fi.branch_code                as ORG
      , d.trans_amount                as TRANS_AMNT
      , d.trans_curr                  as TRANS_CURR
      , d.settl_amount                as SETTL_AMNT
      , d.settl_curr                  as SETTL_CURR
      , mc.contract_number            as TGT_MAIN_C_NUM
      , t.name                        as TRANS_TYPE
      , gtc.amount                    as FEE_AMNT
      , gtc.curr                      as FEE_CURR
      , gt.order_date                 as GL_POSTING_DATE
      , case 
        when gt.gl_trans_code in ('FX_00_ec_F','fx_00_ec_F') then 'FX on credit card'
        when gt.gl_trans_code in ('DCC_MRK_00_vc_F','dcc_mrk_00_vc_F') then 'DCC Markup on VC CC'
        when gt.gl_trans_code in ('DCC_MRK_00_ec_F','dcc_mrk_00_ec_F') then 'DCC Markup on MC CC'
        when gt.gl_trans_code in ('NON_DCC_MRK_00_ec_F','non_dcc_mrk_00_ec_F') then 'NON DCC Markup on MC CC'
        when gt.gl_trans_code in ('NON_DCC_MRK_00_vc_F','non_dcc_mrk_00_vc_F') then 'NON DCC Markup on VC CC'
        else '' 
        end                           as GL_TRANS_CODE
      , gt.amount                     as GL_SYNTH_AMOUNT
      , gt.dr_number                  as GL_DR_NUMBER
      , gt.cr_number                  as GL_CR_NUMBER
      , gt.ref_number                 as REF_NUMBER 
from ows.gl_transfer gt
  join ows.gl_trace gtc on gtc.GL_TRANSFER__ID=gt.ID
  join ows.m_transaction mt on mt.id=gtc.m_transaction__id
  join ows.doc d on d.id=mt.doc__oid
  join ows.acnt_contract c on d.target_contract=c.id
    and c.amnd_state='A'
  join ows.acnt_contract mc on mc.id=c.acnt_contract__oid
    and mc.amnd_state='A'
  join ows.trans_type t on d.trans_type=t.id
    and t.amnd_state='A'
  join ows.f_i fi
    on gt.f_i = fi.id
    and fi.branch_code = :ORG    
where gt.order_date between add_months(trunc(to_date(:P_REPORT_DATE,'dd-mm-yyyy'),'mm'),-1) and last_day(add_months(trunc(to_date(:P_REPORT_DATE,'dd-mm-yyyy'),'mm'),-1))
and gt.GL_TRANS_CODE in ('FX_00_ec_F'
                        ,'fx_00_ec_F'
                        ,'DCC_MRK_00_vc_F'
                        ,'DCC_MRK_00_ec_F'
                        ,'dcc_mrk_00_ec_F'
                        ,'dcc_mrk_00_vc_F'
                        ,'NON_DCC_MRK_00_vc_F'
                        ,'NON_DCC_MRK_00_ec_F'
                        ,'non_dcc_mrk_00_ec_F'
                        ,'non_dcc_mrk_00_vc_F')
and (substr(gt.cr_number,-6)=:CR_NUMBER or substr(gt.dr_number,-6)=:DR_NUMBER)
order by gt.order_date, gtc.id
--and gt.id=494796290
--and gt.f_i=541140

 