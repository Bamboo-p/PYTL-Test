__version__ = "240304.1"
__job_name__ = "PyTL_OmniReports_ELITE_NIGHT_CREDIT_YEARLY_PBF"
__bat_files__ = []
