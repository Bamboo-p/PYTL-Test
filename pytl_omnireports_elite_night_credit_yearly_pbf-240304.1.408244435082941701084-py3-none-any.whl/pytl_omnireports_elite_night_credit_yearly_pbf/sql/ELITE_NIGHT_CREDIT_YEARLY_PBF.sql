/*
* CODE FOR ELITE NIGHT CREDIT YEARLY PBF GENERATION
* PyTL_IS_SimpleReports_ELITE_NIGHT_CREDIT_YEARLY_PBF
* Parameters:
*           :ORGLIST              = '100'
*           :P_REPORT_DATE        = 'DD-MM-YYYY'
*           :P_PROD_CODE_LIST     = '031_ABCD,055_BCDE'
*
* Version history:
* 231226.1 = AlexanderK = ENBD-25639:Initial Development
* 240109.1 = AlexanderK = ENBD-25639:Code Optimisation
* 240112.1 = AlexanderK = ENBD-25639:Yearly Fee removed
* 240124.1 = AlexanderK = ENBD-25639:Code Optimisation
* 240304.1 = AlexanderK = ENBD-25639: Order added
*/

WITH sq_inst AS (
      SELECT  /*+ no_merge materialize */
             inst.id,
             inst.branch_code,
             inst.branch_code_posting,
             inst.posting_institution_id
        FROM (SELECT
                     dwd_institution.branch_code,
                     dwd_institution.posting_institution_id,
                     dwd_institution.id,
                     dwd_institution2.branch_code branch_code_posting
                FROM dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
               WHERE dwd_institution.record_state = 'A'
               ) inst
    START WITH inst.branch_code IN (SELECT TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                      FROM dual
                                CONNECT BY regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL)
    CONNECT BY decode(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id AND level <= 2
    
), logo_list AS (
        select substr(Product_code,1,3) as logo,
               substr(Product_code,5)   as Prod_code
          from (
               SELECT /*+ no_merge materialize*/
                      TRIM(regexp_substr(:P_PROD_CODE_LIST, '[^,]+', 1, level)) Product_code
                 FROM dual
           CONNECT BY regexp_substr(:P_PROD_CODE_LIST, '[^,]+', 1, level) IS NOT NULL
               )
    
), sq_logo AS (
       SELECT /*+ no_merge materialize */
              p.*
         FROM dwd_int_product p
         JOIN sq_inst ON sq_inst.branch_code = substr(code, 1, 3)
        WHERE record_state = 'A'
), sq_cntr1 AS (
       SELECT /*+ no_merge materialize */
              c.*
         FROM opt_dm_contract_info c
         JOIN sq_inst inst ON inst.id = c.institution_id
         JOIN sq_logo logo ON logo.product_id = c.product_id
        WHERE c.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
          AND c.org IN (SELECT DISTINCT branch_code_posting FROM sq_inst)
), sq_cntr2 AS (
       SELECT /*+ leading(c) */
              c.contract_idt,
              MAX(CASE WHEN decision_code = 'BLOCK_CODE_ACC1' THEN decision_result ELSE NULL END) AS bc_1,
              MAX(CASE WHEN decision_code = 'BLOCK_CODE_ACC2' THEN decision_result ELSE NULL END) AS bc_2
         FROM sq_cntr1 c
         JOIN opt_dm_contract_decision d ON d.contract_idt = c.contract_idt
          AND d.decision_result IN ( 'D', 'J', 'X', 'U' )
          AND d.decision_code IN ( 'BLOCK_CODE_ACC1', 'BLOCK_CODE_ACC2' )
          AND d.org IN (SELECT DISTINCT branch_code_posting FROM sq_inst)
          AND d.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
     GROUP BY c.contract_idt
), sq_cntr AS (
       SELECT /*+ no_merge materialize */
              a.*
         FROM sq_cntr1 a
    LEFT JOIN sq_cntr2 b ON b.contract_idt = a.contract_idt
        WHERE b.contract_idt IS NULL
)
, main_sql as (
SELECT /*+ ordered */
          'R;'
       || lpad(ROWNUM, 10, '0')
       || ';'
       || lpad(ROWNUM, 23, '0')
       || ';'
       || '/EID/3000000002/'
       || sq_cntr.primary_card_number
       || ';S;0;'
       || to_char(sysdate, 'YYYYMMDDHH24MI')
       || ';'
       || logo_list.prod_code
       || ';'
       || ';'
       || to_char(nvl(1, 0), 'FM000000000.00')  -- Hardcoded the amount as 1 as per the ENBD-25639 ticket
       || ';EAT/MCC/0000|EAT/TXNCD/999|EAT/AUTHCODE/000000|EAT/CRDBIND/D|EAT/MCNAME/Elite night credit                      |EAT/TXNDATE/'
       || nvl(to_char(sq_cntr.banking_date, 'YYYYMMDD'), '00000000')
       || '|'
       || 'EAT/POSTDATE/'
       || to_char(sysdate, 'yyyymmdd')
       || '|'
       || 'EAT/MERCHANTID1/999999999999999|EAT/PLANNBR/00000|EAT/BONUS/7' AS text
  FROM sq_cntr
  JOIN opt_dm_contract_attribute odca ON odca.contract_idt = sq_cntr.contract_idt
  and odca.spg_flag = 'Y'
  JOIN logo_list on logo_list.logo = sq_cntr.logo
)
select 'H;PBF;'||to_char(sysdate,'YYYYMMDDHH24MI')||';0001;10.00.01' as text from dual
union all
select * from (select text from main_sql order by text)
union all
select 'T;'||(select count(1) from main_sql) as text from dual