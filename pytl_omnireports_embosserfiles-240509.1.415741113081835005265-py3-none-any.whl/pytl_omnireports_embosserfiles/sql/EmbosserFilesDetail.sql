/*
PyTL_OmniReports_EmbosserFiles = EmbosserFilesDetailBody.sql
230818.1: Bharath: NICORE-660: PRN file enhancements
230825.1: Santosh: NICORE-660: Added required fields
230829.1: Santosh: NICORE-660: Alias corection
230831.1: Santosh: NICORE-660: Added Summary Section
231228.1: Hamza: BBY-3190: Adding dates fo the OUTPUT_PREFIX and fixing typos in the files names
*/
with main_query as ( 
 select 'BODY'                                  as ROW_TYPE --[*]231005.1: Hamza: CRKSA-10: Added ROW_TYPE
        ,t_batches.ORG                          as ORG
        ,t_batches.input_filename               as FLNM
        --[+] BEGIN 231120.1: Hamza: BBY-3003: Add Output Filename column
	--[+] BEGIN 231228.1: Hamza: BBY-3003: Adding dates fo the OUTPUT_PREFIX and fixing typos in the files names
        ,CASE
            WHEN SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 1, 5) = 'BBY1' THEN 'BU41R' || TO_CHAR(SYSDATE, 'MMDD')
            WHEN SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 1, 4) = 'BBY2' THEN 'BU42R' || TO_CHAR(SYSDATE, 'MMDD')
            WHEN SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 1, 4) = 'BBY3' THEN 'BU47R' || TO_CHAR(SYSDATE, 'MMDD')
            WHEN SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 1, 4) = 'BBY4' THEN 'BO43R' || TO_CHAR(SYSDATE, 'DD')
            WHEN SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 1, 4) = 'BBY7' and t_records.IN_DATA.ApplicationData.PRTP <> '9' THEN 'BO47R' || TO_CHAR(SYSDATE, 'MMDD')
            WHEN SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 1, 4) = 'BBY7' and t_records.IN_DATA.ApplicationData.PRTP = '9' THEN 'REN_BBY7R' || TO_CHAR(SYSDATE, 'MMDD')
            WHEN SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 1, 4) = 'BBY8' THEN 'B048R' || TO_CHAR(SYSDATE, 'MMDD')
            WHEN SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 1, 5) = 'BBY10' THEN 'B010R' || TO_CHAR(SYSDATE, 'MMDD')
            WHEN SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 1, 5) = 'E0003' THEN 'BO460R' || TO_CHAR(SYSDATE, 'DD')
            WHEN SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 1, 5) = 'E0004' THEN 'BO450R' || TO_CHAR(SYSDATE, 'DD')
            WHEN SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 1, 5) = 'E0005' and (SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 6, 7) IS NULL or SUBSTR(t_records.IN_DATA.ApplicationData.PLSC, 6, 7) <> 'R') THEN 'BO470' || TO_CHAR(SYSDATE, 'DD')
            ELSE 'BUGC' || TO_CHAR(SYSDATE, 'MMDD')
        END AS OUTPUT_PREFIX
	--[+] END 231228.1: Hamza: BBY-3003: Adding dates fo the OUTPUT_PREFIX and fixing typos in the files names
        --[+] END 231120.1: Hamza: BBY-3003: Add Output Filename column
        ,t_records.IN_DATA.ApplicationData.PAND     as PAND
        ,t_records.IN_DATA.ApplicationData.PRTP     as PRTP --[*]230829.1: Santosh: NICORE-660: Alias corection
        ,t_records.IN_DATA.ApplicationData.EXDT     as EXDT
        ,t_records.IN_DATA.ApplicationData.SVCD     as SVCD
        ,t_records.IN_DATA.ApplicationData.CRDN     as CRDN
        ,t_records.IN_DATA.ApplicationData.CMPN     as CMPN
        ,t_records.IN_DATA.ApplicationData.TRC1     as TRC1
        ,t_records.IN_DATA.ApplicationData.PIN1     as PIN1
        ,t_records.IN_DATA.ApplicationData.PIN2     as PIN2
        ,t_records.IN_DATA.ApplicationData.PIN3     as PIN3
        ,t_records.IN_DATA.ApplicationData.PIN4     as PIN4
        ,t_records.IN_DATA.ApplicationData.CITY     as CITY
        ,t_records.IN_DATA.ApplicationData.CNTR     as CNTR
    
        ,t_records.IN_DATA.AddInfo.A1               as A1
        ,t_records.IN_DATA.AddInfo.A2               as A2
        ,t_records.IN_DATA.AddInfo.A3               as A3
        ,t_records.IN_DATA.AddInfo.A4               as A4
        ,t_records.IN_DATA.AddInfo.ACC              as ACC
        ,t_records.IN_DATA.AddInfo.ACCCLN           as ACCCLN
        ,t_records.IN_DATA.AddInfo.ACCCOMP          as ACCCOMP
        ,t_records.IN_DATA.AddInfo.ACCDPT           as ACCDPT
        ,t_records.IN_DATA.AddInfo.ACCLIM           as ACCLIM
        ,t_records.IN_DATA.AddInfo.ACCSTID          as ACCSTID
        ,t_records.IN_DATA.AddInfo.ACTN             as ACTN
        ,t_records.IN_DATA.AddInfo.BR               as BR
        ,t_records.IN_DATA.AddInfo.BR1              as BR1
        ,t_records.IN_DATA.AddInfo.BR2              as BR2
        ,t_records.IN_DATA.AddInfo.CAF              as CAF
        ,t_records.IN_DATA.AddInfo.CCLIM            as CCLIM
        ,t_records.IN_DATA.AddInfo.CID              as CID
        ,t_records.IN_DATA.AddInfo.CLCNTR           as CLCNTR
        ,t_records.IN_DATA.AddInfo.CLIM             as CLIM
        ,t_records.IN_DATA.AddInfo.CLN              as CLN
        ,t_records.IN_DATA.AddInfo.CLRN             as CLRN
        ,t_records.IN_DATA.AddInfo.CLSN             as CLSN
        ,t_records.IN_DATA.AddInfo.COMP             as COMP
        ,t_records.IN_DATA.AddInfo.CRDCCN           as CRDCCN
        ,t_records.IN_DATA.AddInfo.CT               as CT
        ,t_records.IN_DATA.AddInfo.CTY              as CTY
        ,t_records.IN_DATA.AddInfo.CTYPE            as CTYPE
        ,t_records.IN_DATA.AddInfo.CURR             as CURR
        ,t_records.IN_DATA.AddInfo.DDN              as DDN
        ,t_records.IN_DATA.AddInfo.DES              as DES
        ,t_records.IN_DATA.AddInfo.ERN              as ERN
        ,t_records.IN_DATA.AddInfo.EXID             as EXID
        ,t_records.IN_DATA.AddInfo.EXT_UID          as EXT_UID
        ,t_records.IN_DATA.AddInfo.FLAG             as FLAG
        ,t_records.IN_DATA.AddInfo.HPHN             as HPHN
        ,t_records.IN_DATA.AddInfo.IDN              as IDN
        ,t_records.IN_DATA.AddInfo.LCT              as LCT
        ,t_records.IN_DATA.AddInfo.LNG              as LNG
        ,t_records.IN_DATA.AddInfo.LOGO             as LOGO
        ,t_records.IN_DATA.AddInfo.MPHN             as MPHN
        ,t_records.IN_DATA.AddInfo.OPDT             as OPDT
        ,t_records.IN_DATA.AddInfo.PCT              as PCT
        ,t_records.IN_DATA.AddInfo.PCT_EFF          as PCT_EFF
        ,t_records.IN_DATA.AddInfo.PFLAG            as PFLAG
        ,t_records.IN_DATA.AddInfo.PR               as PR
        ,t_records.IN_DATA.AddInfo.PRIM             as PRIM
        ,t_records.IN_DATA.AddInfo.RAF              as RAF
        ,t_records.IN_DATA.AddInfo.REFN             as REFN
        ,t_records.IN_DATA.AddInfo.REFN2            as REFN2
        ,t_records.IN_DATA.AddInfo.REFN3            as REFN3
        ,t_records.IN_DATA.AddInfo.REFN4            as REFN4
        ,t_records.IN_DATA.AddInfo.REFN5            as REFN5
        ,t_records.IN_DATA.AddInfo.REFN6            as REFN6
        ,t_records.IN_DATA.AddInfo.STT              as STT
        ,t_records.IN_DATA.AddInfo.WP               as WP
        ,t_records.IN_DATA.AddInfo.WPHN             as WPHN
        ,t_records.IN_DATA.AddInfo.ZIP              as ZIP
        ,t_records.IN_DATA.AddInfo."UID"            as "UID"
--[+] BEGIN 231005.1: Hamza: CRKSA-10: Added Extra Information
        ,t_records.IN_DATA.ApplicationData.PLSC     as PLSC
        ,t_records.IN_DATA.ApplicationData.CSNB     as CSNB
        ,t_records.IN_DATA.ApplicationData.ADD2     as ADD2
        ,t_records.IN_DATA.ApplicationData.ACX1     as ACX1
        ,t_records.IN_DATA.ApplicationData.ACX2     as ACX2
        ,t_records.IN_DATA.ApplicationData.NMBR     as NMBR
        ,t_records.IN_DATA.ApplicationData.FRSN     as FRSN
        ,t_records.IN_DATA.ApplicationData.LSTN     as LSTN
        ,t_records.IN_DATA.ApplicationData.ZIPC     as ZIPC
        ,t_records.IN_DATA.ApplicationData.ADD1     as ADD1
        ,t_records.IN_DATA.ApplicationData.CRLIM    as CRLIM
        ,t_records.IN_DATA.ApplicationData."9F42"   as EMVT9F42
        ,t_records.IN_DATA.ApplicationData.KEKI     as KEKI
        ,t_records.IN_DATA.ApplicationData.PEKI     as PEKI
        ,t_records.IN_DATA.ApplicationData.MST1     as MST1
        ,t_records.IN_DATA.ApplicationData.MST2     as MST2
        ,t_records.IN_DATA.ApplicationData.PINF     as PINF
        ,t_records.IN_DATA.ApplicationData."5A"     as EMVT5A
--[+] END 231005.1: Hamza: CRKSA-10: Added Extra Information
--[+] BEGIN 231025.1: Hamza: CRKSA-124: Added Extra Information
        ,t_records.IN_DATA.ApplicationData.CVC2     as CVC2
        ,t_records.IN_DATA.ApplicationData."9F1F"   as EMVT9F1F
        ,t_records.IN_DATA.ApplicationData."57"     as EMVT57
        ,t_records.IN_DATA.ApplicationData.PIND     as PIND
        ,t_records.IN_DATA.ApplicationData."5F28"   as EMVT5F28
--[+] END 231025.1: Hamza: CRKSA-124: Added Extra Information
--[+] BEGIN 231115.1: Hamza: BBY-3003: Added Extra Information
        ,t_records.IN_DATA.ApplicationData."5F25"   as EMVT5F25
        ,t_records.IN_DATA.ApplicationData.CVC1     as CVC1
        ,t_records.IN_DATA.ApplicationData.PVVC     as PVVC
        ,t_records.IN_DATA.ApplicationData.ICVV     as ICVV
        ,t_records.IN_DATA.ApplicationData."5F34"   as EMVT5F34
--[+] END 231115.1: Hamza: BBY-3003: Added Extra Information
        ,t_records.IN_DATA.ApplicationData.PVKI     as PVKI --[+] 231117.2: Hamza: BBY-3003: Adding missing data element

--[+] BEGIN 2311211: deniska: BBY-3003: Added Extra fields for FWF format
        ,t_records.IN_DATA.ApplicationData.PAND     as PAND_2
        ,t_records.IN_DATA.ApplicationData."5F25"   as EMVT5F25_2CHR
        ,t_records.IN_DATA.ApplicationData.EXDT     as EXDT_2
        ,''                                         as FILLER_1
        ,t_records.IN_DATA.ApplicationData.CRDN     as CRDN_2
        ,t_records.IN_DATA.ApplicationData.PAND     as PAND_3
        ,t_records.IN_DATA.ApplicationData.EXDT     as EXDT_3
        ,t_records.IN_DATA.ApplicationData.PVKI     as PVKI_2
        ,t_records.IN_DATA.ApplicationData.PVVC     as PVVC_2
        ,t_records.IN_DATA.ApplicationData.CVC1     as CVC1_2
        ,''                                         as FILLER_2
        ,'000000000444555'                          as CONSTANT_TEXT_000000000444555
        ,''                                         as FILLER_3
        ,'~'                                        as TILDA
--[+] END  2311211: deniska: BBY-3003: Added Extra fields for FWF format

      
     from stg_etl.PYTL_INTERFACES_BATCHES t_batches
left join stg_etl.PYTL_INTERFACES_RECORDS t_records on t_records.BATCH_ID = t_batches.UNIQUE_ID
    where t_batches.INPUT_BATCH_UID = :INPUT_BATCH_UID
      and t_batches.ORG = :ORG
      and t_batches.INTERFACE = 'EmbosserFiles'
)
--[+] BEGIN 230831.1: Santosh: NICORE-660: Added Summary Section	
select 
        'HEADER'                                    as ROW_TYPE --[*]231005.1: Hamza: CRKSA-10: Added ROW_TYPE
        ,:ORG                                       as ORG
        ,null                                       as FLNM
        ,null                                       as OUTPUT_PREFIX
        , :ORG||'    EMBOSSER FILE   '||to_char(SYSDATE,'DD-MM-YYYY HH24:MI:SS')  as PAND
        ,null                                       as PRTP 
        ,null                                       as EXDT
        ,null                                       as SVCD
        ,null                                       as CRDN
        ,null                                       as CMPN
        ,null                                       as TRC1
        ,null                                       as PIN1
        ,null                                       as PIN2
        ,null                                       as PIN3
        ,null                                       as PIN4
        ,null                                       as CITY
        ,null                                       as CNTR
        ,null                                       as A1
        ,null                                       as A2
        ,null                                       as A3
        ,null                                       as A4
        ,null                                       as ACC
        ,null                                       as ACCCLN
        ,null                                       as ACCCOMP
        ,null                                       as ACCDPT
        ,null                                       as ACCLIM
        ,null                                       as ACCSTID
        ,null                                       as ACTN
        ,null                                       as BR
        ,null                                       as BR1
        ,null                                       as BR2
        ,null                                       as CAF
        ,null                                       as CCLIM
        ,null                                       as CID
        ,null                                       as CLCNTR
        ,null                                       as CLIM
        ,null                                       as CLN
        ,null                                       as CLRN
        ,null                                       as CLSN
        ,null                                       as COMP
        ,null                                       as CRDCCN
        ,null                                       as CT
        ,null                                       as CTY
        ,null                                       as CTYPE
        ,null                                       as CURR
        ,null                                       as DDN
        ,null                                       as DES
        ,null                                       as ERN
        ,null                                       as EXID
        ,null                                       as EXT_UID
        ,null                                       as FLAG
        ,null                                       as HPHN
        ,null                                       as IDN
        ,null                                       as LCT
        ,null                                       as LNG
        ,null                                       as LOGO
        ,null                                       as MPHN
        ,null                                       as OPDT
        ,null                                       as PCT
        ,null                                       as PCT_EFF
        ,null                                       as PFLAG
        ,null                                       as PR
        ,null                                       as PRIM
        ,null                                       as RAF
        ,null                                       as REFN
        ,null                                       as REFN2
        ,null                                       as REFN3
        ,null                                       as REFN4
        ,null                                       as REFN5
        ,null                                       as REFN6
        ,null                                       as STT
        ,null                                       as WP
        ,null                                       as WPHN
        ,null                                       as ZIP
        ,null                                       as "UID"
        ,null                                       as PLSC
        ,null                                       as CSNB
        ,null                                       as ADD2
        ,null                                       as ACX1
        ,null                                       as ACX2
        ,null                                       as NMBR
        ,null                                       as FRSN
        ,null                                       as LSTN
        ,null                                       as ZIPC
        ,null                                       as ADD1
        ,null                                       as CRLIM
        ,null                                       as EMVT9F42
        ,null                                       as KEKI
        ,null                                       as PEKI
        ,null                                       as MST1
        ,null                                       as MST2
        ,null                                       as PINF
        ,null                                       as EMVT5A
        ,null                                       as CVC2
        ,null                                       as EMVT9F1F
        ,null                                       as EMVT57
        ,null                                       as PIND
        ,null                                       as EMVT5F28
        ,null                                       as EMVT5F25
        ,null                                       as CVC1
        ,null                                       as PVVC
        ,null                                       as ICVV
        ,null                                       as EMVT5F34
        ,null                                       as PVKI

--[+] BEGIN 2311211: deniska: BBY-3003: Added Extra fields for FWF format
        ,null                                       as PAND_2
        ,null                                       as EMVT5F25_2CHR
        ,null                                       as EXDT_2
        ,null                                       as FILLER_1
        ,null                                       as CRDN_2
        ,null                                       as PAND_3
        ,null                                       as EXDT_3
        ,null                                       as PVKI_2
        ,null                                       as PVVC_2
        ,null                                       as CVC1_2
        ,null                                       as FILLER_2
        ,null                                       as CONSTANT_TEXT_000000000444555
        ,null                                       as FILLER_3
        ,null                                       as TILDA
--[+] END  2311211: deniska: BBY-3003: Added Extra fields for FWF format

from 
    dual
where upper(substr(nvl(:INCLUDE_HEADER,'N'),1,1)) = 'Y'
union all
select 
        *
    from
        main_query t1 
 union all
    select
        'TAIL'                                      as ROW_TYPE --[*]231005.1: Hamza: CRKSA-10: Added ROW_TYPE
        ,t2.ORG                                     as ORG
        ,null                                       as FLNM
        ,null                                       as OUTPUT_PREFIX
        ,'TOTAL COUNT   :   '||count(org)           as PAND
        ,null                                       as PRTP 
        ,null                                       as EXDT
        ,null                                       as SVCD
        ,null                                       as CRDN
        ,null                                       as CMPN
        ,null                                       as TRC1
        ,null                                       as PIN1
        ,null                                       as PIN2
        ,null                                       as PIN3
        ,null                                       as PIN4
        ,null                                       as CITY
        ,null                                       as CNTR
        ,null                                       as A1
        ,null                                       as A2
        ,null                                       as A3
        ,null                                       as A4
        ,null                                       as ACC
        ,null                                       as ACCCLN
        ,null                                       as ACCCOMP
        ,null                                       as ACCDPT
        ,null                                       as ACCLIM
        ,null                                       as ACCSTID
        ,null                                       as ACTN
        ,null                                       as BR
        ,null                                       as BR1
        ,null                                       as BR2
        ,null                                       as CAF
        ,null                                       as CCLIM
        ,null                                       as CID
        ,null                                       as CLCNTR
        ,null                                       as CLIM
        ,null                                       as CLN
        ,null                                       as CLRN
        ,null                                       as CLSN
        ,null                                       as COMP
        ,null                                       as CRDCCN
        ,null                                       as CT
        ,null                                       as CTY
        ,null                                       as CTYPE
        ,null                                       as CURR
        ,null                                       as DDN
        ,null                                       as DES
        ,null                                       as ERN
        ,null                                       as EXID
        ,null                                       as EXT_UID
        ,null                                       as FLAG
        ,null                                       as HPHN
        ,null                                       as IDN
        ,null                                       as LCT
        ,null                                       as LNG
        ,null                                       as LOGO
        ,null                                       as MPHN
        ,null                                       as OPDT
        ,null                                       as PCT
        ,null                                       as PCT_EFF
        ,null                                       as PFLAG
        ,null                                       as PR
        ,null                                       as PRIM
        ,null                                       as RAF
        ,null                                       as REFN
        ,null                                       as REFN2
        ,null                                       as REFN3
        ,null                                       as REFN4
        ,null                                       as REFN5
        ,null                                       as REFN6
        ,null                                       as STT
        ,null                                       as WP
        ,null                                       as WPHN
        ,null                                       as ZIP
--[+] BEGIN 231005.1: Hamza: CRKSA-10: Added Extra Information
        ,null                                       as "UID"
        ,null                                       as PLSC
        ,null                                       as CSNB
        ,null                                       as ADD2
        ,null                                       as ACX1
        ,null                                       as ACX2
        ,null                                       as NMBR
        ,null                                       as FRSN
        ,null                                       as LSTN
        ,null                                       as ZIPC
        ,null                                       as ADD1
        ,null                                       as CRLIM
        ,null                                       as EMVT9F42
        ,null                                       as KEKI
        ,null                                       as PEKI
        ,null                                       as MST1
        ,null                                       as MST2
        ,null                                       as PINF
        ,null                                       as EMVT5A
        ,null                                       as CVC2
        ,null                                       as EMVT9F1F
        ,null                                       as EMVT57
        ,null                                       as PIND
        ,null                                       as EMVT5F28
--[+] END 231005.1: Hamza: CRKSA-10: Added Extra Information
        ,null                                       as EMVT5F25
        ,null                                       as CVC1
        ,null                                       as PVVC
        ,null                                       as ICVV
        ,null                                       as EMVT5F34
        ,null                                       as PVKI
        
--[+] BEGIN 2311211: deniska: BBY-3003: Added Extra fields for FWF format
        ,null                                       as PAND_2
        ,null                                       as EMVT5F25_2CHR
        ,null                                       as EXDT_2
        ,null                                       as FILLER_1
        ,null                                       as CRDN_2
        ,null                                       as PAND_3
        ,null                                       as EXDT_3
        ,null                                       as PVKI_2
        ,null                                       as PVVC_2
        ,null                                       as CVC1_2
        ,null                                       as FILLER_2
        ,null                                       as CONSTANT_TEXT_000000000444555
        ,null                                       as FILLER_3
        ,null                                       as TILDA
--[+] END  2311211: deniska: BBY-3003: Added Extra fields for FWF format
    from
        main_query t2
    group by 
        ORG
    having upper(substr(nvl(:INCLUDE_TAIL,'N'),1,1)) = 'Y'
--[+] END 230831.1: Santosh: NICORE-660: Added Summary Section