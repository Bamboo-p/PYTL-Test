/*
PyTL_OmniReports_EmbosserFiles = EmbosserFilesDeatailTimestamp.sql
230818.1: Bharath: NICORE-660: PRN file enhancements*/
  select :ORG||'    EMBOSSER FILE   '||to_char(SYSDATE,'DD-MM-YYYY HH24:MI:SS')  as TITLE
    from dual
