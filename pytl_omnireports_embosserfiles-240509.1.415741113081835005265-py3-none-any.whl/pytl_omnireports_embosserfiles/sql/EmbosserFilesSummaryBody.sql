/*
PyTL_OmniReports_EmbosserFiles = EmbosserFilesSummaryBody.sql
230721.2: deniska: NICORE-660: Initial development
230807.1: deniska: NICORE-660: added mandatory field ORG
230818.1: Bharath: NICORE-660: PRN_P1 file enhancements
230824.2: deniska: NICORE-660: convertion into single SQL
230830.1: santosh: NICORE-660: logic change to populate total count
230831.1: santosh: NICORE-660: INSTNM tag correction
230914.1: santosh: NICORE-660: ACTNTYPE logic change and field addition
240130.1: Shalini: NICORE-1145: Logic correction for field RECORDS_COUNT
240508.1: HamzaD: PRD-27318: Fixing count issue when processing multiple files
*/
with main_query as (
        select DISTINCT
            t_batches.ORG                                                   as ORG
            ,t_records.IN_DATA.AddInfo.INSTNM                             	as INSTNAME --[*]230830.2: santosh: NICORE-660: INSTNM tag correction
            ,t_batches.INPUT_FILENAME                                       as FILENAME
            ,t_records.IN_DATA.AddInfo.PR                                   as PR            
            --[*]BEGIN 230914.1: santosh: NICORE-660: ACTNTYPE logic change and field addition
--            ,decode(t_records.IN_DATA.AddInfo.ACTN,1,
--                    'NEW',3,'REISSUE/REPLACE',
--                    5,'PIN MAILER',7,'RENEWAL')                             as ACTNTYPE
            ,CASE WHEN t_records.IN_DATA.AddInfo.RAF = 'R' THEN 'Replace'
                  WHEN t_records.IN_DATA.AddInfo.RAF = 'N' THEN
                      CASE WHEN t_records.IN_DATA.AddInfo.ACTN = 1 THEN  'New Issue'
                           WHEN t_records.IN_DATA.AddInfo.ACTN = 3 THEN  'Reissue'
                           WHEN t_records.IN_DATA.AddInfo.ACTN = 7 THEN  'Renewal'
                           WHEN t_records.IN_DATA.AddInfo.ACTN = 5 THEN  'PIN Reissue' END
                   END                                                      as ACTNTYPE      
            ,t_records.IN_DATA.AddInfo.ACTN                                 as ACTN
            ,t_records.IN_DATA.AddInfo.RAF                                  as RAF
            ,t_records.IN_DATA.ApplicationData.PRTP                         as PRTP
            --[*]BEGIN 230914.1: santosh: NICORE-660: ACTNTYPE logic change and field addition
            ,count(*) over (partition by t_records.IN_DATA.AddInfo.ACTN,t_records.IN_DATA.AddInfo.RAF,t_records.IN_DATA.AddInfo.PR,t_batches.UNIQUE_ID)    as RECORDS_COUNT --[*] 240130.1 = NICORE-1145

         from stg_etl.PYTL_INTERFACES_BATCHES t_batches
    left join stg_etl.PYTL_INTERFACES_RECORDS t_records on t_records.BATCH_ID = t_batches.UNIQUE_ID
        where t_batches.INPUT_BATCH_UID = :INPUT_BATCH_UID
          and t_batches.ORG = :ORG
          and t_batches.INTERFACE = 'EmbosserFiles'
)
    select
        t1.ORG                                                              as ORG
        ,t1.INSTNAME                                                        as INSTNAME
        ,t1.FILENAME                                                        as FILENAME
        ,t1.PR                                                              as PR
        ,t1.ACTNTYPE                                                        as ACTNTYPE
        ,t1.ACTN                                                            as ACTN
        ,t1.RAF                                                             as RAF
        ,t1.PRTP                                                            as PRTP
        ,t1.RECORDS_COUNT                                                   as RECORDS_COUNT
    from
        main_query t1
union all
    select
        t2.ORG                                                              as ORG
        ,'TOTAL COUNT   :   '||sum(RECORDS_COUNT)                           as INSTNAME --[*]230830.1: santosh: NICORE-660: logic change to populate total count
        ,null                                                               as FILENAME
        ,null                                                               as PR
        ,null                                                               as ACTNTYPE
        ,null                                                               as ACTN
        ,null                                                               as RAF
        ,null                                                               as PRTP
        ,null                                                               as RECORDS_COUNT
    from
        main_query t2
    group by 
        ORG
