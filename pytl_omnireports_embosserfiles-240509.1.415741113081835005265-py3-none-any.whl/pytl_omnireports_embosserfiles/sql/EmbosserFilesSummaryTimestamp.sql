/*
PyTL_OmniReports_EmbosserFiles = EmbosserFilesDeatailTimestamp.sql
230830.1: Santosh: NICORE-660: PRN_P1 file enhancements*/
  select :ORG||'    '||to_char(SYSDATE,'DD-MM-YYYY HH24:MI:SS')  as TITLE
    from dual
