select distinct 
    t_batches.ORG,
    t_batches.INPUT_BATCH_UID
    ,t_batches.INPUT_DATETIME
from
    stg_etl.PYTL_INTERFACES_BATCHES t_batches
    where t_batches.INTERFACE = 'EmbosserFiles'
order by
    t_batches.INPUT_DATETIME desc

