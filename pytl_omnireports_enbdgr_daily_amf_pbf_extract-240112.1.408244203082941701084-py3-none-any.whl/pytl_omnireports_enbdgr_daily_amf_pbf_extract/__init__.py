__version__ = "240112.1"
__job_name__ = "PyTL_OmniReports_ENBDGR_DAILY_AMF_PBF_EXTRACT"
__bat_files__ = []
