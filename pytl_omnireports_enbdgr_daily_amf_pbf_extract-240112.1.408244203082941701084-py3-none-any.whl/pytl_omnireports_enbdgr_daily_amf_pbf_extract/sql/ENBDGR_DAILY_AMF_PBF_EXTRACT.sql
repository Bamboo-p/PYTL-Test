/*
* CODE FOR ENBDGR_DAILY_AMF_PBF_EXTRACT
* PyTL_IS_OmniReports_ENBDGR_DAILY_AMF_PBF_EXTRACT=ENBDGR_DAILY_AMF_PBF_EXTRACT.sql
* Parameters:
*           :ORGLIST              = '033,010'
*           :P_REPORT_DATE        = 'DD-MM-YYYY'
*           :P_PROD_CODE_LIST     = '031_ABCD,055_BCDE'
*           :P_AMF_TXN_LIST       = '505,525'
*           :P_NUM_PDD            = '3'
*
* Version history:
* 231212.1 = RakeshG = ENBD-25194:Initial Version
* 231225.1 = RakeshG = ENBD-25775:Fixed payment done on the PDD txn was not considered.
* 240112.1 = RakeshG = ENBD-25868:Changed the value from 5 to 6 as it is AMF report.
*/

WITH inst as (
      SELECT  /*+ no_merge materialize */
             inst.id,
             inst.branch_code,
             inst.branch_code_posting,
             inst.posting_institution_id
        FROM (SELECT dwd_institution.branch_code,
                     dwd_institution.posting_institution_id,
                     dwd_institution.id,
                     dwd_institution2.branch_code branch_code_posting
                FROM dwd_institution
                JOIN dwd_institution dwd_institution2
                  ON dwd_institution.posting_institution_id = dwd_institution2.id
               WHERE dwd_institution.record_state = 'A'
              ) inst
   START WITH inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                     from dual
                               connect by regexp_substr(:ORGLIST , '[^,]+', 1, level) is not null)
   CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = prior inst.id
        AND level <= 2
)
, logo_list AS (
        select substr(Product_code,1,3) as logo,
               substr(Product_code,5)   as Prod_code
          from (
               SELECT /*+ no_merge materialize*/
                      TRIM(regexp_substr(:P_PROD_CODE_LIST, '[^,]+', 1, level)) Product_code
                 FROM dual
           CONNECT BY regexp_substr(:P_PROD_CODE_LIST, '[^,]+', 1, level) IS NOT NULL
               )
)
, amf_txn_list AS (
SELECT /*+ no_merge materialize*/
                      TRIM(regexp_substr(:P_AMF_TXN_LIST, '[^,]+', 1, level)) TXN_CODE
                 FROM dual
           CONNECT BY regexp_substr(:P_AMF_TXN_LIST, '[^,]+', 1, level) IS NOT NULL
)
, attr AS (
   SELECT /*+ no_merge materialize */
          id
     FROM dwd_attribute
    WHERE type_code = 'LTY_ENROLL'
      AND code = 'Y'
      AND dwd_attribute.record_state <> 'C'
      AND dwd_attribute.record_date_to >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
      AND dwd_attribute.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
)
, op AS (
    SELECT /*+ no_merge materialize */
           *
      FROM v_dwr_operation_type op
     WHERE op.class_code = 'ENBD_REPORTS'
       AND op.type_code = 'TURNOVERS'
       AND op.code = 'PAYMENT'
)
, fee AS (
    SELECT /*+ materialize */
        fee_temp.contract_idt,
        fee_temp.period_start_date,
        fee_temp.BILLING_DATE,        
        SUM(fee_temp.debit)        AnnualMembershipFee,
        MAX(fee_temp.banking_date) banking_date
    FROM
        (SELECT /*+ no_merge use_nl_with_index(e DWF_ACCOUNT_ENTRY_OP_IDX) use_nl_with_index(b1 DWF_CNTR_BILLING_DATE_IDX) */
                e.contract_idt,
                e.debit,
                e.banking_date,
                bl.period_start_date,
                bl.BILLING_DATE
           FROM dwf_account_entry e
           JOIN v_dwr_operation_type op ON ( e.operation_type_id = op.operation_type_id )
           JOIN inst on inst.posting_institution_id = e.institution_id
           JOIN dwf_contract_billing bl ON bl.contract_idt = e.contract_idt
            AND bl.due_date = to_date(:P_REPORT_DATE,'DD-MM-YYYY')
          WHERE op.class_code = inst.branch_code_posting||'_TXN_CODE'
            AND op.type_code = 'TXN_CODE'
            AND op.code in (select TXN_CODE from amf_txn_list)
            AND e.banking_date <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
            AND e.banking_date >= add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'), - :P_NUM_PDD)) fee_temp
 GROUP BY fee_temp.contract_idt,
          fee_temp.period_start_date,
          fee_temp.BILLING_DATE
)
, billing_info AS (
        select /*+ ordered use_nl_with_index(bill DWF_CNTR_BILLING_DATE_IDX) */
               fee.contracT_idt,
               bill.due_date,
               fee.banking_date,
               lag(due_date) over(PARTITION BY bill.contract_idt order by bill.due_date) as prev_due,
               row_number() over(partition by bill.contract_idt order by bill.due_date desc) rn 
          from fee
          join dwf_contracT_billing bill on bill.contract_idt = fee.contract_idt
           and bill.due_date > fee.banking_date
           and bill.due_date <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
)
, ctd_pmt AS (
      SELECT /*+ ordered use_nl_with_index(e DWF_ACCOUNT_ENTRY_CONT_IDX) */
             fee.contract_idt,
             sum(coalesce(e.credit, 0) - coalesce(e.debit, 0)) AS ctd_pmt_amt,
             count(1)
        FROM fee
        join billing_info bill on bill.contract_idt = fee.contract_idt and bill.rn = 1
        JOIN dwf_account_entry e ON fee.contract_idt = e.contract_idt
         AND e.banking_date between nvl(bill.prev_due,fee.banking_date) and bill.due_date
        JOIN op ON op.operation_type_id = e.operation_type_id
        JOIN inst on inst.posting_institution_id = e.institution_id
    group by fee.contract_idt having count(1) > 0 and sum(coalesce(e.credit, 0) - coalesce(e.debit, 0)) > 0
)
, AMF_LOGO_CHECK as (
             select * 
			   from (select c.contract_idt,
                            cd.pan,
                            c.ctd_pmt_amt,
                            ROW_NUMBER() OVER(PARTITION BY cd.main_contract_idt ORDER BY nvl(cd.effective_date, TO_DATE('01.01.1990', 'dd.mm.yyyy')) DESC, cd.record_idt DESC) rn,
                            substr(p.product_code,9,3) as logo
                       from ctd_pmt c
                       JOIN fee f on f.contract_idt = c.contract_idt
                       JOIN dwd_card cd ON cd.main_contract_idt = c.contract_idt
                       JOIN inst on inst.id = cd.institution_id
                       JOIN dwd_card_product p on p.id = cd.card_product_id
                        AND p.record_date_from <= f.banking_date
                        AND p.record_date_to >= f.banking_date
                        AND substr(p.product_code,1,3) = inst.branch_code
                      WHERE cd.record_date_from <= f.banking_date
                        AND cd.record_date_to >= f.banking_date
                        AND cd.main_card_flag = 'Y')
				where logo in (select logo from logo_list) and rn = 1
)
, pay AS (
  SELECT /*+ materialize*/
         pay_temp.contract_idt,
         bill.due_date,
         SUM(case when pay_temp.payment_date <= bill.due_date then pay_temp.cdrtmindbt else 0 end) AS cdrtmindbt
    FROM(SELECT  /*+ ordered use_nl_with_index(e, DWF_ACCOUNT_ENTRY_CONT_IDX) parallel_index(e, DWF_ACCOUNT_ENTRY_CONT_IDX,4)*/
                e.contract_idt,
                e.banking_date as payment_Date,
                coalesce(e.credit, 0) - coalesce(e.debit, 0) AS cdrtmindbt
           FROM ctd_pmt c
		   JOIN fee f on f.contract_idt = c.contract_idt
           JOIN AMF_LOGO_CHECK amf on amf.contract_idt = c.contracT_idt
           JOIN dwf_account_entry e ON c.contract_idt = e.contract_idt
           JOIN op ON op.operation_type_id = e.operation_type_id
            AND e.banking_date <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
            AND e.banking_date > f.banking_date
           JOIN inst on inst.posting_institution_id = e.institution_id) pay_temp
     JOIN billing_info bill on bill.contract_idt = pay_temp.contract_idt
    WHERE pay_temp.cdrtmindbt <> 0
 GROUP BY pay_temp.contract_idt,bill.due_date
)
, pass_check as (
         select 
                fee.contract_idt,
                count(1) 
           from fee
           join pay on pay.contract_idt = fee.contract_idt 
            and pay.cdrtmindbt >= fee.annualmembershipfee 
       group by fee.contract_idt having count(1) = 1
)
, primary_card AS (
           select * 
             from (SELECT /*+ materialize ordered use_nl_with_index(cd, DWD_CARD_MAIN_CNTR_IDX)*/
                          cd.record_idt    AS primary_card_idt,
                          cd.pan,
                          cd.main_contract_idt,
                          cd.embossed_last_name,
                          cd.embossed_company,
                          cd.expiry_date,
                          cd.effective_date,
                          cd.opening_date,
                          cd.add_info,
                          ROW_NUMBER() OVER(PARTITION BY cd.main_contract_idt ORDER BY nvl(effective_date, TO_DATE('01.01.1990', 'dd.mm.yyyy')) DESC, cd.record_idt DESC) rn,
                          cd.lost_card_idt AS primary_card_lost_card_idt,
                          substr(p.product_code,9,3) as logo
                     FROM pass_check pc
                     JOIN dwd_card cd ON cd.main_contract_idt = pc.contract_idt
                     JOIN inst on inst.id = cd.institution_id
                     JOIN dwd_card_product p on p.id = cd.card_product_id
                      AND p.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
                      AND p.record_date_to >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
                      AND substr(p.product_code,1,3) = inst.branch_code
                    WHERE cd.record_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
                      AND cd.record_date_to >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
                      AND cd.main_card_flag = 'Y') where logo in (select logo from logo_list) and rn = 1
)
, main_sql as (
SELECT /*+ ordered */
          'R;'
       || lpad(ROWNUM, 10, '0')
       || ';'
       || lpad(ROWNUM, 23, '0')
       || ';'
       || '/EID/3000000002/'
       || primary_card.pan
       || ';S;0;'
       || to_char(sysdate, 'YYYYMMDDHH24MI')
       || ';'
       || logo_list.prod_code
       || ';'
       || ';'
       || to_char(nvl(fee.AnnualMembershipFee, 0), 'FM000000000.00')
       || ';EAT/MCC/0000|EAT/TXNCD/999|EAT/AUTHCODE/000000|EAT/CRDBIND/D|EAT/MCNAME/Annual Maintainence Fee Bonus           |EAT/TXNDATE/'
       || nvl(to_char(fee.banking_date, 'YYYYMMDD'), '00000000')
       || '|'
       || 'EAT/POSTDATE/'
       || to_char(sysdate, 'yyyymmdd')
       || '|'
       || 'EAT/MERCHANTID1/999999999999999|EAT/PLANNBR/00000|EAT/BONUS/6' AS text --[*] ENBD-25868 = Rakesh = Changed value from 5 to 6
  FROM fee
  JOIN (SELECT ca.contract_idt
          FROM dwa_contract_attribute ca
          JOIN attr ON ( ca.attr_id = attr.id)
         WHERE ca.attr_date_from <= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
           AND ca.attr_date_to >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
        )dca ON dca.contract_idt = fee.contract_idt
  JOIN primary_card ON primary_card.main_contract_idt = fee.contract_idt
  JOIN logo_list on logo_list.logo = primary_card.logo
)
select 'H;PBF;'||to_char(sysdate,'YYYYMMDDHH24MI')||';0001;10.00.01' as text from dual
union all
select text from main_sql
union all
select 'T;'||(select count(1) from main_sql) as text from dual