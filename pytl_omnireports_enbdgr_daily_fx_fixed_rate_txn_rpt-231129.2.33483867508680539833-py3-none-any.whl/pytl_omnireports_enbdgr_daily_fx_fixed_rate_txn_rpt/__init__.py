__version__ = "231129.2"
__job_name__ = "PyTL_OmniReports_ENBDGR_DAILY_FX_FIXED_RATE_TXN_RPT"
__bat_files__ = []
