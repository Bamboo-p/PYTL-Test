/*
* CODE FOR ENBD TEMPORARY DAILY FIXED RATE TRANS EXTRACT
* PyTL_IS_OmniReports_ENBD_TEMP_DAILY_FX_FIXED_RATE_TXN_RPT=ENBD_TEMP_DAILY_FX_FIXED_RATE_TXN_RPT.sql
* This job is used to generate two file one for the ENBD and one for the DP portal posting of txns
* Parameters:
*           :ORG                  = '100'
*           :P_REPORT_DATE        = 'DD-MM-YYYY'
*           :P_LOGO_LIST          = '045,046'
*           :P_CLIENT_LIST        = '000000000000001,000000000000002,0000000000000003'
*           :P_TXNCURR            = 'USD'
*           :P_FX_RATE            = '3.65'
*           :P_PAYMENT_SCHEME     = 'MasterCard International'
*           :P_TXN_FILTER         = 'FORCE_POST_RPT=Y;'
*
* Version history:
* 231124.1 = RakeshG = ENBD-25448:Initial Version
* 231129.1 = RakeshG = ENBD-25601: Introduced new parameters to limit it to only Retail transaction type and to Mastercard only.
*/

WITH
sq_client_list AS (
           SELECT /*+ no_merge materialize*/
                  TRIM(regexp_substr(:P_CLIENT_LIST, '[^,]+', 1, level)) client_number
             FROM dual
       CONNECT BY regexp_substr(:P_CLIENT_LIST, '[^,]+', 1, level) IS NOT NULL
)
, sq_logo_list AS (
           SELECT /*+ no_merge materialize*/
                  TRIM(regexp_substr(:P_LOGO_LIST, '[^,]+', 1, level)) logo
             FROM dual
       CONNECT BY regexp_substr(:P_LOGO_LIST, '[^,]+', 1, level) IS NOT NULL
)
, sq_cntr AS (
      SELECT /*+ no_merge materialize ordered */
             info.*
        FROM sq_client_list cl
        JOIN dwd_client c ON cl.client_number = c.client_number
        JOIN dwd_contract cc ON c.record_idt = cc.client_idt
         AND cc.record_state = 'A'
        JOIN opt_dm_contract_info info ON cc.record_idt = info.parent_contract_idt
         AND info.org = :ORG
         AND info.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        JOIN dwd_product p on p.id = info.product_id and p.record_state = 'A'
         AND p.payment_scheme = :P_PAYMENT_SCHEME
        JOIN sq_logo_list l ON l.logo = info.logo
       WHERE c.record_state = 'A'
)
, sq_trns AS (
      SELECT
             cc.logo,
             cc.contract_number,
             cc.bank_code,
             cc.org,
             t.trans_amount,
             t.txn_code,
             t.trans_date,
             nvl(t.trans_amount * nvl(:P_FX_RATE, 1), 0)                          AS converted_amnt,
             nvl(t.trans_amount * nvl(:P_FX_RATE, 1), 0) - nvl(t.settl_amount, 0) AS diff_amnt,
             t.auth_code,
             t.trans_currency,
             t.trans_details,
             t.settl_amount,
             t.card_idt,
             t.trans_country_code,
             t.trans_city,
             t.settl_currency
        FROM sq_cntr cc
        JOIN opt_dm_transaction t ON cc.contract_idt = t.contract_idt
         AND t.org = :ORG
         AND t.direction = '-1'
         AND t.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
        JOIN dwd_currency c ON c.code = t.trans_currency
         AND c.record_state = 'A'
         AND c.name = :P_TXNCURR
		 AND instr(t.OPER_TYPE_ADD_INFO,:P_TXN_FILTER) > 0
)
SELECT /*+ leading(t) */
       t.bank_code                                   AS Org,
       ROWNUM                                        AS SRNO,
        ''                                           AS Org_,
       t.logo                                        AS Product_number,
       card.pan                                      AS CardNumber,
        ''                                           AS AcctNumber,
       ltrim(to_char(abs(t.diff_amnt), '9999999990.00'), ' ') AS Amount,
       t.contract_number                             AS Employee_Contract_Number,
       CASE WHEN t.diff_amnt > 0 THEN '044'
            WHEN t.diff_amnt < 0 THEN '045' END      AS TxnCode,
       ''                                            AS EffectiveDate,
       '0'                                           AS Plan,
       ''                                            AS SeqNo,	   
       rpad('AED'
            || ' '
            || ltrim(to_char(t.settl_amount, '9999999990.00'), ' ')
            || ' '
            || 'FX ADJ'
            || ' '
            || t.trans_details
            || ' '
            || t.trans_city
            || ' '
            || t.trans_country_code, 40, ' ')         AS Narration,	   
       t.auth_code                                    AS AuthCode,
        ''                                            AS CreditAccNo,
        ''                                            AS DebitAccNo,
       '784'                                          AS Currency,		
       'L4'                                           AS AccountType,	   
       t.trans_details                                AS Transaction_Description,
       t.trans_currency                               AS Source_Transaction_Currency,
       t.trans_amount                                 AS Source_Transaction_Amount,
       t.settl_amount                                 AS Cardholder_Billing_Amount,
       nvl(:P_FX_RATE, 1)                             AS Enbd_Fixed_Rate,
       t.converted_amnt                               AS Converted_Amount_In_AED,
       t.diff_amnt                                    AS Difference_Amount
  FROM sq_trns t
  JOIN dwd_card card ON card.record_idt = t.card_idt
   AND card.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
   AND card.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
 WHERE t.diff_amnt != 0