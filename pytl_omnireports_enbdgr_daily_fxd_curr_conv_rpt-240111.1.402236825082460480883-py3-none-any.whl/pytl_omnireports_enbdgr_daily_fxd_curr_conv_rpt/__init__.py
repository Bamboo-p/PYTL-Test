__version__ = "240111.1"
__job_name__ = "PyTL_OmniReports_ENBDGR_DAILY_FXD_CURR_CONV_RPT"
__bat_files__ = []
