/*
* CODE FOR ENBD FIXED CURRENCY ENABLED CUSTOMER
* PyTL_IS_OmniReports_ENBDGR_DAILY_FXD_CURR_CONV_RPT=ENBDGR_DAILY_FXD_CURR_CONV_RPT.sql
* Parameters:
*           :ORGLIST              = '100'
*           :P_REPORT_DATE        = 'DD-MM-YYYY'
*           :P_LOGO_LIST          = '027,030'
*           :P_TXNCURR            = 'USD'
*           :P_PAYMENT_SCHEME     = 'MasterCard International'
*           :P_DELIMITER          = ','
*           :P_TXNCODE_LIST       = '340,341,150,151,030,031'
*
* Version history:
* 231213.1 = RakeshG = ENBD-25330:Initial Version
* 231221.1 = RakeshG = ENBD-25737:Fixed the calculative fields and added new fields(direction/txn code) as requested.
* 231221.1 = RakeshG = ENBD-25817:FX amount correction for non fixed currency transactions and removed the flag check.
*/

WITH sq_inst AS (
    SELECT  /*+ no_merge materialize */
        inst.id,
        inst.branch_code,
        inst.branch_code_posting
    FROM
        (SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code branch_code_posting
            FROM
                     dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY decode(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
)
, sq_logo_list AS (
    SELECT /*+ no_merge materialize*/
        TRIM(regexp_substr(:P_LOGO_LIST, '[^,]+', 1, level)) logo
    FROM
        dual
    CONNECT BY
        regexp_substr(:P_LOGO_LIST, '[^,]+', 1, level) IS NOT NULL
)
, sq_txncode_list AS (
    SELECT /*+ no_merge materialize*/
        TRIM(regexp_substr(:P_TXNCODE_LIST, '[^,]+', 1, level)) txn_code
    FROM
        dual
    CONNECT BY
        regexp_substr(:P_TXNCODE_LIST, '[^,]+', 1, level) IS NOT NULL
)
, sq_cntr AS (
       SELECT /*+ no_merge materialize ordered */
              info.*
         FROM opt_dm_contract_info info
         JOIN sq_inst     inst ON inst.id = info.institution_id
/*         JOIN (SELECT
                      att.contract_idt
                 FROM dwa_contract_attribute att
                 JOIN dwd_attribute da ON att.attr_id = da.id
                  AND da.record_state = 'A'
                  AND da.type_code = 'FIX_RATE_FLAG'
                  AND da.code = 'Y'
                WHERE att.attr_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                  AND att.attr_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
              )att ON att.contract_idt = info.contract_idt */
        JOIN dwd_product p ON p.id = info.product_id
         AND p.record_state = 'A'
         AND p.payment_scheme = :P_PAYMENT_SCHEME
       WHERE info.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
         AND info.logo IN (SELECT logo FROM sq_logo_list)
)
, sq_trns AS (
       SELECT * 
	     FROM (SELECT /*+ ordered use_nl(t)*/
                      c.bank_code,
                      c.org,
                      c.logo,
                      c.contract_number,
                      card.pan,
                      t.doc_idt,
                      t.trans_amount,
                      t.trans_currency,
                      (t.amount - nvl(e.credit - e.debit,0)) * -1 AS billed_amount,
                      (t.settl_amount * t.direction) * -1 AS settl_amount,
                      t.direction,
                      (nvl((t.settl_amount * t.direction), 0) - nvl(t.amount - nvl(e.credit - e.debit,0) , 0))   AS diff_amnt,
                      t.txn_code,
                      decode(t.direction,-1,'D','C') as Trans_Type
                 FROM sq_cntr c
                 JOIN opt_dm_transaction t ON c.contract_idt = t.contract_idt
                  AND t.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                  AND t.org = c.org
	        	 JOIN sq_txncode_list tl on tl.txn_code = t.txn_code
                 JOIN dwd_currency curr ON curr.code = t.trans_currency
                  AND curr.record_state = 'A'
                  AND curr.name = :P_TXNCURR
                 JOIN dwd_card card ON card.record_idt = t.card_idt
	        	  AND card.main_contracT_idt = c.contract_idt
                  AND card.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                  AND card.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
            LEFT JOIN dwf_account_entry e on e.primary_doc_idt = t.doc_idt
                  AND e.contracT_idt = t.contracT_idt 
                  AND e.banking_date = t.banking_date
                  AND e.fee_code = 'MARKUP') 
		WHERE diff_amnt <> 0
), sq_header AS (
         SELECT NULL AS org,
                'Sr'||:P_DELIMITER|| 'Logo'||:P_DELIMITER|| 'Card Number'||:P_DELIMITER|| 'Post to A/C'||:P_DELIMITER||'Txn Code'||:P_DELIMITER||'Txn Type'||:P_DELIMITER|| 'Transaction Amount'||:P_DELIMITER|| 'Transaction Curr'||:P_DELIMITER|| 'Incoming billing Amount (MC)'||:P_DELIMITER||'Calc Billing Amt Bank Fixed rate'||:P_DELIMITER||'Difference Amount' AS text
           FROM dual
)
, main_sql AS (
        SELECT /*+ leading(t) */
               t.org,
               ROWNUM||:P_DELIMITER|| t.logo||:P_DELIMITER|| t.pan||:P_DELIMITER|| t.contract_number||:P_DELIMITER||t.txn_code||:P_DELIMITER||t.Trans_Type||:P_DELIMITER|| t.trans_amount||:P_DELIMITER|| t.trans_currency||:P_DELIMITER|| t.settl_amount||:P_DELIMITER|| ltrim(to_char(t.billed_amount, '9999999990.00'), ' ')|| :P_DELIMITER|| ltrim(to_char(t.diff_amnt, '9999999990.00'), ' ') AS text
          FROM sq_trns t
), sq_summary AS (
    SELECT
        org,
        logo||:P_DELIMITER|| total_settlement_amount||:P_DELIMITER|| total_billed_amount||:P_DELIMITER|| total_difference AS text
    FROM
        (SELECT
                t.org,
                t.logo,
                ltrim(to_char(SUM(billed_amount), '9999999990.00'), ' ') AS total_billed_amount,
                ltrim(to_char(SUM(settl_amount), '9999999990.00'), ' ') AS total_settlement_amount,
                ltrim(to_char(SUM(diff_amnt), '9999999990.00'), ' ') AS total_difference
           FROM sq_trns t
       GROUP BY t.org,t.logo
        )
)
, sq_summ_header AS (
    SELECT
           NULL AS org,
           'LOGO'||:P_DELIMITER|| 'TOTAL CARDHOLDER MC BILLING AMOUNT'||:P_DELIMITER|| 'TOTAL CALCULATED BILLING AMT'||:P_DELIMITER|| 'TOTAL DIFF AMOUNT' AS text
      FROM dual
)
SELECT org, text FROM sq_header
UNION ALL
SELECT org, text FROM main_sql
UNION ALL
SELECT org, text FROM sq_summ_header
UNION ALL
SELECT org, text FROM sq_summary