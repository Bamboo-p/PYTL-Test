__version__ = "240529.1"
__job_name__ = "PyTL_OmniReports_ENBDGR_INSTALMENT_PLAN_EXTRACT"
__bat_files__ = []
