/*
* Code for Daily INSTALMENT PLAN REPORT
* Input parameters
*   :ORG            = Inreal it's not a real ORG - it's banks' group ID
*   :P_REPORT_DATE
*   :P_DELIMITER
*   :P_DATEFORMAT
*
* Version history:
* 20220531-001 - RakeshG - Initial Version
* 20220610-001 - RakeshG - ECCBAU-5758 Rate and effective_date field mapping
* 20220614-001 - RakeshG - ECCBAU-5766 Concatenation of values into one column to avoid showing of trailing delimiters. Added :P_DELIMITER.
* 20220614-002 - RakeshG - ECCBAU-5766 Merchant name remapping and rewrite account issue fix.
* 20220615-001 - RakeshG - EIB-9047 Additional field for EIB
* 20220622-001 - RakeshG - EIB-9094 Fixing the Flat rate calculation formula and CIF number mapping for ENBD group banks.
* 20230613-001 - RakeshG - EIB-9659 Added new field as part of CPR phase 2 for EIB,file changed to .sqp and removed hard-coded values for EIB
* 20230707-001 - RakeshG - EIB-9094 Pan Masking for EIB
* 20230717-001 - RakeshG - EIB-9900 Fixing Plan number fetching logic and processing fee logic changes.
* 20230726-001 - RakeshG - EIB-9948 Excluding the REVISED status records in installment.
* 20230804-001 - RakeshG - ENBD-24754 ENABLED new fields for ENBD as part of CPR Phase 2 by removing the condition of EIB behaviour. Added one extra field for ENBD
* 20231013-001 - RakeshG - ENBD-25276 Added REPLACE function to remove commma(,) from the trans_details field
* 20240201-001 - RakeshG - ENBD-25964 New field for ENBD as part of Visa Installent
* 20240219-001 - RakeshG - ENBD-25964 Moved the report simple report to Omnireport and changed from sqp to sql
* 20240222-001 - RakeshG - ENBD-26154 Moved the report simple report to Omnireport and changed from sqp to sql,Added new column for VAT for ENBD
* 20240527-001 - RakeshG - ENBD-26788 Adding new field TOTAL_AMT_WITH_VAT
*/

with
sub_query_OPERATION_TYPES as (
    select /*+ materialize*/
        *
    from
        dwh.V_DWR_OPERATION_TYPE op
    where
        op.CLASS_CODE = :ORG || '_TXN_CODE'
    and instr(op.ADD_INFO, 'IPP_RPT=Y;') > 0
    and op.TYPE_CODE = 'TXN_CODE'
),
sub_query_TRANS as (
    select /*+ no_merge */
        t.BANKING_DATE,
        t.CONTRACT_IDT,
        t.TXN_CODE,
        t.DOC_IDT,
        substr(
            t.ADD_INFO,
            instr(t.ADD_INFO, 'INST_PLAN_ID=') + 13,
            (instr(t.ADD_INFO, ';', instr(t.ADD_INFO, 'INST_PLAN_ID=')) - instr(t.ADD_INFO, 'INST_PLAN_ID=') - 13)
        ) as INSTALMENT_IDT,
        ot.OPERATION_TYPE_CODE,
		(t.amount * -1) as amount,                                           -- [+] 230717-001 - RakeshG - EIB-9900 Fixing processing fee logic
		decode(t.is_fee,'1','N','2','Y') as is_fee                           -- [+] 230717-001 - RakeshG - EIB-9900 Fixing processing fee logic
        ,t.oper_type_add_info
    from
         dwh.OPT_DM_TRANSACTION t
    join sub_query_OPERATION_TYPES ot ON ot.OPERATION_TYPE_ID = t.OPERATION_TYPE_ID
    where
        t.BANKING_DATE = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    and t.ORG = :ORG
-- [+][begin] 230613.1 = RakeshG = EIB-9659 Added new field
), sub_query_PROC_FEE as (
   select /*+ no_merge */
          t.BANKING_DATE,
          t.CONTRACT_IDT,
          t.TXN_CODE,
          t.DOC_IDT,
-- [*][begin] 230717-001 - RakeshG - EIB-9900 Fixing processing fee logic
          t.INSTALMENT_IDT,
          t.amount
     from sub_query_TRANS t
    where t.BANKING_DATE = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
      and t.is_fee = 'Y'
      and instr(t.oper_type_add_info,'IS_VAT=Y;') = 0
-- [*][end]230717-001 - RakeshG - EIB-9900 Fixing processing fee logic
-- [+][end] 230613.1 = RakeshG = EIB-9659 Added new field
), sub_query_VAT as (
   select /*+ no_merge */
          t.BANKING_DATE,
          t.CONTRACT_IDT,
          t.TXN_CODE,
          t.DOC_IDT,
          t.INSTALMENT_IDT,
          t.amount as vat_amt
     from sub_query_TRANS t
    where t.BANKING_DATE = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
--      and t.is_fee = 'Y'
      and instr(t.oper_type_add_info,'IS_VAT=Y;') > 0
), sub_query_INSTALMENT as (
    select /*+ no_merge materialize ordered use_index(i DWD_INSTALMENT_IDT_IDX)*/
        inst.BRANCH_CODE as code,
        inst.NAME,
        i.ADD_INFO,
        i.CREATION_DATE,
        i.SCHEME_NAME,
        i.DOC_IDT,
        i.CONTRACT_IDT,
        i.RECORD_IDT as INSTALMENT_ID,
        i.INSTITUTION_ID,
        i.TENOR,
-- [*][begin] 220610.1 = RakeshG = ECCBAU-5758 Installment Rate Mapping correction
--      i.EFFECTIVE_RATE,
        i.RATE as EFFECTIVE_RATE,
-- [*][end]   220610.1 = RakeshG = ECCBAU-5758 Installment Rate Mapping correction
        c.CONTRACT_NUMBER,
--        c.CLIENT_NUMBER,                    -- [-] 220622-001 - RakeshG - EIB-9094 Fixing the Mapping for CIF number for ENBD group
        c.CLIENT_REG_NUMBER as CLIENT_NUMBER, -- [+] 220622-001 - RakeshG - EIB-9094 Fixing the Mapping for CIF number for ENBD group
        c.PRODUCT_NAME,
        c.LOGO,
        substr(regexp_replace(nvl(substr(i.add_info,1,instr(i.add_info, ':', 1)-1),i.add_info), '[^[:digit:]]', ''),1,7) as PLAN_NUMBER, -- [*] 230717-001 - RakeshG - EIB-9900 Fixing Plan number fetching from String
        t.TXN_CODE,
        DECODE(i.CARD_IDT, i.CONTRACT_IDT, c.PRIMARY_CARD_IDT, i.CARD_IDT) AS CARD_IDT,
        CASE
            WHEN INSTR(t.OPERATION_TYPE_CODE, 'BALCONV') > 0 THEN
                SUBSTR(t.OPERATION_TYPE_CODE, 5, 7)
            ELSE
                REGEXP_SUBSTR(i.SCHEME_OPTION_CODE, '[^_]+', 1, 1)
        END                                                                AS INST_PROD_NAME,
        TO_CHAR(ROUND((NVL(i.RATE, 0) / 12), 2))                           AS MONTHLY_RATE
    FROM DWD_INSTALMENT i
    join OPT_DM_CONTRACT_INFO c on c.CONTRACT_IDT = i.CONTRACT_IDT
    join DWD_INSTITUTION inst on inst.RECORD_IDT = i.INSTITUTION_ID and inst.RECORD_STATE = 'A'
    join DWD_INSTL_STATUS inst_st ON inst_st.ID = i.STATUS_ID
                                         AND inst_st.RECORD_STATE = 'A'
                                         AND inst_st.CODE not in ('Z','REVISED')       -- [+] 230726-001 - RakeshG - EIB-9948 Excluding the REVISED status records in installment
    left join sub_query_TRANS t on i.RECORD_IDT = t.INSTALMENT_IDT and t.is_fee = 'N'  -- [+] 230717-001 - RakeshG - EIB-9900 Fixing processing fee logic

    where i.CREATION_DATE  = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
      and i.RECORD_STATE   = 'A'
      and i.RECORD_DATE_TO = to_date('2100-01-01','YYYY-MM-DD')
      and c.BANKING_DATE   = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')  -- [+] 220610.1 = RakeshG = ECCBAU-5758 to have report date values
      and c.org            = :ORG                                   -- [+] 220615.1 = RakeshG = EIB-9047 org filter
-- [+][begin] 230613.1 = RakeshG = EIB-9659 Added new field
), sub_query_CARD AS (
    SELECT /*+ materialize */
        i.instalment_id AS instalment_idt,
        c.pan           AS card_number
    FROM
             sub_query_instalment i
        JOIN dwd_card c ON c.record_idt = i.card_idt
                           AND c.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                           AND c.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
-- [+][end] 230613.1 = RakeshG = EIB-9659 Added new field
), sub_query_PORTION as (
    select /*+ no_merge ordered use_hash(i dit) */
        i.CODE,
        dit.INSTALMENT_IDT,
        dit.CONTRACT_IDT,
-- [*][begin] 220610.1 = RakeshG = ECCBAU-5758 EFFECTIVE_DATE mapping correction
--      dit.EFFECTIVE_DATE,
        dit.DELINQUENCY_DATE as EFFECTIVE_DATE,
-- [*][begin] 220610.1 = RakeshG = ECCBAU-5758 EFFECTIVE_DATE mapping correction
        i.CONTRACT_NUMBER,
        i.PLAN_NUMBER,
        max(
            case
                when dit.AMOUNT_TYPE = 'PRINCIPAL' then
                    dit.AMOUNT
                else
                    0
            end
        ) as PRINCIPAL_AMT,
        max(
            case
                when dit.AMOUNT_TYPE = 'FEE' then
                    dit.AMOUNT
                else
                    0
            end
        ) as INTEREST_AMT
    from sub_query_INSTALMENT i
    join DWF_INSTL_TOTAL dit ON dit.INSTITUTION_ID = i.INSTITUTION_ID
     and i.CONTRACT_IDT = dit.CONTRACT_IDT
     and dit.INSTALMENT_IDT = i.INSTALMENT_ID
    group by
        dit.INSTALMENT_IDT,
        dit.CONTRACT_IDT,
-- [*][begin] 220610.1 = RakeshG = ECCBAU-5758 effective_date Mapping correction
--      dit.EFFECTIVE_DATE,
        dit.DELINQUENCY_DATE,
-- [*][end] 220610.1 = RakeshG = ECCBAU-5758 effective_date Mapping correction
        i.CONTRACT_NUMBER,
        i.PLAN_NUMBER,
        i.CODE
), sub_query_CONTRACT_SUMMARY as (
    select /*+ materialize */
        INSTALMENT_IDT,
        CONTRACT_IDT,
        sum(PRINCIPAL_AMT) as TOTAL_PRINCIPAL_AMT,
        sum(INTEREST_AMT)  as TOTAL_INTEREST_AMT
    from
        sub_query_PORTION
    group by
        INSTALMENT_IDT,
        CONTRACT_IDT
-- [+][begin] 230613.1 = RakeshG = EIB-9659 Added new field
), sub_query_PORTION_SUMMARY AS (
    SELECT /*+ no_merge materialize */
        p.instalment_idt,
        p.effective_date,
        ( s.total_principal_amt - p_amnt ) AS rem_prin_amt
    FROM
             sub_query_portion p
        JOIN sub_query_contract_summary s ON s.instalment_idt = p.instalment_idt
        JOIN (
            SELECT /*+ materialize */
                p.instalment_idt,
                p.effective_date,
                SUM(p.principal_amt)
                OVER(PARTITION BY p.instalment_idt
                     ORDER BY
                         p.effective_date
                ) AS p_amnt
            FROM
                sub_query_portion p
        )                          ss ON ss.instalment_idt = p.instalment_idt
                AND ss.effective_date = p.effective_date
-- [+][end] 230613.1 = RakeshG = EIB-9659 Added new field
), sub_query_MAIN_SQL as (
    select /*+ */
         i.CODE                                                                                as ORG
        ,i.CONTRACT_IDT                                                                        as CONTRACT_IDT
        ,i.INSTALMENT_ID                                                                       as INSTALMENT_IDT
        ,i.CREATION_DATE                                                                       as INSTALMENT_DATE
        ,'P'                                                                                   as RECORD_TYPE
        ,i.CODE                                                                                as BANK_CODE
        ,i.NAME                                                                                as BANK_NAME
        ,i.LOGO                                                                                as LOGO
        ,i.PRODUCT_NAME                                                                        as PRODUCT_NAME
        ,i.CLIENT_NUMBER                                                                       as CLIENT_NBR
        ,i.CONTRACT_NUMBER                                                                     as CONTRACT_NBR
        ,to_char(i.PLAN_NUMBER)                                                                as PLAN_NBR
        ,to_char(i.CREATION_DATE, :P_DATEFORMAT)                                               as CREATION_DATE
        ,to_char(i.TXN_CODE)                                                                   as TXN_CODE
        ,to_char(i.SCHEME_NAME)                                                                as IPP_NAME
        ,to_char(i.TENOR)                                                                      as TENOR
        ,to_char(i.EFFECTIVE_RATE)                                                             as EFF_DATE
		,to_char(round(((cs.TOTAL_INTEREST_AMT/(cs.TOTAL_PRINCIPAL_AMT * i.TENOR))*100*12),4)) as FLAT_RATE
        ,to_char(cs.TOTAL_PRINCIPAL_AMT)                                                       as TOTAL_PRN_AMT
        ,to_char(cs.TOTAL_INTEREST_AMT)                                                        as TOTAL_INT_AMT
        ,to_char(nvl(cs.TOTAL_PRINCIPAL_AMT + cs.TOTAL_INTEREST_AMT, 0))                       as TOTAL_IPP_AMT
        ,to_char(REPLACE(t.trans_details,',',''))                                              as TRANS_DETAILS
        ,to_char(t.TRANS_DATE, :P_DATEFORMAT)                                                  as TRANS_DATE
        ,substr(card.card_number,1,6)||'XXXXXX'||substr(card.card_number,-4)                   as CARD_NBR
        ,i.inst_prod_name                                                                      as IPP_PRD_NAME
        ,to_char(nvl(pf.amount, 0))                                                            as PROC_FEE
        ,to_char(i.monthly_rate)                                                               as MNTLY_RATE
		,to_char(nvl(cs.TOTAL_PRINCIPAL_AMT + cs.TOTAL_INTEREST_AMT+nvl(pf.amount,0),0))       as TOTAL_AMT
		,case when instr(t.ADD_INFO, 'SOURCE_DEPT=VIS')>0 then 'VIS' else null end             as IPP_CHNL
		,to_char(nvl(vat.vat_amt,0))                                                           as VAT_AMT
		,to_char(nvl(cs.TOTAL_PRINCIPAL_AMT + cs.TOTAL_INTEREST_AMT+nvl(pf.amount,0),0)+nvl(vat.vat_amt,0)) as TOTAL_AMT_WITH_VAT
    from
        sub_query_INSTALMENT i
    join sub_query_CONTRACT_SUMMARY cs on cs.INSTALMENT_IDT = i.INSTALMENT_ID
                                       and cs.CONTRACT_IDT = i.CONTRACT_IDT
    left join dwh.OPT_DWF_TRANSACTION t on t.DOC_IDT = i.DOC_IDT and t.TARGET_CONTRACT_IDT = i.CONTRACT_IDT

    join sub_query_CARD card on card.instalment_idt = i.instalment_id
    left join sub_query_PROC_FEE pf on pf.instalment_idt = i.instalment_id

    left join sub_query_VAT vat on vat.instalment_idt = i.instalment_id
    union
    select
         p.CODE                                            as ORG
        ,p.CONTRACT_IDT                                    as CONTRACT_IDT
        ,p.INSTALMENT_IDT                                  as INSTALMENT_IDT
        ,p.EFFECTIVE_DATE                                  as EFFECTIVE_DATE
        ,'I'                                               as RECORD_TYPE
        ,p.CONTRACT_NUMBER                                 as CONTRACT_NBR
        ,to_char(p.EFFECTIVE_DATE, :P_DATEFORMAT)          as EFF_DATE
        ,to_char(p.PLAN_NUMBER)                            as PLAN_NBR
        ,to_char(p.PRINCIPAL_AMT)                          as PRIN_AMT
        ,to_char(p.INTEREST_AMT)                           as INT_AMT
        ,to_char(nvl(p.PRINCIPAL_AMT + p.INTEREST_AMT, 0)) as MNTLY_BILL_AMT
        ,to_char(s.rem_prin_amt)                           as REM_PRIN_AMT
		,'DUMMY_COL'                                       as DUMMY_COL1
		,'DUMMY_COL'                                       as DUMMY_COL2
		,'DUMMY_COL'                                       as DUMMY_COL3
		,'DUMMY_COL'                                       as DUMMY_COL4
		,'DUMMY_COL'                                       as DUMMY_COL5
		,'DUMMY_COL'                                       as DUMMY_COL6
		,'DUMMY_COL'                                       as DUMMY_COL7
		,'DUMMY_COL'                                       as DUMMY_COL8
		,'DUMMY_COL'                                       as DUMMY_COL9
		,'DUMMY_COL'                                       as DUMMY_COL10
		,'DUMMY_COL'                                       as DUMMY_COL11
		,'DUMMY_COL'                                       as DUMMY_COL12
		,'DUMMY_COL'                                       as DUMMY_COL13
        ,'DUMMY_COL'                                       as DUMMY_COL14
        ,'DUMMY_COL'                                       as DUMMY_COL15
        ,'DUMMY_COL'                                       as DUMMY_COL16
        ,'DUMMY_COL'                                       as DUMMY_COL17
		,'DUMMY_COL'                                       as DUMMY_COL18
		,'DUMMY_COL'                                       as DUMMY_COL19
	from
        sub_query_PORTION p

    join sub_query_PORTION_SUMMARY s on s.instalment_idt = p.instalment_idt
                                    and p.effective_date = s.effective_date
)
select
    *
from
    sub_query_MAIN_SQL
order by
    CONTRACT_IDT,
    INSTALMENT_IDT,
    decode(RECORD_TYPE, 'P', 1, 2),
    INSTALMENT_DATE