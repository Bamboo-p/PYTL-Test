/*
* CODE FOR ENBD_NOON_ONE_CO_BRAND_CREDIT_CARD_RPT
* PyTL_OmniReports_ENBDGR_NOON_ONE_CO_BRAND_CR_CARD == ENBDGR_NOON_ONE_CO_BRAND_CR_CARD.sql
* Parameters:
*           :ORG          = '100'
*           :P_REPORT_DATE  = 'DD-MM-YYYY'
*
* Version history:
* 240111.1 = AlexanderK = ECCBAU-6749:Initial Version
* 240219.1 = AlexanderK = ECCBAU-6749:Migration PyTL_OmniReports_ENBDGR_NOON_ONE_CO_BRAND_CR_CARD
* 240509.1 = Mohannafg  = ECCBAU-6866 : Modified noon_id logic
* /

WITH 

sq_cntr_attr AS (
       SELECT 
              odm.*
         FROM opt_dm_contract_attribute odm
         where odm.noon_flag_date_from = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
         AND odm.org = :ORG
)
, sq_attr  AS (
       SELECT /*+ no_merge materialize */
              info.primary_card_idt,
              info.org,
              info.contract_idt,
              info.logo                AS product_code,
              info.contract_number     AS account_number,
              info.primary_card_number AS card_number,
              info.client_reg_number   AS cif,
              info.client_first_name,
              info.client_last_name,
              info.client_idt,
              info.primary_card_number,
              info.card_expiry_date,
              info.card_add_info,
              info.main_contract_idt,

              trim(BOTH ' ' from ref_num) as ref_number,
              trim(BOTH ' ' from noon_id) as noon_id
         FROM (
                   SELECT
                          td.contract_idt as card_idt,
                          MAX(CASE WHEN td.code = 'REF_NUMBER' THEN td.attr_value ELSE NULL END) AS ref_num,
                          MAX(CASE WHEN td.code = 'NOON_ID' THEN td.attr_value ELSE NULL END) AS noon_id
                   FROM opt_dm_td_auth_scheme td
                   where td.code IN ('REF_NUMBER', 'NOON_ID')
                   AND td.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                   group by td.contract_idt) tda
          JOIN opt_dm_contract_info info ON tda.card_idt = info.primary_card_idt
)
,OLD_NOON_ID AS (
                SELECT /*+ no_merge materialize */
               card_idt,
              trim(BOTH ' ' from noon_id) as noon_id,
            row_number() over (partition by INFO.main_contract_idt order by nvl(INFO.effective_date, to_date('01.01.1990', 'dd.mm.yyyy')) desc, INFO.record_idt desc) rn,
            INFO.effective_date,
            INFO.main_contract_idt
                        
         FROM (
                     SELECT
                          td.contract_idt as card_idt,
                          MAX(CASE WHEN td.code = 'NOON_ID' THEN td.attr_value ELSE NULL END) AS noon_id
                   FROM opt_dm_td_auth_scheme td
                   where td.code IN ('NOON_ID')
                   AND td.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                    group by td.contract_idt) tda
          JOIN dwd_card info ON tda.card_idt = info.record_idt 
          where info.recoRd_state  = 'A' 
        
)
       SELECT /*+ no_merge materialize */
              c.org                                                  AS ORG,
              c.product_code                                         AS PRODUCT_CODE,
              c.account_number                                       AS ACCOUNT_NUMBER,
              c.card_number                                          AS CARD_NUMBER,
              c.cif                                                  AS CIF,
              c.ref_number                                           AS REFERENCE_NUMBER,
              c.client_first_name                                    AS CLIENT_FIRST_NAME,
              c.client_last_name                                     AS CLIENT_LAST_NAME,
              to_char(c.card_expiry_date, 'MM')                      AS EXPIRY_MONTH,
              to_char(c.card_expiry_date, 'YYYY')                    AS EXPIRY_YEAR,
              sy_convert.get_tag_value(c.card_add_info,'NOON_EMAIL') AS NOON_ONE_EMAIL_ID,
              r.noon_flag                                            AS NOON_ONE_FLAG,
              NVL(c.noon_id, n.noon_id)                              AS NOON_ONE_MEMBERSHIP_NUMBER,
              regexp_substr(r.noon_flag_details,'INPUT=RC_(.*?)(;|$)',1,1, NULL, 1)      AS STATUS,
              r.noon_flag_reason                                     AS REASON_FOR_REJECTION
         FROM sq_attr c
         JOIN sq_cntr_attr r on r.contract_idt = c.contract_idt
         LEFT JOIN OLD_NOON_ID N  ON  N.MAIN_CONTRACT_IDT = c.MAIN_CONTRACT_IDT 
         AND RN = 1