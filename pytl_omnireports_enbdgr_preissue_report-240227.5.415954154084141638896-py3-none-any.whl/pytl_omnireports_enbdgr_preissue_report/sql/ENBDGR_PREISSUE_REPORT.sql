/*
Purpose: Report to provide the card numbers for which the Pseudo IDs are not available
Incoming parameters:
    :ORGLIST as 096
    :P_BANKING_DATE as dd-MM-yyyy
    :P_DAYS as 60
240201.1 = AlexanderK = ENBD-26057: Initial version
240207.3 = AlexanderK = ENBD-26057: P_REPORT_DATE renamed into P_BANKING_DATE
240209.4 = AlexanderK = ENBD-26057: Added new fields
240227.5 = AlexanderK = ENBD-26057: Added new field
*/
WITH
fi as (
    SELECT /*+ no_merge materialize */
        id,
        branch_code code,
        name
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code branch_code_posting,
                dwd_institution.name
            FROM
                dwd_institution
            JOIN
                dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY decode(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
)
select
    dwinst.code                                                                     as ORG
    ,substr(p.product_code,9,3)                                                     as LOGO
    ,dwcontr.personal_account                                                       as ACCOUNT_NUMBER
    ,dwcard.pan                                                                     as CARD_NUMBER
    ,dwclient.first_name || ' ' || dwclient.last_name                               as CUSTOMER_NAME
    ,dwcard.embossed_last_name                                                      as EMBOSSER_NAME
    ,dcb.name                                                                       as CD_TYP
    ,case when dwcard.plastic_status = 'A' then 'Y' else 'N' end                    as ACTV
    ,dcl.amount                                                                     as CREDIT_LIMIT
    ,case when dwcard.plastic_status = 'A' then '1' else '0' end                    as NO_CARDS
    ,dp_old.expiry_date                                                             as PRIOR_EXP
    ,dwcard.expiry_date                                                             as CUR_EXP
    ,'REISSUE'                                                                      as ACTION_TAKEN
    ,dwclient.ident_number                                                          as CIF
from
    dwd_card dwcard
join dwd_contract dwcontr
    on dwcard.MAIN_CONTRACT_IDT = dwcontr.RECORD_IDT
    and TO_DATE(:P_BANKING_DATE, 'dd-MM-yyyy') BETWEEN dwcontr.record_date_from and dwcontr.record_date_to
join dwd_client dwclient
    on dwcontr.client_idt = dwclient.record_idt
    and TO_DATE(:P_BANKING_DATE, 'dd-MM-yyyy') BETWEEN dwclient.record_date_from and dwclient.record_date_to
join fi dwinst
    on dwclient.institution_id = dwinst.id
JOIN dwd_card_product p
    on p.id = dwcard.card_product_id
left join dwf_contract_limit dcl
    on dcl.contract_idt = dwcontr.RECORD_IDT
    and dcl.banking_date = TO_DATE(:P_BANKING_DATE, 'dd-MM-yyyy')
    and dcl.type_code = 'FIN_LIMIT'
join dwd_card_brand dcb
    on dcb.id = dwcard.card_brand_id
join (select card_idt, expiry_date, prev_record_idt, row_number() over (partition by card_idt order by nvl(effective_date, to_date('01.01.1990', 'dd.mm.yyyy')) desc, record_idt desc) rn from dwd_plastic dp join fi on fi.id = dp.institution_id where to_date(:P_BANKING_DATE, 'DD-MM-YYYY' ) BETWEEN record_date_from and record_date_to) dp_new
    on dp_new.card_idt = dwcard.RECORD_IDT
    and dp_new.rn = 1
left join dwd_plastic dp_old
    on dp_old.card_idt = dwcard.RECORD_IDT
    and TO_DATE(:P_BANKING_DATE, 'dd-MM-yyyy') BETWEEN dp_old.record_date_from and dp_old.record_date_to
    and dp_new.prev_record_idt = dp_old.record_idt
where
    to_date(:P_BANKING_DATE, 'dd-MM-yyyy') BETWEEN dwcard.record_date_from and dwcard.record_date_to
    and dwcard.expiry_date between to_date(:P_BANKING_DATE, 'dd-MM-yyyy') and to_date(:P_BANKING_DATE, 'dd-MM-yyyy') + :P_DAYS