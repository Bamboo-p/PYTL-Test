/*
Purpose: Report to provide the card numbers for which the Pseudo IDs are not available

Incoming parameters:
    :ORGLIST as 096
    :P_BANKING_DATE as dd-MM-yyyy
240201.1 = AlexanderK = ENBD-26057: Initial version
*/
with
fi as (
    select /*+ no_merge materialize */
        id
        ,branch_code
        ,name
    from
        (
            select
                dwd_institution.id
                ,dwd_institution.branch_code
                ,dwd_institution.name
                ,dwd_institution.posting_institution_id
                ,dwd_institution2.branch_code       as BRANCH_CODE_POSTING
            from
                dwd_institution
            join
                dwd_institution dwd_institution2 on dwd_institution.posting_institution_id = dwd_institution2.id
            where
                dwd_institution.record_state = 'A'
        ) inst
    start with
        inst.branch_code in (
            select
                trim(regexp_substr(:ORGLIST, '[^,]+', 1, level))
            from
                dual
            connect by
                regexp_substr(:ORGLIST, '[^,]+', 1, level) is not NULL
        )
    connect by decode(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = prior inst.id
               and level <= 2
)
select
    fi.branch_code                                  as ORG
    ,fi.branch_code                                 as FI_BRANCH_CODE
    ,'-'                                            as TEXT_SEPARATOR
    ,fi.name                                        as FI_NAME
    ,'Preissue Review Report'                       as TEXT_TITLE
    ,'FILE DATE'                                    as TEXT_DATE_NAME
    ,to_char(to_date(sysdate,'dd-mm-yyyy'))         as TEXT_DATE
    ,'PAGE'                                         as TEXT_TIME_NAME
    ,'1'                                            as TEXT_TIME
from fi
union all
select
    fi.branch_code                                  as ORG
    ,''                                             as FI_BRANCH_CODE
    ,''                                             as TEXT_SEPARATOR
    ,''                                             as FI_NAME
    ,'SMART CARD RE-ISSUE REVIEW REGISTER'          as TEXT_TITLE
    ,'PROC DATE'                                    as TEXT_DATE_NAME
    ,to_char(to_date(:P_BANKING_DATE,'dd-mm-yyyy')) as TEXT_DATE
    ,'TIME'                                         as TEXT_TIME_NAME
    ,to_char(sysdate,'HH24:MI:SS')                  as TEXT_TIME
from fi
union all
select
    fi.branch_code                                  as ORG
    ,''                                             as FI_BRANCH_CODE
    ,''                                             as TEXT_SEPARATOR
    ,''                                             as FI_NAME
    ,''                                             as TEXT_TITLE
    ,''                                             as TEXT_DATE_NAME
    ,''                                             as TEXT_DATE
    ,''                                             as TEXT_TIME_NAME
    ,''                                             as TEXT_TIME
from fi
