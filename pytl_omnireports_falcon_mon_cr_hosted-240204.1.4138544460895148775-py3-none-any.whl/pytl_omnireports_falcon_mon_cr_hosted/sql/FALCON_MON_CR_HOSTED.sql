/*
240221.1 : KhaledO : NICORE-1211  : INITIAL REPORT
240204.1 : KhsledO : IB-876 : Query mods

*/ 
with
inst_list AS ( 
        select /*+ parallel(4) */
             v.code       AS client_xid,
             v.name,
             v.add_info   AS tenant_name,
             g.code,
             g.group_code,
             branch_code,
             inst.id
         from sy_conf_group g
         join sy_conf_group_val v
           on v.amnd_state = 'A'
          and g.id = v.sy_conf_group__oid
         join sy_conf_group_rec r
           on r.amnd_state = 'A'
          and r.value_id = v.id
         join dwd_institution inst
           on inst.id = r.table_rec_id
        where g.code = 'CLIENT_BANK_ID'
          and g.group_code = 'FALCON_BATCH_FEED'
          and inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                     from dual
                               connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
     ),
acnt AS (
     SELECT /*+ no_merge materialize use_hash(a p)*/
         a.total_balance,
         p.tenant_name,
         p.client_xid,
         p.score_customer_account_xid,
         p.card_idt,
         p.current_card_status_xcd,
         p.plastic_status
     FROM
         opt_falcon_ais a
         JOIN inst_list inst ON a.tenant_name = inst.tenant_name
                                AND a.client_xid = inst.client_xid
								AND a.bank_xid = inst.branch_code
         JOIN opt_falcon_pis p ON p.account_xid = a.account_xid
                                  AND p.tenant_name = a.tenant_name
                                  AND a.report_date = p.report_date
                                  and p.CARD_TYPE_XCD not in ('P','D')
     WHERE
         a.report_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy')
 
),
ip as (select distinct card_idt
          from dwf_iss_operation ip
         where trunc(ip.trans_date) BETWEEN (to_date(:P_REPORT_DATE,'dd-mm-yyyy') - to_yminterval('0-1') ) + 1 AND to_date(:P_REPORT_DATE,'dd-mm-yyyy')
           and settlement_date >= to_date(:P_REPORT_DATE,'dd-mm-yyyy') - to_yminterval('0-2'))
,contr_status as (
                 SELECT /*+ materialize*/
                     distinct code
                 FROM
                     v_dwr_contract_status
                 WHERE
                     type_code = 'CARD_STATUS'
                     AND contract_status_id IN (
                         SELECT
                             id
                         FROM
                             dwd_contract_status
                         WHERE
                             record_state = 'A'
                             AND code NOT IN (
                                 '04',
                                 '07',
                                 '14',
                                 '34',
                                 '41',
                                 '43'
                             )
                     )
             ) ,
main_query as
(
             SELECT
                 tenant_name,
                 client_xid,
                 bin,
                 COUNT(1) cnt
            FROM
                 (
                     SELECT /*+ no_merge*/
                         a.tenant_name,
                         a.client_xid,
                         substr(a.score_customer_account_xid,1,6) AS bin
                     FROM
                         acnt a
                         left join ip
                          on ip.card_idt = a.card_idt
                     WHERE
                         ip.card_idt is not null
                         OR (ip.card_idt is null
                              AND a.total_balance < 0
                              AND ip.card_idt is null
                              AND a.current_card_status_xcd IN (
                             SELECT
                                 code
                             FROM
                                 contr_status
                              ) 
                              AND a.plastic_status = 'A' )
                 )
            GROUP BY
                 tenant_name,
                 client_xid,
                 bin
)
,
distinct_tenant as
    (
        select distinct tenant_name, client_xid from main_query
    )
    select
        null TENANT_NAME,
        'Falcon Way4 Billing Report' CLIENT_XID,
        null BIN,
        null "COUNT"
    from dual
union all
    select
        null TENANT_NAME,
        null CLIENT_XID,
        'REPORT DATE FROM:' BIN,
        TO_CHAR(ADD_MONTHS(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') +1, -1 ), 'DD-MM-YYYY') "COUNT"
    from dual
union all
    select
        null TENANT_NAME,
        null CLIENT_XID,
        'REPORT DATE TO:' BIN,
        :P_REPORT_DATE "COUNT"
    from dual
union all
    select
        null TENANT_NAME,
        null CLIENT_XID,
        'REPORT EXECUTION DATE:' BIN,
        TO_CHAR(SYSDATE,'DD-MM-YYYY') "COUNT"
    from dual
union all
    SELECT * FROM
    (
        SELECT * FROM 
            (
                select
                    'TENANT NAME' AS TENANT_NAME,
                    client_xid||' CLIENT ID' AS CLIENT_XID,
                    'BIN' AS BIN,
                    'COUNT' AS "COUNT"
                from dual  
                cross join distinct_tenant
            union all
                select
                    tenant_name,
                    client_xid,
                    to_char(bin) as bin,
                    to_char(cnt) as "COUNT"
                from main_query
            union all
                select
                    ' ' AS TENANT_NAME,
                    client_xid as CLIENT_XID,
                    'TOTAL COUNT FOR CLIENT :' AS BIN,
                    TO_CHAR(SUM(cnt)) AS "COUNT"
                from main_query
                group by client_xid
            ) a
        order by  a.CLIENT_XID DESC , a.COUNT DESC
    )