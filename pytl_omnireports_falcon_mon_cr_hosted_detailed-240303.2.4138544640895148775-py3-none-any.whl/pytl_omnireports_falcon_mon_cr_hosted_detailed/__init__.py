__version__ = "240303.2"
__job_name__ = "PyTL_OmniReports_FALCON_MON_CR_HOSTED_DETAILED"
__bat_files__ = []
