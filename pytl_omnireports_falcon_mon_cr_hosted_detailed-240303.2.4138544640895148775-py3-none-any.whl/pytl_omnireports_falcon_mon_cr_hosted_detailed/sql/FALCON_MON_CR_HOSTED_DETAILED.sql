/*
240221.1 : NICORE-1212 : INITIAL REPORT
240303.2 : KhsledO : IB-876 : Query mods

*/
WITH 
    inst_list AS ( 
        select /*+ parallel(4) */
             v.code       AS client_xid,
             v.name,
             v.add_info   AS tenant_name,
             g.code,
             g.group_code,
             branch_code,
             inst.id
         from sy_conf_group g
         join sy_conf_group_val v
           on v.amnd_state = 'A'
          and g.id = v.sy_conf_group__oid
         join sy_conf_group_rec r
           on r.amnd_state = 'A'
          and r.value_id = v.id
         join dwd_institution inst
           on inst.id = r.table_rec_id
        where g.code = 'CLIENT_BANK_ID'
          and g.group_code = 'FALCON_BATCH_FEED'
          and inst.branch_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                     from dual
                               connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null)
     ),
    card_blockcode as
    (
        select /*+ leading(da dca c) */
            da.code card_block_code,dca.card_idt as card_idt_b from dwa_card_attribute dca
        join dwd_card c on dca.card_idt = c.record_idt 
            and c.record_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
            and c.record_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
            and dca.attr_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
            and dca.attr_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
        join dwd_attribute da on da.id              = dca.attr_id
            and da.record_state='A'
        where da.type_code like 'BLOCK_CODE_CARD_%'
    ),
    account_blockcode as (
        select 
            MAX(case when da.type_code like 'BLOCK_CODE_ACC1_%' then da.code end) as Account_block_code_1,
            MAX(case when da.type_code like 'BLOCK_CODE_ACC2_%' then da.code end) as Account_block_code_2,
            MAX(case when da.type_code='BFA_ACCOUNT_STATUS' then da.name end) as Account_status,
            c.record_idt as a_idt 
        from dwa_contract_attribute dca
        join dwd_contract c on c.record_idt = dca.contract_idt
            and c.record_state='A'
            and c.record_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
            and c.record_date_to   >=  to_date(:P_REPORT_DATE,'dd-mm-yyyy')
            and dca.attr_date_from <= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
            and dca.attr_date_to   >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
        join dwd_attribute da on da.id  = dca.attr_id
            and da.record_state='A'
        join inst_list i on  i.id=c.INSTITUTION_ID
        where 
            (
                da.type_code like 'BLOCK_CODE_ACC1_%'  or 
                da.type_code like 'BLOCK_CODE_ACC2_%' or 
                da.type_code ='BFA_ACCOUNT_STATUS' 
            )
        group by c.record_idt
    ),
    acnt AS (
        SELECT  /*+ leading(inst) use_hash(a p) no_merge(a) no_merge(p)*/
            a.total_balance,
            p.tenant_name,
            p.client_xid,
            p.score_customer_account_xid,
            p.card_idt,
            p.current_card_status_xcd,
            p.plastic_status,
            cb.card_block_code as card_block_code,
            a.ACCOUNT_REFERENCE_XID as account_number,
            Account_block_code_1,
            Account_block_code_2,
            Account_status
        FROM opt_falcon_ais a
        JOIN inst_list inst ON a.tenant_name = inst.tenant_name
            AND a.client_xid = inst.client_xid
        JOIN opt_falcon_pis p ON p.account_xid = a.account_xid
            AND p.tenant_name = a.tenant_name
            AND a.report_date = p.report_date
            and p.CARD_TYPE_XCD not in ('P','D')
        left JOIN card_blockcode cb on cb.card_idt_b=p.card_idt
        left JOIN account_blockcode ab on ab.a_idt=a.account_xid
        WHERE a.report_date = to_date(:P_REPORT_DATE,'dd-mm-yyyy')
        ),
    ip as 
    (
        select  distinct card_idt
        from    dwf_iss_operation ip
        where   trunc(ip.trans_date) BETWEEN (add_months(to_date(:P_REPORT_DATE,'dd-mm-yyyy'),-1)) + 1 AND to_date(:P_REPORT_DATE,'dd-mm-yyyy')
        AND     SETTLEMENT_DATE >= add_months(to_date(:P_REPORT_DATE,'dd-mm-yyyy'),-1)
    )
    ,contr_status 
    as (
                 SELECT 
                     distinct code
                 FROM
                     v_dwr_contract_status
                 WHERE
                     type_code = 'CARD_STATUS'
                     AND contract_status_id IN (
                         SELECT
                             id
                         FROM
                             dwd_contract_status
                         WHERE
                             record_state = 'A'
                             AND code NOT IN (
                                 '04',
                                 '07',
                                 '14',
                                 '34',
                                 '41',
                                 '43'
                             )
                     )
        ),
    main_query as
    (
         SELECT
             a.tenant_name as tenant_name,
             a.client_xid as client_xid,
             substr(a.score_customer_account_xid,1,6) AS bin,
             score_customer_account_xid as card_number,
             card_block_code,
             account_number,
             Account_block_code_1,
             Account_block_code_2,
             Account_status
         FROM
             acnt a
         left join ip
              on ip.card_idt = a.card_idt
         WHERE
             ip.card_idt is not null
             OR ( a.total_balance < 0
                  AND ip.card_idt is null
                  AND a.current_card_status_xcd IN (
                 SELECT
                     code
                 FROM
                     contr_status
                  ) 
                  AND a.plastic_status = 'A' )
     ORDER BY
     1,
     2,
     3  
    ),
    distinct_bins as
    (
        select distinct bin from main_query
    )
     SELECT
         null as tenant_name,
         'Falcon Billing Detailed Report : Credit' as client_xid,
         null AS bin,
         null as card_number,
         null card_block_code,
         null account_number,
         null Account_block_code_1,
         null Account_block_code_2,
         null Account_status        
    FROM DUAL
    UNION ALL
     SELECT
         null as tenant_name,
         NULL as client_xid,
         'REPORT DATE FROM:'  AS bin,
         TO_CHAR(ADD_MONTHS(TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') +1, -1 ), 'DD-MM-YYYY') as card_number,
         null card_block_code,
         null account_number,
         null Account_block_code_1,
         null Account_block_code_2,
         null Account_status        
    FROM DUAL
    UNION ALL
     SELECT
         null as tenant_name,
         NULL as client_xid,
         'REPORT DATE TO:'  AS bin,
         :P_REPORT_DATE  as card_number,
         null card_block_code,
         null account_number,
         null Account_block_code_1,
         null Account_block_code_2,
         null Account_status        
    FROM DUAL
    UNION ALL
     SELECT
         null as tenant_name,
         NULL as client_xid,
         'REPORT EXECUTION DATE :'  AS bin,
         to_char(sysdate,'dd-mm-yyyy') as card_number,
         null card_block_code,
         null account_number,
         null Account_block_code_1,
         null Account_block_code_2,
         null Account_status        
    FROM DUAL
    UNION ALL

    SELECT * FROM
    (

        SELECT * FROM(
        
        SELECT
            'Tenant name' tenant_name,
            'Client XID' client_xid,
            bin ||' BIN' AS BIN,
            'Card number' card_number,
            'Card block code' card_block_code,
            'Account number' account_number,
            'Account block code' Account_block_code_1,
            'Account block code' Account_block_code_2,
            'Account status'  Account_status        
        FROM DUAL
            cross join distinct_bins
        UNION ALL
 
        SELECT 
            TO_CHAR(tenant_name) tenant_name,
            TO_CHAR(client_xid) client_xid,
            TO_CHAR(bin) AS BIN,
            TO_CHAR(card_number) card_number,
            TO_CHAR(card_block_code) card_block_code,
            TO_CHAR(account_number) account_number,
            TO_CHAR(Account_block_code_1) Account_block_code_1,
            TO_CHAR(Account_block_code_2) Account_block_code_2,
            TO_CHAR(Account_status) Account_status
        FROM MAIN_QUERY
        UNION ALL
         SELECT
             null as tenant_name,
             'Total Cards for BIN :' as client_xid,
             bin AS bin,
             ': ' as card_number,
             TO_CHAR(count(1)) card_block_code,
             null account_number,
             null Account_block_code_1,
             null Account_block_code_2,
             null Account_status
         FROM
             MAIN_QUERY
             group by bin
        ) A ORDER BY A.BIN desc , A.ACCOUNT_NUMBER  
    )