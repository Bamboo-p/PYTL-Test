/*
* CODE FOR IPP_FORECLOSURE_REPORT
* PyTL_OmniReports_IPP_FORECLOSURE_REPORT == IPP_FORECLOSURE_REPORT.sql
*
* Version history:
* 240226.1 = AlexanderK = EIB-10316:Initial Version
* 240524.1 = RakeshG = EIB-10500:Exluded the procedure
*/

select /*+ parallel(2)*/
       tmp.org, 
       tmp.personal_account as ACCOUNT_NUMBER,
       tmp.card_number,
       tmp.plan_number,
       tmp.total_principal,
       tmp.total_interest,
       tmp.principal_remaining,
       tmp.int_remaining as INTEREST_REMAINING,
	   tmp.Acc_lvl_block_code_1,
	   tmp.Acc_lvl_block_code_2
  from (
     select  /*+ leading(dc di st) use_nl(portions) push_pred(portions) use_nl(forc_amt) push_pred(forc_amt)*/
          di.org,
          di.contract_number                                     as personal_account,
          di.primary_card_number                                 as card_number,
          nvl(substr(di.add_info,(instr(di.add_info,'_',1)+1),
          (instr(di.add_info,':')-(instr(di.add_info,'_',1)+1)))
          /* using NVL since for few palns doesn't have description after paln number*/
          ,substr(di.add_info,(instr(di.add_info,'_',1)+1)))  as plan_number,
          to_char(di.principal,                 '99999990.90')   as total_principal,
          to_char(di.total-principal,           '99999990.90')   as total_interest,
          to_char(forc_amt.principal_remaining, '99999990.90')	 as principal_remaining,
          to_char(forc_amt.int_remaining,       '99999990.90')   as int_remaining,
		  blc.block_code_1                                       as Acc_lvl_block_code_1,
		  blc.block_code_2                                       as Acc_lvl_block_code_2,
          case when portions.status='CLOSED' and  di.end_date > TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') then 1 else 0 end  as forcecls_ind
     from 
     
     (select  /*+ no_merge leading()*/ 
	         dc.contract_number, 
	         dc.primary_card_number,
             dc.bank_code as org,			 
			 di.* 
	 from opt_dm_contract_info dc
     join dwd_instalment di
       on dc.contract_idt   = di.contract_idt
	   and di.record_state='A'
       and  di.record_date_from  = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
       and di.scheme_code not in ('DAC_IPP_PLAN_F_'||:ORG, 'BT_IPP_PLAN_F_'||:ORG)
     join dwd_instl_status st
       on st.id             = di.status_id
      and st.record_state   = 'A'
      and st.code           = 'CLOSED'
      where dc.banking_date        = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
      and dc.bank_code       = :ORG
      
      ) di
     join (select /*+ use_nl(di dit) leading(di dit ip) */
                 dit.instalment_idt,
                 max(st.code)  as status
            from dwf_instl_total dit
            join dwd_instalment di on di.record_idt  = dit.instalment_idt  and di.record_date_from    = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') and di.end_date >  TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
            join dwd_instl_portion ip
              on ip.record_idt     = dit.inst_portion_idt
             and ip.instalment_idt = dit.instalment_idt
             and ip.contract_idt   = dit.contract_idt
            join dwd_instl_status st
              on st.id             = ip.status_id
             and st.record_state   = 'A'
             and st.code           = 'CLOSED'
           where ip.record_state   = 'A'
        group by dit.instalment_idt
            ) portions
          on di.record_idt        = portions.instalment_idt
     join (select /*+ use_nl(di dit) leading(di dit ip) */
                dit.instalment_idt, 
                sum(case when dit.amount_type = 'PRINCIPAL' and st.code = 'WAITING' then amount else 0 end) as principal_remaining,
                sum(case when dit.amount_type = 'FEE'       and st.code = 'WAITING' then amount else 0 end) as int_remaining
            from dwf_instl_total dit
            join dwd_instalment di on di.record_idt  = dit.instalment_idt  and di.record_date_from    = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') and di.end_date >  TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
            join dwd_instl_portion ip
              on ip.record_idt     = dit.inst_portion_idt
             and ip.instalment_idt = dit.instalment_idt
             and ip.contract_idt   = dit.contract_idt
            join dwd_instl_status st
              on st.id             = ip.status_id
             and st.record_state   = 'A'
           where ip.record_date_to = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')-1
        group by dit.instalment_idt
            ) forc_amt
         on di.record_idt        = forc_amt.instalment_idt  
left join (select contract_idt,
                    max(case when decision_code = 'BLOCK_CODE_ACC1' then decision_result else null end) as block_code_1,
                    max(case when decision_code = 'BLOCK_CODE_ACC2' then decision_result else null end) as block_code_2
              from opt_dm_contract_decision
              where banking_date = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
			    and decision_code in ('BLOCK_CODE_ACC1','BLOCK_CODE_ACC2')
           group by contract_idt) blc on blc.contract_idt = di.contract_idt		 
     ) tmp
   where tmp.forcecls_ind = 1