__version__ = "240212.1"
__job_name__ = "PyTL_OmniReports_MONTHLY_ISSUER_METRICS"
__bat_files__ = []
