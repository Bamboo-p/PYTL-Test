/*
* CODE FOR AUBI Issuer Metrics
* PyTL_OmniReports_AUBI_MONTHLY_ISSUER_METRICS_REPORT=AUBI_MONTHLY_ISSUER_METRICS_REPORT.SQL
* Parameters:
    ORG                = '018' 
    P_BANK_DATE        = 'DD-MM-YYYY' = SYSDATE -1
	TOKEN_LIST         = APPLE PAY,GOOGLE PAY
* VERSION HISTORY:
* 231129.1 = KOKILA J = AUBI-3954 : AUBI Monthly Issuer Metrics
* 240212.2 = KOKILA J = AUBI-4059 : add_info column changes to remove special symbol
*/
WITH inst AS (
    SELECT /*+ no_merge materialize */
        id,
        branch_code,
        name inst_name,
        local_currency
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution.local_currency,
                dwd_institution2.branch_code branch_code_posting,
                dwd_institution.name
            FROM
                     dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORG, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORG, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY decode(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
), m_dates AS (
    SELECT /*+no_merge materialize*/
           trunc(add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1),'mm') as min_date,
           last_day(add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1))   as max_date
    FROM
        dual
), cards AS (
    SELECT /*+no_merge materialize*/
        c.record_idt,
        decode(nvl(sy_convert.get_tag_value(dip.add_info, 'PR_GROUP_REP'), p.card_category_code), 'ISSCREDIT', 'CREDIT', 'ISSDEB', 'DEBIT',
               'ISSPREPAID', 'PREPAID', nvl(sy_convert.get_tag_value(dip.add_info, 'PR_GROUP_REP'), p.card_category_code)) AS card_category_code
    FROM
             dwd_card c
        JOIN inst ON c.institution_id = inst.id
                     AND c.record_state = 'A'
        JOIN dwd_card_product p ON c.card_product_id = p.id
                                   AND p.record_state = 'A'
        JOIN dwd_int_product  dip ON dip.product_id = p.product_id
                                    AND dip.record_state = 'A'
),wallet_names as (
    select /*+no_merge materialize*/  
           trim(regexp_substr(:TOKEN_LIST, '[^,]+', 1, level)) token
      from dual
connect by regexp_substr(:TOKEN_LIST, '[^,]+', 1, level) is not null
),token_meta AS (
    SELECT /*+no_merge materialize*/
        coalesce(org_conf.code, org_conf.filter2, default_conf.code, default_conf.filter2) AS code
    FROM
        (
            SELECT
                *
            FROM
                c$sy_handbook
            WHERE
                    amnd_state = 'A'
                AND group_code LIKE 'TOKEN_REQUESTOR%' --[*] 280322: ALMB-619
                AND filter5 = :ORG
                AND name in (select token from wallet_names)
        ) org_conf
        FULL JOIN (
            SELECT
                *
            FROM
                dwh.c$sy_handbook tt
            WHERE
                    tt.filter = '000'
                AND tt.name IN (select token from wallet_names)
                AND tt.group_code LIKE 'TOKEN_REQUESTOR%'
                AND tt.amnd_state = 'A'
        ) default_conf ON ( org_conf.filter2 = default_conf.filter2
                       AND org_conf.name = default_conf.name)
),
domain_tkn as (
    select /*+no_merge materialize*/
           tatu.td_auth_type__oid
      From c$td_domain td
      join c$td_auth_type_used tatu
        on td.id   = tatu.domain
     where td.code = 'VCARDS'
       and tatu.amnd_state = 'A'
       and tatu.is_ready   = 'Y'
    ),
 parm_id AS (
        select /*+no_merge materialize*/
          parm.id
     from v_c$td_auth_parm parm
     join v_c$td_auth_type t
       on parm.td_auth_type__oid = t.id
      and instr(t.code,:ORG) > 0
     join domain_tkn d
       on d.td_auth_type__oid = t.id
    where parm.code = 'T_STATUS'
      and parm.amnd_state = 'A'
), parm_id2 AS (
    select /*+no_merge materialize*/
          parm.id
     from v_c$td_auth_parm parm
     join v_c$td_auth_type t
       on parm.td_auth_type__oid = t.id
      and instr(t.code,:ORG) > 0
     join domain_tkn d
       on d.td_auth_type__oid = t.id
    where parm.code       = 'TOKEN_REQ_ID'
      and parm.amnd_state = 'A'
), active_token AS (
    select /*+ no_merge materialize*/
          s.id,
          s.auth_idt,
          c.card_category_code as card_category
     from v_c$td_auth_sch s
     join v_c$td_auth_type t
       on s.auth_type  = t.id
      and t.amnd_state = 'A'
      and instr(t.code,:ORG) > 0
     join domain_tkn d
       on d.td_auth_type__oid = t.id
     join cards c
       on c.record_idt = s.acnt_contract__id
     join v_c$td_auth_val td_auth_val1
       on s.id         = td_auth_val1.td_auth_sch__oid
      and td_auth_val1.parm_value = 'Active'
      and td_auth_val1.amnd_state = 'A'
     join parm_id
       on td_auth_val1.auth_parm  = parm_id.id
      and s.date_from  < to_date(:P_REPORT_DATE, 'dd-mm-yyyy') + 1
      and nvl(s.date_to, to_date(:P_REPORT_DATE, 'dd-mm-yyyy')) >= to_date(:P_REPORT_DATE,'dd-mm-yyyy')
), contracts AS (
    SELECT /*+ index(DWD_CONTRACT_INST_IDX c)*/
        c.record_idt,
        c.personal_account,
        decode(nvl(sy_convert.get_tag_value(dip.add_info, 'PR_GROUP_REP'), p.card_category_code), 'ISSCREDIT', 'CREDIT', 'ISSDEB', 'DEBIT',
               'ISSPREPAID', 'PREPAID', nvl(sy_convert.get_tag_value(dip.add_info, 'PR_GROUP_REP'), p.card_category_code)) AS code
    FROM
             dwd_contract c
        JOIN inst            i ON i.id = c.institution_id
                       AND c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
                       AND c.record_date_to >= TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy')
        JOIN dwd_int_product dip ON dip.product_id = c.product_id
                                    AND dip.record_state = 'A'
        JOIN dwd_product     p ON p.id = c.product_id
                              AND p.record_state = 'A'
), operation_types AS (
    SELECT /*+ no_merge materialize */
        *
    FROM
             v_dwr_operation_type
        JOIN inst ON class_code = inst.branch_code || '_TXN_CODE'
), entry AS (
    SELECT /*+ no_merge use_nl(e) nlj_prefetch(e) use_nl(inst) use_nl(d) use_nl(op) swap_join_inputs(inst) swap_join_inputs(op) swap_join_inputs(d)*/
        e.contract_idt,
        e.banking_date,
        e.primary_doc_idt,
        SUM(credit - debit) AS amount
    FROM
             dwf_account_entry e
        JOIN inst ON inst.id = e.institution_id
			   --[+] 220929.1 : AUBI-3521
        JOIN contracts       c ON c.record_idt = e.contract_idt
			   --[+] 220929.1 : AUBI-3521
        JOIN m_dates         d ON e.banking_date BETWEEN d.min_date AND d.max_date
        JOIN operation_types op ON op.operation_type_id = e.operation_type_id
    WHERE
        e.account_group_id NOT IN (
            SELECT
                id
            FROM
                dwd_account_group
            WHERE
                    record_state = 'A'
                AND code = 'ISS-D-2740636506'
        )
    GROUP BY
        e.contract_idt,
        e.banking_date,
        e.primary_doc_idt
), transactions AS (
    SELECT /*+ parallel(4) no_px_join_filter(t) no_pq_replicate(t) pq_distribute(t broadcast none)*/
        t.*,
        regexp_substr(t.add_info, '(D_TKN+)=([^;]+);', 1, 1, '',
                      2) AS d_tkn,
        CASE
            WHEN instr(dtc.condition_list, 'ENET') > 0 THEN
                1
            ELSE
                0
        END              AS in_application_flag,
        e.amount         AS amt1,
        t.local_amount   AS amount,
        e.primary_doc_idt,
        c.code
    FROM
             contracts c
        JOIN entry                    e ON c.record_idt = e.contract_idt
        JOIN dwh.dwf_transaction      t ON e.primary_doc_idt = t.doc_idt
        JOIN inst                     i ON i.id = t.institution_id
        JOIN m_dates                  d ON t.banking_date BETWEEN d.min_date AND d.max_date
        LEFT JOIN dwh.dwd_trans_conditions dtc ON dtc.id = t.trans_conditions_id
    WHERE
            instr(t.add_info, 'D_TKN') > 0
        AND nvl(sy_convert.get_tag_value(t.add_info, 'WSP_REQ_ID'), sy_convert.get_tag_value(t.add_info, 'MC_WALLET_DATA')) IN (
            SELECT
                code
            FROM
                token_meta
        )
)
SELECT
    :ORG as org,
    to_char(banking_date,'mm/dd/yyyy') as banking_date,
    to_char(effective_date,'mm/dd/yyyy') as effective_date,
    to_char(settlement_date,'mm/dd/yyyy') as settlement_date,
    institution_id,
    to_char(trans_date,'mm/dd/yyyy') as trans_date,
    doc_idt,
    previous_doc_idt,
    card_brand_id,
    card_category_id,
    card_product_id,
    trans_payment_scheme,
    device_category,
    auth_code,
    transaction_type_id,
    trans_country_code,
    trans_city,
    trans_currency,
    trans_amount,
    settl_currency,
    settl_amount,
    local_amount,
    trans_reason,
    trans_details,
    trans_rrn,
    trans_irn,
    trans_arn,
    trans_response_code,
    trans_srn,
    trans_mcc,
    trans_conditions_id,
    posting_status,
    posting_flag,
    merchant,
    source_institution_id,
    source_card_idt,
    source_device_idt,
    source_contract_idt,
    source_category,
    source_number,
    source_channel,
    source_member_idn,
    source_on_us_flag,
    source_residence,
    source_country_code,
    source_message_code,
    target_institution_id,
    target_card_idt,
    target_device_idt,
    target_contract_idt,
    target_number,
    target_channel,
    target_member_idn,
    target_on_us_flag,
    target_residence,
    target_country_code,
    target_message_code,
    target_category,
    direction,
    payer_country_code,
    payee_country_code,
    regexp_replace(add_info,'[^[:print:]]') as add_info,
    bank_officer_id,
    bin_table_idt,
    batch_idn,
    corrected_doc_idt,
    correction_type,
    card_expire,
    trans_ext_type,
    contra_card_number,
    contra_card_client,
    card_sequence_number,
    trans_psrn,
    to_char(acq_sys_date,'mm/dd/yyyy') as acq_sys_date,
    reason_code,
    fx_seq_number,
    original_doc_idt,
    token_idt,
    trans_comment,
    d_tkn,
    in_application_flag,
    amt1,
    amount,
    primary_doc_idt,
    code
FROM
    transactions