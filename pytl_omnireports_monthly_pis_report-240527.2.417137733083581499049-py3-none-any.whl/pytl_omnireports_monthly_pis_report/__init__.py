__version__ = "240527.2"
__job_name__ = "PyTL_OmniReports_MONTHLY_PIS_REPORT"
__bat_files__ = []
