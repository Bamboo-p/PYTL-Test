/*
* CODE FOR MONTHLY_PIS_REPORT GENERATION
* PyTL_OmniReports_MONTHLY_PIS_REPORT
* Parameters:
*           :ORG                  = '017'
*           :P_REPORT_DATE        = 'DD-MM-YYYY'
*           :P_GL_NBR_1           = '252127'
*           :P_GL_NBR_2           = '562207'
*
* Version history:
* 240417.1 = AlexanderK = ENBD-26617:Initial Development
* 240527.2 = AlexanderK = ENBD-26617:Adjusted Name as a fixed value in the report
*/

with abc as (select  mt.doc__oid                                                                                    DOC_ID,
case  when mt.contract is not null then mt.contract
      when cd.id is not null and cd.CONTRACT_NUMBER not like '017%' then cd.id
      when cd2.id is not null and cd2.CONTRACT_NUMBER not like '017%' then cd2.id
      when c3.id is not null then c3.id
      else null end                                                                                                 C_ID
,case
      when c.contract_number is not null then c.contract_number
      when cd.contract_number is not null and cd.CONTRACT_NUMBER not like '017%' then cd.contract_number
      when cd2.contract_number is not null and cd2.CONTRACT_NUMBER not like '017%' then cd2.contract_number
      when c.id is null and cd.id is null and c3.id is not null then c3.contract_number
      else null end                                                                                                 C_NUMBER
      ,gtc.amount                                                                                                   AMT
      , gtc.curr                                                                                                    CUR
      , gt.order_date                                                                                               GL_POSTING_DATE
      , gt.gl_trans_code                                                                                            GL_TRANS_CODE
      , gt.amount                                                                                                   GL_SYNTH_AMOUNT
      , gt.dr_number                                                                                                GL_DR_NUMBER
      , gt.cr_number                                                                                                GL_CR_NUMBER
      , gt.ref_number                                                                                               REF_NUMBER
      , fi.branch_code                                                                                              ORG_CODE
     from ows.gl_transfer gt
     join ows.gl_trace gtc on gtc.GL_TRANSFER__ID=gt.ID
     join ows.m_transaction mt on mt.id=gtc.m_transaction__id
     join ows.f_i fi on fi.id = gt.f_i and fi.branch_code = :ORG
left join ows.acnt_contract c on c.id=mt.contract and c.amnd_state='A'
left join ows.doc d on d.id=mt.doc__oid
left join ows.acnt_contract cd on d.target_contract=cd.id
left join ows.account a on a.id=mt.source_account
left join ows.acnt_contract c3 on c3.id=a.acnt_contract__oid and c3.amnd_state='A'
left join ows.doc d2 on d2.id=mt.doc__oid
left join ows.acnt_contract cd2 on d2.source_contract=cd2.id
    where gt.order_date between add_months(trunc(to_date(:P_REPORT_DATE,'dd-mm-yyyy'),'mm'),-1) and last_day(add_months(trunc(to_date(:P_REPORT_DATE,'dd-mm-yyyy'),'mm'),-1))
     and (substr(gt.cr_number,-6) = :P_GL_NBR_1 or substr(gt.dr_number,-6) = :P_GL_NBR_1)
      )
,template as (
select 'LE/RC changes' as name, :P_GL_NBR_1 as DR_NA, :P_GL_NBR_1 as CR_NA from dual
union all
select 'Write off' as name, :P_GL_NBR_1 as DR_NA, :P_GL_NBR_2 as CR_NA from dual
union all
select 'PIS Recovery' as name, :P_GL_NBR_1 as DR_NA, ' ' as CR_NA from dual
union all
select 'PIS' as name, ' ' as DR_NA, :P_GL_NBR_1 as CR_NA from dual
)
,gl as(
select
max(org_code) as ORG,
case when GL_TRANS_CODE = 'Transfer' and substr(abc.GL_DR_NUMBER,-6) = :P_GL_NBR_1 and substr(abc.GL_CR_NUMBER,-6) = :P_GL_NBR_1 then 'LE/RC changes'
            when GL_TRANS_CODE = 'Transfer' and substr(abc.GL_DR_NUMBER,-6) = :P_GL_NBR_1 and substr(abc.GL_CR_NUMBER,-6) = :P_GL_NBR_2 then 'Write off'
            when GL_TRANS_CODE = 'RSRV_BAD_DEBT_TRANS' and substr(abc.GL_DR_NUMBER,-6) = :P_GL_NBR_1 then 'PIS Recovery'
            when GL_TRANS_CODE = 'RSRV_BAD_DEBT_TRANS' and substr(abc.GL_CR_NUMBER,-6) = :P_GL_NBR_1 then 'PIS'
            else null end name,
            GL_TRANS_CODE,
--            substr(abc.GL_DR_NUMBER,-6) as DR_NA,
--            substr(abc.GL_CR_NUMBER,-6) as CR_NA,
            sum(abc.AMT) as amount
        from abc
group by case when GL_TRANS_CODE = 'Transfer' and substr(abc.GL_DR_NUMBER,-6) = :P_GL_NBR_1 and substr(abc.GL_CR_NUMBER,-6) = :P_GL_NBR_1 then 'LE/RC changes'
            when GL_TRANS_CODE = 'Transfer' and substr(abc.GL_DR_NUMBER,-6) = :P_GL_NBR_1 and substr(abc.GL_CR_NUMBER,-6) = :P_GL_NBR_2 then 'Write off'
            when GL_TRANS_CODE = 'RSRV_BAD_DEBT_TRANS' and substr(abc.GL_DR_NUMBER,-6) = :P_GL_NBR_1 then 'PIS Recovery'
            when GL_TRANS_CODE = 'RSRV_BAD_DEBT_TRANS' and substr(abc.GL_CR_NUMBER,-6) = :P_GL_NBR_1 then 'PIS'
            else null end,substr(abc.GL_DR_NUMBER,-6),substr(abc.GL_CR_NUMBER,-6),GL_TRANS_CODE
)
select
       gl.org                           as ORG,
       t.name                           as NAME,
       t.DR_NA                          as DEBIT_NA,
       t.CR_NA                          as CREDIT_NA,
       nvl(gl.amount,'0')               as AMOUNT
from template t
left join gl
  on gl.name = t.name