__version__ = "231101.1"
__job_name__ = "PyTL_OmniReports_NIC_CASHBACK_REPORT"
__bat_files__ = ["PyTL_OmniReports_NIC_CASHBACK_REPORT.bat"]
