/*
* Code for NIC_CASHBACK_REPORT
* PyTL_IS_SimpleReports_NIC_CASHBACK_REPORT = NIC_CASHBACK_REPORT.sql
* Version history:
* 20221019.1 : AUBI-3499 : AsserM  : Initial development
* 20230119.1 : AUBI-3627 : Kokila J : Source channel mapping change,transaction  code and instr number comparison change
* 20230310.1 : AUBI-3627 : Shalini : P_REPORT_DATE ,ORG and field names updated in upper case
* 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
*/WITH product AS (
    SELECT /*+ no_merge materialize */
        p.product_id,
        substr(p.code, 1, 3) AS logo,
        p.name
    FROM
        v_dwr_product p
    WHERE
            p.class_code = 'BASE_REPORTS'
        AND p.type_code = 'LOGO'
)
SELECT
    client_number                           AS client_number,
    personal_account                        AS account_number,
    pan                                     AS card_number,
    logo                                    AS logo,
    e.pr_amount                             AS points_redeemed,
    cb_tcode                                AS cashback_txn,
    cb_direction                            AS db_cr,
    e.cb_amount                             AS cashback_amt,
    cb_currency                             AS cashback_curr,
    trans_rrn                               AS rrn,
    to_char(to_date(trans_date),'DD-MON-YYYY')       AS trans_date,                 -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
    to_char(to_date(posting_date),'DD-MON-YYYY HH24:MI:SS') AS cashback_post_date,  -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
    cb_description                          AS cashback_desc,
    source_channel                          AS channel_id,
    decode(posting_status, 'P', 'Posted', 'C', 'Closed',
           'I', 'Inactive', posting_status) AS post_status,
    ' '                                     AS reject_reason
FROM
         dwd_client cl
    JOIN dwd_contract c ON c.client_idt = cl.record_idt
                           AND c.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                           AND c.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
                           AND c.institution_id = (
        SELECT
            id
        FROM
            dwd_institution
        WHERE
            code = :ORG
    )
    JOIN product      p ON p.product_id = c.product_id
    JOIN (
        SELECT
            ROW_NUMBER()
            OVER(PARTITION BY crd.main_contract_idt
                 ORDER BY
                     decode(cs.category, 'V', 1, 'D', 2,
                            3), crd.opening_date DESC, crd.effective_date DESC, crd.record_idt DESC
            ) AS rn,
            crd.*
        FROM
                 dwd_card crd
            JOIN dwd_contract_status cs ON cs.id = crd.status_id
        WHERE
                crd.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
            AND crd.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
            AND crd.institution_id = (
                SELECT
                    id
                FROM
                    dwd_institution
                WHERE
                    code = :ORG
            )
    )            crd ON crd.main_contract_idt = c.record_idt
             AND rn = 1
    JOIN (
        SELECT
            contract_idt,
            SUM(
                CASE
                    WHEN instr(ot.add_info, 'CB_REP=CB;') > 0 THEN    -- [*] 20230119.1 : AUBI-3627 : Kokila J
                        credit - debit
                END
            )                                                        AS cb_amount,
            SUM(
                CASE
                    WHEN instr(ot.add_info, 'CB_REP=PR;') > 0 THEN     -- [*] 20230119.1 : AUBI-3627 : Kokila J
                        credit - debit
                END
            )                                                        AS pr_amount,
            MAX(ot.code)                                             AS cb_tcode,   -- [*] 20230119.1 : AUBI-3627 : Kokila J
            MIN(
                CASE
                    WHEN instr(ot.add_info, 'CB_REP=CB;') > 0 THEN    -- [*] 20230119.1 : AUBI-3627 : Kokila J
                        t.direction
                END
            )                                                        AS cb_direction,
            MIN(
                CASE
                    WHEN instr(ot.add_info, 'CB_REP=CB;') > 0 THEN   -- [*] 20230119.1 : AUBI-3627 : Kokila J
                        curr.name
                END
            )                                                        AS cb_currency,
            t.trans_rrn,
            MAX(
                CASE
                    WHEN instr(ot.add_info, 'CB_REP=CB;') > 0 THEN   -- [*] 20230119.1 : AUBI-3627 : Kokila J
                        to_date(t.trans_date, 'dd-MON-yyyy hh24:mi:ss')
                END
            )                                                        AS trans_date, /*New requirement from client to add transaction date which is selected from the doc's trans_date*/
            MAX(
                CASE
                    WHEN instr(ot.add_info, 'CB_REP=CB;') > 0 THEN   -- [*] 20230119.1 : AUBI-3627 : Kokila J
                        to_date(ae.banking_date, 'dd-MON-yyyy hh24:mi:ss')
                END
            )                                                        AS posting_date,
            MAX(
                CASE
                    WHEN instr(ot.add_info, 'CB_REP=CB;') > 0 THEN
                        ot.name
                END
            )                                                        AS cb_description,
            dwh.sy_convert.get_tag_value(t.add_info, 'SRC_APP_NAME') AS source_channel,  -- [*] 20230119.1 : AUBI-3627 : Kokila J
            doc_idt,
            t.posting_status                                         AS posting_status
        FROM
                 dwf_account_entry ae
            JOIN v_dwr_operation_type ot ON ot.operation_type_id = ae.operation_type_id
                                            AND class_code = '018_TXN_CODE'
                                            AND type_code = 'TXN_CODE'
                                            AND ( instr(ot.add_info, 'CB_REP=CB;') > 0
                                                  OR instr(ot.add_info, 'CB_REP=PR;') > 0 )
            JOIN dwf_transaction      t ON t.doc_idt = ae.primary_doc_idt
                                      AND t.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')									  
                                      AND t.institution_id = (
                SELECT
                    id
                FROM
                    dwd_institution
                WHERE
                    code = :ORG
            )
        JOIN DWD_CURRENCY CURR
	    ON CURR.CODE=ae.currency
	   AND CURR.RECORD_STATE='A'    
        WHERE
                ae.banking_date = to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
            AND ae.institution_id = (
                SELECT
                    id
                FROM
                    dwd_institution
                WHERE
                    code = :ORG
            )
        GROUP BY
            contract_idt,
            t.trans_rrn,
            dwh.sy_convert.get_tag_value(t.add_info, 'SRC_APP_NAME'),
            doc_idt,
            t.posting_status
    )            e ON e.contract_idt = c.record_idt
WHERE
        cl.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    AND cl.record_date_to >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    AND cl.institution_id = (
        SELECT
            id
        FROM
            dwd_institution
        WHERE
            code = :ORG
    )