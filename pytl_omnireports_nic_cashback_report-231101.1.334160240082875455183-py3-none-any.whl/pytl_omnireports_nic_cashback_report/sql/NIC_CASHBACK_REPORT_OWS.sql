/*
* Code for NIC_CASHBACK_REPORT
* \PyTL_OmniReports_NIC_CASHBACK_REPORT = NIC_CASHBACK_REPORT_OWS.sql
* Version history:
* 230516.1: KokilaJ: AUBI-3627: Adding request category and entry role
* 230525.1: DenisKa: AUBI-3627: fixing issue with not full names of ows.mp_operation_type*
* 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
* 20230609.1 : AUBI-3627 : Kokila J: Adding amnd_date and changed source channel mapping
*/
WITH ins AS (
    SELECT
        id          AS p_f_i,
        branch_code AS code
    FROM
        ows.f_i
    WHERE
            branch_code = :ORG
        AND amnd_state = 'A'
)
SELECT
    :ORG                                          AS ORG,
    client_number,
    account_number,
    card_number,
    logo,
    points_redeemed,
    txn_code,
    dr_cr,
    cashback_amount,
    cashback_currency,
    rrn,
    to_char(to_date(trans_date),'DD-MON-YYYY')    AS trans_date,                            -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
    to_char(to_date(cashback_posting_date), 'DD-MON-YYYY HH24:MI:SS') AS cashback_post_date,-- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
    cashback_description                          AS cashback_desc,
    source_channel                                AS channel_id,
    ows.xwdoc('POSTING_STATUS', d.posting_status) AS post_status,
    ows.xwdoc('RETURN_CODE', d.return_code)       AS reject_reason
FROM (
    SELECT /*+ no_merge index(d doc_date) */
        cl.client_number,
        ac.contract_number                    AS account_number,
        cc.contract_number                    AS card_number,
        nvl(substr(ap.code, 9, 3), 'NO LOGO') AS logo,
        d.trans_amount                        AS points_redeemed,  -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
        CASE
            WHEN ot.code = 'TRANS_CR_LTY_CASHBACK_INCP'     THEN
                '871'
            WHEN ot.code = 'TRANS_CR_LTY_CASHBACK_INCP_REV' THEN
                '872'
        END                                   AS txn_code,
        CASE
            WHEN ot.direction = - 1 THEN
                'DR'
            ELSE
                'CR'
        END                                   AS dr_cr,
        t.trans_amount                        AS cashback_amount,
        cur.name                              AS cashback_currency, -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
        d.ret_ref_number                      AS rrn,
        d.trans_date                          AS trans_date,
        t.posting_date                        AS cashback_posting_date, -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
        CASE
            WHEN ot.code = 'TRANS_CR_LTY_CASHBACK_INCP'     THEN
                'CASHBACK'
            WHEN ot.code = 'TRANS_CR_LTY_CASHBACK_INCP_REV' THEN
                'CASHBACK REVERSAL'
        END                                   AS cashback_description,
        regexp_substr(add_info, '(SRC_APP_NAME+)=([^;]+);'
                        , 1, 1, '', 2) source_channel,                    --[*] 20230609.1 : AUBI-3627 : Kokila J: Adding amnd_date and changed source channel mapping
        d.posting_status,
        d.return_code
    FROM
             ows.doc d
        LEFT JOIN ows.m_transaction t       ON d.id=t.doc__oid                  -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
                                            AND d.target_contract=t.contract    -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
        JOIN ows.mp_operation_type_rule otr ON otr.trans_type = d.trans_type -- [*] 230525.1: DenisKa: AUBI-3627: fixing issue with not full names of ows.mp_operation_type*
                                            AND otr.amnd_state = 'A'
                                            AND d.REQUEST_CATEGORY=otr.REQUEST_CATEGORY  -- [+] 20230516.1 : AUBI-3627 : Kokila J
                                            AND otr.entry_role='A'                       -- [+] 20230516.1 : AUBI-3627 : Kokila J
        JOIN ows.mp_operation_type ot       ON ot.id = otr.mp_operation_type__oid  -- [*] 230525.1: DenisKa: AUBI-3627: fixing issue with not full names of ows.mp_operation_type*
                                            AND ot.amnd_state = 'A'
                                            AND ot.code IN (
                                                    'TRANS_CR_LTY_CASHBACK_INCP_REV'
                                                   ,'TRANS_CR_LTY_CASHBACK_INCP'
                                                )
        JOIN ows.acnt_contract ac           ON d.target_contract = ac.id
                                            AND ac.amnd_state = 'A'
        JOIN ins ON ac.f_i = ins.p_f_i
        JOIN ows.acnt_contract cc           ON cc.acnt_contract__oid = ac.id
                                            AND ac.amnd_state = 'A'
                                            AND cc.pcat = 'C'
                                            AND cc.con_cat = 'C'
                                            AND cc.ccat = 'P'
        LEFT JOIN ows.client cl             ON cl.id = ac.client__id
                                            AND cl.amnd_state = 'A'
        LEFT JOIN ows.appl_product ap       ON ap.id = ac.main_product
        LEFT JOIN ows.currency cur               ON cur.code = t.trans_curr
                                            AND cur.amnd_state = 'A'
    WHERE
	-- [+] begin 20230609.1 : AUBI-3627 : Kokila J: Adding amnd_date and changed source channel mapping
        d.amnd_date BETWEEN
	  (SELECT
		/*+ no_merge */
		calendar_date
	  FROM ows.mp_consist_point
	  WHERE local_date         = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY') - 1
	  AND mp_consist_type__oid =
		(SELECT MIN(id)
		FROM ows.mp_consist_type
		WHERE code = 'END_DAY'
		)
	  )
	AND (SELECT
		/*+ no_merge */
		calendar_date
	  FROM ows.mp_consist_point
	  WHERE local_date         = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	  AND mp_consist_type__oid =
		(SELECT MIN(id)
		FROM ows.mp_consist_type
		WHERE code = 'END_DAY'
		) )
	-- [+] end 20230609.1 : AUBI-3627 : Kokila J: Adding amnd_date and changed source channel mapping	
        AND d.posting_status IN ( 'D', 'J', 'E' )
        AND d.target_number IS NOT NULL
        AND nvl(d.is_authorization, 'N') = 'N' /*--and d.is_authorization = 'N'   AUBI-1491*/
        AND d.trans_curr != '000'
) d