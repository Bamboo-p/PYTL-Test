/*
* Code for NIC_CASHBACK_REPORT
* \PyTL_OmniReports_NIC_CASHBACK_REPORT = NIC_CASHBACK_REPORT_STG.sql
* Version history:
* 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
* 20230605.1 : AUBI-3627 : Kokila J :Changing the Summary header
*/

with MAIN_SQL as (
    select
        t1.SERIALIZED.CLIENT_NUMBER         as CLIENT_NUMBER,
        t1.SERIALIZED.ACCOUNT_NUMBER        as ACCOUNT_NUMBER,
        t1.SERIALIZED.CARD_NUMBER           as CARD_NUMBER,
        t1.SERIALIZED.LOGO                  as LOGO,
        t1.SERIALIZED.POINTS_REDEEMED       as POINTS_REDEEMED,
        t1.SERIALIZED.CASHBACK_TXN          as CASHBACK_TXN,
        t1.SERIALIZED.DB_CR                 as DB_CR,
        t1.SERIALIZED.CASHBACK_AMT          as CASHBACK_AMT,
        t1.SERIALIZED.CASHBACK_CURR         as CASHBACK_CURR,
        t1.SERIALIZED.RRN                   as RRN,
        t1.SERIALIZED.TRANS_DATE            as TRANS_DATE,
        t1.SERIALIZED.CASHBACK_POST_DATE    as CASHBACK_POST_DATE,
        t1.SERIALIZED.CASHBACK_DESC         as CASHBACK_DESC,
        t1.SERIALIZED.CHANNEL_ID            as CHANNEL_ID,
        ''                                  as LOST_COLUMN,
        t1.SERIALIZED.POST_STATUS           as POST_STATUS,                        -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
        t1.SERIALIZED.REJECT_REASON         as REJECT_REASON
    from
        PyTL_Serialized_Data t1
    where
        t1.QUERY_NAME = 'NIC_CASHBACK_REPORT_DWH'
        and t1.UNIQUE_CALL_ID = :UNIQUE_CALL_ID
    
    union all
    
    select
        t2.SERIALIZED.CLIENT_NUMBER         as CLIENT_NUMBER,
        t2.SERIALIZED.ACCOUNT_NUMBER        as ACCOUNT_NUMBER,
        t2.SERIALIZED.CARD_NUMBER           as CARD_NUMBER,
        t2.SERIALIZED.LOGO                  as LOGO,
        t2.SERIALIZED.POINTS_REDEEMED       as POINTS_REDEEMED,
        t2.SERIALIZED.CASHBACK_TXN          as CASHBACK_TXN,
        t2.SERIALIZED.DB_CR                 as DB_CR,
        t2.SERIALIZED.CASHBACK_AMT          as CASHBACK_AMT,
        t2.SERIALIZED.CASHBACK_CURR         as CASHBACK_CURR,
        t2.SERIALIZED.RRN                   as RRN,
        t2.SERIALIZED.TRANS_DATE            as TRANS_DATE,
        t2.SERIALIZED.CASHBACK_POST_DATE    as CASHBACK_POST_DATE,
        t2.SERIALIZED.CASHBACK_DESC         as CASHBACK_DESC,
        t2.SERIALIZED.CHANNEL_ID            as CHANNEL_ID,
        'closed'                            as LOST_COLUMN,
        t2.SERIALIZED.POST_STATUS           as POST_STATUS,                      -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
        t2.SERIALIZED.REJECT_REASON         as REJECT_REASON
    from
        PyTL_Serialized_Data t2
    where
        t2.QUERY_NAME = 'NIC_CASHBACK_REPORT_OWS'
        and t2.UNIQUE_CALL_ID = :UNIQUE_CALL_ID
)
select
    t3.CLIENT_NUMBER,
    t3.ACCOUNT_NUMBER,
    t3.CARD_NUMBER,
    t3.LOGO,
    t3.POINTS_REDEEMED,
    t3.CASHBACK_TXN,
    t3.DB_CR,
    t3.CASHBACK_AMT,
    t3.CASHBACK_CURR,
    t3.RRN,
    t3.TRANS_DATE,
    t3.CASHBACK_POST_DATE,
    t3.CASHBACK_DESC,
    t3.CHANNEL_ID,
    t3.LOST_COLUMN,
    t3.POST_STATUS,                                               -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
    t3.REJECT_REASON
from
    MAIN_SQL t3
-- [+] Begin 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition	
union all
select                                            --[*] 20230605.1 : AUBI-3627 : Kokila J :Changing the Summary header
    'TOTAL_POINTS'              as CLIENT_NUMBER,              
    'TOTAL CASHBACK_AMT'        as ACCOUNT_NUMBER,
    'CASHBACK_CURR'             as CARD_NUMBER,
    ''                          as LOGO,
    ''                          as POINTS_REDEEMED,
    ''                          as CASHBACK_TXN,
    ''                          as DB_CR,
    ''                          as CASHBACK_AMT,
    ''                          as CASHBACK_CURR,
    ''                          as RRN,
    ''                          as TRANS_DATE,
    ''                          as CASHBACK_POST_DATE,
    ''                          as CASHBACK_DESC,
    ''                          as CHANNEL_ID,
    ''                          as LOST_COLUMN,
    ''                          as POST_STATUS,
    ''                          as REJECT_REASON
from
    Dual
union all	
--[+] End 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition	
select
    to_char(sum(t4.POINTS_REDEEMED)) as CLIENT_NUMBER,        -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
    to_char(sum(t4.CASHBACK_AMT))    as ACCOUNT_NUMBER,       -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
    to_char(max(t4.CASHBACK_CURR))   as CARD_NUMBER,          -- [*] 20230526.1 : AUBI-3627 : Kokila J: Adding date Format to trans and posting dates and adding condition
    ''                               as LOGO,
    ''                          as POINTS_REDEEMED,
    ''                          as CASHBACK_TXN,
    ''                          as DB_CR,
    ''                          as CASHBACK_AMT,
    ''                          as CASHBACK_CURR,
    ''                          as RRN,
    ''                          as TRANS_DATE,
    ''                          as CASHBACK_POST_DATE,
    ''                          as CASHBACK_DESC,
    ''                          as CHANNEL_ID,
    ''                          as LOST_COLUMN,
    ''                          as POST_STATUS,
    ''                          as REJECT_REASON
from
    MAIN_SQL t4
