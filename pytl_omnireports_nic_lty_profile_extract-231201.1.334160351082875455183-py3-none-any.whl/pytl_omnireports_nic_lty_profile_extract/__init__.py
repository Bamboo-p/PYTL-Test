__version__ = "231201.1"
__job_name__ = "PyTL_OmniReports_NIC_LTY_PROFILE_EXTRACT"
__bat_files__ = []
