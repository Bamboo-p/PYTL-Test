/*
* PyTL_OmniReports_NIC_LTY_PROFILE_EXTRACT=NIC_LTY_PROFILE_EXTRACT.SQL
* Parameters:
    ORG                = '328'
    P_REPORT_DATE      = 'DD-MM-YYYY' = SYSDATE
* VERSION HISTORY:
* 231128.1 = Santosh = AAFP-177 : Initial Version
* P_BLOCK_LIST:D,G,H,I,K,Q,T,X,Y,Z
* P_BLOCK_LIST_2:B,C
* 231129.1 = Santosh = AAFP-177 : Added additional_details_3
* 231201.1 = Santosh = AAFP-177 : change to pick only DD in billing
*/
WITH ins AS (
    SELECT      /*+ no_merge materialize */
        code   AS branch_code,
        name   AS bank_name,
        institution_id
    FROM
        dwh.v_dwr_institution
    WHERE
        class_code = 'BASE_REPORTS'
        AND type_code = 'BANK_DESC'
        AND code = :ORG
), 
client AS (
    SELECT
        * /*+ no_merge materialize */
    FROM
        (
            SELECT
                cl.record_idt,
                cl.record_date_from,
                cl.record_date_to,
                cl.client_number,
                cl.client_category,
                'DEFAULT' AS customer_type,
                cl.first_name
                || ' '
                || cl.middle_name
                || ' '
                || cl.last_name AS member_name,
                TO_CHAR(cl.birth_date, 'ddmmyyyy') AS dob,
                cl.gender,
                cl.citizenship,
                cl.country_code,
                sy_convert.get_tag_value(cl.add_info, 'PASSP_NR') AS passport_number,
                cl.language   as,
                cl.record_state,
                cl.creation_date,
                ROW_NUMBER() OVER(
                    PARTITION BY cl.record_idt
                    ORDER BY
                        nvl(cl.record_date_from, TO_DATE('01.01.1900', 'dd.mm.yyyy')) ASC
                ) AS cl_rn
            FROM
                dwh.dwd_client cl
                JOIN ins ON ins.institution_id = cl.institution_id
                LEFT JOIN dwd_client_type clt ON cl.client_type_id = clt.id
        )
    WHERE
        record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
),
addr AS (
    SELECT /*+ no_merge materialize */
        client_idt,
        MAX(addr_rn) addr_rn,
        MAX(type_add_code) type_add_code,
        MAX(record_date_from) record_date_from,
        MAX(record_date_to) record_date_to,
        MAX(curr_add_l1) curr_add_l1,
        MAX(curr_add_l2) curr_add_l2,
        MAX(curr_add_l3) curr_add_l3,
        MAX(prem_add_l1) prem_add_l1,
        MAX(prem_add_l2) prem_add_l2,
        MAX(prem_add_l3) prem_add_l3,
        MAX(phone) phone,
        MAX(email) email
    FROM
        (
            SELECT /*+ no_merge materialize */
                MAX(da.record_date_from) AS record_date_from,
                MAX(da.record_date_to) AS record_date_to,
                da.client_idt,
                MAX(CASE
                    WHEN dat.code = 'MAIL_ADDR'
                         then sy_convert.get_tag_value(da.add_info, 'COPY_TO_ADDRESS')
                END) AS type_add_code,
                MAX(CASE
                    WHEN dat.code = 'PRESENT' THEN address_line_1
                    ELSE NULL
                END) AS curr_add_l1,
                MAX(CASE
                    WHEN dat.code = 'PRESENT' THEN address_line_2
                    ELSE NULL
                END) AS curr_add_l2,
                MAX(CASE
                    WHEN dat.code = 'PRESENT' THEN address_line_2
                    ELSE NULL
                END) AS curr_add_l3,
                MAX(CASE
                    WHEN dat.code = 'PERMANENT' THEN address_line_1
                    ELSE NULL
                END) AS prem_add_l1,
                MAX(CASE
                    WHEN dat.code = 'PERMANENT' THEN address_line_2
                    ELSE NULL
                END) AS prem_add_l2,
                MAX(CASE
                    WHEN dat.code = 'PERMANENT' THEN address_line_2
                    ELSE NULL
                END) AS prem_add_l3,
                MAX(CASE
                    WHEN dat.code = 'ADD_SMS_1' THEN address_zip
                    ELSE NULL
                END) AS phone,
                MAX(CASE
                    WHEN dat.code = 'ADD_SMS_1' THEN e_mail
                    ELSE NULL
                END) AS email,
                ROW_NUMBER() OVER(
                    PARTITION BY da.record_idt
                    ORDER BY
                        nvl(da.record_date_from, TO_DATE('01.01.1900', 'dd.mm.yyyy')) ASC
                ) AS addr_rn
            FROM
                dwh.dwd_address da
                JOIN ins ON ins.institution_id = da.institution_id
                JOIN dwh.dwd_address_type dat ON da.address_type_id = dat.id
            WHERE
                dat.code IN (
                    'MAIL_ADDR',
                    'ADD_SMS_1',
                    'PRESENT',
                    'PERMANENT'
                )
                AND da.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                AND da.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
            GROUP BY
                da.client_idt,
                da.record_idt,
                da.record_date_from
        )
    WHERE
        record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    GROUP BY
        client_idt
),
attr_card AS (
    SELECT /*+ no_merge materialize */
        main_contract_idt,
        MAX(CASE
            WHEN da.type_code = 'BLOCK_CODE_CARD_' || :ORG THEN da.code
            ELSE NULL
        END) AS card_blk,
        MAX(CASE
            WHEN da.type_code = 'BLOCK_CODE_CARD_' || :ORG THEN dca.attr_date_from
            ELSE NULL
        END) AS card_blk_date,
        dca.card_idt
    FROM
        (
            SELECT /*+ no_merge use_hash(cd i) use_hash(cd cs) ordered */
                ROW_NUMBER() OVER(
                    PARTITION BY cd.main_contract_idt
                    ORDER BY
                        nvl(effective_date, TO_DATE('01.01.1990', 'dd.mm.yyyy')) DESC, cd.record_idt DESC
                ) rn,
                cd.main_contract_idt,
                cd.record_idt   AS card_idt
            FROM
                dwh.dwd_card cd
                JOIN ins ON ins.institution_id = cd.institution_id
            WHERE
                cd.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                AND cd.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                AND cd.main_card_flag = 'Y'
                AND cd.plastic_status <> 'C'
        ) primary_card
        JOIN dwh.dwa_card_attribute dca ON primary_card.card_idt = dca.card_idt
                                       AND primary_card.rn = 1
        JOIN dwh.dwd_attribute da ON da.id = dca.attr_id
                                 AND da.type_code = 'BLOCK_CODE_CARD_' || :ORG
    WHERE
        dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND dca.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    GROUP BY
        main_contract_idt,
        dca.card_idt
),
prev_attr_crd AS (
    SELECT /*+ no_merge materialize */
        main_contract_idt,
        MAX(CASE
            WHEN da.type_code = 'BLOCK_CODE_CARD_' || :ORG THEN da.code
            ELSE NULL
        END) AS prev_card_blk
    FROM
        attr_card
        JOIN dwh.dwa_card_attribute dca ON attr_card.card_idt = dca.card_idt
        JOIN dwh.dwd_attribute da ON da.id = dca.attr_id
                                 AND da.type_code = 'BLOCK_CODE_CARD_' || :ORG
    WHERE
        dca.attr_date_to = card_blk_date - 1
    GROUP BY
        main_contract_idt
),
attr AS (
    SELECT /*+ no_merge use_hash(dca da) */
        dca.contract_idt,
		MAX(CASE
            WHEN da.type_code = 'PCT_TARIFF' THEN da.code
            ELSE NULL
        END) AS pct_tariff,
        MAX(CASE
            WHEN da.type_code = 'BLOCK_CODE_ACC1_' || :ORG THEN da.code
            ELSE '_'
        END) AS bc1,
        MAX(CASE
            WHEN da.type_code = 'BLOCK_CODE_ACC2_' || :ORG THEN da.code
            ELSE '_'
        END) AS bc2,
        MAX(CASE
            WHEN da.type_code = 'BLOCK_CODE_ACC2_' || :ORG THEN dca.attr_date_from
            ELSE NULL
        END) AS bc2_date,
        MAX(CASE
            WHEN da.type_code = 'BLOCK_CODE_ACC1_' || :ORG THEN dca.attr_date_from
            ELSE NULL
        END) AS bc1_date
    FROM
        dwh.dwa_contract_attribute dca
        JOIN dwh.dwd_attribute da ON da.id = dca.attr_id
                                 AND da.type_code IN (
            'PCT_TARIFF',
			'BLOCK_CODE_ACC1_' || :ORG,
            'BLOCK_CODE_ACC2_' || :ORG
        )
    WHERE
        dca.attr_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND dca.attr_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    GROUP BY
        dca.contract_idt
),
prev_attr AS (
    SELECT /*+ no_merge materialize */
        dca.contract_idt,
		MAX(CASE
            WHEN da.type_code = 'PCT_TARIFF' THEN da.code
            ELSE NULL
        END) AS pct_tariff,
        MAX(CASE
            WHEN da.type_code = 'BLOCK_CODE_ACC2_' || :ORG
                 AND dca.attr_date_to = bc2_date - 1 THEN da.code
            ELSE '_'
        END) AS prev_bc2,
        MAX(CASE
            WHEN da.type_code = 'BLOCK_CODE_ACC1_' || :ORG
                 AND dca.attr_date_to = bc1_date - 1 THEN da.code
            ELSE '_'
        END) AS prev_bc1
    FROM
        attr
        JOIN dwh.dwa_contract_attribute dca ON attr.contract_idt = dca.contract_idt
        JOIN dwh.dwd_attribute da ON da.id = dca.attr_id
                                 AND da.type_code IN (
            'PCT_TARIFF',
			'BLOCK_CODE_ACC2_' || :ORG,
            'BLOCK_CODE_ACC1_' || :ORG
        )
    WHERE
        ( dca.attr_date_to = bc2_date - 1
          OR dca.attr_date_to = bc1_date - 1 )
    GROUP BY
        dca.contract_idt
),
billing AS (
    SELECT /*+ use_hash (dcb inst) */
        contract_idt,
        to_char(MAX(billing_date),'DD') AS billing_date -- [*] 231201.1 = Santosh = AAFP-177 : change to pick only DD in billing
    FROM
        dwf_contract_billing dcb
        JOIN ins ON ins.institution_id = dcb.institution_id
    WHERE
        billing_date >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
    GROUP BY
        contract_idt
),	
main_data AS (
    SELECT /*+ no_merge materialize */
        CASE
            WHEN ( TO_CHAR(c.date_open, 'dd-mm-yyyy') = TO_CHAR(TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy'), 'dd-mm-yyyy') ) THEN 'N'
            WHEN ( ( cl_rn > 1
                     OR addr_rn > 1 )
                   AND ( cl.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                         OR addr.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') ) ) THEN 'U'
        END AS action_type_c,
        CASE
            WHEN ( ( ( attr.bc1_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                     AND ( attr.bc1 IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            ) ) )
                   OR ( ( attr_card.card_blk_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                        AND attr_card.card_blk IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            ) ) 
			OR 
			( ( attr.bc2_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                     AND ( attr.bc2 IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            ) ) )) THEN 'B'
            WHEN ((( attr.bc1_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                     AND ( attr.bc1 IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST_2, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST_2, '[^,]+', 1, level) IS NOT NULL
            ) ) )
			OR
			( ( attr.bc2_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                     AND ( attr.bc2 IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST_2, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST_2, '[^,]+', 1, level) IS NOT NULL
            ) ) )
                   OR ( ( attr_card.card_blk_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                        AND attr_card.card_blk IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST_2, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST_2, '[^,]+', 1, level) IS NOT NULL
            ) ) ) THEN 'C'
            WHEN ( (  attr.bc1 <> prev_attr.prev_bc1
                       AND attr.bc1_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') 
                     AND  attr.bc1 NOT IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
                    )
                   AND prev_attr.prev_bc1 IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            )) 
			OR
			(attr.bc2 <> prev_attr.prev_bc2
                       AND attr.bc2_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                     AND attr.bc2 NOT IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            )
                AND prev_attr.prev_bc2 IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            ) )
                   OR ( attr_card.card_blk <> prev_attr_crd.prev_card_blk
                          AND attr_card.card_blk_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') 
                        AND  attr_card.card_blk NOT IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            )
                              AND prev_attr_crd.prev_card_blk IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            ) ) ) THEN 'A'
		WHEN attr.bc2 is null then 'D'
		WHEN attr.bc1 is null then 'D'	
        END action_type_bc,
        cl.client_number   AS base_number,
        attr.pct_tariff AS customer_segment,
        customer_type      AS customer_type,
        member_name        AS member_name,
        DECODE(addr.type_add_code, 'PRESENT', addr.curr_add_l1, 'PERMANENT', addr.prem_add_l1)
        || ' '
        || DECODE(addr.type_add_code, 'PRESENT', addr.curr_add_l2, 'PERMANENT', addr.prem_add_l2)
        || ' '
        || DECODE(addr.type_add_code, 'PRESENT', addr.curr_add_l3, 'PERMANENT', addr.prem_add_l3)
        || ' ' AS member_address,
        addr.phone         AS mobile_number,
        addr.email         AS email_address,
        dob                AS date_of_birth,
        cl.gender          AS gender,
        cl.citizenship     AS nationality,
        cl.country_code    AS national_identity,
        passport_number    AS passport_number,
        cl.language        AS preferred_language,
        '|' AS filler,
        cl.record_idt      AS client_idt,
		c.personal_account  AS personal_account,
		p.code 				AS prd_code,
		substr(cd.pan, 1, 8) AS bin,
		b.billing_date       AS billing_date
    FROM
        client cl
        JOIN dwh.dwd_contract c ON cl.record_idt = c.client_idt
                               AND c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                               AND c.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        JOIN dwh.opt_dm_nice_contract_hierarchy c ON cl.record_idt = c.client_idt
                               AND c.banking_date <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
							   AND contract_hierarchy_level=1
        JOIN dwd_int_product p ON c.int_product_idt   = p.record_idt 
							  AND p.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY') 
							  AND p.record_date_to   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
		LEFT JOIN dwd_card cd ON cd.main_contract_idt = c.record_idt
		                      AND cd.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY') 
		                      AND cd.record_date_to   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY') 									
        LEFT JOIN addr ON addr.client_idt = cl.record_idt
        LEFT JOIN attr ON c.record_idt = attr.contract_idt
        LEFT JOIN prev_attr ON c.record_idt = prev_attr.contract_idt
        LEFT JOIN attr_card ON c.record_idt = attr_card.main_contract_idt
        LEFT JOIN prev_attr_crd ON c.record_idt = prev_attr_crd.main_contract_idt
		LEFT JOIN billing b ON b.contract_idt = c.record_idt
    WHERE
        ( cl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
          AND cl.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
        OR addr.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        OR ( (attr.bc1_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
             OR ( attr.bc2_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') ) )
        OR ( attr_card.card_blk_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
        AND c.parent_contract_idt IS NULL
    UNION ALL
    SELECT /*+ no_merge materialize */
        CASE
            WHEN ( TO_CHAR(c.date_open, 'dd-mm-yyyy') = TO_CHAR(TO_DATE(:P_REPORT_DATE, 'dd-mm-yyyy'), 'dd-mm-yyyy') ) THEN 'N'
            WHEN ( ( cl_rn > 1
                     OR addr_rn > 1 )
                   AND ( cl.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                         OR addr.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') ) ) THEN 'U'
        END AS action_type_c,
         CASE
            WHEN ( ( ( attr.bc1_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                     AND ( attr.bc1 IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            ) ) )
                   OR ( ( attr_card.card_blk_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                        AND attr_card.card_blk IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            ) ) 
			OR 
			( ( attr.bc2_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                     AND ( attr.bc2 IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            ) ) )) THEN 'B'
            WHEN ((( attr.bc1_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                     AND ( attr.bc1 IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST_2, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST_2, '[^,]+', 1, level) IS NOT NULL
            ) ) )
			OR
			( ( attr.bc2_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                     AND ( attr.bc2 IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST_2, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST_2, '[^,]+', 1, level) IS NOT NULL
            ) ) )
                   OR ( ( attr_card.card_blk_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
                        AND attr_card.card_blk IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST_2, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST_2, '[^,]+', 1, level) IS NOT NULL
            ) ) ) THEN 'C'
            WHEN ( (  attr.bc1 <> prev_attr.prev_bc1
                       AND attr.bc1_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') 
                     AND  attr.bc1 NOT IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
                    )
                   AND prev_attr.prev_bc1 IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            )) 
			OR
			(attr.bc2 <> prev_attr.prev_bc2
                       AND attr.bc2_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                     AND attr.bc2 NOT IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            )
                AND prev_attr.prev_bc2 IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            ) )
                   OR ( attr_card.card_blk <> prev_attr_crd.prev_card_blk
                          AND attr_card.card_blk_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') 
                        AND  attr_card.card_blk NOT IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            )
                              AND prev_attr_crd.prev_card_blk IN (
                SELECT
                    TRIM(regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level)) org
                FROM
                    dual
                CONNECT BY
                    regexp_substr(:P_BLOCK_LIST, '[^,]+', 1, level) IS NOT NULL
            ) ) ) THEN 'A'
			WHEN attr.bc2 is null then 'D'
			WHEN attr.bc1 is null then 'D'
        END action_type_bc,
        c.root_corporate_id   AS base_number,
        attr.pct_tariff AS customer_segment,
        customer_type              AS customer_type,
        member_name                AS member_name,
        DECODE(addr.type_add_code, 'PRESENT', addr.curr_add_l1, 'PERMANENT', addr.prem_add_l1)
        || ' '
        || DECODE(addr.type_add_code, 'PRESENT', addr.curr_add_l2, 'PERMANENT', addr.prem_add_l2)
        || ' '
        || DECODE(addr.type_add_code, 'PRESENT', addr.curr_add_l3, 'PERMANENT', addr.prem_add_l3)
        || ' ' AS member_address,
        addr.phone                 AS mobile_number,
        addr.email                 AS email_address,
        dob                        AS date_of_birth,
        cl.gender                  AS gender,
        cl.citizenship             AS nationality,
        cl.country_code            AS national_identity,
        passport_number            AS passport_number,
        cl.language                AS preferred_language,
        '|' AS filler,
        cl.record_idt              AS client_idt,
		c.personal_account  AS personal_account,
		p.code 				AS prd_code,
		substr(cd.pan, 1, 8) AS bin,
		b.billing_date       AS billing_date
    FROM
        client cl
        JOIN dwh.dwd_contract c ON cl.record_idt = c.client_idt
                               AND c.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                               AND c.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        JOIN dwh.opt_dm_nice_contract_hierarchy c ON cl.record_idt = c.client_idt
                               AND c.banking_date <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
							   AND contract_hierarchy_level=1
							   AND root_logo like '%C%'
        JOIN dwd_int_product p ON c.int_product_idt   = p.record_idt 
							  AND p.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY') 
							  AND p.record_date_to   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
		LEFT JOIN dwd_card cd ON cd.main_contract_idt = c.record_idt
		                      AND cd.record_date_from <= to_date(:P_REPORT_DATE, 'DD-MM-YYYY') 
		                      AND cd.record_date_to   >= to_date(:P_REPORT_DATE, 'DD-MM-YYYY')
		LEFT JOIN addr ON addr.client_idt = cl.record_idt
        LEFT JOIN attr ON c.record_idt = attr.contract_idt
        LEFT JOIN prev_attr ON c.record_idt = prev_attr.contract_idt
        LEFT JOIN attr_card ON c.record_idt = attr_card.main_contract_idt
        LEFT JOIN prev_attr_crd ON c.record_idt = prev_attr_crd.main_contract_idt
		LEFT JOIN billing b ON b.contract_idt = c.record_idt
    WHERE
       ( cl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
          AND cl.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
        OR addr.record_date_from = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        OR ( (attr.bc1_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
             OR ( attr.bc2_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') ) )
        OR ( attr_card.card_blk_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY') )
), main_sql AS (
    SELECT /*+ no_merge materialize */
        action_type_c   AS action_type,
        case when length(base_number) < 10 then rpad(lpad(md.base_number,10,0),15,' ') 
        else rpad(nvl(md.base_number, ' '), 15, ' ') end AS base_number,
        rpad(nvl(md.customer_segment, ' '), 50, ' ') AS customer_segment,
        rpad(nvl(md.customer_type, ' '), 50, ' ') AS customer_type,
        rpad(nvl(md.member_name, ' '), 50, ' ') AS member_name,
        rpad(nvl(md.member_address, ' '), 500, ' ') AS member_address,
        rpad(nvl(md.mobile_number, ' '), 15, ' ') AS mobile_number,
        rpad(nvl(md.email_address, ' '), 150, ' ') AS email_address,
        lpad(nvl(md.date_of_birth, ' '), 8, ' ') AS date_of_birth,
        lpad(nvl(md.gender, ' '), 1, ' ') AS gender,
        rpad(nvl(md.nationality, ' '), 50, ' ') AS nationality,
        lpad(' ', 16, ' ') AS national_identity,
        rpad(nvl(md.passport_number, ' '), 10, ' ') AS passport_number,
        rpad(nvl(md.preferred_language, 'ENG'), 10, ' ') AS preferred_language,
		md.personal_account,
		md.prd_code,
		md.bin,
		md.billing_date
    FROM
        main_data md
    WHERE
        md.action_type_c IS NOT NULL
    UNION ALL
    SELECT /*+ no_merge materialize */
        rpad(nvl(md.action_type_bc, ' '), 1, ' ') AS action_type,
        case when length(base_number) < 10 then rpad(lpad(md.base_number,10,0),15,' ')
        else rpad(nvl(md.base_number, ' '), 15, ' ') end AS base_number,
        rpad(nvl(md.customer_segment, ' '), 50, ' ') AS customer_segment,
        rpad(nvl(md.customer_type, ' '), 50, ' ') AS customer_type,
        rpad(nvl(md.member_name, ' '), 50, ' ') AS member_name,
        rpad(nvl(md.member_address, ' '), 500, ' ') AS member_address,
        rpad(nvl(md.mobile_number, ' '), 15, ' ') AS mobile_number,
        rpad(nvl(md.email_address, ' '), 150, ' ') AS email_address,
        rpad(nvl(md.date_of_birth, ' '), 8, ' ') AS date_of_birth,
        rpad(nvl(md.gender, ' '), 1, ' ') AS gender,
        rpad(nvl(md.nationality, ' '), 50, ' ') AS nationality,
        lpad(' ', 16, ' ') AS national_identity,
        rpad(nvl(md.passport_number, ' '), 10, ' ') AS passport_number,
        rpad(nvl(md.preferred_language, 'ENG'), 10, ' ') AS preferred_language,
		md.personal_account,
		md.prd_code,
		md.bin,
		md.billing_date
    FROM
        main_data md
    WHERE
        md.action_type_bc IS NOT NULL
)
SELECT * FROM
(SELECT /*+ no_merge materialize */
    :ORG AS org,
    lpad(ROWNUM, 6, 0) AS recordnumber,
    CASE
        WHEN ( (action_type LIKE 'N%'
               AND action_type LIKE '%C')
               OR
               action_type LIKE 'N%D%') THEN 'N'
        WHEN ( action_type LIKE 'N%C%B%'
               OR 
               action_type LIKE 'N%B%'
               OR
               action_type LIKE 'N%A%'
			   OR 
			   action_type LIKE 'D%B%'
			   OR
			   action_type LIKE 'D%C%'
               ) THEN 'A'
        ELSE substr(action_type, length(action_type), 1)
    END AS action_type,
    base_number,
    customer_segment,
    customer_type,
    member_name,
    member_address,
    mobile_number,
    email_address,
    date_of_birth,
    gender,
    nationality,
    national_identity,
    passport_number,
    preferred_language,
    rpad('CNR='||personal_account||';PRD='||prd_code||';BILLC='||billing_date||';',100,' ') as additional_details_1,
    rpad(' ', 100, ' ') AS additional_details_2,
	rpad(' ', 100, ' ') AS additional_details_3,
	rpad(bin,8,' ') as bin
FROM
(
SELECT /*+ no_merge materialize */
    LISTAGG(action_type, ',') WITHIN GROUP(
        ORDER BY
            action_type DESC
    ) AS action_type,
    base_number,
    customer_segment,
    customer_type,
    member_name,
    member_address,
    mobile_number,
    email_address,
    date_of_birth,
    gender,
    nationality,
    national_identity,
    passport_number,
    preferred_language,
	personal_account,
	prd_code,
	bin,
	billing_date,
    1 AS rn
FROM
    main_sql s1
WHERE
    action_type <> 'U'
GROUP BY
    base_number,
    customer_segment,
    customer_type,
    member_name,
    member_address,
    mobile_number,
    email_address,
    date_of_birth,
    gender,
    nationality,
    national_identity,
    passport_number,
    preferred_language,
	personal_account,
	prd_code,
	bin,
	billing_date
UNION ALL
SELECT /*+ no_merge materialize */
    action_type,
    base_number,
    customer_segment,
    customer_type,
    member_name,
    member_address,
    mobile_number,
    email_address,
    date_of_birth,
    gender,
    nationality,
    national_identity,
    passport_number,
    preferred_language,
	personal_account,
	prd_code,
	bin,
	billing_date,
    ROW_NUMBER() OVER(
        PARTITION BY base_number
        ORDER BY
            action_type
    ) AS rn
FROM
    main_sql s2
WHERE
    action_type = 'U'
)
WHERE 
    rn =1 

)
where action_type <> 'D'
order by action_type desc