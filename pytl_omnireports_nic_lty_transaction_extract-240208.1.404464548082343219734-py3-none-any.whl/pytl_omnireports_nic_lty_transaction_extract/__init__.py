__version__ = "240208.1"
__job_name__ = "PyTL_OmniReports_NIC_LTY_TRANSACTION_EXTRACT"
__bat_files__ = []
