__version__ = "240607.1"
__job_name__ = "PyTL_OmniReports_NIC_VIS_EXCEPTION_REPORT"
__bat_files__ = []

