/*
NIC_VIS_EXCEPTION_REPORT.sql
240308.1 = Santosh Singh = NICORE-1005: Initial Development
240425.1 = Santosh Singh = NICORE-1005: Logic correction for EXCEPTION transactions
240607.1 = Santosh Singh = ADCB-11516: Mapping of fields changed and performance enchancement
*/
WITH fi AS (
    SELECT /*+ no_merge materialize */
        id            institution_id,
        branch_code   code,
        name,
        add_info
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code   branch_code_posting,
                dwd_institution.name,
                dwd_institution.add_info
            FROM
                dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORG, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORG, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
)
,exid as (
	select /*+no_merge materialize */
	       dca.card_idt,
		   dca.attr_value card_exid
	  from dwa_card_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CARD'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	)

,event as (select /*+no_merge materialize */
             dc.record_idt,
             dc.pan,
             dc.card_int_product_idt,
             substr(regexp_substr(details,'JSON=[^;]+;',1,1),6) as jsonmess,
             ev.*
 FROM dwd_card dc
 JOIN fi ON fi.institution_id  = dc.institution_id
  AND dc.institution_id = fi.institution_id
  AND dc.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
  AND dc.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
 JOIN dwf_card_event ev on ev.card_idt = dc.record_idt
 JOIN dwd_event_type et on ev.event_type_id = et.id
  AND et.code like ('IPP_VIS%') --not in ('IPP_VIS_TRAN-CANCELLED','IPP_VIS_TRAN-CONFIRMED')
 WHERE ev.activate_date BETWEEN TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')-2 AND TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
   
 )	
,doc_level as (
	select tr.* 
	from dwf_transaction tr
	join fi on tr.institution_id = fi.institution_id
	where tr.banking_date = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	and sy_convert.get_tag_value(tr.add_info, 'INST_VER') = 'VISA_INST'
	and sy_convert.get_tag_value(tr.add_info, 'VIS_WARNING') = 'Y'
 )

 /* Event Level EXCEPTION */
SELECT /*+ no_merge */ distinct
    fi.code            																				AS ORG,
	p.code 																							AS PRODUCT_CODE,
    decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)),'Y',exid.card_exid, et.pan) 				AS PAN,
	sy_convert.get_tag_value(et.details, 'VIS_RET_LABEL')                                           AS STATUS,
	JSON_VALUE(jsonmess, '$.messageMetadata.vMessageID')											AS MESSAGEID,									
	sy_convert.get_tag_value(et.details, 'PLAN_NR') 												AS PLAN_NUMBER,
	sy_convert.get_tag_value(et.details, 'PLAN/installmentPlan/numberOfInstallments')				AS TENURE, 
	sy_convert.get_tag_value(et.details, 'PLAN/installmentPlan/costInfo/annualPercentageRate') 		AS APR,
	sy_convert.get_tag_value(et.details, 'PLAN/installmentPlan/costInfo/totalUpfrontFees')/100    	AS PROCESSING_FEE,
	JSON_VALUE(jsonmess, '$.transactionAmount') / 100												AS TRANSACTION_AMOUNT,
    NULL            												                                AS SETTLEMENT_AMOUNT,
	NULL         																					AS MERCHANT_NAME,
	NULL         																					AS MERCHANT_ID,
	JSON_VALUE(jsonmess, '$.authCode')      														AS AUTH_CODE,
	et.activate_date																				AS TRANSACTION_DATE,
	--NULL        																					AS ARN,
    NULL                                                                                            AS RRN,
	JSON_VALUE(jsonmess, '$.vPlanID')				 												AS PLAN_ID,
	JSON_VALUE(jsonmess, '$.messageMetadata.createdDateTime')       								AS CREATEDDATETIME,
--	sy_convert.get_tag_value(et.details, 'VIS_RET_LABEL') 											AS EXCEPTIONREASONCODE,
	sy_convert.get_tag_value(et.details, 'VIS_RET_TEXT') 											AS EXCEPTIONDESCRIPTION
--	sy_convert.get_tag_value(et.details, 'VIS_RET_TEXT') 											AS FAILUREDETAILS
FROM
    event et
	JOIN fi ON et.institution_id = fi.institution_id 
    AND sy_convert.get_tag_value(et.details, 'VIS_RET_CLASS') = 'E' 
--	LEFT JOIN dwd_card card ON card.record_idt = et.card_idt
    LEFT JOIN dwd_card_int_product p on p.record_idt = et.card_int_product_idt
	LEFT JOIN exid on exid.card_idt = et.record_idt
	
WHERE 
--	card.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
--    AND card.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
	 p.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    AND p.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')

UNION ALL

 /* Doc Level EXCEPTION */
SELECT /*+ no_merge parallel(16) */ distinct
    fi.code            																				AS ORG,
	p.code 																							AS PRODUCT_CODE,
    decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)),'Y',exid.card_exid, et.pan) 				AS PAN,
	sy_convert.get_tag_value(et.details, 'VIS_RET_LABEL')                                           AS STATUS,
	JSON_VALUE(jsonmess, '$.messageMetadata.vMessageID')											AS MESSAGEID,									
	sy_convert.get_tag_value(et.details, 'PLAN_NR') 												AS PLAN_NUMBER,
	sy_convert.get_tag_value(et.details, 'PLAN/installmentPlan/numberOfInstallments')				AS TENURE, 
	sy_convert.get_tag_value(et.details, 'PLAN/installmentPlan/costInfo/annualPercentageRate') 		AS APR,
	sy_convert.get_tag_value(et.details, 'PLAN/installmentPlan/costInfo/totalUpfrontFees')/100    	AS PROCESSING_FEE,
	doc.trans_amount												                                AS TRANSACTION_AMOUNT,
    doc.settl_amount												                                AS SETTLEMENT_AMOUNT,
	doc.trans_details																				AS MERCHANT_NAME,
	doc.source_number																				AS MERCHANT_ID,
	doc.auth_code                             														AS AUTH_CODE,
	et.activate_date																				AS TRANSACTION_DATE,
	--doc.trans_arn																					AS ARN,
    doc.trans_rrn                                                                                   AS RRN,
	JSON_VALUE(jsonmess, '$.vPlanID')				 												AS PLAN_ID,
	JSON_VALUE(jsonmess, '$.messageMetadata.createdDateTime')       								AS CREATEDDATETIME,
	--doc.reason_code 											                                    AS EXCEPTIONREASONCODE,
	'Confirmation API not received'                      											AS EXCEPTIONDESCRIPTION
	--'Confirmation API not received'                      											AS FAILUREDETAILS
FROM
    doc_level doc
	JOIN fi ON doc.institution_id = fi.institution_id 
    JOIN event et on doc.target_card_idt = et.card_idt
--            AND  sy_convert.get_tag_value(doc.add_info, 'vPlanAcceptanceID') = sy_convert.get_tag_value(et.details, 'vPlanAcceptanceID')
--            AND  sy_convert.get_tag_value(doc.add_info, 'VIS_TRAN_ADD_ID') = sy_convert.get_tag_value(et.details, 'VIS_TRAN_ADD_ID')
              AND  sy_convert.get_tag_value(doc.add_info, 'VIS_TRAN-EVENT_ID') = sy_convert.get_tag_value(et.details, 'VIS_TRAN-EVENT_ID')  
--	LEFT JOIN dwd_card card ON card.record_idt = doc.target_card_idt
    LEFT JOIN dwd_card_int_product p on p.record_idt = et.card_int_product_idt
	LEFT JOIN exid on exid.card_idt = et.record_idt	
WHERE  p.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
   AND p.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')