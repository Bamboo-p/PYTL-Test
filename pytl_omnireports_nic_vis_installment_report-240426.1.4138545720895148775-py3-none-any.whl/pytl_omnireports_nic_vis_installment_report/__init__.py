__version__ = "240426.1"
__job_name__ = "PyTL_OmniReports_NIC_VIS_INSTALLMENT_REPORT"
__bat_files__ = []

