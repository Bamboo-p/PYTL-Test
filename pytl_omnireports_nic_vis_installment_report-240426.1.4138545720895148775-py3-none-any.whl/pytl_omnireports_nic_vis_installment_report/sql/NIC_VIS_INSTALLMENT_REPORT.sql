/*
NIC_VIS_INSTALLMENT_REPORT.sql
240229.1 = Santosh Singh = NICORE-1005: Initial Development
240426.1 = Santosh Singh = NICORE-1005: Logic correction to report installements
*/
WITH fi AS (
    SELECT /*+ no_merge materialize */
        id            institution_id,
        branch_code   code,
        name,
        add_info
    FROM
        (
            SELECT
                dwd_institution.branch_code,
                dwd_institution.posting_institution_id,
                dwd_institution.id,
                dwd_institution2.branch_code   branch_code_posting,
                dwd_institution.name,
                dwd_institution.add_info
            FROM
                dwd_institution
                JOIN dwd_institution dwd_institution2 ON dwd_institution.posting_institution_id = dwd_institution2.id
            WHERE
                dwd_institution.record_state = 'A'
        ) inst
    START WITH
        inst.branch_code IN (
            SELECT
                TRIM(regexp_substr(:ORG, '[^,]+', 1, level)) org
            FROM
                dual
            CONNECT BY
                regexp_substr(:ORG, '[^,]+', 1, level) IS NOT NULL
        )
    CONNECT BY DECODE(inst.posting_institution_id, inst.id, NULL, inst.posting_institution_id) = PRIOR inst.id
               AND level <= 2
)
,exid as (
	select /*+no_merge materialize */
	       dca.card_idt,
		   dca.attr_value card_exid
	  from dwa_card_attribute dca
	  join dwd_attribute da
	    on dca.attr_id         = da.id
	 where dca.attr_date_from <= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and dca.attr_date_to   >= TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
	   and da.dimension_code   = 'DWD_CARD'
	   and da.record_source    = 'W4TD_DOMAIN'
	   and da.code             = 'EXID'
	)
,event as (select
             substr(regexp_substr(details,'JSON=[^;]+;',1,1),6) as jsonmess,
             ev.*
 from dwf_card_event ev
 join dwd_event_type et
   on ev.event_type_id = et.id
 and et.code in ('IPP_VIS_TRAN-CANCELLED','IPP_VIS_TRAN-CONFIRMED')
 where ev.activate_date = TO_DATE(:P_REPORT_DATE,'DD-MM-YYYY')
 and sy_convert.get_tag_value(ev.details, 'VIS_RET_CLASS') = 'I' 
 )

SELECT /*+ no_merge */
    fi.code            																	                AS ORG,
    decode(upper(substr(nvl(:RETURN_EXID_CARD,'N'),1,1)),'Y',exid.card_exid, card.pan) 	                AS PAN,
	case when sy_convert.get_tag_value(tr.add_info, 'VIS_CANCEL_REF') is not null then
     'CANCELLED' else
    sy_convert.get_tag_value(et.details, 'TRAN/status')
    end                                                                                                 AS STATUS,
    instl.tenor 																		                AS TENURE, 
	sy_convert.get_tag_value(et.details, 'PLAN/installmentPlan/costInfo/annualPercentageRate')		    AS APR,
    tr.trans_amount                                                                                     AS TOTAL_AMOUNT,
    sy_convert.get_tag_value(et.details, 'PLAN/installmentPlan/costInfo/totalUpfrontFees')/100          AS PROCESSING_FEE,
    sy_convert.get_tag_value(tr.add_info, 'PLAN/installmentPlan/type')					                AS INSTL_TYPE,
	sy_convert.get_tag_value(instl.add_info, 'AH_FEE_VALUE')							                AS BILATERAL_FEE,
	tr.auth_code																		                AS AUTH_CODE,
	tr.trans_arn																		                AS ARN,
	sy_convert.get_tag_value(tr.add_info, 'VIS_TRAN-EVENT_ID') 							                AS PLAN_ID,
	sy_convert.get_tag_value(tr.add_info, 'vPlanAcceptanceID') 							                AS ACCEPTANCEID,
	sy_convert.get_tag_value(tr.add_info, 'PLAN_NR') 								                    AS PLAN_NUMBER,
	tr.TRANS_MCC 																		                AS MERCHANT_ID,
	tr.merchant 																		                AS MERCHANT_DETAIL
FROM
    dwd_instalment instl
    JOIN fi ON instl.institution_id = fi.institution_id  
    JOIN dwd_instl_status insts on  insts.id =  instl.status_id
    JOIN dwd_card card ON card.record_idt = instl.card_idt
                               AND card.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                               AND card.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
    LEFT JOIN exid on exid.card_idt = card.record_idt
    JOIN event et on et.card_idt = instl.CARD_IDT                               
    JOIN dwf_transaction tr ON tr.doc_idt = instl.doc_idt	
                            AND instl.record_date_to >= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
                            AND instl.record_date_from <= TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
        AND sy_convert.get_tag_value(tr.add_info, 'VIS_TRAN-EVENT_ID')  = sy_convert.get_tag_value(et.details, 'VIS_TRAN-EVENT_ID')
WHERE
       tr.banking_date = TO_DATE(:P_REPORT_DATE, 'DD-MM-YYYY')
      AND sy_convert.get_tag_value(tr.add_info, 'INST_VER') = 'VISA_INST'
      AND nvl(insts.code,1) <> 'Z'