__version__ = "240626.1"
__job_name__ = "PyTL_OmniReports_QMR"
__bat_files__ = ["PyTL_OmniReports_QMR.bat"]
