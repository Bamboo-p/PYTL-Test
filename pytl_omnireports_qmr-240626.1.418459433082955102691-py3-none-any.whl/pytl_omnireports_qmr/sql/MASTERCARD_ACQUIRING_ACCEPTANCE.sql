/* PyTL_OmniReports_QMR/MASTERCARD_ACCEPTANCE.sql
230124.1 = AhmedG  = NICORE-133: Initial development
230329.1 = deniska = NOPE-161: Added more one worksheet with this query
231215.1 = maksimsk = NIINT-4196: added new fields name_2, name_3 for supporting new metric
*/
SELECT
     org,
     name,
     name_1,
     name_2,
     name_3
 FROM
     dwh.opt_mc_qmr_acq_accept
 WHERE
     org = :ORG
 ORDER BY
     r_order
