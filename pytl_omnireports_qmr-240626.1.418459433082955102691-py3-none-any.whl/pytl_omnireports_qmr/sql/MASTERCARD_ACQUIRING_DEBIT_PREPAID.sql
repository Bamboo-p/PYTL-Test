/* PyTL_OmniReports_QMR/MASTERCARD_ACQUIRING_DEBIT_PREPAID.sql
230124.1 = AhmedG  = NICORE-133: Initial development
230311.2 = deniska = NICORE-133: Adoptation for PyTL_OmniReports_QMR
230329.1 = deniska = NOPE-161: added schema name
*/
SELECT
     inst.code AS org,
     d.product_name,
     d.name,
     d.name_1,
     d.name_2,
     d.currency
 FROM
     dwh.opt_mc_qmr_acq_data d
     JOIN dwh.dwd_institution inst ON to_number(inst.code) = d.org
                                  AND inst.code = :ORG
                                  AND inst.record_state = 'A'
                                  AND d.product_name IS NOT NULL
                                  AND d.r_order IS NOT NULL
 WHERE
     d.product_name IN (
         'Acquiring Debit',
         'Acquiring Prepaid'
     )
 ORDER BY
     d.currency,
     d.product_name,
     d.r_order,
     d.name