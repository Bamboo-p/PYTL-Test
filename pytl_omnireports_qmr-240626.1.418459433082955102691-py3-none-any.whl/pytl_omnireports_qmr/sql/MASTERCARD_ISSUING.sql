/* PyTL_OmniReports_QMR/MASTERCARD_ISSUING.sql
230124.1 = AhmedG  = NICORE-133: Initial development
230311.2 = deniska = NICORE-133: Adoptation for PyTL_OmniReports_QMR
230329.1 = deniska = NOPE-161: added schema name
230414.1 = robbyda = NOPE-183: add order by currency for multiple currency result
*/
SELECT
    inst.code AS org,
    inst.name AS inst_name,
    replace(
        trim(
            replace(
                replace(
                    replace(
                        'MC ' || trim(nvl(d.PRODUCT_NAME, '')),
                        'MASTERCARD',
                        ''
                    ),
                    ' CARD',
                    ''
                ),
                '  ',
                ' '
            )
        ),    
        ' ',
        '_'
    )
    as PRODUCT_NAME,
--    d.PRODUCT_NAME,
    d.R_ORDER,
    d.NAME,
    d.NAME_1,
    d.NAME_2,
    d.NAME_3,
    d.CURRENCY
FROM
     dwh.opt_mc_qmr_iss_data d
     JOIN dwh.dwd_institution inst ON to_number(inst.code) = d.org
                                  AND inst.code = :ORG
                                  AND inst.record_state = 'A'
                                  AND d.product_name IS NOT NULL
                                  AND d.r_order IS NOT NULL
ORDER BY
     inst.name,
     d.product_name,
     d.currency,
     d.r_order,
     d.name
