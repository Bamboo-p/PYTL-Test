/* PyTL_OmniReports_QMR/VISA_ACQUIRING.sql
230124.1 = AhmedG  = NICORE-133: Initial development
230311.2 = deniska = NICORE-133: Adoptation for PyTL_OmniReports_QMR
230329.1 = deniska = NOPE-161: added schema name
240626.1 = mohda = NIINT-5378: splitting the amount based on Credit, Debit, Prepaid as per Visa new requirements
*/

SELECT
     inst.code AS org,
     d.R_ORDER, d.PRODUCT_LOCAL_NAME AS "Metric Type", d.AMOUNT AS "Acceptance Information", d.CREDIT, d.DEBIT, d.PREPAID, d.CURRENCY

 FROM 
 	 dwh.opt_visa_qmr_acq_data d
     JOIN dwh.dwd_institution inst ON to_number(inst.code) = d.org
                                   AND inst.code = :ORG
                                   AND inst.record_state = 'A'
                                   AND d.r_order IS NOT NULL

 ORDER BY
  d.currency,
  d.r_order
