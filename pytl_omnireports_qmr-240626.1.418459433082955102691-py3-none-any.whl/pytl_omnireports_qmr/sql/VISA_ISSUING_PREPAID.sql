/* PyTL_OmniReports_QMR/VISA_ISSUING_PREPAID.sql
230124.1 = AhmedG  = NICORE-133: Initial development
230311.2 = deniska = NICORE-133: Adoptation for PyTL_OmniReports_QMR
*/
SELECT
     inst.code AS org,
     d.*
 FROM
     dwh.visa_qmr_data_issprepaid d
     JOIN dwh.dwd_institution inst ON to_number(inst.code) = d.org
                                    AND inst.code = :ORG
                                    AND inst.record_state = 'A'
                                    -- AND d.r_order IS NOT NULL
 ORDER BY
     d.currency,
     d.r_order
