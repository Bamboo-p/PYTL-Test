/*
TIQMO_TRANSACTIONS.sql
06-05-2022 : OPKSAIC-3120 : Bharath : Initial version : Tiqmo Transactions
230125.1 : NIINT-2986 : Santosh : Added logic for product_type
240227.1 : NICORE-1215 : Shalini : Renaming of job and sql
*/
with inst as(
    select /*+ no_merge materialize */
          id,
          bank_code code,
          name
    from (select fi.bank_code,
                 fi.posting_in,
                 fi.id,
                 fi2.bank_code bank_code_posting,
                 fi.name
            from ows.f_i fi
            join ows.f_i fi2
              on fi.posting_in  = fi2.id
           where fi.amnd_state  = 'A'
             and fi2.amnd_state = 'A'
         ) inst
  start with inst.bank_code in (select trim(regexp_substr(:ORGLIST, '[^,]+', 1, level)) org
                                  from dual
                                  connect by regexp_substr(:ORGLIST, '[^,]+', 1, level) is not null
                                  )
  connect by decode(inst.posting_in, inst.id, null, inst.posting_in) = prior inst.id and level <= 2
    ),
m_dates as (
    select /*+no_merge materialize*/
           add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1)+1 as min_date,
           to_date(:P_REPORT_DATE,'DD-MM-YYYY') as max_date,
           trim(to_char(add_months(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),-1)+1,'ddth Month'))||' to '||
           trim(to_char(to_date(:P_REPORT_DATE,'DD-MM-YYYY'),'ddth Month')) as rep_Date
      from dual
    ),
cards as (
    select /*+ no_merge materialize */
          c.id,
          c.contract_number,
          i.code as institution,
          i.name as institution_name,
          decode(nvl(ows.sy_convert.get_tag_value(p.custom_data,'PR_GROUP_REP'),p.product_group),
          'ISSCREDIT','CREDIT','ISSDEB','DEBIT','ISSPREPAID','PREPAID','CREDIT') as category_code
          ,p.contract_role -- [+] 230125.1 : NIINT-2986 : Santosh : Added logic for product_type
     from ows.acnt_contract c
     join inst i
       on i.id         = c.f_i
     join ows.appl_product p
       on c.product    = p.internal_code
      and p.amnd_state = 'A'
    where c.amnd_state = 'A'
    ),
transactions as (
    select /*+ no_merge materialize */
          dd.rep_Date,
          d.target_number,
          d.source_number,
          d.amnd_date,
          d.trans_type,
          t.name,
          t.production_event,
          t.dr_Cr,
          c.institution,
          c.institution_name,
          c.category_code,
          case when production_event is not null then production_event
                when dr_cr = -1 then 'Debit' else 'Credit' end as transaction_type,
          decode(d.posting_status,'J','DECLINED','APPROVED') as tran_type,
          d.trans_amount
         ,decode(c.contract_role,'CORP','Commercial','Consumer')  as Product_type-- [+] 230125.1 : NIINT-2986 : Santosh : Added logic for product_type
     from ows.doc d
     join m_dates dd
       on trunc(d.amnd_date) between dd.min_date and dd.max_date
     join ows.trans_type t
       on d.trans_type        = t.id
      and t.amnd_state        = 'A'
     join cards c
       on c.contract_number   = nvl(d.target_number,d.source_number)
    )

    select institution      as org,
           rep_date,
           institution_name as Institution_Name,
           'WAY4'           as source_system,
           substr(ltrim(nvl(target_number,source_number),'0'),1,6) as bin,
           category_code    as category_of_transaction,
           transaction_type as type_of_transaction,
           '00'             as tran_code,
           name             as tran_Code_desc,
           tran_type,
           count(1) as tran_cnt,
           sum(trans_amount) as amt,
           'Y' as billable_nonbillable,
           Product_type -- [+] 230125.1 : NIINT-2986 : Santosh : Added logic for product_type
      from transactions t
  group by institution,
           rep_date,
           institution_name,
           substr(ltrim(nvl(target_number,source_number),'0'),1,6),
           category_code,
           transaction_type,
           name,
           tran_type,
           Product_type -- [+] 230125.1 : NIINT-2986 : Santosh : Added logic for product_type
