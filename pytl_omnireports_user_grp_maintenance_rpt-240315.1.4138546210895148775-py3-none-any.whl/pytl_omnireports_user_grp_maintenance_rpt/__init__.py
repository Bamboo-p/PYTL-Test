__version__ = "240315.1"
__job_name__ = "PyTL_OmniReports_USER_GRP_MAINTENANCE_RPT"
__bat_files__ = []
