/*
* PyTL_OmniReports_USER_GRP_MAINTENANCE_RPT = USER_GRP_MAINTENANCE_RPT.sql
* Parameters:
    ORGLIST            = '033,010,017,016'
    P_REPORT_DATE      = 'DD-MM-YYYY'
	P_USER_GROUP_LIST  = 'NI.NI AFU MAKER,NI.NI AFU CHECKER'
* VERSION HISTORY:
* 240122.1: RakeshG: NIINT-4312: Initial Version
* 240207.1: RakeshG: NIINT-4616: Added missed classifier
*/
WITH orglist AS (
           SELECT /*+ no_merge materialize*/
                  TRIM(regexp_substr(:ORGLIST, '[^,]+', 1, level)) bank_code
             FROM dual
       CONNECT BY regexp_substr(:ORGLIST, '[^,]+', 1, level) IS NOT NULL
),
user_groups_code as (
           SELECT /*+ no_merge materialize*/
                  TRIM(regexp_substr(:P_USER_GROUP_LIST, '[^,]+', 1, level)) group_code
             FROM dual
       CONNECT BY regexp_substr(:P_USER_GROUP_LIST, '[^,]+', 1, level) IS NOT NULL
),
inst as (
    select /*+ materialize */
           fi.*
      from ows.f_i fi
      join orglist o on o.bank_code = fi.bank_code
     where fi.amnd_state = 'A'
),
user_group as (
      select /*+ materialize */
             o.id,
             o.name,
			 o.user_id,
             og.name as group_name
        from ows.officer_group og
        join ows.officer o on o.officer_group__oid = og.id
         and o.amnd_state = 'A'
        join user_groups_code ugc on ugc.group_code = og.code
       where og.amnd_state ='A'
)
,upd_acnt AS (
    SELECT /*+ materialize ordered use_nl_with_index(aa,CONTRACT_CAT)*/
            aa.amnd_prev,
            aa.amnd_date,
            aa.contract_number,
            aa.con_cat
      FROM inst
      join ows.acnt_contract aa ON inst.id = aa.f_i
       AND aa.amnd_state = 'A'
       AND aa.amnd_date >= TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy')
       AND aa.amnd_date <  TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy') + 1
      join user_group ug on ug.id = aa.amnd_officer
)
,upd_clnt AS (
SELECT /*+ materialize ordered use_nl_with_index(aa,CONTRACT_CAT)*/
            aa.amnd_prev,
            aa.amnd_date,
            aa.client_number
      FROM inst
      join ows.client aa ON inst.id = aa.f_i
       AND aa.amnd_state = 'A'
       AND aa.amnd_date >= TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy')
       AND aa.amnd_date <  TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy') + 1
)
,cntr as (
       select /*+ materialize */  
                ac.id
              , ac.product
              , ac.date_open
              , ac.contract_number
              , inst.bank_code
              , ac.f_i
			  , ac.LIAB_CATEGORY
         from inst
         join ows.acnt_contract ac on ac.f_i = inst.id
          and ac.amnd_state = 'A'
          and ac.date_open <= TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy')
)
,ap as (
     select /*+ materialize */
            ap.internal_code
          , ap.code
          , inst.bank_code
       from inst
       join ows.appl_product ap on ap.amnd_state = 'A'
        and ap.f_i = inst.id
),
cs as (
    select /*+ materialize */
              cs.id
            , cs.con_cat
            , cs.name 
         from ows.contr_status cs 
        where cs.amnd_state = 'A'
),
ct as (
    select /*+ materialize */
              ct.id
            , ct.name
       from ows.client_title ct 
      where ct.amnd_state = 'A'
)
,a1 AS (
    SELECT /*+ materialize */
              DECODE(a0.amnd_state, 'A', 9999999999, a0.id) row_id,
              a0.*,
              ct.name ct_tr_title,
              cs.name contr_status_desc,
              ows.opt_reports.get_product_name(a0.id) product_desc,
              ows.opt_reports.get_logo(ap.code) logo,
              inst.bank_code
       FROM upd_acnt
       join ows.acnt_contract a0 ON a0.amnd_prev = upd_acnt.amnd_prev
       join inst on inst.id = a0.f_i
       JOIN ap ON ap.internal_code = a0.product
  LEFT JOIN cs ON cs.id = a0.contr_status
        AND cs.con_cat = a0.con_cat
  LEFT JOIN ct ON a0.tr_title = ct.id
)
,ac AS (
     SELECT /*+ materialize */
            ROW_NUMBER() OVER(PARTITION BY a1.amnd_prev ORDER BY a1.amnd_date DESC, a1.row_id DESC) AS rn,
            a1.*
       FROM a1
   ORDER BY a1.amnd_prev,
            a1.amnd_date DESC,
            a1.row_id DESC
),
appl_list as (
    select /*+ no_merge parallel(appl)*/
         inst.bank_code as bc,
         appl.*
    from ows.adv_appl appl
    join inst on inst.id = appl.f_i
   where appl.amnd_state = 'A'
     and appl.amnd_date >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
     and appl.amnd_date < to_Date(:P_REPORT_DATE,'DD-MM-YYYY') + 1
     and upper(appl.objecT_for) = 'CONTRACT'
     and upper(appl.wf_stage)   = 'CLOSE'
),
main_sql as (
    select /*+ no_merge leading(appl_list)*/
           appl_list.bc as bank_code,
           acnt.contract_number ,
           ows.opt_reports.get_logo(prd.code) as logo,
           act.date_to            as   new_value,
           appl_list.posting_Date as old_value,
           (select /*+ no_parallel(a) */ max(a.amnd_officer) from ows.adv_appl a where a.id = appl_list.main_application and a.amnd_state = 'A') as amnd_officer,
           appl_list.amnd_date,
           'ACCOUNT' grp
      from appl_list
      join ows.appl_action act
        on act.adv_appl__oid = appl_list.id
       and nvl(instr(appl_list.private_data,'TEMP_CR_LIM_STR'),0) > 0
      join ows.acnt_contract acnt 
        on acnt.amnd_state = 'A'
       and acnt.id = appl_list.objecT_for_id 
      join ows.appl_product prd on prd.internal_code = acnt.product
       and prd.amnd_state = 'A'
),
Cr_limit as (
        select /*+ no_merge leading(appl) use_hash(appl ch) */
        ch.acnt_contract__oid as contract_id,
        ows.opt_reports.get_logo(prd.code) as logo,
        acnt.contract_number as contract_number,
        ch.trans_amount as new_value,
        lead(ch.trans_amount) over(partition by ch.acnt_contract__oid order by ch.posting_date desc) as old_value,
        row_number() over(partition by ch.acnt_contract__oid order by ch.posting_date desc) as rn,
        appl.id as appl_id,
        appl.wf_object_id,
        ug.name as amnd_officer,
        ug.group_name,
        appl.amnd_date,
        appl.bc as bank_code,
        'ACCOUNT' grp
        from appl_list appl 
        join ows.credit_history ch on ch.service_class = 'P'
         and ch.acnt_contract__oid = appl.object_for_id
         and appl.object_type = 'Limit'
--         and appl.creation_type = 'IMPORT'
        join ows.acnt_contract acnt on acnt.amnd_state = 'A'
         and acnt.id = ch.acnt_contract__oid 
        join ows.appl_product prd on prd.internal_code = acnt.product
         and prd.amnd_state = 'A'
        join user_group ug on ug.id = appl.amnd_officer
) 
,cst as (
select /*+ materialize */
               cst.id
             , cst.code
             , cst.name
        from inst
             join ows.cs_status_type cst ON cst.amnd_state = 'A'

                                            and (cst.code LIKE 'BC_AC_DEC_M_'
                                                 || inst.bank_code
                                                 || '_CPY'   /*16.3*/
                                                 OR cst.code LIKE 'BCODE-A1-' || inst.bank_code   /*16.5*/
                                                 OR cst.code LIKE 'BCODE-A2-' || inst.bank_code   /*16.5*/
                                                 OR cst.code LIKE 'CONTR_STATUS' /*16.3/16.5*/
                                                 OR cst.code LIKE 'BFA_ACCOUNT_STATUS' /*16.5*/
                                                 OR cst.code LIKE 'ACTIVITY_STATUS'  /*16.3 Only in  Account*/
                                                 OR cst.code LIKE 'AMF_WAIVE_ACC'
                                                 OR cst.code LIKE 'INTEREST_WAIVE_PE'
                                                 OR cst.code LIKE 'LPF_WAIVE_PE'
                                                 OR cst.code LIKE 'NSF_WAIVE_PE'
                                                 OR cst.code LIKE 'OVL_WAIVE_PE'
                                                 OR cst.code LIKE 'STMT_FEE_WAIVE_PERS'
                                                 OR cst.code LIKE 'CARD_TARIFF'
                                                 OR cst.code LIKE 'INS_ENROLMENT-01'
                                                 OR cst.code LIKE 'INS_ENROLMENT-02'
                                                 OR cst.code LIKE 'INS_ENROLMENT-03'
                                                 OR cst.code LIKE 'INS_ENROLMENT-04'
                                                 OR cst.code LIKE 'INS_ENROLMENT-05'
                                                 OR cst.code LIKE 'INS_ENROLMENT-06'
                                                 OR cst.code LIKE 'STMT_FLAG_PE'
                                                 OR cst.code LIKE 'FINANCE_CHARGES_PE'
                                                 OR cst.code LIKE 'JF_ACC_WAIVE_PE'
                                                 OR cst.code LIKE 'AMF_WAIVE_PE'
                                                 OR cst.code LIKE 'INS_WAIVE_PE'
                                                 OR cst.code LIKE 'STMT_FEE_WAIVE_PE'
                                                 OR cst.code LIKE 'MMF_WAIVE_PE'
                                                 OR cst.code LIKE 'RE_ORDER_WAIVE_PE'
                                                 OR cst.code LIKE 'RE_ISSUE_WAIVE_PE'
                                                 OR cst.code LIKE 'MMF_WAIVE_CARD_PE'
                                                 OR cst.code LIKE 'AMF_WAIVE_CARD_PE' 
                                                 OR cst.code LIKE 'BCFEAT-SCF'
                                                 OR cst.code LIKE 'RBP_FLAG'
                                                 OR cst.code like 'BILLING_DAY'
                                                 OR cst.code LIKE 'PAYMENT_HOLIDAY'
												 OR cst.code like 'CRLIM_MAX_IGNORE_PE'
												 OR cst.code like 'DIRECT_DEBIT'
                                                 OR cst.code LIKE 'LTY_ENROLMENT'
                                                 OR cst.code LIKE 'MMF_WAIVE_ACC'
												 OR cst.code LIKE 'PLASTIC_STATUS'
                                                  )
)
,
csv as (select /*+ materialize */
               csv.id
             , csv.cs_status_type__oid
             , csv.name
             , csv.code
          from ows.cs_status_value csv 
         where csv.amnd_state = 'A'
)
,cl as (
select /*+ materialize ordered */
              cl.acnt_contract__oid
                  , cl.status_date
                  , cst.name cst_name
                  , cst.code cst_code
                  , ug.name amnd_officer
                  , ug.group_name
                  , csv_n.code csv_n_code
                  , csv_n.name csv_n_name
				  , csv_o.code csv_o_code
                  , csv_o.name csv_o_name 
                  , case when csv_o.id is not null then 'Y'
                         when cst.code = 'BILLING_DAY' and c.liab_category = 'Y' and c.date_open < TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy') and csv_o.id is null	then 'Y'
                    else 'N' end Extract_in_report
       from ows.cs_status_log cl
	   JOIN cntr c on c.id = cl.acnt_contract__oid
       JOIN cst ON cst.id = cl.status_type
  left JOIN csv csv_o ON csv_o.id = cl.status_value_prev
        AND cst.id = csv_o.cs_status_type__oid
       JOIN csv csv_n ON csv_n.id = cl.status_value
        AND cst.id = csv_n.cs_status_type__oid
       JOIN user_group ug on ug.id = cl.officer
      where cl.status_date >= TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy')
        AND cl.status_date < TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy') + 1
        AND nvl(instr(cl.descript,'STORNOED;'),0) = 0 /*ADCB-6433 */
)
,t_ca AS (
    SELECT /*+ NO_MERGE */
           ca.amnd_prev
      FROM ows.client c
      JOIN inst ON inst.id = c.f_i
      JOIN ows.client_address ca ON c.id = ca.client__oid
      JOIN user_group ug on ug.id = c.amnd_officer
     WHERE ca.amnd_date >= trunc(TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy'))
       AND ca.amnd_date < trunc(TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy')) + 1
)
,main_appl_info as (
    select 
           decode(ai.amnd_state, 'A', 99999999999, ai.id) row_id,
           ai.*
          ,ac.contract_number
          ,ac.product
      from ows.appl_info ai 
      join cntr ac on ai.acnt_contract__oid = ac.id 
      join inst  ON inst.id = ac.f_i
     where ai.add_info_type like 'ACC_APPR_INFO'
  order by ai.amnd_prev,ai.amnd_date desc
)
,t_appl_info as (
            select
            *
            from
            (                
                select /*+ materialize */
                api.amnd_date,
                api.amnd_officer,
                api.contract_number,
                api.product,
                to_char(api.amnd_date, 'DDMMYY HH24MISS') amnd_date_stamp,
                case when api.add_info_type = 'ACC_APPR_INFO' then api.add_info_06 else null end as  sourcecoden,
                case when api.add_info_type = 'ACC_APPR_INFO' then lag(api.add_info_06) over(partition by api.amnd_prev order by api.amnd_date, api.row_id ) else null end as sourcecodeo,
                'ACCOUNT' grp
                from main_appl_info api
            )
            unpivot (( changed_from, changed_to )for field_description in (( sourcecodeo, sourcecoden) as 'SOURCE_CODE' ))
            where amnd_date >= to_date(:P_REPORT_DATE,'DD-MM-YYYY')
            and amnd_date < to_date(:P_REPORT_DATE,'DD-MM-YYYY') + 1
)
,crs as (
        select ap.bank_code,
               ows.opt_reports.get_logo(ap.code) logo,
               tai.contract_number, 
               ug.name amnd_officer,
               tai.amnd_date_stamp, 
               tai.field_description, 
               tai.changed_from, 
               tai.changed_to, 
               tai.grp,
               ug.group_name
          from t_appl_info tai
          JOIN user_group ug on ug.id = tai.amnd_officer
          JOIN ap ON ap.internal_code = tai.product
)
,clnt as (
SELECT /*+ materialize */
              diff.bank_code,
              diff.logo,
              diff.client_number AS contract_number,
              diff.field_description,
              to_char(diff.changed_from) as changed_from,
              to_char(diff.changed_to) as changed_to,
              diff.amnd_date  AS amnd_date_stamp,
              o.name  AS amnd_officer,
              diff.amnd_prev,
              'CLIENT' grp,
              o.group_name
        FROM (SELECT ps.*
              FROM (
              
                SELECT
                       LEAD(ac.amnd_prev) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS is_first,
                       ac.amnd_date,
                       ac.amnd_state,
                       ac.amnd_prev,
                       ac.amnd_officer,
                       ac.f_i,
                       inst.bank_code,
                       ac.client_number,
					   null as logo,
                       TO_CHAR(ac.SHORT_NAME) as short_namen, 
                       TO_CHAR(ac.FIRST_NAM) as FIRST_NAMn, 
                       TO_CHAR(ac.LAST_NAM) as LAST_NAMn, 
                       TO_CHAR(ac.FATHER_S_NAM) as FATHER_S_NAMn, 
                       TO_CHAR(ac.BIRTH_NAM) as BIRTH_NAMn, 
                       TO_CHAR(ac.MOTHER_S_NAM) as MOTHER_S_NAMn, 
                       TO_CHAR(ac.BIRTH_DATE) as BIRTH_DATEn,
                       TO_CHAR(ac.BIRTH_PLACE) as BIRTH_PLACEn, 
                       TO_CHAR(ac.GENDER) as GENDERn, 
                       TO_CHAR(ac.MARITAL_STATUS) as MARITAL_STATUSn, 
                       TO_CHAR(ac.COMPANY_NAM) as COMPANY_NAMn, 
                       TO_CHAR(ac.REG_NUMBER) as REG_NUMBERn, 
                       TO_CHAR(ac.REG_DETAILS) as REG_DETAILSn, 
                       TO_CHAR(ac.PROFESSION) as PROFESSIONn, 
                       TO_CHAR(ac.CITIZENSHIP) as CITIZENSHIPn, 
                       TO_CHAR(ac.COUNTRY) as COUNTRYn, 
                       TO_CHAR(ac.ADDRESS_ZIP) as ADDRESS_ZIPn, 
                       TO_CHAR(ac.STATE) as STATEn, 
                       TO_CHAR(ac.CITY) as cityn, 
                       TO_CHAR(ac.ADDRESS_LINE_1) as ADDRESS_LINE_1n, 
                       TO_CHAR(ac.ADDRESS_LINE_2) as ADDRESS_LINE_2n, 
                       TO_CHAR(ac.ADDRESS_LINE_3) as ADDRESS_LINE_3n, 
                       TO_CHAR(ac.ADDRESS_LINE_4) as ADDRESS_LINE_4n,
                       				   
/* *********************************************************Add_Info*********************************************************** */

                       regexp_substr(ac.add_info_02, '(MEMO_1+)=([^;]+);', 1, 1, '', 10) memo_1n,
					   regexp_substr(ac.add_info_02, '(MEMO_2+)=([^;]+);', 1, 1, '', 10) memo_2n,
                                              
                       LEAD(TO_CHAR(ac.SHORT_NAME)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS short_nameo,
                       LEAD(TO_CHAR(ac.FIRST_NAM)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS FIRST_NAMo, 
                       LEAD(TO_CHAR(ac.LAST_NAM)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS LAST_NAMo, 
                       LEAD(TO_CHAR(ac.FATHER_S_NAM)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS FATHER_S_NAMo, 
                       LEAD(TO_CHAR(ac.BIRTH_NAM)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS BIRTH_NAMo, 
                       LEAD(TO_CHAR(ac.MOTHER_S_NAM)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS MOTHER_S_NAMo, 
                       LEAD(TO_CHAR(ac.BIRTH_DATE)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS BIRTH_DATEo,
                       LEAD(TO_CHAR(ac.BIRTH_PLACE)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS BIRTH_PLACEo, 
                       LEAD(TO_CHAR(ac.GENDER)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS GENDERo, 
                       LEAD(TO_CHAR(ac.MARITAL_STATUS)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS MARITAL_STATUSo, 
                       LEAD(TO_CHAR(ac.COMPANY_NAM)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS COMPANY_NAMo, 
                       LEAD(TO_CHAR(ac.REG_NUMBER)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS REG_NUMBERo, 
                       LEAD(TO_CHAR(ac.REG_DETAILS)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS REG_DETAILSo, 
                       LEAD(TO_CHAR(ac.PROFESSION)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS PROFESSIONo, 
                       LEAD(TO_CHAR(ac.CITIZENSHIP)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS CITIZENSHIPo, 
                       LEAD(TO_CHAR(ac.COUNTRY)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS COUNTRYo, 
                       LEAD(TO_CHAR(ac.ADDRESS_ZIP)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS ADDRESS_ZIPo, 
                       LEAD(TO_CHAR(ac.STATE)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS STATEo, 
                       LEAD(TO_CHAR(ac.CITY)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS CITYO, 
                       LEAD(TO_CHAR(ac.ADDRESS_LINE_1)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS ADDRESS_LINE_1o, 
                       LEAD(TO_CHAR(ac.ADDRESS_LINE_2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS ADDRESS_LINE_2o, 
                       LEAD(TO_CHAR(ac.ADDRESS_LINE_3)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS ADDRESS_LINE_3o, 
                       LEAD(TO_CHAR(ac.ADDRESS_LINE_4)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS ADDRESS_LINE_4o,
					  
/* ********************************************************* Add_Info old previous Values *********************************************************** */
					   
                       LEAD(regexp_substr(ac.add_info_02, '(MEMO_1+)=([^;]+);', 1, 1, '', 10)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS MEMO_1O,
                       LEAD(regexp_substr(ac.add_info_02, '(MEMO_2+)=([^;]+);', 1, 1, '', 10)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC) AS MEMO_2O
					   
                    FROM ows.client ac
                    join inst on inst.id = ac.f_i
				WHERE ac.amnd_prev in (select /*+ no_merge materialize */amnd_prev from upd_clnt)
                    ) UNPIVOT ((changed_from, changed_to ) FOR field_description IN
                                      ((short_nameo,short_namen ) AS 'SHORT_NAME', 
                                      (FIRST_NAMo,FIRST_NAMn ) AS 'FIRST_NAME',
                                      (LAST_NAMo,LAST_NAMn) AS 'LAST_NAME',
                                      (FATHER_S_NAMo,FATHER_S_NAMn) AS 'FATHER_S_NAME',
                                      (BIRTH_NAMo,BIRTH_NAMn) AS 'BIRTH_NAME',
                                      (MOTHER_S_NAMo,MOTHER_S_NAMn) AS 'MOTHER_S_NAME',
                                      (BIRTH_DATEo,BIRTH_DATEn) AS 'BIRTH_DATE',
                                      (BIRTH_PLACEo,BIRTH_PLACEn) AS 'BIRTH_PLACE',
                                      (GENDERo,GENDERn) AS 'GENDER',
                                      (MARITAL_STATUSo,MARITAL_STATUSn) AS 'MARITAL_STATUS',
                                      (COMPANY_NAMo,COMPANY_NAMn) AS 'COMPANY_NAME',
                                      (REG_NUMBERo,REG_NUMBERn) AS 'REG_NUMBER',
                                      (REG_DETAILSo,REG_DETAILSn) AS 'REG_DETAILS',
                                      (PROFESSIONo,PROFESSIONn) AS 'PROFESSION',
                                      (CITIZENSHIPo,CITIZENSHIPn) AS 'CITIZENSHIP',
                                      (COUNTRYo,COUNTRYn) AS 'COUNTRY',
                                      (ADDRESS_ZIPo,ADDRESS_ZIPn) AS 'ADDRESS_ZIP',
                                      (STATEo,STATEn) AS 'STATE',
                                      (CITYO,CITYN) AS 'CITY',
                                      (ADDRESS_LINE_1o,ADDRESS_LINE_1n) AS 'ADDRESS_LINE_1',
                                      (ADDRESS_LINE_2o,ADDRESS_LINE_2n) AS 'ADDRESS_LINE_2',
                                      (ADDRESS_LINE_3o,ADDRESS_LINE_3n) AS 'ADDRESS_LINE_3',
                                      (ADDRESS_LINE_4o,ADDRESS_LINE_4n) As 'ADDRESS_LINE_4',
                                      (MEMO_1O,MEMO_1N) AS 'MEMO_1',
                                      (MEMO_2O,MEMO_2N) AS 'MEMO_2'
                                      )
                                      ) ps
                   WHERE ps.amnd_date >= TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy')
                     AND ps.amnd_date < TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy') + 1) diff
                    JOIN user_group o ON o.id = diff.amnd_officer
                   WHERE (nvl(diff.changed_from, '0') <> nvl(diff.changed_to, '0') OR diff.amnd_state = 'C' )
                     AND diff.is_first IS NOT NULL
                ORDER BY f_i,logo,contract_number,amnd_prev,field_description,amnd_date_stamp DESC
)
,ts AS (
        SELECT /*+ materialize */
              diff.bank_code,
              diff.logo,
              diff.contract_number AS contract_number,
              diff.field_description,
              diff.changed_from,
              diff.changed_to,
              diff.amnd_date  AS amnd_date_stamp,
              o.name  AS upd_amnd_officer,
              o.group_name,
              diff.amnd_prev,
              'ACCOUNT' grp
        FROM (SELECT ps.*
              FROM (
              
                SELECT
                       ac.rn,
                       row_id,
                       LEAD(ac.amnd_prev) OVER( PARTITION  BY ac.amnd_prev ORDER BY amnd_date DESC, row_id DESC) AS is_first,
                       ac.amnd_date,
                       ac.amnd_state,
                       ac.amnd_prev,
                       ac.amnd_officer,
                       ac.f_i,
                       ac.bank_code,
                       ac.contract_number,
                       ac.logo,
                       TO_CHAR(ac.pcat) AS pcatn,
                       TO_CHAR(ac.con_cat) AS con_catn,
                       TO_CHAR(ac.terminal_category) AS terminal_categoryn,
                       TO_CHAR(ac.ccat) AS ccatn,
                       TO_CHAR(ac.branch) AS branchn,
                       TO_CHAR(ac.service_group) AS service_groupn,
                       TO_CHAR(ac.contract_number) AS contract_numbern,
                       TO_CHAR(ac.base_relation) AS base_relationn,
                       TO_CHAR(ac.contract_name) AS contract_namen,
                       TO_CHAR(ac.comment_text) AS comment_textn,
                       TO_CHAR(ac.relation_tag) AS relation_tagn,
                       TO_CHAR(ac.contr_type) AS contr_typen,
                       TO_CHAR(ac.old_pack) AS old_packn,
                       TO_CHAR(ac.channel) AS channeln,
                       TO_CHAR(ac.old_scheme) AS old_schemen,
                       TO_CHAR(ac.product_desc) AS productn,
                       TO_CHAR(ac.parent_product) AS parent_productn,
                       TO_CHAR(ac.product_prev) AS product_prevn,
                       TO_CHAR(ac.main_product) AS main_productn,
                       TO_CHAR(ac.liab_category) AS liab_categoryn,
                       TO_CHAR(ac.client_type) AS client_typen,
                       TO_CHAR(ac.liab_contract) AS liab_contractn,
                       TO_CHAR(ac.liab_contract_prev) AS liab_contract_prevn,
                       TO_CHAR(ac.billing_contract) AS billing_contractn,
                       TO_CHAR(ac.behavior_group) AS behavior_groupn,
                       TO_CHAR(ac.behavior_type) AS behavior_typen,
                       TO_CHAR(ac.behavior_type_prev) AS behavior_type_prevn,
                       TO_CHAR(ac.check_available) AS check_availablen,
                       TO_CHAR(ac.check_usage) AS check_usagen,
                       TO_CHAR(ac.curr) AS currn,
                       TO_CHAR(ac.old_curr) AS old_currn,
                       TO_CHAR(ac.date_open) AS date_openn,
                       TO_CHAR(ac.date_expire) AS date_expiren,
                       TO_CHAR(ac.last_scan) AS last_scann,
                       TO_CHAR(ac.card_expire) AS card_expiren,
                       TO_CHAR(ac.production_status) AS production_statusn,
                       TO_CHAR(ac.rbs_member_id) AS rbs_member_idn,
                       TO_CHAR(ac.rbs_number) AS rbs_numbern,
                       TO_CHAR(ac.report_type) AS report_typen,
                       TO_CHAR(ac.max_pin_attempts) AS max_pin_attemptsn,
                       TO_CHAR(ac.pin_attempts) AS pin_attemptsn,
                       TO_CHAR(ac.risk_scheme) AS risk_schemen,
                       TO_CHAR(ac.chip_scheme) AS chip_schemen,
                       TO_CHAR(ac.risk_factor) AS risk_factorn,
                       TO_CHAR(ac.risk_factor_prev) AS risk_factor_prevn,
                       TO_CHAR(ac.contr_status_desc) AS contr_statusn,
                       TO_CHAR(ac.merchant_id) AS merchant_idn,
                       TO_CHAR(ac.ct_tr_title) AS tr_titlen,
                       TO_CHAR(ac.tr_company) AS tr_companyn,
                       TO_CHAR(ac.tr_country) AS tr_countryn,
                       TO_CHAR(ac.tr_first_nam) AS tr_first_namn,
                       TO_CHAR(ac.tr_last_nam) AS tr_last_namn,
                       TO_CHAR(ac.tr_sic) AS tr_sicn,
                       TO_CHAR(ac.client__id) AS client_numbern,
                       TO_CHAR(ac.auth_limit_amount * - 1) AS credit_limitn,
					   
/* *********************************************************Add_Info*********************************************************** */

                       regexp_substr(ac.add_info_01, '(AMBS_DDA_ACNT_NBR+)=([^;]+);', 1, 1, '', 2) ambs_dda_acnt_nbrn,
                       regexp_substr(ac.add_info_01, '(CIVIL_ID+)=([^;]+);', 1, 1, '', 2) civil_idn,
                       regexp_substr(ac.add_info_01, '(CTZ+)=([^;]+);', 1, 1, '', 2) ctzn,
                       regexp_substr(ac.add_info_01, '(INCOME+)=([^;]+);', 1, 1, '', 2) incomen,
                       regexp_substr(ac.add_info_01, '(DOB+)=([^;]+);', 1, 1, '', 2) dobn,
                       regexp_substr(ac.add_info_01, '(REZ+)=([^;]+);', 1, 1, '', 2) rezn,
                       regexp_substr(ac.add_info_01, '(GENDER+)=([^;]+);', 1, 1, '', 2) gendern,
                       regexp_substr(ac.add_info_01, '(MAR_ST+)=([^;]+);', 1, 1, '', 2) mar_stn,
                       regexp_substr(ac.add_info_01, '(AMBS_DDA_ACCT_NBR+)=([^;]+);', 1, 1, '', 2) ambs_dda_acct_nbrn,
                       regexp_substr(ac.add_info_01, '(OFFICER_CODE+)=([^;]+);', 1, 1, '', 2) officer_coden,
                       regexp_substr(ac.add_info_01, '(AMBS_USR_ACCT_NBR+)=([^;]+);', 1, 1, '', 2) ambs_usr_acct_nbrn,
                       regexp_substr(ac.add_info_02, '(AMBS_DDA_ACCT_NBR+)=([^;]+);', 1, 1, '', 2) OriginatingBranchNumbern,
                       regexp_substr(ac.add_info_02, '(MPDPD+)=([^;]+);', 1, 1, '', 2) mpdpdn,
                       regexp_substr(ac.add_info_02, '(CARD_CL_PCNT+)=([^;]+);', 1, 1, '', 2) card_cl_pcntn,
                       regexp_substr(ac.add_info_02, '(MAILING_LIST+)=([^;]+);', 1, 1, '', 2) mailing_listn,
                       regexp_substr(ac.add_info_02, '(HOME_BRANCH+)=([^;]+);', 1, 1, '', 2) home_branchn,
                       regexp_substr(ac.add_info_02, '(PROMO_1+)=([^;]+);', 1, 1, '', 2) promo_1n,
                       regexp_substr(ac.add_info_02, '(PROMO_2+)=([^;]+);', 1, 1, '', 2) promo_2n,
                       regexp_substr(ac.add_info_02, '(PROMO_3+)=([^;]+);', 1, 1, '', 2) promo_3n,
                       regexp_substr(ac.add_info_02, '(SAVING_BRANCH+)=([^;]+);', 1, 1, '', 2) saving_branchn,
                       regexp_substr(ac.add_info_02, '(REF_NUM+)=([^;]+);', 1, 1, '', 2) ref_numn,
                       regexp_substr(ac.add_info_03, '(SELLER_ID+)=([^;]+);', 1, 1, '', 2) seller_idn,
                       regexp_substr(ac.add_info_03, '(ERN+)=([^;]+);', 1, 1, '', 2) ernn,
                       regexp_substr(ac.add_info_04, '(DD_MBR+)=([^;]+);', 1, 1, '', 2) dd_mbrn,
                       regexp_substr(ac.add_info_04, '(DD_NUM+)=([^;]+);', 1, 1, '', 2) dd_numn,
                       regexp_substr(ac.add_info_04, '(DD_DAY+)=([^;]+);', 1, 1, '', 2) dd_dayn,
                       ltrim(regexp_substr(ac.add_info_04, '(DD_PCNT+)=([^;]+);', 1, 1, '', 2),'0') dd_pcntn, 
                                              
                       LEAD(TO_CHAR(ac.client__id)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS client_numbero,
                       LEAD(TO_CHAR(ac.pcat)) OVER(PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS pcato,
                       LEAD(TO_CHAR(ac.con_cat)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS con_cato,
                       LEAD(TO_CHAR(ac.terminal_category)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS terminal_categoryo,
                       LEAD(TO_CHAR(ac.ccat)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS ccato,
                       LEAD(TO_CHAR(ac.branch)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS brancho,
                       LEAD(TO_CHAR(ac.service_group)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS service_groupo,
                       LEAD(TO_CHAR(ac.contract_number)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS contract_numbero,
                       LEAD(TO_CHAR(ac.base_relation)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS base_relationo,
                       LEAD(TO_CHAR(ac.contract_name)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS contract_nameo,
                       LEAD(TO_CHAR(ac.comment_text)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS comment_texto,
                       LEAD(TO_CHAR(ac.relation_tag)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS relation_tago,
                       LEAD(TO_CHAR(ac.contr_type)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS contr_typeo,
                       LEAD(TO_CHAR(ac.old_pack)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS old_packo,
                       LEAD(TO_CHAR(ac.channel)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS channelo,
                       LEAD(TO_CHAR(ac.old_scheme)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS old_schemeo,
                       LEAD(TO_CHAR(ac.product_desc)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS producto,
                       LEAD(TO_CHAR(ac.parent_product)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS parent_producto,
                       LEAD(TO_CHAR(ac.product_prev)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS product_prevo,
                       LEAD(TO_CHAR(ac.main_product)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS main_producto,
                       LEAD(TO_CHAR(ac.liab_category)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS liab_categoryo,
                       LEAD(TO_CHAR(ac.client_type)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS client_typeo,
                       LEAD(TO_CHAR(ac.liab_contract)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS liab_contracto,
                       LEAD(TO_CHAR(ac.liab_contract_prev)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS liab_contract_prevo,
                       LEAD(TO_CHAR(ac.billing_contract)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS billing_contracto,
                       LEAD(TO_CHAR(ac.behavior_group)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS behavior_groupo,
                       LEAD(TO_CHAR(ac.behavior_type)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS behavior_typeo,
                       LEAD(TO_CHAR(ac.behavior_type_prev)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS behavior_type_prevo,
                       LEAD(TO_CHAR(ac.check_available)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS check_availableo,
                       LEAD(TO_CHAR(ac.check_usage)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS check_usageo,
                       LEAD(TO_CHAR(ac.curr)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS curro,
                       LEAD(TO_CHAR(ac.old_curr)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS old_curro,
                       LEAD(TO_CHAR(ac.date_open)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS date_openo,
                       LEAD(TO_CHAR(ac.date_expire)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS date_expireo,
                       LEAD(TO_CHAR(ac.card_expire)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS card_expireo,
                       LEAD(TO_CHAR(ac.production_status)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS production_statuso,
                       LEAD(TO_CHAR(ac.rbs_member_id)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS rbs_member_ido,
                       LEAD(TO_CHAR(ac.rbs_number)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS rbs_numbero,
                       LEAD(TO_CHAR(ac.report_type)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS report_typeo,
                       LEAD(TO_CHAR(ac.max_pin_attempts)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS max_pin_attemptso,
                       LEAD(TO_CHAR(ac.pin_attempts)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS pin_attemptso,
                       LEAD(TO_CHAR(ac.risk_scheme)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS risk_schemeo,
                       LEAD(TO_CHAR(ac.chip_scheme)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS chip_schemeo,
                       LEAD(TO_CHAR(ac.risk_factor)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS risk_factoro,
                       LEAD(TO_CHAR(ac.risk_factor_prev)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS risk_factor_prevo,
                       LEAD(TO_CHAR(ac.contr_status_desc)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS contr_statuso,
                       LEAD(TO_CHAR(ac.merchant_id)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS merchant_ido,
                       LEAD(TO_CHAR(ac.ct_tr_title)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS tr_titleo,
                       LEAD(TO_CHAR(ac.tr_company)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS tr_companyo,
                       LEAD(TO_CHAR(ac.tr_country)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS tr_countryo,
                       LEAD(TO_CHAR(ac.tr_first_nam)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS tr_first_namo,
                       LEAD(TO_CHAR(ac.tr_last_nam)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS tr_last_namo,
                       LEAD(TO_CHAR(ac.tr_sic)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS tr_sico,
                       LEAD(TO_CHAR(ac.auth_limit_amount * - 1)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS credit_limito,
					  
/* ********************************************************* Add_Info old previous Values *********************************************************** */
					   
                       LEAD(regexp_substr(ac.add_info_01, '(AMBS_DDA_ACNT_NBR+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS ambs_dda_acnt_nbro,
                       LEAD(regexp_substr(ac.add_info_01, '(CIVIL_ID+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS civil_ido,
                       LEAD(regexp_substr(ac.add_info_01, '(CTZ+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS ctzo,
                       LEAD(regexp_substr(ac.add_info_01, '(INCOME+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS incomeo,
                       LEAD(regexp_substr(ac.add_info_01, '(DOB+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS dobo,
                       LEAD(regexp_substr(ac.add_info_01, '(REZ+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS rezo,
                       LEAD(regexp_substr(ac.add_info_01, '(GENDER+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS gendero,
                       LEAD(regexp_substr(ac.add_info_01, '(MAR_ST+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS mar_sto,
                       LEAD(regexp_substr(ac.add_info_01, '(AMBS_DDA_ACCT_NBR+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS ambs_dda_acct_nbro,
                       LEAD(regexp_substr(ac.add_info_01, '(OFFICER_CODE+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS officer_codeo,
                       LEAD(regexp_substr(ac.add_info_01, '(AMBS_USR_ACCT_NBR+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS ambs_usr_acct_nbro,
                       LEAD(regexp_substr(ac.add_info_02, '(AMBS_DDA_ACCT_NBR+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS OriginatingBranchNumbero,
                       LEAD(regexp_substr(ac.add_info_02, '(MPDPD+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS mpdpdo,
                       LEAD(regexp_substr(ac.add_info_02, '(CARD_CL_PCNT+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS card_cl_pcnto,
                       LEAD(regexp_substr(ac.add_info_02, '(MAILING_LIST+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS mailing_listo,
                       LEAD(regexp_substr(ac.add_info_02, '(HOME_BRANCH+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS home_brancho,
                       LEAD(regexp_substr(ac.add_info_02, '(PROMO_1+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS promo_1o,
                       LEAD(regexp_substr(ac.add_info_02, '(PROMO_2+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS promo_2o,
                       LEAD(regexp_substr(ac.add_info_02, '(PROMO_3+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS promo_3o,
                       LEAD(regexp_substr(ac.add_info_02, '(SAVING_BRANCH+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS saving_brancho,
                       LEAD(regexp_substr(ac.add_info_02, '(REF_NUM+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS ref_numo,
                       LEAD(regexp_substr(ac.add_info_03, '(SELLER_ID+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS seller_ido,
                       LEAD(regexp_substr(ac.add_info_03, '(ERN+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS erno,
                       LEAD(regexp_substr(ac.add_info_04, '(DD_MBR+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS dd_mbro,
                       LEAD(regexp_substr(ac.add_info_04, '(DD_NUM+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS dd_numo,
                       LEAD(regexp_substr(ac.add_info_04, '(DD_DAY+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC) AS dd_dayo,
                       ltrim(LEAD(regexp_substr(ac.add_info_04, '(DD_PCNT+)=([^;]+);', 1, 1, '', 2)) OVER( PARTITION  BY ac.amnd_prev ORDER BY ac.amnd_date DESC, row_id DESC),'0') AS dd_pcnto
                       
                    FROM ac
                    

                    ) UNPIVOT ((changed_from, changed_to ) FOR field_description IN
                                      (( pcato,pcatn ) AS 'PCAT', 
                                      (con_cato,con_catn ) AS 'CON_CAT', 
                                      (terminal_categoryo, terminal_categoryn ) AS 'TERMINAL_CATEGORY', 
                                      (brancho,   branchn ) AS 'BRANCH', 
                                      (service_groupo,service_groupn) AS 'SERVICE_GROUP' ,
                                      (contract_numbero,contract_numbern) AS 'CONTRACT_NUMBER',
                                      (base_relationo,base_relationn) AS 'BASE_RELATION',
                                      (contract_nameo,contract_namen) AS 'CONTRACT_NAME',
                                      (comment_texto,comment_textn) AS 'COMMENT_TEXT', 
                                      (relation_tago,relation_tagn) AS 'RELATION_TAG',
                                      (old_packo,old_packn) AS 'OLD_PACK', 
                                      (channelo,channeln) AS 'CHANNEL',
                                      (old_schemeo,old_schemen) AS 'OLD_SCHEME', 
                                      (producto,productn) AS 'PRODUCT',
                                      (parent_producto,parent_productn) AS 'PARENT_PRODUCT', 
                                      (liab_categoryo,liab_categoryn) AS 'LIAB_CATEGORY',
                                      (client_typeo,client_typen) AS 'CLIENT_TYPE',
                                      (liab_contracto,liab_contractn) AS 'LIAB_CONTRACT',
                                      (liab_contract_prevo,liab_contract_prevn) AS 'LIAB_CONTRACT_PREV', 
                                      (billing_contracto,billing_contractn) AS 'BILLING_CONTRACT',
                                      (behavior_groupo,behavior_groupn) AS 'BEHAVIOR_GROUP',  
                                      (behavior_typeo,behavior_typen) AS 'BEHAVIOR_TYPE',
                                      (behavior_type_prevo,behavior_type_prevn) AS 'BEHAVIOR_TYPE_PREV', 
                                      (check_availableo,check_availablen) AS 'CHECK_AVAILABLE',
                                      (check_usageo,check_usagen) AS 'CHECK_USAGE', 
                                      (curro,currn) AS 'CURR',
                                      (old_curro,old_currn) AS 'OLD_CURR',
                                      (date_openo,date_openn) AS 'DATE_OPEN',   
                                      (date_expireo,date_expiren) AS 'DATE_EXPIRE', 
                                      (card_expireo,card_expiren) AS 'CARD_EXPIRE', 
                                      (production_statuso,production_statusn) AS 'PRODUCTION_STATUS',   
                                      (rbs_member_ido,rbs_member_idn) AS 'RBS_MEMBER_ID',  
                                      (rbs_numbero,rbs_numbern) AS 'RBS_NUMBER',   
                                      (report_typeo,report_typen) AS 'REPORT_TYPE',   
                                      (max_pin_attemptso,max_pin_attemptsn) AS 'MAX_PIN_ATTEMPTS',  
                                      (pin_attemptso,pin_attemptsn) AS 'PIN_ATTEMPTS',  
                                      (risk_schemeo,risk_schemen) AS 'RISK_SCHEME', 
                                      (chip_schemeo,chip_schemen) AS 'CHIP_SCHEME',   
                                      (risk_factoro,risk_factorn) AS 'RISK_FACTOR',  
                                      (risk_factor_prevo,risk_factor_prevn) AS 'RISK_FACTOR_PREV',
                                      (merchant_ido,merchant_idn) AS 'MERCHANT_ID',
                                      (tr_titleo,tr_titlen) AS 'TR_TITLE',   
                                      (tr_companyo,tr_companyn) AS 'TR_COMPANY',
                                      (tr_countryo,tr_countryn) AS 'TR_COUNTRY',   
                                      (tr_first_namo,tr_first_namn) AS 'TR_FIRST_NAM',   
                                      (tr_last_namo,tr_last_namn) AS 'TR_LAST_NA',  
                                      (tr_sico,tr_sicn) AS 'TR_SIC', 
                                      (credit_limito,credit_limitn) AS 'CREDIT_LIMIT', 
                                      /*Add_Info*/ 
                                      (ambs_dda_acnt_nbro, ambs_dda_acnt_nbrn) AS 'AMBS_DDA_ACNT_NBR',
                                      (civil_ido,  civil_idn) AS 'CIVIL_ID', 
                                      (ctzo, ctzn) AS 'CTZ',
                                      (incomeo, incomen) AS 'INCOME',
                                      (dobo,  dobn) AS 'DOB', 
                                      (ambs_dda_acct_nbro,  ambs_dda_acct_nbrn) AS 'AMBS_DDA_ACCT_NBR', 
                                      (OriginatingBranchNumbero,  OriginatingBranchNumbern) AS 'ORIGINATING BRANCH NUMBER',
                                      (officer_codeo, officer_coden) AS 'OFFICER_CODE',
                                      (ambs_usr_acct_nbro,      ambs_usr_acct_nbrn) AS 'AMBS_USR_ACCT_NBR',   
                                      (mpdpdo,  mpdpdn) AS 'MPDPD', 
                                      (card_cl_pcnto, card_cl_pcntn) AS 'CARD_CL_PCNT',
                                      (mailing_listo,  mailing_listn) AS 'MAILING_LIST', 
                                      (home_brancho,  home_branchn) AS 'HOME_BRANCH', 
                                      (ref_numo, ref_numn) AS 'REF_NUM',
                                      (seller_ido,  seller_idn) AS 'SELLER_ID', 
                                      (erno,  ernn) AS 'ERN',
                                      (dd_mbro,  dd_mbrn) AS 'DD_MBR', 
                                      (dd_numo,   dd_numn) AS 'DD_NUM',
                                      (dd_dayo,  dd_dayn) AS 'DD_DAY', 
                                      (dd_pcnto,   dd_pcntn) AS 'DD_PCNT',
                                      (client_numbero,client_numbern) AS 'CLIENT_NUMBER',
                                      (promo_1o,  promo_1n) AS 'PROMO_1', 
                                      (promo_2o,  promo_2n) AS 'PROMO_2', 
                                      (promo_3o,  promo_3n) AS 'PROMO_3',
                                      (saving_brancho,  saving_branchn) AS 'SAVING_BRANCH'                                        
                                      )
                                      ) ps
                   WHERE ps.amnd_date >= TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy')
                     AND ps.amnd_date < TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy') + 1) diff
                    JOIN user_group o ON o.id = diff.amnd_officer
                   WHERE (nvl(diff.changed_from, '0') <> nvl(diff.changed_to, '0') OR diff.amnd_state = 'C' )
                     AND diff.is_first IS NOT NULL
                ORDER BY f_i,logo,contract_number,amnd_prev,field_description,amnd_date_stamp DESC
)
,cls_q AS (
    SELECT /*+ materialize*/
                ac.bank_code,
                 ows.opt_reports.get_logo(ap.code) logo,
                 ac.contract_number,
                 CASE
                   WHEN cl.cst_code LIKE 'BC_AC_DEC_M-'
                   || ac.bank_code
                   || '-CPY' THEN 'BLOCK-CODE ACCOUNT'
                   WHEN cl.cst_code LIKE 'BCODE-A1-' || ac.bank_code THEN 'BLOCK-CODE 1'
                   WHEN cl.cst_code LIKE 'BCODE-A2-' || ac.bank_code THEN 'BLOCK-CODE 2'
                   WHEN cl.cst_code LIKE 'BCFEAT-SCF'                THEN 'SCHEME CORPORATE FILE'
                   ELSE upper(cl.cst_name)
                 END field_description,
                 CASE
                   WHEN ( cl.cst_code LIKE 'CONTR_STATUS'
                          OR cl.cst_code LIKE 'ACTIVITY_STATUS'
                          OR cl.cst_code LIKE 'BFA_ACCOUNT_STATUS'
                          OR cl.cst_code LIKE 'AMF_WAIVE_ACC'
                          OR cl.cst_code LIKE 'INTEREST_WAIVE_PE'
                          OR cl.cst_code LIKE 'LPF_WAIVE_PE'
                          OR cl.cst_code LIKE 'NSF_WAIVE_PE'
                          OR cl.cst_code LIKE 'OVL_WAIVE_PE'
                          OR cl.cst_code LIKE 'STMT_FEE_WAIVE_PERS'
                          OR cl.cst_code LIKE 'CARD_TARIFF'
                          OR cl.cst_code LIKE 'INS_ENROLMENT-01'
                          OR cl.cst_code LIKE 'INS_ENROLMENT-02'
                          OR cl.cst_code LIKE 'INS_ENROLMENT-03'
                          OR cl.cst_code LIKE 'INS_ENROLMENT-04'
                          OR cl.cst_code LIKE 'INS_ENROLMENT-05'
                          OR cl.cst_code LIKE 'INS_ENROLMENT-06'
                          OR cl.cst_code LIKE 'FINANCE_CHARGES_PE'
                          OR cl.cst_code LIKE 'JF_ACC_WAIVE_PE'
                          OR cl.cst_code LIKE 'AMF_WAIVE_PE'
                          OR cl.cst_code LIKE 'INS_WAIVE_PE'
                          OR cl.cst_code LIKE 'STMT_FEE_WAIVE_PE'
                          OR cl.cst_code LIKE 'MMF_WAIVE_PE'
                          OR cl.cst_code LIKE 'RE_ORDER_WAIVE_PE'
                          OR cl.cst_code LIKE 'RE_ISSUE_WAIVE_PE'
                          OR cl.cst_code LIKE 'MMF_WAIVE_CARD_PE'
                          OR cl.cst_code LIKE 'AMF_WAIVE_CARD_PE'
                          OR cl.cst_code LIKE 'RBP_FLAG'                              
                          OR cl.cst_code LIKE 'CRLIM_MAX_IGNORE_PE'
                          OR cl.cst_code LIKE 'PAYMENT_HOLIDAY'
						  OR cl.cst_code LIKE 'DIRECT_DEBIT'
                          OR cl.cst_code LIKE 'LTY_ENROLMENT'
                          OR cl.cst_code LIKE 'MMF_WAIVE_ACC'
                          OR cl.cst_code LIKE 'PLASTIC_STATUS') THEN cl.csv_o_name
                   WHEN( cl.cst_code LIKE 'BCODE-A1-' || ac.bank_code
                           OR cl.cst_code LIKE 'BCODE-A2-' || ac.bank_code
                           OR cl.cst_code LIKE 'BC_AC_DEC_M_' || ac.bank_code || '_CPY'
                           OR cl.cst_code LIKE 'BCFEAT-SCF'
                           or cl.cst_code like 'BILLING_DAY') 
                   THEN DECODE(TO_CHAR(cl.csv_o_code), '_', NULL, cl.csv_o_code)
                   WHEN  (cl.cst_code LIKE 'STMT_FLAG_PE' ) 
				   THEN DECODE(TO_CHAR(cl.csv_o_code), 'E', 'O', 'O', 'H', 'B', ' ', cl.csv_o_code)
                   ELSE DECODE(TO_CHAR(cl.csv_o_code), '_', NULL, cl.csv_o_code) 
                   END changed_from,
                 CASE WHEN (    cl.cst_code LIKE 'CONTR_STATUS'
                             OR cl.cst_code LIKE 'ACTIVITY_STATUS'
                             OR cl.cst_code LIKE 'BFA_ACCOUNT_STATUS'
                             OR cl.cst_code LIKE 'AMF_WAIVE_ACC'
                             OR cl.cst_code LIKE 'INTEREST_WAIVE_PE'
                             OR cl.cst_code LIKE 'LPF_WAIVE_PE'
                             OR cl.cst_code LIKE 'NSF_WAIVE_PE'
                             OR cl.cst_code LIKE 'OVL_WAIVE_PE'
                             OR cl.cst_code LIKE 'STMT_FEE_WAIVE_PERS'
                             OR cl.cst_code LIKE 'CARD_TARIFF'
                             OR cl.cst_code LIKE 'INS_ENROLMENT-01'
                             OR cl.cst_code LIKE 'INS_ENROLMENT-02'
                             OR cl.cst_code LIKE 'INS_ENROLMENT-03'
                             OR cl.cst_code LIKE 'INS_ENROLMENT-04'
                             OR cl.cst_code LIKE 'INS_ENROLMENT-05'
                             OR cl.cst_code LIKE 'INS_ENROLMENT-06'
                             OR cl.cst_code LIKE 'FINANCE_CHARGES_PE'
                             OR cl.cst_code LIKE 'JF_ACC_WAIVE_PE'
                             OR cl.cst_code LIKE 'AMF_WAIVE_PE'
                             OR cl.cst_code LIKE 'INS_WAIVE_PE'
                             OR cl.cst_code LIKE 'STMT_FEE_WAIVE_PE'
                             OR cl.cst_code LIKE 'MMF_WAIVE_PE'
                             OR cl.cst_code LIKE 'RE_ORDER_WAIVE_PE'
                             OR cl.cst_code LIKE 'RE_ISSUE_WAIVE_PE'
                             OR cl.cst_code LIKE 'MMF_WAIVE_CARD_PE'
                             OR cl.cst_code LIKE 'AMF_WAIVE_CARD_PE'
                             OR cl.cst_code LIKE 'RBP_FLAG'                                    
                             OR cl.cst_code LIKE 'CRLIM_MAX_IGNORE_PE'
                             OR cl.cst_code LIKE 'PAYMENT_HOLIDAY'
						     OR cl.cst_code LIKE 'DIRECT_DEBIT'
                             OR cl.cst_code LIKE 'LTY_ENROLMENT'
                             OR cl.cst_code LIKE 'MMF_WAIVE_ACC'
                             OR cl.cst_code LIKE 'PLASTIC_STATUS' ) THEN cl.csv_n_name
                     WHEN ( cl.cst_code LIKE 'BCODE-A1-' || ac.bank_code
                         OR cl.cst_code LIKE 'BCODE-A2-' || ac.bank_code
                         OR cl.cst_code LIKE 'BC_AC_DEC_M_' || ac.bank_code || '_CPY'
                         OR cl.cst_code LIKE 'BCFEAT-SCF'
                         OR cl.cst_code like 'BILLING_DAY') THEN DECODE(TO_CHAR(cl.csv_n_code), '_', NULL, cl.csv_n_code)
                     WHEN ( cl.cst_code LIKE 'STMT_FLAG_PE' ) THEN DECODE(TO_CHAR(cl.csv_n_code), 'E', 'O', 'O', 'H', 'B', ' ', cl.csv_n_code)
                     ELSE DECODE(TO_CHAR(cl.csv_n_code), '_', NULL, cl.csv_n_code) END changed_to,
                 cl.status_date amnd_date_stamp,
                 cl.amnd_officer upd_amnd_officer,
                 cl.cst_code,
                 'CLASSIFIER' grp,
                 cl.group_name
          FROM cntr ac
          JOIN cl ON ac.id = cl.acnt_contract__oid and cl.extract_in_report = 'Y'
          JOIN ap ON ap.internal_code = ac.product
)
,
con_add as
(
SELECT ap.bank_code,
    ows.opt_reports.get_logo(ap.code) logo,
    DECODE(diff.client__oid, NULL, aco.contract_number, nvl(co.client_number, co.reg_number)) as CONTRACT_NUMBER,
    diff.field_description as field_description,
    changed_from,
    changed_to,
    TO_CHAR(diff.amnd_date, 'DDMMYY HH24MISS') AS AMND_DATE_STAMP,
    ug.name   AS user_name,
    ug.group_name,
    'CLIENT' grp
FROM
    (
        SELECT
            *
        FROM
            (
                SELECT
                    lp.amnd_date,
                    lp.amnd_prev,
                    lp.amnd_officer,
                    lp.client__oid,
                    lp.acnt_contract__oid,
                    lp.amnd_state   AS amnd_state,
                    LAG(lp.amnd_prev) OVER(PARTITION 	BY lp.amnd_prev ORDER BY lp.amnd_date) AS is_first,
					
					/*********************************************************************New Values ***********************************************************************************************/
					
                    lp.first_nam    AS first_namn,
                    lp.last_nam     AS last_namn,
                    lp.e_mail       AS e_mailn,
                    lp.amnd_state   AS amnd_staten,
                    CASE WHEN adt.code = 'PERMANENT'   	THEN lp.country         ELSE NULL  END AS  prmnt_countryn,
                    CASE WHEN adt.code = 'PRESENT'  	THEN lp.country         ELSE NULL  END AS  prsnt_countryn,
                    CASE WHEN adt.code = 'WORK'   		THEN lp.address_zip     ELSE NULL  END AS  address_zipn,
                    CASE WHEN adt.code = 'PERMANENT'  	THEN lp.address_zip     ELSE NULL  END AS  prmnt_zipn,
                    CASE WHEN adt.code = 'PRESENT'  	THEN lp.address_zip     ELSE NULL  END AS  prsnt_zipn,
                    CASE WHEN adt.code = 'ADD_SMS_1'  	THEN lp.address_zip     ELSE NULL  END AS  sms_non,
                    CASE WHEN adt.code = 'WORK'   		THEN lp.state 			ELSE NULL  END AS  staten,
                    CASE WHEN adt.code = 'PERMANENT'  	THEN lp.state 			ELSE NULL  END AS  prmnt_staten,
                    CASE WHEN adt.code = 'PRESENT'  	THEN lp.state 			ELSE NULL  END AS  prsnt_staten,
                    CASE WHEN adt.code = 'WORK'   		THEN lp.city 			ELSE NULL  END AS  cityn,
                    CASE WHEN adt.code = 'PERMANENT'  	THEN lp.city 			ELSE NULL  END AS  prmnt_cityn,
                    CASE WHEN adt.code = 'PRESENT'  	THEN lp.city 			ELSE NULL  END AS  prsnt_cityn,
                    CASE WHEN adt.code = 'PERMANENT'  	THEN lp.location 		ELSE NULL  END AS  prmnt_locationn,
                    CASE WHEN adt.code = 'PRESENT'  	THEN lp.location 		ELSE NULL  END AS  prsnt_locationn,
                    CASE WHEN adt.code = 'WORK'   		THEN lp.address_line_1 	ELSE NULL  END AS  address_line_1n,
                    CASE WHEN adt.code = 'PERMANENT'  	THEN lp.address_line_1 	ELSE NULL  END AS  prmnt_bldg_namen,
                    CASE WHEN adt.code = 'PRESENT'  	THEN lp.address_line_1 	ELSE NULL  END AS  prsnt_bldg_namen,
                    CASE WHEN adt.code = 'WORK'   		THEN lp.address_line_2 	ELSE NULL  END AS  address_line_2n,
                    CASE WHEN adt.code = 'PERMANENT'  	THEN lp.address_line_2 	ELSE NULL  END AS  prmnt_lndlrd_namen,
                    CASE WHEN adt.code = 'PRESENT'  	THEN lp.address_line_2 	ELSE NULL  END AS  prsnt_lndlrd_namen,
                    CASE WHEN adt.code = 'WORK'   		THEN lp.address_line_3 	ELSE NULL  END AS  address_line_3n,
                    CASE WHEN adt.code = 'PERMANENT'  	THEN lp.address_line_3 	ELSE NULL  END AS  prmnt_house_numbern,
                    CASE WHEN adt.code = 'PRESENT'  	THEN lp.address_line_3 	ELSE NULL  END AS  prsnt_house_nbrn,
                    CASE WHEN adt.code = 'WORK'  	    THEN lp.address_line_4 	ELSE NULL  END AS  work_streetn, 
                    CASE WHEN adt.code = 'PERMANENT'  	THEN lp.address_line_4 	ELSE NULL  END AS  prmnt_streetn,
                    CASE WHEN adt.code = 'PRESENT'  	THEN lp.address_line_4 	ELSE NULL  END AS  prsnt_streetn,
                    CASE WHEN adt.code = 'ADD_SMS_1'    THEN lp.phone 			ELSE NULL  END AS  phonen,
                    CASE WHEN adt.code = 'ADD_SMS_1'    THEN lp.phone_h 		ELSE NULL  END AS  phone_hn,
                    CASE WHEN adt.code = 'ADD_SMS_1'    THEN lp.e_mail 			ELSE NULL  END AS  emailn,
                    CASE WHEN adt.code = 'ADD_SMS_1'    THEN lp.fax 			ELSE NULL  END AS  sms_faxn,
                    CASE WHEN adt.code = 'STMT_SMS'     THEN (select name from ows.address_type where id = lp.copy_to_address and amnd_state ='A') else null end as Estmt_indn,
                    CASE WHEN adt.code = 'STMT_ADDR'    THEN (select name from ows.address_type where id = lp.copy_to_address and amnd_state ='A') else null end as stmt_indn,
                    CASE WHEN adt.code = 'MAIL_ADDR'    THEN (select name from ows.address_type where id = lp.copy_to_address and amnd_state ='A') else null end as mail_addrn,
					
					/**********************************************************************Old Values ***********************************************************************************************/
					
                    LAG(TO_CHAR(lp.amnd_state)) OVER(PARTITION 	BY lp.amnd_prev ORDER BY lp.amnd_date) AS amnd_stateo,
                    LAG(lp.first_nam) 			OVER(PARTITION 	BY lp.amnd_prev ORDER BY lp.amnd_date) AS first_namo,
                    LAG(lp.last_nam) 			OVER(PARTITION 	BY lp.amnd_prev ORDER BY lp.amnd_date) AS last_namo,
                    LAG(lp.e_mail) 				OVER(PARTITION 	BY lp.amnd_prev ORDER BY lp.amnd_date) AS e_mailo,
                    CASE WHEN adt.code = 'PERMANENT'   THEN LAG(lp.country)         OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prmnt_countryo,
                    CASE WHEN adt.code = 'PRESENT'     THEN LAG(lp.country) 	    OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prsnt_countryo,
                    CASE WHEN adt.code = 'WORK'        THEN LAG(lp.address_zip)     OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  address_zipo,
                    CASE WHEN adt.code = 'PERMANENT'   THEN LAG(lp.address_zip)     OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prmnt_zipo,
                    CASE WHEN adt.code = 'PRESENT'     THEN LAG(lp.address_zip)     OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prsnt_zipo,
                    CASE WHEN adt.code = 'ADD_SMS_1'   THEN LAG(lp.address_zip)     OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  sms_noo,
                    CASE WHEN adt.code = 'WORK'   	   THEN LAG(lp.state) 		    OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  stateo,
                    CASE WHEN adt.code = 'PERMANENT'   THEN LAG(lp.state) 		    OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prmnt_stateo,
                    CASE WHEN adt.code = 'PRESENT'     THEN LAG(lp.state) 		    OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prsnt_stateo,
                    CASE WHEN adt.code = 'WORK'        THEN LAG(lp.city) 		    OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  cityo,
                    CASE WHEN adt.code = 'PERMANENT'   THEN LAG(lp.city) 		    OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prmnt_cityo,
                    CASE WHEN adt.code = 'PRESENT'     THEN LAG(lp.city) 		    OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prsnt_cityo,
                    CASE WHEN adt.code = 'PERMANENT'   THEN LAG(lp.location) 	    OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prmnt_locationo,
                    CASE WHEN adt.code = 'PRESENT'     THEN LAG(lp.location) 	    OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prsnt_locationo,
                    CASE WHEN adt.code = 'WORK'        THEN LAG(lp.address_line_1)  OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  address_line_1o,
                    CASE WHEN adt.code = 'PERMANENT'   THEN LAG(lp.address_line_1)  OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prmnt_bldg_nameo,
                    CASE WHEN adt.code = 'PRESENT'     THEN LAG(lp.address_line_1)  OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prsnt_bldg_nameo,
                    CASE WHEN adt.code = 'WORK'        THEN LAG(lp.address_line_2)  OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  address_line_2o,
                    CASE WHEN adt.code = 'PERMANENT'   THEN LAG(lp.address_line_2)  OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prmnt_lndlrd_nameo,
                    CASE WHEN adt.code = 'PRESENT'     THEN LAG(lp.address_line_2)  OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prsnt_lndlrd_nameo,
                    CASE WHEN adt.code = 'WORK'        THEN LAG(lp.address_line_3)  OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  address_line_3o,
                    CASE WHEN adt.code = 'PERMANENT'   THEN LAG(lp.address_line_3)  OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prmnt_house_numbero,
                    CASE WHEN adt.code = 'PRESENT'     THEN LAG(lp.address_line_3)  OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prsnt_house_nbro,
                    CASE WHEN adt.code = 'WORK'        THEN LAG(lp.address_line_4)  OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  work_streeto,
					CASE WHEN adt.code = 'PERMANENT'   THEN LAG(lp.address_line_4)  OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prmnt_streeto,
                    CASE WHEN adt.code = 'PRESENT'     THEN LAG(lp.address_line_4)  OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  prsnt_streeto,
                    CASE WHEN adt.code = 'ADD_SMS_1'   THEN LAG(lp.phone) 			OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  phoneo,
                    CASE WHEN adt.code = 'ADD_SMS_1'   THEN LAG(lp.phone_h) 		OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  phone_ho,
                    CASE WHEN adt.code = 'ADD_SMS_1'   THEN LAG(lp.e_mail) 			OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  emailo,
                    CASE WHEN adt.code = 'ADD_SMS_1'   THEN LAG(lp.fax) 			OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END AS  sms_faxo,
                    CASE WHEN adt.code = 'STMT_SMS'    THEN LAG((select name from ows.address_type where id = lp.copy_to_address and amnd_state ='A')) OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END  AS  estmt_indo,
                    CASE WHEN adt.code = 'STMT_ADDR'   THEN LAG((select name from ows.address_type where id = lp.copy_to_address and amnd_state ='A')) OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END  AS  stmt_indo,
                    CASE WHEN adt.code = 'MAIL_ADDR'   THEN LAG((select name from ows.address_type where id = lp.copy_to_address and amnd_state ='A')) OVER(PARTITION  BY lp.amnd_prev ORDER BY lp.amnd_Date) ELSE NULL  END  AS  mail_addro
        FROM ows.client_address lp
        JOIN ows.address_type adt ON lp.address_type = adt.id
         AND adt.amnd_state = 'A'
   LEFT JOIN ows.client_title ct ON lp.title = ct.id
         AND ct.amnd_state = 'A'
       WHERE(lp.amnd_prev) IN (SELECT amnd_prev FROM t_ca))
UNPIVOT ((changed_from,changed_to)
FOR field_description IN 
((first_namo,first_namn) 			    	AS 'NAME_LINE_1'
,(last_namo,last_namn)  				    AS 'NAME_LINE_2'
,( prmnt_countryo,prmnt_countryn )          AS 'PRMNT_COUNTRY'
,( prsnt_countryo,prsnt_countryn)           AS 'PRSNT_COUNTRY'
,(address_zipo,address_zipn)                AS 'ZIP_CODE'
,(prmnt_zipo,prmnt_zipn)                    AS 'PRMNT_ZIP'
,(prsnt_zipo,prsnt_zipn)                    AS 'PRSNT_ZIP'
,(sms_noo,sms_non)                          AS 'MOBILE_PHONE'
,(stateo,staten)                            AS 'STATE'
,(prmnt_stateo,prmnt_staten)                AS 'PRMNT_STATE'
,(prsnt_stateo,prsnt_staten)                AS 'PRSNT_STATE'
,(cityo,cityn)                              AS 'WORK_CITY'
,(prmnt_cityo,prmnt_cityn)                  AS 'PRMNT_CITY'
,(prsnt_cityo,prsnt_cityn)                  AS 'PRSNT_CITY'
,(prmnt_locationo,prmnt_locationn)          AS 'PRMNT_LOCATION'
,(prsnt_locationo,prsnt_locationn)          AS 'PRSNT_LOCATION'
,(address_line_1o,address_line_1n)          AS 'WORK_ADDRESS_LINE_1'
,(prmnt_bldg_nameo,prmnt_bldg_namen)        AS 'PRMNT_ADDR_NA_LN_1'
,(prsnt_bldg_nameo,prsnt_bldg_namen)        AS 'PRSNT_ADDR_NA_LN_1'
,(address_line_2o,address_line_2n)		    AS 'WORK_ADDRESS_LINE_2'
,(prmnt_lndlrd_nameo,prmnt_lndlrd_namen)    AS 'PRMNT_ADDR_NA_LN_2'
,(prsnt_lndlrd_nameo,prsnt_lndlrd_namen)    AS 'PRSNT_ADDR_NA_LN_2'
,(address_line_3o,address_line_3n)		    AS 'WORK_ADDRESS_LINE_3'
,(prmnt_house_numbero,prmnt_house_numbern)	AS 'PRMNT_ADDR_NA_LN_3'
,(prsnt_house_nbro,prsnt_house_nbrn)		AS 'PRSNT_ADDR_NA_LN_3'
,(work_streeto,work_streetn)				AS 'WORK_ADDRESS_LINE_4'
,(prmnt_streeto,prmnt_streetn)				AS 'PRMNT_STREET'
,(prsnt_streeto,prsnt_streetn)				AS 'PRSNT_STREET'
,(phoneo,phonen)							AS 'WORK_PHONE'
,(phone_ho,phone_hn)						AS 'HOME_PHONE'
,(emailo,emailn)							AS 'E_MAIL'
,(sms_faxo,sms_faxn) 						AS 'FAX'
,(estmt_indo,estmt_indn) 					AS 'E_STMT_IND'
,(stmt_indo,stmt_indn) 						AS 'STATEMENT_ADDR_IND'
,(mail_addro,mail_addrn) 					AS 'MAILING_ADDR_IND')
)
WHERE amnd_date >= trunc(TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy'))
  AND amnd_date < trunc(TO_DATE(:P_REPORT_DATE,'dd-MM-yyyy')) + 1
) diff
JOIN user_group ug on ug.id = diff.amnd_officer
                     
LEFT JOIN ows.client co
 ON co.id = diff.client__oid
    
LEFT JOIN cntr aco 
 ON aco.id = diff.acnt_contract__oid

JOIN ap ON ap.internal_code = aco.product
        
WHERE
    (nvl(changed_from, 0) <> nvl(changed_to, 0)
      OR diff.amnd_state = 'C' )
    AND is_first IS NOT NULL
)
SELECT BANK_CODE as ORG,
       DECODE(logo, 'AAA', '000', logo) AS logo,
       lpad(contract_number, 19, '0') AS contract_number,
       upd_amnd_officer  amnd_officer,
       amnd_date_stamp   amnd_date_stamp,
       field_description field_description,
       changed_from changed_from,
       changed_to   changed_to,
       grp,
       group_name
FROM (
     SELECT BANK_CODE,
             logo,
             contract_number,
             upd_amnd_officer,
             TO_CHAR(amnd_date_stamp, 'DDMMYY HH24MISS') amnd_date_stamp,
             field_description,
             case when field_description = 'CLIENT_NUMBER' then (select /*+ no_parallel(cl) */ cl.client_number from ows.client cl where cl.amnd_state = 'A' and cl.id = changed_from)
             else changed_from end as changed_from,
             case when field_description = 'CLIENT_NUMBER' then (select /*+ no_parallel(cl) */ cl.client_number from ows.client cl where cl.amnd_state = 'A' and cl.id = changed_to)
             else changed_to end as changed_to,
             grp,
             group_name
       FROM ts
       
       UNION
       SELECT BANK_CODE,
         logo AS logo,
         contract_number,
         upd_amnd_officer,
         TO_CHAR(amnd_date_stamp, 'DDMMYY HH24MISS') amnd_date_stamp,
         field_description,
         changed_from,
         changed_to,
         grp,
         group_name
       FROM cls_q 
       where 1 = 1
       and amnd_date_stamp >= TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy')
       and amnd_date_stamp < TO_DATE(:P_REPORT_DATE, 'dd-MM-yyyy') + 1
        
       UNION
       SELECT cr.BANK_CODE,
          cr.logo,
          cr.contract_number,
          amnd_officer,
          to_char(cr.amnd_date,'DDMMYY HH24MISS') amnd_date_stamp,
          'CREDIT_LIMIT' as field_description,
          to_char(cr.old_value) as changed_from,
          to_char(cr.new_value) as changed_to,
          cr.grp,
          group_name
       FROM cr_limit cr
          where rn = 1
          
        UNION
        SELECT BANK_CODE,
        ms.logo,
        ms.contract_number,
        ug.name as amnd_officer,
        to_char(ms.amnd_date,'DDMMYY HH24MISS') amnd_date_stamp,
        'TEMP_CR_LIMIT_DATE' as field_description,
         to_char(ms.old_value) as changed_from,
         to_char(ms.new_value) as changed_to,
         ms.grp,
         ug.group_name
       FROM main_sql ms
       JOIN USER_GROUP ug on ug.id = ms.amnd_officer
      
       union all
       select BANK_CODE,
       logo, 
	   CONTRACT_NUMBER, 
	   USER_NAME,
	   AMND_DATE_STAMP, 
	   FIELD_DESCRIPTION, 
	   CHANGED_FROM, 
	   CHANGED_TO, 
	   grp,
       group_name
       from con_add 
	   where  nvl(CHANGED_FROM,'0') <> nvl(CHANGED_TO,'0')
       
       union all
       select BANK_CODE,
       LOGO, 
	   CONTRACT_NUMBER, 
	   AMND_OFFICER, 
	   AMND_DATE_STAMP, 
	   FIELD_DESCRIPTION, 
	   CHANGED_FROM, 
	   CHANGED_TO, 
	   GRP,
       group_name
       from crs 
	   where  nvl(CHANGED_FROM,'0') <> nvl(CHANGED_TO,'0')
	   
	   union all
       select BANK_CODE,
       LOGO, 
	   CONTRACT_NUMBER, 
	   AMND_OFFICER, 
	   TO_CHAR(amnd_date_stamp, 'DDMMYY HH24MISS') amnd_date_stamp,
	   FIELD_DESCRIPTION, 
	   CHANGED_FROM as CHANGED_FROM, 
	   CHANGED_TO as CHANGED_TO,
	   GRP,
       group_name
       from clnt 
	   where nvl(CHANGED_FROM,'0') <> nvl(CHANGED_TO,'0')
       )
ORDER BY
      bank_code,
      logo,
      contract_number,
      amnd_date_stamp,
      field_description