/* PyTL_OmniReports_VISA_COBRAND_REPORTING
230124.1 = AlexanderK  = EIB-10459: Initial development
*/
SELECT
     inst.code AS org,
     d.*
 FROM
     dwh.visa_cobrand_data_isscredit d
     JOIN dwh.dwd_institution inst ON to_number(inst.code) = d.org
                                  AND inst.code = :ORG
                                  AND inst.record_state = 'A'
                                  -- AND d.r_order IS NOT NULL
 ORDER BY
     d.currency,
     d.r_order
