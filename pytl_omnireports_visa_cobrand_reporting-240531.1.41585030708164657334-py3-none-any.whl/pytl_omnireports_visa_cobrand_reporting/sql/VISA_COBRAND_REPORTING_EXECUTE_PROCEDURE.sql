BEGIN 
    dwh.opt_visa_cobrand.visa_cobrand_data_iss_load (:ORG, :P_QUARTER);
END;
