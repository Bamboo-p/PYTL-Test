__version__ = "230322.4"
__job_name__ = "PyTL_SqlLoader"
__bat_files__ = ["PyTL_SqlLoader.bat"]

