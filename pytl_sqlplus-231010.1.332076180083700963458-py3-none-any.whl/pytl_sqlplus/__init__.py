__version__ = "231010.1"
__job_name__ = "PyTL_SqlPlus"
__bat_files__ = ["NIC_SqlPlus.bat", "PyTL_SqlPlus.bat"]

