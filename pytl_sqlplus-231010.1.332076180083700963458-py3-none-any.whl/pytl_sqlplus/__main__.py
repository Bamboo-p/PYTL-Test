from __init__ import __version__
from __init__ import __job_name__
from __init__ import __bat_files__

print(f"{__version__=}")
print(f"{__job_name__=}")
print(f"{__bat_files__=}")

