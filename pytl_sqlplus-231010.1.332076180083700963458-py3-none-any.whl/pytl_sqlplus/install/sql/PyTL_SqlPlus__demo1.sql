SET SERVEROUTPUT ON

select 'PyTL_SqlPlus.install: demo1.sql' as MSG from dual;

;
exit;


