SET SERVEROUTPUT ON

select 'PyTL_SqlPlus.install: demo2.sql' as MSG from dual;

;
exit;


