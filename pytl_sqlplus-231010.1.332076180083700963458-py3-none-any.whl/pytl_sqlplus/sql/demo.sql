SET SERVEROUTPUT ON

select 'PyTL SqlPlus demo' as MSG from dual;

;
exit;


