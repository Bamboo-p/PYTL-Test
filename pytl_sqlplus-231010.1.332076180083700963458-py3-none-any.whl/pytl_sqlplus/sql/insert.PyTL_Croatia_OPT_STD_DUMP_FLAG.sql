BEGIN
    INSERT INTO &6 (
        ORG
        ,LOAD_FLAG                      -- N / Y
        ,REPORT_DATE                    -- report date passed as part of input parameter
        ,LOAD_TYPE                      -- F / I , full or incremental
        ,DUMP_NAME                      -- Table name
        -- ,REC_COUNT                      -- provide if possible , else 0
        ,UNIQUE_CALL_ID                 -- Unique call ID
    )
    VALUES (
        '&1'                            -- P_ORG
        ,'N'
        ,to_date('&2', 'DD-MM-YYYY')    -- P_REPORT_DATE
        ,'&3'                           -- P_LOAD_TYPE
        ,'&4'                           -- P_DUMP_NAME
        -- , 0      
        ,'&5'                           -- P_UNIQUE_CALL_ID
    );
    commit;
END;
/
exit;