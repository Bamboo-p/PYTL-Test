declare
    Message             dtype.LongStr%Type;
    Errm                dtype.LongStr%Type;
    Is_Process_Start    dtype.Tag%Type;
    v_consis_type_cnt   dtype.counter%type;
    v_consis_point_cnt  dtype.counter%type := 0;
    type consis_types is varray(2) of varchar(100);
    v_consis_types      consis_types;
    Process_interrupt   Exception;
begin

    sy_process.START_CURRENT_V3(
        ProcessName  => 'KSA ETL Consistency Point check',
        ProcessParms => null,
        IsUnique     => stnd.Yes,
        ToStartSub   => stnd.Yes,
        ObjectType   => null,
        ObjectId     => null,
        IsActive     => Is_Process_Start
    );

    if Is_Process_Start <> stnd.Yes  then
        Message := msg.GET_PGM_ERR0('KSA ETL CHECK:E001', 'Errors in process <<KSA ETL Consistency Point check>> starting');
        sy_process.PROCESS_MESSAGE(stnd.Error, substr(Message,3));
    end if;

    begin
        v_consis_types := consis_types('END_DAY', 'AUTH_CUT_OFF_TIME');
        v_consis_type_cnt := v_consis_types.count;

        for i in 1..v_consis_type_cnt loop
            while (v_consis_point_cnt = 0) loop
                select count(1)
                into v_consis_point_cnt
                from v_c$v_mp_consist_point mpcp1
                where mpcp1.scn = (
                    select min(mpcp2.scn)
                    from v_c$v_mp_consist_point mpcp2
                     where mpcp2.scn > (
                                        select nvl(max(etlcp.scn), 0)
                                          from etl_consist_point etlcp
                                         where etlcp.amnd_state = stnd.active
                                           and etlcp.etl_consist_type__id = nvl2(
                                                                                v_consis_types(i),
                                                                                (
                                                                                select id
                                                                                  from etl_consist_type
                                                                                 where code = v_consis_types(i)
                                                                                   and amnd_state = stnd.active
                                                                                ),
                                                                                etlcp.etl_consist_type__id
                                                                            )
                                        )
                       and mpcp2.mp_consist_type__oid = nvl2(v_consis_types(i), (
                                                                                select mct1.id
                                                                                  from
                                                                                       v_c$v_mp_consist_type mct1,
                                                                                       etl_consist_type ect
                                                                                 where mct1.code = v_consis_types(i)
                                                                                   and ect.amnd_state = stnd.active
                                                                                   and ect.code = v_consis_types(i)
                                                                                ),
                                                                                (
                                                                                select mct2.id
                                                                                  from
                                                                                        v_c$v_mp_consist_type mct2,
                                                                                        etl_consist_type ect
                                                                                 where mpcp2.mp_consist_type__oid = mct2.id
                                                                                   and mct2.code = ect.code
                                                                                  and ect.amnd_state = stnd.active
                                                                                )
                                                        )
                );

                if v_consis_point_cnt = 0 then
                    dbms_lock.sleep(60);
                end if;
            end loop;
            v_consis_point_cnt := 0;
        end loop;

        Message := msg.GET_PGM_INF0('KSA ETL CHECK:I001', 'KSA ETL Consistency points copying to Clone is completed');
        sy_process.PROCESS_MESSAGE(stnd.Information, substr(Message,3));
        commit;

    exception when others then
        Message := msg.GET_PGM_ERR(
            'KSA ETL CHECK:E002',
            'Errors in n ETL consis point check script: %% %%',
            SQLERRM,
            dbms_utility.format_error_backtrace, null
        );
        sy_process.PROCESS_MESSAGE(stnd.Error, substr(Message,3));
        stnd.PROCESS_REJECT;
        commit;
        raise Process_interrupt;
    end;

    stnd.process_end;
    commit;

end;
/
commit;

exit;
