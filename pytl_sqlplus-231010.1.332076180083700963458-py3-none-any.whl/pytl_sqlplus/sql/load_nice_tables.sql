/*
*230802.1 = OPKSAIC-5526 : Initial Version
*230815.1 = OPKSAIC-5526 : Santosh : Added commit
*/
declare
  rc           dtype. counter    %Type := 0;
  org_list     dtype. Name       %Type;
  LoadDateFrom dtype.CurrentDate %Type;
begin 
  
  rc := sy_process.process_start('inserting into OPT_DM_NICE tables', null, stnd.No);
  
  select listagg(branch_Code,',') within group (order by id) into org_list
    From dwd_institution 
   where instr(add_info,'BANKDESC=NIC') > 0
     and record_state = 'A';

  execute immediate 'alter session set optimizer_dynamic_sampling = 0';
  select max(banking_date) into LoadDateFrom from dwd_banking_date;
  DWH.opt_dm_nice.load_nice_tables(LoadDateFrom,org_list,null);

  sy_process.process_end();
  
end;
/
commit;

exit;