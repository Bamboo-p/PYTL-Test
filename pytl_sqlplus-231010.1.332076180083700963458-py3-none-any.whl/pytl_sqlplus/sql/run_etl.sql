set verify on
set serveroutput on

declare
  Message dtype.LongStr%Type;
  Errm    dtype.LongStr%Type;
begin
  dbms_output.disable();
  
  -- turn off dynamic sampling on session level for ETL related activities
  execute immediate 'alter session set optimizer_dynamic_sampling = 0';
  
  soft.start_simple(
    computername    =>  sys_context('USERENV', 'HOST', 255),
    clientapp       =>  'Main ETL And Auth ETL',
    appversion      =>  null
  );


     Message := wf_etl.COPY_NEW_CONS_POINT_CONSTYPE('END_DAY');
     If substr(Message, 1, 1) = stnd.Error then raise_application_error(-20001, message);
     end if;
	 
     message:=ETL.WF_INCREMENTAL_LOAD_ANY_TYPE('END_DAY');
     If substr(Message, 1, 1) = stnd.Error then raise_application_error(-20002, message);
     end if;
	 
	 message:=wf_etl.COPY_NEW_CONS_POINT_CONSTYPE('AUTH_CUT_OFF_TIME');
     If substr(Message, 1, 1) = stnd.Error then raise_application_error(-20003, message);
     end if;
  
     message:=ETL.WF_INCREMENTAL_LOAD_ANY_TYPE('AUTH_CUT_OFF_TIME');
     If substr(Message, 1, 1) = stnd.Error then raise_application_error(-20004, message);
     end if; 


  soft.finish_simple();
 
exception when others then
  Errm := sqlerrm;
  dbms_output.put_line(Errm);
  raise_application_error(-20020, 'Fatal error in WF Incr DWH Load all FI: ' || Errm || chr(10) || dbms_utility.FORMAT_ERROR_BACKTRACE());
end;
/
commit;

exit;