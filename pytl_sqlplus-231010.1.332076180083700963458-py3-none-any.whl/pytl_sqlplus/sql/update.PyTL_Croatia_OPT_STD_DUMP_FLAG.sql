declare
    records_count   number(22);
begin
    select
        count(ORG)
    into
        records_count
    from
        &2
    where
        UNIQUE_CALL_ID = '&1';

    update &3 set
        LOAD_FLAG = 'Y'
        ,REC_COUNT = records_count
    where
        UNIQUE_CALL_ID = '&1'
    ;
    commit;
    dbms_output.put_line( 'Saved into &2 ' || records_count || ' records with UNIQUE_CALL_ID = ''&1''');
end;
/
exit;