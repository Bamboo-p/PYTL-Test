SET SERVEROUTPUT ON

select 'PyTL_SqlPlus.uninstall: demo4.sql' as MSG from dual;

;
exit;


